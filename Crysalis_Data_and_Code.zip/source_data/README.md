# Source data for the Crysalis manuscript

Force values are in eV/Å, lengths in Å, angles in degrees, and rates in [0,1] unless a file column explicitly gives percentages. Natural logarithms are used throughout.

The keys parent_id, event_id, candidate_index, arm, and K identify parents, conditional placement events, candidate order, strategy, and candidate budget. Candidate indices in the raw records are zero-based. Context-minus-orbit differences are negative when context has the lower outcome. Missing force labels on failed candidates are not zeros.

| File or directory | Observational unit and contents |
|---|---|
| cohort_accounting.csv | Parent, event, requested-candidate, evaluated-candidate, and failure counts for both atlases. |
| atlas_events.csv | 1,092 events across two cohorts; within-event force summaries, assembly stage, and space group. |
| candidate_labels_development.csv | All 15,912 development requests, including 15 failed candidate checks. |
| candidate_labels_additional.csv | All 10,296 additional-parent requests, including eight failed candidate checks. |
| candidate_check_failures.csv | The same 23 failures, with original identifiers and failure reasons. |
| candidate_selections.csv | Paired scorer and contact selections for each event, plus NDCG@5. Development values are out-of-fold. |
| development_model_summaries.csv | Stored fold-level aggregate summaries. |
| workflow_parent.json | Original primitive-cell lattice, coordinates, species, and orbit records for mp-10302. |
| workflow_candidates.csv | The 24 stored early-event candidate geometries for the illustrated parent. |
| independent_potential_candidates.csv | Selected-candidate MatterSim observations expanded by strategy label. Several labels may share one physical candidate. |
| independent_potential_pairs.csv | One row per paired event, n = 96; each strategy column is a MatterSim maximum force. |
| independent_potential_groups.csv | Stored group summaries and paired-bootstrap intervals; select potential and grouping explicitly. |
| dft_results.csv | 36 DFT calculations with convergence flags, force values, quartile, grid, and PAW symbols. |
| dft_protocol.json | Saved single-point DFT settings. |
| dft_summary.json | DFT aggregate values. |
| dft_structures/ | 12 events × 3 geometries; POSCAR, full-coordinate P1 CIF, INCAR, KPOINTS, and POTCAR.spec. CIF uses no symmetry refinement. The electronic status is in dft_results.csv. |
| generation_summary.csv | Seventeen strategy/budget summaries, each from 512 attempted conditions. Force summaries use legal terminals. |
| generation_forces.csv | One row per legal terminal with CHGNet force. |
| generation_mattersim.csv | Per-condition saved-structure MatterSim evaluation and status for K = 8 and 24. |
| generation_paired.csv | Common legal finite-force condition pairs, including 447 at K = 24. |
| generation_trajectories.jsonl | Original recorded generation trajectories for all evaluated strategies and budgets. |
| relaxation_results.csv | One row per evaluated structure, including primary and secondary arms, raw steps, capped scores, displacements, and symmetry checks. |
| relaxation_pairs.csv | Paired comparisons. The primary filter is comparison = CONTEXT_K24_VS_ORBIT_K24, with n = 96; left is context and right is orbit-only. |
| relaxation_trajectories.jsonl | Original force histories and final fractional coordinates for the recorded fixed-cell runs. |

The capped relaxation score is 1 for structures initially below threshold, the first passage step otherwise, and 101 for failure within 100 steps. It must not be treated as raw execution time. The log1p_rms_delta column is a difference on the transformed displacement scale, not an Å-valued difference.

POTCAR.spec records the PAW symbols. Licensed PAW potential contents are not included. POSCAR files specify the DFT calculation geometries; CIF files provide coordinate exports. SI Section S9 specifies the preserved ASE 3.27.0 runtime and FIRE defaults. The individual relaxation outputs have no package lock. Additional five-seed and sensitivity-analysis files are indexed in ../supplemental_experiments/README.md.

Source dataset version: MP-20 in DiffCSP, commit `7121d159826efa2ba9500bf299250d96da37f146`.

DFT leave-one-event-out results for Section S13: `../supplemental_experiments/analysis/dft_influence.json`.
