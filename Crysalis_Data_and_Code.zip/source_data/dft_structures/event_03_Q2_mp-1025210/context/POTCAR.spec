C
Nd_3
Re_pv
Si
