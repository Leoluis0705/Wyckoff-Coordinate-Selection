Pt
Sn_d
Tb_3
