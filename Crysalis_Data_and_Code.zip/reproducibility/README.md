# Code, inputs and models

code/ contains the supplied Crysalis implementation and experiment entry points. inputs/ contains model inputs and parent structures; models/ contains model weights; splits/ and training_records/ provide fit information.

requirements_scorer_environment.txt specifies the Windows scorer-check environment. Its ASE 3.29.0 entry does not specify the separate WSL FIRE runtime. The preserved FIRE runtime contains Python 3.10 and ASE 3.27.0, with settings listed in SI Section S9. The original relaxation runner is code/scripts/run_final_bounded_relaxation_consequence.py, which invokes code/scripts/run_mattersim_fire_relaxation.py. Runner paths and external model locations must be set for the execution machine.

The historical relaxation outputs do not include a per-run package lock. The preserved runtime and earlier environment receipt agree on ASE 3.27.0.

Training and physical evaluation are separate operations. The supplemental numerical data can be read without rerunning either. CHGNet and MatterSim require their respective model weights; VASP and PAW potential contents are not redistributed.
