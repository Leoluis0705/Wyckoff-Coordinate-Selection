from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import time
from collections import Counter, defaultdict
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

import numpy as np
import torch
from pymatgen.core import Lattice

from crysalis_g1.experiments.c0_symmetry_oracle import load_recovered_parents
from crysalis_g1.experiments.context_conditional_landscape import (
    CONTEXT_FEATURE_NAMES,
    ORBIT_ONLY_FEATURE_NAMES,
    build_matched_feature_matrices,
)
from crysalis_g1.experiments.full_orbit_compatibility import (
    full_orbit_parent_free_features,
    shifted_halton_points,
)
from crysalis_g1.experiments.full_orbit_operator import FullOrbitCompatibilityMLP
from crysalis_g1.experiments.integrated_what_where import failure_class
from crysalis_g1.experiments.orbit_inverse_policy import OrbitInversePolicy
from crysalis_g1.geometry_mdn.model import WrappedMixtureDensityDecoder
from crysalis_g1.symmetry.assembly import (
    AddOrbitAction,
    C0SymmetryProjector,
    SpaceGroupLegalActionCompiler,
    SymmetryAssemblyState,
)
from crysalis_g1.symmetry.wyckoff import (
    OrbitState,
    SpaceGroupConditionedWyckoffExpander,
    WyckoffExpansionError,
)
from scripts.run_context_conditional_wyckoff_atlas import _normalized_predict
from scripts.run_full_orbit_compatibility_dataset_poc import _load_chgnet
from scripts.run_integrated_what_where_poc import (
    MAX_ORBITS,
    _candidate_orbits,
    _finite_structure,
    _load_policy_and_mdn,
    _sample_direct_mdn,
)
from scripts.run_parent_restricted_orbit_rollout import _composition
from crysalis_g1.geometry_mdn.evaluation import (
    _parent_structure,
    _receipt_structure,
    _structure_metrics,
)


SCHEMA_VERSION = "crysalis-final-generative-budget.1.0.0"
MAX_WALL_CLOCK_MINUTES = 30.0
STREAM = 20260903
K_VALUES = (4, 8, 16, 24)
ARMS = ("DIRECT_MDN", "RANDOM_LEGAL", "CONTACT", "ORBIT_ONLY", "CONTEXT")
CORE_ARMS = {"DIRECT_MDN", "ORBIT_ONLY", "CONTEXT"}
MINIMUM_DISTANCE = 0.5
BOOTSTRAP_N = 10_000


def _load_landscape(path: Path, expected_features: Sequence[str]) -> tuple[Any, Mapping[str, object]]:
    payload = torch.load(path, map_location="cpu", weights_only=True)
    if tuple(payload["feature_names"]) != tuple(expected_features):
        raise RuntimeError(f"feature schema drifted: {path}")
    model = FullOrbitCompatibilityMLP(
        input_n=int(payload["input_n"]), hidden_n=int(payload["hidden_n"])
    )
    model.load_state_dict(payload["state_dict"], strict=True)
    model.eval().requires_grad_(False)
    return model, payload["normalization"]


def _action_payload(orbit: OrbitState) -> dict[str, object]:
    return {
        "species": int(orbit.species),
        "wyckoff_letter": str(orbit.wyckoff_letter),
        "multiplicity": int(orbit.multiplicity),
        "free_dof": len(orbit.free_parameters),
    }


def _deterministic_random_index(*, parent_id: str, step: int, k: int, count: int) -> int:
    key = f"final-geometry:{STREAM}:{parent_id}:{step}:{k}:RANDOM_LEGAL"
    seed = int.from_bytes(hashlib.sha256(key.encode("utf-8")).digest()[:8], "little")
    return int(np.random.default_rng(seed).integers(0, count))


def _candidate_pool(
    *, state: SymmetryAssemblyState, selected: OrbitState, final_site_count: int,
    expander: SpaceGroupConditionedWyckoffExpander, k: int,
) -> list[dict[str, object]]:
    partial = expander.expand_many(
        state.orbits,
        state.lattice.primitive_matrix,
        require_target_space_group=False,
        require_distinct_orbit_instances=False,
    )
    framework_z = np.asarray(partial.atomic_numbers, dtype=int)
    framework_frac = np.asarray(partial.fractional_coordinates, dtype=float)
    lattice = Lattice(state.lattice.primitive_matrix)
    progress = state.site_count / final_site_count
    rows: list[dict[str, object]] = []
    for index, legal_u in enumerate(shifted_halton_points(len(selected.free_parameters), count=24)[:k]):
        row: dict[str, object] = {
            "candidate_index": index,
            "legal_u": tuple(float(value) for value in legal_u),
            "expansion_valid": False,
            "failure_reason": None,
            "target_space_group": int(state.target_space_group),
            "wyckoff_letter": str(selected.wyckoff_letter),
            "species": int(selected.species),
            "multiplicity": int(selected.multiplicity),
            "free_dof": len(selected.free_parameters),
            "lattice_a": float(lattice.a), "lattice_b": float(lattice.b), "lattice_c": float(lattice.c),
            "lattice_alpha": float(lattice.alpha), "lattice_beta": float(lattice.beta), "lattice_gamma": float(lattice.gamma),
        }
        try:
            orbit = OrbitState.create(
                state.target_space_group,
                selected.wyckoff_letter,
                selected.species,
                row["legal_u"],
                cell_transform=state.lattice.cell_transform_values,
                orbit_instance_id=selected.orbit_instance_id,
            )
            expanded = expander.expand(
                orbit,
                state.lattice.primitive_matrix,
                require_target_space_group=False,
                require_distinct_orbit_instances=False,
            )
            candidate_frac = np.asarray(expanded.fractional_coordinates, dtype=float)
            if len(candidate_frac) != selected.multiplicity:
                raise ValueError("candidate multiplicity mismatch")
            row.update(full_orbit_parent_free_features(
                lattice=lattice,
                framework_atomic_numbers=framework_z,
                framework_fractional_coordinates=framework_frac,
                candidate_atomic_number=selected.species,
                candidate_fractional_coordinates=candidate_frac,
                free_dof=len(selected.free_parameters),
                assembly_progress=progress,
            ))
            row["expansion_valid"] = True
        except (ValueError, RuntimeError, WyckoffExpansionError) as error:
            row["failure_reason"] = f"{type(error).__name__}:{error}"
        rows.append(row)
    return rows


def _select_landscape_geometry(
    *, arm: str, rows: list[dict[str, object]], parent_id: str, step: int, k: int,
    orbit_model: Any, orbit_norm: Mapping[str, object], context_model: Any,
    context_norm: Mapping[str, object],
) -> tuple[tuple[float, ...] | None, dict[str, object]]:
    valid = [row for row in rows if row["expansion_valid"]]
    audit: dict[str, object] = {
        "candidate_count": k,
        "expansion_valid_candidate_count": len(valid),
        "selected_candidate_index": None,
        "selected_candidate_rank": None,
        "predicted_compatibility_score": None,
    }
    if not valid:
        return None, audit
    if arm == "RANDOM_LEGAL":
        chosen = valid[_deterministic_random_index(parent_id=parent_id, step=step, k=k, count=len(valid))]
        ordered = valid
    elif arm == "CONTACT":
        ordered = sorted(valid, key=lambda row: (float(row["static_full_orbit_contact_score"]), int(row["candidate_index"])))
        chosen = ordered[0]
        audit["predicted_compatibility_score"] = float(chosen["static_full_orbit_contact_score"])
    else:
        orbit_x, context_x = build_matched_feature_matrices(valid)
        if arm == "ORBIT_ONLY":
            pred = _normalized_predict(orbit_model, orbit_x, orbit_norm, device="cpu")
        elif arm == "CONTEXT":
            pred = _normalized_predict(context_model, context_x, context_norm, device="cpu")
        else:
            raise RuntimeError(f"unknown landscape arm: {arm}")
        for row, value in zip(valid, pred, strict=True):
            row["predicted_compatibility_score"] = float(value)
        ordered = sorted(valid, key=lambda row: (float(row["predicted_compatibility_score"]), int(row["candidate_index"])))
        chosen = ordered[0]
        audit["predicted_compatibility_score"] = float(chosen["predicted_compatibility_score"])
    audit["selected_candidate_index"] = int(chosen["candidate_index"])
    audit["selected_candidate_rank"] = int(ordered.index(chosen) + 1)
    return tuple(float(value) for value in chosen["legal_u"]), audit


def _run_trajectory(
    *, parent: Any, arm: str, k: int, policy: OrbitInversePolicy,
    mdn: WrappedMixtureDensityDecoder, orbit_model: Any, orbit_norm: Mapping[str, object],
    context_model: Any, context_norm: Mapping[str, object], device: torch.device,
) -> tuple[dict[str, object], Any | None]:
    parent_id = str(parent.material_id)
    parent_by_id = {orbit.orbit_instance_id: orbit for orbit in parent.orbits}
    rank_by_id = {orbit_id: rank for rank, orbit_id in enumerate(sorted(parent_by_id))}
    parent_remaining = set(parent_by_id)
    state = SymmetryAssemblyState.empty(
        target_space_group=parent.target_space_group,
        composition=_composition(parent),
        lattice=parent.lattice,
    )
    compiler = SpaceGroupLegalActionCompiler(max_sites=20)
    projector = C0SymmetryProjector(minimum_distance=MINIMUM_DISTANCE)
    expander = SpaceGroupConditionedWyckoffExpander()
    final_orbit_count = len(parent.orbits)
    final_site_count = sum(int(orbit.multiplicity) for orbit in parent.orbits)
    receipt = None
    failure = None
    steps: list[dict[str, object]] = []
    for step in range(MAX_ORBITS):
        if not state.remaining_composition:
            break
        before = state
        candidates = _candidate_orbits(parent, state, parent_remaining, step, compiler)
        fraction = len(state.orbits) / final_orbit_count
        if not candidates:
            failure = "NO_LEGAL_ACTION"
            steps.append({
                "parent_id": parent_id, "stream": STREAM, "arm": arm, "K": k,
                "step_index": step + 1, "assembly_fraction": fraction,
                "selected_action": None, "free_DOF": None, "candidate_count": 0,
                "selected_u": None, "selected_candidate_rank": None,
                "geometry_source": None, "projector_status": "NOT_RUN",
                "failure_reason": failure,
            })
            break
        with torch.no_grad():
            from scripts.run_parent_restricted_orbit_rollout import _policy_batch
            logits = policy(_policy_batch(parent, state, candidates).to(device))[0]
        selected = candidates[int(torch.argmax(logits).item())]
        rank_by_id.setdefault(selected.orbit_instance_id, min(step, MAX_ORBITS - 1))
        strict_match = selected.orbit_instance_id in parent_remaining
        free_dof = len(selected.free_parameters)
        geometry_source = "FIXED"
        score = None
        audit = {"candidate_count": 0, "selected_candidate_rank": None, "selected_candidate_index": None}
        sampled: tuple[float, ...] | None
        if free_dof == 0:
            sampled = ()
        elif arm == "DIRECT_MDN" or (arm in {"CONTACT", "ORBIT_ONLY", "CONTEXT"} and fraction < 0.50):
            sampled, _ = _sample_direct_mdn(
                model=mdn, parent=parent, state=state, selected=selected,
                rank_by_id=rank_by_id, device=device, stream_seed=STREAM, step=step,
            )
            geometry_source = "DIRECT_MDN"
            audit["candidate_count"] = 1
            audit["selected_candidate_rank"] = 1
            audit["selected_candidate_index"] = 0
        else:
            geometry_source = arm
            try:
                pool = _candidate_pool(
                    state=state, selected=selected, final_site_count=final_site_count,
                    expander=expander, k=k,
                )
                sampled, audit = _select_landscape_geometry(
                    arm=arm, rows=pool, parent_id=parent_id, step=step, k=k,
                    orbit_model=orbit_model, orbit_norm=orbit_norm,
                    context_model=context_model, context_norm=context_norm,
                )
                score = audit.get("predicted_compatibility_score")
            except (ValueError, RuntimeError, WyckoffExpansionError) as error:
                sampled = None
                audit["selection_error"] = f"{type(error).__name__}:{error}"
            if sampled is None:
                failure = "NO_VALID_GEOMETRY_CANDIDATE"
        proposal = None
        if failure is None and sampled is not None:
            try:
                proposal = compiler.apply_add(state, AddOrbitAction(
                    selected.wyckoff_letter, selected.species, sampled,
                    selected.orbit_instance_id,
                ))
            except Exception as error:
                failure = "EXPANSION_FAILURE"
                audit["apply_error"] = f"{type(error).__name__}:{error}"
        if proposal is None:
            accepted = False
            reasons = [failure or "EXPANSION_FAILURE"]
        else:
            receipt = projector.project(proposal)
            accepted = bool(receipt.accepted)
            reasons = list(receipt.reason_codes)
            if accepted:
                state = proposal
                if strict_match:
                    parent_remaining.remove(selected.orbit_instance_id)
            else:
                failure = "PROJECTOR_REJECTED"
        steps.append({
            "parent_id": parent_id, "stream": STREAM, "arm": arm, "K": k,
            "step_index": step + 1, "assembly_fraction": fraction,
            "selected_action": _action_payload(selected), "free_DOF": free_dof,
            "candidate_count": int(audit.get("candidate_count", 0)),
            "selected_u": None if sampled is None else list(sampled),
            "selected_candidate_rank": audit.get("selected_candidate_rank"),
            "selected_candidate_index": audit.get("selected_candidate_index"),
            "geometry_source": geometry_source,
            "projector_status": "ACCEPTED" if accepted else "REJECTED",
            "failure_reason": failure,
            "predicted_compatibility_score": score if arm in {"ORBIT_ONLY", "CONTEXT"} else None,
        })
        if failure is not None:
            break
    if state.remaining_composition and failure is None:
        failure = "MAX_ORBITS_EXCEEDED"
    completed = not state.remaining_composition and failure is None
    legal_terminal = bool(completed and receipt is not None and compiler.can_terminate(state, receipt))
    structure = _receipt_structure(receipt) if receipt is not None else None
    metrics = _structure_metrics(_parent_structure(parent), structure)
    composition_match = bool(not state.remaining_composition and receipt is not None and receipt.composition_valid)
    target_sg_match = metrics["detected_space_group"] == parent.target_space_group
    terminal_valid = bool(legal_terminal and composition_match and target_sg_match and _finite_structure(structure))
    classification = failure_class(terminal_valid=terminal_valid, failure=failure)
    record_id = f"{STREAM}:{arm}:K{k}:{parent_id}"
    return {
        "schema_version": SCHEMA_VERSION,
        "record_id": record_id,
        "parent_id": parent_id,
        "stream": STREAM,
        "arm": arm,
        "K": k,
        "formula_sg_legal_terminal": terminal_valid,
        "geometry_rejection": classification == "GEOMETRY_ENDPOINT_REJECTION",
        "discrete_dead_end": classification == "DISCRETE_DEAD_END",
        "wrong_terminal": classification == "WRONG_TERMINAL",
        "failure": failure,
        "failure_class": classification,
        "completed_steps": sum(row["selected_action"] is not None for row in steps),
        "initial_max_force_ev_per_angstrom": None,
        "chgnet_status": "PENDING" if terminal_valid else "NOT_LEGAL_TERMINAL",
        "steps": steps,
        **metrics,
    }, structure if terminal_valid else None


def _evaluate_chgnet(model: Any, trajectories: list[dict[str, object]], structures: Mapping[str, Any]) -> None:
    pending = [row for row in trajectories if row["chgnet_status"] == "PENDING"]
    for start in range(0, len(pending), 32):
        batch = pending[start:start + 32]
        raw = model.predict_structure([structures[str(row["record_id"])] for row in batch], task="ef", batch_size=32)
        outputs = raw if isinstance(raw, list) else [raw]
        if len(outputs) != len(batch):
            raise RuntimeError("CHGNet output count mismatch")
        for row, output in zip(batch, outputs, strict=True):
            force = output["f"]
            if hasattr(force, "detach"):
                force = force.detach().cpu()
            value = float(np.linalg.norm(np.asarray(force, dtype=float), axis=-1).max())
            row["initial_max_force_ev_per_angstrom"] = value
            row["chgnet_status"] = "EVALUATED" if math.isfinite(value) else "FAILED"


def _conditions() -> list[tuple[str, int]]:
    return [("DIRECT_MDN", 1), *((arm, k) for k in K_VALUES for arm in ARMS[1:])]


def _bootstrap(values: np.ndarray, *, seed: int) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    n = len(values)
    if n == 0:
        return math.nan, math.nan
    result = np.empty(BOOTSTRAP_N)
    for index in range(BOOTSTRAP_N):
        result[index] = float(np.mean(values[rng.integers(0, n, n)]))
    return tuple(float(value) for value in np.quantile(result, [0.025, 0.975]))


def _summary(rows: list[dict[str, object]]) -> dict[str, object]:
    legal = [row for row in rows if row["formula_sg_legal_terminal"]]
    force = np.asarray([float(row["initial_max_force_ev_per_angstrom"]) for row in legal if row["chgnet_status"] == "EVALUATED"], dtype=float)
    return {
        "trajectory_n": len(rows), "legal_terminal_n": len(legal),
        "legal_terminal_rate": float(np.mean([row["formula_sg_legal_terminal"] for row in rows])),
        "geometry_rejection_rate": float(np.mean([row["geometry_rejection"] for row in rows])),
        "discrete_dead_end_rate": float(np.mean([row["discrete_dead_end"] for row in rows])),
        "wrong_terminal_rate": float(np.mean([row["wrong_terminal"] for row in rows])),
        "mean_completed_steps": float(np.mean([row["completed_steps"] for row in rows])),
        "force_n": len(force),
        "force_median": float(np.median(force)) if len(force) else math.nan,
        "force_mean": float(np.mean(force)) if len(force) else math.nan,
        "force_p75": float(np.quantile(force, .75)) if len(force) else math.nan,
        "force_p90": float(np.quantile(force, .90)) if len(force) else math.nan,
        "force_p95": float(np.quantile(force, .95)) if len(force) else math.nan,
        "gt5_rate": float(np.mean(force > 5)) if len(force) else math.nan,
        "gt10_rate": float(np.mean(force > 10)) if len(force) else math.nan,
        "gt20_rate": float(np.mean(force > 20)) if len(force) else math.nan,
    }


def _paired(left: list[dict[str, object]], right: list[dict[str, object]], *, seed: int) -> dict[str, object]:
    lmap = {str(row["parent_id"]): row for row in left if row["formula_sg_legal_terminal"] and row["chgnet_status"] == "EVALUATED"}
    rmap = {str(row["parent_id"]): row for row in right if row["formula_sg_legal_terminal"] and row["chgnet_status"] == "EVALUATED"}
    ids = sorted(lmap.keys() & rmap.keys())
    delta = np.asarray([math.log1p(float(lmap[pid]["initial_max_force_ev_per_angstrom"])) - math.log1p(float(rmap[pid]["initial_max_force_ev_per_angstrom"])) for pid in ids])
    tail = np.asarray([float(lmap[pid]["initial_max_force_ev_per_angstrom"] > 10) - float(rmap[pid]["initial_max_force_ev_per_angstrom"] > 10) for pid in ids])
    return {
        "pair_n": len(ids), "mean_delta": float(np.mean(delta)) if len(delta) else math.nan,
        "median_delta": float(np.median(delta)) if len(delta) else math.nan,
        "ci95": _bootstrap(delta, seed=seed),
        "left_win_rate": float(np.mean(delta < 0)) if len(delta) else math.nan,
        "tail_rate_difference": float(np.mean(tail)) if len(tail) else math.nan,
        "parent_ids": ids,
    }


def _analyze(trajectories: list[dict[str, object]]) -> dict[str, object]:
    by = defaultdict(list)
    for row in trajectories:
        by[(str(row["arm"]), int(row["K"]))].append(row)
    summaries = {f"{arm}:K{k}": _summary(by[(arm, k)]) for arm, k in _conditions()}
    comparisons = {}
    for k in K_VALUES:
        comparisons[f"CONTEXT_VS_ORBIT:K{k}"] = _paired(by[("CONTEXT", k)], by[("ORBIT_ONLY", k)], seed=STREAM + k)
        comparisons[f"CONTEXT_VS_CONTACT:K{k}"] = _paired(by[("CONTEXT", k)], by[("CONTACT", k)], seed=STREAM + 100 + k)
    c24 = {str(row["parent_id"]): float(row["formula_sg_legal_terminal"]) for row in by[("CONTEXT", 24)]}
    o24 = {str(row["parent_id"]): float(row["formula_sg_legal_terminal"]) for row in by[("ORBIT_ONLY", 24)]}
    ids = sorted(c24.keys() & o24.keys())
    terminal_delta = np.asarray([c24[pid] - o24[pid] for pid in ids])
    terminal_ci = _bootstrap(terminal_delta, seed=STREAM + 2400)
    equivalence = {}
    for ck in K_VALUES:
        equivalence[str(ck)] = {}
        cs = summaries[f"CONTEXT:K{ck}"]
        for metric in ("force_median", "force_p90", "gt10_rate"):
            found = [ok for ok in K_VALUES if summaries[f"ORBIT_ONLY:K{ok}"][metric] <= cs[metric]]
            equivalence[str(ck)][metric] = min(found) if found else ">24"
    c8 = summaries["CONTEXT:K8"]
    meets = sum(c8[m] <= summaries["ORBIT_ONLY:K16"][m] for m in ("force_median", "force_p90", "gt10_rate"))
    efficiency_supported = meets >= 2
    c4 = summaries["CONTEXT:K4"]
    strong = sum(c4[m] <= summaries["ORBIT_ONLY:K16"][m] for m in ("force_median", "force_p90", "gt10_rate")) >= 2
    comparison_supported = any(comparisons[f"CONTEXT_VS_ORBIT:K{k}"]["ci95"][1] < 0 for k in (16, 24))
    tail_better = summaries["CONTEXT:K24"]["gt10_rate"] < summaries["ORBIT_ONLY:K24"]["gt10_rate"]
    contact_better = any(
        summaries[f"CONTEXT:K{k}"][metric] < summaries[f"CONTACT:K{k}"][metric]
        for k in K_VALUES for metric in ("force_median", "force_p90", "gt10_rate")
    )
    noninferior = terminal_ci[0] > -0.05
    consequence = comparison_supported and tail_better and noninferior and contact_better
    co = comparisons["CONTEXT_VS_ORBIT:K24"]
    crows = {str(row["parent_id"]): row for row in by[("CONTEXT", 24)] if row["formula_sg_legal_terminal"] and row["chgnet_status"] == "EVALUATED"}
    orows = {str(row["parent_id"]): row for row in by[("ORBIT_ONLY", 24)] if row["formula_sg_legal_terminal"] and row["chgnet_status"] == "EVALUATED"}
    common = sorted(crows.keys() & orows.keys(), key=lambda pid: (float(orows[pid]["initial_max_force_ev_per_angstrom"]), pid))
    quartiles = np.array_split(common, 4)
    qrows = {}
    for qi, qids in enumerate(quartiles, 1):
        delta = np.asarray([math.log1p(float(crows[pid]["initial_max_force_ev_per_angstrom"])) - math.log1p(float(orows[pid]["initial_max_force_ev_per_angstrom"])) for pid in qids])
        qrows[f"Q{qi}"] = {"n": len(delta), "mean_delta": float(np.mean(delta)), "ci95": _bootstrap(delta, seed=STREAM + 3000 + qi)}
    q4 = qrows["Q4"]
    tail_mechanism = q4["mean_delta"] == min(row["mean_delta"] for row in qrows.values()) and q4["ci95"][1] < 0
    return {
        "summaries": summaries, "comparisons": comparisons,
        "terminal_delta_pp": float(np.mean(terminal_delta) * 100),
        "terminal_ci95_pp": (terminal_ci[0] * 100, terminal_ci[1] * 100),
        "terminal_noninferior": noninferior,
        "equivalent_orbit_budget": equivalence,
        "context_candidate_efficiency": efficiency_supported,
        "strong_efficiency_gain": strong,
        "context_generative_consequence": consequence,
        "quartiles": qrows,
        "generative_tail_mechanism": tail_mechanism,
        "common_legal_k24_n": co["pair_n"],
    }


def _write_outputs(output: Path, trajectories: list[dict[str, object]], analysis: Mapping[str, object], total_minutes: float) -> None:
    output.mkdir(parents=True, exist_ok=False)
    with (output / "FINAL_GENERATIVE_TRAJECTORIES.jsonl").open("x", encoding="utf-8", newline="\n") as handle:
        for row in trajectories:
            handle.write(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n")
    summaries = analysis["summaries"]
    with (output / "FINAL_GENERATIVE_BUDGET_RESULTS.csv").open("x", encoding="utf-8", newline="") as handle:
        fields = ["arm", "K", *next(iter(summaries.values())).keys()]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for arm, k in _conditions():
            writer.writerow({"arm": arm, "K": k, **summaries[f"{arm}:K{k}"]})
    force_fields = ["parent_id", "arm", "K", "force", "gt5", "gt10", "gt20"]
    with (output / "FINAL_GENERATIVE_FORCE_DISTRIBUTIONS.csv").open("x", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=force_fields)
        writer.writeheader()
        for row in trajectories:
            if row["chgnet_status"] == "EVALUATED":
                force = float(row["initial_max_force_ev_per_angstrom"])
                writer.writerow({"parent_id": row["parent_id"], "arm": row["arm"], "K": row["K"], "force": force, "gt5": force > 5, "gt10": force > 10, "gt20": force > 20})
    with (output / "FINAL_GENERATIVE_EFFICIENCY_CURVES.csv").open("x", encoding="utf-8", newline="") as handle:
        fields = ["arm", "K", "force_median", "force_p90", "gt10_rate", "context_equivalent_orbit_median", "context_equivalent_orbit_p90", "context_equivalent_orbit_gt10"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for k in K_VALUES:
            for arm in ARMS[1:]:
                summary = summaries[f"{arm}:K{k}"]
                eq = analysis["equivalent_orbit_budget"].get(str(k), {}) if arm == "CONTEXT" else {}
                writer.writerow({"arm": arm, "K": k, "force_median": summary["force_median"], "force_p90": summary["force_p90"], "gt10_rate": summary["gt10_rate"], "context_equivalent_orbit_median": eq.get("force_median"), "context_equivalent_orbit_p90": eq.get("force_p90"), "context_equivalent_orbit_gt10": eq.get("gt10_rate")})
    q = analysis["quartiles"]
    tail_md = "# Final Generative Tail Analysis\n\n" + "\n".join(
        f"- {name}: N={row['n']}, mean paired log1p delta={row['mean_delta']:.12f}, CI95=[{row['ci95'][0]:.12f}, {row['ci95'][1]:.12f}]"
        for name, row in q.items()
    ) + f"\n\nGENERATIVE_TAIL_MECHANISM = {'SUPPORTED' if analysis['generative_tail_mechanism'] else 'NOT_SUPPORTED'}\n"
    (output / "FINAL_GENERATIVE_TAIL_ANALYSIS.md").write_text(tail_md, encoding="utf-8")
    lines = ["# CRYSALIS Final Generative Benchmark Verdict", "", "CRYSALIS_FINAL_GENERATIVE_CANDIDATE_BUDGET = COMPLETE", "", "PARENT_N = 512", "", "STREAM_N = 1", "", f"DIRECT_MDN_LEGAL = {summaries['DIRECT_MDN:K1']['legal_terminal_rate']:.12f}", "", "RESULTS_BY_K =", ""]
    for k in K_VALUES:
        comp = analysis["comparisons"][f"CONTEXT_VS_ORBIT:K{k}"]
        lines.extend([f"K{k}:", f"RANDOM_LEGAL={summaries[f'RANDOM_LEGAL:K{k}']['legal_terminal_rate']:.12f}", f"CONTACT_LEGAL={summaries[f'CONTACT:K{k}']['legal_terminal_rate']:.12f}", f"ORBIT_LEGAL={summaries[f'ORBIT_ONLY:K{k}']['legal_terminal_rate']:.12f}", f"CONTEXT_LEGAL={summaries[f'CONTEXT:K{k}']['legal_terminal_rate']:.12f}", "", f"ORBIT_FORCE_MEDIAN={summaries[f'ORBIT_ONLY:K{k}']['force_median']:.12f}", f"CONTEXT_FORCE_MEDIAN={summaries[f'CONTEXT:K{k}']['force_median']:.12f}", "", f"ORBIT_FORCE_P90={summaries[f'ORBIT_ONLY:K{k}']['force_p90']:.12f}", f"CONTEXT_FORCE_P90={summaries[f'CONTEXT:K{k}']['force_p90']:.12f}", "", f"ORBIT_GT10_RATE={summaries[f'ORBIT_ONLY:K{k}']['gt10_rate']:.12f}", f"CONTEXT_GT10_RATE={summaries[f'CONTEXT:K{k}']['gt10_rate']:.12f}", "", f"CONTEXT_VS_ORBIT_CI95=[{comp['ci95'][0]:.12f}, {comp['ci95'][1]:.12f}]", ""])
    eq8 = analysis["equivalent_orbit_budget"]["8"]
    eq_values = [eq8[m] for m in ("force_median", "force_p90", "gt10_rate")]
    eq8_summary = max([v for v in eq_values if isinstance(v, int)], default=0) if all(v != ">24" for v in eq_values) else ">24"
    lines.extend([
        f"CONTEXT_K24_MINUS_ORBIT_K24_TERMINAL_PP = {analysis['terminal_delta_pp']:.12f}", "",
        f"TERMINAL_NONINFERIOR_CI95 = [{analysis['terminal_ci95_pp'][0]:.12f}, {analysis['terminal_ci95_pp'][1]:.12f}]", "",
        f"CONTEXT_GENERATIVE_CONSEQUENCE = {'SUPPORTED' if analysis['context_generative_consequence'] else 'NOT_SUPPORTED'}", "",
        f"CONTEXT_CANDIDATE_EFFICIENCY = {'SUPPORTED' if analysis['context_candidate_efficiency'] else 'NOT_SUPPORTED'}", "",
        f"STRONG_EFFICIENCY_GAIN = {str(analysis['strong_efficiency_gain']).lower()}", "",
        f"CONTEXT_K8_EQUIVALENT_ORBIT_BUDGET = {eq8_summary}", "",
        f"GENERATIVE_Q4_DELTA = {q['Q4']['mean_delta']:.12f}", "",
        f"GENERATIVE_Q4_CI95 = [{q['Q4']['ci95'][0]:.12f}, {q['Q4']['ci95'][1]:.12f}]", "",
        f"GENERATIVE_TAIL_MECHANISM = {'SUPPORTED' if analysis['generative_tail_mechanism'] else 'NOT_SUPPORTED'}", "",
        "NEW_MODEL_TRAINING_RUNS = 0", "", "MATTERSIM_RUNS = 0", "", "DFT_RUNS = 0", "",
        f"TOTAL_WALL_CLOCK_MINUTES = {total_minutes:.6f}", "",
        f"NEXT_ACTION = {'FINAL_GENERATIVE_MATTERSIM_VALIDATION' if analysis['context_generative_consequence'] else 'REASSESS_GENERATIVE_CONSEQUENCE'}", "",
    ])
    (output / "CRYSALIS_FINAL_GENERATIVE_BENCHMARK_VERDICT.md").write_text("\n".join(lines), encoding="utf-8")


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--recovered-parents", type=Path, required=True)
    parser.add_argument("--holdout", type=Path, required=True)
    parser.add_argument("--policy-checkpoint", type=Path, required=True)
    parser.add_argument("--mdn-checkpoint", type=Path, required=True)
    parser.add_argument("--orbit-checkpoint", type=Path, required=True)
    parser.add_argument("--context-checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    return parser.parse_args()


def main() -> None:
    started = time.monotonic()
    args = _parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    holdout = json.loads(args.holdout.read_text(encoding="utf-8"))
    parent_ids = list(map(str, holdout["parent_ids"]))
    if holdout.get("frozen") is not True or len(parent_ids) != 512 or len(set(parent_ids)) != 512:
        raise RuntimeError("final holdout contract drifted")
    parents = load_recovered_parents(args.recovered_parents)
    if not set(parent_ids) <= set(parents):
        raise RuntimeError("frozen holdout parent missing from recovered parents")
    device = torch.device(args.device)
    policy, mdn, _ = _load_policy_and_mdn(args.policy_checkpoint, args.mdn_checkpoint, device)
    orbit_model, orbit_norm = _load_landscape(args.orbit_checkpoint, ORBIT_ONLY_FEATURE_NAMES)
    context_model, context_norm = _load_landscape(args.context_checkpoint, CONTEXT_FEATURE_NAMES)
    chgnet = _load_chgnet(args.device)
    setup_seconds = time.monotonic() - started
    preflight_ids = [parent_ids[min(511, math.floor((i + 0.5) * 512 / 32))] for i in range(32)]
    preflight_set = set(preflight_ids)
    trajectories: list[dict[str, object]] = []
    structures: dict[str, Any] = {}

    def run_ids(ids: Sequence[str], *, label: str) -> None:
        total = len(ids) * len(_conditions())
        completed = 0
        for arm, k in _conditions():
            for parent_id in ids:
                row, structure = _run_trajectory(
                    parent=parents[parent_id], arm=arm, k=k, policy=policy, mdn=mdn,
                    orbit_model=orbit_model, orbit_norm=orbit_norm,
                    context_model=context_model, context_norm=context_norm, device=device,
                )
                trajectories.append(row)
                if structure is not None:
                    structures[str(row["record_id"])] = structure
                completed += 1
                if completed % 64 == 0:
                    print(json.dumps({"phase": label, "completed": completed, "total": total}), flush=True)

    variable_start = time.monotonic()
    run_ids(preflight_ids, label="PREFLIGHT_ROLLOUT")
    rollout_seconds = time.monotonic() - variable_start
    core_pre = [row for row in trajectories if row["arm"] in CORE_ARMS]
    aux_pre = [row for row in trajectories if row["arm"] not in CORE_ARMS]
    chg_start = time.monotonic()
    _evaluate_chgnet(chgnet, core_pre, structures)
    core_chg_seconds = time.monotonic() - chg_start
    chg_start = time.monotonic()
    _evaluate_chgnet(chgnet, aux_pre, structures)
    aux_chg_seconds = time.monotonic() - chg_start
    core_rollout_fraction = 9 / 17
    core_variable = rollout_seconds * core_rollout_fraction + core_chg_seconds
    full_variable = rollout_seconds + core_chg_seconds + aux_chg_seconds
    core_eta_minutes = (setup_seconds + 16 * core_variable + 20) / 60
    full_eta_minutes = (setup_seconds + 16 * full_variable + 30) / 60
    preview = {
        "phase": "PREFLIGHT_COMPLETE", "parent_n": 32,
        "setup_seconds": setup_seconds, "rollout_seconds": rollout_seconds,
        "core_chgnet_seconds": core_chg_seconds, "aux_chgnet_seconds": aux_chg_seconds,
        "core_arms_eta_minutes": core_eta_minutes, "full_arms_eta_minutes": full_eta_minutes,
        "projected_total_minutes": full_eta_minutes,
    }
    print(json.dumps(preview, sort_keys=True), flush=True)
    if full_eta_minutes > MAX_WALL_CLOCK_MINUTES:
        args.output.mkdir(parents=True, exist_ok=False)
        (args.output / "PREFLIGHT_ETA.json").write_text(json.dumps(preview, indent=2) + "\n", encoding="utf-8")
        return
    remaining_ids = [pid for pid in parent_ids if pid not in preflight_set]
    run_ids(remaining_ids, label="FULL_ROLLOUT")
    already_evaluated = {str(row["record_id"]) for row in core_pre + aux_pre}
    pending = [row for row in trajectories if str(row["record_id"]) not in already_evaluated]
    _evaluate_chgnet(chgnet, pending, structures)
    if len(trajectories) != 512 * 17:
        raise RuntimeError(f"trajectory count drifted: {len(trajectories)}")
    elapsed = (time.monotonic() - started) / 60
    if elapsed > MAX_WALL_CLOCK_MINUTES:
        raise TimeoutError(f"elapsed {elapsed:.3f} minutes exceeded 30")
    analysis = _analyze(trajectories)
    elapsed = (time.monotonic() - started) / 60
    _write_outputs(args.output, trajectories, analysis, elapsed)
    print(json.dumps({"phase": "COMPLETE", "trajectory_n": len(trajectories), "total_minutes": elapsed, "output": str(args.output)}, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
