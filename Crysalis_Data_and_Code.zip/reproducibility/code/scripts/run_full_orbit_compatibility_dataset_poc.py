from __future__ import annotations

import argparse
import csv
import json
import math
import time
from collections import Counter
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

import numpy as np
from pymatgen.core import Lattice, Structure

from crysalis_g1.experiments.c0_symmetry_oracle import load_recovered_parents
from crysalis_g1.experiments.full_orbit_compatibility import (
    FEATURE_SCHEMA,
    aggregate_poc,
    choose_event_budget,
    choose_terminal_completion_events,
    full_orbit_parent_free_features,
    shifted_halton_points,
    stratified_systematic_select,
    summarize_event_forces,
    validate_new_output_path,
)
from crysalis_g1.symmetry.assembly import (
    AddOrbitAction,
    C0SymmetryProjector,
    SpaceGroupLegalActionCompiler,
    SymmetryAssemblyState,
)
from crysalis_g1.symmetry.wyckoff import (
    OrbitState,
    SpaceGroupConditionedWyckoffExpander,
    WyckoffExpansionError,
)

SCHEMA_VERSION = "crysalis-full-orbit-compatibility-poc.1.0.0"
TARGET_EVENT_N = 64
CANDIDATE_N_PER_EVENT = 24
MAX_WALL_CLOCK_MINUTES = 25.0
MINIMUM_DISTANCE_ANGSTROM = 0.5


def _read_jsonl(path: Path) -> list[dict[str, object]]:
    rows = []
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def _composition(parent: Any) -> tuple[tuple[int, int], ...]:
    counts: Counter[int] = Counter()
    for orbit in parent.orbits:
        counts[int(orbit.species)] += int(orbit.multiplicity)
    return tuple(sorted(counts.items()))


def _preview(
    eligible: Sequence[Mapping[str, object]],
    selected: Sequence[Mapping[str, object]],
) -> dict[str, object]:
    def distribution(field: str) -> dict[str, int]:
        counts = Counter(str(row[field]) for row in selected)
        return dict(sorted(counts.items()))

    return {
        "ELIGIBLE_PARENT_N": len(eligible),
        "SELECTED_PARENT_N": len(selected),
        "POLICY_TRAIN_SELECTED_N": sum(
            row["original_split_source"] == "policy_train" for row in selected
        ),
        "POLICY_VALIDATION_SELECTED_N": sum(
            row["original_split_source"] == "policy_validation" for row in selected
        ),
        "FREE_DOF_DISTRIBUTION": distribution("free_dof"),
        "MULTIPLICITY_DISTRIBUTION": distribution("multiplicity"),
        "CRYSTAL_SYSTEM_DISTRIBUTION": distribution("crystal_system"),
        "CURRENT_SCOPE": "TERMINAL_COMPLETION_ONLY",
        "GENERAL_STEPWISE_COMPATIBILITY": "NOT_YET_TESTED",
    }


def _partial_state(parent: Any, event: Mapping[str, object]) -> SymmetryAssemblyState:
    orbit_by_id = {orbit.orbit_instance_id: orbit for orbit in parent.orbits}
    active = tuple(orbit_by_id[str(value)] for value in event["active_orbit_ids"])
    return SymmetryAssemblyState(
        target_space_group=int(parent.target_space_group),
        composition=_composition(parent),
        remaining_composition=tuple(
            (int(species), int(count))
            for species, count in event["remaining_composition"]
        ),
        lattice=parent.lattice,
        orbits=active,
    )


def _minimum_distance(structure: Structure) -> float | None:
    if len(structure) < 2:
        return None
    distances = np.asarray(structure.distance_matrix, dtype=float)
    np.fill_diagonal(distances, np.inf)
    value = float(np.min(distances))
    return value if math.isfinite(value) else None


def _empty_feature_values() -> dict[str, None]:
    return {str(entry["name"]): None for entry in FEATURE_SCHEMA}


def _candidate_base(
    event: Mapping[str, object], *, candidate_index: int, legal_u: Sequence[float]
) -> dict[str, object]:
    return {
        "schema_version": SCHEMA_VERSION,
        "event_id": str(event["event_id"]),
        "candidate_id": f"{event['event_id']}:candidate-{candidate_index:02d}",
        "candidate_index": int(candidate_index),
        "parent_id": str(event["parent_id"]),
        "original_split_source": str(event["original_split_source"]),
        "partial_state_reference": str(event["partial_state_reference"]),
        "canonical_event_index": int(event["canonical_event_index"]),
        "target_space_group": int(event["target_space_group"]),
        "action_wyckoff_position_id": str(event["wyckoff_position_id"]),
        "action_wyckoff_letter": str(event["wyckoff_letter"]),
        "action_species": int(event["species"]),
        "action_multiplicity": int(event["multiplicity"]),
        "action_free_dof": int(event["free_dof"]),
        "legal_u": tuple(float(value) for value in legal_u),
        "expanded_atom_count": 0,
        "expected_multiplicity": int(event["multiplicity"]),
        "expanded_full_orbit_coordinates": None,
        "expansion_valid": False,
        "expansion_failure_reason": None,
        "duplicate_site_status": "NOT_EVALUATED",
        "finite_geometry": False,
        "complete_atomic_numbers": None,
        "complete_fractional_coordinates": None,
        "complete_lattice": None,
        "composition_valid": False,
        "projector_accepted": False,
        "projector_reason_codes": None,
        "projector_target_space_group_match": False,
        "projector_orbit_membership_valid": False,
        "projector_distinct_orbit_instances_valid": False,
        "projector_multiplicity_valid": False,
        "minimum_distance_angstrom": None,
        **_empty_feature_values(),
        "chgnet_status": "NOT_EXPANSION_VALID",
        "chgnet_failure_reason": None,
        "initial_max_force_ev_per_angstrom": None,
        "force_target_log1p": None,
    }


def _build_candidate(
    *,
    parent: Any,
    event: Mapping[str, object],
    state: SymmetryAssemblyState,
    framework_atomic_numbers: tuple[int, ...],
    framework_coordinates: tuple[tuple[float, float, float], ...],
    legal_u: Sequence[float],
    candidate_index: int,
    compiler: SpaceGroupLegalActionCompiler,
    projector: C0SymmetryProjector,
    expander: SpaceGroupConditionedWyckoffExpander,
) -> tuple[dict[str, object], Structure | None]:
    row = _candidate_base(event, candidate_index=candidate_index, legal_u=legal_u)
    try:
        orbit = OrbitState.create(
            int(event["target_space_group"]),
            str(event["wyckoff_letter"]),
            int(event["species"]),
            tuple(float(value) for value in legal_u),
            cell_transform=parent.lattice.cell_transform_values,
            orbit_instance_id=str(event["target_orbit_id"]),
        )
        expanded = expander.expand(
            orbit,
            parent.lattice.primitive_matrix,
            require_target_space_group=False,
            require_distinct_orbit_instances=False,
        )
        row["expanded_atom_count"] = len(expanded.atomic_numbers)
        row["expanded_full_orbit_coordinates"] = expanded.fractional_coordinates
        if len(expanded.atomic_numbers) != int(event["multiplicity"]):
            row["expansion_failure_reason"] = "MULTIPLICITY_MISMATCH"
            row["duplicate_site_status"] = "FAILED"
            return row, None
        coordinates = np.asarray(expanded.fractional_coordinates, dtype=float)
        if not np.isfinite(coordinates).all():
            row["expansion_failure_reason"] = "NONFINITE_EXPANSION"
            row["duplicate_site_status"] = "FAILED"
            return row, None
        row["expansion_valid"] = True
        row["duplicate_site_status"] = "PASS"
        progress = int(event["partial_site_count"]) / int(event["complete_site_count"])
        row.update(
            full_orbit_parent_free_features(
                lattice=Lattice(parent.lattice.primitive_matrix),
                framework_atomic_numbers=np.asarray(
                    framework_atomic_numbers, dtype=int
                ),
                framework_fractional_coordinates=np.asarray(
                    framework_coordinates, dtype=float
                ),
                candidate_atomic_number=int(event["species"]),
                candidate_fractional_coordinates=coordinates,
                free_dof=int(event["free_dof"]),
                assembly_progress=progress,
            )
        )
        proposal = compiler.apply_add(
            state,
            AddOrbitAction(
                str(event["wyckoff_letter"]),
                int(event["species"]),
                tuple(float(value) for value in legal_u),
                str(event["target_orbit_id"]),
            ),
        )
        receipt = projector.project(proposal)
        full_atomic_numbers = (*framework_atomic_numbers, *expanded.atomic_numbers)
        full_coordinates = (*framework_coordinates, *expanded.fractional_coordinates)
        structure = Structure(
            Lattice(parent.lattice.primitive_matrix),
            full_atomic_numbers,
            full_coordinates,
            to_unit_cell=True,
        )
        row.update(
            {
                "finite_geometry": bool(
                    np.isfinite(np.asarray(structure.frac_coords, dtype=float)).all()
                    and np.isfinite(
                        np.asarray(structure.lattice.matrix, dtype=float)
                    ).all()
                ),
                "complete_atomic_numbers": tuple(
                    int(site.specie.Z) for site in structure
                ),
                "complete_fractional_coordinates": tuple(
                    tuple(float(value) for value in site.frac_coords)
                    for site in structure
                ),
                "complete_lattice": tuple(
                    tuple(float(value) for value in matrix_row)
                    for matrix_row in structure.lattice.matrix
                ),
                "composition_valid": Counter(full_atomic_numbers)
                == Counter(dict(_composition(parent))),
                "projector_accepted": bool(receipt.accepted),
                "projector_reason_codes": receipt.reason_codes,
                "projector_target_space_group_match": bool(
                    receipt.detected_space_groups.get(0.03)
                    == int(event["target_space_group"])
                ),
                "projector_orbit_membership_valid": bool(
                    receipt.orbit_membership_valid
                ),
                "projector_distinct_orbit_instances_valid": bool(
                    receipt.distinct_orbit_instances_valid
                ),
                "projector_multiplicity_valid": bool(receipt.multiplicity_valid),
                "minimum_distance_angstrom": _minimum_distance(structure),
                "chgnet_status": "PENDING",
            }
        )
        if not row["finite_geometry"]:
            row["chgnet_status"] = "NONFINITE_GEOMETRY"
            return row, None
        return row, structure
    except (ValueError, WyckoffExpansionError) as error:
        row["expansion_failure_reason"] = (
            f"{type(error).__name__}:{getattr(error, 'reason_code', str(error))}"
        )
        row["duplicate_site_status"] = "FAILED"
        return row, None


def _prepare_event(
    *,
    parent: Any,
    event: Mapping[str, object],
    compiler: SpaceGroupLegalActionCompiler,
    projector: C0SymmetryProjector,
    expander: SpaceGroupConditionedWyckoffExpander,
) -> dict[str, object]:
    state = _partial_state(parent, event)
    legal_keys = {
        (
            action.wyckoff_letter,
            action.species,
            action.multiplicity,
            action.free_parameter_count,
        )
        for action in compiler.legal_add_actions(state)
    }
    target_key = (
        str(event["wyckoff_letter"]),
        int(event["species"]),
        int(event["multiplicity"]),
        int(event["free_dof"]),
    )
    if target_key not in legal_keys:
        raise RuntimeError(
            f"selected target is not compiler-legal: {event['event_id']}"
        )
    partial = expander.expand_many(
        state.orbits,
        parent.lattice.primitive_matrix,
        require_target_space_group=False,
        require_distinct_orbit_instances=False,
    )
    points = shifted_halton_points(int(event["free_dof"]), count=CANDIDATE_N_PER_EVENT)
    parent_u = np.asarray(event["parent_u_star"], dtype=float)
    circular = np.abs(points - parent_u[None, :])
    circular = np.minimum(circular, 1.0 - circular)
    if np.any(np.max(circular, axis=1) <= 1e-12):
        raise RuntimeError(
            f"registered candidate collides with parent u*: {event['event_id']}"
        )
    rows = []
    structures: dict[int, Structure] = {}
    for candidate_index, legal_u in enumerate(points):
        row, structure = _build_candidate(
            parent=parent,
            event=event,
            state=state,
            framework_atomic_numbers=partial.atomic_numbers,
            framework_coordinates=partial.fractional_coordinates,
            legal_u=legal_u,
            candidate_index=candidate_index,
            compiler=compiler,
            projector=projector,
            expander=expander,
        )
        rows.append(row)
        if structure is not None:
            structures[candidate_index] = structure
    oracle_row, oracle_structure = _build_candidate(
        parent=parent,
        event=event,
        state=state,
        framework_atomic_numbers=partial.atomic_numbers,
        framework_coordinates=partial.fractional_coordinates,
        legal_u=event["parent_u_star"],
        candidate_index=-1,
        compiler=compiler,
        projector=projector,
        expander=expander,
    )
    nearest_distance = float(np.min(np.linalg.norm(circular, axis=1)))
    return {
        "event": dict(event),
        "candidate_rows": rows,
        "candidate_structures": structures,
        "oracle_row": oracle_row,
        "oracle_structure": oracle_structure,
        "parent_oracle_nearest_candidate_torus_distance": nearest_distance,
    }


def _load_chgnet(device: str) -> Any:
    import chgnet
    import torch
    from chgnet.model import CHGNet

    if chgnet.__version__ != "0.4.2":
        raise RuntimeError(f"CHGNet package drifted: {chgnet.__version__}")
    if device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")
    model = CHGNet.load(model_name="0.3.0", use_device=device, verbose=False)
    if str(getattr(model, "version", "")) != "0.3.0":
        raise RuntimeError("CHGNet model version drifted")
    model.eval()
    model.requires_grad_(False)
    return model


def _evaluate_event(model: Any, prepared: Mapping[str, object]) -> None:
    candidate_rows = prepared["candidate_rows"]
    candidate_structures = prepared["candidate_structures"]
    oracle_row = prepared["oracle_row"]
    items: list[tuple[dict[str, object], Structure]] = []
    for row in candidate_rows:
        candidate_index = int(row["candidate_index"])
        structure = candidate_structures.get(candidate_index)
        if row["chgnet_status"] == "PENDING" and structure is not None:
            items.append((row, structure))
    oracle_structure = prepared["oracle_structure"]
    if oracle_row["chgnet_status"] == "PENDING" and oracle_structure is not None:
        items.append((oracle_row, oracle_structure))
    if not items:
        return
    try:
        raw = model.predict_structure(
            [structure for _, structure in items], task="ef", batch_size=16
        )
        outputs = raw if isinstance(raw, list) else [raw]
        if len(outputs) != len(items):
            raise RuntimeError("CHGNet batch output count mismatch")
    except Exception as error:
        reason = f"{type(error).__name__}:{error}"
        for row, _ in items:
            row["chgnet_status"] = "FAILED"
            row["chgnet_failure_reason"] = reason
        return
    for (row, _), output in zip(items, outputs, strict=True):
        force = output["f"]
        if hasattr(force, "detach"):
            force = force.detach().cpu()
        array = np.asarray(force, dtype=float)
        maximum = float(np.linalg.norm(array, axis=-1).max())
        if not math.isfinite(maximum):
            row["chgnet_status"] = "FAILED"
            row["chgnet_failure_reason"] = "NONFINITE_FORCE"
            continue
        row["chgnet_status"] = "EVALUATED"
        row["initial_max_force_ev_per_angstrom"] = maximum
        row["force_target_log1p"] = math.log1p(maximum)


def _event_row(prepared: Mapping[str, object]) -> dict[str, object]:
    event = dict(prepared["event"])
    candidates = prepared["candidate_rows"]
    oracle = prepared["oracle_row"]
    summary = summarize_event_forces(candidates)
    oracle_force = oracle.get("initial_max_force_ev_per_angstrom")
    finite_forces = sorted(
        float(row["initial_max_force_ev_per_angstrom"])
        for row in candidates
        if row.get("chgnet_status") == "EVALUATED"
        and row.get("initial_max_force_ev_per_angstrom") is not None
    )
    oracle_rank = None
    oracle_percentile = None
    if oracle_force is not None and finite_forces:
        oracle_rank = 1 + sum(value < float(oracle_force) for value in finite_forces)
        oracle_percentile = oracle_rank / (len(finite_forces) + 1)
    return {
        "schema_version": SCHEMA_VERSION,
        "event_id": event["event_id"],
        "parent_id": event["parent_id"],
        "original_split_source": event["original_split_source"],
        "crystal_system": event["crystal_system"],
        "partial_state_reference": event["partial_state_reference"],
        "canonical_event_index": event["canonical_event_index"],
        "target_space_group": event["target_space_group"],
        "action_wyckoff_position_id": event["wyckoff_position_id"],
        "action_wyckoff_letter": event["wyckoff_letter"],
        "action_species": event["species"],
        "action_multiplicity": event["multiplicity"],
        "action_free_dof": event["free_dof"],
        "partial_site_count": event["partial_site_count"],
        "complete_site_count": event["complete_site_count"],
        "assembly_progress": int(event["partial_site_count"])
        / int(event["complete_site_count"]),
        "registered_candidate_n": len(candidates),
        "expansion_valid_n": sum(bool(row["expansion_valid"]) for row in candidates),
        "chgnet_finite_n": summary["finite_force_n"],
        **summary,
        "parent_oracle_posthoc_only": True,
        "parent_oracle_u": event["parent_u_star"],
        "parent_oracle_expanded_coordinates": oracle.get(
            "expanded_full_orbit_coordinates"
        ),
        "parent_oracle_status": oracle.get("chgnet_status"),
        "parent_oracle_force": oracle_force,
        "parent_oracle_log1p_force": oracle.get("force_target_log1p"),
        "parent_oracle_projector_accepted": oracle.get("projector_accepted"),
        "parent_oracle_projector_reason_codes": oracle.get("projector_reason_codes"),
        "parent_oracle_nearest_candidate_torus_distance": prepared[
            "parent_oracle_nearest_candidate_torus_distance"
        ],
        "parent_oracle_rank_equivalent": oracle_rank,
        "parent_oracle_rank_percentile": oracle_percentile,
    }


def _csv_value(value: object) -> object:
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, sort_keys=True, separators=(",", ":"))
    return value


def _write_csv(path: Path, rows: Sequence[Mapping[str, object]]) -> None:
    if not rows:
        raise ValueError(f"cannot write empty CSV: {path.name}")
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: _csv_value(row.get(key)) for key in fieldnames})


def _format_number(value: object, digits: int = 6) -> str:
    return f"{float(value):.{digits}f}"


def _results_markdown(
    *,
    preview: Mapping[str, object],
    aggregate: Mapping[str, object],
    initial_selected_expansion_valid_rate: float,
    eta: Mapping[str, object],
    total_minutes: float,
) -> str:
    return "\n".join(
        [
            "# Full-Orbit Compatibility Dataset POC Results",
            "",
            "## Frozen scope",
            "",
            "- `CURRENT_SCOPE = TERMINAL_COMPLETION_ONLY`",
            "- `GENERAL_STEPWISE_COMPATIBILITY = NOT_YET_TESTED`",
            "- `NEW_MODEL_TRAINING_RUNS = 0`",
            "- Frozen CHGNet 0.3.0 single point only; no relaxation, retry, or refill.",
            "- CHGNet force is not evidence of thermodynamic stability or synthesizability.",
            "",
            "## Cohort preview emitted before CHGNet",
            "",
            "```json",
            json.dumps(preview, indent=2, sort_keys=True),
            "```",
            "",
            "## Time gate",
            "",
            "```json",
            json.dumps(eta, indent=2, sort_keys=True),
            "```",
            "",
            "## Data quality",
            "",
            f"- Initial 64-event expansion-valid rate: `{initial_selected_expansion_valid_rate:.6f}`.",
            f"- Retained event count: `{aggregate['event_n']}`.",
            f"- Candidate grain: `{aggregate['candidate_n']}` rows = 24 per event.",
            f"- Retained expansion-valid rate: `{float(aggregate['expansion_valid_rate']):.6f}`.",
            f"- CHGNet finite rate conditional on expansion-valid: `{float(aggregate['chgnet_finite_rate']):.6f}`.",
            "",
            "## Landscape and parent-free contact sanity check",
            "",
            f"- Landscape event rate: `{float(aggregate['landscape_event_rate']):.6f}`.",
            f"- Full-orbit landscape: `{aggregate['full_orbit_landscape_exists']}`.",
            f"- Overall contact-force Spearman: `{float(aggregate['contact_force_spearman']):.6f}`.",
            f"- Mean defined event-wise Spearman: `{float(aggregate['event_mean_contact_force_spearman']):.6f}` across `{aggregate['event_contact_spearman_defined_n']}` events.",
            f"- Best within-event contact quartile force median: `{float(aggregate['best_contact_quartile_force_median']):.6f}` eV/A.",
            f"- Worst within-event contact quartile force median: `{float(aggregate['worst_contact_quartile_force_median']):.6f}` eV/A.",
            "",
            "## Decision",
            "",
            f"- `FULL_ORBIT_COMPATIBILITY_DATASET_SIGNAL = {aggregate['full_orbit_compatibility_dataset_signal']}`",
            f"- `NEXT_ACTION = {aggregate['next_action']}`",
            f"- Total wall clock: `{total_minutes:.4f}` minutes.",
            "",
        ]
    )


def _verdict_markdown(aggregate: Mapping[str, object], total_minutes: float) -> str:
    return "\n".join(
        [
            "# CRYSALIS Full-Orbit Compatibility Verdict",
            "",
            "```text",
            "CRYSALIS_FULL_ORBIT_COMPATIBILITY_POC = COMPLETE",
            "",
            f"EVENT_N = {aggregate['event_n']}",
            "",
            f"CANDIDATE_N = {aggregate['candidate_n']}",
            "",
            f"EXPANSION_VALID_RATE = {_format_number(aggregate['expansion_valid_rate'])}",
            "",
            f"CHGNET_FINITE_RATE = {_format_number(aggregate['chgnet_finite_rate'])}",
            "",
            f"FULL_ORBIT_FORCE_MEDIAN = {_format_number(aggregate['full_orbit_force_median'])}",
            "",
            f"EVENT_FORCE_IQR_MEDIAN = {_format_number(aggregate['event_force_iqr_median'])}",
            "",
            f"FULL_ORBIT_LANDSCAPE_EXISTS = {aggregate['full_orbit_landscape_exists']}",
            "",
            f"CONTACT_FORCE_SPEARMAN = {_format_number(aggregate['contact_force_spearman'])}",
            "",
            f"EVENT_MEAN_CONTACT_FORCE_SPEARMAN = {_format_number(aggregate['event_mean_contact_force_spearman'])}",
            "",
            f"BEST_CONTACT_QUARTILE_FORCE_MEDIAN = {_format_number(aggregate['best_contact_quartile_force_median'])}",
            "",
            f"WORST_CONTACT_QUARTILE_FORCE_MEDIAN = {_format_number(aggregate['worst_contact_quartile_force_median'])}",
            "",
            f"PARENT_ORACLE_FORCE_MEDIAN = {_format_number(aggregate['parent_oracle_force_median'])}",
            "",
            f"FULL_ORBIT_COMPATIBILITY_DATASET_SIGNAL = {aggregate['full_orbit_compatibility_dataset_signal']}",
            "",
            "NEW_MODEL_TRAINING_RUNS = 0",
            "",
            f"TOTAL_WALL_CLOCK_MINUTES = {total_minutes:.4f}",
            "",
            f"NEXT_ACTION = {aggregate['next_action']}",
            "```",
            "",
            "`CURRENT_SCOPE = TERMINAL_COMPLETION_ONLY`",
            "",
            "`GENERAL_STEPWISE_COMPATIBILITY = NOT_YET_TESTED`",
            "",
        ]
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--recovered-parents", type=Path, required=True)
    parser.add_argument("--observed-graph", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    started = time.monotonic()
    deadline = started + MAX_WALL_CLOCK_MINUTES * 60.0
    output = validate_new_output_path(args.output)
    parent_payload_rows = _read_jsonl(args.recovered_parents)
    parent_payloads = {str(row["material_id"]): row for row in parent_payload_rows}
    graph_rows = _read_jsonl(args.observed_graph)
    diagnostic_ids = {
        str(row["parent_id"]) for row in graph_rows if row["split"] == "diagnostic"
    }
    if len(diagnostic_ids) != 159:
        raise RuntimeError("frozen diagnostic parent count is not 159")
    eligible = choose_terminal_completion_events(
        parent_payloads, graph_rows, forbidden_parent_ids=diagnostic_ids
    )
    selected = stratified_systematic_select(eligible, target_n=TARGET_EVENT_N)
    if {str(row["parent_id"]) for row in selected} & diagnostic_ids:
        raise RuntimeError("selected cohort overlaps diagnostic parents")
    preview = _preview(eligible, selected)
    print(json.dumps({"COHORT_PREVIEW": preview}, sort_keys=True), flush=True)
    output.mkdir(parents=True, exist_ok=False)
    parents = load_recovered_parents(args.recovered_parents)
    compiler = SpaceGroupLegalActionCompiler(max_sites=20)
    projector = C0SymmetryProjector(minimum_distance=MINIMUM_DISTANCE_ANGSTROM)
    expander = SpaceGroupConditionedWyckoffExpander()
    prepared_events = []
    for event in selected:
        if time.monotonic() >= deadline:
            raise TimeoutError(
                "25-minute deadline reached during candidate construction"
            )
        prepared_events.append(
            _prepare_event(
                parent=parents[str(event["parent_id"])],
                event=event,
                compiler=compiler,
                projector=projector,
                expander=expander,
            )
        )
    initial_rows = [
        row for prepared in prepared_events for row in prepared["candidate_rows"]
    ]
    initial_expansion_valid_rate = float(
        np.mean([bool(row["expansion_valid"]) for row in initial_rows])
    )
    print(
        json.dumps(
            {
                "PRE_CHGNET_EXPANSION_VALID_RATE": initial_expansion_valid_rate,
                "PRE_CHGNET_CANDIDATE_N": len(initial_rows),
            },
            sort_keys=True,
        ),
        flush=True,
    )
    if initial_expansion_valid_rate < 0.95:
        raise RuntimeError(
            "FULL_ORBIT_ACTION_PARAMETERIZATION_PROBLEM: expansion-valid rate below 0.95"
        )
    if time.monotonic() >= deadline:
        raise TimeoutError("25-minute deadline reached before CHGNet load")
    model = _load_chgnet(args.device)
    target_event_n = 64
    eta: dict[str, object] = {}
    completed = 0
    for prepared in prepared_events:
        if completed >= target_event_n:
            break
        elapsed = time.monotonic() - started
        if elapsed >= MAX_WALL_CLOCK_MINUTES * 60.0:
            raise TimeoutError("25-minute deadline reached before minimum completion")
        _evaluate_event(model, prepared)
        completed += 1
        elapsed_minutes = (time.monotonic() - started) / 60.0
        print(
            json.dumps(
                {
                    "PROGRESS_EVENT_N": completed,
                    "EVENT_ID": prepared["event"]["event_id"],
                    "ELAPSED_MINUTES": elapsed_minutes,
                },
                sort_keys=True,
            ),
            flush=True,
        )
        if completed == 8:
            target_event_n = choose_event_budget(
                elapsed_minutes_at_eight=elapsed_minutes,
                max_wall_clock_minutes=MAX_WALL_CLOCK_MINUTES,
            )
            eta = {
                "MEASURED_EIGHT_EVENT_MINUTES": elapsed_minutes,
                "PROJECTED_64_EVENT_MINUTES": elapsed_minutes * 8.0,
                "PROJECTED_48_EVENT_MINUTES": elapsed_minutes * 6.0,
                "PROJECTED_32_EVENT_MINUTES": elapsed_minutes * 4.0,
                "RETAINED_EVENT_N": target_event_n,
            }
            print(json.dumps({"ETA_DECISION": eta}, sort_keys=True), flush=True)
    if completed != target_event_n or completed < 32:
        raise RuntimeError(
            f"registered event budget incomplete: completed {completed}, target {target_event_n}"
        )
    retained = prepared_events[:target_event_n]
    candidate_rows = [
        row for prepared in retained for row in prepared["candidate_rows"]
    ]
    event_rows = [_event_row(prepared) for prepared in retained]
    aggregate = aggregate_poc(candidate_rows, event_rows)
    event_summary_by_id = {
        str(row["event_id"]): row for row in aggregate["event_summaries"]
    }
    for row in event_rows:
        summary = event_summary_by_id[str(row["event_id"])]
        row.update({"registered_landscape_nontrivial": summary["landscape_nontrivial"]})
    if len(candidate_rows) != target_event_n * CANDIDATE_N_PER_EVENT:
        raise RuntimeError("candidate persistence grain mismatch")
    _write_csv(output / "FULL_ORBIT_COMPATIBILITY_EVENTS.csv", event_rows)
    _write_csv(output / "FULL_ORBIT_COMPATIBILITY_CANDIDATES.csv", candidate_rows)
    schema_payload = {
        "schema_version": SCHEMA_VERSION,
        "current_scope": "TERMINAL_COMPLETION_ONLY",
        "general_stepwise_compatibility": "NOT_YET_TESTED",
        "candidate_sequence": {
            "name": "shifted_halton",
            "bases": [2, 3, 5],
            "shifts": [
                math.sqrt(2.0) - 1.0,
                math.sqrt(3.0) - 1.0,
                math.sqrt(5.0) - 2.0,
            ],
            "count_per_event": 24,
        },
        "fixed_cutoff": "min(4.5,1.25*(r_i+r_j))",
        "safe_distance": "0.65*c_fixed/1.25",
        "radius_priority": [
            "atomic_radius",
            "atomic_radius_calculated",
            "1.0_angstrom_fallback",
        ],
        "registered_thresholds": {
            "expansion_valid_rate_minimum": 0.95,
            "event_finite_force_minimum": 18,
            "event_projector_accepted_minimum": 1,
            "event_log1p_force_iqr_minimum": math.log(1.25),
            "landscape_event_fraction_minimum": 0.70,
            "contact_overall_spearman_minimum": 0.30,
            "contact_event_mean_spearman_minimum": 0.20,
        },
        "feature_count": len(FEATURE_SCHEMA),
        "features": FEATURE_SCHEMA,
    }
    with (output / "FULL_ORBIT_COMPATIBILITY_FEATURE_SCHEMA.json").open(
        "x", encoding="utf-8"
    ) as stream:
        json.dump(schema_payload, stream, indent=2, sort_keys=True)
        stream.write("\n")
    elapsed_before_reports = (time.monotonic() - started) / 60.0
    with (output / "FULL_ORBIT_COMPATIBILITY_POC_RESULTS.md").open(
        "x", encoding="utf-8", newline="\n"
    ) as stream:
        stream.write(
            _results_markdown(
                preview=preview,
                aggregate=aggregate,
                initial_selected_expansion_valid_rate=initial_expansion_valid_rate,
                eta=eta,
                total_minutes=elapsed_before_reports,
            )
        )
    total_minutes = (time.monotonic() - started) / 60.0
    if total_minutes > MAX_WALL_CLOCK_MINUTES:
        raise TimeoutError("run exceeded the registered 25-minute deadline")
    with (output / "CRYSALIS_FULL_ORBIT_COMPATIBILITY_VERDICT.md").open(
        "x", encoding="utf-8", newline="\n"
    ) as stream:
        stream.write(_verdict_markdown(aggregate, total_minutes))
    print(
        json.dumps(
            {
                "RUN_COMPLETE": True,
                "EVENT_N": aggregate["event_n"],
                "CANDIDATE_N": aggregate["candidate_n"],
                "TOTAL_WALL_CLOCK_MINUTES": total_minutes,
                "SIGNAL": aggregate["full_orbit_compatibility_dataset_signal"],
            },
            sort_keys=True,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
