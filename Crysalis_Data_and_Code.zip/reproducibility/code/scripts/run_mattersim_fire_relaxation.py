from __future__ import annotations

import argparse
import hashlib
import json
import math
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
from ase import Atoms
from ase.optimize import FIRE


EXPECTED_COMMIT = "aedf510ec536cf24163edad4570eaceafdb7cb2b"
EXPECTED_WEIGHT_SHA256 = "28b0b0b0f13efefee06b47ea4c9105a26bd3e2c8396da193430da96b3b49a8be"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _symmetry(atoms: Atoms) -> tuple[int | None, int | None]:
    import spglib

    dataset = spglib.get_symmetry_dataset(
        (np.asarray(atoms.cell.array), np.asarray(atoms.get_scaled_positions(wrap=True)), np.asarray(atoms.numbers)),
        symprec=0.01,
    )
    if dataset is None:
        return None, None
    return int(dataset.number), int(len(dataset.rotations))


def _force_summary(atoms: Atoms) -> tuple[float, float, float]:
    force = np.asarray(atoms.get_forces(), dtype=float)
    norms = np.linalg.norm(force, axis=1)
    energy = float(atoms.get_potential_energy())
    values = (energy, float(norms.max()), float(norms.mean()))
    if not all(math.isfinite(value) for value in values):
        raise ValueError("nonfinite MatterSim result")
    return values


def _displacement(initial_fractional: np.ndarray, final_fractional: np.ndarray, lattice: np.ndarray) -> dict[str, float]:
    if initial_fractional.shape != final_fractional.shape:
        raise ValueError("atom mapping/order changed")
    delta = final_fractional - initial_fractional
    delta -= np.rint(delta)
    norms = np.linalg.norm(delta @ lattice, axis=1)
    return {
        "rms_atomic_displacement": float(np.sqrt(np.mean(norms**2))),
        "median_atomic_displacement": float(np.median(norms)),
        "p90_atomic_displacement": float(np.quantile(norms, 0.90)),
        "max_atomic_displacement": float(np.max(norms)),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--weight", type=Path, required=True)
    parser.add_argument("--max-minutes", type=float, required=True)
    args = parser.parse_args()
    started = time.monotonic()
    head = subprocess.run(("git", "rev-parse", "HEAD"), cwd=args.checkout, check=True, capture_output=True, text=True).stdout.strip()
    if head != EXPECTED_COMMIT:
        raise RuntimeError("MatterSim checkout identity drifted")
    if _sha256(args.weight) != EXPECTED_WEIGHT_SHA256:
        raise RuntimeError("MatterSim checkpoint identity drifted")
    rows = json.loads(args.input.read_text(encoding="utf-8"))["structures"]
    sys.path.insert(0, str(args.checkout / "src"))
    import torch
    from mattersim.forcefield import MatterSimCalculator

    if not torch.cuda.is_available():
        raise RuntimeError("MatterSim CUDA is unavailable")
    calculator = MatterSimCalculator(load_path=str(args.weight), device="cuda")
    model_load_minutes = (time.monotonic() - started) / 60.0
    evaluation_started = time.monotonic()
    results = []
    for row in rows:
        if (time.monotonic() - started) / 60.0 >= args.max_minutes:
            raise TimeoutError("MatterSim relaxation deadline reached")
        atoms = Atoms(
            numbers=row["atomic_numbers"], cell=row["lattice"],
            scaled_positions=row["fractional_coordinates"], pbc=True,
        )
        atoms.calc = calculator
        lattice = np.asarray(row["lattice"], dtype=float)
        initial_fractional = np.asarray(row["fractional_coordinates"], dtype=float)
        trajectory = []
        first_0p10 = None
        first_0p05 = None
        try:
            initial_sg, initial_ops = _symmetry(atoms)
            energy, max_force, mean_force = _force_summary(atoms)
            trajectory.append({"step": 0, "energy": energy, "max_force": max_force, "mean_force": mean_force})
            if max_force < 0.10:
                first_0p10 = 1
            if max_force < 0.05:
                first_0p05 = 1
            optimizer = FIRE(atoms, logfile=None)

            def record_step() -> None:
                nonlocal first_0p10, first_0p05
                if (time.monotonic() - started) / 60.0 >= args.max_minutes:
                    raise TimeoutError("MatterSim relaxation deadline reached")
                step = int(optimizer.nsteps)
                step_energy, step_max, step_mean = _force_summary(atoms)
                trajectory.append({"step": step, "energy": step_energy, "max_force": step_max, "mean_force": step_mean})
                if first_0p10 is None and step_max < 0.10:
                    first_0p10 = max(1, step)
                if first_0p05 is None and step_max < 0.05:
                    first_0p05 = max(1, step)

            optimizer.attach(record_step, interval=1)
            optimizer.run(fmax=0.05, steps=100)
            final_fractional = np.asarray(atoms.get_scaled_positions(wrap=True), dtype=float)
            final_sg, final_ops = _symmetry(atoms)
            displacement = _displacement(initial_fractional, final_fractional, lattice)
            if not trajectory or trajectory[-1]["step"] != int(optimizer.nsteps):
                record_step()
            result = {
                "structure_id": row["structure_id"], "status": "EVALUATED",
                "failure_reason": None, "retry_count": 0,
                "relaxation_steps": int(optimizer.nsteps),
                "steps_to_0p10": int(first_0p10) if first_0p10 is not None else 101,
                "steps_to_0p05": int(first_0p05) if first_0p05 is not None else 101,
                "converged_0p10": first_0p10 is not None,
                "converged_0p05": first_0p05 is not None,
                "final_max_force": float(trajectory[-1]["max_force"]),
                "final_mean_force": float(trajectory[-1]["mean_force"]),
                "initial_detected_sg": initial_sg, "final_detected_sg": final_sg,
                "initial_symmetry_operation_n": initial_ops, "final_symmetry_operation_n": final_ops,
                "target_sg_retained": final_sg == int(row["target_space_group"]),
                "symmetry_operation_count_change": None if initial_ops is None or final_ops is None else int(final_ops - initial_ops),
                "large_reconstruction": displacement["rms_atomic_displacement"] > 0.50 or displacement["max_atomic_displacement"] > 1.50,
                "final_fractional_coordinates": final_fractional.tolist(),
                "trajectory": trajectory,
                **displacement,
            }
        except TimeoutError:
            raise
        except Exception as error:
            result = {
                "structure_id": row["structure_id"], "status": "FAILED",
                "failure_reason": f"{type(error).__name__}:{error}", "retry_count": 0,
                "relaxation_steps": int(len(trajectory) - 1 if trajectory else 0),
                "steps_to_0p10": 101, "steps_to_0p05": 101,
                "converged_0p10": False, "converged_0p05": False,
                "final_max_force": trajectory[-1]["max_force"] if trajectory else None,
                "final_mean_force": trajectory[-1]["mean_force"] if trajectory else None,
                "initial_detected_sg": None, "final_detected_sg": None,
                "initial_symmetry_operation_n": None, "final_symmetry_operation_n": None,
                "target_sg_retained": False, "symmetry_operation_count_change": None,
                "rms_atomic_displacement": None, "median_atomic_displacement": None,
                "p90_atomic_displacement": None, "max_atomic_displacement": None,
                "large_reconstruction": None, "final_fractional_coordinates": None,
                "trajectory": trajectory,
            }
        results.append(result)
        print(json.dumps({"relaxed": len(results), "total": len(rows), "structure_id": row["structure_id"]}), flush=True)
    args.output.write_text(json.dumps({
        "schema_version": "crysalis-mattersim-fire-relaxation.1.0.0",
        "matter_sim_commit": EXPECTED_COMMIT, "weight_sha256": EXPECTED_WEIGHT_SHA256,
        "model_load_minutes": model_load_minutes,
        "evaluation_minutes": (time.monotonic() - evaluation_started) / 60.0,
        "elapsed_minutes": (time.monotonic() - started) / 60.0,
        "results": results,
    }, allow_nan=False, sort_keys=True), encoding="utf-8")


if __name__ == "__main__":
    main()
