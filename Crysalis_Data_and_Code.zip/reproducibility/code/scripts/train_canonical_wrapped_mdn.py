from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from crysalis_g1.geometry_mdn.serialization import load_packed_dataset
from crysalis_g1.geometry_mdn.training import (
    MDNTrainingConfig,
    build_batch_schedule,
    train_arm,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()

    config = MDNTrainingConfig()
    train = load_packed_dataset(args.dataset_root / "train.pt")
    validation = load_packed_dataset(args.dataset_root / "validation.pt")
    schedule = build_batch_schedule(
        train.active_dof_indices,
        updates=config.max_updates,
        batch_size=config.batch_size,
        seed=config.seed,
    )
    args.output_root.mkdir(parents=True, exist_ok=True)
    torch_schedule = args.output_root / "SHARED_BATCH_SCHEDULE.pt"
    if not torch_schedule.exists():
        import torch

        torch.save(schedule, torch_schedule)

    direct = train_arm(
        train,
        validation,
        relation_mode="direct",
        schedule=schedule,
        output_dir=args.output_root / "DIRECT_MDN",
        device=args.device,
        config=config,
        stop_update=50,
    )
    oracle = train_arm(
        train,
        validation,
        relation_mode="oracle",
        schedule=schedule,
        output_dir=args.output_root / "ORACLE_RELATION_MDN",
        device=args.device,
        config=config,
        stop_update=50,
    )
    projected_hours = (
        float(direct["seconds_per_update"])
        + float(oracle["seconds_per_update"])
    ) * config.max_updates / 3600.0
    gate = {
        "development_diagnostic": True,
        "direct_first_50": direct,
        "oracle_first_50": oracle,
        "projected_two_arm_training_hours": projected_hours,
        "runtime_gate": "PASS" if projected_hours <= 4.0 else "STOP_GT_4_HOURS",
    }
    (args.output_root / "FIRST_50_RUNTIME_GATE.json").write_text(
        json.dumps(gate, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(gate, sort_keys=True, allow_nan=False), flush=True)
    if projected_hours > 4.0:
        return

    results = {
        "direct": train_arm(
            train,
            validation,
            relation_mode="direct",
            schedule=schedule,
            output_dir=args.output_root / "DIRECT_MDN",
            device=args.device,
            config=config,
        ),
        "oracle": train_arm(
            train,
            validation,
            relation_mode="oracle",
            schedule=schedule,
            output_dir=args.output_root / "ORACLE_RELATION_MDN",
            device=args.device,
            config=config,
        ),
    }
    (args.output_root / "DIRECT_ORACLE_TRAINING_RESULT.json").write_text(
        json.dumps(results, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(results, sort_keys=True, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
