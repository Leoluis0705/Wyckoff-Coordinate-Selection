from __future__ import annotations

import argparse
import json
import sys
import time
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from crysalis_g1.full_crysalis.data import IntegratedCorpus
from crysalis_g1.geometry_mdn.dataset import (
    build_canonical_targets,
    classify_condition_groups,
)
from crysalis_g1.geometry_mdn.serialization import pack_targets, save_packed_dataset
from crysalis_g1.geometry_v2.phase2a_adapter import load_frozen_phase2a_bundles_v2


def _diagnostic_parent_ids(path: Path | None) -> tuple[str, ...]:
    if path is None:
        return ()
    values = set()
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            if line.strip():
                values.add(str(json.loads(line)["parent_id"]))
    return tuple(sorted(values))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase2a-root", type=Path, required=True)
    parser.add_argument("--runtime-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--diagnostic-records", type=Path)
    args = parser.parse_args()
    start = time.perf_counter()
    bundles = load_frozen_phase2a_bundles_v2(
        phase2a_root=args.phase2a_root,
        runtime_artifact_root=args.runtime_root,
    )
    loaded = time.perf_counter()
    corpus = IntegratedCorpus.build(bundles)
    corpus_built = time.perf_counter()
    targets = build_canonical_targets(bundles, corpus)
    targets_built = time.perf_counter()
    direct_groups = classify_condition_groups(targets, relation_mode="direct")
    oracle_groups = classify_condition_groups(targets, relation_mode="oracle")
    if direct_groups["CONDITION_ALIASING"] or oracle_groups["CONDITION_ALIASING"]:
        raise RuntimeError("CONDITIONING_REDESIGN_REQUIRED")
    output = args.output_root
    data_root = output / "canonical_dataset"
    train = tuple(item for item in targets if item.split == "train_fit")
    validation = tuple(item for item in targets if item.split == "validation")
    save_packed_dataset(pack_targets(train), data_root / "train.pt")
    save_packed_dataset(pack_targets(validation), data_root / "validation.pt")
    packed = time.perf_counter()
    diagnostic_ids = _diagnostic_parent_ids(args.diagnostic_records)
    (data_root / "diagnostic_parent_ids.json").write_text(
        json.dumps(
            {
                "development_diagnostic": True,
                "parent_count": len(diagnostic_ids),
                "parent_ids": diagnostic_ids,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    special_components = 0
    active_components = 0
    for target in targets:
        representative = target.target_equivalents[0]
        for value, active in zip(representative, target.free_dof_mask, strict=True):
            if not active:
                continue
            active_components += 1
            distance = min(abs(value - point) for point in (0.0, 0.25, 0.5, 0.75, 1.0))
            special_components += int(distance <= 0.02)
    report = {
        "schema_version": "canonical-geometry-target-audit.1.0.0",
        "development_diagnostic": True,
        "target_contract_status": "PASS",
        "target_count": len(targets),
        "train_target_count": len(train),
        "validation_target_count": len(validation),
        "diagnostic_parent_count": len(diagnostic_ids),
        "free_dof_counts": dict(Counter(sum(item.free_dof_mask) for item in targets)),
        "equivalence_size_counts": dict(Counter(len(item.target_equivalents) for item in targets)),
        "direct_condition_groups": direct_groups,
        "oracle_condition_groups": oracle_groups,
        "active_free_parameter_component_count": active_components,
        "near_special_stratum_component_count": special_components,
        "near_special_stratum_component_fraction": special_components / active_components,
        "timing_seconds": {
            "source_load": loaded - start,
            "corpus_build": corpus_built - loaded,
            "canonical_target_build": targets_built - corpus_built,
            "tensor_pack_and_write": packed - targets_built,
            "total": packed - start,
        },
    }
    output.mkdir(parents=True, exist_ok=True)
    (output / "TARGET_DATASET_AUDIT.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, sort_keys=True))


if __name__ == "__main__":
    main()
