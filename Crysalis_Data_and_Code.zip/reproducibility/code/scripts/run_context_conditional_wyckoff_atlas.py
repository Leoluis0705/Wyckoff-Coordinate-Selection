from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import time
from collections import Counter, defaultdict
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

import numpy as np
import torch
from pymatgen.core import Lattice, Structure

from crysalis_g1.experiments.assembly_depth_generalization import (
    assemble_depth_event_pool,
)
from crysalis_g1.experiments.c0_symmetry_oracle import load_recovered_parents
from crysalis_g1.experiments.context_conditional_landscape import (
    CONTEXT_FEATURE_NAMES,
    ORBIT_ONLY_FEATURE_NAMES,
    STAGES,
    action_signature,
    assembly_stage_effect,
    atlas_verdict,
    build_matched_feature_matrices,
    choose_parent_budget,
    context_value_verdict,
    cross_context_analysis,
    deterministic_parent_folds,
    select_parent_events,
    stratified_parent_order,
    summarize_landscapes,
    trainable_parameter_ratio,
)
from crysalis_g1.experiments.full_orbit_compatibility import (
    choose_terminal_completion_events,
    full_orbit_parent_free_features,
    shifted_halton_points,
)
from crysalis_g1.experiments.full_orbit_operator import (
    FullOrbitCompatibilityMLP,
    event_ranking_metrics,
    fit_fold_model,
    paired_bootstrap,
    trainable_parameter_count,
)
from crysalis_g1.experiments.compatibility_operator import predict_regressor
from crysalis_g1.symmetry.assembly import SpaceGroupLegalActionCompiler
from crysalis_g1.symmetry.wyckoff import (
    OrbitState,
    SpaceGroupConditionedWyckoffExpander,
    WyckoffExpansionError,
)
from scripts.run_compatibility_assembly_depth_generalization import (
    _partial_state,
    _teacher_complete,
)
from scripts.run_full_orbit_compatibility_dataset_poc import _load_chgnet

SCHEMA_VERSION = "crysalis-context-conditional-wyckoff-atlas.1.0.0"
MAX_TOTAL_WALL_CLOCK_MINUTES = 35.0
TARGET_PARENT_N = 256
CANDIDATE_N = 24
MODEL_UPDATES = 300
BOOTSTRAP_RESAMPLES = 10_000
REGISTERED_SEED = 20260902


def ensure_new_output(path: Path) -> Path:
    target = Path(path)
    if target.exists():
        raise FileExistsError(f"output already exists: {target}")
    return target


def _normalized_predict(
    model: FullOrbitCompatibilityMLP,
    values: np.ndarray,
    normalization: Mapping[str, object],
    *,
    device: str,
) -> np.ndarray:
    x_mean = np.asarray(normalization["x_mean"], dtype=float)
    x_scale = np.asarray(normalization["x_scale"], dtype=float)
    standardized = predict_regressor(
        model, (np.asarray(values, dtype=float) - x_mean) / x_scale, device=device
    )
    return standardized * float(normalization["y_scale"]) + float(
        normalization["y_mean"]
    )


def save_reload_checkpoint(
    *,
    path: Path,
    model: FullOrbitCompatibilityMLP,
    feature_names: Sequence[str],
    normalization: Mapping[str, object],
    sanity_x: np.ndarray,
    sanity_candidate_ids: Sequence[str],
    metadata: Mapping[str, object],
) -> dict[str, object]:
    if path.exists():
        raise FileExistsError(f"checkpoint already exists: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    input_n = len(feature_names)
    if np.asarray(sanity_x).shape[1:] != (input_n,):
        raise ValueError("sanity feature width differs from checkpoint schema")
    state_dict = {
        key: value.detach().cpu().clone() for key, value in model.state_dict().items()
    }
    reference = FullOrbitCompatibilityMLP(input_n=input_n)
    reference.load_state_dict(state_dict)
    expected = _normalized_predict(
        reference, np.asarray(sanity_x, dtype=float), normalization, device="cpu"
    )
    payload = {
        "schema_version": SCHEMA_VERSION,
        "state_dict": state_dict,
        "input_n": input_n,
        "hidden_n": 128,
        "feature_names": list(feature_names),
        "normalization": dict(normalization),
        "sanity_candidate_ids": list(map(str, sanity_candidate_ids)),
        "sanity_prediction_log1p_force": expected.tolist(),
        "metadata": dict(metadata),
    }
    torch.save(payload, path)
    loaded = torch.load(path, map_location="cpu", weights_only=True)
    reloaded = FullOrbitCompatibilityMLP(
        input_n=int(loaded["input_n"]), hidden_n=int(loaded["hidden_n"])
    )
    reloaded.load_state_dict(loaded["state_dict"])
    actual = _normalized_predict(
        reloaded,
        np.asarray(sanity_x, dtype=float),
        loaded["normalization"],
        device="cpu",
    )
    maximum_error = float(np.max(np.abs(actual - expected))) if len(expected) else 0.0
    reloadable = bool(np.allclose(actual, expected, atol=1e-7, rtol=0.0))
    if not reloadable:
        raise RuntimeError(f"checkpoint reload sanity failed: {maximum_error}")
    reloaded.eval().requires_grad_(False)
    return {
        "reloadable": reloadable,
        "maximum_absolute_error": maximum_error,
        "model": reloaded,
        "normalization": loaded["normalization"],
    }


def _read_jsonl(path: Path) -> list[dict[str, object]]:
    rows = []
    with path.open(encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as error:
                raise ValueError(f"invalid JSONL at {path}:{line_number}") from error
    return rows


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def _csv_value(value: object) -> object:
    if isinstance(value, (tuple, list, dict)):
        return json.dumps(value, sort_keys=True, separators=(",", ":"))
    if isinstance(value, np.generic):
        return value.item()
    return value


def _write_csv_new(path: Path, rows: Sequence[Mapping[str, object]]) -> None:
    if path.exists():
        raise FileExistsError(f"artifact already exists: {path}")
    if not rows:
        raise ValueError(f"cannot write empty CSV: {path.name}")
    fieldnames = []
    seen = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fieldnames.append(key)
    with path.open("x", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: _csv_value(row.get(key)) for key in fieldnames})


def _deadline(started: float, phase: str) -> None:
    elapsed = (time.monotonic() - started) / 60.0
    if elapsed >= MAX_TOTAL_WALL_CLOCK_MINUTES:
        raise TimeoutError(
            f"{phase} exceeded {MAX_TOTAL_WALL_CLOCK_MINUTES:g} wall-clock minutes"
        )


def _terminal_event_adapter(
    event: Mapping[str, object], parent_payload: Mapping[str, object]
) -> dict[str, object]:
    final_n = len(parent_payload["orbits"])  # type: ignore[arg-type]
    active_n = len(event["active_orbit_ids"])  # type: ignore[arg-type]
    return {
        **event,
        "event_base_id": str(event["event_id"]),
        "active_orbit_count": active_n,
        "final_orbit_count": final_n,
        "active_orbit_fraction": active_n / final_n,
        "missing_orbit_count": 1,
    }


def _event_is_officially_legal(
    event: Mapping[str, object],
    parent: Any,
    compiler: SpaceGroupLegalActionCompiler,
    expander: SpaceGroupConditionedWyckoffExpander,
) -> bool:
    try:
        state = _partial_state(parent, event)
        legal = {
            (
                action.wyckoff_letter,
                int(action.species),
                int(action.multiplicity),
                int(action.free_parameter_count),
            )
            for action in compiler.legal_add_actions(state)
        }
        expected = (
            str(event["wyckoff_letter"]),
            int(event["species"]),
            int(event["multiplicity"]),
            int(event["free_dof"]),
        )
        target = next(
            orbit
            for orbit in parent.orbits
            if orbit.orbit_instance_id == str(event["target_orbit_id"])
        )
        expanded = expander.expand(
            target,
            parent.lattice.primitive_matrix,
            require_target_space_group=False,
            require_distinct_orbit_instances=False,
        )
        return bool(
            expected in legal
            and len(expanded.atomic_numbers) == int(event["multiplicity"])
            and np.isfinite(np.asarray(expanded.fractional_coordinates, dtype=float)).all()
        )
    except (StopIteration, ValueError, WyckoffExpansionError):
        return False


def select_structural_parent_cohort(
    parent_rows: Sequence[Mapping[str, object]],
    events: Sequence[Mapping[str, object]],
    *,
    target_n: int,
) -> tuple[list[str], list[dict[str, object]]]:
    ordered = stratified_parent_order(parent_rows)
    if len(ordered) < target_n:
        raise RuntimeError(
            f"eligible Atlas parent count {len(ordered)} is below {target_n}"
        )
    selected_ids = [str(row["parent_id"]) for row in ordered[:target_n]]
    rank = {parent_id: index for index, parent_id in enumerate(selected_ids)}
    stage_rank = {stage: index for index, stage in enumerate(STAGES)}
    selected_events = [
        dict(event) for event in events if str(event["parent_id"]) in rank
    ]
    selected_events.sort(
        key=lambda event: (
            rank[str(event["parent_id"])],
            stage_rank[str(event["stage"])],
        )
    )
    return selected_ids, selected_events


def _preflight(args: argparse.Namespace) -> tuple[dict[str, Any], list[dict[str, object]], list[str], dict[str, object]]:
    recovered = load_recovered_parents(args.recovered_parents)
    parent_payloads = {key: value.to_dict() for key, value in recovered.items()}
    graph_rows = _read_jsonl(args.state_graph)
    split_rows = _read_csv(args.development_split)
    split_counts = Counter(row["split"] for row in split_rows)
    if split_counts != Counter(
        {"policy_train": 6911, "policy_validation": 768, "diagnostic": 159}
    ):
        raise RuntimeError(f"development split drifted: {split_counts}")
    diagnostic_ids = {row["parent_id"] for row in split_rows if row["split"] == "diagnostic"}
    terminal_training_ids = {
        row["parent_id"] for row in _read_csv(args.terminal_training_events)
    }
    assembly_depth_ids = {
        row["parent_id"] for row in _read_csv(args.assembly_depth_events)
    }
    if (
        len(diagnostic_ids) != 159
        or len(terminal_training_ids) != 64
        or len(assembly_depth_ids) != 32
    ):
        raise RuntimeError("registered compatibility exclusion counts drifted")
    forbidden = diagnostic_ids | terminal_training_ids | assembly_depth_ids
    depth = assemble_depth_event_pool(
        parent_payloads, graph_rows, forbidden_parent_ids=forbidden
    )
    terminal = choose_terminal_completion_events(
        parent_payloads, graph_rows, forbidden_parent_ids=forbidden
    )
    combined = [
        *depth,
        *(
            _terminal_event_adapter(event, parent_payloads[str(event["parent_id"])])
            for event in terminal
        ),
    ]
    chosen = select_parent_events(combined)
    by_parent: dict[str, list[dict[str, object]]] = defaultdict(list)
    for event in chosen:
        by_parent[str(event["parent_id"])].append(event)
    parent_rows = []
    for parent_id, events in by_parent.items():
        parent = parent_payloads[parent_id]
        orbits = list(parent["orbits"])  # type: ignore[arg-type]
        parent_rows.append(
            {
                "parent_id": parent_id,
                "crystal_system": str(parent["lattice"]["crystal_system"]),  # type: ignore[index]
                "element_count": len({int(orbit["species"]) for orbit in orbits}),
                "final_orbit_count": len(orbits),
                "available_free_dof_classes": tuple(
                    sorted({int(event["free_dof"]) for event in events})
                ),
            }
        )
    ordered_ids, structural_events = select_structural_parent_cohort(
        parent_rows, chosen, target_n=TARGET_PARENT_N
    )
    compiler = SpaceGroupLegalActionCompiler(max_sites=20)
    expander = SpaceGroupConditionedWyckoffExpander()
    events = [
        event
        for event in structural_events
        if _event_is_officially_legal(
            event, recovered[str(event["parent_id"])], compiler, expander
        )
    ]
    stage_counts = Counter(str(event["stage"]) for event in events)
    preview = {
        "eligible_parent_n": len(parent_rows),
        "selected_parent_n": len(ordered_ids),
        "event_n_256": len(events),
        "stage_counts_256": dict(stage_counts),
        "excluded_terminal_training_parent_n": len(terminal_training_ids),
        "excluded_assembly_depth_parent_n": len(assembly_depth_ids),
        "excluded_diagnostic_parent_n": len(diagnostic_ids),
        "forbidden_overlap_n": len(set(ordered_ids) & forbidden),
        "future_parent_info_used_for_selection": False,
    }
    if preview["forbidden_overlap_n"] != 0:
        raise RuntimeError("Atlas cohort overlaps a forbidden parent set")
    return recovered, events, ordered_ids, preview


def _candidate_records(
    *,
    event: Mapping[str, object],
    parent: Any,
    expander: SpaceGroupConditionedWyckoffExpander,
) -> list[dict[str, object]]:
    state = _partial_state(parent, event)
    partial = expander.expand_many(
        state.orbits,
        parent.lattice.primitive_matrix,
        require_target_space_group=False,
        require_distinct_orbit_instances=False,
    )
    framework_z = np.asarray(partial.atomic_numbers, dtype=int)
    framework_frac = np.asarray(partial.fractional_coordinates, dtype=float)
    lattice = Lattice(parent.lattice.primitive_matrix)
    assembly_progress = state.site_count / sum(count for _, count in state.composition)
    parent_u = np.asarray(event["parent_u_star"], dtype=float)
    result = []
    for candidate_index, legal_u_array in enumerate(
        shifted_halton_points(int(event["free_dof"]), count=CANDIDATE_N)
    ):
        legal_u = tuple(float(value) for value in legal_u_array)
        delta = np.abs(np.asarray(legal_u, dtype=float) - parent_u)
        if float(np.max(np.minimum(delta, 1.0 - delta))) <= 1e-12:
            raise RuntimeError(f"registered candidate contains parent u*: {event['event_id']}")
        row: dict[str, object] = {
            "schema_version": SCHEMA_VERSION,
            "candidate_id": f"{event['event_id']}:candidate-{candidate_index:02d}",
            "candidate_index": candidate_index,
            "event_id": str(event["event_id"]),
            "parent_id": str(event["parent_id"]),
            "stage": str(event["stage"]),
            "S_reference": json.dumps(
                {
                    "parent_id": str(event["parent_id"]),
                    "graph_line_number": int(event["graph_line_number"]),
                    "active_orbit_ids": list(event["active_orbit_ids"]),
                },
                sort_keys=True,
                separators=(",", ":"),
            ),
            "target_space_group": int(event["target_space_group"]),
            "wyckoff_position_id": str(event["wyckoff_position_id"]),
            "wyckoff_letter": str(event["wyckoff_letter"]),
            "species": int(event["species"]),
            "multiplicity": int(event["multiplicity"]),
            "free_dof": int(event["free_dof"]),
            "legal_u": legal_u,
            "lattice_a": float(lattice.a),
            "lattice_b": float(lattice.b),
            "lattice_c": float(lattice.c),
            "lattice_alpha": float(lattice.alpha),
            "lattice_beta": float(lattice.beta),
            "lattice_gamma": float(lattice.gamma),
            "expanded_orbit": None,
            "expansion_valid": False,
            "candidate_valid": False,
            "chgnet_status": "NOT_EVALUATED",
            "initial_max_force_ev_per_angstrom": None,
            "failure_reason": None,
            "future_parent_info_used_for_selection": False,
        }
        structure = None
        try:
            candidate_orbit = OrbitState.create(
                int(event["target_space_group"]),
                str(event["wyckoff_letter"]),
                int(event["species"]),
                legal_u,
                cell_transform=parent.lattice.cell_transform_values,
                orbit_instance_id=str(event["target_orbit_id"]),
            )
            expanded = expander.expand(
                candidate_orbit,
                parent.lattice.primitive_matrix,
                require_target_space_group=False,
                require_distinct_orbit_instances=False,
            )
            candidate_frac = np.asarray(expanded.fractional_coordinates, dtype=float)
            if len(candidate_frac) != int(event["multiplicity"]):
                raise ValueError("candidate multiplicity mismatch")
            features = full_orbit_parent_free_features(
                lattice=lattice,
                framework_atomic_numbers=framework_z,
                framework_fractional_coordinates=framework_frac,
                candidate_atomic_number=int(event["species"]),
                candidate_fractional_coordinates=candidate_frac,
                free_dof=int(event["free_dof"]),
                assembly_progress=assembly_progress,
            )
            row.update(features)
            row["expanded_orbit"] = candidate_frac.tolist()
            row["expansion_valid"] = True
            # Parent future geometry is accessed only after all selectable features exist.
            structure = _teacher_complete(
                parent=parent,
                target_orbit_id=str(event["target_orbit_id"]),
                selected_u=legal_u,
                expander=expander,
            )
        except (ValueError, RuntimeError, WyckoffExpansionError) as error:
            row["failure_reason"] = f"{type(error).__name__}:{error}"
            row["chgnet_status"] = "FAILED"
        result.append({"row": row, "structure": structure})
    return result


def _evaluate_chgnet(
    model: Any, records: Sequence[dict[str, object]], started: float
) -> None:
    pending = [record for record in records if record["structure"] is not None]
    for start in range(0, len(pending), 16):
        _deadline(started, "CHGNet Atlas evaluation")
        batch = pending[start : start + 16]
        try:
            raw = model.predict_structure(
                [record["structure"] for record in batch], task="ef", batch_size=16
            )
            outputs = raw if isinstance(raw, list) else [raw]
            if len(outputs) != len(batch):
                raise RuntimeError("CHGNet batch output count mismatch")
        except Exception as error:
            reason = f"{type(error).__name__}:{error}"
            for record in batch:
                record["row"]["chgnet_status"] = "FAILED"  # type: ignore[index]
                record["row"]["failure_reason"] = reason  # type: ignore[index]
            continue
        for record, output in zip(batch, outputs, strict=True):
            force = output["f"]
            if hasattr(force, "detach"):
                force = force.detach().cpu()
            array = np.asarray(force, dtype=float)
            maximum = float(np.linalg.norm(array, axis=-1).max())
            row = record["row"]
            if math.isfinite(maximum) and maximum >= 0.0:
                row["chgnet_status"] = "EVALUATED"  # type: ignore[index]
                row["candidate_valid"] = True  # type: ignore[index]
                row["initial_max_force_ev_per_angstrom"] = maximum  # type: ignore[index]
            else:
                row["chgnet_status"] = "FAILED"  # type: ignore[index]
                row["failure_reason"] = "NONFINITE_FORCE"  # type: ignore[index]


def _model_seed(label: str) -> int:
    return int(
        hashlib.sha256(f"{REGISTERED_SEED}:wyckoff-atlas:{label}".encode()).hexdigest()[:8],
        16,
    )


def _cross_validate(
    *,
    label: str,
    features: np.ndarray,
    target: np.ndarray,
    parent_ids: np.ndarray,
    fold_by_parent: Mapping[str, int],
    device: str,
    started: float,
) -> dict[str, object]:
    prediction = np.full(len(target), np.nan, dtype=float)
    fold_rows = []
    for fold in range(4):
        _deadline(started, f"{label} cross-validation")
        test_mask = np.asarray(
            [fold_by_parent[str(parent_id)] == fold for parent_id in parent_ids],
            dtype=bool,
        )
        train_indices = np.flatnonzero(~test_mask)
        test_indices = np.flatnonzero(test_mask)
        if not len(train_indices) or not len(test_indices):
            raise RuntimeError(f"empty parent-disjoint fold: {fold}")
        fitted = fit_fold_model(
            x_train=features[train_indices],
            y_train=target[train_indices],
            x_test=features[test_indices],
            device=device,
            seed=_model_seed(f"{label}:fold-{fold}"),
            deadline=time.monotonic()
            + max(0.0, MAX_TOTAL_WALL_CLOCK_MINUTES * 60.0 - (time.monotonic() - started)),
            updates=MODEL_UPDATES,
        )
        prediction[test_indices] = np.asarray(fitted["prediction"], dtype=float)
        fold_rows.append(
            {
                "row_type": "TRAINING_FOLD",
                "model": label,
                "fold": fold,
                "train_parent_n": len(set(parent_ids[train_indices].astype(str))),
                "held_out_parent_n": len(set(parent_ids[test_indices].astype(str))),
                "train_candidate_n": len(train_indices),
                "held_out_candidate_n": len(test_indices),
                "parameter_n": trainable_parameter_count(fitted["model"]),
                "final_training_loss": float(fitted["final_training_loss"]),
            }
        )
        del fitted
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    if not np.isfinite(prediction).all():
        raise RuntimeError(f"{label} OOF prediction is incomplete")
    return {"prediction": prediction, "fold_rows": fold_rows}


def _evaluate_predictions(
    *,
    candidate_rows: Sequence[Mapping[str, object]],
    orbit_prediction: np.ndarray,
    context_prediction: np.ndarray,
    fold_by_parent: Mapping[str, int],
) -> dict[str, object]:
    by_event: dict[str, list[int]] = defaultdict(list)
    for index, row in enumerate(candidate_rows):
        by_event[str(row["event_id"])].append(index)
    event_rows = []
    for event_id in sorted(by_event):
        indices = np.asarray(
            sorted(by_event[event_id], key=lambda index: int(candidate_rows[index]["candidate_index"])),
            dtype=int,
        )
        force = np.asarray(
            [candidate_rows[index]["initial_max_force_ev_per_angstrom"] for index in indices],
            dtype=float,
        )
        orbit_metrics = event_ranking_metrics(
            force=force, prediction=orbit_prediction[indices]
        )
        context_metrics = event_ranking_metrics(
            force=force, prediction=context_prediction[indices]
        )
        contact_local = int(
            np.argmin(
                [float(candidate_rows[index]["static_full_orbit_contact_score"]) for index in indices]
            )
        )
        first = candidate_rows[int(indices[0])]
        orbit_force = float(orbit_metrics["top1_force"])
        context_force = float(context_metrics["top1_force"])
        event_rows.append(
            {
                "row_type": "EVENT",
                "event_id": event_id,
                "parent_id": str(first["parent_id"]),
                "stage": str(first["stage"]),
                "fold": fold_by_parent[str(first["parent_id"])],
                "candidate_n": len(indices),
                "orbit_only_ndcg5": float(orbit_metrics["ndcg5"]),
                "context_ndcg5": float(context_metrics["ndcg5"]),
                "orbit_only_spearman": float(orbit_metrics["spearman"]),
                "context_spearman": float(context_metrics["spearman"]),
                "orbit_only_pairwise_accuracy": float(orbit_metrics["pairwise_accuracy"]),
                "context_pairwise_accuracy": float(context_metrics["pairwise_accuracy"]),
                "orbit_only_top1_force": orbit_force,
                "context_top1_force": context_force,
                "contact_top1_force": float(force[contact_local]),
                "context_minus_orbit_log1p_force": math.log1p(context_force) - math.log1p(orbit_force),
            }
        )
    fold_rows = []
    fold_deltas = []
    for fold in range(4):
        rows = [row for row in event_rows if int(row["fold"]) == fold]
        delta = float(np.mean([row["context_minus_orbit_log1p_force"] for row in rows]))
        fold_deltas.append(delta)
        fold_rows.append(
            {
                "row_type": "FOLD_SUMMARY",
                "fold": fold,
                "event_n": len(rows),
                "orbit_only_ndcg5": float(np.mean([row["orbit_only_ndcg5"] for row in rows])),
                "context_ndcg5": float(np.mean([row["context_ndcg5"] for row in rows])),
                "orbit_only_top1_force": float(np.median([row["orbit_only_top1_force"] for row in rows])),
                "context_top1_force": float(np.median([row["context_top1_force"] for row in rows])),
                "context_minus_orbit_log1p_force": delta,
            }
        )
    orbit_force = np.asarray([row["orbit_only_top1_force"] for row in event_rows], dtype=float)
    context_force = np.asarray([row["context_top1_force"] for row in event_rows], dtype=float)
    comparison = paired_bootstrap(
        context_force,
        orbit_force,
        resamples=BOOTSTRAP_RESAMPLES,
        seed=REGISTERED_SEED,
    )
    aggregate = {
        "orbit_only_ndcg5": float(np.mean([row["orbit_only_ndcg5"] for row in event_rows])),
        "context_ndcg5": float(np.mean([row["context_ndcg5"] for row in event_rows])),
        "orbit_only_spearman": float(np.mean([row["orbit_only_spearman"] for row in event_rows])),
        "context_spearman": float(np.mean([row["context_spearman"] for row in event_rows])),
        "orbit_only_pairwise_accuracy": float(np.mean([row["orbit_only_pairwise_accuracy"] for row in event_rows])),
        "context_pairwise_accuracy": float(np.mean([row["context_pairwise_accuracy"] for row in event_rows])),
        "orbit_only_top1_force": float(np.median(orbit_force)),
        "context_top1_force": float(np.median(context_force)),
        "contact_top1_force": float(np.median([row["contact_top1_force"] for row in event_rows])),
    }
    stage_summary = {}
    stage_rows = []
    for stage in STAGES:
        rows = [row for row in event_rows if row["stage"] == stage]
        summary = {
            "orbit_ndcg5": float(np.mean([row["orbit_only_ndcg5"] for row in rows])),
            "context_ndcg5": float(np.mean([row["context_ndcg5"] for row in rows])),
            "orbit_top1_force": float(np.median([row["orbit_only_top1_force"] for row in rows])),
            "context_top1_force": float(np.median([row["context_top1_force"] for row in rows])),
        }
        stage_summary[stage] = summary
        stage_rows.append({"row_type": "STAGE_SUMMARY", "stage": stage, "event_n": len(rows), **summary})
    return {
        "event_rows": event_rows,
        "fold_rows": fold_rows,
        "stage_rows": stage_rows,
        "stage_summary": stage_summary,
        "aggregate": aggregate,
        "comparison": comparison,
        "fold_deltas": fold_deltas,
    }


def _fit_full_model(
    *,
    label: str,
    features: np.ndarray,
    target: np.ndarray,
    device: str,
    started: float,
) -> dict[str, object]:
    sanity_n = min(64, len(features))
    return fit_fold_model(
        x_train=features,
        y_train=target,
        x_test=features[:sanity_n],
        device=device,
        seed=_model_seed(f"{label}:full"),
        deadline=time.monotonic()
        + max(0.0, MAX_TOTAL_WALL_CLOCK_MINUTES * 60.0 - (time.monotonic() - started)),
        updates=MODEL_UPDATES,
    )


def _context_shuffle_control(
    *,
    events: Sequence[Mapping[str, object]],
    candidate_rows: Sequence[Mapping[str, object]],
    recovered: Mapping[str, Any],
    model: FullOrbitCompatibilityMLP,
    normalization: Mapping[str, object],
) -> dict[str, object]:
    event_by_id = {str(event["event_id"]): event for event in events}
    by_signature: dict[tuple[int, str, int, int, str], list[Mapping[str, object]]] = defaultdict(list)
    for event in events:
        by_signature[action_signature(event)].append(event)
    swap_by_event = {}
    for signature_events in by_signature.values():
        if len({str(event["parent_id"]) for event in signature_events}) < 4:
            continue
        ordered = sorted(signature_events, key=lambda event: (str(event["parent_id"]), str(event["event_id"])))
        for index, event in enumerate(ordered):
            for offset in range(1, len(ordered)):
                other = ordered[(index + offset) % len(ordered)]
                if str(other["parent_id"]) != str(event["parent_id"]):
                    swap_by_event[str(event["event_id"])] = other
                    break
    expander = SpaceGroupConditionedWyckoffExpander()
    by_event: dict[str, list[Mapping[str, object]]] = defaultdict(list)
    for row in candidate_rows:
        if str(row["event_id"]) in swap_by_event:
            by_event[str(row["event_id"])].append(row)
    correlations = []
    retained = []
    for event_id, rows in by_event.items():
        swapped_event = swap_by_event[event_id]
        swapped_parent = recovered[str(swapped_event["parent_id"])]
        swapped_state = _partial_state(swapped_parent, swapped_event)
        partial = expander.expand_many(
            swapped_state.orbits,
            swapped_parent.lattice.primitive_matrix,
            require_target_space_group=False,
            require_distinct_orbit_instances=False,
        )
        lattice = Lattice(swapped_parent.lattice.primitive_matrix)
        progress = swapped_state.site_count / sum(count for _, count in swapped_state.composition)
        original_context = []
        shuffled_context = []
        for row in sorted(rows, key=lambda value: int(value["candidate_index"])):
            original_context.append(row)
            candidate_frac = np.asarray(row["expanded_orbit"], dtype=float)
            features = full_orbit_parent_free_features(
                lattice=lattice,
                framework_atomic_numbers=np.asarray(partial.atomic_numbers, dtype=int),
                framework_fractional_coordinates=np.asarray(partial.fractional_coordinates, dtype=float),
                candidate_atomic_number=int(row["species"]),
                candidate_fractional_coordinates=candidate_frac,
                free_dof=int(row["free_dof"]),
                assembly_progress=progress,
            )
            shuffled_context.append({**row, **features})
        _, original_x = build_matched_feature_matrices(original_context)
        _, shuffled_x = build_matched_feature_matrices(shuffled_context)
        original_prediction = _normalized_predict(model, original_x, normalization, device="cpu")
        shuffled_prediction = _normalized_predict(model, shuffled_x, normalization, device="cpu")
        correlation = float(
            np.corrcoef(
                np.argsort(np.argsort(original_prediction)),
                np.argsort(np.argsort(shuffled_prediction)),
            )[0, 1]
        )
        if math.isfinite(correlation):
            correlations.append(correlation)
        retained.append(int(np.argmin(original_prediction) == np.argmin(shuffled_prediction)))
    return {
        "shuffled_event_n": len(by_event),
        "prediction_rank_correlation_median": float(np.median(correlations)) if correlations else math.nan,
        "top1_retention_rate": float(np.mean(retained)) if retained else math.nan,
        "new_chgnet_runs": 0,
    }


def _fmt(value: object, digits: int = 12) -> str:
    if value is None:
        return "NA"
    number = float(value)
    return f"{number:.{digits}f}" if math.isfinite(number) else "nan"


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--recovered-parents", type=Path, required=True)
    parser.add_argument("--state-graph", type=Path, required=True)
    parser.add_argument("--development-split", type=Path, required=True)
    parser.add_argument("--terminal-training-events", type=Path, required=True)
    parser.add_argument("--assembly-depth-events", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    parser.add_argument("--preflight-only", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = _parse_args()
    ensure_new_output(args.output)
    started = time.monotonic()
    recovered, events_256, parent_ids_256, preview = _preflight(args)
    print(json.dumps({"phase": "PREFLIGHT", **preview}, sort_keys=True), flush=True)
    if args.preflight_only:
        return
    if args.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")

    event_counts = {}
    for parent_n in (256, 192, 128):
        retained = set(parent_ids_256[:parent_n])
        event_counts[parent_n] = sum(
            str(event["parent_id"]) in retained for event in events_256
        )
    expander = SpaceGroupConditionedWyckoffExpander()
    chgnet = _load_chgnet(args.device)
    records: list[dict[str, object]] = []
    first_event_n = min(16, len(events_256))
    for event in events_256[:first_event_n]:
        records.extend(
            _candidate_records(
                event=event,
                parent=recovered[str(event["parent_id"])],
                expander=expander,
            )
        )
    _evaluate_chgnet(chgnet, records, started)
    elapsed_at_16 = (time.monotonic() - started) / 60.0
    parent_n = choose_parent_budget(
        elapsed_minutes_at_16=elapsed_at_16, event_counts=event_counts
    )
    projected = {
        key: elapsed_at_16 * value / 16.0 for key, value in event_counts.items()
    }
    print(
        json.dumps(
            {
                "phase": "ETA_DECISION",
                "measured_16_event_minutes": elapsed_at_16,
                "projected_total_minutes": projected,
                "retained_parent_n": parent_n,
            },
            sort_keys=True,
        ),
        flush=True,
    )
    retained_parent_ids = parent_ids_256[:parent_n]
    retained_set = set(retained_parent_ids)
    events = [event for event in events_256 if str(event["parent_id"]) in retained_set]
    if events[:first_event_n] != events_256[:first_event_n]:
        raise RuntimeError("nested ETA cohort invariant failed")
    for block_start in range(first_event_n, len(events), 16):
        block_records = []
        for event in events[block_start : block_start + 16]:
            _deadline(started, "Atlas candidate construction")
            block_records.extend(
                _candidate_records(
                    event=event,
                    parent=recovered[str(event["parent_id"])],
                    expander=expander,
                )
            )
        _evaluate_chgnet(chgnet, block_records, started)
        records.extend(block_records)
        print(
            json.dumps(
                {
                    "phase": "ATLAS",
                    "completed_event_n": min(block_start + 16, len(events)),
                    "total_event_n": len(events),
                    "elapsed_minutes": (time.monotonic() - started) / 60.0,
                },
                sort_keys=True,
            ),
            flush=True,
        )
    del chgnet
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    candidate_rows = [record["row"] for record in records]
    if len(candidate_rows) != len(events) * CANDIDATE_N:
        raise RuntimeError("Atlas candidate persistence grain mismatch")
    if any(bool(row["future_parent_info_used_for_selection"]) for row in candidate_rows):
        raise RuntimeError("future parent information leaked into selection")

    landscape = summarize_landscapes(events, candidate_rows)
    summary_by_event = {
        str(row["event_id"]): row for row in landscape["event_summaries"]
    }
    event_rows = [
        {
            "schema_version": SCHEMA_VERSION,
            **event,
            **summary_by_event[str(event["event_id"])],
            "action_signature": action_signature(event),
            "future_parent_info_used_for_selection": False,
        }
        for event in events
    ]
    cross_context = cross_context_analysis(events, candidate_rows)
    finite_rows = [row for row in candidate_rows if row["chgnet_status"] == "EVALUATED"]
    orbit_x, context_x = build_matched_feature_matrices(finite_rows)
    target = np.log1p(
        np.asarray(
            [row["initial_max_force_ev_per_angstrom"] for row in finite_rows],
            dtype=float,
        )
    )
    parent_values = np.asarray([str(row["parent_id"]) for row in finite_rows], dtype=object)
    fold_by_parent = deterministic_parent_folds(retained_parent_ids)
    ratio = trainable_parameter_ratio(orbit_x.shape[1], context_x.shape[1])
    if not 0.7 <= ratio <= 1.3:
        raise RuntimeError(f"matched model parameter ratio out of range: {ratio}")
    orbit_cv = _cross_validate(
        label="ORBIT_ONLY",
        features=orbit_x,
        target=target,
        parent_ids=parent_values,
        fold_by_parent=fold_by_parent,
        device=args.device,
        started=started,
    )
    context_cv = _cross_validate(
        label="CONTEXT_CONDITIONAL",
        features=context_x,
        target=target,
        parent_ids=parent_values,
        fold_by_parent=fold_by_parent,
        device=args.device,
        started=started,
    )
    evaluation = _evaluate_predictions(
        candidate_rows=finite_rows,
        orbit_prediction=np.asarray(orbit_cv["prediction"], dtype=float),
        context_prediction=np.asarray(context_cv["prediction"], dtype=float),
        fold_by_parent=fold_by_parent,
    )
    aggregate = evaluation["aggregate"]
    comparison = evaluation["comparison"]
    context_value = context_value_verdict(
        orbit_ndcg5=float(aggregate["orbit_only_ndcg5"]),
        context_ndcg5=float(aggregate["context_ndcg5"]),
        orbit_top1_force=float(aggregate["orbit_only_top1_force"]),
        context_top1_force=float(aggregate["context_top1_force"]),
        fold_top1_log_deltas=evaluation["fold_deltas"],
        ci_upper=float(comparison["ci_upper"]),
    )
    stage_effect = assembly_stage_effect(evaluation["stage_summary"])
    stage_rugged = landscape["stage_rugged_rate"]
    verdict = atlas_verdict(
        overall_rugged_rate=float(landscape["overall_rugged_rate"]),
        mid_rugged_rate=float(stage_rugged["MID"]),
        late_rugged_rate=float(stage_rugged["LATE"]),
        context_value=str(context_value["status"]),
        cross_context_spearman_median=float(cross_context["spearman_median"]),
    )

    orbit_full = _fit_full_model(
        label="ORBIT_ONLY", features=orbit_x, target=target, device=args.device, started=started
    )
    context_full = _fit_full_model(
        label="CONTEXT_CONDITIONAL", features=context_x, target=target, device=args.device, started=started
    )
    args.output.mkdir(parents=True, exist_ok=False)
    model_dir = args.output / "CONTEXT_LANDSCAPE_MODELS"
    sanity_n = min(64, len(finite_rows))
    sanity_ids = [str(row["candidate_id"]) for row in finite_rows[:sanity_n]]
    orbit_reload = save_reload_checkpoint(
        path=model_dir / "orbit_only.pt",
        model=orbit_full["model"],
        feature_names=ORBIT_ONLY_FEATURE_NAMES,
        normalization=orbit_full["normalization"],
        sanity_x=orbit_x[:sanity_n],
        sanity_candidate_ids=sanity_ids,
        metadata={
            "model_label": "ORBIT_ONLY",
            "updates": MODEL_UPDATES,
            "parameter_n": trainable_parameter_count(orbit_full["model"]),
            "seed": _model_seed("ORBIT_ONLY:full"),
        },
    )
    context_reload = save_reload_checkpoint(
        path=model_dir / "context_conditional.pt",
        model=context_full["model"],
        feature_names=CONTEXT_FEATURE_NAMES,
        normalization=context_full["normalization"],
        sanity_x=context_x[:sanity_n],
        sanity_candidate_ids=sanity_ids,
        metadata={
            "model_label": "CONTEXT_CONDITIONAL",
            "updates": MODEL_UPDATES,
            "parameter_n": trainable_parameter_count(context_full["model"]),
            "seed": _model_seed("CONTEXT_CONDITIONAL:full"),
        },
    )
    shuffle = _context_shuffle_control(
        events=events,
        candidate_rows=finite_rows,
        recovered=recovered,
        model=context_reload["model"],
        normalization=context_reload["normalization"],
    )
    _deadline(started, "Atlas report aggregation")
    total_minutes = (time.monotonic() - started) / 60.0

    _write_csv_new(args.output / "WYCKOFF_LANDSCAPE_ATLAS_EVENTS.csv", event_rows)
    _write_csv_new(args.output / "WYCKOFF_LANDSCAPE_ATLAS_CANDIDATES.csv", candidate_rows)
    cv_rows = [
        *orbit_cv["fold_rows"],
        *context_cv["fold_rows"],
        *evaluation["event_rows"],
        *evaluation["fold_rows"],
        *evaluation["stage_rows"],
        {
            "row_type": "AGGREGATE",
            **aggregate,
            "context_minus_orbit_ci_lower": comparison["ci_lower"],
            "context_minus_orbit_ci_upper": comparison["ci_upper"],
            "context_conditional_value": context_value["status"],
        },
    ]
    _write_csv_new(args.output / "ORBIT_ONLY_VS_CONTEXT_CV.csv", cv_rows)

    ruggedness_text = f"""# Landscape Ruggedness Analysis

- Parent N: {parent_n}
- Event N: {len(events)}
- Candidate N: {len(candidate_rows)}
- Rugged event threshold: log1p(force) IQR >= 0.50.
- Overall rugged-event rate: {_fmt(landscape['overall_rugged_rate'])}.
- EARLY/MID/LATE/TERMINAL rates: {_fmt(stage_rugged['EARLY'])} / {_fmt(stage_rugged['MID'])} / {_fmt(stage_rugged['LATE'])} / {_fmt(stage_rugged['TERMINAL'])}.
- Candidate futures were teacher-completed only after candidate features were fixed. Frozen CHGNet 0.3.0 single points were used with no relaxation, retry, or refill.
- `FUTURE_PARENT_INFO_USED_FOR_SELECTION = false`
- `WYCKOFF_LANDSCAPE_UBIQUITY = {verdict['wyckoff_landscape_ubiquity']}`
"""
    (args.output / "LANDSCAPE_RUGGEDNESS_ANALYSIS.md").write_text(
        ruggedness_text, encoding="utf-8", newline="\n"
    )
    context_text = f"""# Context Dependence Analysis

## Cross-context physical ranking

- Qualifying action-signature N: {cross_context['qualifying_signature_n']}.
- Same-action cross-context pair N: {cross_context['pair_n']}.
- Same-action cross-context Spearman median: {_fmt(cross_context['spearman_median'])}.

## Matched parent-disjoint models

- ORBIT_ONLY / CONTEXT parameter counts: {trainable_parameter_count(orbit_full['model'])} / {trainable_parameter_count(context_full['model'])}; ratio {ratio:.12f}.
- ORBIT_ONLY / CONTEXT NDCG@5: {_fmt(aggregate['orbit_only_ndcg5'])} / {_fmt(aggregate['context_ndcg5'])}.
- ORBIT_ONLY / CONTEXT top1 force medians: {_fmt(aggregate['orbit_only_top1_force'])} / {_fmt(aggregate['context_top1_force'])} eV/A.
- Contact top1 force median: {_fmt(aggregate['contact_top1_force'])} eV/A.
- Context-minus-orbit event-paired log1p-force CI95: [{_fmt(comparison['ci_lower'])}, {_fmt(comparison['ci_upper'])}].
- Directionally favorable folds: {context_value['directional_fold_n']}/4.
- `CONTEXT_CONDITIONAL_VALUE = {context_value['status']}`

## Context-shuffle control

- Shuffled event N: {shuffle['shuffled_event_n']}.
- Original-vs-shuffled prediction-rank correlation median: {_fmt(shuffle['prediction_rank_correlation_median'])}.
- Top1 retention rate: {_fmt(shuffle['top1_retention_rate'])}.
- New CHGNet evaluations for shuffle: 0.

## Stage dependence

{json.dumps(evaluation['stage_summary'], indent=2, sort_keys=True)}

- `ASSEMBLY_STAGE_EFFECT = {stage_effect}`
"""
    (args.output / "CONTEXT_DEPENDENCE_ANALYSIS.md").write_text(
        context_text, encoding="utf-8", newline="\n"
    )
    verdict_text = f"""# CRYSALIS Context-Conditional Wyckoff Landscape Verdict

CRYSALIS_CONTEXT_CONDITIONAL_WYCKOFF_ATLAS = COMPLETE

PARENT_N = {parent_n}

EVENT_N = {len(events)}

CANDIDATE_N = {len(candidate_rows)}

RUGGED_EVENT_RATE = {_fmt(landscape['overall_rugged_rate'])}

EARLY_RUGGED_RATE = {_fmt(stage_rugged['EARLY'])}

MID_RUGGED_RATE = {_fmt(stage_rugged['MID'])}

LATE_RUGGED_RATE = {_fmt(stage_rugged['LATE'])}

TERMINAL_RUGGED_RATE = {_fmt(stage_rugged['TERMINAL'])}

WYCKOFF_LANDSCAPE_UBIQUITY = {verdict['wyckoff_landscape_ubiquity']}

SAME_ACTION_CROSS_CONTEXT_PAIR_N = {cross_context['pair_n']}

SAME_ACTION_CROSS_CONTEXT_SPEARMAN_MEDIAN = {_fmt(cross_context['spearman_median'])}

ORBIT_ONLY_NDCG5 = {_fmt(aggregate['orbit_only_ndcg5'])}

CONTEXT_NDCG5 = {_fmt(aggregate['context_ndcg5'])}

ORBIT_ONLY_TOP1_FORCE = {_fmt(aggregate['orbit_only_top1_force'])}

CONTEXT_TOP1_FORCE = {_fmt(aggregate['context_top1_force'])}

CONTACT_TOP1_FORCE = {_fmt(aggregate['contact_top1_force'])}

CONTEXT_TOP1_VS_ORBIT_ONLY_CI95 = [{_fmt(comparison['ci_lower'])}, {_fmt(comparison['ci_upper'])}]

CONTEXT_CONDITIONAL_VALUE = {context_value['status']}

ASSEMBLY_STAGE_EFFECT = {stage_effect}

SECOND_MLIP_CHECK = NOT_RUN

CONDITIONAL_LANDSCAPE_SIGNAL = {verdict['conditional_landscape_signal']}

NC_CORE_CLAIM_CANDIDATE = {verdict['nc_core_claim_candidate']}

TRAINING_RUNS = 2

TOTAL_WALL_CLOCK_MINUTES = {total_minutes:.12f}

NEXT_ACTION = {verdict['next_action']}
"""
    (args.output / "CRYSALIS_CONTEXT_CONDITIONAL_LANDSCAPE_VERDICT.md").write_text(
        verdict_text, encoding="utf-8", newline="\n"
    )
    print(
        json.dumps(
            {
                "phase": "COMPLETE",
                "parent_n": parent_n,
                "event_n": len(events),
                "candidate_n": len(candidate_rows),
                "verdict": verdict,
                "total_wall_clock_minutes": total_minutes,
                "orbit_reload_error": orbit_reload["maximum_absolute_error"],
                "context_reload_error": context_reload["maximum_absolute_error"],
            },
            sort_keys=True,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
