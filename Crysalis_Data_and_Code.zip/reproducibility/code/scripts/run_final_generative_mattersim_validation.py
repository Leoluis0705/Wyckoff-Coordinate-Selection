from __future__ import annotations

import argparse
import csv
import json
import math
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Any

import numpy as np
from scipy.stats import spearmanr

from crysalis_g1.experiments.c0_symmetry_oracle import load_recovered_parents
from crysalis_g1.geometry_mdn.evaluation import _receipt_structure, _structure_metrics, _parent_structure
from crysalis_g1.symmetry.assembly import (
    AddOrbitAction,
    C0SymmetryProjector,
    SpaceGroupLegalActionCompiler,
    SymmetryAssemblyState,
)
from scripts.run_parent_restricted_orbit_rollout import _composition


STREAM = 20260903
BOOTSTRAP_N = 10_000
MAX_MINUTES = 30.0
ARMS = ("ORBIT_ONLY", "CONTEXT")
KS = (8, 24)


def _wsl(path: Path) -> str:
    resolved = path.resolve()
    drive = resolved.drive[0].lower()
    return f"/mnt/{drive}/{resolved.as_posix()[3:]}"


def _load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def _rebuild(row: dict[str, Any], parent: Any) -> tuple[Any, dict[str, Any]]:
    state = SymmetryAssemblyState.empty(
        target_space_group=parent.target_space_group,
        composition=_composition(parent),
        lattice=parent.lattice,
    )
    compiler = SpaceGroupLegalActionCompiler(max_sites=20)
    projector = C0SymmetryProjector(minimum_distance=0.5)
    receipt = None
    for step in row["steps"]:
        selected = step.get("selected_action")
        if selected is None:
            raise RuntimeError("legal trajectory contains an empty selected action")
        if step.get("projector_status") != "ACCEPTED":
            raise RuntimeError("legal trajectory contains a rejected step")
        u = tuple(float(value) for value in step["selected_u"])
        action = AddOrbitAction(
            str(selected["wyckoff_letter"]),
            int(selected["species"]),
            u,
            f"replay:{row['record_id']}:{step['step_index']}",
        )
        proposal = compiler.apply_add(state, action)
        receipt = projector.project(proposal)
        if not receipt.accepted:
            raise RuntimeError(f"replayed projector rejected: {receipt.reason_codes}")
        state = proposal
    if receipt is None or not compiler.can_terminate(state, receipt):
        raise RuntimeError("replayed state is not a legal terminal")
    structure = _receipt_structure(receipt)
    metrics = _structure_metrics(_parent_structure(parent), structure)
    checks = {
        "composition_valid": bool(receipt.composition_valid),
        "target_sg_valid": int(metrics["detected_space_group"]) == int(parent.target_space_group),
        "detected_sg_match": int(metrics["detected_space_group"]) == int(row["detected_space_group"]),
        "site_count": len(structure),
        "step_count": len(row["steps"]),
    }
    if not all(checks[key] for key in ("composition_valid", "target_sg_valid", "detected_sg_match")):
        raise RuntimeError(f"identity check failed: {checks}")
    return structure, checks


def _matter_payload(identifier: str, structure: Any) -> dict[str, Any]:
    return {
        "candidate_id": identifier,
        "lattice": np.asarray(structure.lattice.matrix, dtype=float).tolist(),
        "atomic_numbers": [int(site.specie.Z) for site in structure],
        "fractional_coordinates": np.asarray(structure.frac_coords, dtype=float).tolist(),
    }


def _run_mattersim(
    structures: list[dict[str, Any]], helper: Path, checkout: Path, weight: Path,
    minutes: float,
) -> tuple[dict[str, Any], float]:
    with tempfile.TemporaryDirectory(prefix="crysalis_final_mattersim_") as temporary:
        folder = Path(temporary)
        input_path = folder / "input.json"
        output_path = folder / "output.json"
        input_path.write_text(json.dumps({"structures": structures}, allow_nan=False), encoding="utf-8")
        command = [
            "wsl.exe", "-d", "Ubuntu", "--exec", "/mnt/d/CGCNN/mattergen/.venv/bin/python",
            _wsl(helper), "--input", _wsl(input_path), "--output", _wsl(output_path),
            "--checkout", _wsl(checkout), "--weight", _wsl(weight),
            "--max-minutes", f"{minutes:.6f}",
        ]
        started = time.monotonic()
        completed = subprocess.run(command, check=False, text=True)
        elapsed = (time.monotonic() - started) / 60.0
        if completed.returncode != 0 or not output_path.is_file():
            raise RuntimeError(f"MatterSim process failed: {completed.returncode}")
        return json.loads(output_path.read_text(encoding="utf-8")), elapsed


def _bootstrap(values: np.ndarray, label: str) -> tuple[float, float]:
    seed = int.from_bytes(label.encode("utf-8"), "little", signed=False) % (2**63 - 1)
    rng = np.random.default_rng(seed)
    means = np.empty(BOOTSTRAP_N, dtype=float)
    for start in range(0, BOOTSTRAP_N, 1000):
        size = min(1000, BOOTSTRAP_N - start)
        idx = rng.integers(0, len(values), size=(size, len(values)))
        means[start : start + size] = values[idx].mean(axis=1)
    low, high = np.quantile(means, (0.025, 0.975))
    return float(low), float(high)


def _distribution(rows: list[dict[str, Any]]) -> dict[str, float]:
    force = np.asarray([row["mattersim_max_force"] for row in rows if row["finite"]], dtype=float)
    return {
        "n": int(len(force)), "median": float(np.median(force)),
        "p75": float(np.quantile(force, 0.75)), "p90": float(np.quantile(force, 0.90)),
        "p95": float(np.quantile(force, 0.95)),
        "gt5": float(np.mean(force > 5.0)), "gt10": float(np.mean(force > 10.0)),
        "gt20": float(np.mean(force > 20.0)),
    }


def _paired(result_rows: list[dict[str, Any]], k: int) -> list[dict[str, Any]]:
    maps = {
        arm: {row["parent_id"]: row for row in result_rows if row["K"] == k and row["arm"] == arm and row["finite"]}
        for arm in ARMS
    }
    ids = sorted(set(maps["ORBIT_ONLY"]) & set(maps["CONTEXT"]))
    paired = []
    for parent_id in ids:
        orbit = maps["ORBIT_ONLY"][parent_id]
        context = maps["CONTEXT"][parent_id]
        delta = math.log1p(context["mattersim_max_force"]) - math.log1p(orbit["mattersim_max_force"])
        paired.append({
            "parent_id": parent_id, "stream": STREAM, "K": k,
            "orbit_terminal_structure_id": orbit["terminal_structure_id"],
            "context_terminal_structure_id": context["terminal_structure_id"],
            "orbit_mattersim_force": orbit["mattersim_max_force"],
            "context_mattersim_force": context["mattersim_max_force"],
            "delta_log1p": delta,
            "orbit_chgnet_force": orbit["chgnet_max_force"],
            "context_chgnet_force": context["chgnet_max_force"],
            "context_win": context["mattersim_max_force"] < orbit["mattersim_max_force"],
            "quartile": None,
        })
    return paired


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _fmt(value: float) -> str:
    return f"{value:.12f}"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--trajectories", type=Path, required=True)
    parser.add_argument("--recovered-parents", type=Path, required=True)
    parser.add_argument("--mattersim-checkout", type=Path, required=True)
    parser.add_argument("--mattersim-weight", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    started = time.monotonic()
    if args.output.exists():
        raise FileExistsError(args.output)

    all_rows = _load_jsonl(args.trajectories)
    selected = [row for row in all_rows if row["arm"] in ARMS and int(row["K"]) in KS]
    if len(selected) != 512 * 4 or len({row["record_id"] for row in selected}) != len(selected):
        raise RuntimeError("formal trajectory identity cardinality mismatch")
    if len({row["parent_id"] for row in selected}) != 512:
        raise RuntimeError("parent cardinality mismatch")
    parents = load_recovered_parents(args.recovered_parents)

    structures: dict[str, dict[str, Any]] = {}
    identity_failures: list[str] = []
    for row in selected:
        if not row["formula_sg_legal_terminal"]:
            continue
        try:
            structure, _ = _rebuild(row, parents[row["parent_id"]])
            structures[row["record_id"]] = _matter_payload(row["record_id"], structure)
        except Exception as error:
            identity_failures.append(f"{row['record_id']}:{type(error).__name__}:{error}")
    audit_pass = not identity_failures and len(structures) == sum(bool(row["formula_sg_legal_terminal"]) for row in selected)
    if not audit_pass:
        raise RuntimeError("STRUCTURE_IDENTITY_AUDIT=FAIL\n" + "\n".join(identity_failures[:20]))

    k24_maps = {
        arm: {row["parent_id"]: row for row in selected if row["arm"] == arm and row["K"] == 24 and row["formula_sg_legal_terminal"]}
        for arm in ARMS
    }
    common = sorted(set(k24_maps["ORBIT_ONLY"]) & set(k24_maps["CONTEXT"]))
    if len(common) < 32:
        raise RuntimeError("fewer than 32 K24 legal parent pairs")
    positions = [min(len(common) - 1, int((index + 0.5) * len(common) / 32)) for index in range(32)]
    preflight_ids = []
    for position in positions:
        parent_id = common[position]
        preflight_ids.extend([k24_maps[arm][parent_id]["record_id"] for arm in ARMS])
    helper = Path(__file__).with_name("run_mattersim_single_point.py")
    preflight, preflight_elapsed = _run_mattersim(
        [structures[key] for key in preflight_ids], helper, args.mattersim_checkout,
        args.mattersim_weight, min(8.0, MAX_MINUTES),
    )
    preflight_by_id = {row["candidate_id"]: row for row in preflight["results"]}
    remaining_ids = sorted(set(structures) - set(preflight_ids))
    elapsed_so_far = (time.monotonic() - started) / 60.0
    model_load = float(preflight.get("model_load_minutes", preflight_elapsed))
    evaluation_minutes = float(preflight.get("evaluation_minutes", 0.0))
    per_structure = evaluation_minutes / len(preflight_ids)
    projected = elapsed_so_far + model_load + per_structure * len(remaining_ids) + 1.0
    print(json.dumps({
        "preflight_pair_n": 32, "preflight_structure_n": len(preflight_ids),
        "preflight_elapsed_minutes": preflight_elapsed,
        "projected_total_minutes": projected, "formal_structure_n": len(structures),
    }), flush=True)
    if projected > MAX_MINUTES:
        raise TimeoutError(f"PROJECTED_TOTAL_MINUTES={projected:.6f}")
    remaining_budget = MAX_MINUTES - (time.monotonic() - started) / 60.0 - 1.0
    formal, _ = _run_mattersim(
        [structures[key] for key in remaining_ids], helper, args.mattersim_checkout,
        args.mattersim_weight, remaining_budget,
    )
    matter_by_id = dict(preflight_by_id)
    matter_by_id.update({row["candidate_id"]: row for row in formal["results"]})

    result_rows = []
    for row in selected:
        found = matter_by_id.get(row["record_id"])
        legal = bool(row["formula_sg_legal_terminal"])
        finite = bool(legal and found is not None and found["status"] == "EVALUATED")
        result_rows.append({
            "schema_version": "crysalis-final-generative-mattersim.1.0.0",
            "parent_id": row["parent_id"], "stream": int(row["stream"]),
            "arm": row["arm"], "K": int(row["K"]),
            "terminal_structure_id": row["record_id"],
            "formula_sg_legal_terminal": legal,
            "structure_identity_verified": legal,
            "matter_sim_model": "MatterSim-v1.0.0-1M",
            "finite": finite,
            "matter_sim_status": found["status"] if found is not None else "NOT_LEGAL_TERMINAL",
            "mattersim_max_force": found["max_force"] if finite else None,
            "mattersim_mean_force": found["mean_force"] if finite else None,
            "mattersim_energy": found["energy"] if finite else None,
            "chgnet_max_force": row["initial_max_force_ev_per_angstrom"] if legal else None,
            "failure_reason": None if finite else (found["failure_reason"] if found is not None else "NOT_LEGAL_TERMINAL"),
        })
    args.output.mkdir(parents=True, exist_ok=False)
    _write_csv(args.output / "FINAL_GENERATIVE_MATTERSIM_RESULTS.csv", result_rows)

    paired8 = _paired(result_rows, 8)
    paired24 = _paired(result_rows, 24)
    deltas24 = np.asarray([row["delta_log1p"] for row in paired24], dtype=float)
    ci24 = _bootstrap(deltas24, "final-mattersim-k24")
    order = sorted(range(len(paired24)), key=lambda index: (paired24[index]["orbit_mattersim_force"], paired24[index]["parent_id"]))
    quartile_indices = np.array_split(np.asarray(order, dtype=int), 4)
    quartile_summary = []
    for number, indices in enumerate(quartile_indices, start=1):
        values = np.asarray([paired24[index]["delta_log1p"] for index in indices], dtype=float)
        for index in indices:
            paired24[int(index)]["quartile"] = f"Q{number}"
        ci = _bootstrap(values, f"final-mattersim-q{number}")
        quartile_summary.append({"quartile": f"Q{number}", "n": len(values), "mean_delta": float(values.mean()), "ci_lower": ci[0], "ci_upper": ci[1]})
    _write_csv(args.output / "FINAL_GENERATIVE_MATTERSIM_PAIRED.csv", paired8 + paired24)

    distributions = {
        (arm, k): _distribution([row for row in result_rows if row["arm"] == arm and row["K"] == k])
        for arm in ARMS for k in KS
    }
    orbit24, context24 = distributions[("ORBIT_ONLY", 24)], distributions[("CONTEXT", 24)]
    direction_ok = float(deltas24.mean()) < 0 and context24["p90"] < orbit24["p90"] and context24["gt10"] < orbit24["gt10"]
    if direction_ok and ci24[1] < 0:
        context_value = "SUPPORTED"
    elif direction_ok:
        context_value = "INCONCLUSIVE"
    else:
        context_value = "NOT_SUPPORTED"
    q_values = [row["mean_delta"] for row in quartile_summary]
    tail_supported = q_values[3] == min(q_values) and quartile_summary[3]["ci_upper"] < 0
    context8 = distributions[("CONTEXT", 8)]
    efficiency_count = sum((
        context8["median"] <= orbit24["median"],
        context8["p90"] <= orbit24["p90"],
        context8["gt10"] <= orbit24["gt10"],
    ))
    efficiency_supported = efficiency_count >= 2
    deltas8 = np.asarray([row["delta_log1p"] for row in paired8], dtype=float)
    ci8 = _bootstrap(deltas8, "final-mattersim-k8")

    finite_rows = [row for row in result_rows if row["finite"] and row["chgnet_max_force"] is not None]
    rho = float(spearmanr(
        [row["chgnet_max_force"] for row in finite_rows],
        [row["mattersim_max_force"] for row in finite_rows],
    ).statistic)
    same_direction = []
    for row in paired24:
        matter_sign = np.sign(row["context_mattersim_force"] - row["orbit_mattersim_force"])
        chgnet_sign = np.sign(row["context_chgnet_force"] - row["orbit_chgnet_force"])
        same_direction.append(matter_sign == chgnet_sign)
    agreement = float(np.mean(same_direction))

    if context_value == "SUPPORTED" and tail_supported:
        final_gate = "SUPPORTED"
    elif context_value == "INCONCLUSIVE":
        final_gate = "INCONCLUSIVE"
    else:
        final_gate = "NOT_SUPPORTED"
    efficiency_replicated = final_gate == "SUPPORTED" and efficiency_supported
    next_action = {
        "SUPPORTED": "BOUNDED_RELAXATION_CONSEQUENCE",
        "INCONCLUSIVE": "USER_DECISION_ON_EXPANDED_MATTERSIM",
        "NOT_SUPPORTED": "REASSESS_GENERATIVE_PHYSICS_CLAIM",
    }[final_gate]

    tail_lines = [
        "# Final generative MatterSim tail analysis", "", "Quartiles are defined independently from MatterSim Orbit-only K24 force in the finite paired cohort.", "",
        "| Quartile | N | Mean context-minus-orbit log1p force | 95% CI |", "|---|---:|---:|---:|",
    ]
    for row in quartile_summary:
        tail_lines.append(f"| {row['quartile']} | {row['n']} | {_fmt(row['mean_delta'])} | [{_fmt(row['ci_lower'])}, {_fmt(row['ci_upper'])}] |")
    tail_lines.extend(["", f"MATTERSIM_GENERATIVE_TAIL_MECHANISM = {'SUPPORTED' if tail_supported else 'NOT_SUPPORTED'}", ""])
    (args.output / "FINAL_GENERATIVE_MATTERSIM_TAIL_ANALYSIS.md").write_text("\n".join(tail_lines), encoding="utf-8")

    efficiency_lines = [
        "# Final generative MatterSim candidate efficiency", "",
        "| Metric | Context K8 | Orbit-only K24 | Context reaches or improves |", "|---|---:|---:|---:|",
        f"| Median force | {_fmt(context8['median'])} | {_fmt(orbit24['median'])} | {context8['median'] <= orbit24['median']} |",
        f"| P90 force | {_fmt(context8['p90'])} | {_fmt(orbit24['p90'])} | {context8['p90'] <= orbit24['p90']} |",
        f"| >10 eV/A rate | {_fmt(context8['gt10'])} | {_fmt(orbit24['gt10'])} | {context8['gt10'] <= orbit24['gt10']} |",
        "", f"MATTERSIM_CONTEXT_K8_EQUIVALENT_ORBIT_K24 = {'SUPPORTED' if efficiency_supported else 'NOT_SUPPORTED'}", "",
        f"Matched-budget K8 paired CI = [{_fmt(ci8[0])}, {_fmt(ci8[1])}]", "",
    ]
    (args.output / "FINAL_GENERATIVE_MATTERSIM_EFFICIENCY.md").write_text("\n".join(efficiency_lines), encoding="utf-8")

    total_minutes = (time.monotonic() - started) / 60.0
    verdict_lines = [
        "# CRYSALIS Final Generative MatterSim Verdict", "",
        "PARENT_N = 512", "STRUCTURE_IDENTITY_AUDIT = PASS",
        f"PROJECTED_TOTAL_MINUTES = {_fmt(projected)}", f"K24_PAIR_N = {len(paired24)}",
        f"K24_ORBIT_FORCE_MEDIAN = {_fmt(orbit24['median'])}", f"K24_CONTEXT_FORCE_MEDIAN = {_fmt(context24['median'])}",
        f"K24_ORBIT_FORCE_P90 = {_fmt(orbit24['p90'])}", f"K24_CONTEXT_FORCE_P90 = {_fmt(context24['p90'])}",
        f"K24_ORBIT_GT10_RATE = {_fmt(orbit24['gt10'])}", f"K24_CONTEXT_GT10_RATE = {_fmt(context24['gt10'])}",
        f"K24_CONTEXT_MINUS_ORBIT_LOG1P = {_fmt(float(deltas24.mean()))}",
        f"K24_CONTEXT_MINUS_ORBIT_CI95 = [{_fmt(ci24[0])}, {_fmt(ci24[1])}]",
        f"K24_CONTEXT_WIN_RATE = {_fmt(float(np.mean([row['context_win'] for row in paired24])))}",
        f"MATTERSIM_GENERATIVE_CONTEXT_VALUE = {context_value}",
    ]
    for row in quartile_summary:
        verdict_lines.append(f"{row['quartile']}_DELTA = {_fmt(row['mean_delta'])}")
    verdict_lines.extend([
        f"Q4_CI95 = [{_fmt(quartile_summary[3]['ci_lower'])}, {_fmt(quartile_summary[3]['ci_upper'])}]",
        f"MATTERSIM_GENERATIVE_TAIL_MECHANISM = {'SUPPORTED' if tail_supported else 'NOT_SUPPORTED'}",
        f"K8_CONTEXT_FORCE_MEDIAN = {_fmt(context8['median'])}", f"K8_CONTEXT_FORCE_P90 = {_fmt(context8['p90'])}",
        f"K8_CONTEXT_GT10_RATE = {_fmt(context8['gt10'])}",
        f"MATTERSIM_CONTEXT_K8_EQUIVALENT_ORBIT_K24 = {'SUPPORTED' if efficiency_supported else 'NOT_SUPPORTED'}",
        f"K8_CONTEXT_VS_ORBIT_CI95 = [{_fmt(ci8[0])}, {_fmt(ci8[1])}]",
        f"CHGNET_MATTERSIM_SPEARMAN = {_fmt(rho)}", f"CHGNET_MATTERSIM_GENERATIVE_AGREEMENT = {_fmt(agreement)}",
        f"FINAL_GENERATIVE_INDEPENDENT_PHYSICS = {final_gate}",
        f"FINAL_GENERATIVE_EFFICIENCY_REPLICATED = {str(efficiency_replicated).lower()}",
        "NEW_MODEL_TRAINING_RUNS = 0", "RELAXATION_RUNS = 0", "DFT_RUNS = 0",
        f"TOTAL_WALL_CLOCK_MINUTES = {_fmt(total_minutes)}", f"NEXT_ACTION = {next_action}", "",
    ])
    (args.output / "CRYSALIS_FINAL_GENERATIVE_MATTERSIM_VERDICT.md").write_text("\n".join(verdict_lines), encoding="utf-8")
    print("\n".join(verdict_lines), flush=True)


if __name__ == "__main__":
    main()
