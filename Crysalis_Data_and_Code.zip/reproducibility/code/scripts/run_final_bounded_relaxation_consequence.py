from __future__ import annotations

import argparse
import csv
import json
import math
import subprocess
import tempfile
import time
from collections import defaultdict
from pathlib import Path
from typing import Any

import numpy as np

from crysalis_g1.experiments.c0_symmetry_oracle import load_recovered_parents
from scripts.run_final_generative_mattersim_validation import _rebuild, _wsl


STREAM = 20260903
TARGET_PAIR_N = 96
BOOTSTRAP_N = 10_000
MAX_MINUTES = 30.0


def _load_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def _load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def _crystal_system(space_group: int) -> str:
    bounds = ((2, "triclinic"), (15, "monoclinic"), (74, "orthorhombic"),
              (142, "tetragonal"), (167, "trigonal"), (194, "hexagonal"), (230, "cubic"))
    for high, name in bounds:
        if space_group <= high:
            return name
    raise ValueError(space_group)


def _stratified_select(parent_ids: list[str], parents: dict[str, Any], n: int) -> list[dict[str, Any]]:
    groups: dict[tuple[str, int, int], list[str]] = defaultdict(list)
    for parent_id in sorted(parent_ids):
        parent = parents[parent_id]
        key = (_crystal_system(int(parent.target_space_group)), len(_composition_counts(parent)), len(parent.orbits))
        groups[key].append(parent_id)
    allocations: dict[tuple[str, int, int], int] = {}
    remainders = []
    for key, ids in groups.items():
        exact = len(ids) * n / len(parent_ids)
        allocations[key] = int(math.floor(exact))
        remainders.append((exact - allocations[key], key))
    for _, key in sorted(remainders, key=lambda item: (-item[0], item[1]))[: n - sum(allocations.values())]:
        allocations[key] += 1
    selected = []
    for key in sorted(groups):
        ids = groups[key]
        count = allocations[key]
        if count == 0:
            continue
        positions = [min(len(ids) - 1, int((index + 0.5) * len(ids) / count)) for index in range(count)]
        for parent_id in (ids[position] for position in positions):
            selected.append({
                "parent_id": parent_id, "crystal_system": key[0],
                "element_count": key[1], "orbit_count": key[2],
            })
    if len(selected) != n or len({row["parent_id"] for row in selected}) != n:
        raise RuntimeError("stratified cohort cardinality mismatch")
    return selected


def _composition_counts(parent: Any) -> dict[int, int]:
    counts: dict[int, int] = {}
    for orbit in parent.orbits:
        counts[int(orbit.species)] = counts.get(int(orbit.species), 0) + int(orbit.multiplicity)
    return counts


def _structure_payload(row: dict[str, Any], parent: Any, label: str) -> dict[str, Any]:
    structure, _ = _rebuild(row, parent)
    return {
        "structure_id": label,
        "lattice": np.asarray(structure.lattice.matrix, dtype=float).tolist(),
        "atomic_numbers": [int(site.specie.Z) for site in structure],
        "fractional_coordinates": np.asarray(structure.frac_coords, dtype=float).tolist(),
        "target_space_group": int(parent.target_space_group),
    }


def _run_helper(structures: list[dict[str, Any]], helper: Path, checkout: Path, weight: Path, minutes: float) -> tuple[dict[str, Any], float]:
    with tempfile.TemporaryDirectory(prefix="crysalis_relaxation_") as temporary:
        folder = Path(temporary)
        input_path, output_path = folder / "input.json", folder / "output.json"
        input_path.write_text(json.dumps({"structures": structures}, allow_nan=False), encoding="utf-8")
        command = [
            "wsl.exe", "-d", "Ubuntu", "--exec", "/mnt/d/CGCNN/mattergen/.venv/bin/python",
            _wsl(helper), "--input", _wsl(input_path), "--output", _wsl(output_path),
            "--checkout", _wsl(checkout), "--weight", _wsl(weight), "--max-minutes", f"{minutes:.6f}",
        ]
        started = time.monotonic()
        completed = subprocess.run(command, check=False, text=True)
        elapsed = (time.monotonic() - started) / 60.0
        if completed.returncode != 0 or not output_path.is_file():
            raise RuntimeError(f"MatterSim FIRE process failed: {completed.returncode}")
        return json.loads(output_path.read_text(encoding="utf-8")), elapsed


def _bootstrap(values: np.ndarray, label: str) -> tuple[float, float]:
    seed = int.from_bytes(label.encode("utf-8"), "little") % (2**63 - 1)
    rng = np.random.default_rng(seed)
    means = np.empty(BOOTSTRAP_N)
    for start in range(0, BOOTSTRAP_N, 1000):
        size = min(1000, BOOTSTRAP_N - start)
        index = rng.integers(0, len(values), size=(size, len(values)))
        means[start:start + size] = values[index].mean(axis=1)
    return tuple(float(value) for value in np.quantile(means, (0.025, 0.975)))


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _paired(rows: list[dict[str, Any]], left: str, right: str) -> list[dict[str, Any]]:
    maps = {arm: {row["parent_id"]: row for row in rows if row["arm"] == arm} for arm in (left, right)}
    out = []
    for parent_id in sorted(set(maps[left]) & set(maps[right])):
        lrow, rrow = maps[left][parent_id], maps[right][parent_id]
        item = {
            "parent_id": parent_id, "left_arm": left, "right_arm": right,
            "left_burden": lrow["steps_to_0p10"], "right_burden": rrow["steps_to_0p10"],
            "burden_delta": lrow["steps_to_0p10"] - rrow["steps_to_0p10"],
            "left_converged_0p10": lrow["converged_0p10"], "right_converged_0p10": rrow["converged_0p10"],
            "convergence_delta": int(lrow["converged_0p10"]) - int(rrow["converged_0p10"]),
            "left_large_reconstruction": lrow["large_reconstruction"], "right_large_reconstruction": rrow["large_reconstruction"],
            "large_reconstruction_delta": None if lrow["large_reconstruction"] is None or rrow["large_reconstruction"] is None else int(lrow["large_reconstruction"]) - int(rrow["large_reconstruction"]),
            "left_rms_displacement": lrow["rms_atomic_displacement"], "right_rms_displacement": rrow["rms_atomic_displacement"],
            "log1p_rms_delta": None if lrow["rms_atomic_displacement"] is None or rrow["rms_atomic_displacement"] is None else math.log1p(lrow["rms_atomic_displacement"]) - math.log1p(rrow["rms_atomic_displacement"]),
        }
        out.append(item)
    return out


def _fmt(value: float) -> str:
    return f"{value:.12f}"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--trajectories", type=Path, required=True)
    parser.add_argument("--mattersim-results", type=Path, required=True)
    parser.add_argument("--recovered-parents", type=Path, required=True)
    parser.add_argument("--mattersim-checkout", type=Path, required=True)
    parser.add_argument("--mattersim-weight", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    started = time.monotonic()
    if args.output.exists():
        raise FileExistsError(args.output)
    parents = load_recovered_parents(args.recovered_parents)
    matter_rows = _load_csv(args.mattersim_results)
    maps = {
        arm: {row["parent_id"]: row for row in matter_rows if row["arm"] == arm and row["K"] == "24" and row["formula_sg_legal_terminal"] == "True" and row["finite"] == "True"}
        for arm in ("ORBIT_ONLY", "CONTEXT")
    }
    eligible = sorted(set(maps["ORBIT_ONLY"]) & set(maps["CONTEXT"]))
    if len(eligible) < TARGET_PAIR_N:
        raise RuntimeError("primary eligible cohort has fewer than 96 parents")
    cohort = _stratified_select(eligible, parents, TARGET_PAIR_N)
    cohort_ids = {row["parent_id"] for row in cohort}
    trajectory_rows = _load_jsonl(args.trajectories)
    trajectory_map = {(row["parent_id"], row["arm"], int(row["K"])): row for row in trajectory_rows}

    planned: dict[str, dict[str, Any]] = {}
    metadata: dict[str, dict[str, Any]] = {}
    for cohort_row in cohort:
        parent_id = cohort_row["parent_id"]
        for arm in ("ORBIT_ONLY", "CONTEXT"):
            source = trajectory_map[(parent_id, arm, 24)]
            label = f"{parent_id}:{arm}:K24"
            planned[label] = _structure_payload(source, parents[parent_id], label)
            metadata[label] = {**cohort_row, "arm": arm, "K": 24, "source_record_id": source["record_id"], "initial_mattersim_force": float(maps[arm][parent_id]["mattersim_max_force"]), "analysis_role": "PRIMARY"}

    direct_labels, efficiency_labels = [], []
    for cohort_row in cohort:
        parent_id = cohort_row["parent_id"]
        direct = trajectory_map.get((parent_id, "DIRECT_MDN", 1))
        if direct is not None and direct["formula_sg_legal_terminal"]:
            label = f"{parent_id}:DIRECT_MDN:K1"
            planned[label] = _structure_payload(direct, parents[parent_id], label)
            metadata[label] = {**cohort_row, "arm": "DIRECT_MDN", "K": 1, "source_record_id": direct["record_id"], "initial_mattersim_force": None, "analysis_role": "SECONDARY_DIRECT"}
            direct_labels.append(label)
        context8 = trajectory_map.get((parent_id, "CONTEXT", 8))
        if context8 is not None and context8["formula_sg_legal_terminal"]:
            label = f"{parent_id}:CONTEXT_K8:K8"
            planned[label] = _structure_payload(context8, parents[parent_id], label)
            metadata[label] = {**cohort_row, "arm": "CONTEXT_K8", "K": 8, "source_record_id": context8["record_id"], "initial_mattersim_force": None, "analysis_role": "SECONDARY_EFFICIENCY"}
            efficiency_labels.append(label)

    cohort_rows = []
    for index, row in enumerate(cohort):
        parent_id = row["parent_id"]
        cohort_rows.append({
            "selection_order": index + 1, **row, "stream": STREAM,
            "orbit_k24_structure_id": f"{parent_id}:ORBIT_ONLY:K24",
            "context_k24_structure_id": f"{parent_id}:CONTEXT:K24",
            "direct_mdn_available": f"{parent_id}:DIRECT_MDN:K1" in planned,
            "context_k8_available": f"{parent_id}:CONTEXT_K8:K8" in planned,
        })

    helper = Path(__file__).with_name("run_mattersim_fire_relaxation.py")
    preflight_parent_ids = [row["parent_id"] for row in cohort[:8]]
    preflight_labels = [f"{parent_id}:{arm}:K24" for parent_id in preflight_parent_ids for arm in ("ORBIT_ONLY", "CONTEXT")]
    preflight, preflight_elapsed = _run_helper([planned[label] for label in preflight_labels], helper, args.mattersim_checkout, args.mattersim_weight, 10.0)
    results_by_id = {row["structure_id"]: row for row in preflight["results"]}
    primary_labels = [f"{row['parent_id']}:{arm}:K24" for row in cohort for arm in ("ORBIT_ONLY", "CONTEXT")]
    remaining_primary = [label for label in primary_labels if label not in results_by_id]
    elapsed = (time.monotonic() - started) / 60.0
    eval_rate = float(preflight["evaluation_minutes"]) / len(preflight_labels)
    model_load = float(preflight["model_load_minutes"])
    projected_primary = elapsed + model_load + eval_rate * len(remaining_primary) + 1.0
    print(json.dumps({"preflight_pair_n": 8, "preflight_relaxation_n": 16, "preflight_elapsed_minutes": preflight_elapsed, "projected_total_minutes": projected_primary}), flush=True)
    if projected_primary > MAX_MINUTES:
        raise TimeoutError(f"PROJECTED_TOTAL_MINUTES={projected_primary:.6f}")

    # Direct-MDN is the registered secondary reference. K8 is added only if the same speed estimate stays within 30 minutes.
    formal_labels = list(remaining_primary)
    direct_projected = elapsed + model_load + eval_rate * (len(formal_labels) + len(direct_labels)) + 1.0
    if len(direct_labels) >= 48 and direct_projected <= MAX_MINUTES:
        formal_labels.extend(direct_labels)
    else:
        direct_labels = []
    efficiency_projected = elapsed + model_load + eval_rate * (len(formal_labels) + len(efficiency_labels)) + 1.0
    if efficiency_projected <= MAX_MINUTES:
        formal_labels.extend(efficiency_labels)
    else:
        efficiency_labels = []
    budget = MAX_MINUTES - (time.monotonic() - started) / 60.0 - 0.75
    formal, _ = _run_helper([planned[label] for label in formal_labels], helper, args.mattersim_checkout, args.mattersim_weight, budget)
    results_by_id.update({row["structure_id"]: row for row in formal["results"]})

    result_rows = []
    trajectory_output = []
    for label in primary_labels + direct_labels + efficiency_labels:
        raw = results_by_id[label]
        meta = metadata[label]
        result_rows.append({key: value for key, value in {**meta, **raw}.items() if key not in {"trajectory", "final_fractional_coordinates"}})
        trajectory_output.append({**meta, **raw})

    args.output.mkdir(parents=True, exist_ok=False)
    _write_csv(args.output / "FINAL_RELAXATION_COHORT.csv", cohort_rows)
    _write_csv(args.output / "FINAL_RELAXATION_RESULTS.csv", result_rows)
    with (args.output / "RELAXATION_TRAJECTORIES.jsonl").open("w", encoding="utf-8") as handle:
        for row in trajectory_output:
            handle.write(json.dumps(row, allow_nan=False, sort_keys=True) + "\n")

    primary_rows = [row for row in result_rows if row["analysis_role"] == "PRIMARY"]
    pairs = _paired(primary_rows, "CONTEXT", "ORBIT_ONLY")
    if len(pairs) != TARGET_PAIR_N:
        raise RuntimeError("primary paired result cardinality mismatch")
    burden_delta = np.asarray([row["burden_delta"] for row in pairs], dtype=float)
    burden_ci = _bootstrap(burden_delta, "relaxation-burden")
    convergence_delta = np.asarray([row["convergence_delta"] for row in pairs], dtype=float)
    convergence_ci = _bootstrap(convergence_delta, "relaxation-convergence")
    rms_pairs = [row for row in pairs if row["log1p_rms_delta"] is not None]
    rms_delta = np.asarray([row["log1p_rms_delta"] for row in rms_pairs], dtype=float)
    rms_ci = _bootstrap(rms_delta, "relaxation-rms")
    large_pairs = [row for row in pairs if row["large_reconstruction_delta"] is not None]
    large_delta = np.asarray([row["large_reconstruction_delta"] for row in large_pairs], dtype=float)
    large_ci = _bootstrap(large_delta, "relaxation-large")

    primary_maps = {arm: {row["parent_id"]: row for row in primary_rows if row["arm"] == arm} for arm in ("CONTEXT", "ORBIT_ONLY")}
    order = sorted(cohort_ids, key=lambda parent_id: (float(maps["ORBIT_ONLY"][parent_id]["mattersim_max_force"]), parent_id))
    quartiles = np.array_split(np.asarray(order, dtype=object), 4)
    tail_rows = []
    for number, ids in enumerate(quartiles, start=1):
        context = [primary_maps["CONTEXT"][str(parent_id)] for parent_id in ids]
        orbit = [primary_maps["ORBIT_ONLY"][str(parent_id)] for parent_id in ids]
        tail_rows.append({
            "quartile": f"Q{number}", "n": len(ids),
            "context_burden": float(np.mean([row["steps_to_0p10"] for row in context])),
            "orbit_burden": float(np.mean([row["steps_to_0p10"] for row in orbit])),
            "context_convergence": float(np.mean([row["converged_0p10"] for row in context])),
            "orbit_convergence": float(np.mean([row["converged_0p10"] for row in orbit])),
            "context_rms": float(np.mean([row["rms_atomic_displacement"] for row in context if row["rms_atomic_displacement"] is not None])),
            "orbit_rms": float(np.mean([row["rms_atomic_displacement"] for row in orbit if row["rms_atomic_displacement"] is not None])),
            "context_large": float(np.mean([row["large_reconstruction"] for row in context if row["large_reconstruction"] is not None])),
            "orbit_large": float(np.mean([row["large_reconstruction"] for row in orbit if row["large_reconstruction"] is not None])),
        })
    q4 = tail_rows[3]
    tail_supported = q4["context_burden"] < q4["orbit_burden"] and (
        q4["context_large"] < q4["orbit_large"] or q4["context_rms"] < q4["orbit_rms"] or q4["context_convergence"] > q4["orbit_convergence"]
    )
    noninferior = convergence_ci[0] > -0.05
    overall_improvement = burden_ci[1] < 0 or large_ci[1] < 0
    if overall_improvement and noninferior and tail_supported:
        consequence = "SUPPORTED"
    elif tail_supported:
        consequence = "TAIL_ONLY"
    else:
        consequence = "NOT_SUPPORTED"

    pair_output = []
    quartile_by_parent = {str(parent_id): f"Q{number}" for number, ids in enumerate(quartiles, start=1) for parent_id in ids}
    for row in pairs:
        pair_output.append({**row, "comparison": "CONTEXT_K24_VS_ORBIT_K24", "orbit_initial_mattersim_quartile": quartile_by_parent[row["parent_id"]]})

    efficiency_status = "NOT_RUN"
    if efficiency_labels:
        efficiency_rows = [row for row in result_rows if row["arm"] in {"CONTEXT_K8", "ORBIT_ONLY"}]
        efficiency_pairs = _paired(efficiency_rows, "CONTEXT_K8", "ORBIT_ONLY")
        eff_burden = np.asarray([row["burden_delta"] for row in efficiency_pairs], dtype=float)
        eff_conv = np.asarray([row["convergence_delta"] for row in efficiency_pairs], dtype=float)
        eff_burden_ci = _bootstrap(eff_burden, "relaxation-efficiency-burden")
        eff_conv_ci = _bootstrap(eff_conv, "relaxation-efficiency-convergence")
        eff_large = np.asarray([row["large_reconstruction_delta"] for row in efficiency_pairs if row["large_reconstruction_delta"] is not None], dtype=float)
        efficiency_status = "SUPPORTED" if (eff_burden_ci[1] < 0 or float(eff_large.mean()) < 0) and eff_conv_ci[0] > -0.05 else "NOT_SUPPORTED"
        pair_output.extend({**row, "comparison": "CONTEXT_K8_VS_ORBIT_K24", "orbit_initial_mattersim_quartile": None} for row in efficiency_pairs)

    direct_n = 0
    if direct_labels:
        direct_rows = [row for row in result_rows if row["arm"] in {"CONTEXT", "DIRECT_MDN"}]
        direct_pairs = _paired(direct_rows, "CONTEXT", "DIRECT_MDN")
        direct_n = len(direct_pairs)
        pair_output.extend({**row, "comparison": "CONTEXT_K24_VS_DIRECT_MDN", "orbit_initial_mattersim_quartile": None} for row in direct_pairs)
    _write_csv(args.output / "FINAL_RELAXATION_PAIRED_ANALYSIS.csv", pair_output)

    by_arm = {arm: [row for row in primary_rows if row["arm"] == arm] for arm in ("CONTEXT", "ORBIT_ONLY")}
    def rate(arm: str, field: str) -> float:
        return float(np.mean([bool(row[field]) for row in by_arm[arm]]))
    def mean_valid(arm: str, field: str) -> float:
        return float(np.mean([row[field] for row in by_arm[arm] if row[field] is not None]))
    def median(arm: str, field: str) -> float:
        return float(np.median([row[field] for row in by_arm[arm]]))

    tail_md = ["# Final relaxation tail analysis", "", "Quartiles are defined from Orbit-only initial MatterSim K24 force after the 96-pair cohort was frozen.", "", "| Quartile | N | Context burden | Orbit burden | Context conv. | Orbit conv. | Context RMS | Orbit RMS | Context large | Orbit large |", "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for row in tail_rows:
        tail_md.append(f"| {row['quartile']} | {row['n']} | {_fmt(row['context_burden'])} | {_fmt(row['orbit_burden'])} | {_fmt(row['context_convergence'])} | {_fmt(row['orbit_convergence'])} | {_fmt(row['context_rms'])} | {_fmt(row['orbit_rms'])} | {_fmt(row['context_large'])} | {_fmt(row['orbit_large'])} |")
    tail_md.extend(["", f"RELAXATION_TAIL_CONSEQUENCE = {'SUPPORTED' if tail_supported else 'NOT_SUPPORTED'}", ""])
    (args.output / "FINAL_RELAXATION_TAIL_ANALYSIS.md").write_text("\n".join(tail_md), encoding="utf-8")

    total_minutes = (time.monotonic() - started) / 60.0
    verdict = [
        "# CRYSALIS Final Relaxation Verdict", "", f"PRIMARY_PAIR_N = {len(pairs)}",
        f"CONTEXT_CONVERGED_0P10_RATE = {_fmt(rate('CONTEXT', 'converged_0p10'))}", f"ORBIT_CONVERGED_0P10_RATE = {_fmt(rate('ORBIT_ONLY', 'converged_0p10'))}",
        f"CONTEXT_CONVERGED_0P05_RATE = {_fmt(rate('CONTEXT', 'converged_0p05'))}", f"ORBIT_CONVERGED_0P05_RATE = {_fmt(rate('ORBIT_ONLY', 'converged_0p05'))}",
        f"CONTEXT_RELAXATION_BURDEN_MEDIAN = {_fmt(median('CONTEXT', 'steps_to_0p10'))}", f"ORBIT_RELAXATION_BURDEN_MEDIAN = {_fmt(median('ORBIT_ONLY', 'steps_to_0p10'))}",
        f"CONTEXT_MINUS_ORBIT_BURDEN = {_fmt(float(burden_delta.mean()))}", f"CONTEXT_MINUS_ORBIT_BURDEN_CI95 = [{_fmt(burden_ci[0])}, {_fmt(burden_ci[1])}]",
        f"CONTEXT_FEWER_STEP_WIN_RATE = {_fmt(float(np.mean(burden_delta < 0)))}",
        f"CONVERGENCE_DELTA_PP = {_fmt(float(convergence_delta.mean() * 100))}", f"CONVERGENCE_NONINFERIOR_CI95 = [{_fmt(convergence_ci[0] * 100)}, {_fmt(convergence_ci[1] * 100)}]",
        f"CONTEXT_RMS_DISPLACEMENT = {_fmt(mean_valid('CONTEXT', 'rms_atomic_displacement'))}", f"ORBIT_RMS_DISPLACEMENT = {_fmt(mean_valid('ORBIT_ONLY', 'rms_atomic_displacement'))}",
        f"RMS_DISPLACEMENT_CI95 = [{_fmt(rms_ci[0])}, {_fmt(rms_ci[1])}]",
        f"CONTEXT_LARGE_RECONSTRUCTION_RATE = {_fmt(rate('CONTEXT', 'large_reconstruction'))}", f"ORBIT_LARGE_RECONSTRUCTION_RATE = {_fmt(rate('ORBIT_ONLY', 'large_reconstruction'))}",
        f"CONTEXT_TARGET_SG_RETENTION = {_fmt(rate('CONTEXT', 'target_sg_retained'))}", f"ORBIT_TARGET_SG_RETENTION = {_fmt(rate('ORBIT_ONLY', 'target_sg_retained'))}",
        f"Q4_CONTEXT_BURDEN = {_fmt(q4['context_burden'])}", f"Q4_ORBIT_BURDEN = {_fmt(q4['orbit_burden'])}",
        f"Q4_CONTEXT_RMS_DISPLACEMENT = {_fmt(q4['context_rms'])}", f"Q4_ORBIT_RMS_DISPLACEMENT = {_fmt(q4['orbit_rms'])}",
        f"Q4_CONTEXT_LARGE_RECONSTRUCTION = {_fmt(q4['context_large'])}", f"Q4_ORBIT_LARGE_RECONSTRUCTION = {_fmt(q4['orbit_large'])}",
        f"RELAXATION_TAIL_CONSEQUENCE = {'SUPPORTED' if tail_supported else 'NOT_SUPPORTED'}", f"CONTEXT_RELAXATION_CONSEQUENCE = {consequence}",
        f"RELAXATION_EFFICIENCY_K8_VS_K24 = {efficiency_status}", f"DIRECT_MDN_SECONDARY_N = {direct_n}",
        "NC_MAIN_SCIENTIFIC_EXPERIMENTS = FROZEN", "NEW_MODEL_TRAINING_RUNS = 0", "DFT_RUNS = 0",
        f"TOTAL_WALL_CLOCK_MINUTES = {_fmt(total_minutes)}", "NEXT_ACTION = FREEZE_RESULTS_AND_WRITE_NC_MANUSCRIPT", "",
    ]
    (args.output / "CRYSALIS_FINAL_RELAXATION_VERDICT.md").write_text("\n".join(verdict), encoding="utf-8")
    freeze = ["# NC Final Result Freeze", "", "NC_MAIN_SCIENTIFIC_EXPERIMENTS = FROZEN", "", "No new scientific experiment is authorized after this task unless a confirmed protocol or code error is found.", "", "Allowed next work: result freeze, statistics, figures, supplementary information, and manuscript writing.", ""]
    (args.output / "NC_FINAL_RESULT_FREEZE.md").write_text("\n".join(freeze), encoding="utf-8")
    print("\n".join(verdict), flush=True)


if __name__ == "__main__":
    main()
