from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import time
from collections import Counter, defaultdict
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

import numpy as np
import torch
from pymatgen.core import Lattice

from crysalis_g1.experiments.c0_symmetry_oracle import load_recovered_parents
from crysalis_g1.experiments.full_orbit_compatibility import (
    full_orbit_parent_free_features,
    shifted_halton_points,
)
from crysalis_g1.experiments.full_orbit_operator import REGISTERED_FEATURE_NAMES
from crysalis_g1.experiments.integrated_what_where import (
    ARM_A,
    ARM_B,
    ARM_C,
    ARM_D,
    ARMS,
    component_synergy,
    deterministic_integrated_parent_sample,
    failure_class,
    force_interaction_analysis,
    force_pair_analysis,
    geometry_method,
    integrated_verdict,
    stage_for_fraction,
    terminal_factorial_analysis,
    validate_frozen_policy_metadata,
)
from crysalis_g1.experiments.orbit_inverse_policy import OrbitInversePolicy
from crysalis_g1.experiments.orbit_multistream import geometry_event_key
from crysalis_g1.geometry_mdn.evaluation import (
    _parent_structure,
    _receipt_structure,
    _structure_metrics,
)
from crysalis_g1.geometry_mdn.model import WrappedMixtureDensityDecoder
from crysalis_g1.geometry_mdn.sampling import (
    registered_mdn_samples_with_components,
)
from crysalis_g1.symmetry.assembly import (
    AddOrbitAction,
    C0SymmetryProjector,
    SpaceGroupLegalActionCompiler,
    SymmetryAssemblyState,
)
from crysalis_g1.symmetry.wyckoff import (
    OrbitState,
    SpaceGroupConditionedWyckoffExpander,
    WyckoffExpansionError,
)
from scripts.run_compatibility_assembly_depth_generalization import (
    _load_frozen_mlp,
)
from scripts.run_full_orbit_compatibility_dataset_poc import _load_chgnet
from scripts.run_parent_restricted_orbit_rollout import (
    MAX_ORBITS,
    _action_key,
    _composition,
    _legal_key,
    _mdn_batch,
    _policy_batch,
)

SCHEMA_VERSION = "crysalis-integrated-what-where-poc.1.0.0"
MAX_WALL_CLOCK_MINUTES = 30.0
PARENT_N = 128
STREAM_SEEDS = (20260823, 20260824, 20260825)
SELECTION_SEED = 20260823
COMPATIBILITY_CANDIDATE_N = 24
MAX_SITES = 20
PROJECTOR_MINIMUM_DISTANCE = 0.5


def _check_deadline(started: float, phase: str) -> None:
    elapsed = (time.monotonic() - started) / 60.0
    if elapsed >= MAX_WALL_CLOCK_MINUTES:
        raise TimeoutError(
            f"{phase} exceeded {MAX_WALL_CLOCK_MINUTES:g} total wall-clock minutes"
        )


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def _signature(orbit: OrbitState) -> tuple[object, ...]:
    return (
        int(orbit.species),
        str(orbit.wyckoff_letter),
        int(orbit.multiplicity),
        int(len(orbit.free_parameters)),
    )


def _signature_payload(signature: Sequence[object]) -> dict[str, object]:
    return {
        "species": int(signature[0]),
        "wyckoff_letter": str(signature[1]),
        "multiplicity": int(signature[2]),
        "free_dof_count": int(signature[3]),
    }


def _uniform_index(count: int, stream_seed: int, parent_id: str, step: int) -> int:
    key = f"orbit_policy:uniform:{int(stream_seed)}:{parent_id}:{int(step)}"
    seed = int.from_bytes(hashlib.sha256(key.encode("utf-8")).digest()[:8], "little")
    return int(np.random.default_rng(seed).integers(0, int(count)))


def _candidate_orbits(
    parent: Any,
    state: SymmetryAssemblyState,
    parent_remaining: set[str],
    step: int,
    compiler: SpaceGroupLegalActionCompiler,
) -> tuple[OrbitState, ...]:
    parent_by_id = {orbit.orbit_instance_id: orbit for orbit in parent.orbits}
    candidates = []
    for index, action in enumerate(
        sorted(compiler.legal_add_actions(state), key=_legal_key)
    ):
        key = _legal_key(action)
        matching = sorted(
            orbit_id
            for orbit_id in parent_remaining
            if _action_key(parent_by_id[orbit_id]) == key
        )
        if matching:
            candidates.append(parent_by_id[matching[0]])
            continue
        parameters = (0.173, 0.287, 0.391)[: action.free_parameter_count]
        candidates.append(
            OrbitState.create(
                parent.target_space_group,
                action.wyckoff_letter,
                action.species,
                parameters,
                cell_transform=parent.lattice.cell_transform_values,
                orbit_instance_id=(
                    f"integrated-full-legal:{parent.material_id}:{step}:{index}"
                ),
            )
        )
    return tuple(candidates)


def _sample_direct_mdn(
    *,
    model: WrappedMixtureDensityDecoder,
    parent: Any,
    state: SymmetryAssemblyState,
    selected: OrbitState,
    rank_by_id: Mapping[str, int],
    device: torch.device,
    stream_seed: int,
    step: int,
) -> tuple[tuple[float, ...], dict[str, object]]:
    batch = _mdn_batch(parent, state, selected, dict(rank_by_id)).to(device)
    with torch.no_grad():
        output = model(batch)
    event_key = geometry_event_key(
        stream_seed, parent.material_id, step + 1, _signature(selected)
    )
    samples, components = registered_mdn_samples_with_components(
        output,
        batch.free_dof_mask,
        root_seed=stream_seed,
        event_keys=(event_key,),
        sample_count=1,
    )
    free_dof = len(selected.free_parameters)
    values = tuple(float(value) for value in samples[0, 0, :free_dof])
    return values, {
        "root_seed": int(stream_seed),
        "event_key": event_key,
        "mixture_component": int(components[0, 0]),
    }


def _compatibility_geometry(
    *,
    state: SymmetryAssemblyState,
    selected: OrbitState,
    expected_final_site_count: int,
    mlp: Any,
    normalization: Mapping[str, Any],
    expander: SpaceGroupConditionedWyckoffExpander,
) -> tuple[tuple[float, ...] | None, dict[str, object]]:
    partial = expander.expand_many(
        state.orbits,
        state.lattice.primitive_matrix,
        require_target_space_group=False,
        require_distinct_orbit_instances=False,
    )
    framework_z = np.asarray(partial.atomic_numbers, dtype=int)
    framework_fractional = np.asarray(partial.fractional_coordinates, dtype=float)
    site_progress = state.site_count / int(expected_final_site_count)
    candidate_rows: list[dict[str, object]] = []
    for candidate_index, legal_u in enumerate(
        shifted_halton_points(
            len(selected.free_parameters), count=COMPATIBILITY_CANDIDATE_N
        )
    ):
        row: dict[str, object] = {
            "candidate_index": candidate_index,
            "legal_u": tuple(float(value) for value in legal_u),
            "expansion_valid": False,
            "failure_reason": None,
        }
        try:
            orbit = OrbitState.create(
                state.target_space_group,
                selected.wyckoff_letter,
                selected.species,
                legal_u,
                cell_transform=state.lattice.cell_transform_values,
                orbit_instance_id=selected.orbit_instance_id,
            )
            expanded = expander.expand(
                orbit,
                state.lattice.primitive_matrix,
                require_target_space_group=False,
                require_distinct_orbit_instances=False,
            )
            if len(expanded.atomic_numbers) != selected.multiplicity:
                raise ValueError("compatibility candidate multiplicity mismatch")
            features = full_orbit_parent_free_features(
                lattice=Lattice(state.lattice.primitive_matrix),
                framework_atomic_numbers=framework_z,
                framework_fractional_coordinates=framework_fractional,
                candidate_atomic_number=selected.species,
                candidate_fractional_coordinates=np.asarray(
                    expanded.fractional_coordinates, dtype=float
                ),
                free_dof=len(selected.free_parameters),
                assembly_progress=site_progress,
            )
            row.update(features)
            row["expansion_valid"] = True
        except (ValueError, WyckoffExpansionError) as error:
            row["failure_reason"] = f"{type(error).__name__}:{error}"
        candidate_rows.append(row)
    valid = [row for row in candidate_rows if bool(row["expansion_valid"])]
    if not valid:
        return None, {
            "registered_candidate_n": COMPATIBILITY_CANDIDATE_N,
            "expansion_valid_candidate_n": 0,
            "selected_candidate_index": None,
            "selected_predicted_log1p_force": None,
            "selected_contact_score": None,
            "failure_reasons": [
                row["failure_reason"]
                for row in candidate_rows
                if row["failure_reason"] is not None
            ],
        }
    matrix = np.asarray(
        [[float(row[name]) for name in REGISTERED_FEATURE_NAMES] for row in valid],
        dtype=float,
    )
    with torch.no_grad():
        standardized = mlp(
            torch.as_tensor(
                (matrix - normalization["x_mean"]) / normalization["x_scale"],
                dtype=torch.float32,
            )
        ).numpy()
    predictions = standardized * float(normalization["y_scale"]) + float(
        normalization["y_mean"]
    )
    for row, prediction in zip(valid, predictions, strict=True):
        row["predicted_log1p_force"] = float(prediction)
    chosen = min(
        valid,
        key=lambda row: (
            float(row["predicted_log1p_force"]),
            int(row["candidate_index"]),
        ),
    )
    selected_features = {name: float(chosen[name]) for name in REGISTERED_FEATURE_NAMES}
    return tuple(float(value) for value in chosen["legal_u"]), {
        "registered_candidate_n": COMPATIBILITY_CANDIDATE_N,
        "expansion_valid_candidate_n": len(valid),
        "selected_candidate_index": int(chosen["candidate_index"]),
        "selected_predicted_log1p_force": float(chosen["predicted_log1p_force"]),
        "selected_contact_score": float(chosen["static_full_orbit_contact_score"]),
        "selected_features": selected_features,
        "failure_reasons": [
            row["failure_reason"]
            for row in candidate_rows
            if row["failure_reason"] is not None
        ],
    }


def _finite_structure(structure: Any | None) -> bool:
    if structure is None:
        return False
    return bool(
        np.isfinite(np.asarray(structure.lattice.matrix, dtype=float)).all()
        and np.isfinite(np.asarray(structure.frac_coords, dtype=float)).all()
    )


def _run_trajectory(
    *,
    parent: Any,
    arm: str,
    stream_seed: int,
    policy: OrbitInversePolicy,
    mdn: WrappedMixtureDensityDecoder,
    compatibility_mlp: Any,
    compatibility_normalization: Mapping[str, Any],
    compiler: SpaceGroupLegalActionCompiler,
    projector: C0SymmetryProjector,
    expander: SpaceGroupConditionedWyckoffExpander,
    device: torch.device,
    started: float,
) -> tuple[dict[str, object], Any | None]:
    _check_deadline(started, "free rollout")
    parent_id = str(parent.material_id)
    parent_by_id = {orbit.orbit_instance_id: orbit for orbit in parent.orbits}
    rank_by_id = {orbit_id: rank for rank, orbit_id in enumerate(sorted(parent_by_id))}
    parent_remaining = set(parent_by_id)
    state = SymmetryAssemblyState.empty(
        target_space_group=parent.target_space_group,
        composition=_composition(parent),
        lattice=parent.lattice,
    )
    final_orbit_count = len(parent.orbits)
    final_site_count = sum(int(orbit.multiplicity) for orbit in parent.orbits)
    compatibility_arm = arm in {ARM_C, ARM_D}
    inverse_arm = arm in {ARM_B, ARM_D}
    receipt = None
    failure = None
    strict_matches: list[bool] = []
    step_rows: list[dict[str, object]] = []
    usage = Counter()
    for step in range(MAX_ORBITS):
        _check_deadline(started, "free rollout")
        if not state.remaining_composition:
            break
        state_before = state
        candidates = _candidate_orbits(parent, state, parent_remaining, step, compiler)
        if not candidates:
            failure = "NO_LEGAL_ACTION"
            step_rows.append(
                {
                    "step_index": step + 1,
                    "active_orbit_count": len(state.orbits),
                    "assembly_fraction": len(state.orbits) / final_orbit_count,
                    "stage": stage_for_fraction(len(state.orbits), final_orbit_count),
                    "legal_candidate_count": 0,
                    "chosen_action_signature": None,
                    "geometry_method": None,
                    "registered_compatibility_candidate_n": 0,
                    "expansion_valid_compatibility_candidate_n": 0,
                    "projector_accepted": None,
                    "failure": failure,
                }
            )
            break
        policy_batch = _policy_batch(parent, state, candidates).to(device)
        with torch.no_grad():
            logits = policy(policy_batch)[0]
            probabilities = torch.softmax(logits, dim=-1).detach().cpu().numpy()
        selected_index = (
            int(torch.argmax(logits).item())
            if inverse_arm
            else _uniform_index(len(candidates), stream_seed, parent_id, step)
        )
        selected = candidates[selected_index]
        selected_signature = _signature(selected)
        strict_match = selected.orbit_instance_id in parent_remaining
        strict_matches.append(strict_match)
        rank_by_id.setdefault(selected.orbit_instance_id, min(step, MAX_ORBITS - 1))
        stage = stage_for_fraction(len(state.orbits), final_orbit_count)
        method = geometry_method(
            len(state.orbits),
            final_orbit_count,
            free_dof=len(selected.free_parameters),
            compatibility_arm=compatibility_arm,
        )
        usage[(stage, method)] += 1
        geometry_seed = None
        compatibility_audit: dict[str, object] = {
            "registered_candidate_n": 0,
            "expansion_valid_candidate_n": 0,
            "selected_candidate_index": None,
            "selected_predicted_log1p_force": None,
            "selected_contact_score": None,
        }
        sampled: tuple[float, ...] | None
        if method == "FIXED_GEOMETRY":
            sampled = tuple(float(value) for value in selected.free_parameters)
        elif method == "DIRECT_MDN":
            sampled, geometry_seed = _sample_direct_mdn(
                model=mdn,
                parent=parent,
                state=state,
                selected=selected,
                rank_by_id=rank_by_id,
                device=device,
                stream_seed=stream_seed,
                step=step,
            )
        elif method == "COMPATIBILITY_MLP":
            try:
                sampled, compatibility_audit = _compatibility_geometry(
                    state=state,
                    selected=selected,
                    expected_final_site_count=final_site_count,
                    mlp=compatibility_mlp,
                    normalization=compatibility_normalization,
                    expander=expander,
                )
            except (ValueError, WyckoffExpansionError) as error:
                sampled = None
                compatibility_audit = {
                    **compatibility_audit,
                    "failure_reasons": [f"{type(error).__name__}:{error}"],
                }
            if sampled is None:
                failure = "COMPATIBILITY_NO_VALID_CANDIDATE"
        else:
            raise RuntimeError(f"unknown geometry method: {method}")
        expansion_status = "NOT_RUN"
        if failure is None and sampled is not None:
            try:
                proposal = compiler.apply_add(
                    state,
                    AddOrbitAction(
                        selected.wyckoff_letter,
                        selected.species,
                        sampled,
                        selected.orbit_instance_id,
                    ),
                )
                expansion_status = "EXPANDED"
            except Exception as error:
                proposal = None
                failure = "EXPANSION_FAILURE"
                expansion_status = f"{type(error).__name__}:{error}"
        else:
            proposal = None
        if proposal is None:
            accepted = False
            reasons = [failure or "EXPANSION_FAILURE"]
            minimum_distance = None
        else:
            receipt = projector.project(proposal)
            accepted = bool(receipt.accepted)
            reasons = list(receipt.reason_codes)
            minimum_distance = receipt.minimum_distance_angstrom
            state = proposal
            if strict_match:
                parent_remaining.remove(selected.orbit_instance_id)
            if not accepted:
                failure = "PROJECTOR_REJECTED"
        step_rows.append(
            {
                "step_index": step + 1,
                "active_orbit_count": len(state_before.orbits),
                "assembly_fraction": len(state_before.orbits) / final_orbit_count,
                "stage": stage,
                "remaining_composition": [
                    list(value) for value in state_before.remaining_composition
                ],
                "legal_candidate_count": len(candidates),
                "candidate_action_signatures": [
                    _signature_payload(_signature(candidate))
                    for candidate in candidates
                ],
                "learned_candidate_probabilities": [
                    float(value) for value in probabilities
                ],
                "chosen_action_signature": _signature_payload(selected_signature),
                "chosen_hidden_orbit_instance_id": str(selected.orbit_instance_id),
                "chosen_action_probability": (
                    float(probabilities[selected_index])
                    if inverse_arm
                    else 1.0 / len(candidates)
                ),
                "strict_parent_orbit_id_match": strict_match,
                "geometry_method": method,
                "geometry_seed": geometry_seed,
                "sampled_free_parameters": (
                    None if sampled is None else [float(value) for value in sampled]
                ),
                "registered_compatibility_candidate_n": compatibility_audit[
                    "registered_candidate_n"
                ],
                "expansion_valid_compatibility_candidate_n": compatibility_audit[
                    "expansion_valid_candidate_n"
                ],
                "compatibility_selected_candidate_index": compatibility_audit[
                    "selected_candidate_index"
                ],
                "compatibility_predicted_log1p_force": compatibility_audit[
                    "selected_predicted_log1p_force"
                ],
                "compatibility_contact_score": compatibility_audit[
                    "selected_contact_score"
                ],
                "compatibility_selected_features": compatibility_audit.get(
                    "selected_features"
                ),
                "official_expansion_status": expansion_status,
                "projector_accepted": accepted,
                "projector_rejection_reason": reasons,
                "minimum_interatomic_distance_angstrom": minimum_distance,
                "future_parent_information_used_for_geometry_selection": False,
                "chgnet_used_for_selection": False,
                "failure": failure,
            }
        )
        if failure is not None:
            break
    if state.remaining_composition and failure is None:
        failure = "MAX_ORBITS_EXCEEDED"
    completed = not state.remaining_composition and failure is None
    legal_terminal = bool(
        completed and receipt is not None and compiler.can_terminate(state, receipt)
    )
    structure = _receipt_structure(receipt) if receipt is not None else None
    metrics = _structure_metrics(_parent_structure(parent), structure)
    composition_match = bool(
        not state.remaining_composition
        and receipt is not None
        and receipt.composition_valid
    )
    target_sg_match = metrics["detected_space_group"] == parent.target_space_group
    finite_geometry = _finite_structure(structure)
    terminal_valid = bool(
        legal_terminal and composition_match and target_sg_match and finite_geometry
    )
    classification = failure_class(terminal_valid=terminal_valid, failure=failure)
    record_id = f"{int(stream_seed)}:{arm}:{parent_id}"
    trajectory = {
        "schema_version": SCHEMA_VERSION,
        "record_id": record_id,
        "stream_seed": int(stream_seed),
        "arm": arm,
        "parent_id": parent_id,
        "completed_steps": sum(
            row["chosen_action_signature"] is not None for row in step_rows
        ),
        "failure": failure,
        "failure_class": classification,
        "legal_terminal": legal_terminal,
        "composition_match": composition_match,
        "target_space_group_valid": target_sg_match,
        "finite_geometry": finite_geometry,
        "terminal_valid": terminal_valid,
        "formula_sg_legal_terminal": terminal_valid,
        "geometry_endpoint_rejection": classification == "GEOMETRY_ENDPOINT_REJECTION",
        "discrete_dead_end": classification == "DISCRETE_DEAD_END",
        "wrong_terminal": classification == "WRONG_TERMINAL",
        "parent_consistent_action_rate": (
            float(np.mean(strict_matches)) if strict_matches else 0.0
        ),
        "mdn_selected_step_count": sum(
            value for (stage, method), value in usage.items() if method == "DIRECT_MDN"
        ),
        "compatibility_selected_step_count": sum(
            value
            for (stage, method), value in usage.items()
            if method == "COMPATIBILITY_MLP"
        ),
        "fixed_geometry_step_count": sum(
            value
            for (stage, method), value in usage.items()
            if method == "FIXED_GEOMETRY"
        ),
        "geometry_usage_by_stage": {
            stage: {
                method: int(usage[(stage, method)])
                for method in (
                    "DIRECT_MDN",
                    "COMPATIBILITY_MLP",
                    "FIXED_GEOMETRY",
                )
            }
            for stage in ("EARLY", "MID", "LATE")
        },
        "future_parent_information_used_for_selection": False,
        "chgnet_used_for_selection": False,
        "initial_max_force_ev_per_angstrom": None,
        "chgnet_status": "PENDING" if terminal_valid else "NOT_LEGAL_TERMINAL",
        "steps": step_rows,
        **metrics,
    }
    return trajectory, structure if terminal_valid else None


def _load_policy_and_mdn(
    policy_checkpoint: Path,
    mdn_checkpoint: Path,
    device: torch.device,
) -> tuple[OrbitInversePolicy, WrappedMixtureDensityDecoder, dict[str, object]]:
    policy_payload = torch.load(
        policy_checkpoint, map_location="cpu", weights_only=False
    )
    validate_frozen_policy_metadata(policy_payload)
    policy = OrbitInversePolicy()
    policy.load_state_dict(policy_payload["model"])
    policy.eval().to(device).requires_grad_(False)
    mdn_payload = torch.load(mdn_checkpoint, map_location="cpu", weights_only=False)
    if (
        mdn_payload.get("schema_version") != "wrapped-mdn-checkpoint.1.0.0"
        or int(mdn_payload.get("update", -1)) != 1500
    ):
        raise RuntimeError("frozen Direct-MDN checkpoint drifted")
    mdn = WrappedMixtureDensityDecoder()
    mdn.load_state_dict(mdn_payload["model"])
    mdn.eval().to(device).requires_grad_(False)
    return (
        policy,
        mdn,
        {
            "policy_update": int(policy_payload["update"]),
            "policy_parameter_n": sum(
                parameter.numel() for parameter in policy.parameters()
            ),
            "mdn_update": int(mdn_payload["update"]),
            "mdn_parameter_n": sum(parameter.numel() for parameter in mdn.parameters()),
        },
    )


def _preflight(
    args: argparse.Namespace,
) -> tuple[dict[str, Any], tuple[str, ...], dict[str, object]]:
    parents = load_recovered_parents(args.recovered_parents)
    split_rows = _read_csv(args.development_split)
    split_counts = Counter(row["split"] for row in split_rows)
    if split_counts != Counter(
        {"policy_train": 6911, "policy_validation": 768, "diagnostic": 159}
    ):
        raise RuntimeError(f"frozen development split drifted: {split_counts}")
    split_by_parent = {row["parent_id"]: row["split"] for row in split_rows}
    compatibility_training_ids = {
        row["parent_id"] for row in _read_csv(args.compatibility_training_events)
    }
    assembly_depth_ids = {
        row["parent_id"] for row in _read_csv(args.assembly_depth_events)
    }
    diagnostic_ids = {
        str(value)
        for value in json.loads(args.diagnostic_ids.read_text(encoding="utf-8"))[
            "parent_ids"
        ]
    }
    if (
        len(compatibility_training_ids) != 64
        or len(assembly_depth_ids) != 32
        or len(diagnostic_ids) != 159
    ):
        raise RuntimeError("registered exclusion-set counts drifted")
    exclusion_sets = (
        compatibility_training_ids,
        assembly_depth_ids,
        diagnostic_ids,
    )
    if any(
        exclusion_sets[left] & exclusion_sets[right]
        for left, right in ((0, 1), (0, 2), (1, 2))
    ):
        raise RuntimeError("registered exclusion sets are not disjoint")
    forbidden = set().union(*exclusion_sets)
    compiler = SpaceGroupLegalActionCompiler(max_sites=MAX_SITES)
    metadata = []
    for parent_id, split in split_by_parent.items():
        if split not in {"policy_train", "policy_validation"}:
            continue
        parent = parents[parent_id]
        orbit_count = len(parent.orbits)
        site_count = sum(int(orbit.multiplicity) for orbit in parent.orbits)
        if not 1 <= orbit_count <= MAX_ORBITS or site_count > MAX_SITES:
            continue
        initial = SymmetryAssemblyState.empty(
            target_space_group=parent.target_space_group,
            composition=_composition(parent),
            lattice=parent.lattice,
        )
        if not compiler.legal_add_actions(initial):
            continue
        metadata.append(
            {
                "parent_id": parent_id,
                "original_split_source": split,
                "crystal_system": parent.lattice.crystal_system,
                "orbit_count": orbit_count,
                "free_dof_count": sum(
                    len(orbit.free_parameters) for orbit in parent.orbits
                ),
                "element_count": len(_composition(parent)),
            }
        )
    selected = deterministic_integrated_parent_sample(
        metadata,
        forbidden_parent_ids=forbidden,
        count=PARENT_N,
        seed=SELECTION_SEED,
    )
    if set(selected) & forbidden or len(selected) != PARENT_N:
        raise RuntimeError("integrated cohort isolation failed")
    selected_metadata = [row for row in metadata if row["parent_id"] in set(selected)]
    preview = {
        "PARENT_N": len(selected),
        "ELIGIBLE_DEVELOPMENT_PARENT_N": sum(
            row["parent_id"] not in forbidden for row in metadata
        ),
        "POLICY_TRAIN_SELECTED_N": sum(
            row["original_split_source"] == "policy_train" for row in selected_metadata
        ),
        "POLICY_VALIDATION_SELECTED_N": sum(
            row["original_split_source"] == "policy_validation"
            for row in selected_metadata
        ),
        "EXCLUDED_COMPATIBILITY_TRAINING_N": len(compatibility_training_ids),
        "EXCLUDED_ASSEMBLY_DEPTH_N": len(assembly_depth_ids),
        "EXCLUDED_DIAGNOSTIC_N": len(diagnostic_ids),
        "FORBIDDEN_OVERLAP_N": len(set(selected) & forbidden),
        "ORBIT_COUNT_DISTRIBUTION": dict(
            sorted(Counter(row["orbit_count"] for row in selected_metadata).items())
        ),
        "CRYSTAL_SYSTEM_DISTRIBUTION": dict(
            sorted(Counter(row["crystal_system"] for row in selected_metadata).items())
        ),
        "NEW_MODEL_TRAINING_RUNS": 0,
        "CHGNET_RUNS": 0,
    }
    return parents, selected, preview


def _evaluate_chgnet(
    trajectories: Sequence[dict[str, object]],
    structures: Mapping[str, Any],
    *,
    device: str,
    started: float,
) -> None:
    model = _load_chgnet(device)
    by_id = {str(row["record_id"]): row for row in trajectories}
    keys = sorted(structures)
    for start in range(0, len(keys), 16):
        _check_deadline(started, "CHGNet single-point evaluation")
        batch_keys = keys[start : start + 16]
        batch = [structures[key] for key in batch_keys]
        try:
            raw = model.predict_structure(batch, task="ef", batch_size=16)
            outputs = raw if isinstance(raw, list) else [raw]
            if len(outputs) != len(batch_keys):
                raise RuntimeError("CHGNet batch output count mismatch")
        except Exception as error:
            reason = f"{type(error).__name__}:{error}"
            for key in batch_keys:
                by_id[key]["chgnet_status"] = "FAILED"
                by_id[key]["chgnet_failure_reason"] = reason
            continue
        for key, output in zip(batch_keys, outputs, strict=True):
            force = output["f"]
            if hasattr(force, "detach"):
                force = force.detach().cpu()
            array = np.asarray(force, dtype=float)
            maximum = float(np.linalg.norm(array, axis=-1).max())
            if math.isfinite(maximum) and maximum >= 0.0:
                by_id[key]["initial_max_force_ev_per_angstrom"] = maximum
                by_id[key]["chgnet_status"] = "EVALUATED"
            else:
                by_id[key]["chgnet_status"] = "FAILED"
                by_id[key]["chgnet_failure_reason"] = "NONFINITE_FORCE"
        print(
            json.dumps(
                {
                    "phase": "CHGNET",
                    "completed": min(start + 16, len(keys)),
                    "total": len(keys),
                },
                sort_keys=True,
            ),
            flush=True,
        )
    del model
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


def _force_summary(rows: Sequence[Mapping[str, object]]) -> dict[str, object]:
    values = np.asarray(
        [
            float(row["initial_max_force_ev_per_angstrom"])
            for row in rows
            if row["chgnet_status"] == "EVALUATED"
        ],
        dtype=float,
    )
    return {
        "n": int(len(values)),
        "median": float(np.median(values)) if len(values) else None,
        "mean": float(np.mean(values)) if len(values) else None,
        "p90": float(np.quantile(values, 0.90)) if len(values) else None,
        "p95": float(np.quantile(values, 0.95)) if len(values) else None,
    }


def _aggregate(
    trajectories: Sequence[dict[str, object]], parent_ids: Sequence[str]
) -> dict[str, object]:
    if len(trajectories) != PARENT_N * len(ARMS) * len(STREAM_SEEDS):
        raise RuntimeError("trajectory count differs from registered 1536")
    stream_rows = []
    arm_summaries = {}
    for stream_seed in STREAM_SEEDS:
        for arm in ARMS:
            rows = [
                row
                for row in trajectories
                if row["stream_seed"] == stream_seed and row["arm"] == arm
            ]
            stream_rows.append(
                {
                    "stream_seed": stream_seed,
                    "arm": arm,
                    "trajectory_n": len(rows),
                    "legal_terminal_n": sum(
                        bool(row["terminal_valid"]) for row in rows
                    ),
                    "legal_terminal_rate": float(
                        np.mean([bool(row["terminal_valid"]) for row in rows])
                    ),
                    "geometry_rejection_n": sum(
                        bool(row["geometry_endpoint_rejection"]) for row in rows
                    ),
                    "discrete_dead_end_n": sum(
                        bool(row["discrete_dead_end"]) for row in rows
                    ),
                    "wrong_terminal_n": sum(
                        bool(row["wrong_terminal"]) for row in rows
                    ),
                    "mean_completed_steps": float(
                        np.mean([int(row["completed_steps"]) for row in rows])
                    ),
                }
            )
    for arm in ARMS:
        rows = [row for row in trajectories if row["arm"] == arm]
        classes = Counter(str(row["failure_class"]) for row in rows)
        if sum(classes.values()) != len(rows):
            raise RuntimeError(f"failure decomposition is incomplete for {arm}")
        rates = [row["legal_terminal_rate"] for row in stream_rows if row["arm"] == arm]
        arm_summaries[arm] = {
            "trajectory_n": len(rows),
            "legal_terminal_n": sum(bool(row["terminal_valid"]) for row in rows),
            "legal_terminal_mean": float(np.mean(rates)),
            "legal_terminal_sd": float(np.std(rates, ddof=1)),
            "legal_terminal_range": [float(np.min(rates)), float(np.max(rates))],
            "geometry_rejection_rate": classes["GEOMETRY_ENDPOINT_REJECTION"]
            / len(rows),
            "discrete_dead_end_rate": classes["DISCRETE_DEAD_END"] / len(rows),
            "wrong_terminal_rate": classes["WRONG_TERMINAL"] / len(rows),
            "failure_class_counts": dict(classes),
            "mean_completed_steps": float(
                np.mean([int(row["completed_steps"]) for row in rows])
            ),
            "force": _force_summary(rows),
        }
    terminal = terminal_factorial_analysis(
        trajectories, stream_seeds=STREAM_SEEDS, parent_ids=parent_ids
    )
    force = {
        "C_MINUS_A": force_pair_analysis(
            trajectories,
            left_arm=ARM_C,
            right_arm=ARM_A,
            stream_seeds=STREAM_SEEDS,
            parent_ids=parent_ids,
            seed=SELECTION_SEED + 10,
        ),
        "D_MINUS_B": force_pair_analysis(
            trajectories,
            left_arm=ARM_D,
            right_arm=ARM_B,
            stream_seeds=STREAM_SEEDS,
            parent_ids=parent_ids,
            seed=SELECTION_SEED + 11,
        ),
        "D_MINUS_A": force_pair_analysis(
            trajectories,
            left_arm=ARM_D,
            right_arm=ARM_A,
            stream_seeds=STREAM_SEEDS,
            parent_ids=parent_ids,
            seed=SELECTION_SEED + 12,
        ),
    }
    force_interaction = force_interaction_analysis(
        trajectories,
        stream_seeds=STREAM_SEEDS,
        parent_ids=parent_ids,
        seed=SELECTION_SEED + 13,
    )
    synergy = component_synergy(
        terminal_interaction=float(terminal["INTERACTION"]["point"]),
        force_interaction=float(force_interaction["point"]),
    )
    verdict = integrated_verdict(
        b_minus_a_terminal=terminal["B_MINUS_A"],
        d_minus_b_terminal=terminal["D_MINUS_B"],
        d_minus_a_terminal=terminal["D_MINUS_A"],
        d_minus_b_force=force["D_MINUS_B"],
        d_minus_a_force=force["D_MINUS_A"],
    )
    stage_usage = {
        stage: {
            method: sum(
                int(row["geometry_usage_by_stage"][stage][method])
                for row in trajectories
                if row["arm"] in {ARM_C, ARM_D}
            )
            for method in (
                "DIRECT_MDN",
                "COMPATIBILITY_MLP",
                "FIXED_GEOMETRY",
            )
        }
        for stage in ("EARLY", "MID", "LATE")
    }
    if stage_usage["EARLY"]["COMPATIBILITY_MLP"] != 0:
        raise RuntimeError("EARLY_COMPATIBILITY_USE_N is nonzero")
    return {
        "stream_rows": stream_rows,
        "arms": arm_summaries,
        "terminal": terminal,
        "force": force,
        "terminal_interaction": terminal["INTERACTION"],
        "force_interaction": force_interaction,
        "component_synergy": synergy,
        "stage_usage": stage_usage,
        "verdict": verdict,
    }


def _csv_value(value: object) -> object:
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, sort_keys=True, separators=(",", ":"))
    return value


def _write_csv_new(path: Path, rows: Sequence[Mapping[str, object]]) -> None:
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("x", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: _csv_value(row.get(key)) for key in fieldnames})


def _write_jsonl_new(path: Path, rows: Sequence[Mapping[str, object]]) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, sort_keys=True) + "\n")


def _format(value: object) -> str:
    return "NA" if value is None else f"{float(value):.12f}"


def _result_rows(
    analysis: Mapping[str, object], total_minutes: float
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for stream_row in analysis["stream_rows"]:
        rows.append(
            {
                "schema_version": SCHEMA_VERSION,
                "row_type": "STREAM_SUMMARY",
                **stream_row,
            }
        )
    for arm, summary in analysis["arms"].items():
        force = summary["force"]
        rows.append(
            {
                "schema_version": SCHEMA_VERSION,
                "row_type": "ARM_SUMMARY",
                "arm": arm,
                **{key: value for key, value in summary.items() if key != "force"},
                **{f"force_{key}": value for key, value in force.items()},
            }
        )
    for name, comparison in analysis["terminal"].items():
        rows.append(
            {
                "schema_version": SCHEMA_VERSION,
                "row_type": "TERMINAL_COMPARISON",
                "comparison": name,
                **comparison,
            }
        )
    for name, comparison in analysis["force"].items():
        rows.append(
            {
                "schema_version": SCHEMA_VERSION,
                "row_type": "FORCE_COMPARISON",
                "comparison": name,
                **comparison,
            }
        )
    rows.append(
        {
            "schema_version": SCHEMA_VERSION,
            "row_type": "FORCE_INTERACTION",
            "comparison": "INTERACTION",
            **analysis["force_interaction"],
        }
    )
    for stage, values in analysis["stage_usage"].items():
        rows.append(
            {
                "schema_version": SCHEMA_VERSION,
                "row_type": "STAGE_USAGE",
                "stage": stage,
                **values,
            }
        )
    rows.append(
        {
            "schema_version": SCHEMA_VERSION,
            "row_type": "VERDICT",
            "component_synergy": analysis["component_synergy"],
            "integrated_crysalis_signal": analysis["verdict"]["signal"],
            "verdict_conditions": analysis["verdict"]["conditions"],
            "new_model_training_runs": 0,
            "fire_runs": 0,
            "mattersim_runs": 0,
            "total_wall_clock_minutes": total_minutes,
            "next_action": analysis["verdict"]["next_action"],
        }
    )
    return rows


def _factorial_markdown(
    analysis: Mapping[str, object], preview: Mapping[str, object], total_minutes: float
) -> str:
    stream_table = "\n".join(
        f"| {row['stream_seed']} | {row['arm']} | {row['legal_terminal_n']}/128 | "
        f"{100*row['legal_terminal_rate']:.3f}% | {row['geometry_rejection_n']} | "
        f"{row['discrete_dead_end_n']} | {row['wrong_terminal_n']} | "
        f"{row['mean_completed_steps']:.3f} |"
        for row in analysis["stream_rows"]
    )
    arm_table = "\n".join(
        f"| {arm} | {100*summary['legal_terminal_mean']:.3f}% | "
        f"{100*summary['geometry_rejection_rate']:.3f}% | "
        f"{100*summary['discrete_dead_end_rate']:.3f}% | "
        f"{summary['force']['n']} | {_format(summary['force']['median'])} | "
        f"{_format(summary['force']['mean'])} | {_format(summary['force']['p90'])} | "
        f"{_format(summary['force']['p95'])} |"
        for arm, summary in analysis["arms"].items()
    )
    terminal_lines = "\n".join(
        f"- `{name}`: {_format(100*value['point'])} pp; CI95 "
        f"[{_format(100*value['ci95_lower'])}, {_format(100*value['ci95_upper'])}] pp."
        for name, value in analysis["terminal"].items()
    )
    force_lines = "\n".join(
        f"- `{name}`: common legal N={value['common_legal_n']}; mean log1p delta "
        f"{_format(value['mean_log1p_force_delta'])}; CI95 "
        f"[{_format(value['ci95_lower'])}, {_format(value['ci95_upper'])}]; "
        f"left-arm win rate {_format(value['left_win_rate'])}."
        for name, value in analysis["force"].items()
    )
    usage_table = "\n".join(
        f"| {stage} | {value['DIRECT_MDN']} | {value['COMPATIBILITY_MLP']} | "
        f"{value['FIXED_GEOMETRY']} |"
        for stage, value in analysis["stage_usage"].items()
    )
    interaction_force = analysis["force_interaction"]
    return f"""# Integrated Crysalis Factorial Analysis

## Frozen scope and cohort

- `PARENT_N = 128`; `STREAM_N = 3`; total trajectories = 1536.
- Development-only eligible parents were sampled structurally after excluding 64 compatibility-training, 32 assembly-depth, and 159 repeated-diagnostic parents; selected forbidden overlap was {preview['FORBIDDEN_OVERLAP_N']}.
- Frozen inverse policy, Direct-MDN, strict parent-free 16-feature MLP, compiler, official expansion, Projector, and CHGNet 0.3.0 were used without training or modification.
- Compatibility gate was exactly active-orbit fraction 0.50. CHGNet was absent from selection. No retry, refill, backtracking, FIRE, MatterSim, or DFT occurred.

## Per-stream terminal and failure outcomes

| Stream | Arm | Legal terminal | Rate | Geometry rejection | Discrete dead end | Wrong terminal | Mean completed steps |
|---:|---|---:|---:|---:|---:|---:|---:|
{stream_table}

## Cross-stream arm summaries

| Arm | Legal mean | Geometry rejection | Discrete dead end | Force N | Median | Mean | p90 | p95 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
{arm_table}

## Terminal factorial effects

{terminal_lines}

## Common-legal physical effects

{force_lines}

## Exploratory interactions

- Terminal interaction `(D-B)-(C-A)`: {_format(100*analysis['terminal_interaction']['point'])} pp; CI95 [{_format(100*analysis['terminal_interaction']['ci95_lower'])}, {_format(100*analysis['terminal_interaction']['ci95_upper'])}] pp.
- Force interaction on all-four-legal N={interaction_force['all_four_legal_n']}: {_format(interaction_force['point'])}; CI95 [{_format(interaction_force['ci95_lower'])}, {_format(interaction_force['ci95_upper'])}].
- `COMPONENT_SYNERGY = {analysis['component_synergy']}` under the preregistered unweighted sign-consensus rule.

## Stage usage in C and D

| Stage | Direct-MDN steps | Compatibility steps | Fixed-geometry steps |
|---|---:|---:|---:|
{usage_table}

`EARLY_COMPATIBILITY_USE_N = {analysis['stage_usage']['EARLY']['COMPATIBILITY_MLP']}`

## Registered integrated decision

`INTEGRATED_CRYSALIS_SIGNAL = {analysis['verdict']['signal']}`

`NEXT_ACTION = {analysis['verdict']['next_action']}`

`TOTAL_WALL_CLOCK_MINUTES = {_format(total_minutes)}`
"""


def _verdict_markdown(analysis: Mapping[str, object], total_minutes: float) -> str:
    arms = analysis["arms"]
    terminal = analysis["terminal"]
    force = analysis["force"]
    usage = analysis["stage_usage"]
    return f"""# CRYSALIS Integrated What-Where Verdict

CRYSALIS_INTEGRATED_WHAT_WHERE_POC = COMPLETE

PARENT_N = 128

STREAM_N = 3

A_UNIFORM_MDN_LEGAL = {_format(arms[ARM_A]['legal_terminal_mean'])}

B_INVERSE_MDN_LEGAL = {_format(arms[ARM_B]['legal_terminal_mean'])}

C_UNIFORM_COMPAT_LEGAL = {_format(arms[ARM_C]['legal_terminal_mean'])}

D_INVERSE_COMPAT_LEGAL = {_format(arms[ARM_D]['legal_terminal_mean'])}

B_MINUS_A_TERMINAL_PP = {_format(100*terminal['B_MINUS_A']['point'])}

B_MINUS_A_CI95 = [{_format(100*terminal['B_MINUS_A']['ci95_lower'])}, {_format(100*terminal['B_MINUS_A']['ci95_upper'])}]

D_MINUS_B_TERMINAL_PP = {_format(100*terminal['D_MINUS_B']['point'])}

D_MINUS_B_CI95 = [{_format(100*terminal['D_MINUS_B']['ci95_lower'])}, {_format(100*terminal['D_MINUS_B']['ci95_upper'])}]

D_MINUS_A_TERMINAL_PP = {_format(100*terminal['D_MINUS_A']['point'])}

D_MINUS_A_CI95 = [{_format(100*terminal['D_MINUS_A']['ci95_lower'])}, {_format(100*terminal['D_MINUS_A']['ci95_upper'])}]

A_FORCE_MEDIAN = {_format(arms[ARM_A]['force']['median'])}

B_FORCE_MEDIAN = {_format(arms[ARM_B]['force']['median'])}

C_FORCE_MEDIAN = {_format(arms[ARM_C]['force']['median'])}

D_FORCE_MEDIAN = {_format(arms[ARM_D]['force']['median'])}

COMMON_LEGAL_D_B_N = {force['D_MINUS_B']['common_legal_n']}

D_MINUS_B_LOG1P_FORCE = {_format(force['D_MINUS_B']['mean_log1p_force_delta'])}

D_MINUS_B_FORCE_CI95 = [{_format(force['D_MINUS_B']['ci95_lower'])}, {_format(force['D_MINUS_B']['ci95_upper'])}]

D_FORCE_WIN_RATE_VS_B = {_format(force['D_MINUS_B']['left_win_rate'])}

D_MINUS_A_LOG1P_FORCE = {_format(force['D_MINUS_A']['mean_log1p_force_delta'])}

D_MINUS_A_FORCE_CI95 = [{_format(force['D_MINUS_A']['ci95_lower'])}, {_format(force['D_MINUS_A']['ci95_upper'])}]

EARLY_COMPATIBILITY_USE_N = {usage['EARLY']['COMPATIBILITY_MLP']}

MID_COMPATIBILITY_USE_N = {usage['MID']['COMPATIBILITY_MLP']}

LATE_COMPATIBILITY_USE_N = {usage['LATE']['COMPATIBILITY_MLP']}

A_GEOMETRY_REJECTION_RATE = {_format(arms[ARM_A]['geometry_rejection_rate'])}

B_GEOMETRY_REJECTION_RATE = {_format(arms[ARM_B]['geometry_rejection_rate'])}

C_GEOMETRY_REJECTION_RATE = {_format(arms[ARM_C]['geometry_rejection_rate'])}

D_GEOMETRY_REJECTION_RATE = {_format(arms[ARM_D]['geometry_rejection_rate'])}

A_DISCRETE_DEAD_END_RATE = {_format(arms[ARM_A]['discrete_dead_end_rate'])}

B_DISCRETE_DEAD_END_RATE = {_format(arms[ARM_B]['discrete_dead_end_rate'])}

C_DISCRETE_DEAD_END_RATE = {_format(arms[ARM_C]['discrete_dead_end_rate'])}

D_DISCRETE_DEAD_END_RATE = {_format(arms[ARM_D]['discrete_dead_end_rate'])}

COMPONENT_SYNERGY = {analysis['component_synergy']}

INTEGRATED_CRYSALIS_SIGNAL = {analysis['verdict']['signal']}

NEW_MODEL_TRAINING_RUNS = 0

FIRE_RUNS = 0

MATTERSIM_RUNS = 0

TOTAL_WALL_CLOCK_MINUTES = {_format(total_minutes)}

NEXT_ACTION = {analysis['verdict']['next_action']}
"""


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--recovered-parents", type=Path, required=True)
    parser.add_argument("--development-split", type=Path, required=True)
    parser.add_argument("--compatibility-training-events", type=Path, required=True)
    parser.add_argument("--assembly-depth-events", type=Path, required=True)
    parser.add_argument("--diagnostic-ids", type=Path, required=True)
    parser.add_argument("--policy-checkpoint", type=Path, required=True)
    parser.add_argument("--mdn-checkpoint", type=Path, required=True)
    parser.add_argument("--frozen-operator", type=Path, required=True)
    parser.add_argument("--training-candidates", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    parser.add_argument("--preflight-only", action="store_true")
    return parser.parse_args()


def main() -> None:
    started = time.monotonic()
    args = _parse_args()
    if args.output.exists():
        raise FileExistsError(f"output already exists: {args.output}")
    if args.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")
    parents, parent_ids, preview = _preflight(args)
    _check_deadline(started, "preflight")
    print(json.dumps({"phase": "PREFLIGHT", **preview}, sort_keys=True), flush=True)
    if args.preflight_only:
        return

    device = torch.device(args.device)
    policy, mdn, model_audit = _load_policy_and_mdn(
        args.policy_checkpoint, args.mdn_checkpoint, device
    )
    compatibility_mlp, compatibility_normalization = _load_frozen_mlp(
        args.frozen_operator, args.training_candidates
    )
    compiler = SpaceGroupLegalActionCompiler(max_sites=MAX_SITES)
    projector = C0SymmetryProjector(minimum_distance=PROJECTOR_MINIMUM_DISTANCE)
    expander = SpaceGroupConditionedWyckoffExpander()
    trajectories: list[dict[str, object]] = []
    structures: dict[str, Any] = {}
    total_trajectory_n = PARENT_N * len(ARMS) * len(STREAM_SEEDS)
    for stream_seed in STREAM_SEEDS:
        for arm in ARMS:
            for parent_id in parent_ids:
                trajectory, structure = _run_trajectory(
                    parent=parents[parent_id],
                    arm=arm,
                    stream_seed=stream_seed,
                    policy=policy,
                    mdn=mdn,
                    compatibility_mlp=compatibility_mlp,
                    compatibility_normalization=compatibility_normalization,
                    compiler=compiler,
                    projector=projector,
                    expander=expander,
                    device=device,
                    started=started,
                )
                trajectories.append(trajectory)
                if structure is not None:
                    structures[str(trajectory["record_id"])] = structure
                if len(trajectories) % 64 == 0:
                    print(
                        json.dumps(
                            {
                                "phase": "ROLLOUT",
                                "completed": len(trajectories),
                                "total": total_trajectory_n,
                            },
                            sort_keys=True,
                        ),
                        flush=True,
                    )
    if len(trajectories) != total_trajectory_n:
        raise RuntimeError("rollout did not produce all registered trajectories")
    early_compatibility = sum(
        int(row["geometry_usage_by_stage"]["EARLY"]["COMPATIBILITY_MLP"])
        for row in trajectories
        if row["arm"] in {ARM_C, ARM_D}
    )
    if early_compatibility != 0:
        raise RuntimeError("EARLY_COMPATIBILITY_USE_N is nonzero before CHGNet")
    del policy, mdn
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    _evaluate_chgnet(trajectories, structures, device=args.device, started=started)
    analysis = _aggregate(trajectories, parent_ids)
    total_minutes = (time.monotonic() - started) / 60.0
    if total_minutes > MAX_WALL_CLOCK_MINUTES:
        raise TimeoutError("aggregation exceeded the 30-minute total deadline")
    result_rows = _result_rows(analysis, total_minutes)
    args.output.mkdir(parents=True, exist_ok=False)
    _write_jsonl_new(
        args.output / "INTEGRATED_CRYSALIS_TRAJECTORIES.jsonl", trajectories
    )
    _write_csv_new(args.output / "INTEGRATED_CRYSALIS_RESULTS.csv", result_rows)
    with (args.output / "INTEGRATED_CRYSALIS_FACTORIAL_ANALYSIS.md").open(
        "x", encoding="utf-8", newline="\n"
    ) as handle:
        handle.write(_factorial_markdown(analysis, preview, total_minutes))
    with (args.output / "CRYSALIS_INTEGRATED_WHAT_WHERE_VERDICT.md").open(
        "x", encoding="utf-8", newline="\n"
    ) as handle:
        handle.write(_verdict_markdown(analysis, total_minutes))
    print(
        json.dumps(
            {
                "phase": "COMPLETE",
                "output": str(args.output),
                "model_audit": model_audit,
                "compatibility_reload_sanity_max_abs_error": compatibility_normalization[
                    "reload_sanity_max_abs_error"
                ],
                "trajectory_n": len(trajectories),
                "legal_structure_n": len(structures),
                "component_synergy": analysis["component_synergy"],
                "integrated_crysalis_signal": analysis["verdict"]["signal"],
                "next_action": analysis["verdict"]["next_action"],
                "new_model_training_runs": 0,
                "total_wall_clock_minutes": total_minutes,
            },
            sort_keys=True,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
