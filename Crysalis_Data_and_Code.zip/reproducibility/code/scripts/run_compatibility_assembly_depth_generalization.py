from __future__ import annotations

import argparse
import csv
import json
import math
import time
from collections import Counter
from collections.abc import Mapping, Sequence
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import numpy as np
import torch
from pymatgen.core import Lattice, Structure

from crysalis_g1.experiments.assembly_depth_generalization import (
    STAGE_TARGETS,
    assemble_depth_event_pool,
    generalization_verdict,
    paired_force_comparison,
    select_depth_cohort,
)
from crysalis_g1.experiments.c0_symmetry_oracle import load_recovered_parents
from crysalis_g1.experiments.full_orbit_compatibility import (
    full_orbit_parent_free_features,
    shifted_halton_points,
)
from crysalis_g1.experiments.full_orbit_operator import (
    FullOrbitCompatibilityMLP,
    REGISTERED_FEATURE_NAMES,
    audit_parent_free_schema,
    stable_random_candidate_index,
)
from crysalis_g1.geometry_mdn.evaluation import load_final_model
from crysalis_g1.symmetry.assembly import (
    SpaceGroupLegalActionCompiler,
    SymmetryAssemblyState,
)
from crysalis_g1.symmetry.wyckoff import (
    OrbitState,
    SpaceGroupConditionedWyckoffExpander,
    WyckoffExpansionError,
)
from scripts.run_full_orbit_compatibility_dataset_poc import _load_chgnet
from scripts.run_parent_restricted_orbit_rollout import _sample_direct_mdn

SCHEMA_VERSION = "crysalis-compatibility-assembly-depth-generalization.1.0.0"
MAX_WALL_CLOCK_MINUTES = 20.0
PARENT_N = 32
CANDIDATE_N = 24
ARMS = ("RANDOM", "CONTACT", "DIRECT_MDN", "MLP")
BASELINES = ("RANDOM", "DIRECT_MDN", "CONTACT")


def _deadline(started: float, phase: str) -> None:
    elapsed = (time.monotonic() - started) / 60.0
    if elapsed >= MAX_WALL_CLOCK_MINUTES:
        raise TimeoutError(
            f"{phase} exceeded {MAX_WALL_CLOCK_MINUTES:g} wall-clock minutes"
        )


def _read_jsonl(path: Path) -> list[dict[str, object]]:
    rows = []
    with path.open(encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as error:
                raise ValueError(f"invalid JSONL at {path}:{line_number}") from error
    return rows


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def _composition(parent: Any) -> tuple[tuple[int, int], ...]:
    counts: Counter[int] = Counter()
    for orbit in parent.orbits:
        counts[int(orbit.species)] += int(orbit.multiplicity)
    return tuple(sorted(counts.items()))


def _partial_state(parent: Any, event: Mapping[str, object]) -> SymmetryAssemblyState:
    active_ids = {str(value) for value in event["active_orbit_ids"]}
    active = tuple(
        orbit for orbit in parent.orbits if orbit.orbit_instance_id in active_ids
    )
    if len(active) != len(active_ids):
        raise RuntimeError(f"active orbit identity mismatch: {event['event_id']}")
    remaining = Counter(dict(_composition(parent)))
    for orbit in active:
        remaining[int(orbit.species)] -= int(orbit.multiplicity)
    remaining = Counter({key: value for key, value in remaining.items() if value})
    return SymmetryAssemblyState(
        target_space_group=int(parent.target_space_group),
        composition=_composition(parent),
        remaining_composition=tuple(sorted(remaining.items())),
        lattice=parent.lattice,
        orbits=active,
    )


def _target_key(event: Mapping[str, object]) -> tuple[str, int, int, int]:
    return (
        str(event["wyckoff_letter"]),
        int(event["species"]),
        int(event["multiplicity"]),
        int(event["free_dof"]),
    )


def _preflight_cohort(
    args: argparse.Namespace,
) -> tuple[dict[str, Any], list[dict[str, object]], dict[str, Any]]:
    recovered = load_recovered_parents(args.recovered_parents)
    parent_payloads = {key: value.to_dict() for key, value in recovered.items()}
    graph_rows = _read_jsonl(args.state_graph)
    split_rows = _read_csv(args.development_split)
    split_by_parent = {row["parent_id"]: row["split"] for row in split_rows}
    if Counter(split_by_parent.values()) != Counter(
        {"policy_train": 6911, "policy_validation": 768, "diagnostic": 159}
    ):
        raise RuntimeError("development split counts drifted")
    training_rows = _read_csv(args.training_events)
    training_ids = {row["parent_id"] for row in training_rows}
    diagnostic_payload = json.loads(args.diagnostic_ids.read_text(encoding="utf-8"))
    diagnostic_ids = {str(value) for value in diagnostic_payload["parent_ids"]}
    if len(training_ids) != 64 or len(diagnostic_ids) != 159:
        raise RuntimeError("registered parent exclusion counts drifted")
    if training_ids & diagnostic_ids:
        raise RuntimeError("training and diagnostic exclusion sets overlap")
    forbidden = training_ids | diagnostic_ids
    pool = assemble_depth_event_pool(
        parent_payloads, graph_rows, forbidden_parent_ids=forbidden
    )
    selected = select_depth_cohort(pool, target_parent_n=PARENT_N)
    selected_ids = {str(event["parent_id"]) for event in selected}
    if selected_ids & forbidden or len(selected_ids) != PARENT_N:
        raise RuntimeError("selected parent isolation failed")
    for event in selected:
        if (
            split_by_parent.get(str(event["parent_id"]))
            != event["original_split_source"]
        ):
            raise RuntimeError("selected event split provenance mismatch")

    compiler = SpaceGroupLegalActionCompiler(max_sites=20)
    expander = SpaceGroupConditionedWyckoffExpander()
    validated: list[dict[str, object]] = []
    skipped: list[dict[str, object]] = []
    for event in selected:
        parent = recovered[str(event["parent_id"])]
        state = _partial_state(parent, event)
        legal_keys = {
            (
                action.wyckoff_letter,
                action.species,
                action.multiplicity,
                action.free_parameter_count,
            )
            for action in compiler.legal_add_actions(state)
        }
        try:
            target = next(
                orbit
                for orbit in parent.orbits
                if orbit.orbit_instance_id == event["target_orbit_id"]
            )
            expanded = expander.expand(
                target,
                parent.lattice.primitive_matrix,
                require_target_space_group=False,
                require_distinct_orbit_instances=False,
            )
            valid = (
                _target_key(event) in legal_keys
                and len(expanded.atomic_numbers) == int(event["multiplicity"])
                and np.isfinite(
                    np.asarray(expanded.fractional_coordinates, dtype=float)
                ).all()
            )
        except (StopIteration, ValueError, WyckoffExpansionError) as error:
            valid = False
            event = {**event, "preflight_failure": f"{type(error).__name__}:{error}"}
        if valid:
            validated.append(dict(event))
        else:
            skipped.append(dict(event))
    stage_counts = Counter(str(event["stage"]) for event in validated)
    preview = {
        "PARENT_N": len(selected_ids),
        "EARLY_EVENT_N": stage_counts["EARLY"],
        "MID_EVENT_N": stage_counts["MID"],
        "LATE_EVENT_N": stage_counts["LATE"],
        "STRUCTURAL_EVENT_POOL_N": len(pool),
        "POLICY_TRAIN_PARENT_N": sum(
            split_by_parent[parent_id] == "policy_train" for parent_id in selected_ids
        ),
        "POLICY_VALIDATION_PARENT_N": sum(
            split_by_parent[parent_id] == "policy_validation"
            for parent_id in selected_ids
        ),
        "EXCLUDED_COMPATIBILITY_TRAINING_PARENT_N": len(training_ids),
        "EXCLUDED_DIAGNOSTIC_PARENT_N": len(diagnostic_ids),
        "OFFICIAL_PREFLIGHT_SKIPPED_EVENT_N": len(skipped),
        "FUTURE_PARENT_INFORMATION_USED_FOR_SELECTION": False,
        "NEW_MODEL_TRAINING_RUNS": 0,
    }
    if stage_counts != Counter({"EARLY": 32, "MID": 32, "LATE": 32}):
        raise RuntimeError(f"official stage coverage failed without refill: {preview}")
    return recovered, validated, preview


def _load_frozen_mlp(
    frozen: Path, training_candidates: Path
) -> tuple[Any, dict[str, Any]]:
    schema = json.loads((frozen / "feature_schema.json").read_text(encoding="utf-8"))
    audit = audit_parent_free_schema(schema)
    if audit["parent_dependent_input_n"] != 0:
        raise RuntimeError("frozen feature schema is not strictly parent-free")
    normalization = json.loads(
        (frozen / "normalization.json").read_text(encoding="utf-8")
    )
    config = json.loads((frozen / "model_config.json").read_text(encoding="utf-8"))
    if normalization["feature_names"] != list(REGISTERED_FEATURE_NAMES):
        raise RuntimeError("frozen normalization feature order drifted")
    if (
        int(config["input_n"]) != 16
        or int(config["parameter_n"]) != 18817
        or not bool(config["reload_sanity_passed"])
    ):
        raise RuntimeError("frozen model configuration drifted")
    payload = torch.load(frozen / "model.pt", map_location="cpu", weights_only=True)
    model = FullOrbitCompatibilityMLP(input_n=16)
    model.load_state_dict(payload["state_dict"])
    model.eval().requires_grad_(False)
    x_mean = np.asarray(normalization["x_mean"], dtype=float)
    x_scale = np.asarray(normalization["x_scale"], dtype=float)
    y_mean = float(normalization["y_mean"])
    y_scale = float(normalization["y_scale"])
    if (
        x_mean.shape != (16,)
        or x_scale.shape != (16,)
        or not np.isfinite(x_mean).all()
        or not np.isfinite(x_scale).all()
        or np.any(x_scale <= 0.0)
        or not y_scale > 0.0
    ):
        raise RuntimeError("frozen normalization is invalid")

    saved_rows = {row["candidate_id"]: row for row in _read_csv(training_candidates)}
    sanity_ids = [str(value) for value in config["sanity_candidate_ids"]]
    sanity_x = np.asarray(
        [
            [float(saved_rows[candidate_id][name]) for name in REGISTERED_FEATURE_NAMES]
            for candidate_id in sanity_ids
        ],
        dtype=float,
    )
    with torch.no_grad():
        prediction = model(
            torch.as_tensor((sanity_x - x_mean) / x_scale, dtype=torch.float32)
        ).numpy()
    prediction = prediction * y_scale + y_mean
    expected = np.asarray(config["sanity_prediction_log1p_force"], dtype=float)
    maximum_error = float(np.max(np.abs(prediction - expected)))
    if not np.allclose(prediction, expected, atol=1e-7, rtol=0.0):
        raise RuntimeError(f"frozen MLP reload sanity failed: {maximum_error}")
    return model, {
        "x_mean": x_mean,
        "x_scale": x_scale,
        "y_mean": y_mean,
        "y_scale": y_scale,
        "reload_sanity_max_abs_error": maximum_error,
        "parent_dependent_input_n": int(audit["parent_dependent_input_n"]),
    }


def _selection_candidates(
    *,
    event: Mapping[str, object],
    parent: Any,
    state: SymmetryAssemblyState,
    expander: SpaceGroupConditionedWyckoffExpander,
    mlp: Any,
    normalization: Mapping[str, Any],
) -> tuple[list[dict[str, object]], dict[str, dict[str, object]]]:
    partial = expander.expand_many(
        state.orbits,
        parent.lattice.primitive_matrix,
        require_target_space_group=False,
        require_distinct_orbit_instances=False,
    )
    framework_z = np.asarray(partial.atomic_numbers, dtype=int)
    framework_frac = np.asarray(partial.fractional_coordinates, dtype=float)
    site_progress = state.site_count / sum(count for _, count in state.composition)
    rows: list[dict[str, object]] = []
    for candidate_index, legal_u in enumerate(
        shifted_halton_points(int(event["free_dof"]), count=CANDIDATE_N)
    ):
        candidate_id = f"{event['event_id']}:candidate-{candidate_index:02d}"
        row: dict[str, object] = {
            "candidate_id": candidate_id,
            "candidate_index": candidate_index,
            "legal_u": tuple(float(value) for value in legal_u),
            "expansion_valid": False,
            "failure_reason": None,
        }
        try:
            orbit = OrbitState.create(
                int(event["target_space_group"]),
                str(event["wyckoff_letter"]),
                int(event["species"]),
                legal_u,
                cell_transform=parent.lattice.cell_transform_values,
                orbit_instance_id=str(event["target_orbit_id"]),
            )
            expanded = expander.expand(
                orbit,
                parent.lattice.primitive_matrix,
                require_target_space_group=False,
                require_distinct_orbit_instances=False,
            )
            if len(expanded.atomic_numbers) != int(event["multiplicity"]):
                raise ValueError("candidate multiplicity mismatch")
            features = full_orbit_parent_free_features(
                lattice=Lattice(parent.lattice.primitive_matrix),
                framework_atomic_numbers=framework_z,
                framework_fractional_coordinates=framework_frac,
                candidate_atomic_number=int(event["species"]),
                candidate_fractional_coordinates=np.asarray(
                    expanded.fractional_coordinates, dtype=float
                ),
                free_dof=int(event["free_dof"]),
                assembly_progress=site_progress,
            )
            row.update(features)
            row["expansion_valid"] = True
        except (ValueError, WyckoffExpansionError) as error:
            row["failure_reason"] = f"{type(error).__name__}:{error}"
        rows.append(row)
    valid = [row for row in rows if row["expansion_valid"]]
    if not valid:
        raise RuntimeError(
            f"event has no expansion-valid registered candidates: {event['event_id']}"
        )
    parent_u = np.asarray(event["parent_u_star"], dtype=float)
    for row in valid:
        delta = np.abs(np.asarray(row["legal_u"], dtype=float) - parent_u)
        if float(np.max(np.minimum(delta, 1.0 - delta))) <= 1e-12:
            raise RuntimeError(
                f"registered candidate contains parent u*: {event['event_id']}"
            )
    feature_matrix = np.asarray(
        [[float(row[name]) for name in REGISTERED_FEATURE_NAMES] for row in valid],
        dtype=float,
    )
    with torch.no_grad():
        standardized = mlp(
            torch.as_tensor(
                (feature_matrix - normalization["x_mean"]) / normalization["x_scale"],
                dtype=torch.float32,
            )
        ).numpy()
    prediction = standardized * float(normalization["y_scale"]) + float(
        normalization["y_mean"]
    )
    for row, value in zip(valid, prediction, strict=True):
        row["mlp_predicted_log1p_force"] = float(value)
    by_id = {str(row["candidate_id"]): row for row in valid}
    random_id = stable_random_candidate_index(str(event["event_id"]), list(by_id))
    selected = {
        "RANDOM": by_id[random_id],
        "CONTACT": min(
            valid,
            key=lambda row: (
                float(row["static_full_orbit_contact_score"]),
                int(row["candidate_index"]),
            ),
        ),
        "MLP": min(
            valid,
            key=lambda row: (
                float(row["mlp_predicted_log1p_force"]),
                int(row["candidate_index"]),
            ),
        ),
    }
    return rows, selected


def _direct_mdn_selection(
    *,
    model: Any,
    parent: Any,
    state: SymmetryAssemblyState,
    event: Mapping[str, object],
    device: str,
) -> dict[str, object]:
    zero_geometry_target = OrbitState.create(
        int(event["target_space_group"]),
        str(event["wyckoff_letter"]),
        int(event["species"]),
        (0.0,) * int(event["free_dof"]),
        cell_transform=parent.lattice.cell_transform_values,
        orbit_instance_id=str(event["target_orbit_id"]),
    )
    rank_by_id = {
        orbit.orbit_instance_id: rank for rank, orbit in enumerate(parent.orbits)
    }
    geometry_free_parent_proxy = SimpleNamespace(
        material_id=parent.material_id,
        target_space_group=parent.target_space_group,
        lattice=parent.lattice,
        orbits=(None,) * len(parent.orbits),
    )
    legal_u = _sample_direct_mdn(
        model,
        geometry_free_parent_proxy,
        state,
        zero_geometry_target,
        rank_by_id,
        device,
    )
    return {
        "candidate_id": f"{event['event_id']}:direct-mdn-k1",
        "candidate_index": -1,
        "legal_u": legal_u,
        "expansion_valid": True,
    }


def _teacher_complete(
    *, parent: Any, target_orbit_id: str, selected_u: Sequence[float], expander: Any
) -> Structure:
    orbits = []
    found = False
    for orbit in parent.orbits:
        if orbit.orbit_instance_id != target_orbit_id:
            orbits.append(orbit)
            continue
        found = True
        orbits.append(
            OrbitState.create(
                parent.target_space_group,
                orbit.wyckoff_letter,
                orbit.species,
                selected_u,
                cell_transform=parent.lattice.cell_transform_values,
                orbit_instance_id=orbit.orbit_instance_id,
            )
        )
    if not found:
        raise RuntimeError(f"teacher-completion target not found: {target_orbit_id}")
    expanded = expander.expand_many(
        orbits,
        parent.lattice.primitive_matrix,
        require_target_space_group=False,
        require_distinct_orbit_instances=False,
    )
    structure = Structure(
        Lattice(parent.lattice.primitive_matrix),
        expanded.atomic_numbers,
        expanded.fractional_coordinates,
        to_unit_cell=True,
    )
    if Counter(expanded.atomic_numbers) != Counter(dict(_composition(parent))):
        raise RuntimeError("teacher-completed composition mismatch")
    if not np.isfinite(np.asarray(structure.frac_coords, dtype=float)).all():
        raise RuntimeError("teacher-completed structure is nonfinite")
    return structure


def _parent_oracle(parent: Any, expander: Any) -> Structure:
    expanded = expander.expand_many(
        parent.orbits,
        parent.lattice.primitive_matrix,
        require_target_space_group=False,
        require_distinct_orbit_instances=False,
    )
    return Structure(
        Lattice(parent.lattice.primitive_matrix),
        expanded.atomic_numbers,
        expanded.fractional_coordinates,
        to_unit_cell=True,
    )


def _chgnet_force_records(
    model: Any, records: list[dict[str, object]], started: float
) -> None:
    pending = [record for record in records if record["structure"] is not None]
    for start in range(0, len(pending), 16):
        _deadline(started, "CHGNet evaluation")
        batch = pending[start : start + 16]
        try:
            raw = model.predict_structure(
                [record["structure"] for record in batch], task="ef", batch_size=16
            )
            outputs = raw if isinstance(raw, list) else [raw]
            if len(outputs) != len(batch):
                raise RuntimeError("CHGNet batch output count mismatch")
        except Exception as error:
            reason = f"{type(error).__name__}:{error}"
            for record in batch:
                record["chgnet_status"] = "FAILED"
                record["failure_reason"] = reason
            continue
        for record, output in zip(batch, outputs, strict=True):
            force = output["f"]
            if hasattr(force, "detach"):
                force = force.detach().cpu()
            array = np.asarray(force, dtype=float)
            maximum = float(np.linalg.norm(array, axis=-1).max())
            if math.isfinite(maximum) and maximum >= 0.0:
                record["chgnet_status"] = "EVALUATED"
                record["force"] = maximum
            else:
                record["chgnet_status"] = "FAILED"
                record["failure_reason"] = "NONFINITE_FORCE"
        print(
            json.dumps(
                {
                    "phase": "CHGNET",
                    "completed": min(start + 16, len(pending)),
                    "total": len(pending),
                },
                sort_keys=True,
            ),
            flush=True,
        )


def _summary_and_verdict(
    event_rows: list[dict[str, object]],
) -> tuple[list[dict[str, object]], dict[str, Any]]:
    result_rows: list[dict[str, object]] = []
    comparisons: dict[tuple[str, str], dict[str, Any]] = {}
    for stage_index, stage in enumerate(STAGE_TARGETS):
        stage_rows = [row for row in event_rows if row["stage"] == stage]
        for arm in ARMS:
            finite = [
                float(row[f"{arm.lower()}_force"])
                for row in stage_rows
                if row[f"{arm.lower()}_status"] == "EVALUATED"
            ]
            result_rows.append(
                {
                    "schema_version": SCHEMA_VERSION,
                    "row_type": "ARM_SUMMARY",
                    "stage": stage,
                    "arm": arm,
                    "event_n": len(stage_rows),
                    "finite_n": len(finite),
                    "finite_rate": len(finite) / len(stage_rows),
                    "force_median": float(np.median(finite)) if finite else None,
                    "force_p90": float(np.percentile(finite, 90)) if finite else None,
                }
            )
        for baseline_index, baseline in enumerate(BASELINES):
            paired = [
                (
                    float(row["mlp_force"]),
                    float(row[f"{baseline.lower()}_force"]),
                )
                for row in stage_rows
                if row["mlp_status"] == "EVALUATED"
                and row[f"{baseline.lower()}_status"] == "EVALUATED"
            ]
            if not paired:
                raise RuntimeError(f"no common-finite {stage} MLP-{baseline} pairs")
            comparison = paired_force_comparison(
                np.asarray([value[0] for value in paired]),
                np.asarray([value[1] for value in paired]),
                seed=20260902 + stage_index * 10 + baseline_index,
            )
            comparisons[(stage, baseline)] = dict(comparison)
            result_rows.append(
                {
                    "schema_version": SCHEMA_VERSION,
                    "row_type": "PAIRED_COMPARISON",
                    "stage": stage,
                    "arm": "MLP",
                    "baseline": baseline,
                    **comparison,
                }
            )
    verdict = generalization_verdict(
        random_by_stage={
            stage: comparisons[(stage, "RANDOM")] for stage in STAGE_TARGETS
        },
        direct_by_stage={
            stage: comparisons[(stage, "DIRECT_MDN")] for stage in STAGE_TARGETS
        },
    )
    return result_rows, {"comparisons": comparisons, **verdict}


def _csv_value(value: object) -> object:
    if value is None:
        return ""
    if isinstance(value, (tuple, list, dict)):
        return json.dumps(value, sort_keys=True, separators=(",", ":"))
    return value


def _write_csv_new(path: Path, rows: Sequence[Mapping[str, object]]) -> None:
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("x", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: _csv_value(row.get(key)) for key in fieldnames})


def _fmt(value: float) -> str:
    return f"{float(value):.12f}"


def _render_verdict(
    event_rows: list[dict[str, object]],
    result_rows: list[dict[str, object]],
    verdict: Mapping[str, Any],
    preview: Mapping[str, Any],
    normalization: Mapping[str, Any],
    total_minutes: float,
) -> str:
    arms = {
        (row["stage"], row["arm"]): row
        for row in result_rows
        if row["row_type"] == "ARM_SUMMARY"
    }
    comparison = verdict["comparisons"]
    oracle = {
        stage: float(
            np.median(
                [
                    float(row["parent_oracle_force"])
                    for row in event_rows
                    if row["stage"] == stage
                    and row["parent_oracle_status"] == "EVALUATED"
                ]
            )
        )
        for stage in STAGE_TARGETS
    }
    stage_lines = []
    for stage in STAGE_TARGETS:
        stage_lines.extend(
            [
                f"- {stage} MLP/Random/Contact/Direct-MDN finite rates: "
                f"{_fmt(arms[(stage, 'MLP')]['finite_rate'])} / "
                f"{_fmt(arms[(stage, 'RANDOM')]['finite_rate'])} / "
                f"{_fmt(arms[(stage, 'CONTACT')]['finite_rate'])} / "
                f"{_fmt(arms[(stage, 'DIRECT_MDN')]['finite_rate'])}.",
                f"- {stage} MLP/Random/Contact/Direct-MDN median forces: "
                f"{_fmt(arms[(stage, 'MLP')]['force_median'])} / "
                f"{_fmt(arms[(stage, 'RANDOM')]['force_median'])} / "
                f"{_fmt(arms[(stage, 'CONTACT')]['force_median'])} / "
                f"{_fmt(arms[(stage, 'DIRECT_MDN')]['force_median'])} eV/A.",
                f"- {stage} MLP/Random/Contact/Direct-MDN p90 forces: "
                f"{_fmt(arms[(stage, 'MLP')]['force_p90'])} / "
                f"{_fmt(arms[(stage, 'RANDOM')]['force_p90'])} / "
                f"{_fmt(arms[(stage, 'CONTACT')]['force_p90'])} / "
                f"{_fmt(arms[(stage, 'DIRECT_MDN')]['force_p90'])} eV/A.",
            ]
        )
    comparison_lines = []
    for stage in STAGE_TARGETS:
        for baseline in BASELINES:
            row = comparison[(stage, baseline)]
            comparison_lines.append(
                f"- {stage} MLP vs {baseline}: N={row['pair_n']}, mean log1p delta "
                f"{_fmt(row['mean_delta'])}, CI95 [{_fmt(row['ci_lower'])}, "
                f"{_fmt(row['ci_upper'])}], win rate {_fmt(row['win_rate'])}."
            )
    return f"""# CRYSALIS Compatibility Assembly-Depth Generalization Verdict

CRYSALIS_COMPATIBILITY_ASSEMBLY_DEPTH_GENERALIZATION = COMPLETE

## Frozen protocol ledger

- 32 development parents were selected structurally after excluding the 64 operator-training and 159 repeated-diagnostic parents.
- Each event teacher-forced the exact canonical state and next orbit action. The 24-candidate MLP/Random/Contact set used the frozen shifted-Halton torus; Direct-MDN used its frozen K=1 sampler.
- The exact saved 16-feature schema, normalization, and 18,817-parameter checkpoint passed reload sanity with maximum absolute error {_fmt(normalization['reload_sanity_max_abs_error'])}.
- Candidate selection completed before teacher completion. Future parent orbit geometry was unavailable to MLP, Random, Contact, and the geometry-free Direct-MDN parent proxy.
- CHGNet 0.3.0 single-point forces were evaluated only on complete counterfactual crystals. No relaxation, retry, refill, training, architecture, feature, or hyperparameter change occurred.

## Stage physical summaries

{chr(10).join(stage_lines)}

## Event-paired comparisons

{chr(10).join(comparison_lines)}

## Registered verdict

- `EARLY_SIGNAL = {verdict['stage_signal']['EARLY']}`
- `MID_SIGNAL = {verdict['stage_signal']['MID']}`
- `LATE_SIGNAL = {verdict['stage_signal']['LATE']}`
- `ASSEMBLY_DEPTH_GENERALIZATION = {verdict['assembly_depth_generalization']}`
- `COMPATIBILITY_BEATS_DIRECT_MDN = {verdict['compatibility_beats_direct_mdn']}`
- `PARENT_ORACLE_FORCE_EARLY = {_fmt(oracle['EARLY'])}`
- `PARENT_ORACLE_FORCE_MID = {_fmt(oracle['MID'])}`
- `PARENT_ORACLE_FORCE_LATE = {_fmt(oracle['LATE'])}`
- `FUTURE_PARENT_INFORMATION_USED_FOR_SELECTION = false`
- `NEW_MODEL_TRAINING_RUNS = 0`
- `TOTAL_WALL_CLOCK_MINUTES = {_fmt(total_minutes)}`
- `NEXT_ACTION = {verdict['next_action']}`
"""


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--recovered-parents", type=Path, required=True)
    parser.add_argument("--state-graph", type=Path, required=True)
    parser.add_argument("--development-split", type=Path, required=True)
    parser.add_argument("--training-events", type=Path, required=True)
    parser.add_argument("--training-candidates", type=Path, required=True)
    parser.add_argument("--diagnostic-ids", type=Path, required=True)
    parser.add_argument("--frozen-operator", type=Path, required=True)
    parser.add_argument("--direct-mdn-checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    parser.add_argument("--preflight-only", action="store_true")
    return parser.parse_args()


def main() -> None:
    started = time.monotonic()
    args = _parse_args()
    if args.output.exists():
        raise FileExistsError(f"output already exists: {args.output}")
    recovered, events, preview = _preflight_cohort(args)
    _deadline(started, "cohort preflight")
    print(json.dumps({"phase": "PREFLIGHT", **preview}, sort_keys=True), flush=True)
    if args.preflight_only:
        return

    mlp, normalization = _load_frozen_mlp(
        args.frozen_operator, args.training_candidates
    )
    mdn = load_final_model(args.direct_mdn_checkpoint, device=args.device)
    expander = SpaceGroupConditionedWyckoffExpander()
    event_rows: list[dict[str, object]] = []
    force_records: list[dict[str, object]] = []
    for event_index, event in enumerate(events):
        _deadline(started, "candidate selection")
        parent = recovered[str(event["parent_id"])]
        state = _partial_state(parent, event)
        candidates, selected = _selection_candidates(
            event=event,
            parent=parent,
            state=state,
            expander=expander,
            mlp=mlp,
            normalization=normalization,
        )
        selected["DIRECT_MDN"] = _direct_mdn_selection(
            model=mdn,
            parent=parent,
            state=state,
            event=event,
            device=args.device,
        )
        event_row: dict[str, object] = {
            "schema_version": SCHEMA_VERSION,
            **event,
            "registered_candidate_n": len(candidates),
            "expansion_valid_candidate_n": sum(
                bool(row["expansion_valid"]) for row in candidates
            ),
            "future_parent_information_used_for_selection": False,
            "new_model_training_runs": 0,
        }
        for arm in ARMS:
            choice = selected[arm]
            event_row[f"{arm.lower()}_candidate_id"] = choice["candidate_id"]
            event_row[f"{arm.lower()}_selected_u"] = choice["legal_u"]
            event_row[f"{arm.lower()}_status"] = "PENDING"
            event_row[f"{arm.lower()}_force"] = None
            if arm in {"RANDOM", "CONTACT", "MLP"}:
                event_row[f"{arm.lower()}_contact_score"] = choice[
                    "static_full_orbit_contact_score"
                ]
                event_row[f"{arm.lower()}_mlp_predicted_log1p_force"] = choice[
                    "mlp_predicted_log1p_force"
                ]
            try:
                structure = _teacher_complete(
                    parent=parent,
                    target_orbit_id=str(event["target_orbit_id"]),
                    selected_u=choice["legal_u"],
                    expander=expander,
                )
                status = "PENDING"
                reason = None
            except (ValueError, WyckoffExpansionError, RuntimeError) as error:
                structure = None
                status = "FAILED"
                reason = f"{type(error).__name__}:{error}"
            force_records.append(
                {
                    "record_type": "ARM",
                    "event_row": event_row,
                    "arm": arm,
                    "structure": structure,
                    "chgnet_status": status,
                    "failure_reason": reason,
                    "force": None,
                }
            )
        event_rows.append(event_row)
        if (event_index + 1) % 8 == 0:
            print(
                json.dumps(
                    {
                        "phase": "SELECTION",
                        "completed": event_index + 1,
                        "total": len(events),
                    },
                    sort_keys=True,
                ),
                flush=True,
            )
    del mdn
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    oracle_records: dict[str, dict[str, object]] = {}
    for parent_id in sorted({str(event["parent_id"]) for event in events}):
        oracle_records[parent_id] = {
            "record_type": "ORACLE",
            "parent_id": parent_id,
            "structure": _parent_oracle(recovered[parent_id], expander),
            "chgnet_status": "PENDING",
            "failure_reason": None,
            "force": None,
        }
    all_force_records = [*force_records, *oracle_records.values()]
    chgnet = _load_chgnet(args.device)
    _chgnet_force_records(chgnet, all_force_records, started)
    del chgnet
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    for record in force_records:
        event_row = record["event_row"]
        arm = str(record["arm"]).lower()
        event_row[f"{arm}_status"] = record["chgnet_status"]
        event_row[f"{arm}_force"] = record["force"]
        event_row[f"{arm}_failure_reason"] = record["failure_reason"]
    for event_row in event_rows:
        oracle_record = oracle_records[str(event_row["parent_id"])]
        event_row["parent_oracle_status"] = oracle_record["chgnet_status"]
        event_row["parent_oracle_force"] = oracle_record["force"]
        event_row["parent_oracle_failure_reason"] = oracle_record["failure_reason"]

    result_rows, verdict = _summary_and_verdict(event_rows)
    total_minutes = (time.monotonic() - started) / 60.0
    if total_minutes > MAX_WALL_CLOCK_MINUTES:
        raise TimeoutError("aggregation exceeded the registered 20-minute deadline")
    result_rows.append(
        {
            "schema_version": SCHEMA_VERSION,
            "row_type": "VERDICT",
            "assembly_depth_generalization": verdict["assembly_depth_generalization"],
            "compatibility_beats_direct_mdn": verdict["compatibility_beats_direct_mdn"],
            "early_signal": verdict["stage_signal"]["EARLY"],
            "mid_signal": verdict["stage_signal"]["MID"],
            "late_signal": verdict["stage_signal"]["LATE"],
            "future_parent_information_used_for_selection": False,
            "new_model_training_runs": 0,
            "total_wall_clock_minutes": total_minutes,
            "next_action": verdict["next_action"],
        }
    )
    args.output.mkdir(parents=True, exist_ok=False)
    _write_csv_new(args.output / "ASSEMBLY_DEPTH_GENERALIZATION_EVENTS.csv", event_rows)
    _write_csv_new(
        args.output / "ASSEMBLY_DEPTH_GENERALIZATION_RESULTS.csv", result_rows
    )
    verdict_text = _render_verdict(
        event_rows,
        result_rows,
        verdict,
        preview,
        normalization,
        total_minutes,
    )
    (args.output / "CRYSALIS_ASSEMBLY_DEPTH_GENERALIZATION_VERDICT.md").write_text(
        verdict_text, encoding="utf-8", newline="\n"
    )
    print(
        json.dumps(
            {
                "phase": "COMPLETE",
                "output": str(args.output),
                "preview": preview,
                "verdict": {
                    key: value for key, value in verdict.items() if key != "comparisons"
                },
                "total_wall_clock_minutes": total_minutes,
            },
            sort_keys=True,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
