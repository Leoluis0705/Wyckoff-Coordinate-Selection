from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

import numpy as np
import torch

from crysalis_g1.experiments.c0_symmetry_oracle import load_recovered_parents
from crysalis_g1.experiments.orbit_inverse_policy import OrbitInversePolicy, OrbitPolicyBatch
from crysalis_g1.geometry_mdn.evaluation import (
    _parent_structure,
    _receipt_structure,
    _structure_metrics,
    add_chgnet_initial_forces,
)
from crysalis_g1.geometry_mdn.model import GeometryMDNBatch
from crysalis_g1.geometry_mdn.sampling import registered_mdn_samples_with_components
from crysalis_g1.symmetry.assembly import (
    AddOrbitAction,
    C0SymmetryProjector,
    SpaceGroupLegalActionCompiler,
    SymmetryAssemblyState,
)
from crysalis_g1.symmetry.wyckoff import OrbitState, orbit_representative_fractional_coordinate


SEED = 20260823
MAX_ORBITS = 8


def _read_jsonl(path: Path):
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            if line.strip():
                yield json.loads(line)


def _wyckoff(letter: str) -> int:
    return ord(letter.lower()) - ord("a")


def _action_key(orbit: OrbitState):
    return (orbit.wyckoff_letter, orbit.species, orbit.multiplicity, len(orbit.free_parameters))


def _legal_key(action):
    return (action.wyckoff_letter, action.species, action.multiplicity, action.free_parameter_count)


def _composition(parent) -> tuple[tuple[int, int], ...]:
    values = Counter()
    for orbit in parent.orbits:
        values[orbit.species] += orbit.multiplicity
    return tuple(sorted(values.items()))


def _policy_batch(parent, state, candidates: tuple[OrbitState, ...]) -> OrbitPolicyBatch:
    composition = torch.zeros(1, 119)
    remaining = torch.zeros(1, 119)
    total = sum(count for _, count in state.composition)
    for species, count in state.composition:
        composition[0, species] = count / total
    for species, count in state.remaining_composition:
        remaining[0, species] = count / total
    active_species = torch.zeros(1, MAX_ORBITS, dtype=torch.long)
    active_wyckoff = torch.zeros(1, MAX_ORBITS, dtype=torch.long)
    active_multiplicity = torch.zeros(1, MAX_ORBITS)
    active_dof = torch.zeros(1, MAX_ORBITS, dtype=torch.long)
    active_free = torch.zeros(1, MAX_ORBITS, 3)
    active_representative = torch.zeros(1, MAX_ORBITS, 3)
    active_mask = torch.zeros(1, MAX_ORBITS, dtype=torch.bool)
    for index, orbit in enumerate(state.orbits):
        active_species[0, index] = orbit.species
        active_wyckoff[0, index] = _wyckoff(orbit.wyckoff_letter)
        active_multiplicity[0, index] = orbit.multiplicity / 20.0
        active_dof[0, index] = len(orbit.free_parameters)
        active_free[0, index, : len(orbit.free_parameters)] = torch.tensor(orbit.free_parameters)
        active_representative[0, index] = torch.tensor(orbit_representative_fractional_coordinate(orbit))
        active_mask[0, index] = True
    count = len(candidates)
    candidate_species = torch.zeros(1, count, dtype=torch.long)
    candidate_wyckoff = torch.zeros(1, count, dtype=torch.long)
    candidate_multiplicity = torch.zeros(1, count)
    candidate_dof = torch.zeros(1, count, dtype=torch.long)
    feasibility = torch.zeros(1, count, 3)
    remaining_counter = Counter(dict(state.remaining_composition))
    for index, orbit in enumerate(candidates):
        candidate_species[0, index] = orbit.species
        candidate_wyckoff[0, index] = _wyckoff(orbit.wyckoff_letter)
        candidate_multiplicity[0, index] = orbit.multiplicity / 20.0
        candidate_dof[0, index] = len(orbit.free_parameters)
        count_for_species = remaining_counter[orbit.species]
        feasibility[0, index] = torch.tensor(
            [count_for_species / 20.0, state.site_count / 20.0, (count_for_species - orbit.multiplicity) / 20.0]
        )
    return OrbitPolicyBatch(
        composition=composition,
        remaining_composition=remaining,
        target_sg=torch.tensor([parent.target_space_group]),
        lattice=torch.tensor(parent.lattice.primitive_matrix, dtype=torch.float32).reshape(1, 9) / 10.0,
        progress=torch.tensor([[len(state.orbits) / len(parent.orbits)]], dtype=torch.float32),
        active_species=active_species,
        active_wyckoff=active_wyckoff,
        active_multiplicity=active_multiplicity,
        active_dof=active_dof,
        active_free_parameters=active_free,
        active_representative=active_representative,
        active_mask=active_mask,
        candidate_species=candidate_species,
        candidate_wyckoff=candidate_wyckoff,
        candidate_multiplicity=candidate_multiplicity,
        candidate_dof=candidate_dof,
        candidate_feasibility=feasibility,
        legal_mask=torch.ones(1, count, dtype=torch.bool),
        positive_mask=torch.ones(1, count, dtype=torch.bool),
    )


def _mdn_batch(parent, state, candidate: OrbitState, rank_by_id: dict[str, int]) -> GeometryMDNBatch:
    composition = torch.zeros(1, 119)
    total = sum(count for _, count in state.composition)
    for species, count in state.composition:
        composition[0, species] = count / total
    active_species = torch.zeros(1, MAX_ORBITS, dtype=torch.long)
    active_wyckoff = torch.zeros(1, MAX_ORBITS, dtype=torch.long)
    active_multiplicity = torch.zeros(1, MAX_ORBITS)
    active_dof = torch.zeros(1, MAX_ORBITS, dtype=torch.long)
    active_rank = torch.zeros(1, MAX_ORBITS, dtype=torch.long)
    active_free = torch.zeros(1, MAX_ORBITS, 3)
    active_mask = torch.zeros(1, MAX_ORBITS, dtype=torch.bool)
    ordered_active = sorted(state.orbits, key=lambda item: rank_by_id[item.orbit_instance_id])
    for index, orbit in enumerate(ordered_active):
        active_species[0, index] = orbit.species
        active_wyckoff[0, index] = _wyckoff(orbit.wyckoff_letter)
        active_multiplicity[0, index] = orbit.multiplicity / 12.0
        active_dof[0, index] = len(orbit.free_parameters)
        active_rank[0, index] = rank_by_id[orbit.orbit_instance_id]
        active_free[0, index, : len(orbit.free_parameters)] = torch.tensor(orbit.free_parameters)
        active_mask[0, index] = True
    active_ids = {orbit.orbit_instance_id for orbit in state.orbits}
    removed = sorted({rank for orbit_id, rank in rank_by_id.items() if orbit_id not in active_ids})[:MAX_ORBITS]
    removed_ranks = torch.zeros(1, MAX_ORBITS, dtype=torch.long)
    removed_mask = torch.zeros(1, MAX_ORBITS, dtype=torch.bool)
    removed_ranks[0, : len(removed)] = torch.tensor(removed)
    removed_mask[0, : len(removed)] = True
    free_mask = torch.zeros(1, 3, dtype=torch.bool)
    free_mask[0, : len(candidate.free_parameters)] = True
    return GeometryMDNBatch(
        composition=composition,
        target_sg=torch.tensor([parent.target_space_group]),
        lattice=torch.tensor(parent.lattice.primitive_matrix, dtype=torch.float32).reshape(1, 3, 3) / 10.0,
        active_species=active_species,
        active_wyckoff=active_wyckoff,
        active_multiplicity=active_multiplicity,
        active_dof=active_dof,
        active_rank=active_rank,
        active_free_parameters=active_free,
        active_mask=active_mask,
        candidate_species=torch.tensor([candidate.species]),
        candidate_wyckoff=torch.tensor([_wyckoff(candidate.wyckoff_letter)]),
        candidate_multiplicity=torch.tensor([candidate.multiplicity / 12.0]),
        candidate_dof=torch.tensor([len(candidate.free_parameters)]),
        candidate_rank=torch.tensor([rank_by_id[candidate.orbit_instance_id]]),
        path_index=torch.tensor([0]),
        step_index=torch.tensor([max(0, min(MAX_ORBITS - 1, len(parent.orbits) - len(state.orbits) - 1))]),
        removed_ranks=removed_ranks,
        removed_mask=removed_mask,
        relation_features=torch.zeros(1, MAX_ORBITS, 11),
        relation_mask=torch.zeros(1, MAX_ORBITS, dtype=torch.bool),
        free_dof_mask=free_mask,
    )


def _sample_direct_mdn(model, parent, state, candidate, rank_by_id, device):
    batch = _mdn_batch(parent, state, candidate, rank_by_id).to(device)
    with torch.no_grad():
        output = model(batch)
    samples, _ = registered_mdn_samples_with_components(
        output,
        batch.free_dof_mask,
        root_seed=SEED,
        event_keys=(f"orbit-rollout:{parent.material_id}:{candidate.orbit_instance_id}",),
        sample_count=1,
    )
    return tuple(float(value) for value in samples[0, 0, : len(candidate.free_parameters)])


def _uniform_choice(candidates, parent_id, step):
    seed = int.from_bytes(f"{SEED}:uniform:{parent_id}:{step}".encode(), "little") % (2**32)
    rng = np.random.default_rng(seed)
    return candidates[int(rng.integers(0, len(candidates)))]


def _binary_bootstrap_delta(learned, uniform, seed=SEED, replicates=10_000):
    delta = np.asarray(learned, dtype=float) - np.asarray(uniform, dtype=float)
    rng = np.random.default_rng(seed)
    values = np.empty(replicates)
    for start in range(0, replicates, 1000):
        stop = min(start + 1000, replicates)
        sample = rng.integers(0, len(delta), size=(stop - start, len(delta)))
        values[start:stop] = delta[sample].mean(axis=1)
    return {
        "point": float(delta.mean()),
        "ci95_lower": float(np.quantile(values, 0.025)),
        "ci95_upper": float(np.quantile(values, 0.975)),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase2a-root", type=Path, required=True)
    parser.add_argument("--recovered-parents", type=Path, required=True)
    parser.add_argument("--diagnostic-ids", type=Path, required=True)
    parser.add_argument("--policy-checkpoint", type=Path, required=True)
    parser.add_argument("--mdn-checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    device = torch.device(args.device)
    parents = load_recovered_parents(args.recovered_parents)
    diagnostic_ids = tuple(sorted(json.loads(args.diagnostic_ids.read_text())["parent_ids"]))
    oracle_order = {}
    for row in _read_jsonl(args.phase2a_root / "trajectories/d_orbit.jsonl"):
        if int(row["path_index"]) == 0 and row["parent_structure_id"] in diagnostic_ids:
            oracle_order[str(row["parent_structure_id"])] = tuple(
                str(action["target_id"]) for action in row["inverse_actions"]
            )
    if set(oracle_order) != set(diagnostic_ids):
        raise ValueError("registered oracle path is incomplete")
    policy_payload = torch.load(args.policy_checkpoint, map_location="cpu", weights_only=False)
    policy = OrbitInversePolicy()
    policy.load_state_dict(policy_payload["model"])
    policy.to(device).eval()
    mdn_payload = torch.load(args.mdn_checkpoint, map_location="cpu", weights_only=False)
    from crysalis_g1.geometry_mdn.model import WrappedMixtureDensityDecoder
    mdn = WrappedMixtureDensityDecoder()
    mdn.load_state_dict(mdn_payload["model"])
    mdn.to(device).eval()
    projector = C0SymmetryProjector(minimum_distance=0.5)
    compiler = SpaceGroupLegalActionCompiler(max_sites=20)
    records = []
    structures = {}
    for arm in ("ORACLE_REGISTERED", "UNIFORM_PARENT_RESTRICTED", "LEARNED_PARENT_RESTRICTED"):
        for parent_id in diagnostic_ids:
            parent = parents[parent_id]
            parent_orbit_by_id = {orbit.orbit_instance_id: orbit for orbit in parent.orbits}
            rank_by_id = {orbit_id: rank for rank, orbit_id in enumerate(sorted(parent_orbit_by_id))}
            state = SymmetryAssemblyState.empty(
                target_space_group=parent.target_space_group,
                composition=_composition(parent),
                lattice=parent.lattice,
            )
            remaining_ids = set(parent_orbit_by_id)
            receipt = None
            failure = None
            action_order = []
            for step in range(len(parent.orbits)):
                compiler_legal = {_legal_key(item) for item in compiler.legal_add_actions(state)}
                candidates = tuple(
                    sorted(
                        (parent_orbit_by_id[item] for item in remaining_ids if _action_key(parent_orbit_by_id[item]) in compiler_legal),
                        key=lambda item: item.orbit_instance_id,
                    )
                )
                if not candidates:
                    failure = "NO_LEGAL_ACTION"
                    break
                if arm == "ORACLE_REGISTERED":
                    expected_id = oracle_order[parent_id][step]
                    selected = next((item for item in candidates if item.orbit_instance_id == expected_id), None)
                    if selected is None:
                        failure = "ORACLE_ACTION_NOT_LEGAL"
                        break
                elif arm == "UNIFORM_PARENT_RESTRICTED":
                    selected = _uniform_choice(candidates, parent_id, step)
                else:
                    with torch.no_grad():
                        logits = policy(_policy_batch(parent, state, candidates).to(device))[0]
                    selected = candidates[int(torch.argmax(logits).item())]
                sampled = _sample_direct_mdn(mdn, parent, state, selected, rank_by_id, device)
                proposal = compiler.apply_add(
                    state,
                    AddOrbitAction(selected.wyckoff_letter, selected.species, sampled, selected.orbit_instance_id),
                )
                receipt = projector.project(proposal)
                action_order.append(selected.orbit_instance_id)
                if not receipt.accepted:
                    failure = "PROJECTOR_REJECTED"
                    state = proposal
                    break
                state = proposal
                remaining_ids.remove(selected.orbit_instance_id)
            completed = not remaining_ids and failure is None
            legal_terminal = bool(completed and receipt is not None and compiler.can_terminate(state, receipt))
            candidate_structure = _receipt_structure(receipt) if receipt is not None else None
            metrics = _structure_metrics(_parent_structure(parent), candidate_structure)
            key = f"{arm}:{parent_id}"
            if legal_terminal and candidate_structure is not None:
                structures[key] = candidate_structure
            records.append(
                {
                    "parent_id": key,
                    "source_parent_id": parent_id,
                    "arm": arm,
                    "terminal_completion": completed,
                    "legal": legal_terminal,
                    "completed_steps": len(action_order),
                    "endpoint_rejection": failure == "PROJECTOR_REJECTED",
                    "no_legal_action": failure == "NO_LEGAL_ACTION",
                    "failure": failure,
                    "action_order": action_order,
                    "target_space_group_valid": metrics["detected_space_group"] == parent.target_space_group,
                    "initial_max_force_ev_per_angstrom": None,
                    "chgnet_status": "PENDING" if legal_terminal else "NOT_LEGAL_TERMINAL",
                    **metrics,
                }
            )
    add_chgnet_initial_forces(records, structures, device=args.device, batch_size=16)
    with (args.output / "parent_restricted_records.jsonl").open("w", encoding="utf-8", newline="\n") as stream:
        for row in records:
            stream.write(json.dumps(row, sort_keys=True) + "\n")
    summary = {}
    by_arm = {arm: [row for row in records if row["arm"] == arm] for arm in {row["arm"] for row in records}}
    for arm, rows in by_arm.items():
        forces = [row["initial_max_force_ev_per_angstrom"] for row in rows if row["initial_max_force_ev_per_angstrom"] is not None]
        rmsd = [row["cartesian_rmsd_angstrom"] for row in rows if row["cartesian_rmsd_angstrom"] is not None]
        nn = [row["nearest_neighbor_error_angstrom"] for row in rows if row["nearest_neighbor_error_angstrom"] is not None]
        summary[arm] = {
            "parent_n": len(rows),
            "terminal_completion_count": sum(row["terminal_completion"] for row in rows),
            "legal_terminal_count": sum(row["legal"] for row in rows),
            "mean_completed_steps": float(np.mean([row["completed_steps"] for row in rows])),
            "endpoint_rejection_count": sum(row["endpoint_rejection"] for row in rows),
            "no_legal_action_count": sum(row["no_legal_action"] for row in rows),
            "parent_match_count": sum(row["parent_match"] for row in rows),
            "target_space_group_valid_count": sum(row["target_space_group_valid"] for row in rows),
            "initial_force_median": float(np.median(forces)) if forces else None,
            "initial_force_p90": float(np.quantile(forces, 0.9)) if forces else None,
            "rmsd_median": float(np.median(rmsd)) if rmsd else None,
            "nearest_neighbor_error_median": float(np.median(nn)) if nn else None,
            "short_contact_count": sum("SHORT_CONTACT" in (row.get("failure") or "") for row in rows),
        }
    learned = {row["source_parent_id"]: row for row in by_arm["LEARNED_PARENT_RESTRICTED"]}
    uniform = {row["source_parent_id"]: row for row in by_arm["UNIFORM_PARENT_RESTRICTED"]}
    ids = sorted(learned)
    legal_delta = _binary_bootstrap_delta([learned[key]["legal"] for key in ids], [uniform[key]["legal"] for key in ids])
    match_delta = _binary_bootstrap_delta([learned[key]["parent_match"] for key in ids], [uniform[key]["parent_match"] for key in ids], seed=SEED + 1)
    primary = legal_delta["ci95_lower"] > 0.0 or match_delta["ci95_lower"] > 0.0
    force_not_worse = (
        summary["LEARNED_PARENT_RESTRICTED"]["initial_force_median"] is not None
        and summary["UNIFORM_PARENT_RESTRICTED"]["initial_force_median"] is not None
        and summary["LEARNED_PARENT_RESTRICTED"]["initial_force_median"] <= summary["UNIFORM_PARENT_RESTRICTED"]["initial_force_median"]
    )
    sg_not_worse = summary["LEARNED_PARENT_RESTRICTED"]["target_space_group_valid_count"] >= summary["UNIFORM_PARENT_RESTRICTED"]["target_space_group_valid_count"]
    result = {
        "schema_version": "orbit-order-parent-restricted.1.0.0",
        "development_diagnostic": True,
        "summary": summary,
        "learned_minus_uniform_legal_terminal": legal_delta,
        "learned_minus_uniform_parent_match": match_delta,
        "force_point_estimate_not_worse": force_not_worse,
        "target_sg_not_worse": sg_not_worse,
        "orbit_order_signal": "SUPPORTED" if primary and force_not_worse and sg_not_worse else "NOT_SUPPORTED",
    }
    (args.output / "ORBIT_ORDER_ROLLOUT_RESULTS.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
