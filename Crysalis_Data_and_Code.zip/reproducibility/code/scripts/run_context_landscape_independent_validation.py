from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import time
from collections import Counter, defaultdict
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

import numpy as np
import torch

from crysalis_g1.experiments.assembly_depth_generalization import (
    assemble_depth_event_pool,
)
from crysalis_g1.experiments.c0_symmetry_oracle import load_recovered_parents
from crysalis_g1.experiments.context_conditional_landscape import (
    CONTEXT_FEATURE_NAMES,
    ORBIT_ONLY_FEATURE_NAMES,
    STAGES,
    action_signature,
    build_matched_feature_matrices,
    cross_context_analysis,
    deterministic_parent_folds,
    select_parent_events,
    summarize_landscapes,
)
from crysalis_g1.experiments.context_landscape_external import (
    choose_external_parent_budget,
    external_replication_verdict,
    external_stage_effect,
    nc_landscape_verdict,
    unique_selection_indices,
)
from crysalis_g1.experiments.full_orbit_compatibility import (
    choose_terminal_completion_events,
)
from crysalis_g1.experiments.full_orbit_operator import (
    FullOrbitCompatibilityMLP,
)
from scripts import run_context_conditional_wyckoff_atlas as atlas

SCHEMA_VERSION = "crysalis-context-landscape-independent-validation.1.0.0"
MAX_TOTAL_WALL_CLOCK_MINUTES = 35.0
TARGET_PARENT_N = 128
MINIMUM_PARENT_N = 96
SECOND_MLIP_NAME = "NOT_RUN"


def _deadline(started: float, phase: str) -> None:
    elapsed = (time.monotonic() - started) / 60.0
    if elapsed >= MAX_TOTAL_WALL_CLOCK_MINUTES:
        raise TimeoutError(f"{phase} exceeded the 35-minute deadline")


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _load_frozen_model(
    *,
    checkpoint: Path,
    expected_features: Sequence[str],
    atlas_candidate_rows: Mapping[str, Mapping[str, object]],
    model_kind: str,
) -> dict[str, object]:
    payload = torch.load(checkpoint, map_location="cpu", weights_only=True)
    if list(payload["feature_names"]) != list(expected_features):
        raise RuntimeError(f"{model_kind} frozen feature schema drifted")
    normalization = payload["normalization"]
    required_normalization = {"x_mean", "x_scale", "y_mean", "y_scale"}
    if set(normalization) != required_normalization:
        raise RuntimeError(f"{model_kind} frozen normalization is incomplete")
    model = FullOrbitCompatibilityMLP(
        input_n=int(payload["input_n"]), hidden_n=int(payload["hidden_n"])
    )
    model.load_state_dict(payload["state_dict"])
    model.eval().requires_grad_(False)
    sanity_ids = [str(value) for value in payload["sanity_candidate_ids"]]
    sanity_rows = [atlas_candidate_rows[candidate_id] for candidate_id in sanity_ids]
    orbit_x, context_x = build_matched_feature_matrices(sanity_rows)
    sanity_x = orbit_x if model_kind == "ORBIT_ONLY" else context_x
    actual = atlas._normalized_predict(
        model, sanity_x, normalization, device="cpu"
    )
    expected = np.asarray(payload["sanity_prediction_log1p_force"], dtype=float)
    maximum_error = float(np.max(np.abs(actual - expected)))
    if not np.allclose(actual, expected, atol=1e-7, rtol=0.0):
        raise RuntimeError(
            f"{model_kind} frozen checkpoint reload sanity failed: {maximum_error}"
        )
    return {
        "model": model,
        "normalization": normalization,
        "sha256": _sha256(checkpoint),
        "reload_error": maximum_error,
    }


def _preflight(
    args: argparse.Namespace,
) -> tuple[dict[str, Any], list[dict[str, object]], list[str], dict[str, object]]:
    recovered = load_recovered_parents(args.recovered_parents)
    parent_payloads = {key: value.to_dict() for key, value in recovered.items()}
    graph_rows = atlas._read_jsonl(args.state_graph)
    split_rows = _read_csv(args.development_split)
    if Counter(row["split"] for row in split_rows) != Counter(
        {"policy_train": 6911, "policy_validation": 768, "diagnostic": 159}
    ):
        raise RuntimeError("development split counts drifted")
    diagnostic_ids = {
        row["parent_id"] for row in split_rows if row["split"] == "diagnostic"
    }
    atlas_ids = {row["parent_id"] for row in _read_csv(args.atlas_events)}
    terminal_ids = {
        row["parent_id"] for row in _read_csv(args.terminal_training_events)
    }
    depth_ids = {row["parent_id"] for row in _read_csv(args.assembly_depth_events)}
    if (
        len(diagnostic_ids) != 159
        or len(atlas_ids) != 192
        or len(terminal_ids) != 64
        or len(depth_ids) != 32
    ):
        raise RuntimeError("registered external exclusion counts drifted")
    forbidden = diagnostic_ids | atlas_ids | terminal_ids | depth_ids
    depth_events = assemble_depth_event_pool(
        parent_payloads, graph_rows, forbidden_parent_ids=forbidden
    )
    terminal_events = choose_terminal_completion_events(
        parent_payloads, graph_rows, forbidden_parent_ids=forbidden
    )
    combined = [
        *depth_events,
        *(
            atlas._terminal_event_adapter(
                event, parent_payloads[str(event["parent_id"])]
            )
            for event in terminal_events
        ),
    ]
    chosen = select_parent_events(combined)
    by_parent: dict[str, list[dict[str, object]]] = defaultdict(list)
    for event in chosen:
        by_parent[str(event["parent_id"])].append(event)
    parent_rows = []
    for parent_id, events in by_parent.items():
        parent = parent_payloads[parent_id]
        orbits = list(parent["orbits"])  # type: ignore[arg-type]
        parent_rows.append(
            {
                "parent_id": parent_id,
                "crystal_system": str(parent["lattice"]["crystal_system"]),  # type: ignore[index]
                "element_count": len({int(orbit["species"]) for orbit in orbits}),
                "final_orbit_count": len(orbits),
                "available_free_dof_classes": tuple(
                    sorted({int(event["free_dof"]) for event in events})
                ),
            }
        )
    selected_ids, structural_events = atlas.select_structural_parent_cohort(
        parent_rows, chosen, target_n=TARGET_PARENT_N
    )
    compiler = atlas.SpaceGroupLegalActionCompiler(max_sites=20)
    expander = atlas.SpaceGroupConditionedWyckoffExpander()
    events = [
        event
        for event in structural_events
        if atlas._event_is_officially_legal(
            event, recovered[str(event["parent_id"])], compiler, expander
        )
    ]
    stage_counts = Counter(str(event["stage"]) for event in events)
    overlap = set(selected_ids) & forbidden
    preview = {
        "eligible_parent_n": len(parent_rows),
        "selected_parent_n": len(selected_ids),
        "event_n_128": len(events),
        "stage_counts_128": dict(stage_counts),
        "excluded_atlas_parent_n": len(atlas_ids),
        "excluded_terminal_parent_n": len(terminal_ids),
        "excluded_depth_parent_n": len(depth_ids),
        "excluded_diagnostic_parent_n": len(diagnostic_ids),
        "forbidden_overlap_n": len(overlap),
    }
    if overlap:
        raise RuntimeError("external cohort overlaps a forbidden parent set")
    return recovered, events, selected_ids, preview


def _assign_frozen_predictions(
    *,
    event_records: Sequence[dict[str, object]],
    orbit_model: FullOrbitCompatibilityMLP,
    orbit_normalization: Mapping[str, object],
    context_model: FullOrbitCompatibilityMLP,
    context_normalization: Mapping[str, object],
) -> None:
    eligible = [record for record in event_records if record["structure"] is not None]
    rows = [record["row"] for record in eligible]
    if not rows:
        raise RuntimeError("external event has no finite teacher-completed candidates")
    orbit_x, context_x = build_matched_feature_matrices(rows)
    orbit_prediction = atlas._normalized_predict(
        orbit_model, orbit_x, orbit_normalization, device="cpu"
    )
    context_prediction = atlas._normalized_predict(
        context_model, context_x, context_normalization, device="cpu"
    )
    for row, orbit_value, context_value in zip(
        rows, orbit_prediction, context_prediction, strict=True
    ):
        row["orbit_only_prediction_log1p_force"] = float(orbit_value)
        row["context_prediction_log1p_force"] = float(context_value)
        row["orbit_only_top1"] = False
        row["context_top1"] = False
        row["contact_top1"] = False
        row["fixed_reference_index_12"] = int(row["candidate_index"]) == 12
    orbit_top1 = min(
        rows,
        key=lambda row: (
            float(row["orbit_only_prediction_log1p_force"]),
            int(row["candidate_index"]),
        ),
    )
    context_top1 = min(
        rows,
        key=lambda row: (
            float(row["context_prediction_log1p_force"]),
            int(row["candidate_index"]),
        ),
    )
    contact_top1 = min(
        rows,
        key=lambda row: (
            float(row["static_full_orbit_contact_score"]),
            int(row["candidate_index"]),
        ),
    )
    orbit_top1["orbit_only_top1"] = True
    context_top1["context_top1"] = True
    contact_top1["contact_top1"] = True
    selected_indices = unique_selection_indices(
        context_index=int(context_top1["candidate_index"]),
        orbit_index=int(orbit_top1["candidate_index"]),
        contact_index=int(contact_top1["candidate_index"]),
        reference_index=12,
    )
    for row in rows:
        row["selected_for_independent_mlip"] = int(row["candidate_index"]) in selected_indices
    for record in event_records:
        row = record["row"]
        row["schema_version"] = SCHEMA_VERSION  # type: ignore[index]
        if record["structure"] is None:
            row["orbit_only_prediction_log1p_force"] = None  # type: ignore[index]
            row["context_prediction_log1p_force"] = None  # type: ignore[index]
            row["orbit_only_top1"] = False  # type: ignore[index]
            row["context_top1"] = False  # type: ignore[index]
            row["contact_top1"] = False  # type: ignore[index]
            row["fixed_reference_index_12"] = int(row["candidate_index"]) == 12  # type: ignore[index]
            row["selected_for_independent_mlip"] = False  # type: ignore[index]


def _evaluate_external_predictions(
    candidate_rows: Sequence[Mapping[str, object]], parent_ids: Sequence[str]
) -> dict[str, object]:
    finite = [row for row in candidate_rows if row["chgnet_status"] == "EVALUATED"]
    orbit_prediction = np.asarray(
        [row["orbit_only_prediction_log1p_force"] for row in finite], dtype=float
    )
    context_prediction = np.asarray(
        [row["context_prediction_log1p_force"] for row in finite], dtype=float
    )
    return atlas._evaluate_predictions(
        candidate_rows=finite,
        orbit_prediction=orbit_prediction,
        context_prediction=context_prediction,
        fold_by_parent=deterministic_parent_folds(parent_ids),
    )


def _fmt(value: object) -> str:
    if value is None:
        return "NA"
    number = float(value)
    return f"{number:.12f}" if math.isfinite(number) else "NA"


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--recovered-parents", type=Path, required=True)
    parser.add_argument("--state-graph", type=Path, required=True)
    parser.add_argument("--development-split", type=Path, required=True)
    parser.add_argument("--terminal-training-events", type=Path, required=True)
    parser.add_argument("--assembly-depth-events", type=Path, required=True)
    parser.add_argument("--atlas-events", type=Path, required=True)
    parser.add_argument("--atlas-candidates", type=Path, required=True)
    parser.add_argument("--orbit-checkpoint", type=Path, required=True)
    parser.add_argument("--context-checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    parser.add_argument("--preflight-only", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = _parse_args()
    atlas.ensure_new_output(args.output)
    started = time.monotonic()
    saved_atlas_rows = _read_csv(args.atlas_candidates)
    saved_by_id = {row["candidate_id"]: row for row in saved_atlas_rows}
    orbit_frozen = _load_frozen_model(
        checkpoint=args.orbit_checkpoint,
        expected_features=ORBIT_ONLY_FEATURE_NAMES,
        atlas_candidate_rows=saved_by_id,
        model_kind="ORBIT_ONLY",
    )
    context_frozen = _load_frozen_model(
        checkpoint=args.context_checkpoint,
        expected_features=CONTEXT_FEATURE_NAMES,
        atlas_candidate_rows=saved_by_id,
        model_kind="CONTEXT_CONDITIONAL",
    )
    recovered, events_128, parent_ids_128, preview = _preflight(args)
    preview.update(
        {
            "orbit_checkpoint_sha256": orbit_frozen["sha256"],
            "context_checkpoint_sha256": context_frozen["sha256"],
            "orbit_reload_error": orbit_frozen["reload_error"],
            "context_reload_error": context_frozen["reload_error"],
            "second_mlip_used": SECOND_MLIP_NAME,
            "new_model_training_runs": 0,
        }
    )
    print(json.dumps({"phase": "PREFLIGHT", **preview}, sort_keys=True), flush=True)
    if args.preflight_only:
        return
    if args.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")

    event_counts = {}
    for parent_n in (128, 96):
        ids = set(parent_ids_128[:parent_n])
        event_counts[parent_n] = sum(
            str(event["parent_id"]) in ids for event in events_128
        )
    expander = atlas.SpaceGroupConditionedWyckoffExpander()
    chgnet = atlas._load_chgnet(args.device)
    records: list[dict[str, object]] = []
    for event in events_128[:16]:
        event_records = atlas._candidate_records(
            event=event,
            parent=recovered[str(event["parent_id"])],
            expander=expander,
        )
        _assign_frozen_predictions(
            event_records=event_records,
            orbit_model=orbit_frozen["model"],
            orbit_normalization=orbit_frozen["normalization"],
            context_model=context_frozen["model"],
            context_normalization=context_frozen["normalization"],
        )
        records.extend(event_records)
    atlas._evaluate_chgnet(chgnet, records, started)
    elapsed_at_16 = (time.monotonic() - started) / 60.0
    parent_n = choose_external_parent_budget(
        elapsed_minutes_at_16=elapsed_at_16, event_counts=event_counts
    )
    projected = {
        key: elapsed_at_16 * value / 16.0 for key, value in event_counts.items()
    }
    print(
        json.dumps(
            {
                "phase": "ETA_DECISION",
                "measured_16_event_minutes": elapsed_at_16,
                "projected_total_minutes": projected,
                "retained_parent_n": parent_n,
            },
            sort_keys=True,
        ),
        flush=True,
    )
    retained_parent_ids = parent_ids_128[:parent_n]
    retained_set = set(retained_parent_ids)
    events = [
        event for event in events_128 if str(event["parent_id"]) in retained_set
    ]
    if events[:16] != events_128[:16]:
        raise RuntimeError("nested external ETA cohort invariant failed")
    for block_start in range(16, len(events), 16):
        block_records = []
        for event in events[block_start : block_start + 16]:
            _deadline(started, "external candidate construction")
            event_records = atlas._candidate_records(
                event=event,
                parent=recovered[str(event["parent_id"])],
                expander=expander,
            )
            _assign_frozen_predictions(
                event_records=event_records,
                orbit_model=orbit_frozen["model"],
                orbit_normalization=orbit_frozen["normalization"],
                context_model=context_frozen["model"],
                context_normalization=context_frozen["normalization"],
            )
            block_records.extend(event_records)
        atlas._evaluate_chgnet(chgnet, block_records, started)
        records.extend(block_records)
        print(
            json.dumps(
                {
                    "phase": "EXTERNAL_ATLAS",
                    "completed_event_n": min(block_start + 16, len(events)),
                    "total_event_n": len(events),
                    "elapsed_minutes": (time.monotonic() - started) / 60.0,
                },
                sort_keys=True,
            ),
            flush=True,
        )
    del chgnet
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    candidate_rows = [record["row"] for record in records]
    if len(candidate_rows) != len(events) * atlas.CANDIDATE_N:
        raise RuntimeError("external candidate persistence grain mismatch")
    landscape = summarize_landscapes(events, candidate_rows)
    cross_context = cross_context_analysis(events, candidate_rows)
    evaluation = _evaluate_external_predictions(candidate_rows, retained_parent_ids)
    aggregate = evaluation["aggregate"]
    comparison = evaluation["comparison"]
    stage_summary = evaluation["stage_summary"]
    stage_rows = {
        stage: {
            "ndcg_delta": float(values["context_ndcg5"])
            - float(values["orbit_ndcg5"]),
            "top1_force_delta": float(values["context_top1_force"])
            - float(values["orbit_top1_force"]),
        }
        for stage, values in stage_summary.items()
    }
    nonreverse_stage_n = sum(
        values["ndcg_delta"] >= 0.0 and values["top1_force_delta"] <= 0.0
        for values in stage_rows.values()
    )
    replication = external_replication_verdict(
        orbit_ndcg5=float(aggregate["orbit_only_ndcg5"]),
        context_ndcg5=float(aggregate["context_ndcg5"]),
        orbit_top1_force=float(aggregate["orbit_only_top1_force"]),
        context_top1_force=float(aggregate["context_top1_force"]),
        ci_upper=float(comparison["ci_upper"]),
        nonreverse_stage_n=nonreverse_stage_n,
    )
    stage_effect = external_stage_effect(stage_rows)
    second_value = "NOT_RUN"
    nc = nc_landscape_verdict(replication, second_value)
    event_summary_by_id = {
        str(row["event_id"]): row for row in landscape["event_summaries"]
    }
    event_rows = [
        {
            "schema_version": SCHEMA_VERSION,
            **event,
            **event_summary_by_id[str(event["event_id"])],
            "action_signature": action_signature(event),
            "future_parent_info_used_for_selection": False,
        }
        for event in events
    ]
    _deadline(started, "external aggregation")
    total_minutes = (time.monotonic() - started) / 60.0
    args.output.mkdir(parents=True, exist_ok=False)
    atlas._write_csv_new(
        args.output / "EXTERNAL_WYCKOFF_ATLAS_EVENTS.csv", event_rows
    )
    atlas._write_csv_new(
        args.output / "EXTERNAL_WYCKOFF_ATLAS_CANDIDATES.csv", candidate_rows
    )
    independent_rows = [
        {
            "schema_version": SCHEMA_VERSION,
            "row_type": "STATUS",
            "second_mlip_used": "NOT_RUN",
            "reason": "No already-installed and project-validated independent MLIP was available; no download or deployment was attempted.",
            "pair_n": 0,
            "second_mlip_context_value": "NOT_RUN",
        }
    ]
    atlas._write_csv_new(
        args.output / "INDEPENDENT_MLIP_CONTEXT_RESULTS.csv", independent_rows
    )
    stage_lines = "\n".join(
        f"- {stage}: NDCG delta {_fmt(stage_rows[stage]['ndcg_delta'])}; top1-force delta {_fmt(stage_rows[stage]['top1_force_delta'])} eV/A."
        for stage in STAGES
    )
    replication_text = f"""# External Context Replication

- The external cohort contains {parent_n} parents and excludes all 192 Atlas, 64 full-orbit compatibility, 32 assembly-depth, and 159 diagnostic parents.
- Frozen checkpoint hashes: ORBIT_ONLY `{orbit_frozen['sha256']}`; CONTEXT_CONDITIONAL `{context_frozen['sha256']}`. Both reload sanity errors were zero within 1e-7.
- Every event used the unchanged K=24 shifted-Halton torus and teacher completion only after frozen-model/contact selection. CHGNet 0.3.0 single-point force was the only external-Atlas label; no relaxation, retry, refill, or training occurred.
- External rugged-event rate: {_fmt(landscape['overall_rugged_rate'])}.
- Same-action cross-context Spearman median: {_fmt(cross_context['spearman_median'])} over {cross_context['pair_n']} pairs.
- ORBIT_ONLY / CONTEXT NDCG@5: {_fmt(aggregate['orbit_only_ndcg5'])} / {_fmt(aggregate['context_ndcg5'])}.
- ORBIT_ONLY / CONTEXT / Contact top1 force: {_fmt(aggregate['orbit_only_top1_force'])} / {_fmt(aggregate['context_top1_force'])} / {_fmt(aggregate['contact_top1_force'])} eV/A.
- Context-minus-orbit paired log1p-force CI95: [{_fmt(comparison['ci_lower'])}, {_fmt(comparison['ci_upper'])}].
- Non-reverse stages: {nonreverse_stage_n}/4.

## Stage replication

{stage_lines}

- `EXTERNAL_STAGE_EFFECT = {stage_effect}`
- `EXTERNAL_CONTEXT_REPLICATION = {replication}`
- `NEW_MODEL_TRAINING_RUNS = 0`
"""
    (args.output / "EXTERNAL_CONTEXT_REPLICATION.md").write_text(
        replication_text, encoding="utf-8", newline="\n"
    )
    cross_text = """# Cross-Potential Analysis

`SECOND_MLIP_USED = NOT_RUN`

No already-installed, project-validated independent MLIP was available in the current environment. In accordance with the preregistered boundary, no model was downloaded or deployed, external CHGNet replication was not blocked, and no cross-potential statistic was fabricated.

`SECOND_MLIP_PAIR_N = 0`

`SECOND_MLIP_CONTEXT_VALUE = NOT_RUN`

`CROSS_POTENTIAL_SPEARMAN = NA`
"""
    (args.output / "CROSS_POTENTIAL_ANALYSIS.md").write_text(
        cross_text, encoding="utf-8", newline="\n"
    )
    verdict_text = f"""# CRYSALIS Context Landscape External Verdict

CRYSALIS_CONTEXT_LANDSCAPE_EXTERNAL_VALIDATION = COMPLETE

EXTERNAL_PARENT_N = {parent_n}

EXTERNAL_EVENT_N = {len(events)}

EXTERNAL_RUGGED_RATE = {_fmt(landscape['overall_rugged_rate'])}

EXTERNAL_CROSS_CONTEXT_SPEARMAN = {_fmt(cross_context['spearman_median'])}

ORBIT_ONLY_NDCG5 = {_fmt(aggregate['orbit_only_ndcg5'])}

CONTEXT_NDCG5 = {_fmt(aggregate['context_ndcg5'])}

ORBIT_ONLY_TOP1_FORCE = {_fmt(aggregate['orbit_only_top1_force'])}

CONTEXT_TOP1_FORCE = {_fmt(aggregate['context_top1_force'])}

CONTACT_TOP1_FORCE = {_fmt(aggregate['contact_top1_force'])}

CONTEXT_VS_ORBIT_CI95 = [{_fmt(comparison['ci_lower'])}, {_fmt(comparison['ci_upper'])}]

EXTERNAL_CONTEXT_REPLICATION = {replication}

SECOND_MLIP_USED = NOT_RUN

SECOND_MLIP_PAIR_N = 0

SECOND_MLIP_CONTEXT_FORCE = NA

SECOND_MLIP_ORBIT_ONLY_FORCE = NA

SECOND_MLIP_CONTEXT_CI95 = [NA, NA]

SECOND_MLIP_CONTEXT_VALUE = NOT_RUN

CROSS_POTENTIAL_SPEARMAN = NA

EXTERNAL_STAGE_EFFECT = {stage_effect}

NC_LANDSCAPE_CORE = {nc['nc_landscape_core']}

NEW_MODEL_TRAINING_RUNS = 0

FIRE_RUNS = 0

DFT_RUNS = 0

TOTAL_WALL_CLOCK_MINUTES = {total_minutes:.12f}

NEXT_ACTION = {nc['next_action']}
"""
    (args.output / "CRYSALIS_CONTEXT_LANDSCAPE_EXTERNAL_VERDICT.md").write_text(
        verdict_text, encoding="utf-8", newline="\n"
    )
    print(
        json.dumps(
            {
                "phase": "COMPLETE",
                "external_parent_n": parent_n,
                "external_event_n": len(events),
                "replication": replication,
                "second_mlip": second_value,
                "nc_landscape_core": nc["nc_landscape_core"],
                "total_wall_clock_minutes": total_minutes,
            },
            sort_keys=True,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
