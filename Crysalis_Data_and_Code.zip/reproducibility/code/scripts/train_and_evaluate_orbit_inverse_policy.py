from __future__ import annotations

import argparse
import json
import math
import os
import time
from collections import Counter
from pathlib import Path

import numpy as np
import torch

from crysalis_g1.experiments.c0_symmetry_oracle import load_recovered_parents
from crysalis_g1.experiments.orbit_inverse_policy import (
    OrbitInversePolicy,
    OrbitPolicyBatch,
    set_marginal_nll,
)
from crysalis_g1.geometry_mdn.training import build_batch_schedule, seed_everything
from crysalis_g1.symmetry.wyckoff import orbit_representative_fractional_coordinate


SEED = 20260823
MAX_UPDATES = 1500
BATCH_SIZE = 128
VALIDATION_INTERVAL = 100
LEARNING_RATE = 3.0e-4
WEIGHT_DECAY = 1.0e-5
GRADIENT_CLIP = 1.0
MAX_ORBITS = 8
MAX_ACTIONS = 38


def _read_jsonl(path: Path):
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            if line.strip():
                yield json.loads(line)


def _wyckoff_index(letter: str) -> int:
    return ord(letter.lower()) - ord("a")


def _allocate(count: int) -> dict[str, np.ndarray]:
    return {
        "composition": np.zeros((count, 119), np.float32),
        "remaining_composition": np.zeros((count, 119), np.float32),
        "target_sg": np.zeros(count, np.int64),
        "lattice": np.zeros((count, 9), np.float32),
        "progress": np.zeros((count, 1), np.float32),
        "active_species": np.zeros((count, MAX_ORBITS), np.int64),
        "active_wyckoff": np.zeros((count, MAX_ORBITS), np.int64),
        "active_multiplicity": np.zeros((count, MAX_ORBITS), np.float32),
        "active_dof": np.zeros((count, MAX_ORBITS), np.int64),
        "active_free_parameters": np.zeros((count, MAX_ORBITS, 3), np.float32),
        "active_representative": np.zeros((count, MAX_ORBITS, 3), np.float32),
        "active_mask": np.zeros((count, MAX_ORBITS), bool),
        "candidate_species": np.zeros((count, MAX_ACTIONS), np.int64),
        "candidate_wyckoff": np.zeros((count, MAX_ACTIONS), np.int64),
        "candidate_multiplicity": np.zeros((count, MAX_ACTIONS), np.float32),
        "candidate_dof": np.zeros((count, MAX_ACTIONS), np.int64),
        "candidate_feasibility": np.zeros((count, MAX_ACTIONS, 3), np.float32),
        "legal_mask": np.zeros((count, MAX_ACTIONS), bool),
        "positive_mask": np.zeros((count, MAX_ACTIONS), bool),
    }


def _pack(graph_path: Path, recovered_path: Path):
    rows = list(_read_jsonl(graph_path))
    parents = load_recovered_parents(recovered_path)
    values = _allocate(len(rows))
    split_names = []
    parent_ids = []
    for index, row in enumerate(rows):
        parent_id = str(row["parent_id"])
        parent = parents[parent_id]
        orbit_by_id = {orbit.orbit_instance_id: orbit for orbit in parent.orbits}
        composition = Counter()
        for orbit in parent.orbits:
            composition[orbit.species] += orbit.multiplicity
        total_atoms = sum(composition.values())
        remaining = composition.copy()
        active_ids = tuple(str(item) for item in row["active_orbit_ids"])
        for orbit_index, orbit_id in enumerate(active_ids):
            orbit = orbit_by_id[orbit_id]
            remaining[orbit.species] -= orbit.multiplicity
            if remaining[orbit.species] == 0:
                del remaining[orbit.species]
            values["active_species"][index, orbit_index] = orbit.species
            values["active_wyckoff"][index, orbit_index] = _wyckoff_index(orbit.wyckoff_letter)
            values["active_multiplicity"][index, orbit_index] = orbit.multiplicity / 20.0
            values["active_dof"][index, orbit_index] = len(orbit.free_parameters)
            values["active_free_parameters"][index, orbit_index, : len(orbit.free_parameters)] = orbit.free_parameters
            values["active_representative"][index, orbit_index] = orbit_representative_fractional_coordinate(orbit)
            values["active_mask"][index, orbit_index] = True
        for species, count in composition.items():
            values["composition"][index, species] = count / total_atoms
        for species, count in remaining.items():
            values["remaining_composition"][index, species] = count / total_atoms
        values["target_sg"][index] = parent.target_space_group
        values["lattice"][index] = np.asarray(parent.lattice.primitive_matrix, dtype=np.float32).reshape(9) / 10.0
        values["progress"][index, 0] = len(active_ids) / len(parent.orbits)
        positives = {tuple(item) for item in row["positive_action_keys"]}
        legal = [tuple(item) for item in row["legal_action_keys"]]
        if len(legal) > MAX_ACTIONS:
            raise ValueError("legal action count exceeds frozen maximum")
        site_count = sum(orbit_by_id[item].multiplicity for item in active_ids)
        for action_index, (letter, species, multiplicity, dof) in enumerate(legal):
            species = int(species)
            multiplicity = int(multiplicity)
            values["candidate_species"][index, action_index] = species
            values["candidate_wyckoff"][index, action_index] = _wyckoff_index(str(letter))
            values["candidate_multiplicity"][index, action_index] = multiplicity / 20.0
            values["candidate_dof"][index, action_index] = int(dof)
            remaining_count = remaining[species]
            values["candidate_feasibility"][index, action_index] = (
                remaining_count / 20.0,
                site_count / 20.0,
                (remaining_count - multiplicity) / 20.0,
            )
            values["legal_mask"][index, action_index] = True
            values["positive_mask"][index, action_index] = (
                str(letter), species, multiplicity, int(dof)
            ) in positives
        if not values["positive_mask"][index].any():
            raise ValueError("packed state has no positive compiler action")
        split_names.append(str(row["split"]))
        parent_ids.append(parent_id)
    tensors = {name: torch.from_numpy(array) for name, array in values.items()}
    return tensors, tuple(split_names), tuple(parent_ids)


def _batch(tensors: dict[str, torch.Tensor], indices: torch.Tensor) -> OrbitPolicyBatch:
    return OrbitPolicyBatch(**{name: tensor.index_select(0, indices) for name, tensor in tensors.items()})


@torch.no_grad()
def _evaluate_nll(model, tensors, indices, device) -> float:
    model.eval()
    total = 0.0
    count = 0
    for start in range(0, len(indices), 512):
        batch = _batch(tensors, indices[start : start + 512]).to(device)
        loss = set_marginal_nll(model(batch), batch.positive_mask, batch.legal_mask)
        total += float(loss) * len(batch.target_sg)
        count += len(batch.target_sg)
    return total / count


@torch.no_grad()
def _diagnostic_records(model, tensors, indices, parent_ids, device):
    model.eval()
    records = []
    for start in range(0, len(indices), 512):
        selected = indices[start : start + 512]
        batch = _batch(tensors, selected).to(device)
        logits = model(batch)
        log_probability = torch.log_softmax(logits, dim=-1)
        probability = log_probability.exp()
        positive_log_mass = torch.logsumexp(
            log_probability.masked_fill(~batch.positive_mask, -torch.inf), dim=-1
        )
        learned_nll = -positive_log_mass
        legal_count = batch.legal_mask.sum(dim=-1)
        positive_count = batch.positive_mask.sum(dim=-1)
        uniform_nll = -torch.log(positive_count / legal_count)
        top1 = batch.positive_mask.gather(1, logits.argmax(dim=-1, keepdim=True)).squeeze(1)
        top3_index = logits.topk(k=min(3, logits.shape[1]), dim=-1).indices
        top3 = batch.positive_mask.gather(1, top3_index).any(dim=-1)
        entropy = -(probability * log_probability.nan_to_num()).sum(dim=-1)
        order = logits.argsort(dim=-1, descending=True)
        ranked_positive = batch.positive_mask.gather(1, order)
        best_rank = ranked_positive.to(torch.int64).argmax(dim=-1) + 1
        positive_mass = probability.masked_fill(~batch.positive_mask, 0.0).sum(dim=-1)
        for local, global_index in enumerate(selected.tolist()):
            records.append(
                {
                    "parent_id": parent_ids[global_index],
                    "state_index": global_index,
                    "learned_set_nll": float(learned_nll[local]),
                    "uniform_set_nll": float(uniform_nll[local]),
                    "positive_set_probability_mass": float(positive_mass[local]),
                    "learned_top1_positive_hit": bool(top1[local]),
                    "uniform_expected_top1_positive_hit": float(positive_count[local] / legal_count[local]),
                    "learned_top3_positive_recall": bool(top3[local]),
                    "best_positive_rank": int(best_rank[local]),
                    "action_entropy": float(entropy[local]),
                    "legal_action_count": int(legal_count[local]),
                    "positive_action_count": int(positive_count[local]),
                }
            )
    return records


def _paired_bootstrap_delta(values: np.ndarray, seed: int, replicates: int = 10_000):
    rng = np.random.default_rng(seed)
    estimates = np.empty(replicates, dtype=np.float64)
    for start in range(0, replicates, 500):
        stop = min(start + 500, replicates)
        sampled = rng.integers(0, len(values), size=(stop - start, len(values)))
        estimates[start:stop] = values[sampled].mean(axis=1)
    return {
        "point": float(values.mean()),
        "ci95_lower": float(np.quantile(estimates, 0.025)),
        "ci95_upper": float(np.quantile(estimates, 0.975)),
        "replicates": replicates,
    }


def _atomic_save(payload, path: Path):
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temporary)
    os.replace(temporary, path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--graph", type=Path, required=True)
    parser.add_argument("--recovered-parents", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    started = time.perf_counter()
    args.output.mkdir(parents=True, exist_ok=True)
    seed_everything(SEED)
    tensors, splits, parent_ids = _pack(args.graph, args.recovered_parents)
    indices = {
        name: torch.tensor([index for index, value in enumerate(splits) if value == name], dtype=torch.long)
        for name in ("policy_train", "policy_validation", "diagnostic")
    }
    schedule = build_batch_schedule(
        indices["policy_train"], updates=MAX_UPDATES, batch_size=BATCH_SIZE, seed=SEED
    )
    device = torch.device(args.device)
    model = OrbitInversePolicy().to(device)
    parameter_count = sum(parameter.numel() for parameter in model.parameters())
    optimizer = torch.optim.AdamW(model.parameters(), lr=LEARNING_RATE, weight_decay=WEIGHT_DECAY)
    best_validation = math.inf
    metrics_path = args.output / "training_metrics.jsonl"
    first_fifty_seconds = None
    for update in range(1, MAX_UPDATES + 1):
        model.train()
        batch = _batch(tensors, schedule[update - 1]).to(device)
        optimizer.zero_grad(set_to_none=True)
        logits = model(batch)
        loss = set_marginal_nll(logits, batch.positive_mask, batch.legal_mask)
        if not torch.isfinite(loss):
            raise FloatingPointError("orbit policy loss is non-finite")
        loss.backward()
        gradient = torch.nn.utils.clip_grad_norm_(model.parameters(), GRADIENT_CLIP)
        if not torch.isfinite(gradient):
            raise FloatingPointError("orbit policy gradient is non-finite")
        optimizer.step()
        validation = None
        if update % VALIDATION_INTERVAL == 0:
            validation = _evaluate_nll(model, tensors, indices["policy_validation"], device)
            if validation < best_validation:
                best_validation = validation
                _atomic_save(
                    {
                        "schema_version": "orbit-inverse-policy.1.0.0",
                        "update": update,
                        "seed": SEED,
                        "model": model.state_dict(),
                        "validation_set_marginal_action_nll": validation,
                        "parameter_count": parameter_count,
                    },
                    args.output / "best_validation_checkpoint.pt",
                )
        elapsed = time.perf_counter() - started
        if update == 50:
            first_fifty_seconds = elapsed
            estimated_training_minutes = elapsed / 50.0 * MAX_UPDATES / 60.0
            if estimated_training_minutes > 45.0:
                raise TimeoutError(
                    f"first-50 estimate {estimated_training_minutes:.3f} minutes exceeds 45"
                )
        with metrics_path.open("a", encoding="utf-8", newline="\n") as stream:
            stream.write(
                json.dumps(
                    {
                        "update": update,
                        "train_set_marginal_action_nll": float(loss),
                        "validation_set_marginal_action_nll": validation,
                        "gradient_norm": float(gradient),
                        "wall_seconds": elapsed,
                    },
                    sort_keys=True,
                )
                + "\n"
            )
    _atomic_save(
        {
            "schema_version": "orbit-inverse-policy.1.0.0",
            "update": MAX_UPDATES,
            "seed": SEED,
            "model": model.state_dict(),
            "validation_set_marginal_action_nll": _evaluate_nll(
                model, tensors, indices["policy_validation"], device
            ),
            "parameter_count": parameter_count,
        },
        args.output / "final_update_1500_checkpoint.pt",
    )
    best = torch.load(args.output / "best_validation_checkpoint.pt", map_location=device, weights_only=False)
    model.load_state_dict(best["model"])
    records = _diagnostic_records(model, tensors, indices["diagnostic"], parent_ids, device)
    with (args.output / "local_action_records.jsonl").open("w", encoding="utf-8", newline="\n") as stream:
        for row in records:
            stream.write(json.dumps(row, sort_keys=True) + "\n")
    learned = np.asarray([row["learned_set_nll"] for row in records])
    uniform = np.asarray([row["uniform_set_nll"] for row in records])
    bootstrap = _paired_bootstrap_delta(learned - uniform, SEED)
    learned_top1 = float(np.mean([row["learned_top1_positive_hit"] for row in records]))
    uniform_top1 = float(np.mean([row["uniform_expected_top1_positive_hit"] for row in records]))
    supported = bootstrap["ci95_upper"] < 0.0 and learned_top1 > uniform_top1
    result = {
        "schema_version": "orbit-inverse-policy-local-results.1.0.0",
        "development_diagnostic": True,
        "parameter_count": parameter_count,
        "best_checkpoint_update": int(best["update"]),
        "best_validation_set_marginal_action_nll": float(best["validation_set_marginal_action_nll"]),
        "first_50_update_seconds": first_fifty_seconds,
        "first_50_estimated_training_minutes": first_fifty_seconds / 50.0 * MAX_UPDATES / 60.0,
        "learned_set_nll": float(learned.mean()),
        "uniform_set_nll": float(uniform.mean()),
        "delta_nll_bootstrap": bootstrap,
        "learned_top1_positive_hit": learned_top1,
        "uniform_expected_top1_positive_hit": uniform_top1,
        "learned_top3_positive_recall": float(np.mean([row["learned_top3_positive_recall"] for row in records])),
        "mean_best_positive_rank": float(np.mean([row["best_positive_rank"] for row in records])),
        "mean_action_entropy": float(np.mean([row["action_entropy"] for row in records])),
        "mean_positive_set_probability_mass": float(np.mean([row["positive_set_probability_mass"] for row in records])),
        "local_action_signal": "SUPPORTED" if supported else "NOT_SUPPORTED",
        "wall_seconds": time.perf_counter() - started,
    }
    (args.output / "ORBIT_INVERSE_POLICY_LOCAL_RESULTS.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
