from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Mapping

import torch
import torch.nn.functional as F
from torch import nn

from crysalis_g1.full_crysalis.config import (
    LOSS_WEIGHTS,
    FullCrysalisConfig,
)
from crysalis_g1.full_crysalis.data import IntegratedBatch
from crysalis_g1.full_crysalis.geometry import (
    GeometryGeneratorConfig,
    RelationConditionedGeometryGenerator,
)
from crysalis_g1.full_crysalis.relation import (
    RelationBackendConfig,
    RelationRestorationOutput,
    SplineKANRelationBackend,
    relation_restoration_loss,
)


@dataclass(frozen=True, slots=True)
class FullCrysalisOutput:
    relation: RelationRestorationOutput
    free_parameters: torch.Tensor
    representative_fractional: torch.Tensor
    representative_delta_cartesian: torch.Tensor
    lattice_degrees: torch.Tensor
    cell_index_logits: torch.Tensor
    termination_logits: torch.Tensor
    physics_prediction: torch.Tensor


class FullCrysalisModel(nn.Module):
    def __init__(
        self,
        *,
        relation_config: RelationBackendConfig,
        geometry_config: GeometryGeneratorConfig,
        loss_weights: Mapping[str, float],
    ) -> None:
        super().__init__()
        weights = {name: float(value) for name, value in loss_weights.items()}
        if weights != LOSS_WEIGHTS:
            raise ValueError("Full Crysalis loss weights must remain frozen")
        if relation_config.latent_dim != geometry_config.relation_latent_dim:
            raise ValueError("relation/geometry latent dimensions disagree")
        self.loss_weights = weights
        self.relation_backend = SplineKANRelationBackend(relation_config)
        self.geometry_generator = RelationConditionedGeometryGenerator(
            geometry_config
        )

    @classmethod
    def from_config(cls, config: FullCrysalisConfig) -> FullCrysalisModel:
        return cls(
            relation_config=RelationBackendConfig(
                numeric_dim=270,
                embedding_dim=config.relation.embedding_dim,
                hidden_dim=config.relation.hidden_dim,
                latent_dim=config.relation.latent_dim,
                grid_size=config.relation.kan_grid_size,
                layer_count=config.relation.kan_layer_count,
            ),
            geometry_config=GeometryGeneratorConfig(
                hidden_dim=config.geometry.hidden_dim,
                block_count=config.geometry.block_count,
                radial_basis_count=config.geometry.radial_basis_count,
                cutoff_angstrom=config.geometry.cutoff_angstrom,
                coordinate_step_scale=config.geometry.coordinate_step_scale,
                maximum_orbits=config.geometry.maximum_orbits,
                maximum_cell_index=config.geometry.maximum_cell_index,
                relation_latent_dim=config.relation.latent_dim,
            ),
            loss_weights=config.loss_weights,
        )

    def forward(self, batch: IntegratedBatch) -> FullCrysalisOutput:
        relation = self.relation_backend(batch)
        geometry = self.geometry_generator(batch, relation)
        return FullCrysalisOutput(
            relation=relation,
            free_parameters=geometry.free_parameters,
            representative_fractional=geometry.representative_fractional,
            representative_delta_cartesian=(
                geometry.representative_delta_cartesian
            ),
            lattice_degrees=geometry.lattice_degrees,
            cell_index_logits=geometry.cell_index_logits,
            termination_logits=geometry.termination_logits,
            physics_prediction=geometry.physics_prediction,
        )


@dataclass(frozen=True, slots=True)
class FullCrysalisLosses:
    total: torch.Tensor
    components: Mapping[str, torch.Tensor]


def _masked_mean(values: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    expanded = mask.to(values.dtype)
    while expanded.ndim < values.ndim:
        expanded = expanded.unsqueeze(-1)
    expanded = expanded.expand_as(values)
    return (values * expanded).sum() / expanded.sum().clamp_min(1.0)


def compute_full_crysalis_losses(
    output: FullCrysalisOutput,
    batch: IntegratedBatch,
    loss_weights: Mapping[str, float],
) -> FullCrysalisLosses:
    weights = {name: float(value) for name, value in loss_weights.items()}
    if weights != LOSS_WEIGHTS:
        raise ValueError("Full Crysalis loss weights must remain frozen")
    relation = relation_restoration_loss(output.relation, batch).total

    circular_difference = output.free_parameters - batch.target_free_parameters
    circular_difference = circular_difference - torch.round(circular_difference)
    free_parameters = _masked_mean(
        circular_difference.square(),
        batch.target_free_parameter_mask & batch.candidate_mask[:, None],
    )

    representative_error = F.smooth_l1_loss(
        output.representative_delta_cartesian,
        batch.target_representative_delta,
        reduction="none",
    )
    representative_geometry = _masked_mean(
        representative_error,
        batch.candidate_mask,
    )

    lattice_regression = F.smooth_l1_loss(
        output.lattice_degrees,
        batch.target_lattice_degrees,
    )
    lattice_classification = F.cross_entropy(
        output.cell_index_logits,
        batch.target_cell_index,
    )
    lattice = lattice_regression + lattice_classification

    physics_regression = F.smooth_l1_loss(
        output.physics_prediction,
        batch.target_physics_feedback,
    )
    if batch.relation_vectors.shape[0]:
        corrected_vectors = (
            batch.relation_vectors
            + output.representative_delta_cartesian[
                batch.relation_event_index
            ]
        )
        candidate_distances = torch.linalg.vector_norm(
            corrected_vectors,
            dim=-1,
        )
        short_contact_hinge = F.relu(0.5 - candidate_distances).square().mean()
    else:
        short_contact_hinge = output.representative_delta_cartesian.sum() * 0.0
    physics_consistency = physics_regression + short_contact_hinge

    termination = F.binary_cross_entropy_with_logits(
        output.termination_logits,
        batch.target_terminate,
    )
    components = {
        "relation": relation,
        "free_parameters": free_parameters,
        "representative_geometry": representative_geometry,
        "lattice": lattice,
        "physics_consistency": physics_consistency,
        "termination": termination,
    }
    total = sum(weights[name] * value for name, value in components.items())
    if any(
        not math.isfinite(float(value.detach()))
        for value in (total, *components.values())
    ):
        raise FloatingPointError("non-finite Full Crysalis loss")
    return FullCrysalisLosses(total=total, components=components)
