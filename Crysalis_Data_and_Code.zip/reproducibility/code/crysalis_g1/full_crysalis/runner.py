from __future__ import annotations

import hashlib
import json
import os
from dataclasses import asdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Mapping

from crysalis_g1.full_crysalis.config import (
    FullCrysalisConfig,
    sha256_file,
    verify_frozen_artifacts,
)
from crysalis_g1.full_crysalis.data import IntegratedCorpus
from crysalis_g1.full_crysalis.evaluation import run_full_evaluation
from crysalis_g1.full_crysalis.generation import run_full_generation
from crysalis_g1.full_crysalis.reporting import (
    REQUIRED_ARTIFACT_NAMES,
    build_final_artifacts,
)
from crysalis_g1.full_crysalis.training import (
    run_engineering_preflight,
    train_full_crysalis,
)


FORMAL_STAGE_ORDER = (
    "audit",
    "preflight",
    "train",
    "generate",
    "evaluate",
    "final",
)


def _canonical_json(payload: object) -> str:
    return json.dumps(
        payload,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def _config_sha256(config: FullCrysalisConfig) -> str:
    return hashlib.sha256(
        _canonical_json(asdict(config)).encode("utf-8")
    ).hexdigest()


def _write_json_new(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(
            payload,
            stream,
            ensure_ascii=False,
            allow_nan=False,
            indent=2,
            sort_keys=True,
        )
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def _receipt_path(root: Path, stage: str) -> Path:
    return root / "engineering" / f"{stage}_complete.json"


def _relative(root: Path, path: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def _verify_receipt(
    config: FullCrysalisConfig,
    stage: str,
) -> dict[str, Any]:
    root = Path(config.output_root)
    path = _receipt_path(root, stage)
    if not path.is_file():
        raise FileNotFoundError(f"prior {stage} stage receipt is missing: {path}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("stage") != stage or payload.get("status") != "COMPLETE":
        raise ValueError(f"invalid {stage} stage receipt")
    if payload.get("config_sha256") != _config_sha256(config):
        raise ValueError(f"{stage} stage receipt config hash drifted")
    outputs = payload.get("output_sha256")
    if not isinstance(outputs, Mapping) or not outputs:
        raise ValueError(f"{stage} stage receipt has no hashed outputs")
    for relative, expected in outputs.items():
        output = root / str(relative)
        if not output.is_file():
            raise FileNotFoundError(
                f"{stage} stage output recorded by receipt is missing: {output}"
            )
        observed = sha256_file(output)
        if observed != expected:
            raise ValueError(
                f"{stage} stage output hash drifted: {relative}: "
                f"expected {expected}, observed {observed}"
            )
    return payload


def _verify_prior_receipts(config: FullCrysalisConfig, stage: str) -> None:
    index = FORMAL_STAGE_ORDER.index(stage)
    for prior in FORMAL_STAGE_ORDER[:index]:
        _verify_receipt(config, prior)


def _write_receipt(
    config: FullCrysalisConfig,
    stage: str,
    outputs: tuple[Path, ...],
) -> dict[str, Any]:
    root = Path(config.output_root)
    missing = [str(path) for path in outputs if not path.is_file()]
    if missing:
        raise RuntimeError(f"{stage} stage outputs are missing: {missing}")
    payload = {
        "schema_version": "g1-full-crysalis-stage-receipt.1.0.0",
        "stage": stage,
        "status": "COMPLETE",
        "completed_at_utc": datetime.now(UTC).isoformat(),
        "config_sha256": _config_sha256(config),
        "output_sha256": {
            _relative(root, path): sha256_file(path) for path in outputs
        },
        "retry_count": 0,
        "refill_count": 0,
        "sealed_or_blind_data_accessed": False,
        "server_used": False,
        "dft_used": False,
        "ablation_performed": False,
        "isolated_scientific_audit_performed": False,
    }
    _write_json_new(_receipt_path(root, stage), payload)
    return payload


def _append_fatal_failure(
    config: FullCrysalisConfig,
    stage: str,
    error: BaseException,
) -> None:
    path = Path(config.output_root) / "engineering" / "runner_failures.jsonl"
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": "g1-full-crysalis-runner-failure.1.0.0",
        "recorded_at_utc": datetime.now(UTC).isoformat(),
        "stage": stage,
        "failure_scope": "FATAL_STAGE_FAILURE",
        "exception_type": type(error).__name__,
        "exception_message": str(error),
        "retry_count": 0,
        "refill_count": 0,
        "sealed_or_blind_data_accessed": False,
        "ablation_performed": False,
    }
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(_canonical_json(payload) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def _run_audit(config: FullCrysalisConfig) -> tuple[Path, ...]:
    root = Path(config.output_root)
    if root.exists():
        raise FileExistsError(f"Full Crysalis audit refuses to overwrite: {root}")
    frozen = verify_frozen_artifacts(config)
    corpus = IntegratedCorpus.from_config(config)
    root.mkdir(parents=True, exist_ok=False)
    audit_path = root / "engineering" / "audit.json"
    _write_json_new(
        audit_path,
        {
            "schema_version": "g1-full-crysalis-audit.1.0.0",
            "status": "PASS",
            "root_seed": config.root_seed,
            "frozen_artifact_sha256": frozen,
            "corpus": dict(corpus.report),
            "public_only": True,
            "sealed_or_blind_data_accessed": False,
            "server_used": False,
            "dft_used": False,
            "retry_count": 0,
            "refill_count": 0,
            "orbit_proposal": "UNIFORM_LEGAL",
            "isolated_scientific_audit_performed": False,
            "ablation_performed": False,
        },
    )
    return (audit_path,)


def _run_preflight(config: FullCrysalisConfig) -> tuple[Path, ...]:
    target = Path(config.output_root) / "engineering" / "preflight.json"
    run_engineering_preflight(config, output_path=target)
    return (target,)


def _run_train(config: FullCrysalisConfig) -> tuple[Path, ...]:
    preflight = json.loads(
        (
            Path(config.output_root) / "engineering" / "preflight.json"
        ).read_text(encoding="utf-8")
    )
    effective_batch_size = int(preflight["cuda"]["effective_batch_size"])
    train_full_crysalis(config, effective_batch_size=effective_batch_size)
    output = Path(config.output_root) / "training"
    return (
        output / "best.pt",
        output / "metrics.jsonl",
        output / "training_report.json",
    )


def _run_generate(config: FullCrysalisConfig) -> tuple[Path, ...]:
    run_full_generation(config)
    output = Path(config.output_root) / "generation"
    return (
        output / "generation_records.json",
        output / "generation_summary.json",
    )


def _run_evaluate(config: FullCrysalisConfig) -> tuple[Path, ...]:
    run_full_evaluation(config)
    output = Path(config.output_root) / "evaluation"
    return (
        output / "fixed_cell_fire300_records.jsonl",
        output / "cell_relax_fire300_records.jsonl",
        output / "physics_results.json",
    )


def _run_final(config: FullCrysalisConfig) -> tuple[Path, ...]:
    repo_root = Path(__file__).resolve().parents[2]
    build_final_artifacts(config, repo_root=repo_root)
    root = Path(config.output_root)
    return tuple(root / name for name in REQUIRED_ARTIFACT_NAMES)


_STAGE_FUNCTIONS = {
    "audit": _run_audit,
    "preflight": _run_preflight,
    "train": _run_train,
    "generate": _run_generate,
    "evaluate": _run_evaluate,
    "final": _run_final,
}


def run_stage(config: FullCrysalisConfig, stage: str) -> dict[str, Any]:
    if stage not in FORMAL_STAGE_ORDER:
        raise ValueError(f"unsupported Full Crysalis stage: {stage}")
    root = Path(config.output_root)
    final_manifest = root / "FULL_CRYSALIS_MANIFEST.json"
    try:
        if final_manifest.exists():
            raise FileExistsError(
                f"Full Crysalis final manifest already exists: {final_manifest}"
            )
        _verify_prior_receipts(config, stage)
        receipt = _receipt_path(root, stage)
        if receipt.exists():
            raise FileExistsError(
                f"Full Crysalis stage receipt already exists: {receipt}"
            )
        outputs = _STAGE_FUNCTIONS[stage](config)
        return _write_receipt(config, stage, outputs)
    except BaseException as error:
        _append_fatal_failure(config, stage, error)
        raise


def run_all(config: FullCrysalisConfig) -> dict[str, Any]:
    receipts = []
    for stage in FORMAL_STAGE_ORDER:
        receipts.append(run_stage(config, stage))
    return {
        "schema_version": "g1-full-crysalis-run-complete.1.0.0",
        "status": "COMPLETE",
        "completed_stages": [receipt["stage"] for receipt in receipts],
        "stopped_after": "final",
        "ablation_started": False,
    }
