from __future__ import annotations

import hashlib
import json
import math
from collections import Counter
from dataclasses import dataclass, fields, replace
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import torch
from pymatgen.core import Lattice
from pymatgen.util.coord import pbc_shortest_vectors

from crysalis_g1.experiments.c0_symmetry_data import encode_lattice_degrees
from crysalis_g1.full_crysalis.config import (
    FullCrysalisConfig,
    verify_frozen_artifacts,
)
from crysalis_g1.r1.contracts import (
    FrozenArtifact as R1FrozenArtifact,
    R1Config,
    R1ParentBundle,
    RelationAuditBundle,
    audit_relation_operator,
    ensure_public_split,
    load_r1_bundles,
)
from crysalis_g1.r1.dataset import existing_orbit_geometry, lattice_invariants
from crysalis_g1.r1.descriptors import (
    CONTINUOUS_FIELDS,
    ExplicitOrbitGeometry,
    PersistentRelationState,
    RelationInterfaceDescriptor,
    descriptor_from_members,
)
from crysalis_g1.symmetry.wyckoff import (
    ConstrainedLattice,
    OrbitState,
    SpaceGroupConstrainedLatticeHead,
    orbit_representative_fractional_coordinate,
)


RELATION_NUMERIC_DIM = 270
RELATION_POOL_DIM = 8
PHYSICS_POOL_DIM = 9


def _hash_payload(payload: object) -> str:
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def _wyckoff_index(letter: str) -> int:
    if len(letter) != 1 or not "a" <= letter <= "z":
        raise ValueError(f"unsupported Wyckoff letter: {letter!r}")
    return ord(letter) - ord("a")


def _composition_vector(
    composition: Sequence[tuple[int, int]],
) -> tuple[float, ...]:
    vector = np.zeros(118, dtype=float)
    total = sum(int(count) for _, count in composition)
    if total <= 0:
        return tuple(float(value) for value in vector)
    for atomic_number, count in composition:
        if not 1 <= int(atomic_number) <= 118 or int(count) <= 0:
            raise ValueError("composition contains an invalid entry")
        vector[int(atomic_number) - 1] = int(count) / total
    return tuple(float(value) for value in vector)


def _default_embryo_lattice(
    target: ConstrainedLattice,
    site_count: int,
) -> ConstrainedLattice:
    length = max(3.0, (18.0 * site_count) ** (1.0 / 3.0))
    return SpaceGroupConstrainedLatticeHead().constrain(
        target.target_space_group,
        (length, length * 1.03, length * 1.07, 90.0, 90.0, 100.0),
        cell_transform=target.cell_transform_values,
    )


def _orbit_geometries(
    bundle: R1ParentBundle,
) -> dict[str, ExplicitOrbitGeometry]:
    coordinates = bundle.recovered_parent.reconstructed_fractional_coordinates
    result: dict[str, ExplicitOrbitGeometry] = {}
    start = 0
    for orbit in bundle.recovered_parent.orbits:
        stop = start + orbit.multiplicity
        fractional = tuple(
            tuple(float(value) for value in row) for row in coordinates[start:stop]
        )
        if len(fractional) != orbit.multiplicity:
            raise ValueError("recovered orbit coordinate slice is incomplete")
        result[orbit.orbit_instance_id] = ExplicitOrbitGeometry(
            orbit_instance_id=orbit.orbit_instance_id,
            species=orbit.species,
            wyckoff_letter=orbit.wyckoff_letter,
            multiplicity=orbit.multiplicity,
            free_parameter_count=len(orbit.free_parameters),
            fractional_coordinates=fractional,
        )
        start = stop
    if start != len(coordinates):
        raise ValueError("recovered parent has trailing coordinates")
    return result


def _physics_proxy(
    lattice: Sequence[Sequence[float]],
    geometries: Sequence[ExplicitOrbitGeometry],
) -> tuple[float, ...]:
    coordinates = tuple(
        coordinate
        for geometry in geometries
        for coordinate in geometry.fractional_coordinates
    )
    if len(coordinates) <= 1:
        return (0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0)
    array = np.asarray(coordinates, dtype=float)
    _, squared = pbc_shortest_vectors(
        Lattice(np.asarray(lattice, dtype=float)),
        array,
        array,
        return_d2=True,
    )
    distances = np.sqrt(np.maximum(0.0, np.asarray(squared, dtype=float)))[
        np.triu_indices(len(array), 1)
    ]
    minimum = float(distances.min())
    overlap = min(1.0, max(0.0, (0.5 - minimum) / 0.5))
    force_proxy = overlap * 10.0
    return (
        0.0,
        0.0,
        math.log1p(force_proxy),
        math.log1p(force_proxy),
        math.log1p(force_proxy),
        min(minimum / 5.0, 2.0),
        overlap,
        float(minimum >= 0.5),
        0.0,
    )


@dataclass(frozen=True, slots=True)
class IntegratedRelationTarget:
    pair_key: str
    existing_orbit_id: str
    existing_species: int
    existing_wyckoff_letter: str
    existing_multiplicity: int
    existing_free_parameter_count: int
    existing_geometry: tuple[float, float, float, float, float]
    target_group_id: str | None
    descriptor: RelationInterfaceDescriptor


@dataclass(frozen=True, slots=True)
class IntegratedEvent:
    parent_id: str
    split: str
    event_key: str
    target_space_group: int
    composition: tuple[tuple[int, int], ...]
    lattice: ConstrainedLattice
    active_orbits: tuple[OrbitState, ...]
    candidate_orbit: OrbitState | None
    relation_targets: tuple[IntegratedRelationTarget, ...]
    pooled_relation: tuple[float, ...]
    physics_feedback: tuple[float, ...]
    target_physics_feedback: tuple[float, ...]

    def __post_init__(self) -> None:
        if self.split != "inference":
            ensure_public_split(self.split)
        if len(self.pooled_relation) != RELATION_POOL_DIM:
            raise ValueError("integrated relation state width mismatch")
        if (
            len(self.physics_feedback) != PHYSICS_POOL_DIM
            or len(self.target_physics_feedback) != PHYSICS_POOL_DIM
        ):
            raise ValueError("integrated physics state width mismatch")
        active_ids = {orbit.orbit_instance_id for orbit in self.active_orbits}
        if len(active_ids) != len(self.active_orbits):
            raise ValueError("integrated active orbit IDs must be unique")
        if self.candidate_orbit is None:
            if self.relation_targets:
                raise ValueError("terminal events cannot carry relation targets")
        elif {
            target.existing_orbit_id for target in self.relation_targets
        } != active_ids:
            raise ValueError("relation targets must match candidate-existing pairs")

    @property
    def terminal(self) -> bool:
        return self.candidate_orbit is None

    @property
    def remaining_composition(self) -> tuple[tuple[int, int], ...]:
        remaining = Counter(dict(self.composition))
        for orbit in self.active_orbits:
            remaining[orbit.species] -= orbit.multiplicity
            if remaining[orbit.species] == 0:
                del remaining[orbit.species]
        if any(count < 0 for count in remaining.values()):
            raise ValueError("active orbit state exceeds target composition")
        return tuple(sorted(remaining.items()))

    @property
    def progress(self) -> float:
        total = sum(count for _, count in self.composition)
        active = sum(orbit.multiplicity for orbit in self.active_orbits)
        return active / total


@dataclass(frozen=True, slots=True)
class IntegratedCorpus:
    train_events: tuple[IntegratedEvent, ...]
    validation_events: tuple[IntegratedEvent, ...]
    report: Mapping[str, Any]

    @classmethod
    def build(cls, bundles: Sequence[R1ParentBundle]) -> IntegratedCorpus:
        if not bundles:
            raise ValueError("integrated corpus requires public parent bundles")
        train: list[IntegratedEvent] = []
        validation: list[IntegratedEvent] = []
        event_keys: set[str] = set()
        transition_event_keys: set[str] = set()
        parent_ids: set[str] = set()
        raw_transition_count = 0
        deduplicated_transition_count = 0
        empty_state_event_count = 0
        formal_group_ids: set[str] = set()
        supervised_group_ids: set[str] = set()
        relation_eligible_parent_count = 0

        for bundle in bundles:
            parent_id = bundle.parent.material_id
            if parent_id in parent_ids:
                raise ValueError(f"duplicate integrated parent: {parent_id}")
            parent_ids.add(parent_id)
            split = ensure_public_split(bundle.split)
            destination = train if split == "train_fit" else validation
            orbit_by_id = {
                orbit.orbit_instance_id: orbit
                for orbit in bundle.recovered_parent.orbits
            }
            canonical_ids = {orbit.orbit_id for orbit in bundle.parent.orbits}
            if set(orbit_by_id) != canonical_ids:
                raise ValueError(
                    f"recovered/canonical orbit identity mismatch: {parent_id}"
                )
            geometries = _orbit_geometries(bundle)
            composition_counter: Counter[int] = Counter()
            for orbit in orbit_by_id.values():
                composition_counter[orbit.species] += orbit.multiplicity
            composition = tuple(sorted(composition_counter.items()))
            lattice = bundle.recovered_parent.lattice
            lattice_matrix = lattice.primitive_matrix
            existing_geometry_by_id = {
                orbit_id: existing_orbit_geometry(
                    lattice_matrix,
                    geometry.fractional_coordinates,
                )
                for orbit_id, geometry in geometries.items()
            }
            relation_by_id = {
                relation.relation_id: relation
                for relation in bundle.registry.relations
            }
            group_by_pair = {
                frozenset((group.source_orbit_id, group.target_orbit_id)): group
                for group in bundle.registry.interface_groups
                if group.source_orbit_id != group.target_orbit_id
            }
            expected_cross_groups = {
                group.group_id
                for group in bundle.registry.interface_groups
                if group.source_orbit_id != group.target_orbit_id
            }
            if len(group_by_pair) != len(expected_cross_groups):
                raise ValueError("multiple formal relation groups share one orbit pair")
            formal_group_ids.update(expected_cross_groups)
            if bundle.relation_trajectory is not None:
                relation_eligible_parent_count += 1

            pooled_by_active: dict[tuple[str, ...], tuple[float, ...]] = {}
            physics_by_active: dict[tuple[str, ...], tuple[float, ...]] = {}

            def state_features(active_ids: tuple[str, ...]) -> tuple[
                tuple[float, ...], tuple[float, ...]
            ]:
                pooled = pooled_by_active.get(active_ids)
                physics = physics_by_active.get(active_ids)
                if pooled is None or physics is None:
                    active_geometries = tuple(geometries[item] for item in active_ids)
                    persistent = PersistentRelationState.from_orbit_geometries(
                        lattice=lattice_matrix,
                        orbits=active_geometries,
                    )
                    pooled = persistent.pooled
                    physics = _physics_proxy(lattice_matrix, active_geometries)
                    pooled_by_active[active_ids] = pooled
                    physics_by_active[active_ids] = physics
                return pooled, physics

            for trajectory in bundle.d_orbit_trajectories:
                active = set(orbit_by_id)
                for action in trajectory.forward_actions:
                    raw_transition_count += 1
                    if action.operator != "D_orbit" or action.mode != "REMOVE":
                        raise ValueError(
                            "integrated corpus accepts only formal D_orbit removals"
                        )
                    candidate_id = action.target_id
                    if candidate_id not in active:
                        raise ValueError(
                            "formal D_orbit transition removes an inactive orbit"
                        )
                    active.remove(candidate_id)
                    active_ids = tuple(sorted(active))
                    event_key = _hash_payload(
                        {
                            "parent_id": parent_id,
                            "candidate_orbit_id": candidate_id,
                            "active_orbit_ids": active_ids,
                        }
                    )
                    if event_key in event_keys:
                        deduplicated_transition_count += 1
                        continue
                    event_keys.add(event_key)
                    transition_event_keys.add(event_key)
                    pooled, physics = state_features(active_ids)
                    target_ids = tuple(sorted((*active_ids, candidate_id)))
                    _, target_physics = state_features(target_ids)
                    candidate = orbit_by_id[candidate_id]
                    active_orbits = tuple(orbit_by_id[item] for item in active_ids)
                    relation_targets = []
                    for existing_id in active_ids:
                        existing = orbit_by_id[existing_id]
                        group = group_by_pair.get(
                            frozenset((candidate_id, existing_id))
                        )
                        distances: tuple[float, ...] = ()
                        group_id = None
                        if group is not None:
                            group_id = group.group_id
                            supervised_group_ids.add(group_id)
                            distances = tuple(
                                float(relation_by_id[item].distance)
                                for item in group.relation_ids
                            )
                        descriptor = descriptor_from_members(
                            distances=distances,
                            candidate_multiplicity=candidate.multiplicity,
                            existing_multiplicity=existing.multiplicity,
                        )
                        relation_targets.append(
                            IntegratedRelationTarget(
                                pair_key=_hash_payload(
                                    {
                                        "event_key": event_key,
                                        "existing_orbit_id": existing_id,
                                    }
                                ),
                                existing_orbit_id=existing_id,
                                existing_species=existing.species,
                                existing_wyckoff_letter=existing.wyckoff_letter,
                                existing_multiplicity=existing.multiplicity,
                                existing_free_parameter_count=len(
                                    existing.free_parameters
                                ),
                                existing_geometry=existing_geometry_by_id[existing_id],
                                target_group_id=group_id,
                                descriptor=descriptor,
                            )
                        )
                    event = IntegratedEvent(
                        parent_id=parent_id,
                        split=split,
                        event_key=event_key,
                        target_space_group=bundle.recovered_parent.target_space_group,
                        composition=composition,
                        lattice=lattice,
                        active_orbits=active_orbits,
                        candidate_orbit=candidate,
                        relation_targets=tuple(relation_targets),
                        pooled_relation=pooled,
                        physics_feedback=physics,
                        target_physics_feedback=target_physics,
                    )
                    destination.append(event)
                    empty_state_event_count += int(not active_ids)

            full_ids = tuple(sorted(orbit_by_id))
            pooled, physics = state_features(full_ids)
            terminal_key = _hash_payload(
                {"parent_id": parent_id, "terminal_active_orbit_ids": full_ids}
            )
            if terminal_key in event_keys:
                raise ValueError("terminal event collided with a transition event")
            event_keys.add(terminal_key)
            destination.append(
                IntegratedEvent(
                    parent_id=parent_id,
                    split=split,
                    event_key=terminal_key,
                    target_space_group=bundle.recovered_parent.target_space_group,
                    composition=composition,
                    lattice=lattice,
                    active_orbits=tuple(orbit_by_id[item] for item in full_ids),
                    candidate_orbit=None,
                    relation_targets=(),
                    pooled_relation=pooled,
                    physics_feedback=physics,
                    target_physics_feedback=physics,
                )
            )

        train_parents = {event.parent_id for event in train}
        validation_parents = {event.parent_id for event in validation}
        if train_parents & validation_parents:
            raise ValueError("integrated Structure-OOD parent leakage detected")
        missing_groups = formal_group_ids - supervised_group_ids
        if missing_groups:
            raise ValueError(
                "formal cross-orbit relation groups lack integrated supervision: "
                f"{len(missing_groups)}"
            )
        events = (*train, *validation)
        pair_keys = [
            target.pair_key for event in events for target in event.relation_targets
        ]
        if len(pair_keys) != len(set(pair_keys)):
            raise ValueError("integrated relation pair deduplication failed")
        report = {
            "schema_version": "g1-full-crysalis-corpus-report.1.0.0",
            "parent_count": len(parent_ids),
            "relation_eligible_parent_count": relation_eligible_parent_count,
            "raw_transition_count": raw_transition_count,
            "unique_deconstruction_event_count": len(transition_event_keys),
            "terminal_event_count": len(parent_ids),
            "unique_event_count": len(event_keys),
            "deduplicated_transition_count": deduplicated_transition_count,
            "empty_state_event_count": empty_state_event_count,
            "pair_count": len(pair_keys),
            "train_fit_event_count": len(train),
            "validation_event_count": len(validation),
            "formal_cross_orbit_interface_group_count": len(formal_group_ids),
            "supervised_cross_orbit_interface_group_count": len(
                supervised_group_ids
            ),
            "next_orbit_loss_present": False,
            "next_action_label_present": False,
            "removal_order_loss_present": False,
            "sealed_or_blind_data_accessed": False,
        }
        return cls(tuple(train), tuple(validation), report)

    @classmethod
    def from_config(cls, config: FullCrysalisConfig) -> IntegratedCorpus:
        verify_frozen_artifacts(config)
        artifact_names = {
            "phase2a_manifest": "phase2a_manifest",
            "canonical_parents": "canonical_parents",
            "canonical_relations": "canonical_relations",
            "d_orbit_trajectories": "d_orbit",
            "d_relation_interface_trajectories": "d_relation_interface",
            "structure_ood_manifest": "structure_ood_manifest",
            "recovered_parents": "recovered_parents",
            "c0_manifest": "c0_manifest",
            "c0_checkpoint": "c0_checkpoint",
            "condition_manifest": "condition_manifest",
            "chgnet_weights": "chgnet_weights",
        }
        artifacts = {
            r1_name: R1FrozenArtifact(
                path=Path(config.artifacts[full_name].path),
                sha256=config.artifacts[full_name].sha256,
            )
            for r1_name, full_name in artifact_names.items()
        }
        adapter = R1Config(
            config_path=Path("configs/g1_full_crysalis_20260826_v1.json"),
            raw={},
            root_seed=config.root_seed,
            output_root=Path(config.output_root),
            device=config.training.device,
            top_space_groups=(225, 139, 12, 63, 189, 194, 123, 164),
            frozen_artifacts=artifacts,
            attempt_count=config.generation.attempt_count,
            maximum_orbits=config.generation.maximum_orbits,
            maximum_sites=config.generation.maximum_sites,
            minimum_distance_angstrom=(
                config.generation.minimum_distance_angstrom
            ),
            maximum_placement_candidates=config.generation.candidate_pool_size,
            orbit_proposal_namespace=config.generation.proposal_namespace,
            placement_pool_namespace=config.generation.candidate_namespace,
        )
        bundles = load_r1_bundles(adapter)
        audit = audit_relation_operator(
            tuple(
                RelationAuditBundle(
                    parent=bundle.parent,
                    registry=bundle.registry,
                    trajectory=bundle.relation_trajectory,
                )
                for bundle in bundles
                if bundle.relation_trajectory is not None
            )
        )
        corpus = cls.build(bundles)
        report = {
            **corpus.report,
            "formal_relation_replay_pass_count": audit[
                "formal_replay_pass_count"
            ],
            "formal_relation_count": audit["relation_count"],
            "formal_relation_interface_group_count": audit[
                "relation_interface_group_count"
            ],
        }
        return cls(corpus.train_events, corpus.validation_events, report)


@dataclass(frozen=True, slots=True)
class RelationNormalizer:
    mean: tuple[float, ...]
    std: tuple[float, ...]

    @classmethod
    def fit(cls, events: Sequence[IntegratedEvent]) -> RelationNormalizer:
        if not events:
            raise ValueError("relation normalization requires train_fit events")
        if any(event.split != "train_fit" for event in events):
            raise ValueError("relation normalization may use train_fit only")
        available = np.asarray(
            [
                target.descriptor.continuous_values
                for event in events
                for target in event.relation_targets
                if target.descriptor.continuous_availability == 1.0
            ],
            dtype=float,
        )
        if available.ndim != 2 or available.shape[1] != len(CONTINUOUS_FIELDS):
            raise ValueError("train_fit contains no available relation descriptors")
        mean = available.mean(axis=0)
        std = np.maximum(available.std(axis=0), 1e-6)
        if not np.isfinite(mean).all() or not np.isfinite(std).all():
            raise FloatingPointError("non-finite relation normalization")
        return cls(
            tuple(float(value) for value in mean),
            tuple(float(value) for value in std),
        )

    def normalize(
        self,
        descriptor: RelationInterfaceDescriptor,
    ) -> tuple[float, ...]:
        if not descriptor.continuous_availability:
            return (0.0,) * len(CONTINUOUS_FIELDS)
        values = (
            np.asarray(descriptor.continuous_values, dtype=float)
            - np.asarray(self.mean, dtype=float)
        ) / np.asarray(self.std, dtype=float)
        return tuple(float(value) for value in values)


@dataclass(frozen=True, slots=True)
class IntegratedBatch:
    composition: torch.Tensor
    remaining_composition: torch.Tensor
    target_space_group: torch.Tensor
    progress: torch.Tensor
    active_species: torch.Tensor
    active_wyckoff: torch.Tensor
    active_multiplicity: torch.Tensor
    active_free_parameters: torch.Tensor
    active_representatives: torch.Tensor
    active_mask: torch.Tensor
    active_pair_vectors: torch.Tensor
    active_pair_mask: torch.Tensor
    candidate_species: torch.Tensor
    candidate_wyckoff: torch.Tensor
    candidate_multiplicity: torch.Tensor
    candidate_free_parameter_count: torch.Tensor
    candidate_seed_representative: torch.Tensor
    candidate_mask: torch.Tensor
    lattice: torch.Tensor
    lattice_degrees: torch.Tensor
    pooled_relation: torch.Tensor
    physics_feedback: torch.Tensor
    relation_event_index: torch.Tensor
    relation_existing_orbit_index: torch.Tensor
    relation_target_space_group: torch.Tensor
    relation_candidate_species: torch.Tensor
    relation_candidate_wyckoff: torch.Tensor
    relation_existing_species: torch.Tensor
    relation_existing_wyckoff: torch.Tensor
    relation_numeric_features: torch.Tensor
    relation_vectors: torch.Tensor
    relation_presence_target: torch.Tensor
    relation_continuous_target: torch.Tensor
    relation_continuous_mask: torch.Tensor
    target_terminate: torch.Tensor
    target_free_parameters: torch.Tensor
    target_free_parameter_mask: torch.Tensor
    target_representative: torch.Tensor
    target_representative_delta: torch.Tensor
    target_lattice_degrees: torch.Tensor
    target_cell_index: torch.Tensor
    target_multiplicity: torch.Tensor
    target_physics_feedback: torch.Tensor
    parent_ids: tuple[str, ...]
    event_keys: tuple[str, ...]
    pair_keys: tuple[str, ...]

    @property
    def batch_size(self) -> int:
        return int(self.composition.shape[0])

    @property
    def numeric_features(self) -> torch.Tensor:
        return self.relation_numeric_features

    def to(self, device: str | torch.device) -> IntegratedBatch:
        values: dict[str, Any] = {}
        for field in fields(self):
            value = getattr(self, field.name)
            values[field.name] = value.to(device) if isinstance(value, torch.Tensor) else value
        return IntegratedBatch(**values)

    def with_pooled_relation(self, value: torch.Tensor) -> IntegratedBatch:
        numeric = self.relation_numeric_features.clone()
        if numeric.shape[0]:
            numeric[:, -17:-9] = value[self.relation_event_index]
        return replace(
            self,
            pooled_relation=value,
            relation_numeric_features=numeric,
        )

    def with_physics_feedback(self, value: torch.Tensor) -> IntegratedBatch:
        numeric = self.relation_numeric_features.clone()
        if numeric.shape[0]:
            numeric[:, -9:] = value[self.relation_event_index]
        return replace(
            self,
            physics_feedback=value,
            relation_numeric_features=numeric,
        )


def _candidate_seed(orbit: OrbitState) -> tuple[float, float, float]:
    seed = OrbitState.create(
        orbit.target_space_group,
        orbit.wyckoff_letter,
        orbit.species,
        (0.5,) * len(orbit.free_parameters),
        cell_transform=orbit.cell_transform_values,
        orbit_instance_id=f"seed:{orbit.orbit_instance_id}",
    )
    return orbit_representative_fractional_coordinate(seed)


def _shortest_vector(
    lattice: Sequence[Sequence[float]],
    source_fractional: Sequence[float],
    target_fractional: Sequence[float],
) -> tuple[float, float, float]:
    vectors = pbc_shortest_vectors(
        Lattice(np.asarray(lattice, dtype=float)),
        np.asarray([source_fractional], dtype=float),
        np.asarray([target_fractional], dtype=float),
    )
    vector = np.asarray(vectors, dtype=float)[0, 0]
    if not np.isfinite(vector).all():
        raise FloatingPointError("non-finite periodic relation vector")
    return tuple(float(value) for value in vector)


def collate_integrated_events(
    events: Sequence[IntegratedEvent],
    *,
    normalizer: RelationNormalizer,
    maximum_orbits: int = 20,
) -> IntegratedBatch:
    if not events:
        raise ValueError("cannot collate an empty integrated batch")
    if any(len(event.active_orbits) > maximum_orbits for event in events):
        raise ValueError("integrated event exceeds maximum_orbits")
    batch_size = len(events)
    composition = torch.zeros(batch_size, 119, dtype=torch.float32)
    remaining = torch.zeros_like(composition)
    target_space_group = torch.zeros(batch_size, dtype=torch.long)
    progress = torch.zeros(batch_size, 1, dtype=torch.float32)
    active_species = torch.zeros(batch_size, maximum_orbits, dtype=torch.long)
    active_wyckoff = torch.zeros(batch_size, maximum_orbits, dtype=torch.long)
    active_multiplicity = torch.zeros(batch_size, maximum_orbits, dtype=torch.long)
    active_free = torch.zeros(batch_size, maximum_orbits, 3, dtype=torch.float32)
    active_representatives = torch.zeros_like(active_free)
    active_mask = torch.zeros(batch_size, maximum_orbits, dtype=torch.bool)
    active_pair_vectors = torch.zeros(
        batch_size,
        maximum_orbits,
        maximum_orbits,
        3,
        dtype=torch.float32,
    )
    active_pair_mask = torch.zeros(
        batch_size,
        maximum_orbits,
        maximum_orbits,
        dtype=torch.bool,
    )
    candidate_species = torch.zeros(batch_size, dtype=torch.long)
    candidate_wyckoff = torch.zeros(batch_size, dtype=torch.long)
    candidate_multiplicity = torch.zeros(batch_size, dtype=torch.long)
    candidate_free_count = torch.zeros(batch_size, dtype=torch.long)
    candidate_seed = torch.zeros(batch_size, 3, dtype=torch.float32)
    candidate_mask = torch.zeros(batch_size, dtype=torch.bool)
    lattice = torch.zeros(batch_size, 3, 3, dtype=torch.float32)
    lattice_degrees = torch.zeros(batch_size, 6, dtype=torch.float32)
    pooled_relation = torch.zeros(batch_size, RELATION_POOL_DIM, dtype=torch.float32)
    physics_feedback = torch.zeros(batch_size, PHYSICS_POOL_DIM, dtype=torch.float32)
    target_terminate = torch.zeros(batch_size, 1, dtype=torch.float32)
    target_free = torch.zeros(batch_size, 3, dtype=torch.float32)
    target_free_mask = torch.zeros(batch_size, 3, dtype=torch.bool)
    target_representative = torch.zeros(batch_size, 3, dtype=torch.float32)
    target_representative_delta = torch.zeros_like(target_representative)
    target_lattice = torch.zeros(batch_size, 6, dtype=torch.float32)
    target_cell_index = torch.zeros(batch_size, dtype=torch.long)
    target_multiplicity = torch.zeros(batch_size, dtype=torch.long)
    target_physics = torch.zeros(batch_size, PHYSICS_POOL_DIM, dtype=torch.float32)

    relation_event_index: list[int] = []
    relation_existing_index: list[int] = []
    relation_sg: list[int] = []
    relation_candidate_species: list[int] = []
    relation_candidate_wyckoff: list[int] = []
    relation_existing_species: list[int] = []
    relation_existing_wyckoff: list[int] = []
    relation_numeric: list[tuple[float, ...]] = []
    relation_vectors: list[tuple[float, float, float]] = []
    relation_presence: list[list[float]] = []
    relation_continuous: list[tuple[float, ...]] = []
    relation_continuous_mask: list[list[float]] = []
    pair_keys: list[str] = []

    for row_index, event in enumerate(events):
        for atomic_number, count in event.composition:
            composition[row_index, atomic_number] = count
        for atomic_number, count in event.remaining_composition:
            remaining[row_index, atomic_number] = count
        target_space_group[row_index] = event.target_space_group
        progress[row_index, 0] = event.progress
        total_sites = sum(count for _, count in event.composition)
        input_lattice = (
            event.lattice
            if event.active_orbits
            else _default_embryo_lattice(event.lattice, total_sites)
        )
        lattice[row_index] = torch.tensor(input_lattice.primitive_matrix)
        lattice_degrees[row_index] = torch.tensor(
            encode_lattice_degrees(input_lattice)
        )
        target_lattice[row_index] = torch.tensor(
            encode_lattice_degrees(event.lattice)
        )
        target_cell_index[row_index] = event.lattice.cell_index
        pooled_relation[row_index] = torch.tensor(event.pooled_relation)
        physics_feedback[row_index] = torch.tensor(event.physics_feedback)
        target_physics[row_index] = torch.tensor(event.target_physics_feedback)

        active_index_by_id: dict[str, int] = {}
        active_representative_by_id: dict[str, tuple[float, float, float]] = {}
        for orbit_index, orbit in enumerate(event.active_orbits):
            active_index_by_id[orbit.orbit_instance_id] = orbit_index
            active_mask[row_index, orbit_index] = True
            active_species[row_index, orbit_index] = orbit.species
            active_wyckoff[row_index, orbit_index] = _wyckoff_index(
                orbit.wyckoff_letter
            )
            active_multiplicity[row_index, orbit_index] = orbit.multiplicity
            if orbit.free_parameters:
                active_free[
                    row_index, orbit_index, : len(orbit.free_parameters)
                ] = torch.tensor(orbit.free_parameters)
            representative = orbit_representative_fractional_coordinate(orbit)
            active_representatives[row_index, orbit_index] = torch.tensor(
                representative
            )
            active_representative_by_id[orbit.orbit_instance_id] = representative

        for left_index, left in enumerate(event.active_orbits):
            left_representative = active_representative_by_id[
                left.orbit_instance_id
            ]
            for right_index in range(left_index + 1, len(event.active_orbits)):
                right = event.active_orbits[right_index]
                vector = _shortest_vector(
                    input_lattice.primitive_matrix,
                    left_representative,
                    active_representative_by_id[right.orbit_instance_id],
                )
                active_pair_vectors[row_index, left_index, right_index] = (
                    torch.tensor(vector)
                )
                active_pair_mask[row_index, left_index, right_index] = True

        if event.terminal:
            target_terminate[row_index, 0] = 1.0
            continue
        candidate = event.candidate_orbit
        if candidate is None:
            raise AssertionError("nonterminal integrated event lacks a candidate")
        candidate_mask[row_index] = True
        candidate_species[row_index] = candidate.species
        candidate_wyckoff[row_index] = _wyckoff_index(candidate.wyckoff_letter)
        candidate_multiplicity[row_index] = candidate.multiplicity
        candidate_free_count[row_index] = len(candidate.free_parameters)
        seed = _candidate_seed(candidate)
        candidate_seed[row_index] = torch.tensor(seed)
        target_multiplicity[row_index] = candidate.multiplicity
        if candidate.free_parameters:
            target_free[row_index, : len(candidate.free_parameters)] = torch.tensor(
                candidate.free_parameters
            )
            target_free_mask[row_index, : len(candidate.free_parameters)] = True
        target_coordinate = orbit_representative_fractional_coordinate(candidate)
        target_representative[row_index] = torch.tensor(target_coordinate)
        target_representative_delta[row_index] = torch.tensor(
            _shortest_vector(
                input_lattice.primitive_matrix,
                seed,
                target_coordinate,
            )
        )

        composition_vector = _composition_vector(event.composition)
        remaining_vector = _composition_vector(event.remaining_composition)
        invariants = lattice_invariants(
            input_lattice.primitive_matrix,
            total_sites=total_sites,
        )
        for relation_target in event.relation_targets:
            existing_index = active_index_by_id[
                relation_target.existing_orbit_id
            ]
            numeric = (
                candidate.multiplicity / 20.0,
                len(candidate.free_parameters) / 3.0,
                relation_target.existing_multiplicity / 20.0,
                relation_target.existing_free_parameter_count / 3.0,
                *relation_target.existing_geometry,
                *composition_vector,
                *remaining_vector,
                *invariants,
                event.progress,
                *event.pooled_relation,
                *event.physics_feedback,
            )
            if len(numeric) != RELATION_NUMERIC_DIM:
                raise AssertionError("integrated relation feature width drifted")
            relation_event_index.append(row_index)
            relation_existing_index.append(existing_index)
            relation_sg.append(event.target_space_group)
            relation_candidate_species.append(candidate.species)
            relation_candidate_wyckoff.append(
                _wyckoff_index(candidate.wyckoff_letter)
            )
            relation_existing_species.append(relation_target.existing_species)
            relation_existing_wyckoff.append(
                _wyckoff_index(relation_target.existing_wyckoff_letter)
            )
            relation_numeric.append(numeric)
            relation_vectors.append(
                _shortest_vector(
                    input_lattice.primitive_matrix,
                    active_representative_by_id[
                        relation_target.existing_orbit_id
                    ],
                    seed,
                )
            )
            relation_presence.append([relation_target.descriptor.presence])
            relation_continuous.append(
                normalizer.normalize(relation_target.descriptor)
            )
            relation_continuous_mask.append(
                [relation_target.descriptor.continuous_availability]
            )
            pair_keys.append(relation_target.pair_key)

    pair_count = len(relation_numeric)
    if pair_count:
        relation_numeric_tensor = torch.tensor(
            relation_numeric, dtype=torch.float32
        )
        relation_vectors_tensor = torch.tensor(
            relation_vectors, dtype=torch.float32
        )
        relation_continuous_tensor = torch.tensor(
            relation_continuous, dtype=torch.float32
        )
    else:
        relation_numeric_tensor = torch.empty(
            (0, RELATION_NUMERIC_DIM), dtype=torch.float32
        )
        relation_vectors_tensor = torch.empty((0, 3), dtype=torch.float32)
        relation_continuous_tensor = torch.empty(
            (0, len(CONTINUOUS_FIELDS)), dtype=torch.float32
        )
    batch = IntegratedBatch(
        composition=composition,
        remaining_composition=remaining,
        target_space_group=target_space_group,
        progress=progress,
        active_species=active_species,
        active_wyckoff=active_wyckoff,
        active_multiplicity=active_multiplicity,
        active_free_parameters=active_free,
        active_representatives=active_representatives,
        active_mask=active_mask,
        active_pair_vectors=active_pair_vectors,
        active_pair_mask=active_pair_mask,
        candidate_species=candidate_species,
        candidate_wyckoff=candidate_wyckoff,
        candidate_multiplicity=candidate_multiplicity,
        candidate_free_parameter_count=candidate_free_count,
        candidate_seed_representative=candidate_seed,
        candidate_mask=candidate_mask,
        lattice=lattice,
        lattice_degrees=lattice_degrees,
        pooled_relation=pooled_relation,
        physics_feedback=physics_feedback,
        relation_event_index=torch.tensor(relation_event_index, dtype=torch.long),
        relation_existing_orbit_index=torch.tensor(
            relation_existing_index, dtype=torch.long
        ),
        relation_target_space_group=torch.tensor(relation_sg, dtype=torch.long),
        relation_candidate_species=torch.tensor(
            relation_candidate_species, dtype=torch.long
        ),
        relation_candidate_wyckoff=torch.tensor(
            relation_candidate_wyckoff, dtype=torch.long
        ),
        relation_existing_species=torch.tensor(
            relation_existing_species, dtype=torch.long
        ),
        relation_existing_wyckoff=torch.tensor(
            relation_existing_wyckoff, dtype=torch.long
        ),
        relation_numeric_features=relation_numeric_tensor,
        relation_vectors=relation_vectors_tensor,
        relation_presence_target=torch.tensor(
            relation_presence, dtype=torch.float32
        ).reshape(pair_count, 1),
        relation_continuous_target=relation_continuous_tensor,
        relation_continuous_mask=torch.tensor(
            relation_continuous_mask, dtype=torch.float32
        ).reshape(pair_count, 1),
        target_terminate=target_terminate,
        target_free_parameters=target_free,
        target_free_parameter_mask=target_free_mask,
        target_representative=target_representative,
        target_representative_delta=target_representative_delta,
        target_lattice_degrees=target_lattice,
        target_cell_index=target_cell_index,
        target_multiplicity=target_multiplicity,
        target_physics_feedback=target_physics,
        parent_ids=tuple(event.parent_id for event in events),
        event_keys=tuple(event.event_key for event in events),
        pair_keys=tuple(pair_keys),
    )
    for field in fields(batch):
        value = getattr(batch, field.name)
        if isinstance(value, torch.Tensor) and value.is_floating_point():
            if not torch.isfinite(value).all():
                raise FloatingPointError(
                    f"non-finite integrated batch tensor: {field.name}"
                )
    return batch
