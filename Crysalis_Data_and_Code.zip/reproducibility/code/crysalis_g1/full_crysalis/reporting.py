from __future__ import annotations

import importlib.metadata
import json
import os
import platform
import subprocess
import sys
from collections import Counter
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer

from crysalis_g1.experiments.c0_symmetry_evaluation import (
    structural_uniqueness_and_novelty,
)
from crysalis_g1.full_crysalis.config import (
    FullCrysalisConfig,
    sha256_file,
)
from crysalis_g1.full_crysalis.evaluation import (
    decide_full_crysalis_signal,
    summarize_protocol,
)


REQUIRED_ARTIFACT_NAMES = (
    "FULL_CRYSALIS_ARCHITECTURE.md",
    "FULL_CRYSALIS_IMPLEMENTATION_AUDIT.md",
    "FULL_CRYSALIS_TRAINING_REPORT.json",
    "FULL_CRYSALIS_GENERATION_RESULTS.json",
    "FULL_CRYSALIS_PHYSICS_RESULTS.json",
    "FULL_CRYSALIS_BY_SPACE_GROUP.json",
    "FULL_CRYSALIS_FAILURES.jsonl",
    "FULL_CRYSALIS_VS_C0.json",
    "FULL_CRYSALIS_FINAL_REPORT.md",
    "FULL_CRYSALIS_MANIFEST.json",
)


def _canonical_json(payload: object, *, indent: int | None = None) -> str:
    return json.dumps(
        payload,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":") if indent is None else None,
        indent=indent,
    )


def _contains_module_decision(payload: object) -> bool:
    if isinstance(payload, Mapping):
        for key, value in payload.items():
            normalized = str(key).lower().replace("-", "_")
            if "module_decision" in normalized or "module_rejection" in normalized:
                return True
            if _contains_module_decision(value):
                return True
        return False
    if isinstance(payload, (list, tuple)):
        return any(_contains_module_decision(value) for value in payload)
    if isinstance(payload, str):
        forbidden = (
            "relation_useless=true",
            "memory_useless=true",
            "physics_useless=true",
            "kan_useless=true",
            "relation_restoration_hypothesis_rejected=true",
        )
        lowered = payload.lower().replace(" ", "")
        return any(value in lowered for value in forbidden)
    return False


def _write_payload(path: Path, payload: object) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    if path.suffix == ".md":
        if not isinstance(payload, str):
            raise TypeError(f"Markdown artifact must be text: {path.name}")
        text = payload if payload.endswith("\n") else payload + "\n"
    elif path.suffix == ".jsonl":
        if isinstance(payload, (str, bytes)) or not isinstance(payload, Sequence):
            raise TypeError(f"JSONL artifact must be a sequence: {path.name}")
        text = "".join(_canonical_json(record) + "\n" for record in payload)
    else:
        text = _canonical_json(payload, indent=2) + "\n"
    temporary.write_text(text, encoding="utf-8")
    os.replace(temporary, path)


def write_required_artifacts(
    output_root: str | Path,
    payloads: Mapping[str, object],
    *,
    manifest_metadata: Mapping[str, Any],
) -> dict[str, Any]:
    output = Path(output_root)
    expected_payloads = set(REQUIRED_ARTIFACT_NAMES) - {
        "FULL_CRYSALIS_MANIFEST.json"
    }
    if set(payloads) != expected_payloads:
        missing = sorted(expected_payloads - set(payloads))
        extra = sorted(set(payloads) - expected_payloads)
        raise ValueError(f"required artifact payload mismatch: missing={missing}, extra={extra}")
    if manifest_metadata.get("ablation_performed") is not False:
        raise ValueError("final manifest must prove that ablation was not performed")
    if _contains_module_decision(payloads):
        raise ValueError("module decision/rejection content is forbidden before ablation")
    for name in REQUIRED_ARTIFACT_NAMES:
        if (output / name).exists():
            raise FileExistsError(f"final artifact writer refuses to overwrite: {name}")
    output.mkdir(parents=True, exist_ok=True)
    for name in REQUIRED_ARTIFACT_NAMES[:-1]:
        _write_payload(output / name, payloads[name])
    artifact_sha256 = {
        name: sha256_file(output / name) for name in REQUIRED_ARTIFACT_NAMES[:-1]
    }
    manifest = {
        "schema_version": "g1-full-crysalis-manifest.1.0.0",
        **dict(manifest_metadata),
        "required_artifact_count": len(REQUIRED_ARTIFACT_NAMES),
        "required_artifacts": list(REQUIRED_ARTIFACT_NAMES),
        "artifact_sha256": artifact_sha256,
        "manifest_self_hash_included": False,
        "stop_after_full_system_report": True,
        "leave_one_out_started": False,
    }
    _write_payload(output / "FULL_CRYSALIS_MANIFEST.json", manifest)
    return manifest


def _load_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _structure(payload: Mapping[str, Any]) -> Structure:
    return Structure(
        Lattice(np.asarray(payload["lattice"], dtype=float)),
        [int(value) for value in payload["atomic_numbers"]],
        np.asarray(payload["fractional_coordinates"], dtype=float),
        to_unit_cell=True,
    )


def _strict_c0_records(
    records: Sequence[Mapping[str, Any]],
) -> tuple[dict[str, Any], ...]:
    augmented = []
    for source in records:
        record = dict(source)
        strict_match = False
        if record.get("status") == "EVALUATED":
            try:
                detected = int(
                    SpacegroupAnalyzer(
                        _structure(record["final_structure"]),
                        symprec=0.03,
                        angle_tolerance=5.0,
                    ).get_space_group_number()
                )
            except Exception:
                detected = 0
            strict_match = detected == int(record["target_space_group"])
            record["strict_0_03_space_group"] = detected
        record["strict_symmetry_preserving_survival"] = bool(
            record.get("post_relax_survival") and strict_match
        )
        augmented.append(record)
    return tuple(augmented)


def compare_full_with_c0(
    *,
    full_generation_summary: Mapping[str, Any],
    full_fixed_summary: Mapping[str, Any],
    full_cell_summary: Mapping[str, Any],
    c0_generation: Mapping[str, Any],
    c0_fixed_records: Sequence[Mapping[str, Any]],
    c0_cell_records: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    c0_fixed = summarize_protocol(_strict_c0_records(c0_fixed_records))
    c0_cell = summarize_protocol(_strict_c0_records(c0_cell_records))
    full_force = full_fixed_summary["initial_max_force_ev_per_angstrom"]
    c0_force = c0_fixed["initial_max_force_ev_per_angstrom"]
    if c0_force["median"] is None or c0_force["p90"] is None:
        raise ValueError("frozen C0 comparison lacks initial-force observations")
    full_metrics = {
        "legal_terminal_rate": float(
            full_generation_summary["legal_terminal_rate"]
        ),
        "short_contact_rejection_rate": float(
            full_generation_summary["short_contact_rejection_rate"]
        ),
        "initial_force_median_ev_per_angstrom": (
            None if full_force["median"] is None else float(full_force["median"])
        ),
        "initial_force_p90_ev_per_angstrom": (
            None if full_force["p90"] is None else float(full_force["p90"])
        ),
        "fixed_cell_strict_symmetry_survival_rate": float(
            full_fixed_summary["strict_symmetry_survival_rate_all_attempts"]
        ),
        "cell_relax_strict_symmetry_survival_rate": float(
            full_cell_summary["strict_symmetry_survival_rate_all_attempts"]
        ),
    }
    c0_metrics = {
        "legal_terminal_rate": float(
            c0_generation["symmetry_valid_legal_terminal_rate"]
        ),
        "short_contact_rejection_rate": 1.0
        - float(c0_generation["short_contact_free_rate"]),
        "initial_force_median_ev_per_angstrom": float(c0_force["median"]),
        "initial_force_p90_ev_per_angstrom": float(c0_force["p90"]),
        "fixed_cell_strict_symmetry_survival_rate": float(
            c0_fixed["strict_symmetry_survival_rate_all_attempts"]
        ),
        "cell_relax_strict_symmetry_survival_rate": float(
            c0_cell["strict_symmetry_survival_rate_all_attempts"]
        ),
    }
    decision = decide_full_crysalis_signal(
        legal_delta=full_metrics["legal_terminal_rate"]
        - c0_metrics["legal_terminal_rate"],
        short_contact_delta=full_metrics["short_contact_rejection_rate"]
        - c0_metrics["short_contact_rejection_rate"],
        force_median_delta=(
            None
            if full_metrics["initial_force_median_ev_per_angstrom"] is None
            else full_metrics["initial_force_median_ev_per_angstrom"]
            - c0_metrics["initial_force_median_ev_per_angstrom"]
        ),
        force_p90_delta=(
            None
            if full_metrics["initial_force_p90_ev_per_angstrom"] is None
            else full_metrics["initial_force_p90_ev_per_angstrom"]
            - c0_metrics["initial_force_p90_ev_per_angstrom"]
        ),
        fixed_symmetry_survival_delta=full_metrics[
            "fixed_cell_strict_symmetry_survival_rate"
        ]
        - c0_metrics["fixed_cell_strict_symmetry_survival_rate"],
        cell_symmetry_survival_delta=full_metrics[
            "cell_relax_strict_symmetry_survival_rate"
        ]
        - c0_metrics["cell_relax_strict_symmetry_survival_rate"],
    )
    return {
        "schema_version": "g1-full-crysalis-vs-c0.1.0.0",
        "comparison_systems": ["C0_FROZEN", "FULL_CRYSALIS"],
        "denominator": int(full_generation_summary["attempt_count"]),
        "full_crysalis": full_metrics,
        "c0_frozen": c0_metrics,
        "c0_recomputed_strict_0_03": {
            "fixed_cell": c0_fixed,
            "cell_relax": c0_cell,
        },
        **decision,
        "no_module_conclusion": True,
        "posthoc_relation_reranking_not_supported": True,
        "reachability_only_orbit_scoring_not_supported": True,
        "relation_restoration_hypothesis_rejected": False,
        "reversible_deconstruction_rejected": False,
    }


def by_space_group_results(
    *,
    full_generation_records: Sequence[Mapping[str, Any]],
    full_fixed_records: Sequence[Mapping[str, Any]],
    full_cell_records: Sequence[Mapping[str, Any]],
    c0_generation_records: Sequence[Mapping[str, Any]],
    c0_fixed_records: Sequence[Mapping[str, Any]],
    c0_cell_records: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    def keyed(records: Sequence[Mapping[str, Any]]) -> dict[str, Mapping[str, Any]]:
        return {str(record["condition_id"]): record for record in records}

    full_fixed = keyed(full_fixed_records)
    full_cell = keyed(full_cell_records)
    c0_fixed = keyed(_strict_c0_records(c0_fixed_records))
    c0_cell = keyed(_strict_c0_records(c0_cell_records))
    c0_generation = {
        str(record["condition"]["condition_id"]): record
        for record in c0_generation_records
    }
    groups: dict[int, list[Mapping[str, Any]]] = {}
    for record in full_generation_records:
        groups.setdefault(int(record["condition"]["space_group"]), []).append(record)
    results = {}
    for space_group, records in sorted(groups.items()):
        ids = [str(record["condition"]["condition_id"]) for record in records]
        count = len(ids)
        c0_rows = [c0_generation[item] for item in ids]

        def rate(source: Mapping[str, Mapping[str, Any]], key: str) -> float:
            return sum(bool(source[item].get(key)) for item in ids) / count

        results[str(space_group)] = {
            "condition_count": count,
            "full": {
                "legal_terminal_rate": sum(
                    bool(record["legal_terminal_crystal"]) for record in records
                )
                / count,
                "fixed_strict_symmetry_survival_rate": rate(
                    full_fixed, "strict_symmetry_preserving_survival"
                ),
                "cell_strict_symmetry_survival_rate": rate(
                    full_cell, "strict_symmetry_preserving_survival"
                ),
            },
            "c0": {
                "legal_terminal_rate": sum(
                    bool(record["legal_terminal_crystal"]) for record in c0_rows
                )
                / count,
                "fixed_strict_symmetry_survival_rate": rate(
                    c0_fixed, "strict_symmetry_preserving_survival"
                ),
                "cell_strict_symmetry_survival_rate": rate(
                    c0_cell, "strict_symmetry_preserving_survival"
                ),
            },
            "full_failure_taxonomy": dict(
                sorted(
                    Counter(
                        str(record.get("failure_code") or "NONE")
                        for record in records
                    ).items()
                )
            ),
        }
    macro = {}
    for system in ("full", "c0"):
        macro[system] = {
            metric: float(
                np.mean([payload[system][metric] for payload in results.values()])
            )
            for metric in (
                "legal_terminal_rate",
                "fixed_strict_symmetry_survival_rate",
                "cell_strict_symmetry_survival_rate",
            )
        }
    return {
        "schema_version": "g1-full-crysalis-by-space-group.1.0.0",
        "space_groups": results,
        "macro_average": macro,
        "micro_denominator": len(full_generation_records),
        "ablation_performed": False,
    }


def _git_receipt(repo: Path) -> dict[str, Any]:
    safe = f"safe.directory={repo.as_posix()}"
    commit = subprocess.run(
        ["git", "-c", safe, "rev-parse", "HEAD"],
        cwd=repo,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    status = subprocess.run(
        ["git", "-c", safe, "status", "--short"],
        cwd=repo,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.splitlines()
    return {"commit": commit, "dirty_status": status}


def _dependency_versions() -> dict[str, str]:
    names = ("torch", "numpy", "pymatgen", "spglib", "chgnet", "pyxtal")
    result = {}
    for name in names:
        try:
            result[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            result[name] = "NOT_INSTALLED"
    return result


def _architecture_markdown(config: FullCrysalisConfig) -> str:
    return "\n".join(
        (
            "# FULL CRYSALIS Architecture",
            "",
            "Complete crystal -> semantic D_orbit + D_relation_interface deconstruction "
            "-> KAN relation-transition law -> persistent sample-specific relation state "
            "-> Uniform-Legal orbit proposal -> relation-conditioned orbit-level periodic "
            "EGNN geometry -> generation-time GuideMLIP -> crystallographic hard projector "
            "-> complete generated crystal.",
            "",
            "## Frozen integrated flow",
            "",
            "- Orbit ordering is not learned: the Legal Action Compiler produces the legal "
            "set and the proposal is Uniform-Legal.",
            "- Relation information enters geometry through pairwise KAN latents, predicted "
            "presence/descriptors, and the persistent 8-dimensional trajectory state.",
            "- Physics enters before acceptance through a separate GuideMLIP instance; "
            "energy, global force, candidate-local force, and contact risk update persistent "
            "state and the correction forward pass.",
            "- Geometry operates on orbit nodes and predicts Wyckoff free parameters; "
            "symmetry-equivalent atoms are never moved independently.",
            "- SpaceGroupConditionedWyckoffExpander, SymmetryConstrainedLattice, "
            "LegalActionCompiler, and CrystallographicProjector enforce the legal state space.",
            "- EvalMLIP is terminal-only and cannot write generation state, enter losses, or "
            "select checkpoints.",
            "",
            "## Fixed optimization",
            "",
            f"Loss weights: `{dict(config.loss_weights)}`. Candidate selection uses "
            "`0.5 * relation_rank + 0.5 * physics_rank` after hard legality. "
            "No isolated ablation or module gate is present.",
            "",
        )
    )


def _implementation_audit_markdown(
    *,
    training: Mapping[str, Any],
    generation: Mapping[str, Any],
    physics: Mapping[str, Any],
    preflight: Mapping[str, Any] | None,
) -> str:
    checks = {} if preflight is None else preflight.get("checks", {})
    return "\n".join(
        (
            "# FULL CRYSALIS Implementation Audit",
            "",
            f"- Training status: `{training.get('status')}`; updates: "
            f"`{training.get('completed_updates')}`; checkpoint metric: "
            f"`{training.get('checkpoint_selection_metric')}`.",
            f"- Integrated gradient flow relation -> geometry: "
            f"`{training.get('gradient_flow', {}).get('relation_to_geometry')}`.",
            f"- Persistent relation influence check: "
            f"`{checks.get('persistent_relation_state_changes_geometry')}`.",
            f"- Physics feedback influence check: "
            f"`{checks.get('physics_feedback_changes_geometry')}`.",
            f"- Generation attempts: `{generation.get('attempt_count')}`; retries/refills: "
            f"`{generation.get('retry_count')}/{generation.get('refill_count')}`; proposal: "
            f"`{generation.get('orbit_proposal')}`.",
            f"- EvalMLIP role: `{physics.get('provenance', {}).get('role')}`; writes "
            f"generation state: `{physics.get('provenance', {}).get('writes_generation_state')}`.",
            "- Frozen historical diagnostics are scoped only as "
            "`POSTHOC_RELATION_RERANKING_NOT_SUPPORTED=true` and "
            "`REACHABILITY_ONLY_ORBIT_SCORING_NOT_SUPPORTED=true`.",
            "- Isolated scientific audit, contribution lock, module promotion/rejection, "
            "KAN-vs-MLP comparison, and leave-one-out ablation were not executed.",
            "",
        )
    )


def _final_report_markdown(
    *,
    comparison: Mapping[str, Any],
    generation: Mapping[str, Any],
    physics: Mapping[str, Any],
    novelty: Mapping[str, Any],
    by_space_group: Mapping[str, Any],
) -> str:
    def formatted(value: Any) -> str:
        return "NA" if value is None else f"{float(value):.6f}"

    full = comparison["full_crysalis"]
    c0 = comparison["c0_frozen"]
    fixed = physics["fixed_cell_fire300"]["summary"]
    cell = physics["cell_relax_fire300"]["summary"]
    signal = comparison["FULL_CRYSALIS_SIGNAL"]
    lines = [
        "# FULL CRYSALIS Final Report",
        "",
        f"System-level result: **{signal}**.",
        "",
        "This is the first integrated FULL_CRYSALIS result. It does not estimate, reject, "
        "promote, or delete any individual component.",
        "",
        "## Frozen 300-condition comparison",
        "",
        "| Metric | C0 frozen | FULL_CRYSALIS |",
        "|---|---:|---:|",
        f"| Legal terminal rate | {c0['legal_terminal_rate']:.6f} | {full['legal_terminal_rate']:.6f} |",
        f"| Short-contact rejection rate | {c0['short_contact_rejection_rate']:.6f} | {full['short_contact_rejection_rate']:.6f} |",
        "| Initial max force median (eV/A) | "
        f"{formatted(c0['initial_force_median_ev_per_angstrom'])} | "
        f"{formatted(full['initial_force_median_ev_per_angstrom'])} |",
        "| Initial max force p90 (eV/A) | "
        f"{formatted(c0['initial_force_p90_ev_per_angstrom'])} | "
        f"{formatted(full['initial_force_p90_ev_per_angstrom'])} |",
        f"| Fixed-cell strict symmetry survival | {c0['fixed_cell_strict_symmetry_survival_rate']:.6f} | {full['fixed_cell_strict_symmetry_survival_rate']:.6f} |",
        f"| Cell-relax strict symmetry survival | {c0['cell_relax_strict_symmetry_survival_rate']:.6f} | {full['cell_relax_strict_symmetry_survival_rate']:.6f} |",
        "",
        "## FULL system details",
        "",
        f"- Legal terminals: {generation['legal_terminal_count']}/{generation['attempt_count']}.",
        f"- Fixed-cell FIRE300: convergence {fixed['convergence_count']}, physical survival {fixed['physical_survival_count']}, strict symmetry survival {fixed['strict_symmetry_survival_count']}.",
        f"- Cell-relax FIRE300: convergence {cell['convergence_count']}, physical survival {cell['physical_survival_count']}, strict symmetry survival {cell['strict_symmetry_survival_count']}.",
        f"- Unique legal structures: {novelty['unique_count']}; novel relative to train_fit: {novelty['novel_count']}.",
        f"- Macro SG legal rate: {by_space_group['macro_average']['full']['legal_terminal_rate']:.6f}.",
        "",
    ]
    if signal != "POSITIVE":
        lines.extend(
            (
                "## Required integrated failure analysis",
                "",
                "Relation-to-geometry gradient flow, persistent-state influence, and "
                "physics-to-correction influence are reported in the implementation audit. "
                "Generation failure taxonomy and SG dependence are preserved in the JSON "
                "artifacts. No isolated contribution hunt was started.",
                "",
            )
        )
    lines.extend(
        (
            "## Stop boundary",
            "",
            "Execution stops here. Leave-one-out ablation requires new explicit user authorization.",
            "",
        )
    )
    return "\n".join(lines)


def _failure_records(
    generation_records: Sequence[Mapping[str, Any]],
    physics: Mapping[str, Any],
) -> tuple[dict[str, Any], ...]:
    failures = []
    for record in generation_records:
        if record.get("failure_code") is not None:
            failures.append(
                {
                    "condition_id": record["condition"]["condition_id"],
                    "space_group": record["condition"]["space_group"],
                    "stage": "generation",
                    "failure_code": record["failure_code"],
                    "reason_codes": record.get("projector_rejection_reasons", ()),
                    "retry_count": 0,
                    "refill_count": 0,
                }
            )
    for protocol in ("fixed_cell_fire300", "cell_relax_fire300"):
        for record in physics[protocol]["records"]:
            if record.get("status") not in {
                "EVALUATED",
                "SKIPPED_GENERATION_FAILURE",
            }:
                failures.append(
                    {
                        "condition_id": record["condition_id"],
                        "stage": protocol,
                        "failure_code": record["status"],
                        "exception_type": record.get("exception_type"),
                        "exception_message": record.get("exception_message"),
                        "retry_count": 0,
                        "refill_count": 0,
                    }
                )
    return tuple(failures)


def build_final_artifacts(
    config: FullCrysalisConfig,
    *,
    repo_root: str | Path,
) -> dict[str, Any]:
    root = Path(config.output_root)
    training = _load_json(root / "training" / "training_report.json")
    generation_records = _load_json(root / "generation" / "generation_records.json")
    generation_summary = _load_json(root / "generation" / "generation_summary.json")
    physics = _load_json(root / "evaluation" / "physics_results.json")
    preflight_path = root / "engineering" / "preflight.json"
    preflight = _load_json(preflight_path) if preflight_path.is_file() else None
    if len(generation_records) != config.generation.attempt_count:
        raise ValueError("final report generation denominator drifted")

    c0_generation = _load_json(config.artifacts["c0_generation_metrics"].path)
    c0_generation_payload = _load_json(
        config.artifacts["c0_generation_records"].path
    )
    c0_fixed_payload = _load_json(config.artifacts["c0_fixed_cell_records"].path)
    c0_cell_payload = _load_json(config.artifacts["c0_cell_relax_records"].path)
    full_fixed = physics["fixed_cell_fire300"]
    full_cell = physics["cell_relax_fire300"]
    comparison = compare_full_with_c0(
        full_generation_summary=generation_summary,
        full_fixed_summary=full_fixed["summary"],
        full_cell_summary=full_cell["summary"],
        c0_generation=c0_generation,
        c0_fixed_records=c0_fixed_payload["records"],
        c0_cell_records=c0_cell_payload["records"],
    )
    by_sg = by_space_group_results(
        full_generation_records=generation_records,
        full_fixed_records=full_fixed["records"],
        full_cell_records=full_cell["records"],
        c0_generation_records=c0_generation_payload["records"],
        c0_fixed_records=c0_fixed_payload["records"],
        c0_cell_records=c0_cell_payload["records"],
    )
    phase2a_root = Path(config.artifacts["phase2a_manifest"].path).parent
    novelty = structural_uniqueness_and_novelty(
        generation_records,
        phase2a_root=phase2a_root,
        recovered_parent_cache=config.artifacts["recovered_parents"].path,
    )
    generation_results = {
        **generation_summary,
        "uniqueness_and_novelty": novelty,
        "records": generation_records,
    }
    physics_results = {
        **physics,
        "initial_force_source": "fixed_cell_fire300 pre-relax trajectory",
    }
    failures = _failure_records(generation_records, physics)
    payloads: dict[str, object] = {
        "FULL_CRYSALIS_ARCHITECTURE.md": _architecture_markdown(config),
        "FULL_CRYSALIS_IMPLEMENTATION_AUDIT.md": (
            _implementation_audit_markdown(
                training=training,
                generation=generation_summary,
                physics=physics,
                preflight=preflight,
            )
        ),
        "FULL_CRYSALIS_TRAINING_REPORT.json": training,
        "FULL_CRYSALIS_GENERATION_RESULTS.json": generation_results,
        "FULL_CRYSALIS_PHYSICS_RESULTS.json": physics_results,
        "FULL_CRYSALIS_BY_SPACE_GROUP.json": by_sg,
        "FULL_CRYSALIS_FAILURES.jsonl": failures,
        "FULL_CRYSALIS_VS_C0.json": comparison,
        "FULL_CRYSALIS_FINAL_REPORT.md": _final_report_markdown(
            comparison=comparison,
            generation=generation_summary,
            physics=physics,
            novelty=novelty,
            by_space_group=by_sg,
        ),
    }
    config_path = Path("configs/g1_full_crysalis_20260826_v1.json")
    manifest_metadata = {
        "root_seed": config.root_seed,
        "comparison_systems": list(config.comparison_systems),
        "attempt_count": config.generation.attempt_count,
        "public_only": True,
        "sealed_or_blind_data_accessed": False,
        "retry_count": 0,
        "refill_count": 0,
        "server_used": False,
        "dft_used": False,
        "ablation_performed": False,
        "isolated_scientific_audit_performed": False,
        "contribution_lock_performed": False,
        "full_crysalis_signal": comparison["FULL_CRYSALIS_SIGNAL"],
        "config_path": str(config_path.resolve()),
        "config_sha256": sha256_file(config_path),
        "frozen_input_sha256": {
            name: artifact.sha256 for name, artifact in config.artifacts.items()
        },
        "git": _git_receipt(Path(repo_root)),
        "dependencies": _dependency_versions(),
        "python": sys.version,
        "platform": platform.platform(),
    }
    manifest = write_required_artifacts(
        root,
        payloads,
        manifest_metadata=manifest_metadata,
    )
    return {
        "manifest": manifest,
        "comparison": comparison,
        "by_space_group": by_sg,
        "novelty": novelty,
    }
