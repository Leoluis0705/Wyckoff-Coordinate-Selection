from __future__ import annotations

import hashlib
import json
import math
from dataclasses import asdict, dataclass
from typing import Any, Sequence

from crysalis_g1.r1.descriptors import (
    PersistentPairRecord,
    PersistentRelationState as ExplicitPersistentRelationState,
)
from crysalis_g1.symmetry.assembly import (
    C0SymmetryProjector,
    SpaceGroupLegalActionCompiler,
    SymmetryAssemblyState,
)
from crysalis_g1.symmetry.wyckoff import OrbitState


RELATION_POOL_DIM = 8
PHYSICS_POOL_DIM = 9


def _canonical_hash(payload: Any) -> str:
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def _finite_optional(value: float | None, label: str) -> None:
    if value is not None and not math.isfinite(float(value)):
        raise ValueError(f"{label} must be finite when present")


@dataclass(frozen=True, slots=True)
class PhysicsFeedback:
    energy_per_atom_ev: float | None
    relative_energy_rank: float
    mean_force_ev_per_angstrom: float
    max_force_ev_per_angstrom: float
    candidate_max_force_ev_per_angstrom: float
    minimum_distance_angstrom: float | None
    overlap_risk: float
    locally_feasible: bool
    mlip_applicable: bool
    reason_codes: tuple[str, ...]
    max_force_rank: float = 0.0
    candidate_force_rank: float = 0.0

    def __post_init__(self) -> None:
        _finite_optional(self.energy_per_atom_ev, "energy_per_atom_ev")
        _finite_optional(self.minimum_distance_angstrom, "minimum_distance_angstrom")
        finite_nonnegative = (
            self.relative_energy_rank,
            self.max_force_rank,
            self.candidate_force_rank,
            self.mean_force_ev_per_angstrom,
            self.max_force_ev_per_angstrom,
            self.candidate_max_force_ev_per_angstrom,
            self.overlap_risk,
        )
        if any(not math.isfinite(float(value)) or value < 0 for value in finite_nonnegative):
            raise ValueError("physics feedback scalars must be finite and non-negative")
        if (
            self.relative_energy_rank > 1
            or self.max_force_rank > 1
            or self.candidate_force_rank > 1
            or self.overlap_risk > 1
        ):
            raise ValueError("physics ranks and risks must lie in [0, 1]")
        if (
            self.max_force_ev_per_angstrom + 1e-12
            < self.mean_force_ev_per_angstrom
        ):
            raise ValueError("maximum force cannot be below mean force")
        if self.minimum_distance_angstrom is not None and self.minimum_distance_angstrom < 0:
            raise ValueError("minimum distance cannot be negative")
        if any(not code for code in self.reason_codes):
            raise ValueError("physics reason codes must be non-empty strings")

    @classmethod
    def zero(cls) -> PhysicsFeedback:
        return cls(
            energy_per_atom_ev=None,
            relative_energy_rank=0.0,
            mean_force_ev_per_angstrom=0.0,
            max_force_ev_per_angstrom=0.0,
            candidate_max_force_ev_per_angstrom=0.0,
            minimum_distance_angstrom=None,
            overlap_risk=0.0,
            locally_feasible=True,
            mlip_applicable=False,
            reason_codes=("NO_PRIOR_GUIDE_FEEDBACK",),
        )

    @property
    def vector(self) -> tuple[float, ...]:
        energy = 0.0 if self.energy_per_atom_ev is None else math.tanh(
            self.energy_per_atom_ev / 10.0
        )
        distance = (
            0.0
            if self.minimum_distance_angstrom is None
            else min(self.minimum_distance_angstrom / 5.0, 2.0)
        )
        return (
            float(energy),
            float(self.relative_energy_rank),
            math.log1p(float(self.mean_force_ev_per_angstrom)),
            math.log1p(float(self.max_force_ev_per_angstrom)),
            math.log1p(float(self.candidate_max_force_ev_per_angstrom)),
            float(distance),
            float(self.overlap_risk),
            float(self.locally_feasible),
            float(self.mlip_applicable),
        )


@dataclass(frozen=True, slots=True)
class PredictedRelationRecord:
    candidate_orbit_id: str
    existing_orbit_id: str
    presence_logit: float
    normalized_continuous: tuple[float, ...]
    latent: tuple[float, ...]

    def __post_init__(self) -> None:
        if not self.candidate_orbit_id or not self.existing_orbit_id:
            raise ValueError("predicted relation endpoint IDs must be non-empty")
        values = (
            self.presence_logit,
            *self.normalized_continuous,
            *self.latent,
        )
        if any(not math.isfinite(float(value)) for value in values):
            raise ValueError("predicted relation values must be finite")
        if len(self.normalized_continuous) != 7:
            raise ValueError("predicted relation descriptor width must be seven")


def _pool_physics(history: Sequence[PhysicsFeedback]) -> tuple[float, ...]:
    if not history:
        return (0.0,) * PHYSICS_POOL_DIM
    columns = tuple(zip(*(feedback.vector for feedback in history), strict=True))
    return tuple(float(sum(column) / len(column)) for column in columns)


@dataclass(frozen=True, slots=True)
class PersistentRelationState:
    present_orbit_ids: tuple[str, ...]
    orbit_metadata: tuple[dict[str, Any], ...]
    realized_pair_records: tuple[PersistentPairRecord, ...]
    predicted_relation_records: tuple[PredictedRelationRecord, ...]
    pooled_relation: tuple[float, ...]
    physics_history: tuple[PhysicsFeedback, ...]
    pooled_physics: tuple[float, ...]
    step_index: int
    state_hash: str

    @classmethod
    def empty(cls) -> PersistentRelationState:
        return cls._create(
            present_orbit_ids=(),
            orbit_metadata=(),
            realized_pair_records=(),
            predicted_relation_records=(),
            pooled_relation=(0.0,) * RELATION_POOL_DIM,
            physics_history=(),
            pooled_physics=(0.0,) * PHYSICS_POOL_DIM,
            step_index=0,
        )

    @classmethod
    def _create(
        cls,
        *,
        present_orbit_ids: tuple[str, ...],
        orbit_metadata: tuple[dict[str, Any], ...],
        realized_pair_records: tuple[PersistentPairRecord, ...],
        predicted_relation_records: tuple[PredictedRelationRecord, ...],
        pooled_relation: tuple[float, ...],
        physics_history: tuple[PhysicsFeedback, ...],
        pooled_physics: tuple[float, ...],
        step_index: int,
    ) -> PersistentRelationState:
        if len(pooled_relation) != RELATION_POOL_DIM:
            raise ValueError("persistent relation pool width mismatch")
        if len(pooled_physics) != PHYSICS_POOL_DIM:
            raise ValueError("persistent physics pool width mismatch")
        payload = {
            "present_orbit_ids": present_orbit_ids,
            "orbit_metadata": orbit_metadata,
            "realized_pair_records": [asdict(record) for record in realized_pair_records],
            "predicted_relation_records": [
                asdict(record) for record in predicted_relation_records
            ],
            "pooled_relation": pooled_relation,
            "physics_history": [asdict(item) for item in physics_history],
            "pooled_physics": pooled_physics,
            "step_index": step_index,
        }
        return cls(
            present_orbit_ids=present_orbit_ids,
            orbit_metadata=orbit_metadata,
            realized_pair_records=realized_pair_records,
            predicted_relation_records=predicted_relation_records,
            pooled_relation=pooled_relation,
            physics_history=physics_history,
            pooled_physics=pooled_physics,
            step_index=step_index,
            state_hash=_canonical_hash(payload),
        )

    def update(
        self,
        *,
        accepted_state: SymmetryAssemblyState,
        added_orbit: OrbitState,
        predicted_relations: Sequence[PredictedRelationRecord],
        guide_feedback: PhysicsFeedback,
    ) -> PersistentRelationState:
        accepted_ids = {
            orbit.orbit_instance_id for orbit in accepted_state.orbits
        }
        prior_ids = set(self.present_orbit_ids)
        if added_orbit.orbit_instance_id not in accepted_ids:
            raise ValueError("accepted state does not contain the added orbit")
        if accepted_ids - {added_orbit.orbit_instance_id} != prior_ids:
            raise ValueError("accepted state must preserve exactly the existing orbit prefix")
        if any(
            prediction.candidate_orbit_id != added_orbit.orbit_instance_id
            or prediction.existing_orbit_id not in prior_ids
            for prediction in predicted_relations
        ):
            raise ValueError("predicted relations do not match the accepted add transition")

        projector = C0SymmetryProjector(minimum_distance=0.5)
        receipt = projector.project(accepted_state)
        if not receipt.accepted:
            raise ValueError(
                "persistent state update requires a projector-accepted assembly: "
                + ",".join(receipt.reason_codes)
            )
        explicit = ExplicitPersistentRelationState.from_assembly_state(
            accepted_state, projector
        )
        physics_history = (*self.physics_history, guide_feedback)
        return self._create(
            present_orbit_ids=explicit.present_orbit_ids,
            orbit_metadata=explicit.orbit_metadata,
            realized_pair_records=explicit.pairwise_relation_records,
            predicted_relation_records=(
                *self.predicted_relation_records,
                *tuple(predicted_relations),
            ),
            pooled_relation=explicit.pooled,
            physics_history=physics_history,
            pooled_physics=_pool_physics(physics_history),
            step_index=self.step_index + 1,
        )


@dataclass(frozen=True, slots=True)
class FullGenerationState:
    assembly_state: SymmetryAssemblyState
    persistent_relation_state: PersistentRelationState
    current_predicted_relations: tuple[PredictedRelationRecord, ...]
    current_physics_feedback: PhysicsFeedback
    generation_progress: float
    termination_legal: bool
    terminated: bool
    failure_code: str | None
    state_hash: str

    @classmethod
    def create(
        cls,
        assembly_state: SymmetryAssemblyState,
        persistent_relation_state: PersistentRelationState,
        *,
        current_predicted_relations: Sequence[PredictedRelationRecord] = (),
        current_physics_feedback: PhysicsFeedback | None = None,
        failure_code: str | None = None,
    ) -> FullGenerationState:
        assembly_ids = tuple(
            sorted(orbit.orbit_instance_id for orbit in assembly_state.orbits)
        )
        if assembly_ids != persistent_relation_state.present_orbit_ids:
            raise ValueError("assembly and persistent relation orbit identities disagree")
        projector = C0SymmetryProjector(minimum_distance=0.5)
        receipt = projector.project(assembly_state) if assembly_state.orbits else None
        termination_legal = bool(
            receipt is not None
            and SpaceGroupLegalActionCompiler.can_terminate(assembly_state, receipt)
        )
        total_sites = sum(count for _, count in assembly_state.composition)
        progress = assembly_state.site_count / total_sites
        physics = current_physics_feedback or PhysicsFeedback.zero()
        predicted = tuple(current_predicted_relations)
        payload = {
            "assembly_state": assembly_state.to_dict(),
            "persistent_relation_state_hash": persistent_relation_state.state_hash,
            "predicted_relations": [asdict(item) for item in predicted],
            "current_physics_feedback": asdict(physics),
            "generation_progress": progress,
            "termination_legal": termination_legal,
            "terminated": assembly_state.terminated,
            "failure_code": failure_code,
        }
        return cls(
            assembly_state=assembly_state,
            persistent_relation_state=persistent_relation_state,
            current_predicted_relations=predicted,
            current_physics_feedback=physics,
            generation_progress=progress,
            termination_legal=termination_legal,
            terminated=assembly_state.terminated,
            failure_code=failure_code,
            state_hash=_canonical_hash(payload),
        )
