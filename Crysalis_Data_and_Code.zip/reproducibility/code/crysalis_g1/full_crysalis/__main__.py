from __future__ import annotations

import argparse
import json
from pathlib import Path

from crysalis_g1.full_crysalis.config import FullCrysalisConfig
from crysalis_g1.full_crysalis.runner import FORMAL_STAGE_ORDER, run_all, run_stage


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Execute the integrated Full Crysalis pipeline"
    )
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument(
        "--stage",
        choices=(*FORMAL_STAGE_ORDER, "all"),
        required=True,
    )
    arguments = parser.parse_args()
    config = FullCrysalisConfig.from_json(arguments.config)
    if arguments.stage == "all":
        result = run_all(config)
    else:
        result = run_stage(config, arguments.stage)
    print(json.dumps(result, ensure_ascii=False, allow_nan=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
