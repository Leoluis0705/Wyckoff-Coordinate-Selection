from __future__ import annotations

import json
import math
import os
import random
import time
from dataclasses import asdict, dataclass
from itertools import cycle, islice
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import torch
from pymatgen.core import Lattice, Structure

from crysalis_g1.full_crysalis.config import (
    LOSS_WEIGHTS,
    FullCrysalisConfig,
    sha256_file,
)
from crysalis_g1.full_crysalis.data import (
    IntegratedCorpus,
    IntegratedEvent,
    RelationNormalizer,
    collate_integrated_events,
)
from crysalis_g1.full_crysalis.geometry import GeometryGeneratorConfig
from crysalis_g1.full_crysalis.guide_mlip import GuideMLIP
from crysalis_g1.full_crysalis.model import (
    FullCrysalisModel,
    compute_full_crysalis_losses,
)
from crysalis_g1.full_crysalis.relation import RelationBackendConfig


CHECKPOINT_SCHEMA_VERSION = "g1-full-crysalis-checkpoint.1.0.0"


def _write_json_atomic(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            allow_nan=False,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def _atomic_torch_save(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temporary)
    os.replace(temporary, path)


def _seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed % (2**32))
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


@dataclass(frozen=True, slots=True)
class TrainingLoopConfig:
    root_seed: int
    device: str
    minimum_updates: int
    maximum_updates: int
    batch_size: int
    validation_batch_size: int
    validation_interval: int
    early_stopping_patience: int
    learning_rate: float
    weight_decay: float
    gradient_clip_norm: float
    relation_config: RelationBackendConfig
    geometry_config: GeometryGeneratorConfig
    loss_weights: Mapping[str, float]

    def __post_init__(self) -> None:
        if self.root_seed != 20260823:
            raise ValueError("Full Crysalis training seed must remain 20260823")
        if self.device not in {"cpu", "cuda"}:
            raise ValueError("Full Crysalis training device must be cpu or cuda")
        counts = (
            self.minimum_updates,
            self.maximum_updates,
            self.batch_size,
            self.validation_batch_size,
            self.validation_interval,
            self.early_stopping_patience,
        )
        if any(type(value) is not int or value <= 0 for value in counts):
            raise ValueError("training counts must be positive integers")
        if self.minimum_updates > self.maximum_updates:
            raise ValueError("minimum updates cannot exceed maximum updates")
        scalars = (
            self.learning_rate,
            self.gradient_clip_norm,
        )
        if any(not math.isfinite(value) or value <= 0 for value in scalars):
            raise ValueError("training scales must be finite and positive")
        if not math.isfinite(self.weight_decay) or self.weight_decay < 0:
            raise ValueError("training weight decay must be finite and non-negative")
        if {name: float(value) for name, value in self.loss_weights.items()} != (
            LOSS_WEIGHTS
        ):
            raise ValueError("Full Crysalis training loss weights drifted")

    @classmethod
    def from_full_config(
        cls,
        config: FullCrysalisConfig,
        *,
        effective_batch_size: int | None = None,
    ) -> TrainingLoopConfig:
        return cls(
            root_seed=config.root_seed,
            device=config.training.device,
            minimum_updates=config.training.minimum_updates,
            maximum_updates=config.training.maximum_updates,
            batch_size=(effective_batch_size or config.training.batch_size),
            validation_batch_size=config.training.validation_batch_size,
            validation_interval=config.training.validation_interval,
            early_stopping_patience=config.training.early_stopping_patience,
            learning_rate=config.training.learning_rate,
            weight_decay=config.training.weight_decay,
            gradient_clip_norm=config.training.gradient_clip_norm,
            relation_config=RelationBackendConfig(
                numeric_dim=270,
                embedding_dim=config.relation.embedding_dim,
                hidden_dim=config.relation.hidden_dim,
                latent_dim=config.relation.latent_dim,
                grid_size=config.relation.kan_grid_size,
                layer_count=config.relation.kan_layer_count,
            ),
            geometry_config=GeometryGeneratorConfig(
                hidden_dim=config.geometry.hidden_dim,
                block_count=config.geometry.block_count,
                radial_basis_count=config.geometry.radial_basis_count,
                cutoff_angstrom=config.geometry.cutoff_angstrom,
                coordinate_step_scale=config.geometry.coordinate_step_scale,
                maximum_orbits=config.geometry.maximum_orbits,
                maximum_cell_index=config.geometry.maximum_cell_index,
                relation_latent_dim=config.relation.latent_dim,
            ),
            loss_weights=config.loss_weights,
        )


class _EventSampler:
    def __init__(self, events: Sequence[IntegratedEvent], *, seed: int) -> None:
        if not events:
            raise ValueError("training sampler requires train_fit events")
        self.events = tuple(events)
        self.generator = torch.Generator().manual_seed(seed)
        self.order: list[int] = []
        self.cursor = 0

    def _reshuffle(self) -> None:
        self.order = torch.randperm(
            len(self.events),
            generator=self.generator,
        ).tolist()
        self.cursor = 0

    def batch(self, size: int) -> tuple[IntegratedEvent, ...]:
        selected = []
        while len(selected) < size:
            if self.cursor >= len(self.order):
                self._reshuffle()
            take = min(size - len(selected), len(self.order) - self.cursor)
            selected.extend(
                self.events[index]
                for index in self.order[self.cursor : self.cursor + take]
            )
            self.cursor += take
        return tuple(selected)


def _finite_gradients(model: torch.nn.Module) -> bool:
    return all(
        parameter.grad is None or bool(torch.isfinite(parameter.grad).all())
        for parameter in model.parameters()
    )


def _gradient_flow_probe(
    model: FullCrysalisModel,
    corpus: IntegratedCorpus,
    normalizer: RelationNormalizer,
    device: torch.device,
) -> dict[str, bool]:
    event = next(
        (
            item
            for item in corpus.train_events
            if item.relation_targets
            and item.candidate_orbit is not None
            and item.candidate_orbit.free_parameters
        ),
        None,
    )
    if event is None:
        raise ValueError("training corpus lacks a relation-conditioned geometry event")
    batch = collate_integrated_events(
        (event,),
        normalizer=normalizer,
        maximum_orbits=model.geometry_generator.config.maximum_orbits,
    ).to(device)
    model.zero_grad(set_to_none=True)
    output = model(batch)
    losses = compute_full_crysalis_losses(output, batch, model.loss_weights)
    losses.components["free_parameters"].backward()
    relation_to_geometry = any(
        parameter.grad is not None and bool(parameter.grad.abs().sum() > 0)
        for parameter in model.relation_backend.parameters()
    )
    gradients_finite = _finite_gradients(model)
    model.zero_grad(set_to_none=True)
    return {
        "relation_to_geometry": relation_to_geometry,
        "finite": gradients_finite,
    }


def _evaluate(
    model: FullCrysalisModel,
    events: Sequence[IntegratedEvent],
    *,
    normalizer: RelationNormalizer,
    batch_size: int,
    device: torch.device,
) -> dict[str, float]:
    if not events:
        raise ValueError("validation requires Structure-OOD events")
    names = ("total", *LOSS_WEIGHTS)
    totals = {name: 0.0 for name in names}
    count = 0
    model.eval()
    with torch.no_grad():
        for start in range(0, len(events), batch_size):
            selected = events[start : start + batch_size]
            batch = collate_integrated_events(
                selected,
                normalizer=normalizer,
                maximum_orbits=model.geometry_generator.config.maximum_orbits,
            ).to(device)
            output = model(batch)
            losses = compute_full_crysalis_losses(
                output,
                batch,
                model.loss_weights,
            )
            size = len(selected)
            totals["total"] += float(losses.total.detach()) * size
            for name, value in losses.components.items():
                totals[name] += float(value.detach()) * size
            count += size
    model.train()
    result = {name: value / count for name, value in totals.items()}
    if any(not math.isfinite(value) for value in result.values()):
        raise FloatingPointError("non-finite Structure-OOD validation loss")
    return result


def _checkpoint_payload(
    model: FullCrysalisModel,
    *,
    config: TrainingLoopConfig,
    normalizer: RelationNormalizer,
    update: int,
    validation_losses: Mapping[str, float],
    corpus_report: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        "schema_version": CHECKPOINT_SCHEMA_VERSION,
        "root_seed": config.root_seed,
        "update": update,
        "checkpoint_selection_metric": (
            "structure_ood_validation_total_loss"
        ),
        "validation_losses": dict(validation_losses),
        "model_state_dict": {
            name: value.detach().cpu()
            for name, value in model.state_dict().items()
        },
        "relation_config": asdict(config.relation_config),
        "geometry_config": asdict(config.geometry_config),
        "loss_weights": dict(config.loss_weights),
        "normalizer": {
            "mean": normalizer.mean,
            "std": normalizer.std,
            "fit_split": "train_fit",
        },
        "corpus_report": dict(corpus_report),
        "generation_metrics_used": False,
        "next_orbit_loss_present": False,
        "removal_order_loss_present": False,
        "ablation_performed": False,
    }


def train_on_corpus(
    corpus: IntegratedCorpus,
    config: TrainingLoopConfig,
    *,
    output_dir: str | Path,
) -> dict[str, Any]:
    if not corpus.train_events or not corpus.validation_events:
        raise ValueError("training requires non-empty train_fit and validation events")
    train_parents = {event.parent_id for event in corpus.train_events}
    validation_parents = {event.parent_id for event in corpus.validation_events}
    if train_parents & validation_parents:
        raise ValueError("training detected Structure-OOD parent leakage")
    if config.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA training was requested but is unavailable")
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    checkpoint_path = output / "best.pt"
    metrics_path = output / "metrics.jsonl"
    report_path = output / "training_report.json"
    for path in (checkpoint_path, metrics_path, report_path):
        if path.exists():
            raise FileExistsError(f"Full Crysalis training refuses to overwrite: {path}")

    _seed_everything(config.root_seed)
    device = torch.device(config.device)
    model = FullCrysalisModel(
        relation_config=config.relation_config,
        geometry_config=config.geometry_config,
        loss_weights=config.loss_weights,
    ).to(device)
    normalizer = RelationNormalizer.fit(corpus.train_events)
    gradient_flow = _gradient_flow_probe(model, corpus, normalizer, device)
    if not all(gradient_flow.values()):
        raise RuntimeError("relation-to-geometry gradient-flow precondition failed")
    sampler = _EventSampler(corpus.train_events, seed=config.root_seed)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=config.learning_rate,
        weight_decay=config.weight_decay,
    )
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    best_objective = math.inf
    best_update = 0
    best_validation: dict[str, float] | None = None
    stale_evaluations = 0
    completed_updates = 0
    stopped_early = False
    started = time.perf_counter()
    with metrics_path.open("x", encoding="utf-8") as metrics:
        for update in range(1, config.maximum_updates + 1):
            selected = sampler.batch(config.batch_size)
            batch = collate_integrated_events(
                selected,
                normalizer=normalizer,
                maximum_orbits=config.geometry_config.maximum_orbits,
            ).to(device)
            optimizer.zero_grad(set_to_none=True)
            output_values = model(batch)
            losses = compute_full_crysalis_losses(
                output_values,
                batch,
                model.loss_weights,
            )
            if not bool(torch.isfinite(losses.total)):
                raise FloatingPointError(
                    f"non-finite Full Crysalis loss at update {update}"
                )
            losses.total.backward()
            if not _finite_gradients(model):
                raise FloatingPointError(
                    f"non-finite Full Crysalis gradient at update {update}"
                )
            gradient_norm = torch.nn.utils.clip_grad_norm_(
                model.parameters(),
                config.gradient_clip_norm,
            )
            if not bool(torch.isfinite(gradient_norm)):
                raise FloatingPointError(
                    f"non-finite Full Crysalis gradient norm at update {update}"
                )
            optimizer.step()
            completed_updates = update

            should_validate = (
                update % config.validation_interval == 0
                or update == config.maximum_updates
            )
            if not should_validate:
                continue
            validation = _evaluate(
                model,
                corpus.validation_events,
                normalizer=normalizer,
                batch_size=config.validation_batch_size,
                device=device,
            )
            record = {
                "update": update,
                "train_total_loss": float(losses.total.detach()),
                "gradient_norm_before_clip": float(gradient_norm.detach()),
                **{
                    f"train_{name}": float(value.detach())
                    for name, value in losses.components.items()
                },
                **{
                    f"validation_{name}": value
                    for name, value in validation.items()
                },
            }
            metrics.write(
                json.dumps(
                    record,
                    ensure_ascii=False,
                    allow_nan=False,
                    sort_keys=True,
                    separators=(",", ":"),
                )
                + "\n"
            )
            metrics.flush()
            os.fsync(metrics.fileno())
            objective = validation["total"]
            if objective < best_objective - 1e-12:
                best_objective = objective
                best_update = update
                best_validation = validation
                stale_evaluations = 0
                _atomic_torch_save(
                    checkpoint_path,
                    _checkpoint_payload(
                        model,
                        config=config,
                        normalizer=normalizer,
                        update=update,
                        validation_losses=validation,
                        corpus_report=corpus.report,
                    ),
                )
            else:
                stale_evaluations += 1
            if (
                update >= config.minimum_updates
                and stale_evaluations >= config.early_stopping_patience
            ):
                stopped_early = True
                break

    if best_validation is None or best_update <= 0 or not checkpoint_path.is_file():
        raise RuntimeError("Full Crysalis training produced no selected checkpoint")
    wall_seconds = time.perf_counter() - started
    peak_vram = (
        int(torch.cuda.max_memory_allocated(device))
        if device.type == "cuda"
        else 0
    )
    report: dict[str, Any] = {
        "schema_version": "g1-full-crysalis-training-report.1.0.0",
        "status": "PASS",
        "root_seed": config.root_seed,
        "device": config.device,
        "completed_updates": completed_updates,
        "minimum_updates": config.minimum_updates,
        "maximum_updates": config.maximum_updates,
        "best_update": best_update,
        "stopped_early": stopped_early,
        "best_validation_losses": best_validation,
        "checkpoint_selection_metric": (
            "structure_ood_validation_total_loss"
        ),
        "generation_metrics_used": False,
        "next_orbit_loss_present": False,
        "removal_order_loss_present": False,
        "gradient_flow": gradient_flow,
        "loss_weights": dict(config.loss_weights),
        "train_fit_parent_count": len(train_parents),
        "validation_parent_count": len(validation_parents),
        "train_fit_event_count": len(corpus.train_events),
        "validation_event_count": len(corpus.validation_events),
        "parameter_count": sum(parameter.numel() for parameter in model.parameters()),
        "batch_size": config.batch_size,
        "validation_batch_size": config.validation_batch_size,
        "peak_allocated_vram_bytes": peak_vram,
        "wall_seconds": wall_seconds,
        "checkpoint_file": checkpoint_path.name,
        "checkpoint_sha256": sha256_file(checkpoint_path),
        "metrics_file": metrics_path.name,
        "metrics_sha256": sha256_file(metrics_path),
        "sealed_or_blind_data_accessed": False,
        "retry_count": 0,
        "refill_count": 0,
        "ablation_performed": False,
        "isolated_module_audit_performed": False,
    }
    _write_json_atomic(report_path, report)
    return report


class _PreflightPredictor:
    version = "0.3.0"

    def predict_structure(
        self,
        structures: Sequence[Structure],
        *,
        task: str,
        batch_size: int,
    ) -> list[dict[str, Any]]:
        if task != "ef" or batch_size <= 0:
            raise ValueError("preflight GuideMLIP call contract drifted")
        return [
            {
                "e": -1.0,
                "f": np.full((len(structure), 3), 0.01, dtype=float),
            }
            for structure in structures
        ]


def _influence_checks(
    model: FullCrysalisModel,
    event: IntegratedEvent,
    normalizer: RelationNormalizer,
    device: torch.device,
) -> dict[str, bool]:
    batch = collate_integrated_events(
        (event,),
        normalizer=normalizer,
        maximum_orbits=model.geometry_generator.config.maximum_orbits,
    ).to(device)
    model.eval()
    with torch.no_grad():
        baseline = model(batch).free_parameters
        relation_changed = model(
            batch.with_pooled_relation(batch.pooled_relation + 0.5)
        ).free_parameters
        physics_changed = model(
            batch.with_physics_feedback(batch.physics_feedback + 0.25)
        ).free_parameters
    model.train()
    return {
        "persistent_relation_state_changes_geometry": not torch.allclose(
            baseline, relation_changed
        ),
        "physics_feedback_changes_geometry": not torch.allclose(
            baseline, physics_changed
        ),
    }


def run_engineering_preflight(
    config: FullCrysalisConfig,
    *,
    corpus: IntegratedCorpus | None = None,
    output_path: str | Path | None = None,
) -> dict[str, Any]:
    corpus = corpus or IntegratedCorpus.from_config(config)
    normalizer = RelationNormalizer.fit(corpus.train_events)
    probe_event = next(
        event for event in corpus.train_events if event.relation_targets
    )
    loop_config = TrainingLoopConfig.from_full_config(config)
    _seed_everything(config.root_seed)
    cpu = torch.device("cpu")
    cpu_model = FullCrysalisModel(
        relation_config=loop_config.relation_config,
        geometry_config=loop_config.geometry_config,
        loss_weights=loop_config.loss_weights,
    )
    cpu_gradient = _gradient_flow_probe(cpu_model, corpus, normalizer, cpu)
    influence = _influence_checks(cpu_model, probe_event, normalizer, cpu)

    guide = GuideMLIP.from_predictor(
        _PreflightPredictor(),
        weight_sha256=config.artifacts["chgnet_weights"].sha256,
        batch_size=config.physics.guide_batch_size,
    )
    structure = Structure(
        Lattice.cubic(5.0),
        (8, 14),
        ((0.1, 0.1, 0.1), (0.6, 0.6, 0.6)),
    )
    guide_feedback = guide.evaluate_candidates((structure,), ((1, 2),))[0]
    guide_vector = torch.tensor(guide_feedback.vector, dtype=torch.float32)[None, :]
    probe_batch = collate_integrated_events(
        (probe_event,),
        normalizer=normalizer,
        maximum_orbits=loop_config.geometry_config.maximum_orbits,
    )
    with torch.no_grad():
        before_guide = cpu_model(probe_batch).free_parameters
        after_guide = cpu_model(
            probe_batch.with_physics_feedback(guide_vector)
        ).free_parameters
    guide_enters_geometry = not torch.allclose(before_guide, after_guide)

    cuda_report: dict[str, Any] = {
        "available": torch.cuda.is_available(),
        "executed": False,
        "completed_updates": 0,
        "peak_allocated_vram_bytes": 0,
        "effective_batch_size": loop_config.batch_size,
        "batch_size_adapted": False,
    }
    if config.training.device == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("formal CUDA preflight requested but CUDA is unavailable")
        device = torch.device("cuda")
        effective_batch_size = loop_config.batch_size
        attempted_adaptation = False
        while True:
            try:
                torch.cuda.empty_cache()
                torch.cuda.reset_peak_memory_stats(device)
                cuda_model = FullCrysalisModel(
                    relation_config=loop_config.relation_config,
                    geometry_config=loop_config.geometry_config,
                    loss_weights=loop_config.loss_weights,
                ).to(device)
                optimizer = torch.optim.AdamW(
                    cuda_model.parameters(),
                    lr=loop_config.learning_rate,
                    weight_decay=loop_config.weight_decay,
                )
                selected = tuple(
                    islice(cycle(corpus.train_events), effective_batch_size)
                )
                for _ in range(config.training.preflight_updates):
                    batch = collate_integrated_events(
                        selected,
                        normalizer=normalizer,
                        maximum_orbits=loop_config.geometry_config.maximum_orbits,
                    ).to(device)
                    optimizer.zero_grad(set_to_none=True)
                    values = cuda_model(batch)
                    losses = compute_full_crysalis_losses(
                        values,
                        batch,
                        cuda_model.loss_weights,
                    )
                    losses.total.backward()
                    if not _finite_gradients(cuda_model):
                        raise FloatingPointError(
                            "non-finite CUDA preflight gradients"
                        )
                    torch.nn.utils.clip_grad_norm_(
                        cuda_model.parameters(),
                        loop_config.gradient_clip_norm,
                    )
                    optimizer.step()
                free_bytes, total_bytes = torch.cuda.mem_get_info(device)
                peak = int(torch.cuda.max_memory_allocated(device))
                safety_margin = (total_bytes - peak) / total_bytes
                cuda_report = {
                    "available": True,
                    "executed": True,
                    "completed_updates": config.training.preflight_updates,
                    "peak_allocated_vram_bytes": peak,
                    "free_vram_bytes_after": int(free_bytes),
                    "total_vram_bytes": int(total_bytes),
                    "measured_safety_margin": safety_margin,
                    "effective_batch_size": (
                        effective_batch_size
                        if safety_margin >= 0.15
                        else max(1, effective_batch_size // 2)
                    ),
                    "batch_size_adapted": (
                        attempted_adaptation or safety_margin < 0.15
                    ),
                }
                del cuda_model, optimizer, batch, values, losses
                torch.cuda.empty_cache()
                break
            except torch.OutOfMemoryError:
                torch.cuda.empty_cache()
                if attempted_adaptation or effective_batch_size <= 1:
                    raise
                attempted_adaptation = True
                effective_batch_size = max(1, effective_batch_size // 2)

    checks = {
        "cpu_forward_backward_finite": all(cpu_gradient.values()),
        "relation_to_geometry_gradient": cpu_gradient[
            "relation_to_geometry"
        ],
        **influence,
        "guide_feedback_enters_geometry": guide_enters_geometry,
        "guide_role_separated": guide.provenance["role"]
        == "GENERATION_GUIDE_ONLY",
        "sealed_or_blind_data_accessed": False,
        "next_orbit_loss_present": False,
        "ablation_performed": False,
    }
    positive_checks = (
        "cpu_forward_backward_finite",
        "relation_to_geometry_gradient",
        "persistent_relation_state_changes_geometry",
        "physics_feedback_changes_geometry",
        "guide_feedback_enters_geometry",
        "guide_role_separated",
    )
    negative_checks = (
        "sealed_or_blind_data_accessed",
        "next_orbit_loss_present",
        "ablation_performed",
    )
    if not all(checks[name] is True for name in positive_checks) or not all(
        checks[name] is False for name in negative_checks
    ):
        raise RuntimeError(f"Full Crysalis engineering preflight failed: {checks}")
    report = {
        "schema_version": "g1-full-crysalis-preflight.1.0.0",
        "status": "PASS",
        "root_seed": config.root_seed,
        "checks": checks,
        "cuda": cuda_report,
        "formal_relation_replay_pass_count": corpus.report.get(
            "formal_relation_replay_pass_count"
        ),
        "parent_count": corpus.report["parent_count"],
        "event_count": corpus.report["unique_event_count"],
    }
    if output_path is not None:
        target = Path(output_path)
        if target.exists():
            raise FileExistsError(f"preflight refuses to overwrite: {target}")
        _write_json_atomic(target, report)
    return report


def train_full_crysalis(
    config: FullCrysalisConfig,
    *,
    corpus: IntegratedCorpus | None = None,
    effective_batch_size: int | None = None,
) -> dict[str, Any]:
    corpus = corpus or IntegratedCorpus.from_config(config)
    loop_config = TrainingLoopConfig.from_full_config(
        config,
        effective_batch_size=effective_batch_size,
    )
    return train_on_corpus(
        corpus,
        loop_config,
        output_dir=Path(config.output_root) / "training",
    )
