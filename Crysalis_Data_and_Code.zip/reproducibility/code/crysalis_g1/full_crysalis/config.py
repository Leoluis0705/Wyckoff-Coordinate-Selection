from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping


SCHEMA_VERSION = "g1-full-crysalis.1.0.0"
ROOT_SEED = 20260823
LOSS_WEIGHTS = {
    "relation": 1.0,
    "free_parameters": 2.0,
    "representative_geometry": 1.0,
    "lattice": 0.5,
    "physics_consistency": 0.25,
    "termination": 0.25,
}
FORBIDDEN_AUTHORIZATIONS = (
    "ablation",
    "isolated_scientific_audit",
    "contribution_lock",
    "three_seed_module_audit",
    "server",
    "dft",
    "sealed_or_blind_access",
    "retry",
    "refill",
)


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _positive_int(value: Any, label: str) -> int:
    if type(value) is not int or value <= 0:
        raise ValueError(f"{label} must be a positive integer")
    return value


def _finite_positive(value: Any, label: str) -> float:
    number = float(value)
    if not math.isfinite(number) or number <= 0:
        raise ValueError(f"{label} must be finite and positive")
    return number


@dataclass(frozen=True, slots=True)
class FrozenArtifact:
    path: str
    sha256: str

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> FrozenArtifact:
        path = str(payload["path"])
        digest = str(payload["sha256"]).lower()
        try:
            raw = bytes.fromhex(digest)
        except ValueError as error:
            raise ValueError(f"invalid SHA-256 for {path}") from error
        if len(raw) != 32:
            raise ValueError(f"invalid SHA-256 for {path}")
        return cls(path=path, sha256=digest)


@dataclass(frozen=True, slots=True)
class RelationConfig:
    backend: str
    embedding_dim: int
    hidden_dim: int
    latent_dim: int
    kan_grid_size: int
    kan_layer_count: int

    def __post_init__(self) -> None:
        if self.backend != "kan":
            raise ValueError("the formal Relation Function Backend must be kan")
        for name in (
            "embedding_dim",
            "hidden_dim",
            "latent_dim",
            "kan_grid_size",
            "kan_layer_count",
        ):
            _positive_int(getattr(self, name), f"relation.{name}")
        if self.kan_grid_size < 3:
            raise ValueError("relation.kan_grid_size must be at least three")


@dataclass(frozen=True, slots=True)
class GeometryConfig:
    hidden_dim: int
    block_count: int
    radial_basis_count: int
    cutoff_angstrom: float
    coordinate_step_scale: float
    maximum_orbits: int
    maximum_sites: int
    maximum_cell_index: int

    def __post_init__(self) -> None:
        for name in (
            "hidden_dim",
            "block_count",
            "radial_basis_count",
            "maximum_orbits",
            "maximum_sites",
            "maximum_cell_index",
        ):
            _positive_int(getattr(self, name), f"geometry.{name}")
        if self.radial_basis_count < 2:
            raise ValueError("geometry.radial_basis_count must be at least two")
        _finite_positive(self.cutoff_angstrom, "geometry.cutoff_angstrom")
        _finite_positive(
            self.coordinate_step_scale, "geometry.coordinate_step_scale"
        )


@dataclass(frozen=True, slots=True)
class TrainingConfig:
    device: str
    minimum_updates: int
    maximum_updates: int
    batch_size: int
    validation_batch_size: int
    validation_interval: int
    early_stopping_patience: int
    learning_rate: float
    weight_decay: float
    gradient_clip_norm: float
    preflight_updates: int

    def __post_init__(self) -> None:
        if self.device not in {"cpu", "cuda"}:
            raise ValueError("training.device must be cpu or cuda")
        for name in (
            "minimum_updates",
            "maximum_updates",
            "batch_size",
            "validation_batch_size",
            "validation_interval",
            "early_stopping_patience",
            "preflight_updates",
        ):
            _positive_int(getattr(self, name), f"training.{name}")
        if self.minimum_updates != 3000 or self.maximum_updates != 8000:
            raise ValueError("formal training budget must remain 3000..8000 updates")
        if self.batch_size != 128 or self.validation_interval != 250:
            raise ValueError("formal batch size and validation interval drifted")
        if self.preflight_updates != 10:
            raise ValueError("engineering preflight must remain ten updates")
        _finite_positive(self.learning_rate, "training.learning_rate")
        if not math.isfinite(self.weight_decay) or self.weight_decay < 0:
            raise ValueError("training.weight_decay must be finite and non-negative")
        _finite_positive(self.gradient_clip_norm, "training.gradient_clip_norm")


@dataclass(frozen=True, slots=True)
class GenerationConfig:
    attempt_count: int
    maximum_orbits: int
    maximum_sites: int
    candidate_pool_size: int
    minimum_distance_angstrom: float
    orbit_proposal: str
    proposal_namespace: str
    candidate_namespace: str
    retry: bool
    refill: bool

    def __post_init__(self) -> None:
        if self.attempt_count != 300:
            raise ValueError("formal generation requires exactly 300 attempts")
        if self.maximum_orbits != 20 or self.maximum_sites != 20:
            raise ValueError("formal generation limits must remain 20 orbits/sites")
        if self.candidate_pool_size != 8:
            raise ValueError("formal geometry candidate pool must remain eight")
        if self.orbit_proposal != "UNIFORM_LEGAL":
            raise ValueError("orbit proposal must remain UNIFORM_LEGAL")
        if not self.proposal_namespace or not self.candidate_namespace:
            raise ValueError("generation namespaces must be non-empty")
        if self.retry or self.refill:
            raise ValueError("retry and refill are forbidden")
        if self.minimum_distance_angstrom != 0.5:
            raise ValueError("minimum-distance hard threshold must remain 0.5 Angstrom")


@dataclass(frozen=True, slots=True)
class PhysicsConfig:
    package_version: str
    model_version: str
    device: str
    guide_batch_size: int
    optimizer: str
    force_threshold_ev_per_angstrom: float
    maximum_steps: int
    short_contact_distance_angstrom: float
    guide_role: str
    evaluator_role: str

    def __post_init__(self) -> None:
        if self.package_version != "0.4.2" or self.model_version != "0.3.0":
            raise ValueError("CHGNet package/model provenance drifted")
        if self.device not in {"cpu", "cuda"}:
            raise ValueError("physics.device must be cpu or cuda")
        if self.optimizer != "FIRE" or self.maximum_steps != 300:
            raise ValueError("terminal evaluator must remain FIRE300")
        if self.guide_role != "GENERATION_GUIDE_ONLY":
            raise ValueError("GuideMLIP role drifted")
        if self.evaluator_role != "TERMINAL_EVALUATION_ONLY":
            raise ValueError("EvalMLIP role drifted")
        _positive_int(self.guide_batch_size, "physics.guide_batch_size")
        _finite_positive(
            self.force_threshold_ev_per_angstrom,
            "physics.force_threshold_ev_per_angstrom",
        )
        if self.short_contact_distance_angstrom != 0.5:
            raise ValueError("physics short-contact threshold must remain 0.5 Angstrom")


@dataclass(frozen=True, slots=True)
class AuthorizationConfig:
    full_model_implementation: bool
    full_model_training: bool
    full_model_generation: bool
    guide_physics: bool
    ablation: bool
    isolated_scientific_audit: bool
    contribution_lock: bool
    three_seed_module_audit: bool
    server: bool
    dft: bool
    sealed_or_blind_access: bool
    retry: bool
    refill: bool

    def __post_init__(self) -> None:
        required = (
            "full_model_implementation",
            "full_model_training",
            "full_model_generation",
            "guide_physics",
        )
        for name in required:
            if getattr(self, name) is not True:
                raise ValueError(f"{name} must be authorized")
        for name in FORBIDDEN_AUTHORIZATIONS:
            if getattr(self, name) is not False:
                raise ValueError(f"{name} is forbidden")


@dataclass(frozen=True, slots=True)
class FullCrysalisConfig:
    schema_version: str
    root_seed: int
    output_root: str
    artifacts: Mapping[str, FrozenArtifact]
    relation: RelationConfig
    geometry: GeometryConfig
    loss_weights: Mapping[str, float]
    training: TrainingConfig
    generation: GenerationConfig
    physics: PhysicsConfig
    authorization: AuthorizationConfig
    comparison_systems: tuple[str, str]

    def __post_init__(self) -> None:
        if self.schema_version != SCHEMA_VERSION:
            raise ValueError("unsupported Full Crysalis config schema")
        if self.root_seed != ROOT_SEED:
            raise ValueError("ROOT_SEED must remain 20260823")
        if not self.output_root:
            raise ValueError("output_root must be non-empty")
        if not self.artifacts:
            raise ValueError("frozen artifacts must not be empty")
        weights = {name: float(value) for name, value in self.loss_weights.items()}
        if weights != LOSS_WEIGHTS:
            raise ValueError("full-model loss weights drifted")
        if self.comparison_systems != ("C0_FROZEN", "FULL_CRYSALIS"):
            raise ValueError("first-round comparison must contain only C0 and FULL")
        if self.geometry.maximum_orbits != self.generation.maximum_orbits:
            raise ValueError("geometry/generation maximum_orbits mismatch")
        if self.geometry.maximum_sites != self.generation.maximum_sites:
            raise ValueError("geometry/generation maximum_sites mismatch")

    @classmethod
    def from_json(cls, path: str | Path) -> FullCrysalisConfig:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        artifacts = {
            str(name): FrozenArtifact.from_dict(value)
            for name, value in payload["artifacts"].items()
        }
        return cls(
            schema_version=str(payload["schema_version"]),
            root_seed=int(payload["root_seed"]),
            output_root=str(payload["output_root"]),
            artifacts=artifacts,
            relation=RelationConfig(**payload["relation"]),
            geometry=GeometryConfig(**payload["geometry"]),
            loss_weights={
                str(name): float(value)
                for name, value in payload["loss_weights"].items()
            },
            training=TrainingConfig(**payload["training"]),
            generation=GenerationConfig(**payload["generation"]),
            physics=PhysicsConfig(**payload["physics"]),
            authorization=AuthorizationConfig(**payload["authorization"]),
            comparison_systems=tuple(payload["comparison_systems"]),
        )


def verify_frozen_artifacts(config: FullCrysalisConfig) -> dict[str, str]:
    observed: dict[str, str] = {}
    for name, artifact in config.artifacts.items():
        path = Path(artifact.path)
        if not path.is_file():
            raise FileNotFoundError(f"frozen artifact is missing: {name}: {path}")
        digest = sha256_file(path)
        if digest != artifact.sha256:
            raise ValueError(
                f"frozen artifact hash mismatch for {name}: "
                f"expected {artifact.sha256}, observed {digest}"
            )
        observed[name] = digest

    phase2a = json.loads(
        Path(config.artifacts["phase2a_manifest"].path).read_text(encoding="utf-8")
    )
    if phase2a.get("sealed_or_blind_data_accessed") is not False:
        raise ValueError("Phase2A public-only boundary is not proven")
    if phase2a.get("no_refill") is not True:
        raise ValueError("Phase2A no-refill boundary is not proven")

    c0 = json.loads(
        Path(config.artifacts["c0_manifest"].path).read_text(encoding="utf-8")
    )
    if c0.get("sealed_or_blind_data_accessed") is not False:
        raise ValueError("C0 public-only boundary is not proven")
    if c0.get("server_used") is not False or c0.get("dft_used") is not False:
        raise ValueError("C0 server/DFT boundary drifted")
    if int(c0.get("refill_count", -1)) != 0 or int(c0.get("root_seed", -1)) != ROOT_SEED:
        raise ValueError("C0 refill/root-seed boundary drifted")

    conditions = json.loads(
        Path(config.artifacts["condition_manifest"].path).read_text(encoding="utf-8")
    )
    if len(conditions.get("conditions", ())) != config.generation.attempt_count:
        raise ValueError("frozen condition-manifest denominator drifted")
    forbidden_condition_flags = (
        "material_id_lookup_present",
        "parent_coordinates_present",
        "parent_lattice_present",
        "true_orbit_count_present",
        "true_termination_step_present",
        "true_wyckoff_sequence_present",
    )
    if any(conditions.get(name) is not False for name in forbidden_condition_flags):
        raise ValueError("condition manifest exposes forbidden parent information")
    return observed
