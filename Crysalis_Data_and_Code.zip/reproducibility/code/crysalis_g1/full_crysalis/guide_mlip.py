from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
from pymatgen.core import Structure

from crysalis_g1.full_crysalis.config import (
    FullCrysalisConfig,
    sha256_file,
)
from crysalis_g1.full_crysalis.state import PhysicsFeedback


@dataclass(frozen=True, slots=True)
class _RawFeedback:
    energy_per_atom_ev: float | None
    mean_force: float
    max_force: float
    candidate_max_force: float
    minimum_distance: float | None
    overlap_risk: float
    locally_feasible: bool
    mlip_applicable: bool
    reason_codes: tuple[str, ...]


def _as_numpy(value: Any) -> np.ndarray:
    if hasattr(value, "detach"):
        value = value.detach().cpu().numpy()
    return np.asarray(value, dtype=float)


def _minimum_distance(structure: Structure) -> float | None:
    if len(structure) <= 1:
        return None
    distances = np.asarray(structure.distance_matrix, dtype=float).copy()
    np.fill_diagonal(distances, np.inf)
    finite = distances[np.isfinite(distances)]
    if not len(finite):
        return None
    value = float(finite.min())
    if not math.isfinite(value) or value < 0:
        raise FloatingPointError("GuideMLIP produced a non-finite contact distance")
    return value


def _normalized_ranks(values: Sequence[float | None]) -> tuple[float, ...]:
    if not values:
        return ()
    sortable = [math.inf if value is None else float(value) for value in values]
    if any(math.isnan(value) for value in sortable):
        raise FloatingPointError("GuideMLIP ranking received NaN")
    if len(sortable) == 1:
        return (0.0,)
    order = sorted(range(len(sortable)), key=lambda index: (sortable[index], index))
    ranks = [0.0] * len(sortable)
    start = 0
    while start < len(order):
        stop = start + 1
        while stop < len(order) and sortable[order[stop]] == sortable[order[start]]:
            stop += 1
        average = ((start + stop - 1) / 2.0) / (len(order) - 1)
        for position in range(start, stop):
            ranks[order[position]] = average
        start = stop
    return tuple(ranks)


def physics_rank(feedback: PhysicsFeedback) -> float:
    value = (
        feedback.relative_energy_rank
        + feedback.max_force_rank
        + feedback.candidate_force_rank
    ) / 3.0
    if not math.isfinite(value) or not 0 <= value <= 1:
        raise ValueError("GuideMLIP physics rank lies outside [0, 1]")
    return float(value)


class GuideMLIP:
    """Frozen CHGNet instance used only inside candidate geometry generation."""

    def __init__(
        self,
        predictor: Any,
        *,
        weight_sha256: str,
        batch_size: int = 8,
        force_threshold_ev_per_angstrom: float = 0.2,
        short_contact_distance_angstrom: float = 0.5,
        package_version: str = "0.4.2",
        model_version: str = "0.3.0",
    ) -> None:
        try:
            digest = bytes.fromhex(weight_sha256)
        except ValueError as error:
            raise ValueError("invalid GuideMLIP weight SHA-256") from error
        if len(digest) != 32:
            raise ValueError("invalid GuideMLIP weight SHA-256")
        if type(batch_size) is not int or batch_size <= 0:
            raise ValueError("GuideMLIP batch size must be a positive integer")
        if (
            not math.isfinite(force_threshold_ev_per_angstrom)
            or force_threshold_ev_per_angstrom <= 0
            or not math.isfinite(short_contact_distance_angstrom)
            or short_contact_distance_angstrom <= 0
        ):
            raise ValueError("GuideMLIP thresholds must be finite and positive")
        if str(getattr(predictor, "version", model_version)) != model_version:
            raise RuntimeError("loaded GuideMLIP model version mismatch")
        self.predictor = predictor
        self.batch_size = batch_size
        self.force_threshold = float(force_threshold_ev_per_angstrom)
        self.short_contact_distance = float(short_contact_distance_angstrom)
        self.provenance: Mapping[str, Any] = {
            "role": "GENERATION_GUIDE_ONLY",
            "package_version": package_version,
            "model_version": model_version,
            "weight_sha256": weight_sha256.lower(),
            "terminal_evaluator_instance": False,
            "isolated_partial_proxy": True,
            "neighbor_applicability_cutoff_angstrom": 5.0,
        }

    @classmethod
    def from_predictor(
        cls,
        predictor: Any,
        *,
        weight_sha256: str,
        batch_size: int = 8,
        force_threshold_ev_per_angstrom: float = 0.2,
        short_contact_distance_angstrom: float = 0.5,
    ) -> GuideMLIP:
        return cls(
            predictor,
            weight_sha256=weight_sha256,
            batch_size=batch_size,
            force_threshold_ev_per_angstrom=(
                force_threshold_ev_per_angstrom
            ),
            short_contact_distance_angstrom=(
                short_contact_distance_angstrom
            ),
        )

    @classmethod
    def from_config(cls, config: FullCrysalisConfig) -> GuideMLIP:
        import chgnet
        from chgnet.model import CHGNet

        if chgnet.__version__ != config.physics.package_version:
            raise RuntimeError(
                "GuideMLIP package version mismatch: "
                f"{chgnet.__version__} != {config.physics.package_version}"
            )
        artifact = config.artifacts["chgnet_weights"]
        weight_path = Path(artifact.path)
        if not weight_path.is_file():
            raise FileNotFoundError(f"GuideMLIP weight is missing: {weight_path}")
        observed = sha256_file(weight_path)
        if observed != artifact.sha256:
            raise ValueError(
                "GuideMLIP weight hash mismatch: "
                f"{observed} != {artifact.sha256}"
            )
        predictor = CHGNet.load(
            model_name=config.physics.model_version,
            use_device=config.physics.device,
            verbose=False,
        )
        return cls(
            predictor,
            weight_sha256=artifact.sha256,
            batch_size=config.physics.guide_batch_size,
            force_threshold_ev_per_angstrom=(
                config.physics.force_threshold_ev_per_angstrom
            ),
            short_contact_distance_angstrom=(
                config.physics.short_contact_distance_angstrom
            ),
            package_version=config.physics.package_version,
            model_version=config.physics.model_version,
        )

    @staticmethod
    def _proxy_reason(structure: Structure) -> str | None:
        if len(structure) <= 1:
            return "ISOLATED_PARTIAL_PROXY"
        if max(int(site.specie.Z) for site in structure) > 94:
            return "UNSUPPORTED_ELEMENT_PROXY"
        distances = np.asarray(structure.distance_matrix, dtype=float).copy()
        np.fill_diagonal(distances, np.inf)
        nearest = distances.min(axis=1)
        if bool(np.any(nearest > 5.0)):
            return "NO_CHGNET_NEIGHBOR_PROXY"
        return None

    def _proxy(self, structure: Structure, reason: str) -> _RawFeedback:
        minimum = _minimum_distance(structure)
        overlap = (
            0.0
            if minimum is None
            else min(
                1.0,
                max(
                    0.0,
                    (self.short_contact_distance - minimum)
                    / self.short_contact_distance,
                ),
            )
        )
        force_proxy = overlap * 10.0
        return _RawFeedback(
            energy_per_atom_ev=None,
            mean_force=force_proxy,
            max_force=force_proxy,
            candidate_max_force=force_proxy,
            minimum_distance=minimum,
            overlap_risk=overlap,
            locally_feasible=overlap == 0.0,
            mlip_applicable=False,
            reason_codes=(reason,),
        )

    def _prediction_feedback(
        self,
        structure: Structure,
        prediction: Mapping[str, Any],
        candidate_slice: tuple[int, int],
    ) -> _RawFeedback:
        if "e" not in prediction or "f" not in prediction:
            raise ValueError("GuideMLIP prediction lacks energy or forces")
        energy_values = _as_numpy(prediction["e"])
        if energy_values.size != 1:
            raise ValueError("GuideMLIP energy must be scalar")
        energy = float(energy_values.reshape(-1)[0])
        forces = _as_numpy(prediction["f"])
        if forces.shape != (len(structure), 3):
            raise ValueError("GuideMLIP force shape does not match the structure")
        if not math.isfinite(energy) or not np.isfinite(forces).all():
            raise FloatingPointError("non-finite GuideMLIP energy or force")
        force_norms = np.linalg.norm(forces, axis=1)
        start, stop = candidate_slice
        candidate_force = float(force_norms[start:stop].max())
        mean_force = float(force_norms.mean())
        max_force = float(force_norms.max())
        minimum = _minimum_distance(structure)
        overlap = (
            0.0
            if minimum is None
            else float(minimum < self.short_contact_distance)
        )
        return _RawFeedback(
            energy_per_atom_ev=energy,
            mean_force=mean_force,
            max_force=max_force,
            candidate_max_force=candidate_force,
            minimum_distance=minimum,
            overlap_risk=overlap,
            locally_feasible=(
                overlap == 0.0 and candidate_force <= self.force_threshold
            ),
            mlip_applicable=True,
            reason_codes=(),
        )

    def evaluate_candidates(
        self,
        structures: Sequence[Structure],
        candidate_slices: Sequence[tuple[int, int]],
    ) -> tuple[PhysicsFeedback, ...]:
        structures = tuple(structures)
        slices = tuple(candidate_slices)
        if not structures or len(structures) != len(slices):
            raise ValueError(
                "GuideMLIP structures and candidate slices must align and be non-empty"
            )
        for structure, (start, stop) in zip(structures, slices, strict=True):
            if len(structure) == 0 or not 0 <= start < stop <= len(structure):
                raise ValueError("GuideMLIP candidate slice is invalid")

        raw: list[_RawFeedback | None] = [None] * len(structures)
        applicable_indices = []
        applicable_structures = []
        for index, structure in enumerate(structures):
            reason = self._proxy_reason(structure)
            if reason is None:
                applicable_indices.append(index)
                applicable_structures.append(structure)
            else:
                raw[index] = self._proxy(structure, reason)
        if applicable_structures:
            predictions = self.predictor.predict_structure(
                applicable_structures,
                task="ef",
                batch_size=self.batch_size,
            )
            if isinstance(predictions, Mapping):
                predictions = [predictions]
            if len(predictions) != len(applicable_indices):
                raise ValueError("GuideMLIP prediction count mismatch")
            for index, prediction in zip(
                applicable_indices,
                predictions,
                strict=True,
            ):
                raw[index] = self._prediction_feedback(
                    structures[index],
                    prediction,
                    slices[index],
                )
        if any(item is None for item in raw):
            raise AssertionError("GuideMLIP left a candidate unevaluated")
        complete = tuple(item for item in raw if item is not None)
        energy_ranks = _normalized_ranks(
            tuple(item.energy_per_atom_ev for item in complete)
        )
        force_ranks = _normalized_ranks(
            tuple(item.max_force for item in complete)
        )
        candidate_ranks = _normalized_ranks(
            tuple(item.candidate_max_force for item in complete)
        )
        return tuple(
            PhysicsFeedback(
                energy_per_atom_ev=item.energy_per_atom_ev,
                relative_energy_rank=energy_ranks[index],
                mean_force_ev_per_angstrom=item.mean_force,
                max_force_ev_per_angstrom=item.max_force,
                candidate_max_force_ev_per_angstrom=item.candidate_max_force,
                minimum_distance_angstrom=item.minimum_distance,
                overlap_risk=item.overlap_risk,
                locally_feasible=item.locally_feasible,
                mlip_applicable=item.mlip_applicable,
                reason_codes=item.reason_codes,
                max_force_rank=force_ranks[index],
                candidate_force_rank=candidate_ranks[index],
            )
            for index, item in enumerate(complete)
        )
