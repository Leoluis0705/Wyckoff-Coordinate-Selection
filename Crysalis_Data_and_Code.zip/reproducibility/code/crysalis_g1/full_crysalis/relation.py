from __future__ import annotations

import math
from abc import ABC, abstractmethod
from dataclasses import dataclass

import torch
import torch.nn.functional as F
from torch import nn

from crysalis_g1.experiments.local_relation_learning import LinearSplineKANLayer
from crysalis_g1.full_crysalis.data import IntegratedBatch


@dataclass(frozen=True, slots=True)
class RelationBackendConfig:
    numeric_dim: int
    embedding_dim: int = 16
    hidden_dim: int = 96
    latent_dim: int = 32
    grid_size: int = 15
    layer_count: int = 2

    def __post_init__(self) -> None:
        values = (
            self.numeric_dim,
            self.embedding_dim,
            self.hidden_dim,
            self.latent_dim,
            self.grid_size,
            self.layer_count,
        )
        if any(type(value) is not int or value <= 0 for value in values):
            raise ValueError("relation backend dimensions must be positive integers")
        if self.grid_size < 3:
            raise ValueError("relation KAN grid size must be at least three")
        if self.layer_count < 2:
            raise ValueError("relation KAN requires at least two spline layers")


@dataclass(frozen=True, slots=True)
class RelationRestorationOutput:
    presence_logits: torch.Tensor
    continuous: torch.Tensor
    latent: torch.Tensor


class RelationFunctionBackend(nn.Module, ABC):
    """Shared interface for relation-transition laws used inside generation."""

    @abstractmethod
    def forward(self, batch: IntegratedBatch) -> RelationRestorationOutput:
        raise NotImplementedError


class SplineKANRelationBackend(RelationFunctionBackend):
    def __init__(self, config: RelationBackendConfig) -> None:
        super().__init__()
        self.config = config
        self.space_group_embedding = nn.Embedding(231, config.embedding_dim)
        self.species_embedding = nn.Embedding(119, config.embedding_dim)
        self.wyckoff_embedding = nn.Embedding(26, config.embedding_dim)
        input_dim = config.numeric_dim + 5 * config.embedding_dim
        dimensions = [input_dim]
        dimensions.extend([config.hidden_dim] * (config.layer_count - 1))
        dimensions.append(config.latent_dim)
        self.spline_layers = nn.ModuleList(
            LinearSplineKANLayer(source, target, config.grid_size)
            for source, target in zip(dimensions, dimensions[1:])
        )
        self.presence_head = nn.Linear(config.latent_dim, 1)
        self.continuous_head = nn.Linear(config.latent_dim, 7)

    def _empty_output(self) -> RelationRestorationOutput:
        anchor = sum(parameter.sum() for parameter in self.parameters()) * 0.0
        return RelationRestorationOutput(
            presence_logits=anchor.reshape(1, 1).expand(0, 1),
            continuous=anchor.reshape(1, 1).expand(0, 7),
            latent=anchor.reshape(1, 1).expand(0, self.config.latent_dim),
        )

    def forward(self, batch: IntegratedBatch) -> RelationRestorationOutput:
        numeric = batch.relation_numeric_features
        if numeric.ndim != 2 or numeric.shape[1] != self.config.numeric_dim:
            raise ValueError("relation backend numeric feature width mismatch")
        if numeric.shape[0] == 0:
            return self._empty_output()
        pair_count = numeric.shape[0]
        categorical = (
            batch.relation_target_space_group,
            batch.relation_candidate_species,
            batch.relation_candidate_wyckoff,
            batch.relation_existing_species,
            batch.relation_existing_wyckoff,
        )
        if any(values.shape != (pair_count,) for values in categorical):
            raise ValueError("relation backend categorical shape mismatch")
        values = torch.cat(
            (
                self.space_group_embedding(batch.relation_target_space_group),
                self.species_embedding(batch.relation_candidate_species),
                self.wyckoff_embedding(batch.relation_candidate_wyckoff),
                self.species_embedding(batch.relation_existing_species),
                self.wyckoff_embedding(batch.relation_existing_wyckoff),
                numeric,
            ),
            dim=-1,
        )
        hidden = torch.sigmoid(values)
        for layer_index, layer in enumerate(self.spline_layers):
            hidden = layer(hidden)
            if layer_index + 1 < len(self.spline_layers):
                hidden = torch.sigmoid(hidden)
        latent = torch.tanh(hidden)
        output = RelationRestorationOutput(
            presence_logits=self.presence_head(latent),
            continuous=self.continuous_head(latent),
            latent=latent,
        )
        tensors = (output.presence_logits, output.continuous, output.latent)
        if any(not bool(torch.isfinite(tensor).all()) for tensor in tensors):
            raise FloatingPointError("non-finite KAN relation restoration output")
        return output


@dataclass(frozen=True, slots=True)
class RelationRestorationLoss:
    total: torch.Tensor
    presence: torch.Tensor
    continuous: torch.Tensor


def relation_restoration_loss(
    output: RelationRestorationOutput,
    batch: IntegratedBatch,
) -> RelationRestorationLoss:
    if output.presence_logits.shape != batch.relation_presence_target.shape:
        raise ValueError("relation presence output shape mismatch")
    if output.continuous.shape != batch.relation_continuous_target.shape:
        raise ValueError("relation continuous output shape mismatch")
    if output.latent.shape != (
        batch.relation_numeric_features.shape[0],
        output.latent.shape[-1],
    ):
        raise ValueError("relation latent output shape mismatch")
    if output.presence_logits.shape[0] == 0:
        zero = output.presence_logits.sum() + output.continuous.sum()
        return RelationRestorationLoss(total=zero, presence=zero, continuous=zero)
    presence = F.binary_cross_entropy_with_logits(
        output.presence_logits,
        batch.relation_presence_target,
    )
    elementwise = F.smooth_l1_loss(
        output.continuous,
        batch.relation_continuous_target,
        reduction="none",
    )
    mask = batch.relation_continuous_mask.expand_as(elementwise)
    continuous = (elementwise * mask).sum() / mask.sum().clamp_min(1.0)
    total = presence + continuous
    if any(
        not math.isfinite(float(value.detach()))
        for value in (total, presence, continuous)
    ):
        raise FloatingPointError("non-finite relation restoration loss")
    return RelationRestorationLoss(
        total=total,
        presence=presence,
        continuous=continuous,
    )
