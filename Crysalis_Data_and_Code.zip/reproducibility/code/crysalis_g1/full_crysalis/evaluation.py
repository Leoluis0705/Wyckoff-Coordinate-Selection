from __future__ import annotations

import json
import math
import os
from dataclasses import asdict
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer

from crysalis_g1.experiments.chgnet_terminal import (
    CHGNetEvaluationConfig,
    CHGNetTerminalEvaluator,
)
from crysalis_g1.full_crysalis.config import FullCrysalisConfig, sha256_file


SYMPREC_VALUES = (0.01, 0.03, 0.05, 0.10)


def _write_json_atomic(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            allow_nan=False,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def _force_summary(values: Sequence[float]) -> dict[str, Any]:
    array = np.asarray(tuple(float(value) for value in values), dtype=float)
    if array.size == 0:
        return {
            "sample_count": 0,
            "mean": None,
            "median": None,
            "p90": None,
            "p95": None,
        }
    if not np.isfinite(array).all():
        raise FloatingPointError("non-finite EvalMLIP force summary")
    return {
        "sample_count": int(array.size),
        "mean": float(array.mean()),
        "median": float(np.median(array)),
        "p90": float(np.quantile(array, 0.90)),
        "p95": float(np.quantile(array, 0.95)),
    }


def summarize_protocol(
    records: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    if not records:
        raise ValueError("EvalMLIP protocol summary requires records")
    attempt_count = len(records)
    evaluated = [record for record in records if record.get("status") == "EVALUATED"]
    initial_forces = [
        float(record["pre_max_force_ev_per_angstrom"])
        for record in evaluated
        if record.get("pre_max_force_ev_per_angstrom") is not None
    ]
    final_forces = [
        float(record["post_max_force_ev_per_angstrom"])
        for record in evaluated
        if record.get("post_max_force_ev_per_angstrom") is not None
    ]
    convergence_count = sum(bool(record.get("converged")) for record in records)
    physical_count = sum(
        bool(record.get("post_relax_survival")) for record in records
    )
    strict_count = sum(
        bool(record.get("strict_symmetry_preserving_survival"))
        for record in records
    )
    taxonomy = {
        status: sum(str(record.get("status")) == status for record in records)
        for status in sorted({str(record.get("status")) for record in records})
    }
    latencies = [
        float(record["latency_seconds"])
        for record in records
        if record.get("latency_seconds") is not None
    ]
    return {
        "attempt_count": attempt_count,
        "failure_denominator_includes_all_attempts": True,
        "evaluated_count": len(evaluated),
        "convergence_count": convergence_count,
        "convergence_rate_all_attempts": convergence_count / attempt_count,
        "physical_survival_count": physical_count,
        "physical_survival_rate_all_attempts": physical_count / attempt_count,
        "strict_symmetry_survival_count": strict_count,
        "strict_symmetry_survival_rate_all_attempts": strict_count / attempt_count,
        "initial_max_force_ev_per_angstrom": _force_summary(initial_forces),
        "final_max_force_ev_per_angstrom": _force_summary(final_forces),
        "failure_taxonomy": taxonomy,
        "latency_mean_seconds": (
            float(np.mean(latencies)) if latencies else None
        ),
        "latency_median_seconds": (
            float(np.median(latencies)) if latencies else None
        ),
    }


def decide_full_crysalis_signal(
    *,
    legal_delta: float,
    short_contact_delta: float,
    force_median_delta: float | None,
    force_p90_delta: float | None,
    fixed_symmetry_survival_delta: float,
    cell_symmetry_survival_delta: float,
) -> dict[str, Any]:
    required_values = (
        legal_delta,
        short_contact_delta,
        fixed_symmetry_survival_delta,
        cell_symmetry_survival_delta,
    )
    if any(not math.isfinite(float(value)) for value in required_values):
        raise ValueError("FULL_CRYSALIS_SIGNAL deltas must be finite")
    force_available = (
        force_median_delta is not None and force_p90_delta is not None
    )
    if force_available and (
        not math.isfinite(float(force_median_delta))
        or not math.isfinite(float(force_p90_delta))
    ):
        raise ValueError("FULL_CRYSALIS_SIGNAL force deltas must be finite")
    families = {
        "legal_terminal_rate": legal_delta > 0.0,
        "short_contact_rejection": short_contact_delta < 0.0,
        "initial_force_median_and_p90": (
            force_available
            and float(force_median_delta) < 0.0
            and float(force_p90_delta) < 0.0
        ),
        "fixed_cell_strict_symmetry_survival": (
            fixed_symmetry_survival_delta > 0.0
        ),
        "cell_relax_strict_symmetry_survival": (
            cell_symmetry_survival_delta > 0.0
        ),
    }
    improved_count = sum(families.values())
    strict_family_improved = bool(
        families["fixed_cell_strict_symmetry_survival"]
        or families["cell_relax_strict_symmetry_survival"]
    )
    no_large_decline = bool(
        legal_delta >= -0.02
        and fixed_symmetry_survival_delta >= -0.02
        and cell_symmetry_survival_delta >= -0.02
    )
    positive = improved_count >= 3 and strict_family_improved and no_large_decline
    return {
        "FULL_CRYSALIS_SIGNAL": "POSITIVE" if positive else "NO_POSITIVE_SIGNAL",
        "direction_families": families,
        "improved_family_count": improved_count,
        "strict_symmetry_family_improved": strict_family_improved,
        "initial_force_family_available": force_available,
        "no_guardrail_decline_beyond_0_02": no_large_decline,
        "deltas_full_minus_c0": {
            "legal_terminal_rate": legal_delta,
            "short_contact_rejection_rate": short_contact_delta,
            "initial_force_median_ev_per_angstrom": force_median_delta,
            "initial_force_p90_ev_per_angstrom": force_p90_delta,
            "fixed_cell_strict_symmetry_survival_rate": (
                fixed_symmetry_survival_delta
            ),
            "cell_relax_strict_symmetry_survival_rate": (
                cell_symmetry_survival_delta
            ),
        },
        "system_level_decision_only": True,
        "ablation_authorized": False,
        "isolated_module_conclusions_present": False,
    }


def _structure_from_payload(payload: Mapping[str, Any]) -> Structure:
    return Structure(
        Lattice(np.asarray(payload["lattice"], dtype=float)),
        [int(value) for value in payload["atomic_numbers"]],
        np.asarray(payload["fractional_coordinates"], dtype=float),
        to_unit_cell=True,
    )


def _augment_symmetry(record: Mapping[str, Any]) -> dict[str, Any]:
    result = dict(record)
    if result.get("status") != "EVALUATED":
        result["post_relax_detected_space_groups"] = {}
        result["strict_symmetry_preserving_survival"] = False
        return result
    structure = _structure_from_payload(result["final_structure"])
    detected = {}
    for symprec in SYMPREC_VALUES:
        try:
            number = int(
                SpacegroupAnalyzer(
                    structure,
                    symprec=symprec,
                    angle_tolerance=5.0,
                ).get_space_group_number()
            )
        except Exception:
            number = 0
        detected[f"{symprec:.2f}"] = number
    target = int(result["target_space_group"])
    strict_match = detected["0.03"] == target
    result["post_relax_detected_space_groups"] = detected
    result["strict_0_03_space_group_match"] = strict_match
    result["strict_symmetry_preserving_survival"] = bool(
        result.get("post_relax_survival") and strict_match
    )
    return result


class EvalMLIP:
    """Fresh terminal-only CHGNet role, separate from generation GuideMLIP."""

    def __init__(
        self,
        fixed_evaluator: CHGNetTerminalEvaluator,
        cell_evaluator: CHGNetTerminalEvaluator,
    ) -> None:
        self.fixed_evaluator = fixed_evaluator
        self.cell_evaluator = cell_evaluator
        self.provenance = {
            "role": "TERMINAL_EVALUATION_ONLY",
            "writes_generation_state": False,
            "enters_training_loss": False,
            "checkpoint_selection": False,
            "separate_from_guide_instance": True,
            "fixed_cell": asdict(fixed_evaluator.config),
            "cell_relax": asdict(cell_evaluator.config),
        }

    @classmethod
    def from_config(cls, config: FullCrysalisConfig) -> EvalMLIP:
        artifact = config.artifacts["chgnet_weights"]
        fixed_config = CHGNetEvaluationConfig(
            package_version=config.physics.package_version,
            model_version=config.physics.model_version,
            weight_path=artifact.path,
            weight_sha256=artifact.sha256,
            optimizer=config.physics.optimizer,
            force_threshold_ev_per_angstrom=(
                config.physics.force_threshold_ev_per_angstrom
            ),
            maximum_steps=config.physics.maximum_steps,
            relax_cell=False,
            short_contact_distance=(
                config.physics.short_contact_distance_angstrom
            ),
            device=config.physics.device,
        )
        cell_config = CHGNetEvaluationConfig(
            **{**asdict(fixed_config), "relax_cell": True}
        )
        fixed = CHGNetTerminalEvaluator(fixed_config)
        cell = CHGNetTerminalEvaluator(cell_config, optimizer=fixed.optimizer)
        return cls(fixed, cell)

    @staticmethod
    def _load_journal(path: Path) -> dict[str, dict[str, Any]]:
        completed = {}
        if not path.exists():
            return completed
        for line_number, line in enumerate(
            path.read_text(encoding="utf-8").splitlines(),
            1,
        ):
            try:
                record = json.loads(line)
            except json.JSONDecodeError as error:
                raise ValueError(
                    f"invalid EvalMLIP journal at {path}:{line_number}"
                ) from error
            condition_id = str(record["condition_id"])
            if condition_id in completed:
                raise ValueError(f"duplicate EvalMLIP journal record: {condition_id}")
            completed[condition_id] = record
        return completed

    def _run_protocol(
        self,
        evaluator: CHGNetTerminalEvaluator,
        records: Sequence[Mapping[str, Any]],
        *,
        journal_path: Path,
    ) -> tuple[dict[str, Any], ...]:
        journal_path.parent.mkdir(parents=True, exist_ok=True)
        completed = self._load_journal(journal_path)
        results = []
        with journal_path.open("a", encoding="utf-8", buffering=1) as stream:
            for generation_record in records:
                condition_id = str(
                    generation_record["condition"]["condition_id"]
                )
                if condition_id in completed:
                    result = completed[condition_id]
                else:
                    result = _augment_symmetry(
                        evaluator._evaluate_record(dict(generation_record))
                    )
                    stream.write(
                        json.dumps(
                            result,
                            ensure_ascii=False,
                            allow_nan=False,
                            sort_keys=True,
                            separators=(",", ":"),
                        )
                        + "\n"
                    )
                    stream.flush()
                    os.fsync(stream.fileno())
                    completed[condition_id] = result
                results.append(result)
        return tuple(results)

    def evaluate(
        self,
        records: Sequence[Mapping[str, Any]],
        *,
        output_dir: str | Path,
    ) -> dict[str, Any]:
        if not records:
            raise ValueError("EvalMLIP requires generation records")
        condition_ids = [
            str(record["condition"]["condition_id"]) for record in records
        ]
        if len(set(condition_ids)) != len(records):
            raise ValueError("EvalMLIP generation conditions are not unique")
        output = Path(output_dir)
        fixed = self._run_protocol(
            self.fixed_evaluator,
            records,
            journal_path=output / "fixed_cell_fire300_records.jsonl",
        )
        cell = self._run_protocol(
            self.cell_evaluator,
            records,
            journal_path=output / "cell_relax_fire300_records.jsonl",
        )
        payload = {
            "schema_version": "g1-full-crysalis-eval-mlip.1.0.0",
            "provenance": self.provenance,
            "attempt_count": len(records),
            "fixed_cell_fire300": {
                "summary": summarize_protocol(fixed),
                "records": fixed,
            },
            "cell_relax_fire300": {
                "summary": summarize_protocol(cell),
                "records": cell,
            },
            "retry_count": 0,
            "refill_count": 0,
            "sealed_or_blind_data_accessed": False,
            "dft_used": False,
            "ablation_performed": False,
        }
        summary_path = output / "physics_results.json"
        if summary_path.exists():
            raise FileExistsError(f"EvalMLIP refuses to overwrite: {summary_path}")
        _write_json_atomic(summary_path, payload)
        return payload


def run_full_evaluation(config: FullCrysalisConfig) -> dict[str, Any]:
    generation_path = Path(config.output_root) / "generation" / "generation_records.json"
    if not generation_path.is_file():
        raise FileNotFoundError(f"Full generation records are missing: {generation_path}")
    generation = json.loads(generation_path.read_text(encoding="utf-8"))
    if len(generation) != config.generation.attempt_count:
        raise ValueError("Full generation denominator drifted before EvalMLIP")
    evaluator = EvalMLIP.from_config(config)
    result = evaluator.evaluate(
        generation,
        output_dir=Path(config.output_root) / "evaluation",
    )
    result["generation_records_sha256"] = sha256_file(generation_path)
    return result
