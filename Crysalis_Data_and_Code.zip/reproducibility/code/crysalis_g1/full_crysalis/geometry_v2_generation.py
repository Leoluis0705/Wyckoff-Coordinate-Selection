from __future__ import annotations

import hashlib
import itertools
import json
import math
import os
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping, Protocol, Sequence

import numpy as np
import torch
from pymatgen.core import Lattice, Structure

from crysalis_g1.experiments.c0_symmetry_data import decode_lattice_degrees
from crysalis_g1.full_crysalis.config import FullCrysalisConfig, sha256_file
from crysalis_g1.full_crysalis.data import (
    IntegratedEvent,
    IntegratedRelationTarget,
    RelationNormalizer,
    _physics_proxy,
    collate_integrated_events,
)
from crysalis_g1.full_crysalis.geometry import GeometryGeneratorConfig
from crysalis_g1.full_crysalis.guide_mlip import GuideMLIP, physics_rank
from crysalis_g1.full_crysalis.model import FullCrysalisModel, FullCrysalisOutput
from crysalis_g1.full_crysalis.relation import RelationBackendConfig
from crysalis_g1.full_crysalis.state import (
    FullGenerationState,
    PersistentRelationState,
    PhysicsFeedback,
    PredictedRelationRecord,
)
from crysalis_g1.geometry_v2.formal_adapters import RelationGeometryCalibrationV2
from crysalis_g1.geometry_v2.endpoint import audit_formal_endpoint_receipt
from crysalis_g1.geometry_v2.memory import PersistentRelationMemoryV2
from crysalis_g1.geometry_v2.model import FormalGeometryV2Model
from crysalis_g1.geometry_v2.phase2a_adapter import (
    MAXIMUM_ACTIVE_ORBITS_V2,
    MAXIMUM_RELATION_EDGES_V2,
    MAXIMUM_RELATION_TRIPLETS_V2,
    _orbit_feature,
    _wyckoff_index,
)
from crysalis_g1.geometry_v2.production_guide import ProductionGuideObjectiveV2
from crysalis_g1.geometry_v2.relation_interface import (
    ActiveOrbitGraphV2,
    RelationInputProvenanceV2,
    RelationModelInputV2,
)
from crysalis_g1.r1.dataset import existing_orbit_geometry
from crysalis_g1.r1.descriptors import (
    ExplicitOrbitGeometry,
    PersistentRelationState as RealizedRelationState,
    descriptor_from_members,
    descriptor_from_orbit_pair,
)
from crysalis_g1.symmetry.assembly import (
    AddOrbitAction,
    C0SymmetryProjector,
    LegalAddOrbit,
    ProjectionReceipt,
    SpaceGroupLegalActionCompiler,
    SymmetryAssemblyState,
)
from crysalis_g1.symmetry.wyckoff import (
    OrbitState,
    SpaceGroupConstrainedLatticeHead,
    WyckoffExpansionError,
    orbit_representative_fractional_coordinate,
)


CHGNET_GUIDE_WEIGHT_SHA256 = (
    "d14ab7c0f093efe64b60a7bcd540bca10e74fb7f46c86108a079af60524659d1"
)


class _GuideProtocol(Protocol):
    provenance: Mapping[str, Any]

    def evaluate_candidates(
        self,
        structures: Sequence[Structure],
        candidate_slices: Sequence[tuple[int, int]],
    ) -> tuple[PhysicsFeedback, ...]: ...


def _canonical_json(payload: object) -> str:
    return json.dumps(
        payload,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def _payload_hash(payload: object) -> str:
    return hashlib.sha256(_canonical_json(payload).encode("utf-8")).hexdigest()


def _write_json_atomic(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            allow_nan=False,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


@dataclass(frozen=True, slots=True)
class GenerationRuntimeConfig:
    root_seed: int = 20260823
    maximum_orbits: int = 20
    maximum_sites: int = 20
    minimum_distance_angstrom: float = 0.5
    proposal_namespace: str = "full_crysalis:uniform_legal_orbit"
    geometry_namespace: str = "full_crysalis:geometry_v2_registered_k1"

    def __post_init__(self) -> None:
        if self.root_seed != 20260823:
            raise ValueError("Full Crysalis generation seed must remain 20260823")
        if self.maximum_orbits != 20 or self.maximum_sites != 20:
            raise ValueError("Full Crysalis generation limits must remain 20")
        if self.minimum_distance_angstrom != 0.5:
            raise ValueError("Full Crysalis minimum distance must remain 0.5")
        if not self.proposal_namespace or not self.geometry_namespace:
            raise ValueError("Full Crysalis RNG namespaces must be non-empty")

    @classmethod
    def from_full_config(
        cls,
        config: FullCrysalisConfig,
    ) -> GenerationRuntimeConfig:
        return cls(
            root_seed=config.root_seed,
            maximum_orbits=config.generation.maximum_orbits,
            maximum_sites=config.generation.maximum_sites,
            minimum_distance_angstrom=(
                config.generation.minimum_distance_angstrom
            ),
            proposal_namespace=config.generation.proposal_namespace,
        )


def derive_generation_seed(
    root_seed: int,
    condition_id: str,
    *,
    namespace: str,
    step_index: int,
) -> int:
    if root_seed != 20260823 or not condition_id or not namespace or step_index < 0:
        raise ValueError("invalid Full Crysalis RNG derivation input")
    digest = hashlib.sha256(
        f"{root_seed}:{namespace}:{condition_id}:{step_index}".encode("utf-8")
    ).digest()
    return int.from_bytes(digest[:8], "big") % (2**63)


def _embryo_lattice(space_group: int, site_count: int):
    length = max(3.0, (18.0 * site_count) ** (1.0 / 3.0))
    return SpaceGroupConstrainedLatticeHead().constrain(
        space_group,
        (length, length * 1.03, length * 1.07, 90.0, 90.0, 100.0),
    )


def _canonical_cell_transform(index: int) -> tuple[tuple[int, int, int], ...]:
    if index <= 0:
        raise ValueError("cell index must be positive")
    return ((index, 0, 0), (0, 1, 0), (0, 0, 1))


def _model_device(model: FullCrysalisModel) -> torch.device:
    try:
        return next(model.parameters()).device
    except StopIteration:
        return torch.device("cpu")


def _identity_normalizer() -> RelationNormalizer:
    return RelationNormalizer(mean=(0.0,) * 7, std=(1.0,) * 7)


def _state_geometries(
    state: SymmetryAssemblyState,
    receipt: ProjectionReceipt,
) -> dict[str, tuple[tuple[float, float, float], ...]]:
    coordinates = receipt.fractional_coordinates
    result = {}
    start = 0
    for orbit in state.orbits:
        stop = start + orbit.multiplicity
        result[orbit.orbit_instance_id] = tuple(coordinates[start:stop])
        start = stop
    if start != len(coordinates):
        raise ValueError("projected coordinates do not align with orbit states")
    return result


def _inference_event(
    *,
    condition_id: str,
    state: SymmetryAssemblyState,
    persistent: PersistentRelationState,
    candidate: OrbitState | None,
    step_index: int,
    projector: C0SymmetryProjector,
) -> IntegratedEvent:
    relation_targets: list[IntegratedRelationTarget] = []
    if candidate is not None and state.orbits:
        receipt = projector.project(state)
        if not receipt.accepted:
            raise ValueError("inference state is not projector-legal")
        geometries = _state_geometries(state, receipt)
        for existing in state.orbits:
            geometry = geometries[existing.orbit_instance_id]
            relation_targets.append(
                IntegratedRelationTarget(
                    pair_key=_payload_hash(
                        {
                            "condition_id": condition_id,
                            "step_index": step_index,
                            "candidate_orbit_id": candidate.orbit_instance_id,
                            "existing_orbit_id": existing.orbit_instance_id,
                        }
                    ),
                    existing_orbit_id=existing.orbit_instance_id,
                    existing_species=existing.species,
                    existing_wyckoff_letter=existing.wyckoff_letter,
                    existing_multiplicity=existing.multiplicity,
                    existing_free_parameter_count=len(existing.free_parameters),
                    existing_geometry=existing_orbit_geometry(
                        state.lattice.primitive_matrix,
                        geometry,
                    ),
                    target_group_id=None,
                    descriptor=descriptor_from_members(
                        distances=(),
                        candidate_multiplicity=candidate.multiplicity,
                        existing_multiplicity=existing.multiplicity,
                    ),
                )
            )
    return IntegratedEvent(
        parent_id=condition_id,
        split="inference",
        event_key=_payload_hash(
            {
                "condition_id": condition_id,
                "step_index": step_index,
                "active_orbit_ids": [
                    orbit.orbit_instance_id for orbit in state.orbits
                ],
                "candidate_orbit_id": (
                    None if candidate is None else candidate.orbit_instance_id
                ),
            }
        ),
        target_space_group=state.target_space_group,
        composition=state.composition,
        lattice=state.lattice,
        active_orbits=state.orbits,
        candidate_orbit=candidate,
        relation_targets=tuple(relation_targets),
        pooled_relation=persistent.pooled_relation,
        physics_feedback=persistent.pooled_physics,
        target_physics_feedback=persistent.pooled_physics,
    )


def _model_forward(
    model: FullCrysalisModel,
    event: IntegratedEvent,
    normalizer: RelationNormalizer,
    *,
    physics_override: PhysicsFeedback | None = None,
) -> tuple[FullCrysalisOutput, Any]:
    batch = collate_integrated_events(
        (event,),
        normalizer=normalizer,
        maximum_orbits=model.geometry_generator.config.maximum_orbits,
    )
    if physics_override is not None:
        feedback = torch.tensor(
            physics_override.vector,
            dtype=batch.physics_feedback.dtype,
        )[None, :]
        batch = batch.with_physics_feedback(feedback)
    device = _model_device(model)
    batch = batch.to(device)
    with torch.no_grad():
        output = model(batch)
    return output, batch


def _candidate_pool(
    base: Sequence[float],
    *,
    count: int,
    seed: int,
) -> tuple[tuple[float, ...], ...]:
    base = tuple(float(value) for value in base)
    if not 0 <= len(base) <= 3 or any(
        not math.isfinite(value) or not 0 <= value <= 1 for value in base
    ):
        raise ValueError("invalid candidate free-parameter base")
    if not base:
        return ((),)
    engine = torch.quasirandom.SobolEngine(
        dimension=len(base),
        scramble=True,
        seed=int(seed) % (2**31 - 1),
    )
    additional = engine.draw(count - 1).to(torch.float64).tolist()
    return (base, *(tuple(float(value) for value in row) for row in additional))


def _shift_pool(
    pool: Sequence[Sequence[float]],
    *,
    original_base: Sequence[float],
    corrected_base: Sequence[float],
) -> tuple[tuple[float, ...], ...]:
    original = np.asarray(tuple(original_base), dtype=float)
    corrected = np.asarray(tuple(corrected_base), dtype=float)
    if original.shape != corrected.shape:
        raise ValueError("geometry correction base shape mismatch")
    if not len(original):
        return ((),)
    shift = corrected - original
    shift -= np.round(shift)
    return tuple(
        tuple(float(value) for value in np.mod(np.asarray(item) + shift, 1.0))
        for item in pool
    )


def _rank_values(values: Sequence[float]) -> tuple[float, ...]:
    if not values:
        return ()
    if any(not math.isfinite(float(value)) for value in values):
        raise FloatingPointError("candidate ranking received a non-finite value")
    if len(values) == 1:
        return (0.0,)
    order = sorted(range(len(values)), key=lambda index: (values[index], index))
    ranks = [0.0] * len(values)
    start = 0
    while start < len(order):
        stop = start + 1
        while stop < len(order) and values[order[stop]] == values[order[start]]:
            stop += 1
        rank = ((start + stop - 1) / 2.0) / (len(order) - 1)
        for position in range(start, stop):
            ranks[order[position]] = rank
        start = stop
    return tuple(ranks)


def _relation_distance(
    output: FullCrysalisOutput,
    *,
    state: SymmetryAssemblyState,
    next_state: SymmetryAssemblyState,
    receipt: ProjectionReceipt,
    normalizer: RelationNormalizer,
) -> tuple[float, list[dict[str, Any]]]:
    pair_count = len(state.orbits)
    if pair_count == 0:
        return 0.0, []
    logits = output.relation.presence_logits.detach().cpu().numpy().reshape(-1)
    predicted = output.relation.continuous.detach().cpu().numpy()
    if logits.shape != (pair_count,) or predicted.shape != (pair_count, 7):
        raise ValueError("relation prediction does not align with existing orbits")
    all_coordinates = receipt.fractional_coordinates
    candidate_start = state.site_count
    candidate_coordinates = all_coordinates[candidate_start:]
    candidate = next_state.orbits[-1]
    realized_presence = []
    realized_continuous = []
    audit = []
    start = 0
    for existing in state.orbits:
        stop = start + existing.multiplicity
        descriptor = descriptor_from_orbit_pair(
            lattice=receipt.lattice,
            candidate_species=candidate.species,
            candidate_fractional=candidate_coordinates,
            existing_species=existing.species,
            existing_fractional=all_coordinates[start:stop],
        )
        normalized = normalizer.normalize(descriptor)
        realized_presence.append(descriptor.presence)
        realized_continuous.append(normalized)
        audit.append(
            {
                "existing_orbit_id": existing.orbit_instance_id,
                "descriptor": asdict(descriptor),
                "continuous_normalized": list(normalized),
            }
        )
        start = stop
    presence = np.asarray(realized_presence, dtype=float)
    continuous = np.asarray(realized_continuous, dtype=float)
    presence_loss = np.logaddexp(0.0, logits) - presence * logits
    difference = np.abs(predicted - continuous)
    smooth_l1 = np.where(
        difference < 1.0,
        0.5 * difference**2,
        difference - 0.5,
    )
    mask = np.broadcast_to(presence[:, None], smooth_l1.shape)
    continuous_loss = float(
        (smooth_l1 * mask).sum() / max(float(mask.sum()), 1.0)
    )
    value = float(presence_loss.mean() + continuous_loss)
    if not math.isfinite(value):
        raise FloatingPointError("non-finite relation compatibility distance")
    return value, audit


@dataclass(slots=True)
class _Candidate:
    candidate_index: int
    free_parameters: tuple[float, ...]
    state: SymmetryAssemblyState
    receipt: ProjectionReceipt
    relation_distance: float
    realized_relation_interface: list[dict[str, Any]]
    feedback: PhysicsFeedback | None = None
    relation_rank: float | None = None
    physics_rank: float | None = None
    joint_rank: float | None = None


def _evaluate_pool(
    *,
    state: SymmetryAssemblyState,
    compiler: SpaceGroupLegalActionCompiler,
    projector: C0SymmetryProjector,
    selected: LegalAddOrbit,
    orbit_id: str,
    pool: Sequence[Sequence[float]],
    output: FullCrysalisOutput,
    normalizer: RelationNormalizer,
    guide: _GuideProtocol,
) -> tuple[list[_Candidate], list[dict[str, Any]]]:
    legal: list[_Candidate] = []
    rejected: list[dict[str, Any]] = []
    for candidate_index, free_parameters in enumerate(pool):
        next_state = compiler.apply_add(
            state,
            AddOrbitAction(
                selected.wyckoff_letter,
                selected.species,
                tuple(float(value) for value in free_parameters),
                orbit_id,
            ),
        )
        receipt = projector.project(next_state)
        if not receipt.accepted:
            rejected.append(
                {
                    "candidate_index": candidate_index,
                    "free_parameters": list(free_parameters),
                    "projector": receipt.to_dict(),
                }
            )
            continue
        relation_distance, interface = _relation_distance(
            output,
            state=state,
            next_state=next_state,
            receipt=receipt,
            normalizer=normalizer,
        )
        legal.append(
            _Candidate(
                candidate_index=candidate_index,
                free_parameters=tuple(float(value) for value in free_parameters),
                state=next_state,
                receipt=receipt,
                relation_distance=relation_distance,
                realized_relation_interface=interface,
            )
        )
    if not legal:
        return legal, rejected
    structures = tuple(
        Structure(
            Lattice(np.asarray(candidate.receipt.lattice, dtype=float)),
            candidate.receipt.atomic_numbers,
            candidate.receipt.fractional_coordinates,
            to_unit_cell=True,
        )
        for candidate in legal
    )
    candidate_slices = tuple(
        (state.site_count, candidate.state.site_count) for candidate in legal
    )
    feedback = guide.evaluate_candidates(structures, candidate_slices)
    if len(feedback) != len(legal):
        raise ValueError("GuideMLIP feedback count differs from legal candidates")
    relation_ranks = _rank_values(
        tuple(candidate.relation_distance for candidate in legal)
    )
    for index, (candidate, item) in enumerate(
        zip(legal, feedback, strict=True)
    ):
        candidate.feedback = item
        candidate.relation_rank = relation_ranks[index]
        candidate.physics_rank = physics_rank(item)
        candidate.joint_rank = (
            0.5 * candidate.relation_rank + 0.5 * candidate.physics_rank
        )
    return legal, rejected


def _candidate_payload(candidate: _Candidate) -> dict[str, Any]:
    if (
        candidate.feedback is None
        or candidate.relation_rank is None
        or candidate.physics_rank is None
        or candidate.joint_rank is None
    ):
        raise ValueError("candidate ranking is incomplete")
    return {
        "candidate_index": candidate.candidate_index,
        "free_parameters": list(candidate.free_parameters),
        "projector": candidate.receipt.to_dict(),
        "relation_distance": candidate.relation_distance,
        "relation_rank": candidate.relation_rank,
        "physics_feedback": asdict(candidate.feedback),
        "physics_rank": candidate.physics_rank,
        "joint_rank": candidate.joint_rank,
        "realized_relation_interface": candidate.realized_relation_interface,
    }


def _predicted_relation_records(
    output: FullCrysalisOutput,
    *,
    candidate_orbit_id: str,
    existing_orbits: Sequence[OrbitState],
) -> tuple[PredictedRelationRecord, ...]:
    logits = output.relation.presence_logits.detach().cpu().reshape(-1).tolist()
    continuous = output.relation.continuous.detach().cpu().tolist()
    latent = output.relation.latent.detach().cpu().tolist()
    if not (
        len(logits) == len(continuous) == len(latent) == len(existing_orbits)
    ):
        raise ValueError("predicted relation state alignment failed")
    return tuple(
        PredictedRelationRecord(
            candidate_orbit_id=candidate_orbit_id,
            existing_orbit_id=existing.orbit_instance_id,
            presence_logit=float(logits[index]),
            normalized_continuous=tuple(float(value) for value in continuous[index]),
            latent=tuple(float(value) for value in latent[index]),
        )
        for index, existing in enumerate(existing_orbits)
    )


@dataclass(frozen=True, slots=True)
class GeometryV2PreparedStep:
    state: SymmetryAssemblyState
    model_input: RelationModelInputV2
    wyckoff_id: torch.Tensor
    free_parameter_mask: torch.Tensor
    registered_seed: int
    candidate_free_dof: int


def _predict_frozen_v1_lattice(
    model: FullCrysalisModel,
    event: IntegratedEvent,
    normalizer: RelationNormalizer,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Run only the copied V1 lattice path; disconnected geometry heads are unused."""

    batch = collate_integrated_events(
        (event,),
        normalizer=normalizer,
        maximum_orbits=model.geometry_generator.config.maximum_orbits,
    ).to(_model_device(model))
    generator = model.geometry_generator
    with torch.no_grad():
        relation = model.relation_backend(batch)
        features, node_mask, _ = generator._node_features(batch)
        batch_size, node_count, hidden = features.shape
        flat_features = features.reshape(batch_size * node_count, hidden)
        flat_mask = node_mask.reshape(-1)
        source, target, vectors, edge_features = generator._edges(batch, relation)
        distances = torch.linalg.vector_norm(vectors, dim=-1)
        radial = torch.exp(
            -generator.radial_gamma
            * (distances[:, None] - generator.radial_centers[None, :]).square()
        )
        for block in generator.blocks:
            flat_features, _ = block(
                flat_features,
                source=source,
                target=target,
                vectors=vectors,
                edge_features=edge_features,
                radial=radial,
                node_mask=flat_mask,
            )
        query_indices = (
            torch.arange(batch_size, device=flat_features.device) * node_count
            + generator.config.maximum_orbits
        )
        query = flat_features[query_indices]
        lattice_degrees = batch.lattice_degrees + 0.1 * torch.tanh(
            generator.lattice_head(query)
        )
        cell_index_logits = generator.cell_index_head(query)
    if not bool(torch.isfinite(lattice_degrees).all()) or not bool(
        torch.isfinite(cell_index_logits).all()
    ):
        raise FloatingPointError("frozen V1 lattice path produced non-finite values")
    return lattice_degrees, cell_index_logits


def _realized_state_features(
    state: SymmetryAssemblyState,
    projector: C0SymmetryProjector,
) -> tuple[tuple[float, ...], tuple[float, ...]]:
    if not state.orbits:
        return (0.0,) * 8, _physics_proxy(state.lattice.primitive_matrix, ())
    receipt = projector.project(state)
    if not receipt.accepted:
        raise ValueError("current Geometry V2 state is not projector-legal")
    relation = RealizedRelationState.from_assembly_state(state, projector).pooled
    geometries: list[ExplicitOrbitGeometry] = []
    start = 0
    for orbit in state.orbits:
        stop = start + orbit.multiplicity
        geometries.append(
            ExplicitOrbitGeometry(
                orbit_instance_id=orbit.orbit_instance_id,
                species=orbit.species,
                wyckoff_letter=orbit.wyckoff_letter,
                multiplicity=orbit.multiplicity,
                free_parameter_count=len(orbit.free_parameters),
                fractional_coordinates=tuple(
                    tuple(float(value) for value in row)
                    for row in receipt.fractional_coordinates[start:stop]
                ),
            )
        )
        start = stop
    if start != len(receipt.fractional_coordinates):
        raise ValueError("projected state does not match orbit multiplicities")
    return relation, _physics_proxy(state.lattice.primitive_matrix, tuple(geometries))


def _memory_to_device(
    memory: PersistentRelationMemoryV2,
    device: torch.device,
) -> PersistentRelationMemoryV2:
    if (
        memory.batch_size != 1
        or memory.max_orbits != MAXIMUM_ACTIVE_ORBITS_V2
        or memory.max_edges != MAXIMUM_RELATION_EDGES_V2
    ):
        raise ValueError("Geometry V2 memory dimensions drifted")
    tensors = memory.tensorize()
    return PersistentRelationMemoryV2.from_tensors(
        orbit=tensors.orbit.to(device),
        edge=tensors.edge.to(device),
        global_memory=tensors.global_memory.to(device),
    )


def _prepare_geometry_v2_step(
    *,
    state: SymmetryAssemblyState,
    selected: LegalAddOrbit,
    orbit_id: str,
    memory: PersistentRelationMemoryV2,
    compiler: SpaceGroupLegalActionCompiler,
    projector: C0SymmetryProjector,
    condition_id: str,
    step_index: int,
    runtime: GenerationRuntimeConfig,
    device: torch.device,
) -> GeometryV2PreparedStep:
    pooled_relation, physics_feedback = _realized_state_features(state, projector)
    generic_seed = (0.137, 0.271, 0.389)[: selected.free_parameter_count]
    candidate_state = compiler.apply_add(
        state,
        AddOrbitAction(
            wyckoff_letter=selected.wyckoff_letter,
            species=selected.species,
            free_parameters=generic_seed,
            orbit_instance_id=orbit_id,
        ),
    )
    candidate = candidate_state.orbits[-1]
    if candidate.multiplicity != selected.multiplicity:
        raise RuntimeError("generic Geometry V2 seed changed legal orbit multiplicity")
    feature_parameters = (0.5,) * selected.free_parameter_count
    feature_orbit = OrbitState.create(
        state.target_space_group,
        selected.wyckoff_letter,
        selected.species,
        feature_parameters,
        cell_transform=state.lattice.cell_transform_values,
        orbit_instance_id=f"{orbit_id}:context-seed",
    )
    progress = state.site_count / sum(count for _, count in state.composition)
    active_features = torch.zeros(1, MAXIMUM_ACTIVE_ORBITS_V2, 64)
    active_mask = torch.zeros(1, MAXIMUM_ACTIVE_ORBITS_V2, dtype=torch.bool)
    edge_index = torch.zeros(1, MAXIMUM_RELATION_EDGES_V2, dtype=torch.long)
    edge_mask = torch.zeros(1, MAXIMUM_RELATION_EDGES_V2, dtype=torch.bool)
    triplet_index = torch.zeros(
        1, MAXIMUM_RELATION_TRIPLETS_V2, 2, dtype=torch.long
    )
    triplet_mask = torch.zeros(
        1, MAXIMUM_RELATION_TRIPLETS_V2, dtype=torch.bool
    )
    for slot, orbit in enumerate(state.orbits):
        active_features[0, slot] = _orbit_feature(
            species=orbit.species,
            wyckoff_index=_wyckoff_index(orbit.wyckoff_letter),
            multiplicity=orbit.multiplicity,
            free_parameters=orbit.free_parameters,
            representative=orbit_representative_fractional_coordinate(orbit),
            progress=progress,
            candidate=False,
            pooled_relation=pooled_relation,
            physics_feedback=physics_feedback,
        )
        active_mask[0, slot] = True
        edge_index[0, slot] = slot
        edge_mask[0, slot] = True
    candidate_slot = len(state.orbits)
    candidate_feature = _orbit_feature(
        species=candidate.species,
        wyckoff_index=_wyckoff_index(candidate.wyckoff_letter),
        multiplicity=selected.multiplicity,
        free_parameters=feature_parameters,
        representative=orbit_representative_fractional_coordinate(feature_orbit),
        progress=progress,
        candidate=True,
        pooled_relation=pooled_relation,
        physics_feedback=physics_feedback,
    )
    active_features[0, candidate_slot] = candidate_feature
    active_mask[0, candidate_slot] = True
    for triplet_slot, pair in enumerate(
        itertools.combinations(range(candidate_slot), 2)
    ):
        triplet_index[0, triplet_slot] = torch.tensor(pair)
        triplet_mask[0, triplet_slot] = True
    graph = ActiveOrbitGraphV2(
        active_orbits=active_features.to(device),
        active_orbit_mask=active_mask.to(device),
        edge_index=edge_index.to(device),
        edge_mask=edge_mask.to(device),
        triplet_index=triplet_index.to(device),
        triplet_mask=triplet_mask.to(device),
    )
    composition = torch.zeros(1, 119, device=device)
    for atomic_number, count in state.composition:
        composition[0, atomic_number] = count
    model_input = RelationModelInputV2.from_mapping(
        {
            "composition": composition,
            "target_sg": torch.tensor(
                [state.target_space_group], dtype=torch.long, device=device
            ),
            "lattice": torch.tensor(
                [state.lattice.primitive_matrix], dtype=torch.float32, device=device
            ),
            "active_orbit_graph": graph,
            "candidate_query": candidate_feature[None].to(device),
            "persistent_memory": _memory_to_device(memory, device),
        },
        provenance=RelationInputProvenanceV2("current_generation_state"),
    )
    mask = torch.zeros(1, 3, dtype=torch.bool, device=device)
    mask[0, : selected.free_parameter_count] = True
    return GeometryV2PreparedStep(
        state=candidate_state,
        model_input=model_input,
        wyckoff_id=torch.tensor(
            [_wyckoff_index(selected.wyckoff_letter)], dtype=torch.long, device=device
        ),
        free_parameter_mask=mask,
        registered_seed=derive_generation_seed(
            runtime.root_seed,
            condition_id,
            namespace=runtime.geometry_namespace,
            step_index=step_index,
        ),
        candidate_free_dof=selected.free_parameter_count,
    )


def _formal_receipt_payload(result: Any) -> dict[str, Any]:
    receipt = result.receipt
    sampling = receipt.sampling
    refinement = receipt.refinement
    return {
        "accepted": bool(receipt.accepted),
        "failure_reason_codes": list(receipt.failure_reason_codes),
        "attempt_count": int(receipt.attempt_count),
        "resampled": bool(receipt.resampled),
        "partial_state": bool(receipt.partial_state),
        "stages": list(receipt.stages),
        "registered_seed": int(sampling.registered_seed),
        "sample_index": int(sampling.sample_index),
        "sample_count": int(sampling.sample_count),
        "integration_steps": int(sampling.integration_steps),
        "velocity_evaluations": int(sampling.velocity_evaluations),
        "zero_dof_bypass": list(sampling.zero_dof_bypass),
        "refinement_accepted_steps": int(refinement.accepted_steps),
        "refinement_attempted_proposals": int(refinement.attempted_proposals),
        "refinement_reason_codes": list(refinement.reason_codes),
        "projector": (
            None if receipt.projector is None else receipt.projector.to_dict()
        ),
        "eval_mlip_present": bool(receipt.dependency_audit.eval_mlip_present),
        "forbidden_nodes": list(receipt.dependency_audit.forbidden_nodes),
    }


def generate_condition(
    v1_model: FullCrysalisModel,
    geometry_v2_model: FormalGeometryV2Model,
    guide: ProductionGuideObjectiveV2,
    relation_calibration: RelationGeometryCalibrationV2,
    condition: Mapping[str, Any],
    *,
    normalizer: RelationNormalizer | None = None,
    runtime: GenerationRuntimeConfig | None = None,
) -> dict[str, Any]:
    """Copied V1 generation shell with only its geometry middle replaced by V2."""

    runtime = runtime or GenerationRuntimeConfig()
    normalizer = normalizer or _identity_normalizer()
    if not isinstance(guide, ProductionGuideObjectiveV2):
        raise TypeError("Geometry V2 generation requires the frozen production Guide")
    condition_id = str(condition.get("condition_id", ""))
    if not condition_id or int(condition.get("root_seed", -1)) != runtime.root_seed:
        raise ValueError("generation condition identity/root seed is invalid")
    composition = tuple(
        (int(atomic_number), int(count))
        for atomic_number, count in condition["composition"]
    )
    target_space_group = int(condition["space_group"])
    if sum(count for _, count in composition) > runtime.maximum_sites:
        raise ValueError("generation condition exceeds the frozen site limit")
    started = time.perf_counter()
    compiler = SpaceGroupLegalActionCompiler(max_sites=runtime.maximum_sites)
    projector = C0SymmetryProjector(
        minimum_distance=runtime.minimum_distance_angstrom
    )
    embryo = SymmetryAssemblyState.empty(
        target_space_group=target_space_group,
        composition=composition,
        lattice=_embryo_lattice(
            target_space_group, sum(count for _, count in composition)
        ),
    )
    lattice_event = _inference_event(
        condition_id=condition_id,
        state=embryo,
        persistent=PersistentRelationState.empty(),
        candidate=None,
        step_index=0,
        projector=projector,
    )
    predicted_lattice, predicted_cell_logits = _predict_frozen_v1_lattice(
        v1_model, lattice_event, normalizer
    )
    cell_logits = predicted_cell_logits[0].detach().cpu().clone()
    cell_logits[0] = -math.inf
    lattice_degrees = tuple(
        float(value) for value in predicted_lattice[0].detach().cpu().tolist()
    )
    legal_cells = []
    for cell_index in range(1, len(cell_logits)):
        candidate_lattice = decode_lattice_degrees(
            target_space_group,
            lattice_degrees,
            cell_transform=_canonical_cell_transform(cell_index),
        )
        candidate_embryo = SymmetryAssemblyState.empty(
            target_space_group=target_space_group,
            composition=composition,
            lattice=candidate_lattice,
        )
        if compiler.legal_add_actions(candidate_embryo):
            legal_cells.append(
                (float(cell_logits[cell_index]), cell_index, candidate_lattice)
            )
    if not legal_cells:
        raise RuntimeError("Geometry V2 found no crystallographically legal cell index")
    _, selected_cell_index, lattice = max(
        legal_cells, key=lambda item: (item[0], -item[1])
    )
    state = SymmetryAssemblyState.empty(
        target_space_group=target_space_group,
        composition=composition,
        lattice=lattice,
    )
    device = _model_device(geometry_v2_model)
    memory = PersistentRelationMemoryV2.empty(
        1,
        MAXIMUM_ACTIVE_ORBITS_V2,
        MAXIMUM_RELATION_EDGES_V2,
        device=device,
    )

    steps: list[dict[str, Any]] = []
    failure_code: str | None = None
    rejection_reasons: list[str] = []
    terminal_receipt: ProjectionReceipt | None = None
    for step_index in range(runtime.maximum_orbits):
        if not state.remaining_composition:
            terminal_receipt = projector.project(state)
            if compiler.can_terminate(state, terminal_receipt):
                break
            failure_code = "TERMINATION_ILLEGAL"
            rejection_reasons.extend(terminal_receipt.reason_codes)
            break
        legal_actions = compiler.legal_add_actions(state)
        if not legal_actions:
            failure_code = "NO_LEGAL_ADD_ORBIT_ACTION"
            break
        proposal_seed = derive_generation_seed(
            runtime.root_seed,
            condition_id,
            namespace=runtime.proposal_namespace,
            step_index=step_index,
        )
        proposal_rng = np.random.default_rng(proposal_seed)
        selected = legal_actions[int(proposal_rng.integers(len(legal_actions)))]
        orbit_id = f"{condition_id}:orbit:{step_index}"
        prepared = _prepare_geometry_v2_step(
            state=state,
            selected=selected,
            orbit_id=orbit_id,
            memory=memory,
            compiler=compiler,
            projector=projector,
            condition_id=condition_id,
            step_index=step_index,
            runtime=runtime,
            device=device,
        )
        memory_before = memory.state_hash()
        try:
            with torch.no_grad():
                result = geometry_v2_model.run_inference(
                    state=prepared.state,
                    model_input=prepared.model_input,
                    wyckoff_id=prepared.wyckoff_id,
                    free_parameter_mask=prepared.free_parameter_mask,
                    registered_seed=prepared.registered_seed,
                    candidate_free_dof=prepared.candidate_free_dof,
                    guide_objective=guide,
                    projector=projector,
                    relation_calibration=relation_calibration,
                )
        except WyckoffExpansionError as error:
            failure_code = "GEOMETRY_V2_WYCKOFF_EXPANSION_FAILED"
            rejection_reasons.append(error.reason_code)
            steps.append(
                {
                    "step_index": step_index,
                    "uniform_legal_action_count": len(legal_actions),
                    "proposal_seed": proposal_seed,
                    "selected_orbit": asdict(selected),
                    "orbit_instance_id": orbit_id,
                    "relation_state_before_hash": memory_before,
                    "relation_state_after_hash": memory_before,
                    "scientific_failure": {
                        "code": failure_code,
                        "reason_code": error.reason_code,
                        "detail": error.detail,
                    },
                }
            )
            break
        audit = audit_formal_endpoint_receipt(result.receipt)
        if not audit.passed:
            raise RuntimeError("Geometry V2 formal endpoint receipt audit failed")
        step_payload = {
            "step_index": step_index,
            "uniform_legal_action_count": len(legal_actions),
            "proposal_seed": proposal_seed,
            "selected_orbit": asdict(selected),
            "orbit_instance_id": orbit_id,
            "formal_endpoint": _formal_receipt_payload(result),
            "relation_state_before_hash": memory_before,
            "selected_free_parameters": [
                float(value) for value in result.state.orbits[-1].free_parameters
            ],
        }
        if not result.receipt.accepted:
            failure_code = "GEOMETRY_V2_FORMAL_ENDPOINT_REJECTED"
            rejection_reasons.extend(result.receipt.failure_reason_codes)
            step_payload["relation_state_after_hash"] = memory_before
            steps.append(step_payload)
            break
        if result.updated_memory is None or result.memory_update_receipt is None:
            raise RuntimeError("accepted Geometry V2 endpoint did not update memory")
        state = result.state
        memory = result.updated_memory
        step_payload["relation_state_after_hash"] = memory.state_hash()
        steps.append(step_payload)
    else:
        if state.remaining_composition:
            failure_code = "MAXIMUM_ORBIT_STEPS_EXCEEDED"
        else:
            terminal_receipt = projector.project(state)
            if not compiler.can_terminate(state, terminal_receipt):
                failure_code = "TERMINATION_ILLEGAL"
                rejection_reasons.extend(terminal_receipt.reason_codes)

    if failure_code is None and terminal_receipt is None:
        terminal_receipt = projector.project(state)
        if not compiler.can_terminate(state, terminal_receipt):
            failure_code = "TERMINATION_ILLEGAL"
            rejection_reasons.extend(terminal_receipt.reason_codes)
    legal_terminal = bool(
        failure_code is None
        and terminal_receipt is not None
        and compiler.can_terminate(state, terminal_receipt)
    )
    candidate_payload = None
    if legal_terminal and terminal_receipt is not None:
        candidate_payload = {
            "atomic_numbers": list(terminal_receipt.atomic_numbers),
            "fractional_coordinates": [
                list(value) for value in terminal_receipt.fractional_coordinates
            ],
            "lattice": [list(value) for value in terminal_receipt.lattice],
            "orbit_states": [asdict(orbit) for orbit in state.orbits],
        }
    final_detected = (
        0
        if terminal_receipt is None
        else int(terminal_receipt.detected_space_groups.get(0.03, 0))
    )
    return {
        "schema_version": "g1-full-crysalis-geometry-v2-generation-record.1.0.0",
        "condition": dict(condition),
        "orbit_proposal": "UNIFORM_LEGAL",
        "learned_orbit_logits_used": False,
        "proposal_namespace": runtime.proposal_namespace,
        "geometry_namespace": runtime.geometry_namespace,
        "geometry_decoder": "CONDITIONAL_TOROIDAL_FLOW_K1",
        "formal_v2_uses_fixed_sobol": False,
        "v1_lattice_reused": True,
        "selected_cell_index": selected_cell_index,
        "selected_lattice_degrees": list(lattice_degrees),
        "selected_lattice": [list(row) for row in lattice.primitive_matrix],
        "steps": steps,
        "completed": legal_terminal,
        "legal_terminal_crystal": legal_terminal,
        "failure_code": failure_code,
        "projector_rejection_reasons": list(dict.fromkeys(rejection_reasons)),
        "composition_valid": bool(
            terminal_receipt and terminal_receipt.composition_valid
        ),
        "multiplicity_valid": bool(
            terminal_receipt and terminal_receipt.multiplicity_valid
        ),
        "wyckoff_orbit_valid": bool(
            terminal_receipt
            and terminal_receipt.orbit_membership_valid
            and terminal_receipt.distinct_orbit_instances_valid
        ),
        "short_contact_free": bool(
            terminal_receipt and terminal_receipt.minimum_distance_valid
        ),
        "detected_space_group": final_detected,
        "post_projector_target_space_group_match": (
            final_detected == target_space_group
        ),
        "candidate": candidate_payload,
        "final_relation_state_hash": memory.state_hash(),
        "latency_seconds": time.perf_counter() - started,
        "retry_count": 0,
        "refill_count": 0,
        "sealed_or_blind_data_accessed": False,
        "ablation_performed": False,
        "preliminary_update_2000": True,
    }


def summarize_generation(records: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    if not records:
        raise ValueError("Full Crysalis generation summary requires records")
    count = len(records)
    latencies = np.asarray(
        [float(record["latency_seconds"]) for record in records],
        dtype=float,
    )
    failures: dict[str, int] = {}
    for record in records:
        code = record.get("failure_code")
        if code is not None:
            failures[str(code)] = failures.get(str(code), 0) + 1
    short_contact_rejections = sum(
        "SHORT_CONTACT" in record.get("projector_rejection_reasons", ())
        for record in records
    )
    legal_count = sum(bool(record["legal_terminal_crystal"]) for record in records)
    return {
        "schema_version": "g1-full-crysalis-geometry-v2-generation-summary.1.0.0",
        "attempt_count": count,
        "failure_denominator_includes_all_attempts": True,
        "legal_terminal_count": legal_count,
        "legal_terminal_rate": legal_count / count,
        "short_contact_rejection_count": short_contact_rejections,
        "short_contact_rejection_rate": short_contact_rejections / count,
        "failure_taxonomy": dict(sorted(failures.items())),
        "latency_mean_seconds": float(latencies.mean()),
        "latency_median_seconds": float(np.median(latencies)),
        "latency_p90_seconds": float(np.percentile(latencies, 90)),
        "retry_count": sum(int(record["retry_count"]) for record in records),
        "refill_count": sum(int(record["refill_count"]) for record in records),
        "orbit_proposal": "UNIFORM_LEGAL",
        "learned_orbit_logits_used": False,
        "formal_v2_uses_fixed_sobol": False,
        "geometry_decoder": "CONDITIONAL_TOROIDAL_FLOW_K1",
        "sealed_or_blind_data_accessed": False,
        "ablation_performed": False,
    }


def load_full_checkpoint(
    path: str | Path,
    *,
    device: str,
) -> tuple[FullCrysalisModel, RelationNormalizer, dict[str, Any]]:
    payload = torch.load(path, map_location=device, weights_only=False)
    if payload.get("schema_version") != "g1-full-crysalis-checkpoint.1.0.0":
        raise ValueError("unsupported Full Crysalis checkpoint schema")
    if payload.get("checkpoint_selection_metric") != (
        "structure_ood_validation_total_loss"
    ):
        raise ValueError("Full checkpoint selection metric drifted")
    if payload.get("generation_metrics_used") is not False:
        raise ValueError("Full checkpoint selection used generation metrics")
    if payload.get("next_orbit_loss_present") is not False:
        raise ValueError("Full checkpoint contains forbidden next-orbit training")
    model = FullCrysalisModel(
        relation_config=RelationBackendConfig(**payload["relation_config"]),
        geometry_config=GeometryGeneratorConfig(**payload["geometry_config"]),
        loss_weights=payload["loss_weights"],
    ).to(device)
    model.load_state_dict(payload["model_state_dict"], strict=True)
    model.eval()
    normalizer = RelationNormalizer(
        mean=tuple(float(value) for value in payload["normalizer"]["mean"]),
        std=tuple(float(value) for value in payload["normalizer"]["std"]),
    )
    if payload["normalizer"].get("fit_split") != "train_fit":
        raise ValueError("Full checkpoint relation normalizer leaked validation")
    return model, normalizer, payload


def load_frozen_conditions(
    path: str | Path,
    *,
    attempt_count: int,
    root_seed: int,
) -> tuple[dict[str, Any], ...]:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    rows = tuple(dict(row) for row in payload.get("conditions", ()))
    if int(payload.get("attempt_count", -1)) != attempt_count or len(rows) != (
        attempt_count
    ):
        raise ValueError("frozen condition denominator drifted")
    condition_ids = [str(row.get("condition_id", "")) for row in rows]
    if any(not item for item in condition_ids) or len(set(condition_ids)) != len(rows):
        raise ValueError("frozen condition IDs are invalid")
    for index, row in enumerate(rows):
        if int(row.get("attempt_index", -1)) != index:
            raise ValueError("frozen condition ordering drifted")
        if int(row.get("root_seed", -1)) != root_seed:
            raise ValueError("frozen condition root seed drifted")
        composition = tuple(
            (int(atomic_number), int(count))
            for atomic_number, count in row["composition"]
        )
        if not composition or any(
            not 1 <= atomic_number <= 118 or count <= 0
            for atomic_number, count in composition
        ):
            raise ValueError("frozen condition composition is invalid")
    return rows


def load_geometry_v2_checkpoint(
    path: str | Path,
    *,
    expected_sha256: str,
    device: str,
    completed_updates: int,
) -> tuple[FormalGeometryV2Model, dict[str, Any]]:
    checkpoint_path = Path(path)
    if sha256_file(checkpoint_path) != expected_sha256.lower():
        raise ValueError("Geometry V2 checkpoint SHA-256 mismatch")
    payload = torch.load(checkpoint_path, map_location=device, weights_only=False)
    if payload.get("schema_version") != (
        "crysalis-geometry-v2-production-checkpoint.1.0.0"
    ):
        raise ValueError("unsupported Geometry V2 production checkpoint schema")
    cursor = payload.get("batch_cursor")
    if not isinstance(cursor, Mapping) or int(cursor.get("next_batch_index", -1)) != (
        completed_updates
    ):
        raise ValueError("Geometry V2 checkpoint update boundary mismatch")
    model = FormalGeometryV2Model().to(device)
    model.load_state_dict(payload["current_model_state"], strict=True)
    model.eval()
    if any(not bool(torch.isfinite(parameter).all()) for parameter in model.parameters()):
        raise FloatingPointError("Geometry V2 checkpoint contains non-finite parameters")
    return model, payload


def run_geometry_v2_generation(
    *,
    output_root: str | Path,
    v1_checkpoint_path: str | Path,
    v2_checkpoint_path: str | Path,
    v2_checkpoint_sha256: str,
    condition_manifest_path: str | Path,
    relation_calibration: RelationGeometryCalibrationV2,
    device: str,
    attempt_count: int = 300,
    completed_updates: int = 2000,
) -> dict[str, Any]:
    output_dir = Path(output_root)
    records_path = output_dir / "generation_records.json"
    summary_path = output_dir / "generation_summary.json"
    if records_path.exists() or summary_path.exists():
        raise FileExistsError("Geometry V2 generation refuses to overwrite evidence")
    v1_model, normalizer, _ = load_full_checkpoint(
        v1_checkpoint_path,
        device=device,
    )
    geometry_v2_model, _ = load_geometry_v2_checkpoint(
        v2_checkpoint_path,
        expected_sha256=v2_checkpoint_sha256,
        device=device,
        completed_updates=completed_updates,
    )
    import chgnet

    if chgnet.__version__ != "0.4.2":
        raise RuntimeError("Geometry V2 Guide requires frozen CHGNet 0.4.2")
    guide_weight_path = (
        Path(chgnet.__file__).resolve().parent
        / "pretrained/0.3.0/chgnet_0.3.0_e29f68s314m37.pth.tar"
    )
    if sha256_file(guide_weight_path) != CHGNET_GUIDE_WEIGHT_SHA256:
        raise RuntimeError("Geometry V2 Guide CHGNet weight hash mismatch")
    guide = ProductionGuideObjectiveV2.from_device(device)
    conditions = load_frozen_conditions(
        condition_manifest_path,
        attempt_count=attempt_count,
        root_seed=20260823,
    )
    runtime = GenerationRuntimeConfig()
    records = []
    for condition in conditions:
        records.append(
            generate_condition(
                v1_model,
                geometry_v2_model,
                guide,
                relation_calibration,
                condition,
                normalizer=normalizer,
                runtime=runtime,
            )
        )
    summary = summarize_generation(records)
    if len(records) != attempt_count:
        raise RuntimeError("Geometry V2 generation denominator is incomplete")
    _write_json_atomic(records_path, records)
    summary = {
        **summary,
        "preliminary_update": completed_updates,
        "v1_checkpoint_sha256": sha256_file(v1_checkpoint_path),
        "v2_checkpoint_sha256": v2_checkpoint_sha256.lower(),
        "condition_manifest_sha256": sha256_file(condition_manifest_path),
        "relation_calibration_sha256": relation_calibration.artifact_sha256,
        "generation_records_sha256": sha256_file(records_path),
    }
    _write_json_atomic(summary_path, summary)
    return {"records": records, "summary": summary}
