from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Sequence

import numpy as np
import torch
from pymatgen.core import Lattice
from pymatgen.util.coord import pbc_shortest_vectors
from torch import nn

from crysalis_g1.full_crysalis.data import IntegratedBatch
from crysalis_g1.full_crysalis.relation import RelationRestorationOutput


def shortest_periodic_vectors(
    lattice: torch.Tensor | Sequence[Sequence[float]],
    source_fractional: torch.Tensor | Sequence[Sequence[float]],
    target_fractional: torch.Tensor | Sequence[Sequence[float]],
) -> torch.Tensor:
    lattice_tensor = torch.as_tensor(lattice)
    source_tensor = torch.as_tensor(source_fractional)
    target_tensor = torch.as_tensor(target_fractional)
    if lattice_tensor.shape != (3, 3):
        raise ValueError("periodic lattice must have shape [3, 3]")
    if (
        source_tensor.ndim != 2
        or target_tensor.ndim != 2
        or source_tensor.shape[1:] != (3,)
        or target_tensor.shape[1:] != (3,)
    ):
        raise ValueError("periodic coordinates must have shape [N, 3]")
    tensors = (lattice_tensor, source_tensor, target_tensor)
    if any(not bool(torch.isfinite(value).all()) for value in tensors):
        raise ValueError("periodic lattice and coordinates must be finite")
    dtype = torch.promote_types(
        lattice_tensor.dtype,
        torch.promote_types(source_tensor.dtype, target_tensor.dtype),
    )
    if not dtype.is_floating_point:
        dtype = torch.float32
    vectors = pbc_shortest_vectors(
        Lattice(lattice_tensor.detach().cpu().double().numpy()),
        source_tensor.detach().cpu().double().numpy(),
        target_tensor.detach().cpu().double().numpy(),
    )
    result = torch.as_tensor(
        np.asarray(vectors),
        dtype=dtype,
        device=lattice_tensor.device,
    )
    if not bool(torch.isfinite(result).all()):
        raise FloatingPointError("non-finite shortest periodic vectors")
    return result


@dataclass(frozen=True, slots=True)
class GeometryGeneratorConfig:
    hidden_dim: int = 128
    block_count: int = 3
    radial_basis_count: int = 16
    cutoff_angstrom: float = 8.0
    coordinate_step_scale: float = 0.05
    maximum_orbits: int = 20
    maximum_cell_index: int = 2
    relation_latent_dim: int = 32

    def __post_init__(self) -> None:
        integer_values = (
            self.hidden_dim,
            self.block_count,
            self.radial_basis_count,
            self.maximum_orbits,
            self.maximum_cell_index,
            self.relation_latent_dim,
        )
        if any(type(value) is not int or value <= 0 for value in integer_values):
            raise ValueError("geometry dimensions must be positive integers")
        if self.hidden_dim % 2:
            raise ValueError("geometry hidden dimension must be even")
        if self.radial_basis_count < 2:
            raise ValueError("geometry radial basis count must be at least two")
        for value in (self.cutoff_angstrom, self.coordinate_step_scale):
            if not math.isfinite(float(value)) or value <= 0:
                raise ValueError("geometry scales must be finite and positive")


@dataclass(frozen=True, slots=True)
class GeometryGeneratorOutput:
    free_parameters: torch.Tensor
    representative_fractional: torch.Tensor
    representative_delta_cartesian: torch.Tensor
    lattice_degrees: torch.Tensor
    cell_index_logits: torch.Tensor
    termination_logits: torch.Tensor
    physics_prediction: torch.Tensor


class _OrbitEGNNBlock(nn.Module):
    def __init__(
        self,
        *,
        hidden_dim: int,
        edge_dim: int,
        radial_basis_count: int,
    ) -> None:
        super().__init__()
        self.message = nn.Sequential(
            nn.Linear(hidden_dim * 2 + edge_dim + radial_basis_count, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(),
        )
        self.node_update = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.coordinate_weight = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, 1, bias=False),
        )
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(
        self,
        features: torch.Tensor,
        *,
        source: torch.Tensor,
        target: torch.Tensor,
        vectors: torch.Tensor,
        edge_features: torch.Tensor,
        radial: torch.Tensor,
        node_mask: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if source.numel() == 0:
            return features, vectors.new_zeros((features.shape[0], 3))
        messages = self.message(
            torch.cat(
                (
                    features[source],
                    features[target],
                    edge_features,
                    radial,
                ),
                dim=-1,
            )
        )
        aggregate = features.new_zeros(features.shape).index_add(
            0, target, messages
        )
        degree = features.new_zeros((features.shape[0], 1)).index_add(
            0,
            target,
            torch.ones_like(messages[:, :1]),
        )
        aggregate = aggregate / degree.clamp_min(1.0)
        features = self.norm(
            features
            + self.node_update(torch.cat((features, aggregate), dim=-1))
        )
        features = features * node_mask[:, None]
        coordinate = vectors.new_zeros((features.shape[0], 3)).index_add(
            0,
            target,
            self.coordinate_weight(messages) * vectors,
        )
        coordinate = coordinate / degree.clamp_min(1.0)
        return features, coordinate * node_mask[:, None]


class RelationConditionedGeometryGenerator(nn.Module):
    node_granularity = "ORBIT"

    def __init__(self, config: GeometryGeneratorConfig) -> None:
        super().__init__()
        self.config = config
        hidden = config.hidden_dim
        self.space_group_embedding = nn.Embedding(231, 16)
        self.species_embedding = nn.Embedding(119, 16)
        self.wyckoff_embedding = nn.Embedding(26, 8)
        self.composition_encoder = nn.Sequential(
            nn.Linear(119, hidden // 2),
            nn.SiLU(),
        )
        self.remaining_encoder = nn.Sequential(
            nn.Linear(119, hidden // 2),
            nn.SiLU(),
        )
        global_width = hidden + 1 + 6 + 8 + 9
        self.global_encoder = nn.Sequential(
            nn.Linear(global_width, hidden),
            nn.SiLU(),
            nn.Linear(hidden, hidden),
        )
        node_width = 16 + 16 + 8 + 6 + hidden
        self.node_encoder = nn.Sequential(
            nn.Linear(node_width, hidden),
            nn.SiLU(),
            nn.Linear(hidden, hidden),
        )
        self.edge_dim = config.relation_latent_dim + 8
        self.realized_edge_encoder = nn.Sequential(
            nn.Linear(9, hidden),
            nn.SiLU(),
            nn.Linear(hidden, self.edge_dim),
        )
        self.blocks = nn.ModuleList(
            _OrbitEGNNBlock(
                hidden_dim=hidden,
                edge_dim=self.edge_dim,
                radial_basis_count=config.radial_basis_count,
            )
            for _ in range(config.block_count)
        )
        centers = torch.linspace(
            0.0,
            config.cutoff_angstrom,
            config.radial_basis_count,
        )
        self.register_buffer("radial_centers", centers)
        spacing = config.cutoff_angstrom / (config.radial_basis_count - 1)
        self.radial_gamma = 1.0 / (spacing * spacing)
        self.free_parameter_head = nn.Linear(hidden, 3)
        self.lattice_head = nn.Linear(hidden, 6)
        self.cell_index_head = nn.Linear(
            hidden,
            config.maximum_cell_index + 1,
        )
        self.termination_head = nn.Linear(hidden, 1)
        self.physics_head = nn.Linear(hidden, 9)

    def _node_features(
        self,
        batch: IntegratedBatch,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        batch_size, maximum_orbits = batch.active_mask.shape
        if maximum_orbits != self.config.maximum_orbits:
            raise ValueError("geometry maximum_orbits does not match the batch")
        composition = self.composition_encoder(batch.composition / 20.0)
        remaining = self.remaining_encoder(batch.remaining_composition / 20.0)
        global_values = torch.cat(
            (
                composition,
                remaining,
                batch.progress,
                batch.lattice_degrees,
                batch.pooled_relation,
                batch.physics_feedback,
            ),
            dim=-1,
        )
        global_state = self.global_encoder(global_values)
        node_count = maximum_orbits + 1
        species = torch.zeros(
            batch_size,
            node_count,
            dtype=torch.long,
            device=batch.composition.device,
        )
        wyckoff = torch.zeros_like(species)
        species[:, :maximum_orbits] = batch.active_species
        wyckoff[:, :maximum_orbits] = batch.active_wyckoff
        species[:, maximum_orbits] = batch.candidate_species
        wyckoff[:, maximum_orbits] = batch.candidate_wyckoff
        scalar = batch.composition.new_zeros((batch_size, node_count, 6))
        scalar[:, :maximum_orbits, :3] = batch.active_free_parameters
        scalar[:, :maximum_orbits, 3] = batch.active_multiplicity / 20.0
        scalar[:, :maximum_orbits, 4] = batch.active_mask.float()
        scalar[:, maximum_orbits, 3] = batch.candidate_multiplicity / 20.0
        scalar[:, maximum_orbits, 4] = (
            batch.candidate_free_parameter_count / 3.0
        )
        scalar[:, maximum_orbits, 5] = 1.0
        sg = self.space_group_embedding(batch.target_space_group)[:, None, :]
        sg = sg.expand(-1, node_count, -1)
        global_nodes = global_state[:, None, :].expand(-1, node_count, -1)
        node_values = torch.cat(
            (
                sg,
                self.species_embedding(species),
                self.wyckoff_embedding(wyckoff),
                scalar,
                global_nodes,
            ),
            dim=-1,
        )
        node_mask = torch.cat(
            (
                batch.active_mask,
                torch.ones(
                    batch_size,
                    1,
                    dtype=torch.bool,
                    device=batch.active_mask.device,
                ),
            ),
            dim=1,
        )
        return self.node_encoder(node_values), node_mask, global_state

    def _edges(
        self,
        batch: IntegratedBatch,
        relation: RelationRestorationOutput,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        batch_size = batch.batch_size
        node_count = self.config.maximum_orbits + 1
        offsets = (
            torch.arange(batch_size, device=batch.composition.device) * node_count
        )
        active_locations = batch.active_pair_mask.nonzero(as_tuple=False)
        active_source = active_locations[:, 1]
        active_target = active_locations[:, 2]
        active_event = active_locations[:, 0]
        active_vectors = batch.active_pair_vectors[batch.active_pair_mask]
        if active_vectors.numel():
            active_distance = torch.linalg.vector_norm(
                active_vectors,
                dim=-1,
                keepdim=True,
            )
            active_edge = self.realized_edge_encoder(
                torch.cat(
                    (
                        batch.pooled_relation[active_event],
                        active_distance / self.config.cutoff_angstrom,
                    ),
                    dim=-1,
                )
            )
        else:
            active_edge = batch.composition.new_empty((0, self.edge_dim))

        pair_count = batch.relation_event_index.shape[0]
        if relation.latent.shape != (pair_count, self.config.relation_latent_dim):
            raise ValueError("geometry relation latent shape mismatch")
        candidate_source = batch.relation_existing_orbit_index
        candidate_target = torch.full_like(
            candidate_source,
            self.config.maximum_orbits,
        )
        candidate_event = batch.relation_event_index
        candidate_edge = torch.cat(
            (
                relation.latent,
                torch.sigmoid(relation.presence_logits),
                relation.continuous,
            ),
            dim=-1,
        )
        source = torch.cat(
            (
                active_source + offsets[active_event],
                candidate_source + offsets[candidate_event],
            )
        )
        target = torch.cat(
            (
                active_target + offsets[active_event],
                candidate_target + offsets[candidate_event],
            )
        )
        vectors = torch.cat((active_vectors, batch.relation_vectors), dim=0)
        edge_features = torch.cat((active_edge, candidate_edge), dim=0)
        return (
            torch.cat((source, target)),
            torch.cat((target, source)),
            torch.cat((vectors, -vectors), dim=0),
            torch.cat((edge_features, edge_features), dim=0),
        )

    def forward(
        self,
        batch: IntegratedBatch,
        relation: RelationRestorationOutput,
    ) -> GeometryGeneratorOutput:
        features, node_mask, _ = self._node_features(batch)
        batch_size, node_count, hidden = features.shape
        flat_features = features.reshape(batch_size * node_count, hidden)
        flat_mask = node_mask.reshape(-1)
        source, target, vectors, edge_features = self._edges(batch, relation)
        distances = torch.linalg.vector_norm(vectors, dim=-1)
        radial = torch.exp(
            -self.radial_gamma
            * (distances[:, None] - self.radial_centers[None, :]).square()
        )
        total_coordinate = vectors.new_zeros((batch_size * node_count, 3))
        for block in self.blocks:
            flat_features, coordinate = block(
                flat_features,
                source=source,
                target=target,
                vectors=vectors,
                edge_features=edge_features,
                radial=radial,
                node_mask=flat_mask,
            )
            total_coordinate = total_coordinate + coordinate
        query_indices = (
            torch.arange(batch_size, device=flat_features.device) * node_count
            + self.config.maximum_orbits
        )
        query = flat_features[query_indices]
        delta_cartesian = self.config.coordinate_step_scale * torch.tanh(
            total_coordinate[query_indices]
        )
        inverse_lattice = torch.linalg.inv(batch.lattice)
        delta_fractional = torch.bmm(
            delta_cartesian[:, None, :],
            inverse_lattice,
        ).squeeze(1)
        representative = torch.remainder(
            batch.candidate_seed_representative + delta_fractional,
            1.0,
        )
        output = GeometryGeneratorOutput(
            free_parameters=torch.sigmoid(self.free_parameter_head(query)),
            representative_fractional=representative,
            representative_delta_cartesian=delta_cartesian,
            lattice_degrees=(
                batch.lattice_degrees
                + 0.1 * torch.tanh(self.lattice_head(query))
            ),
            cell_index_logits=self.cell_index_head(query),
            termination_logits=self.termination_head(query),
            physics_prediction=self.physics_head(query),
        )
        tensors = tuple(getattr(output, name) for name in output.__dataclass_fields__)
        if any(not bool(torch.isfinite(tensor).all()) for tensor in tensors):
            raise FloatingPointError("non-finite relation-conditioned geometry output")
        return output
