"""Integrated relation-aware Crysalis crystal generator."""

from crysalis_g1.full_crysalis.config import FullCrysalisConfig

__all__ = ["FullCrysalisConfig"]
