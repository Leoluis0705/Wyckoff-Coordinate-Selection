from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from crysalis_g1.state.embryo import MaterialEmbryoState


@dataclass(frozen=True)
class EnergyEligibility:
    eligible: bool
    reason_codes: tuple[str, ...]
    composition_fixed_during_step: bool
    topology_fixed_during_step: bool
    oracle_domain_status: str


@dataclass(frozen=True)
class EnergyEvaluation:
    energy_ev: float | None
    energy_per_atom_ev: float | None
    forces_ev_per_angstrom: tuple[tuple[float, float, float], ...] | None
    stress_gpa: tuple[float, ...] | None
    source: str
    oracle_version: str
    weight_sha256: str
    eligibility: EnergyEligibility


class EnergyOracle(Protocol):
    def evaluate(self, state: MaterialEmbryoState) -> EnergyEvaluation: ...


class NullEnergyOracle:
    """Fail-closed placeholder; it never emits an energy pseudo-label."""

    def evaluate(self, state: MaterialEmbryoState) -> EnergyEvaluation:
        del state
        return EnergyEvaluation(
            energy_ev=None,
            energy_per_atom_ev=None,
            forces_ev_per_angstrom=None,
            stress_gpa=None,
            source="NONE",
            oracle_version="none",
            weight_sha256="",
            eligibility=EnergyEligibility(
                False,
                ("ENERGY_ORACLE_NOT_CONFIGURED",),
                True,
                True,
                "NOT_EVALUATED",
            ),
        )

