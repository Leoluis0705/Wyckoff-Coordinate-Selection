from __future__ import annotations

import hashlib
import json
import math
import warnings
from dataclasses import asdict, dataclass
from functools import lru_cache
from typing import Any, Iterable

import numpy as np
import spglib
from pymatgen.core import Lattice, Structure
from pyxtal.symmetry import Group


PRIMARY_SYMPREC = 0.03
AUDIT_SYMPRECS = (0.01, PRIMARY_SYMPREC, 0.05, 0.10)
SETTING_CONVENTION = "pyxtal-1.1.4-standard-conventional-to-primitive"


_CENTERING_TRANSFORMS: dict[str, tuple[tuple[float, float, float], ...]] = {
    "P": ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0)),
    "A": ((1.0, 0.0, 0.0), (0.0, 0.5, -0.5), (0.0, 0.5, 0.5)),
    "B": ((0.5, 0.0, -0.5), (0.0, 1.0, 0.0), (0.5, 0.0, 0.5)),
    "C": ((0.5, -0.5, 0.0), (0.5, 0.5, 0.0), (0.0, 0.0, 1.0)),
    "I": ((-0.5, 0.5, 0.5), (0.5, -0.5, 0.5), (0.5, 0.5, -0.5)),
    "F": ((0.0, 0.5, 0.5), (0.5, 0.0, 0.5), (0.5, 0.5, 0.0)),
    "R": (
        (2.0 / 3.0, -1.0 / 3.0, -1.0 / 3.0),
        (1.0 / 3.0, 1.0 / 3.0, -2.0 / 3.0),
        (1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0),
    ),
}


class WyckoffExpansionError(ValueError):
    def __init__(self, reason_code: str, detail: str):
        self.reason_code = reason_code
        self.detail = detail
        super().__init__(f"{reason_code}: {detail}")


@lru_cache(maxsize=230)
def _group(number: int) -> Group:
    if not 1 <= number <= 230:
        raise ValueError("space-group number must be in [1, 230]")
    return Group(number)


@dataclass(frozen=True, slots=True)
class SpaceGroupSetting:
    target_space_group: int
    hall_number: int
    hall_symbol: str
    international_symbol: str
    crystal_system: str
    centering: str
    convention: str
    primitive_transform_values: tuple[tuple[float, float, float], ...]

    @classmethod
    def for_number(cls, number: int) -> SpaceGroupSetting:
        return _setting_for_number(number)

    @property
    def primitive_transform(self) -> np.ndarray:
        return np.asarray(self.primitive_transform_values, dtype=float)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@lru_cache(maxsize=230)
def _setting_for_number(number: int) -> SpaceGroupSetting:
    group = _group(number)
    hall_number = int(group.hall_number)
    space_group_type = spglib.get_spacegroup_type(hall_number)
    if space_group_type is None or int(space_group_type.number) != number:
        raise RuntimeError(f"cannot resolve standard Hall setting for SG {number}")
    symbol = str(group.symbol)
    centering = symbol[0].upper()
    if centering not in _CENTERING_TRANSFORMS:
        raise RuntimeError(f"unsupported lattice centering {centering!r} for SG {number}")
    return SpaceGroupSetting(
        target_space_group=number,
        hall_number=hall_number,
        hall_symbol=str(space_group_type.hall_symbol),
        international_symbol=str(space_group_type.international_short),
        crystal_system=str(group.lattice_type),
        centering=centering,
        convention=SETTING_CONVENTION,
        primitive_transform_values=_CENTERING_TRANSFORMS[centering],
    )


def _canonical_parameter(value: float) -> float:
    if not math.isfinite(value):
        raise ValueError("Wyckoff free parameters must be finite")
    wrapped = round(float(value) % 1.0, 12)
    return 0.0 if math.isclose(wrapped, 1.0, abs_tol=1e-12) else wrapped


def _periodic_equal(left: np.ndarray, right: np.ndarray, tolerance: float) -> bool:
    delta = left - right
    delta -= np.round(delta)
    return bool(np.max(np.abs(delta)) <= tolerance)


def _canonical_fractional_coordinates(
    coordinates: Iterable[Iterable[float]], *, tolerance: float = 1e-8
) -> tuple[tuple[float, float, float], ...]:
    unique: list[np.ndarray] = []
    for coordinate in np.asarray(tuple(coordinates), dtype=float).reshape(-1, 3):
        wrapped = np.mod(coordinate, 1.0)
        wrapped[np.isclose(wrapped, 1.0, atol=tolerance)] = 0.0
        if not any(_periodic_equal(wrapped, other, tolerance) for other in unique):
            unique.append(wrapped)
    return tuple(
        sorted(
            (
                tuple(float(round(value, 12)) for value in coordinate)
                for coordinate in unique
            ),
            key=lambda value: value,
        )
    )


def _primitive_coordinates(
    conventional_coordinates: np.ndarray, setting: SpaceGroupSetting
) -> tuple[tuple[float, float, float], ...]:
    inverse_transform = np.linalg.inv(setting.primitive_transform)
    return _canonical_fractional_coordinates(
        np.asarray(conventional_coordinates, dtype=float) @ inverse_transform
    )


def _validate_cell_transform(
    transform: Iterable[Iterable[int | float]],
) -> tuple[tuple[int, int, int], ...]:
    array = np.asarray(tuple(tuple(row) for row in transform), dtype=float)
    if array.shape != (3, 3) or not np.isfinite(array).all():
        raise ValueError("cell transform must be a finite 3x3 matrix")
    rounded = np.rint(array)
    if not np.allclose(array, rounded, atol=1e-10):
        raise ValueError("cell transform must contain integers")
    determinant = float(np.linalg.det(rounded))
    if determinant <= 0 or not math.isclose(
        determinant, round(determinant), abs_tol=1e-8
    ):
        raise ValueError("cell transform must have a positive integer determinant")
    return tuple(tuple(int(value) for value in row) for row in rounded)


def _apply_cell_transform(
    coordinates: tuple[tuple[float, float, float], ...],
    transform: tuple[tuple[int, int, int], ...],
) -> tuple[tuple[float, float, float], ...]:
    if transform == ((1, 0, 0), (0, 1, 0), (0, 0, 1)):
        return coordinates
    structure = Structure(
        Lattice(np.eye(3)),
        [1] * len(coordinates),
        coordinates,
        to_unit_cell=True,
    )
    structure.make_supercell(np.asarray(transform, dtype=int))
    return _canonical_fractional_coordinates(structure.frac_coords)


def _wyckoff_position(number: int, letter: str):
    try:
        position = _group(number).get_wyckoff_position(letter)
    except Exception as error:
        raise ValueError(f"unknown Wyckoff position {letter!r} for SG {number}") from error
    if position is None:
        raise ValueError(f"unknown Wyckoff position {letter!r} for SG {number}")
    return position


def _expanded_coordinates(
    number: int,
    letter: str,
    free_parameters: tuple[float, ...],
    cell_transform: tuple[tuple[int, int, int], ...],
) -> tuple[tuple[float, float, float], ...]:
    position = _wyckoff_position(number, letter)
    expected_dof = int(position.get_dof())
    if len(free_parameters) != expected_dof:
        raise ValueError(
            f"Wyckoff {position.get_label()} requires {expected_dof} free parameters, "
            f"received {len(free_parameters)}"
        )
    generator = np.asarray(
        position.get_position_from_free_xyzs(list(free_parameters)), dtype=float
    )
    conventional = np.asarray(position.apply_ops(generator), dtype=float)
    primitive = _primitive_coordinates(
        conventional, SpaceGroupSetting.for_number(number)
    )
    return _apply_cell_transform(primitive, cell_transform)


@dataclass(frozen=True, slots=True)
class OrbitState:
    target_space_group: int
    hall_number: int
    space_group_setting: str
    wyckoff_position_id: str
    wyckoff_letter: str
    multiplicity: int
    species: int
    free_parameters: tuple[float, ...]
    cell_transform_values: tuple[tuple[int, int, int], ...]
    orbit_instance_id: str

    @classmethod
    def create(
        cls,
        target_space_group: int,
        wyckoff_letter: str,
        species: int,
        free_parameters: Iterable[float],
        *,
        cell_transform: Iterable[Iterable[int | float]] = (
            (1, 0, 0),
            (0, 1, 0),
            (0, 0, 1),
        ),
        orbit_instance_id: str | None = None,
    ) -> OrbitState:
        if not 1 <= int(species) <= 118:
            raise ValueError("orbit species must be an atomic number in [1, 118]")
        setting = SpaceGroupSetting.for_number(int(target_space_group))
        position = _wyckoff_position(setting.target_space_group, wyckoff_letter)
        parameters = tuple(_canonical_parameter(value) for value in free_parameters)
        transform = _validate_cell_transform(cell_transform)
        coordinates = _expanded_coordinates(
            setting.target_space_group,
            str(position.letter),
            parameters,
            transform,
        )
        identity_payload = {
            "target_space_group": setting.target_space_group,
            "hall_number": setting.hall_number,
            "wyckoff_position_id": str(position.get_label()),
            "species": int(species),
            "free_parameters": parameters,
            "cell_transform": transform,
        }
        identity = orbit_instance_id or (
            "orbit-state-"
            + hashlib.sha256(
                json.dumps(identity_payload, sort_keys=True).encode("utf-8")
            ).hexdigest()
        )
        if not identity:
            raise ValueError("orbit_instance_id must be non-empty")
        return cls(
            target_space_group=setting.target_space_group,
            hall_number=setting.hall_number,
            space_group_setting=setting.convention,
            wyckoff_position_id=str(position.get_label()),
            wyckoff_letter=str(position.letter),
            multiplicity=len(coordinates),
            species=int(species),
            free_parameters=parameters,
            cell_transform_values=transform,
            orbit_instance_id=identity,
        )

    def __post_init__(self) -> None:
        setting = SpaceGroupSetting.for_number(self.target_space_group)
        if self.hall_number != setting.hall_number:
            raise ValueError("orbit Hall number does not match target SG standard setting")
        if self.space_group_setting != setting.convention:
            raise ValueError("unsupported orbit setting convention")
        position = _wyckoff_position(self.target_space_group, self.wyckoff_letter)
        if self.wyckoff_position_id != str(position.get_label()):
            raise ValueError("Wyckoff position ID and letter disagree")
        coordinates = _expanded_coordinates(
            self.target_space_group,
            self.wyckoff_letter,
            self.free_parameters,
            _validate_cell_transform(self.cell_transform_values),
        )
        if self.multiplicity != len(coordinates):
            raise ValueError("orbit multiplicity does not match its Wyckoff manifold")
        if not 1 <= self.species <= 118:
            raise ValueError("orbit species must be an atomic number in [1, 118]")
        if not self.orbit_instance_id:
            raise ValueError("orbit_instance_id must be non-empty")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @property
    def cell_transform(self) -> np.ndarray:
        return np.asarray(self.cell_transform_values, dtype=int)

    @property
    def cell_index(self) -> int:
        return int(round(np.linalg.det(self.cell_transform)))

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> OrbitState:
        return cls(
            target_space_group=int(payload["target_space_group"]),
            hall_number=int(payload["hall_number"]),
            space_group_setting=str(payload["space_group_setting"]),
            wyckoff_position_id=str(payload["wyckoff_position_id"]),
            wyckoff_letter=str(payload["wyckoff_letter"]),
            multiplicity=int(payload["multiplicity"]),
            species=int(payload["species"]),
            free_parameters=tuple(float(value) for value in payload["free_parameters"]),
            cell_transform_values=_validate_cell_transform(
                payload.get(
                    "cell_transform_values",
                    ((1, 0, 0), (0, 1, 0), (0, 0, 1)),
                )
            ),
            orbit_instance_id=str(payload["orbit_instance_id"]),
        )


@dataclass(frozen=True, slots=True)
class ConstrainedLattice:
    target_space_group: int
    crystal_system: str
    conventional_parameters: tuple[float, float, float, float, float, float]
    conventional_matrix: tuple[tuple[float, float, float], ...]
    base_primitive_matrix: tuple[tuple[float, float, float], ...]
    primitive_matrix: tuple[tuple[float, float, float], ...]
    cell_transform_values: tuple[tuple[int, int, int], ...]

    @property
    def cell_index(self) -> int:
        return int(round(np.linalg.det(np.asarray(self.cell_transform_values))))

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class SpaceGroupConstrainedLatticeHead:
    """Rebuilds a lattice from only the target crystal system's legal DOFs."""

    def constrain(
        self,
        target_space_group: int,
        proposed: Iterable[float],
        *,
        cell_transform: Iterable[Iterable[int | float]] = (
            (1, 0, 0),
            (0, 1, 0),
            (0, 0, 1),
        ),
    ) -> ConstrainedLattice:
        values = tuple(float(value) for value in proposed)
        if len(values) != 6 or not all(math.isfinite(value) for value in values):
            raise ValueError("lattice proposal must contain six finite values")
        a, b, c, alpha, beta, gamma = values
        if min(a, b, c) <= 0:
            raise ValueError("lattice lengths must be positive")
        if not all(5.0 < angle < 175.0 for angle in (alpha, beta, gamma)):
            raise ValueError("lattice angles must lie strictly within (5, 175) degrees")
        setting = SpaceGroupSetting.for_number(target_space_group)
        system = setting.crystal_system
        if system == "triclinic":
            constrained = values
        elif system == "monoclinic":
            constrained = (a, b, c, 90.0, beta, 90.0)
        elif system == "orthorhombic":
            constrained = (a, b, c, 90.0, 90.0, 90.0)
        elif system == "tetragonal":
            basal = (a + b) / 2.0
            constrained = (basal, basal, c, 90.0, 90.0, 90.0)
        elif system in {"hexagonal", "trigonal"}:
            basal = (a + b) / 2.0
            constrained = (basal, basal, c, 90.0, 90.0, 120.0)
        elif system == "cubic":
            length = (a + b + c) / 3.0
            constrained = (length, length, length, 90.0, 90.0, 90.0)
        else:
            raise RuntimeError(f"unsupported crystal system {system!r}")
        conventional = np.asarray(Lattice.from_parameters(*constrained).matrix)
        transform = _validate_cell_transform(cell_transform)
        base_primitive = setting.primitive_transform @ conventional
        primitive = np.asarray(transform, dtype=float) @ base_primitive
        if not np.isfinite(primitive).all() or abs(np.linalg.det(primitive)) <= 1e-8:
            raise ValueError("constrained primitive lattice is singular or non-finite")
        return ConstrainedLattice(
            target_space_group=target_space_group,
            crystal_system=system,
            conventional_parameters=constrained,
            conventional_matrix=tuple(tuple(float(value) for value in row) for row in conventional),
            base_primitive_matrix=tuple(
                tuple(float(value) for value in row) for row in base_primitive
            ),
            primitive_matrix=tuple(tuple(float(value) for value in row) for row in primitive),
            cell_transform_values=transform,
        )


@dataclass(frozen=True, slots=True)
class ExpandedStructure:
    target_space_group: int
    atomic_numbers: tuple[int, ...]
    fractional_coordinates: tuple[tuple[float, float, float], ...]
    orbit_instance_ids: tuple[str, ...]
    orbit_slices: tuple[tuple[int, int], ...]
    expected_multiplicity: int
    detected_space_groups: dict[float, int]
    orbit_membership_valid: bool
    distinct_orbit_instances_valid: bool

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["detected_space_groups"] = {
            f"{symprec:.2f}": value
            for symprec, value in self.detected_space_groups.items()
        }
        return payload


def _symmetry_audit(
    lattice: np.ndarray,
    atomic_numbers: tuple[int, ...],
    coordinates: tuple[tuple[float, float, float], ...],
    orbit_slices: tuple[tuple[int, int], ...],
) -> tuple[dict[float, int], bool, bool]:
    detected: dict[float, int] = {}
    primary_equivalent: np.ndarray | None = None
    cell = (lattice, np.asarray(coordinates, dtype=float), np.asarray(atomic_numbers))
    for symprec in AUDIT_SYMPRECS:
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore", message="Set OLD_ERROR_HANDLING to false.*"
            )
            dataset = spglib.get_symmetry_dataset(
                cell, symprec=symprec, angle_tolerance=5.0
            )
        detected[symprec] = 0 if dataset is None else int(dataset.number)
        if symprec == PRIMARY_SYMPREC and dataset is not None:
            primary_equivalent = np.asarray(
                dataset.crystallographic_orbits, dtype=int
            )
    if primary_equivalent is None:
        return detected, False, False
    groups: list[int] = []
    for start, stop in orbit_slices:
        membership = set(int(value) for value in primary_equivalent[start:stop])
        if len(membership) != 1:
            return detected, False, False
        groups.append(next(iter(membership)))
    return detected, True, len(groups) == len(set(groups))


class SpaceGroupConditionedWyckoffExpander:
    """Expands one orbit object through pinned crystallographic operations."""

    def expand(
        self,
        orbit: OrbitState,
        lattice: Iterable[Iterable[float]],
        *,
        require_target_space_group: bool = True,
        require_distinct_orbit_instances: bool = True,
    ) -> ExpandedStructure:
        return self.expand_many(
            (orbit,),
            lattice,
            require_target_space_group=require_target_space_group,
            require_distinct_orbit_instances=require_distinct_orbit_instances,
        )

    def expand_many(
        self,
        orbits: Iterable[OrbitState],
        lattice: Iterable[Iterable[float]],
        *,
        require_target_space_group: bool = True,
        require_distinct_orbit_instances: bool = True,
    ) -> ExpandedStructure:
        orbit_tuple = tuple(orbits)
        if not orbit_tuple:
            raise WyckoffExpansionError("NO_ORBITS", "at least one orbit is required")
        target = orbit_tuple[0].target_space_group
        if any(orbit.target_space_group != target for orbit in orbit_tuple):
            raise WyckoffExpansionError(
                "MIXED_TARGET_SPACE_GROUPS", "all orbit states must share one target SG"
            )
        cell_transform = orbit_tuple[0].cell_transform_values
        if any(
            orbit.cell_transform_values != cell_transform for orbit in orbit_tuple
        ):
            raise WyckoffExpansionError(
                "MIXED_CELL_TRANSFORMS",
                "all orbit states must share one integer cell transform",
            )
        matrix = np.asarray(tuple(tuple(row) for row in lattice), dtype=float)
        if matrix.shape != (3, 3) or not np.isfinite(matrix).all():
            raise WyckoffExpansionError(
                "INVALID_LATTICE", "lattice must be a finite 3x3 matrix"
            )
        if abs(np.linalg.det(matrix)) <= 1e-8:
            raise WyckoffExpansionError("INVALID_LATTICE", "lattice is singular")
        atomic_numbers: list[int] = []
        coordinates: list[tuple[float, float, float]] = []
        instance_ids: list[str] = []
        slices: list[tuple[int, int]] = []
        for orbit in orbit_tuple:
            expanded = _expanded_coordinates(
                orbit.target_space_group,
                orbit.wyckoff_letter,
                orbit.free_parameters,
                orbit.cell_transform_values,
            )
            if len(expanded) != orbit.multiplicity:
                raise WyckoffExpansionError(
                    "MULTIPLICITY_MISMATCH",
                    f"{orbit.orbit_instance_id} expected {orbit.multiplicity}, got {len(expanded)}",
                )
            start = len(coordinates)
            coordinates.extend(expanded)
            stop = len(coordinates)
            slices.append((start, stop))
            atomic_numbers.extend([orbit.species] * orbit.multiplicity)
            instance_ids.extend([orbit.orbit_instance_id] * orbit.multiplicity)
        for index, coordinate in enumerate(coordinates):
            for other in range(index):
                if _periodic_equal(
                    np.asarray(coordinate), np.asarray(coordinates[other]), 1e-8
                ):
                    raise WyckoffExpansionError(
                        "ORBIT_IDENTITY_CONFLICT",
                        f"expanded sites {other} and {index} occupy the same periodic point",
                    )
        atomic_tuple = tuple(atomic_numbers)
        coordinate_tuple = tuple(coordinates)
        slice_tuple = tuple(slices)
        detected, membership_valid, distinct_instances_valid = _symmetry_audit(
            matrix, atomic_tuple, coordinate_tuple, slice_tuple
        )
        if not membership_valid:
            raise WyckoffExpansionError(
                "ORBIT_MEMBERSHIP_MISMATCH",
                "an expanded orbit does not form one symmetry-equivalent site set",
            )
        if require_distinct_orbit_instances and not distinct_instances_valid:
            raise WyckoffExpansionError(
                "ORBIT_INSTANCE_MERGE",
                "two orbit instances merge under the detected structure symmetry",
            )
        if require_target_space_group and detected[PRIMARY_SYMPREC] != target:
            raise WyckoffExpansionError(
                "TARGET_SPACE_GROUP_MISMATCH",
                f"target {target}, detected {detected[PRIMARY_SYMPREC]} at symprec=0.03",
            )
        return ExpandedStructure(
            target_space_group=target,
            atomic_numbers=atomic_tuple,
            fractional_coordinates=coordinate_tuple,
            orbit_instance_ids=tuple(instance_ids),
            orbit_slices=slice_tuple,
            expected_multiplicity=len(coordinates),
            detected_space_groups=detected,
            orbit_membership_valid=membership_valid,
            distinct_orbit_instances_valid=distinct_instances_valid,
        )


@lru_cache(maxsize=262144)
def orbit_representative_fractional_coordinate(
    orbit: OrbitState,
) -> tuple[float, float, float]:
    """Return one primitive-cell representative without expanding atom-level state."""
    return _expanded_coordinates(
        orbit.target_space_group,
        orbit.wyckoff_letter,
        orbit.free_parameters,
        orbit.cell_transform_values,
    )[0]
