from __future__ import annotations

import math
from collections import Counter
from dataclasses import asdict, dataclass, replace
from functools import lru_cache
from typing import Any, Iterable

import numpy as np
from pymatgen.core import Lattice, Structure
from pyxtal.symmetry import Group

from crysalis_g1.symmetry.wyckoff import (
    PRIMARY_SYMPREC,
    ConstrainedLattice,
    OrbitState,
    SpaceGroupConditionedWyckoffExpander,
    SpaceGroupConstrainedLatticeHead,
    WyckoffExpansionError,
)


class IllegalAssemblyAction(ValueError):
    def __init__(self, reason_code: str, detail: str):
        self.reason_code = reason_code
        self.detail = detail
        super().__init__(f"{reason_code}: {detail}")


@dataclass(frozen=True, slots=True)
class AddOrbitAction:
    wyckoff_letter: str
    species: int
    free_parameters: tuple[float, ...]
    orbit_instance_id: str


@dataclass(frozen=True, slots=True)
class LegalAddOrbit:
    wyckoff_position_id: str
    wyckoff_letter: str
    species: int
    multiplicity: int
    free_parameter_count: int


@dataclass(frozen=True, slots=True)
class SymmetryAssemblyState:
    target_space_group: int
    composition: tuple[tuple[int, int], ...]
    remaining_composition: tuple[tuple[int, int], ...]
    lattice: ConstrainedLattice
    orbits: tuple[OrbitState, ...]
    terminated: bool = False

    @classmethod
    def empty(
        cls,
        *,
        target_space_group: int,
        composition: Iterable[tuple[int, int]],
        lattice: ConstrainedLattice,
    ) -> SymmetryAssemblyState:
        normalized = tuple(sorted((int(z), int(count)) for z, count in composition))
        if not normalized or any(
            not 1 <= atomic_number <= 118 or count <= 0
            for atomic_number, count in normalized
        ):
            raise ValueError("composition must contain positive atomic-number counts")
        if len({atomic_number for atomic_number, _ in normalized}) != len(normalized):
            raise ValueError("composition atomic numbers must be unique")
        if lattice.target_space_group != target_space_group:
            raise ValueError("lattice target SG does not match assembly target SG")
        return cls(
            target_space_group=target_space_group,
            composition=normalized,
            remaining_composition=normalized,
            lattice=lattice,
            orbits=(),
        )

    @property
    def site_count(self) -> int:
        return sum(orbit.multiplicity for orbit in self.orbits)

    @property
    def remaining(self) -> Counter[int]:
        return Counter(dict(self.remaining_composition))

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _generic_parameters(count: int) -> tuple[float, ...]:
    return (0.173, 0.287, 0.391)[:count]


def _can_decompose(count: int, multiplicities: tuple[int, ...]) -> bool:
    if count == 0:
        return True
    reachable = [False] * (count + 1)
    reachable[0] = True
    for value in range(1, count + 1):
        reachable[value] = any(
            value >= multiplicity and reachable[value - multiplicity]
            for multiplicity in multiplicities
        )
    return reachable[count]


@lru_cache(maxsize=1024)
def _wyckoff_catalog(
    target_space_group: int,
    cell_transform: tuple[tuple[int, int, int], ...],
) -> tuple[tuple[str, str, int, int], ...]:
    result = []
    for position in Group(target_space_group).Wyckoff_positions:
        dof = int(position.get_dof())
        probe = OrbitState.create(
            target_space_group,
            str(position.letter),
            1,
            _generic_parameters(dof),
            cell_transform=cell_transform,
        )
        result.append(
            (
                probe.wyckoff_position_id,
                probe.wyckoff_letter,
                probe.multiplicity,
                dof,
            )
        )
    return tuple(result)


class SpaceGroupLegalActionCompiler:
    def __init__(self, *, max_sites: int):
        if max_sites <= 0:
            raise ValueError("max_sites must be positive")
        self.max_sites = int(max_sites)

    def _definitions(self, state: SymmetryAssemblyState) -> tuple[LegalAddOrbit, ...]:
        result = []
        remaining = state.remaining
        existing_fixed = {
            orbit.wyckoff_letter
            for orbit in state.orbits
            if int(
                Group(state.target_space_group)
                .get_wyckoff_position(orbit.wyckoff_letter)
                .get_dof()
            )
            == 0
        }
        for position_id, letter, multiplicity, dof in _wyckoff_catalog(
            state.target_space_group, state.lattice.cell_transform_values
        ):
            if dof == 0 and letter in existing_fixed:
                continue
            for species, count in sorted(remaining.items()):
                if multiplicity > count:
                    continue
                if state.site_count + multiplicity > self.max_sites:
                    continue
                result.append(
                    LegalAddOrbit(
                        wyckoff_position_id=position_id,
                        wyckoff_letter=letter,
                        species=species,
                        multiplicity=multiplicity,
                        free_parameter_count=dof,
                    )
                )
        return tuple(result)

    def legal_add_actions(
        self, state: SymmetryAssemblyState
    ) -> tuple[LegalAddOrbit, ...]:
        if state.terminated:
            return ()
        definitions = self._definitions(state)
        all_multiplicities = tuple(
            sorted({definition.multiplicity for definition in definitions})
        )
        legal = []
        for definition in definitions:
            residual = state.remaining.copy()
            residual[definition.species] -= definition.multiplicity
            if residual[definition.species] == 0:
                del residual[definition.species]
            if all(
                _can_decompose(count, all_multiplicities)
                for count in residual.values()
            ):
                legal.append(definition)
        return tuple(legal)

    def apply_add(
        self, state: SymmetryAssemblyState, action: AddOrbitAction
    ) -> SymmetryAssemblyState:
        matches = [
            definition
            for definition in self.legal_add_actions(state)
            if definition.wyckoff_letter == action.wyckoff_letter
            and definition.species == action.species
        ]
        if not matches:
            raise IllegalAssemblyAction(
                "ACTION_NOT_LEGAL",
                f"SG {state.target_space_group} {action.wyckoff_letter} Z={action.species}",
            )
        definition = matches[0]
        if len(action.free_parameters) != definition.free_parameter_count:
            raise IllegalAssemblyAction(
                "FREE_PARAMETER_COUNT_MISMATCH",
                f"expected {definition.free_parameter_count}, got {len(action.free_parameters)}",
            )
        if action.orbit_instance_id in {
            orbit.orbit_instance_id for orbit in state.orbits
        }:
            raise IllegalAssemblyAction(
                "ORBIT_IDENTITY_CONFLICT", action.orbit_instance_id
            )
        orbit = OrbitState.create(
            state.target_space_group,
            action.wyckoff_letter,
            action.species,
            action.free_parameters,
            cell_transform=state.lattice.cell_transform_values,
            orbit_instance_id=action.orbit_instance_id,
        )
        remaining = state.remaining
        remaining[action.species] -= orbit.multiplicity
        if remaining[action.species] < 0:
            raise IllegalAssemblyAction(
                "COMPOSITION_BUDGET_EXCEEDED", action.orbit_instance_id
            )
        if remaining[action.species] == 0:
            del remaining[action.species]
        return replace(
            state,
            remaining_composition=tuple(sorted(remaining.items())),
            orbits=(*state.orbits, orbit),
        )

    @staticmethod
    def can_terminate(
        state: SymmetryAssemblyState, receipt: ProjectionReceipt
    ) -> bool:
        return bool(
            not state.remaining_composition
            and receipt.accepted
            and receipt.target_space_group == state.target_space_group
            and receipt.detected_space_groups.get(PRIMARY_SYMPREC)
            == state.target_space_group
            and receipt.composition_valid
            and receipt.multiplicity_valid
            and receipt.distinct_orbit_instances_valid
            and receipt.minimum_distance_valid
        )


@dataclass(frozen=True, slots=True)
class ProjectionReceipt:
    target_space_group: int
    accepted: bool
    partial_state: bool
    detected_space_groups: dict[float, int]
    orbit_membership_valid: bool
    distinct_orbit_instances_valid: bool
    composition_valid: bool
    multiplicity_valid: bool
    minimum_distance_valid: bool
    minimum_distance_angstrom: float | None
    reason_codes: tuple[str, ...]
    correction_amount: float
    repaired: bool
    atomic_numbers: tuple[int, ...]
    fractional_coordinates: tuple[tuple[float, float, float], ...]
    lattice: tuple[tuple[float, float, float], ...]

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["detected_space_groups"] = {
            f"{value:.2f}": detected
            for value, detected in self.detected_space_groups.items()
        }
        return payload


class C0SymmetryProjector:
    def __init__(self, *, minimum_distance: float):
        if not math.isfinite(minimum_distance) or minimum_distance <= 0:
            raise ValueError("minimum_distance must be finite and positive")
        self.minimum_distance = float(minimum_distance)

    def project(self, state: SymmetryAssemblyState) -> ProjectionReceipt:
        constrained = SpaceGroupConstrainedLatticeHead().constrain(
            state.target_space_group,
            state.lattice.conventional_parameters,
            cell_transform=state.lattice.cell_transform_values,
        )
        reasons: list[str] = []
        detected: dict[float, int] = {}
        membership_valid = False
        distinct_instances_valid = False
        multiplicity_valid = False
        atomic_numbers: tuple[int, ...] = ()
        coordinates: tuple[tuple[float, float, float], ...] = ()
        partial = bool(state.remaining_composition)
        try:
            expanded = SpaceGroupConditionedWyckoffExpander().expand_many(
                state.orbits,
                constrained.primitive_matrix,
                require_target_space_group=False,
                require_distinct_orbit_instances=not partial,
            )
            detected = expanded.detected_space_groups
            membership_valid = expanded.orbit_membership_valid
            distinct_instances_valid = expanded.distinct_orbit_instances_valid
            atomic_numbers = expanded.atomic_numbers
            coordinates = expanded.fractional_coordinates
            multiplicity_valid = all(
                stop - start == orbit.multiplicity
                for orbit, (start, stop) in zip(
                    state.orbits, expanded.orbit_slices, strict=True
                )
            )
        except WyckoffExpansionError as error:
            reasons.append(error.reason_code)
        target_composition = Counter(dict(state.composition))
        assembled = Counter(atomic_numbers)
        remaining = state.remaining
        composition_valid = assembled + remaining == target_composition
        if not composition_valid:
            reasons.append("COMPOSITION_MISMATCH")
        if not multiplicity_valid:
            reasons.append("MULTIPLICITY_MISMATCH")
        if not membership_valid:
            reasons.append("ORBIT_MEMBERSHIP_MISMATCH")
        if not partial and not distinct_instances_valid:
            reasons.append("ORBIT_INSTANCE_MERGE")
        minimum_distance_value: float | None = None
        minimum_distance_valid = False
        if atomic_numbers:
            structure = Structure(
                Lattice(constrained.primitive_matrix),
                atomic_numbers,
                coordinates,
                to_unit_cell=True,
            )
            if len(structure) == 1:
                minimum_distance_value = None
                minimum_distance_valid = True
            else:
                distances = np.asarray(structure.distance_matrix, dtype=float)
                np.fill_diagonal(distances, np.inf)
                minimum_distance_value = float(distances.min())
                minimum_distance_valid = (
                    minimum_distance_value >= self.minimum_distance
                )
        if not minimum_distance_valid:
            reasons.append("SHORT_CONTACT")
        if (
            not partial
            and detected.get(PRIMARY_SYMPREC) != state.target_space_group
        ):
            reasons.append("TARGET_SPACE_GROUP_MISMATCH")
        return ProjectionReceipt(
            target_space_group=state.target_space_group,
            accepted=not reasons,
            partial_state=partial,
            detected_space_groups=detected,
            orbit_membership_valid=membership_valid,
            distinct_orbit_instances_valid=distinct_instances_valid,
            composition_valid=composition_valid,
            multiplicity_valid=multiplicity_valid,
            minimum_distance_valid=minimum_distance_valid,
            minimum_distance_angstrom=minimum_distance_value,
            reason_codes=tuple(dict.fromkeys(reasons)),
            correction_amount=0.0,
            repaired=False,
            atomic_numbers=atomic_numbers,
            fractional_coordinates=coordinates,
            lattice=constrained.primitive_matrix,
        )
