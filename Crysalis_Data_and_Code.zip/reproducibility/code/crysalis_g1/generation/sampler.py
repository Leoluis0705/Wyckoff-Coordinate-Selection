from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from crysalis_g1.actions import ActionType, AssemblyAction
from crysalis_g1.constraints.projector import CrystallographicProjector
from crysalis_g1.state.embryo import MaterialEmbryoState, initialize_embryo
from crysalis_g1.state.trajectory import Trajectory, TrajectoryStep


@dataclass(frozen=True)
class GeneratedCandidate:
    candidate_id: str
    composition: tuple[tuple[int, int], ...]
    final_state: MaterialEmbryoState
    trajectory: Trajectory
    replay_hash: str


def _smoke_composition(rng: np.random.Generator) -> dict[int, int]:
    elements = np.array([6, 7, 8, 11, 12, 13, 14, 17], dtype=int)
    element_count = int(rng.integers(2, 4))
    selected = rng.choice(elements, size=element_count, replace=False)
    counts = rng.integers(1, 4, size=element_count)
    while int(counts.sum()) > 12:
        counts[int(np.argmax(counts))] -= 1
    return {int(z): int(count) for z, count in zip(selected, counts, strict=True)}


def generate_smoke_candidates(*, count: int, seed: int) -> list[GeneratedCandidate]:
    if count <= 0:
        raise ValueError("count must be positive")
    root_rng = np.random.default_rng(seed)
    projector = CrystallographicProjector(max_sites=12)
    candidates: list[GeneratedCandidate] = []
    for index in range(count):
        candidate_seed = int(root_rng.integers(0, 2**31 - 1))
        rng = np.random.default_rng(candidate_seed)
        composition = _smoke_composition(rng)
        state = initialize_embryo(composition, space_group=1, seed=candidate_seed)
        initial_state = state
        steps: list[TrajectoryStep] = []
        for atomic_number, atomic_count in state.composition:
            for _ in range(atomic_count):
                free = tuple(float(value) for value in rng.random(3))
                add = AssemblyAction(
                    ActionType.ADD_ORBIT,
                    (("wyckoff_letter", "a"), ("free_parameters", free)),
                )
                state, receipt = projector.apply(state, add)
                if not receipt.legal:
                    raise RuntimeError(f"smoke ADD_ORBIT rejected: {receipt.reason_codes}")
                steps.append(TrajectoryStep(add, state.content_hash(), receipt))
                orbit_id = state.orbit_states[-1].orbit_id
                assign = AssemblyAction(
                    ActionType.ASSIGN_SPECIES,
                    (("orbit_id", orbit_id), ("atomic_number", atomic_number)),
                )
                state, receipt = projector.apply(state, assign)
                if not receipt.legal:
                    raise RuntimeError(f"smoke ASSIGN_SPECIES rejected: {receipt.reason_codes}")
                steps.append(TrajectoryStep(assign, state.content_hash(), receipt))
        for edge_index in range(max(0, len(state.orbit_states) - 1)):
            add_edge = AssemblyAction(
                ActionType.ADD_PERIODIC_EDGE,
                (
                    ("source_id", state.orbit_states[edge_index].orbit_id),
                    ("target_id", state.orbit_states[edge_index + 1].orbit_id),
                    ("image", (0, 0, 0)),
                    ("relation_type", "smoke_neighbor"),
                    ("memory", (0.0,) * 8),
                ),
            )
            state, receipt = projector.apply(state, add_edge)
            if not receipt.legal:
                raise RuntimeError(f"smoke edge rejected: {receipt.reason_codes}")
            steps.append(TrajectoryStep(add_edge, state.content_hash(), receipt))
        terminate = AssemblyAction(ActionType.TERMINATE, ())
        state, receipt = projector.apply(state, terminate)
        if not receipt.legal:
            raise RuntimeError(f"smoke termination rejected: {receipt.reason_codes}")
        steps.append(TrajectoryStep(terminate, state.content_hash(), receipt))
        trajectory = Trajectory(
            f"smoke-trajectory-{index:04d}", initial_state, tuple(steps)
        )
        replay_hash = trajectory.replay(projector).content_hash()
        candidates.append(
            GeneratedCandidate(
                f"smoke-candidate-{index:04d}",
                state.composition,
                state,
                trajectory,
                replay_hash,
            )
        )
    return candidates

