from __future__ import annotations

import hashlib
from dataclasses import dataclass, replace
from typing import Any

from crysalis_assembly.serialization import canonical_payload_json

from crysalis_g1.actions import ActionType, AssemblyAction
from crysalis_g1.state.embryo import (
    ActionReceipt,
    FeasibilityRecord,
    LatticeState,
    MaterialEmbryoState,
)
from crysalis_g1.state.motif import MotifFactor
from crysalis_g1.state.orbit import OrbitState
from crysalis_g1.state.periodic_edge import PersistentPeriodicEdgeState


SMOKE_WYCKOFF_MULTIPLICITY: dict[int, dict[str, int]] = {
    1: {"a": 1},
    2: {"a": 1, "b": 1, "i": 2},
}


@dataclass(frozen=True)
class LegalityDecision:
    legal: bool
    reason_codes: tuple[str, ...]


def _float3(values: Any) -> tuple[float, float, float]:
    if not isinstance(values, (tuple, list)) or len(values) != 3:
        raise ValueError("expected a numeric 3-vector")
    return float(values[0]), float(values[1]), float(values[2])


def _int3(values: Any) -> tuple[int, int, int]:
    if not isinstance(values, (tuple, list)) or len(values) != 3:
        raise ValueError("expected an integer 3-vector")
    if any(type(value) is not int for value in values):
        raise ValueError("expected an integer 3-vector")
    return int(values[0]), int(values[1]), int(values[2])


def _matrix3(values: Any) -> tuple[tuple[float, float, float], ...]:
    if not isinstance(values, (tuple, list)) or len(values) != 3:
        raise ValueError("expected a 3x3 matrix")
    return tuple(_float3(row) for row in values)


def _new_state_id(state: MaterialEmbryoState) -> str:
    return "state-" + state.content_hash()[:16]


def _updated_remaining(
    remaining: tuple[tuple[int, int], ...], atomic_number: int, decrement: int
) -> tuple[tuple[int, int], ...]:
    counts = dict(remaining)
    counts[atomic_number] -= decrement
    if counts[atomic_number] == 0:
        counts.pop(atomic_number)
    return tuple(sorted(counts.items()))


class CrystallographicProjector:
    def __init__(self, *, max_sites: int) -> None:
        self.max_sites = max_sites

    def is_action_legal(
        self, state: MaterialEmbryoState, action: AssemblyAction
    ) -> LegalityDecision:
        if state.terminated:
            return LegalityDecision(False, ("STATE_ALREADY_TERMINATED",))
        params = action.params
        if action.action_type is ActionType.ADD_ORBIT:
            if len(state.orbit_states) >= self.max_sites:
                return LegalityDecision(False, ("SITE_BUDGET_EXCEEDED",))
            table = SMOKE_WYCKOFF_MULTIPLICITY.get(state.space_group or -1)
            letter = params.get("wyckoff_letter")
            if table is None or letter not in table:
                return LegalityDecision(False, ("WYCKOFF_NOT_IN_FROZEN_SMOKE_TABLE",))
            free = params.get("free_parameters", ())
            if not isinstance(free, (tuple, list)) or len(free) != 3:
                return LegalityDecision(False, ("FREE_PARAMETER_DIMENSION",))
            return LegalityDecision(True, ())
        if action.action_type is ActionType.ASSIGN_SPECIES:
            orbit = next(
                (item for item in state.orbit_states if item.orbit_id == params.get("orbit_id")),
                None,
            )
            if orbit is None:
                return LegalityDecision(False, ("UNKNOWN_ORBIT",))
            if orbit.atomic_number is not None:
                return LegalityDecision(False, ("ORBIT_ALREADY_ASSIGNED",))
            atomic_number = params.get("atomic_number")
            if type(atomic_number) is not int:
                return LegalityDecision(False, ("INVALID_SPECIES",))
            if dict(state.remaining_composition).get(atomic_number, 0) < orbit.multiplicity:
                return LegalityDecision(False, ("COMPOSITION_BUDGET_EXCEEDED",))
            return LegalityDecision(True, ())
        if action.action_type is ActionType.ADD_PERIODIC_EDGE:
            known = {item.orbit_id for item in state.orbit_states}
            if params.get("source_id") not in known or params.get("target_id") not in known:
                return LegalityDecision(False, ("UNKNOWN_EDGE_ENDPOINT",))
            image = params.get("image")
            if not isinstance(image, (tuple, list)) or len(image) != 3 or any(
                type(value) is not int for value in image
            ):
                return LegalityDecision(False, ("INVALID_PERIODIC_IMAGE",))
            return LegalityDecision(True, ())
        if action.action_type is ActionType.ADD_MOTIF:
            known = {item.orbit_id for item in state.orbit_states}
            members = tuple(params.get("member_ids", ()))
            if not members or not set(members).issubset(known):
                return LegalityDecision(False, ("UNKNOWN_MOTIF_MEMBER",))
            return LegalityDecision(True, ())
        if action.action_type is ActionType.UPDATE_LATTICE:
            matrix = params.get("matrix")
            try:
                LatticeState(_matrix3(matrix), "updated")
            except (TypeError, ValueError):
                return LegalityDecision(False, ("INVALID_LATTICE",))
            return LegalityDecision(True, ())
        if action.action_type is ActionType.REFINE_GEOMETRY:
            known = {item.orbit_id for item in state.orbit_states}
            if params.get("orbit_id") not in known:
                return LegalityDecision(False, ("UNKNOWN_ORBIT",))
            return LegalityDecision(True, ())
        if action.action_type is ActionType.TERMINATE:
            if state.remaining_composition:
                return LegalityDecision(False, ("INCOMPLETE_COMPOSITION",))
            if any(item.atomic_number is None for item in state.orbit_states):
                return LegalityDecision(False, ("UNASSIGNED_ORBIT",))
            if not state.orbit_states:
                return LegalityDecision(False, ("EMPTY_STRUCTURE",))
            return LegalityDecision(True, ())
        return LegalityDecision(False, ("UNSUPPORTED_ACTION",))

    def apply(
        self, state: MaterialEmbryoState, action: AssemblyAction
    ) -> tuple[MaterialEmbryoState, ActionReceipt]:
        before_hash = state.content_hash()
        decision = self.is_action_legal(state, action)
        if not decision.legal:
            receipt = ActionReceipt(False, decision.reason_codes, before_hash, before_hash)
            return state, receipt
        params: dict[str, Any] = action.params
        updated = state
        if action.action_type is ActionType.ADD_ORBIT:
            letter = str(params["wyckoff_letter"])
            multiplicity = SMOKE_WYCKOFF_MULTIPLICITY[state.space_group or 1][letter]
            free_raw = _float3(params["free_parameters"])
            free = (free_raw[0] % 1.0, free_raw[1] % 1.0, free_raw[2] % 1.0)
            orbit_payload = {
                "state": before_hash,
                "letter": letter,
                "index": len(state.orbit_states),
                "free": free,
            }
            orbit_id = "orbit-" + hashlib.sha256(
                canonical_payload_json(orbit_payload).encode()
            ).hexdigest()[:16]
            coordinates = tuple(free for _ in range(multiplicity))
            orbit = OrbitState(
                orbit_id=orbit_id,
                wyckoff_letter=letter,
                multiplicity=multiplicity,
                atomic_number=None,
                oxidation_state=None,
                occupancy=1.0,
                free_parameters=free,
                free_parameter_mask=(True, True, True),
                expanded_fractional_coordinates=coordinates,
                added_step=state.assembly_step,
                legality_status="PASS",
                uncertainty=0.0,
            )
            updated = replace(state, orbit_states=state.orbit_states + (orbit,))
        elif action.action_type is ActionType.ASSIGN_SPECIES:
            orbit_id = str(params["orbit_id"])
            atomic_number = int(params["atomic_number"])
            new_orbits = tuple(
                replace(item, atomic_number=atomic_number)
                if item.orbit_id == orbit_id
                else item
                for item in state.orbit_states
            )
            multiplicity = next(
                item.multiplicity for item in state.orbit_states if item.orbit_id == orbit_id
            )
            updated = replace(
                state,
                orbit_states=new_orbits,
                remaining_composition=_updated_remaining(
                    state.remaining_composition, atomic_number, multiplicity
                ),
            )
        elif action.action_type is ActionType.ADD_PERIODIC_EDGE:
            edge = PersistentPeriodicEdgeState.create(
                source_id=str(params["source_id"]),
                target_id=str(params["target_id"]),
                image=_int3(params["image"]),
                relation_type=str(params.get("relation_type", "neighbor")),
                memory=tuple(float(value) for value in params.get("memory", ())),
                assembly_age=state.assembly_step,
            )
            if edge.edge_id not in {item.edge_id for item in state.periodic_edges}:
                updated = replace(state, periodic_edges=state.periodic_edges + (edge,))
        elif action.action_type is ActionType.ADD_MOTIF:
            motif_payload = canonical_payload_json(params)
            motif = MotifFactor(
                motif_id="motif-" + hashlib.sha256(motif_payload.encode()).hexdigest()[:16],
                motif_type=str(params["motif_type"]),
                member_ids=tuple(str(value) for value in params["member_ids"]),
                edge_ids=tuple(str(value) for value in params.get("edge_ids", ())),
                confidence=float(params.get("confidence", 1.0)),
                source_rule=str(params.get("source_rule", "smoke-certified")),
                created_step=state.assembly_step,
            )
            updated = replace(state, motif_factors=state.motif_factors + (motif,))
        elif action.action_type is ActionType.UPDATE_LATTICE:
            lattice = LatticeState(
                _matrix3(params["matrix"]),
                "updated",
            )
            updated = replace(state, lattice_state=lattice)
        elif action.action_type is ActionType.REFINE_GEOMETRY:
            orbit_id = str(params["orbit_id"])
            free_raw = _float3(params["free_parameters"])
            free = (free_raw[0] % 1.0, free_raw[1] % 1.0, free_raw[2] % 1.0)
            updated = replace(
                state,
                orbit_states=tuple(
                    replace(
                        item,
                        free_parameters=free,
                        expanded_fractional_coordinates=tuple(
                            free for _ in range(item.multiplicity)
                        ),
                    )
                    if item.orbit_id == orbit_id
                    else item
                    for item in state.orbit_states
                ),
            )
        elif action.action_type is ActionType.TERMINATE:
            updated = replace(state, terminated=True)
        updated = replace(
            updated,
            assembly_step=state.assembly_step + 1,
            feasibility=FeasibilityRecord(
                1.0,
                (),
                not updated.remaining_composition
                and bool(updated.orbit_states)
                and all(item.atomic_number is not None for item in updated.orbit_states),
            ),
        )
        after_hash = updated.content_hash()
        receipt = ActionReceipt(True, (), before_hash, after_hash)
        updated = replace(
            updated,
            state_id=_new_state_id(updated),
            history=state.history + (receipt,),
        )
        return updated, receipt

    def project(self, state: MaterialEmbryoState) -> LegalityDecision:
        reasons: list[str] = []
        if state.lattice_state is None:
            reasons.append("MISSING_LATTICE")
        if len(state.orbit_states) > self.max_sites:
            reasons.append("SITE_BUDGET_EXCEEDED")
        if any(item.legality_status != "PASS" for item in state.orbit_states):
            reasons.append("ORBIT_LEGALITY_FAILED")
        return LegalityDecision(not reasons, tuple(reasons))
