from __future__ import annotations

from dataclasses import dataclass

from crysalis_g1.state.periodic_edge import PersistentPeriodicEdgeState


@dataclass(frozen=True)
class PersistentPeriodicEdgeGraph:
    edges: tuple[PersistentPeriodicEdgeState, ...]

    def __post_init__(self) -> None:
        identities = tuple(edge.edge_id for edge in self.edges)
        if len(identities) != len(set(identities)):
            raise ValueError("persistent edge identities must be unique")

    def update_memory(
        self, updates: dict[str, tuple[float, ...]]
    ) -> PersistentPeriodicEdgeGraph:
        unknown = set(updates) - {edge.edge_id for edge in self.edges}
        if unknown:
            raise ValueError(f"unknown persistent edge IDs: {sorted(unknown)}")
        return PersistentPeriodicEdgeGraph(
            tuple(
                edge.with_memory(updates[edge.edge_id])
                if edge.edge_id in updates
                else edge
                for edge in self.edges
            )
        )

