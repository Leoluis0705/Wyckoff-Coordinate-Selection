from __future__ import annotations

import itertools
import math

import numpy as np
import torch


def _search_radius(delta: np.ndarray, lattice: np.ndarray) -> int:
    singular_min = float(np.linalg.svd(lattice, compute_uv=False).min())
    if singular_min <= 0:
        raise ValueError("lattice must be non-singular")
    center = -np.rint(delta).astype(int)
    initial = (delta + center) @ lattice
    upper_bound = float(np.linalg.norm(initial))
    return max(1, int(math.ceil(upper_bound / singular_min)) + 1)


def nearest_image_numpy(
    delta_fractional: np.ndarray, lattice: np.ndarray
) -> tuple[tuple[int, int, int], np.ndarray, float]:
    delta = np.asarray(delta_fractional, dtype=np.float64)
    cell = np.asarray(lattice, dtype=np.float64)
    if delta.shape != (3,) or cell.shape != (3, 3):
        raise ValueError("delta and lattice must have shapes (3,) and (3, 3)")
    center = -np.rint(delta).astype(int)
    radius = _search_radius(delta, cell)
    candidates: list[tuple[float, tuple[int, int, int], np.ndarray]] = []
    for offset in itertools.product(range(-radius, radius + 1), repeat=3):
        image_array = center + np.asarray(offset, dtype=int)
        vector = (delta + image_array) @ cell
        image = (
            int(image_array[0]),
            int(image_array[1]),
            int(image_array[2]),
        )
        candidates.append((float(np.linalg.norm(vector)), image, vector))
    distance, image, vector = min(candidates, key=lambda item: (item[0], item[1]))
    return image, vector, distance


def nearest_image_torch(
    delta_fractional: torch.Tensor, lattice: torch.Tensor
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    if delta_fractional.shape != (3,) or lattice.shape != (3, 3):
        raise ValueError("delta and lattice must have shapes (3,) and (3, 3)")
    image, _, _ = nearest_image_numpy(
        delta_fractional.detach().cpu().double().numpy(),
        lattice.detach().cpu().double().numpy(),
    )
    image_tensor = torch.tensor(image, dtype=torch.long, device=delta_fractional.device)
    vector = (delta_fractional + image_tensor.to(delta_fractional.dtype)) @ lattice
    return image_tensor, vector, torch.linalg.vector_norm(vector)
