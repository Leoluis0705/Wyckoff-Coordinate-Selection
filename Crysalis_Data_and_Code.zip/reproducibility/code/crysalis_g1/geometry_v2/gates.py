from __future__ import annotations

import hashlib
import json
import os
import subprocess
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from pathlib import Path

import yaml


_GATE_PREREQUISITES = {
    "G1": ("G0",),
    "G2": ("G0", "G1"),
    "G3": ("G0", "G1", "G2"),
}
_SERVER_CONFIG_RELATIVE = Path("configs/geometry_v2_server_training_20260828_v1.yaml")


@dataclass(frozen=True, slots=True)
class FrozenGateContractV2:
    registered_run_id: str
    registered_seed: int
    config_sha256: str
    data_manifest_sha256: str
    checkpoint_contract: str
    config_blob_oid: str
    ledger_directory: Path

    @classmethod
    def from_repository(cls) -> FrozenGateContractV2:
        return _load_frozen_gate_contract(Path(__file__).resolve().parents[2])


def _load_frozen_gate_contract(repository_root: Path) -> FrozenGateContractV2:
    config_path = repository_root / _SERVER_CONFIG_RELATIVE
    relative = _SERVER_CONFIG_RELATIVE.as_posix()
    try:
        raw = subprocess.run(
            ["git", "show", f"HEAD:{relative}"],
            cwd=repository_root,
            check=True,
            capture_output=True,
        ).stdout
        blob_oid = subprocess.run(
            ["git", "rev-parse", f"HEAD:{relative}"],
            cwd=repository_root,
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()
    except (OSError, subprocess.CalledProcessError) as error:
        raise ValueError("frozen gate config must exist in the committed HEAD") from error
    if config_path.read_bytes() != raw:
        raise ValueError("working-tree gate config differs from committed HEAD")
    payload = yaml.safe_load(raw)
    if not isinstance(payload, Mapping):
        raise ValueError("frozen Geometry V2 server config must be a mapping")
    try:
        run_id = payload["provenance"]["registered_run_id"]
        seed = payload["seeds"]["registered_sampler_root"]
        manifest = payload["data"]["phase2a_manifest_sha256"]
        checkpoint_contract = payload["checkpoint_selection"]["schema_version"]
        ledger_root = payload["server_package"]["gate_attempt_ledger_root"]
    except (KeyError, TypeError) as error:
        raise ValueError("frozen gate identity fields are missing from server config") from error
    config_sha256 = hashlib.sha256(raw).hexdigest()
    if not isinstance(run_id, str) or not run_id:
        raise ValueError("frozen gate run ID is invalid")
    if type(seed) is not int or seed < 0:
        raise ValueError("frozen gate seed is invalid")
    if not isinstance(manifest, str) or len(manifest) != 64 or any(
        character not in "0123456789abcdef" for character in manifest
    ):
        raise ValueError("frozen gate data manifest SHA-256 is invalid")
    if not isinstance(checkpoint_contract, str) or not checkpoint_contract:
        raise ValueError("frozen gate checkpoint contract is invalid")
    ledger_relative = Path(str(ledger_root))
    if ledger_relative.is_absolute() or ".." in ledger_relative.parts:
        raise ValueError("frozen gate ledger root must be repository-relative")
    ledger_directory = repository_root / ledger_relative / run_id / "gate-attempts"
    return FrozenGateContractV2(
        run_id,
        seed,
        config_sha256,
        manifest,
        checkpoint_contract,
        blob_oid,
        ledger_directory,
    )


@dataclass(frozen=True, slots=True)
class FormalGateAuthorizationV2:
    server_authorized: bool
    formal_authorized: bool
    execution_environment: str

    def __post_init__(self) -> None:
        if type(self.server_authorized) is not bool or type(self.formal_authorized) is not bool:
            raise TypeError("gate authorization flags must be exact booleans")
        if self.execution_environment not in {"local", "server"}:
            raise ValueError("gate execution environment must be local or server")

    def require(self) -> None:
        if not (
            self.server_authorized
            and self.formal_authorized
            and self.execution_environment == "server"
        ):
            raise PermissionError(
                "explicit server and formal authorization is required for G1/G2/G3"
            )


@dataclass(frozen=True, slots=True)
class FormalGateRunReceiptV2:
    gate: str
    status: str
    prerequisite_statuses: tuple[tuple[str, str], ...]
    failure_reason_codes: tuple[str, ...]
    attempt_count: int
    retry_permitted: bool


class GateAttemptLedgerV2:
    """Immutable, process-safe start receipts for formal gate attempts."""

    def __init__(self) -> None:
        self.contract = FrozenGateContractV2.from_repository()
        self.directory = self.contract.ledger_directory

    def claim(self, *, gate: str) -> Path:
        contract = self.contract
        identity = ":".join(
            (
                gate,
                contract.registered_run_id,
                str(contract.registered_seed),
                contract.config_blob_oid,
                contract.config_sha256,
                contract.checkpoint_contract,
            )
        )
        filename = hashlib.sha256(identity.encode("ascii")).hexdigest() + ".json"
        self.directory.mkdir(parents=True, exist_ok=True)
        path = self.directory / filename
        payload = {
            "schema_version": "crysalis-geometry-v2-gate-attempt.1.0.0",
            "gate": gate,
            "registered_run_id": contract.registered_run_id,
            "registered_seed": contract.registered_seed,
            "config_sha256": contract.config_sha256,
            "config_blob_oid": contract.config_blob_oid,
            "data_manifest_sha256": contract.data_manifest_sha256,
            "checkpoint_contract": contract.checkpoint_contract,
            "status": "STARTED",
        }
        try:
            with path.open("x", encoding="utf-8", newline="\n") as target:
                target.write(json.dumps(payload, sort_keys=True) + "\n")
                target.flush()
                os.fsync(target.fileno())
        except FileExistsError as error:
            raise PermissionError(
                "formal gate attempt already exists; retry is forbidden"
            ) from error
        return path


def run_authorized_geometry_gate(
    gate: str,
    authorization: FormalGateAuthorizationV2,
    prior_statuses: Mapping[str, str],
    executor: Callable[[], Mapping[str, object]],
) -> FormalGateRunReceiptV2:
    if gate not in _GATE_PREREQUISITES:
        raise ValueError("only frozen Geometry V2 gates G1, G2, and G3 are supported")
    authorization.require()
    prerequisites = _GATE_PREREQUISITES[gate]
    statuses = tuple((name, str(prior_statuses.get(name, "MISSING"))) for name in prerequisites)
    failed = tuple(f"{name}_NOT_PASS" for name, status in statuses if status != "PASS")
    if failed:
        return FormalGateRunReceiptV2(
            gate=gate,
            status="BLOCKED_PREREQUISITE",
            prerequisite_statuses=statuses,
            failure_reason_codes=failed,
            attempt_count=0,
            retry_permitted=False,
        )
    GateAttemptLedgerV2().claim(gate=gate)
    result = executor()
    status = result.get("status")
    if status not in {"PASS", "FAIL"}:
        raise ValueError("formal gate executor must return frozen PASS or FAIL status")
    raw_reasons = result.get("failure_reason_codes", ())
    if not isinstance(raw_reasons, (tuple, list)) or any(
        not isinstance(reason, str) or not reason for reason in raw_reasons
    ):
        raise ValueError("formal gate failure reasons must be non-empty strings")
    reasons = tuple(raw_reasons)
    if status == "FAIL" and not reasons:
        reasons = ("FROZEN_GATE_FAILED",)
    if status == "PASS" and reasons:
        raise ValueError("passing formal gate cannot carry failure reasons")
    return FormalGateRunReceiptV2(
        gate=gate,
        status=str(status),
        prerequisite_statuses=statuses,
        failure_reason_codes=reasons,
        attempt_count=1,
        retry_permitted=False,
    )


__all__ = [
    "FormalGateAuthorizationV2",
    "FrozenGateContractV2",
    "FormalGateRunReceiptV2",
    "GateAttemptLedgerV2",
    "run_authorized_geometry_gate",
]
