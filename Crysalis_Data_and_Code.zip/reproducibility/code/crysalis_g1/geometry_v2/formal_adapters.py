from __future__ import annotations

import math
import hashlib
import json
import subprocess
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field, replace
from pathlib import Path

import numpy as np
import torch
import yaml
from pymatgen.core import Lattice

from crysalis_g1.symmetry.assembly import SymmetryAssemblyState
from crysalis_g1.symmetry.wyckoff import (
    ExpandedStructure,
    OrbitState,
    SpaceGroupConditionedWyckoffExpander,
    WyckoffExpansionError,
)

from .manifold import WyckoffManifoldAdapter, project_cartesian_forces
from .physics_guidance import GuidanceDriftV2
from .refinement import GuideObjectiveProtocolV2, RelationEvaluationV2
from .relation_interface import ActiveOrbitGraphV2, RelationPredictionV2


_VERIFIED_CALIBRATION_TOKEN = object()


def _valid_digest(value: object) -> bool:
    return (
        isinstance(value, str)
        and value != "0" * 64
        and len(value) == 64
        and all(character in "0123456789abcdef" for character in value)
    )


@dataclass(frozen=True, slots=True)
class RelationGeometryCalibrationV2:
    """Hash-verified physical thresholds with explicit frozen provenance."""

    shell_boundaries_angstrom: tuple[float, float, float]
    coordination_cutoff_angstrom: float
    relation_gradient_scale: float
    uncertainty_scale: float
    uncertainty_floor: float
    artifact_sha256: str
    artifact_path: str
    provenance_kind: str
    source_split: str
    source_dataset_sha256: str | None
    source_split_sha256: str | None
    source_manifest_sha256: str
    fit_receipt_sha256: str
    _verification_token: object = field(repr=False, compare=False)

    def __post_init__(self) -> None:
        boundaries = tuple(float(value) for value in self.shell_boundaries_angstrom)
        if not all(math.isfinite(value) and value > 0 for value in boundaries) or not (
            boundaries[0] < boundaries[1] < boundaries[2]
        ):
            raise ValueError("shell boundaries must be finite, positive, and increasing")
        if not math.isfinite(self.coordination_cutoff_angstrom) or (
            self.coordination_cutoff_angstrom <= 0
        ):
            raise ValueError("coordination cutoff must be finite and positive")
        if not math.isfinite(self.relation_gradient_scale) or self.relation_gradient_scale <= 0:
            raise ValueError("relation gradient scale must be finite and positive")
        if not math.isfinite(self.uncertainty_scale) or self.uncertainty_scale <= 0:
            raise ValueError("relation uncertainty scale must be finite and positive")
        if not math.isfinite(self.uncertainty_floor) or self.uncertainty_floor < 0:
            raise ValueError("relation uncertainty floor must be finite and non-negative")
        if self._verification_token is not _VERIFIED_CALIBRATION_TOKEN:
            raise TypeError("relation calibration must come from the verified artifact loader")
        if not _valid_digest(self.artifact_sha256):
            raise ValueError("relation calibration requires a non-default artifact SHA-256")


_SERVER_CONFIG_RELATIVE_PATH = Path(
    "configs/geometry_v2_server_training_20260828_v1.yaml"
)


def _committed_server_config_bytes(repository_root: Path) -> bytes:
    relative = _SERVER_CONFIG_RELATIVE_PATH.as_posix()
    try:
        committed = subprocess.run(
            ["git", "show", f"HEAD:{relative}"],
            cwd=repository_root,
            check=True,
            capture_output=True,
        ).stdout
    except (OSError, subprocess.CalledProcessError) as error:
        raise ValueError(
            "committed Geometry V2 server calibration contract is unavailable"
        ) from error
    working = repository_root / _SERVER_CONFIG_RELATIVE_PATH
    if not working.is_file() or working.read_bytes() != committed:
        raise ValueError("working server calibration config differs from committed HEAD")
    return committed


def _verified_source_file(
    package_root: Path,
    descriptor: Mapping[str, object],
    *,
    label: str,
) -> tuple[Path, str]:
    if set(descriptor) != {"path", "sha256"}:
        raise ValueError(f"{label} source descriptor is invalid")
    relative = Path(str(descriptor["path"]))
    expected = descriptor["sha256"]
    if relative.is_absolute() or ".." in relative.parts or not _valid_digest(expected):
        raise ValueError(f"{label} source descriptor is invalid")
    path = package_root / relative
    try:
        raw = path.read_bytes()
    except OSError as error:
        raise ValueError(f"{label} source artifact is unavailable") from error
    actual = hashlib.sha256(raw).hexdigest()
    if actual != expected:
        raise ValueError(f"{label} source artifact SHA-256 mismatch")
    return path, actual


def _json_lines(path: Path, *, label: str) -> tuple[Mapping[str, object], ...]:
    rows: list[Mapping[str, object]] = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError as error:
            raise ValueError(f"{label} line {line_number} is invalid JSON") from error
        if not isinstance(row, Mapping):
            raise ValueError(f"{label} line {line_number} is not an object")
        rows.append(row)
    return tuple(rows)


def _fit_verified_relation_distances(
    *,
    distances: Sequence[float],
    material_ids: Sequence[str],
    source_dataset_sha256: str,
    source_split_sha256: str,
    source_manifest_sha256: str,
    source_d_relation_sha256: str,
    output_path: str | Path,
) -> RelationGeometryCalibrationV2:
    values = np.asarray(distances, dtype=float)
    if values.ndim != 1 or len(values) < 4 or not bool(
        np.all(np.isfinite(values) & (values > 0))
    ):
        raise ValueError("verified train-fit relations require four positive distances")
    boundaries_array = np.asarray(np.quantile(values, (0.25, 0.5, 0.75)), dtype=float)
    if not bool(np.all(np.diff(boundaries_array) > 0)):
        raise ValueError("train-fit distances cannot define three distinct shell bins")
    median = float(np.median(values))
    mad = float(np.median(np.abs(values - median)))
    robust_scale = 1.4826 * mad
    robust_scale_method = "MAD_X_1_4826"
    if robust_scale <= 0:
        robust_scale = float(np.quantile(values, 0.75) - np.quantile(values, 0.25)) / 1.349
        robust_scale_method = "IQR_DIV_1_349_FALLBACK"
    if robust_scale <= 0:
        robust_scale = max(abs(median), 1.0)
        robust_scale_method = "MEDIAN_OR_ONE_FALLBACK"
    standardized_residuals = (values - median) / robust_scale
    canonical_material_ids = tuple(sorted(set(material_ids)))
    if not canonical_material_ids or any(not value for value in canonical_material_ids):
        raise ValueError("verified train-fit material IDs are required")
    material_ids_sha256 = hashlib.sha256(
        ("\n".join(canonical_material_ids) + "\n").encode("utf-8")
    ).hexdigest()
    fit_receipt = {
        "schema_version": "crysalis-geometry-v2-relation-calibration-fit.2.0.0",
        "algorithm": "PUBLIC_TRAIN_FIT_DISTANCE_ROBUST_V2",
        "observation_count": len(values),
        "material_count": len(canonical_material_ids),
        "material_ids_sha256": material_ids_sha256,
        "robust_scale_method": robust_scale_method,
        "source_dataset_sha256": source_dataset_sha256,
        "source_split_sha256": source_split_sha256,
        "source_manifest_sha256": source_manifest_sha256,
        "source_d_relation_sha256": source_d_relation_sha256,
    }
    fit_receipt_sha256 = hashlib.sha256(
        json.dumps(fit_receipt, sort_keys=True, separators=(",", ":")).encode(
            "utf-8"
        )
    ).hexdigest()
    payload = {
        "schema_version": "crysalis-geometry-v2-relation-calibration.2.0.0",
        "status": "FIT_COMPLETE",
        "shell_boundaries_angstrom": [float(value) for value in boundaries_array],
        "coordination_cutoff_angstrom": float(np.quantile(values, 0.9)),
        "relation_gradient_scale": float(1.0 / robust_scale),
        "relation_uncertainty_calibration": {
            "scale": float(np.sqrt(np.mean(np.square(standardized_residuals)))),
            "floor": float(np.quantile(np.abs(standardized_residuals), 0.05)),
        },
        "provenance": {
            "kind": "PUBLIC_TRAIN_FIT_DERIVED",
            "source_split": "train_fit",
            "source_dataset_sha256": source_dataset_sha256,
            "source_split_sha256": source_split_sha256,
            "source_manifest_sha256": source_manifest_sha256,
            "fit_receipt_sha256": fit_receipt_sha256,
        },
        "fit_receipt": fit_receipt,
    }
    raw = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("utf-8")
    artifact_path = Path(output_path)
    artifact_path.parent.mkdir(parents=True, exist_ok=True)
    with artifact_path.open("xb") as handle:
        handle.write(raw)
    return load_relation_geometry_calibration_v2(
        artifact_path, expected_sha256=hashlib.sha256(raw).hexdigest()
    )


def _fit_committed_relation_geometry_calibration_v2(
    *,
    repository_root: Path,
    output_path: str | Path,
) -> RelationGeometryCalibrationV2:
    server_config = yaml.safe_load(_committed_server_config_bytes(repository_root))
    contract = server_config["normalizers"]["relation_geometry_calibration"]
    source_contract = contract.get("source_package")
    if not isinstance(source_contract, Mapping):
        raise ValueError("committed train-fit calibration source package is missing")
    package_relative = Path(str(source_contract.get("package_root", "")))
    if (
        not package_relative.parts
        or package_relative.is_absolute()
        or ".." in package_relative.parts
    ):
        raise ValueError("committed train-fit calibration package path is invalid")
    package_root = repository_root / package_relative
    descriptors: dict[str, tuple[Path, str]] = {}
    for key in (
        "phase2a_manifest",
        "structure_ood_manifest",
        "canonical_relations",
        "d_relation_interface",
    ):
        descriptor = source_contract.get(key)
        if not isinstance(descriptor, Mapping):
            raise ValueError(f"committed {key} source descriptor is missing")
        descriptors[key] = _verified_source_file(
            package_root, descriptor, label=key
        )

    manifest_path, manifest_hash = descriptors["phase2a_manifest"]
    manifest = json.loads(manifest_path.read_bytes())
    if (
        not isinstance(manifest, Mapping)
        or manifest.get("sealed_or_blind_data_accessed") is not False
        or not _valid_digest(manifest.get("source_public_cache_sha256"))
        or not isinstance(manifest.get("file_sha256"), Mapping)
    ):
        raise ValueError("Phase2A manifest is not verified public-only provenance")
    manifest_files = manifest["file_sha256"]
    for key in (
        "structure_ood_manifest",
        "canonical_relations",
        "d_relation_interface",
    ):
        relative_path = str(source_contract[key]["path"])
        if manifest_files.get(relative_path) != descriptors[key][1]:
            raise ValueError(f"Phase2A manifest hash for {key} is inconsistent")

    split_path, split_hash = descriptors["structure_ood_manifest"]
    train_fit_ids: set[str] = set()
    seen_ids: set[str] = set()
    for row in _json_lines(split_path, label="structure-OOD split"):
        material_id = row.get("material_id")
        split = row.get("split")
        partition = row.get("source_partition")
        if not isinstance(material_id, str) or not material_id or material_id in seen_ids:
            raise ValueError("structure-OOD split material IDs are invalid or duplicated")
        seen_ids.add(material_id)
        if any(token in str(split).lower() for token in ("sealed", "blind", "test")):
            raise ValueError("structure-OOD split includes a forbidden calibration scope")
        if split == "train_fit":
            reason_codes = row.get("reason_codes")
            moved_to_protect_validation = (
                partition == "validation"
                and isinstance(reason_codes, list)
                and "MOVED_TO_PROTECT_STRUCTURE_OOD_VALIDATION" in reason_codes
            )
            if partition != "train_fit" and not moved_to_protect_validation:
                raise ValueError("train_fit row has inconsistent source partition")
            train_fit_ids.add(material_id)
    if not train_fit_ids:
        raise ValueError("structure-OOD split has no verified train_fit materials")

    relations_path, relations_hash = descriptors["canonical_relations"]
    distances: list[float] = []
    contributing_ids: list[str] = []
    relation_rows: set[str] = set()
    for row in _json_lines(relations_path, label="canonical relations"):
        material_id = row.get("material_id")
        if not isinstance(material_id, str) or material_id in relation_rows:
            raise ValueError("canonical relation material IDs are invalid or duplicated")
        relation_rows.add(material_id)
        if material_id not in train_fit_ids:
            continue
        relations = row.get("relations")
        if not isinstance(relations, list):
            raise ValueError("train_fit canonical relations are invalid")
        material_distances: list[float] = []
        for relation in relations:
            if not isinstance(relation, Mapping):
                raise ValueError("train_fit canonical relation is invalid")
            distance = relation.get("distance")
            if not isinstance(distance, (int, float)) or isinstance(distance, bool):
                raise ValueError("train_fit canonical relation distance is invalid")
            material_distances.append(float(distance))
        if material_distances:
            contributing_ids.append(material_id)
            distances.extend(material_distances)
    if not train_fit_ids.issubset(relation_rows):
        raise ValueError("canonical relations do not cover every train_fit material")
    return _fit_verified_relation_distances(
        distances=distances,
        material_ids=contributing_ids,
        source_dataset_sha256=relations_hash,
        source_split_sha256=split_hash,
        source_manifest_sha256=manifest_hash,
        source_d_relation_sha256=descriptors["d_relation_interface"][1],
        output_path=output_path,
    )


def fit_committed_relation_geometry_calibration_v2(
    output_path: str | Path,
) -> RelationGeometryCalibrationV2:
    """Fit only from the source package frozen by the committed server config."""

    return _fit_committed_relation_geometry_calibration_v2(
        repository_root=Path(__file__).resolve().parents[2],
        output_path=output_path,
    )


def validate_relation_geometry_calibration_contract_v2(
    calibration: RelationGeometryCalibrationV2,
) -> None:
    if not isinstance(calibration, RelationGeometryCalibrationV2):
        raise TypeError("formal calibration contract requires a verified artifact")
    repository_root = Path(__file__).resolve().parents[2]
    committed_config = _committed_server_config_bytes(repository_root)
    server_config = yaml.safe_load(committed_config)
    contract = server_config["normalizers"]["relation_geometry_calibration"]
    if contract.get("status") == "BLOCKED_PENDING_PUBLIC_TRAIN_FIT":
        raise ValueError(
            "BLOCKED_PENDING_PUBLIC_TRAIN_FIT: committed server calibration contract "
            "has no verified train-fit artifact"
        )
    if contract.get("provenance") != "PUBLIC_TRAIN_FIT_DERIVED":
        raise ValueError("committed server calibration provenance is not train_fit")
    relative_artifact = Path(str(contract["artifact_path"]))
    if relative_artifact.is_absolute() or ".." in relative_artifact.parts:
        raise ValueError("committed calibration artifact path must remain repository-local")
    expected_path = (repository_root / relative_artifact).resolve()
    if Path(calibration.artifact_path).resolve() != expected_path:
        raise ValueError("formal calibration artifact path differs from committed contract")
    if calibration.artifact_sha256 != contract.get("artifact_sha256"):
        raise ValueError("formal calibration artifact hash differs from committed contract")
    if hashlib.sha256(expected_path.read_bytes()).hexdigest() != calibration.artifact_sha256:
        raise ValueError("formal calibration artifact bytes differ from committed contract")
    if calibration.provenance_kind != "PUBLIC_TRAIN_FIT_DERIVED" or (
        calibration.source_split != "train_fit"
    ):
        raise ValueError("formal calibration provenance differs from committed contract")
    expected_provenance = {
        "source_dataset_sha256": calibration.source_dataset_sha256,
        "source_split_sha256": calibration.source_split_sha256,
        "source_manifest_sha256": calibration.source_manifest_sha256,
        "fit_receipt_sha256": calibration.fit_receipt_sha256,
    }
    if any(contract.get(key) != value for key, value in expected_provenance.items()):
        raise ValueError("formal calibration provenance differs from committed contract")
    if calibration.source_manifest_sha256 != server_config["normalizers"].get(
        "source_manifest_sha256"
    ):
        raise ValueError("formal calibration source manifest differs from committed contract")


def load_relation_geometry_calibration_v2(
    path: str | Path,
    *,
    expected_sha256: str,
) -> RelationGeometryCalibrationV2:
    artifact_path = Path(path)
    if not _valid_digest(expected_sha256):
        raise ValueError("expected calibration SHA-256 must be exact and non-default")
    raw = artifact_path.read_bytes()
    actual = hashlib.sha256(raw).hexdigest()
    if actual != expected_sha256:
        raise ValueError("relation calibration artifact SHA-256 mismatch")
    payload = json.loads(raw)
    if isinstance(payload, Mapping) and payload.get("status") == (
        "BLOCKED_PENDING_PUBLIC_TRAIN_FIT"
    ):
        raise ValueError(
            "BLOCKED_PENDING_PUBLIC_TRAIN_FIT: verified train-fit relation "
            "calibration artifact has not been fitted"
        )
    required = {
        "schema_version",
        "status",
        "shell_boundaries_angstrom",
        "coordination_cutoff_angstrom",
        "relation_gradient_scale",
        "relation_uncertainty_calibration",
        "provenance",
        "fit_receipt",
    }
    if not isinstance(payload, Mapping) or set(payload) != required or payload[
        "schema_version"
    ] != "crysalis-geometry-v2-relation-calibration.2.0.0" or payload[
        "status"
    ] != "FIT_COMPLETE":
        raise ValueError("relation calibration artifact schema is invalid")
    provenance = payload["provenance"]
    provenance_fields = {
        "kind",
        "source_split",
        "source_dataset_sha256",
        "source_split_sha256",
        "source_manifest_sha256",
        "fit_receipt_sha256",
    }
    if not isinstance(provenance, Mapping) or set(provenance) != provenance_fields:
        raise ValueError("relation calibration provenance fields are invalid")
    kind = provenance["kind"]
    source_split = provenance["source_split"]
    dataset_hash = provenance["source_dataset_sha256"]
    split_hash = provenance["source_split_sha256"]
    manifest_hash = provenance["source_manifest_sha256"]
    fit_receipt_hash = provenance["fit_receipt_sha256"]
    if (
        kind != "PUBLIC_TRAIN_FIT_DERIVED"
        or source_split != "train_fit"
        or not _valid_digest(dataset_hash)
        or not _valid_digest(split_hash)
        or not _valid_digest(manifest_hash)
        or not _valid_digest(fit_receipt_hash)
    ):
        raise ValueError("train-fit calibration provenance is invalid")
    fit_receipt = payload["fit_receipt"]
    if not isinstance(fit_receipt, Mapping):
        raise ValueError("train-fit calibration fit receipt is invalid")
    actual_fit_receipt_hash = hashlib.sha256(
        json.dumps(
            dict(fit_receipt), sort_keys=True, separators=(",", ":")
        ).encode("utf-8")
    ).hexdigest()
    if actual_fit_receipt_hash != fit_receipt_hash:
        raise ValueError("train-fit calibration fit receipt SHA-256 mismatch")
    receipt_required = {
        "schema_version",
        "algorithm",
        "observation_count",
        "material_count",
        "material_ids_sha256",
        "robust_scale_method",
        "source_dataset_sha256",
        "source_split_sha256",
        "source_manifest_sha256",
        "source_d_relation_sha256",
    }
    if (
        set(fit_receipt) != receipt_required
        or fit_receipt["schema_version"]
        != "crysalis-geometry-v2-relation-calibration-fit.2.0.0"
        or fit_receipt["algorithm"] != "PUBLIC_TRAIN_FIT_DISTANCE_ROBUST_V2"
        or type(fit_receipt["observation_count"]) is not int
        or fit_receipt["observation_count"] < 4
        or type(fit_receipt["material_count"]) is not int
        or fit_receipt["material_count"] < 1
        or not _valid_digest(fit_receipt["material_ids_sha256"])
        or fit_receipt["robust_scale_method"]
        not in {
            "MAD_X_1_4826",
            "IQR_DIV_1_349_FALLBACK",
            "MEDIAN_OR_ONE_FALLBACK",
        }
        or fit_receipt["source_dataset_sha256"] != dataset_hash
        or fit_receipt["source_split_sha256"] != split_hash
        or fit_receipt["source_manifest_sha256"] != manifest_hash
        or not _valid_digest(fit_receipt["source_d_relation_sha256"])
    ):
        raise ValueError("train-fit calibration fit receipt is invalid")
    boundaries = payload["shell_boundaries_angstrom"]
    if not isinstance(boundaries, list) or len(boundaries) != 3:
        raise ValueError("relation calibration shell boundaries are invalid")
    shell_boundaries = (
        float(boundaries[0]),
        float(boundaries[1]),
        float(boundaries[2]),
    )
    uncertainty = payload["relation_uncertainty_calibration"]
    if not isinstance(uncertainty, Mapping) or set(uncertainty) != {
        "scale",
        "floor",
    }:
        raise ValueError("relation uncertainty calibration is invalid")
    return RelationGeometryCalibrationV2(
        shell_boundaries_angstrom=shell_boundaries,
        coordination_cutoff_angstrom=float(payload["coordination_cutoff_angstrom"]),
        relation_gradient_scale=float(payload["relation_gradient_scale"]),
        uncertainty_scale=float(uncertainty["scale"]),
        uncertainty_floor=float(uncertainty["floor"]),
        artifact_sha256=actual,
        artifact_path=str(artifact_path),
        provenance_kind=str(kind),
        source_split=str(source_split),
        source_dataset_sha256=str(dataset_hash),
        source_split_sha256=str(split_hash),
        source_manifest_sha256=str(manifest_hash),
        fit_receipt_sha256=str(fit_receipt_hash),
        _verification_token=_VERIFIED_CALIBRATION_TOKEN,
    )


@dataclass(frozen=True, slots=True)
class RealizedRelationsV2:
    expanded: ExpandedStructure
    edge_state: torch.Tensor
    triplet_cosine: torch.Tensor


def _packed(orbits: tuple[OrbitState, ...]) -> np.ndarray:
    return np.asarray(
        [value for orbit in orbits for value in orbit.free_parameters], dtype=float
    )


def _replace_packed(
    orbits: tuple[OrbitState, ...], values: np.ndarray
) -> tuple[OrbitState, ...]:
    offset = 0
    updated: list[OrbitState] = []
    for orbit in orbits:
        count = len(orbit.free_parameters)
        updated.append(
            replace(
                orbit,
                free_parameters=tuple(
                    float(item % 1.0) for item in values[offset : offset + count]
                ),
            )
        )
        offset += count
    return tuple(updated)


def _minimum_image_displacements(
    candidate_sites: np.ndarray,
    anchor_sites: np.ndarray,
    lattice: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    periodic_lattice = Lattice(lattice)
    fractional: np.ndarray = np.empty(
        (len(candidate_sites), len(anchor_sites), 3), dtype=float
    )
    for candidate_index, candidate in enumerate(candidate_sites):
        for anchor_index, anchor in enumerate(anchor_sites):
            _, image = periodic_lattice.get_distance_and_image(anchor, candidate)
            fractional[candidate_index, anchor_index] = candidate + image - anchor
    return fractional, fractional @ lattice


def _nearest_pair(
    candidate_sites: np.ndarray,
    anchor_sites: np.ndarray,
    lattice: np.ndarray,
) -> tuple[float, np.ndarray]:
    fractional, cartesian = _minimum_image_displacements(
        candidate_sites, anchor_sites, lattice
    )
    distances = np.linalg.norm(cartesian, axis=-1)
    candidates = [
        (float(distances[i, j]), tuple(float(value) for value in fractional[i, j]))
        for i in range(distances.shape[0])
        for j in range(distances.shape[1])
    ]
    distance, vector = min(
        candidates,
        key=lambda item: (round(item[0], 12), *(round(v, 12) for v in item[1])),
    )
    return distance, np.asarray(vector, dtype=float)


def _candidate_centered_cosine(
    candidate_sites: np.ndarray,
    first_anchor: np.ndarray,
    second_anchor: np.ndarray,
    lattice: np.ndarray,
) -> float:
    values: list[float] = []
    for center in candidate_sites:
        _, first = _nearest_pair(center[None, :], first_anchor, lattice)
        _, second = _nearest_pair(center[None, :], second_anchor, lattice)
        first_cart = first @ lattice
        second_cart = second @ lattice
        denominator = np.linalg.norm(first_cart) * np.linalg.norm(second_cart)
        if denominator <= 1.0e-12:
            raise ValueError("candidate-centered triplet has a zero displacement")
        values.append(float(np.dot(first_cart, second_cart) / denominator))
    return float(np.mean(values))


def calculate_realized_relations_v2(
    state: SymmetryAssemblyState,
    graph: ActiveOrbitGraphV2,
    calibration: RelationGeometryCalibrationV2,
) -> RealizedRelationsV2:
    if not isinstance(state, SymmetryAssemblyState):
        raise TypeError("realized relations require SymmetryAssemblyState")
    if not isinstance(graph, ActiveOrbitGraphV2) or graph.batch_size != 1:
        raise TypeError("realized relations require one ActiveOrbitGraphV2")
    if not isinstance(calibration, RelationGeometryCalibrationV2):
        raise TypeError("realized relations require frozen train-fit calibration")
    active = graph.active_orbit_mask[0].detach().cpu().numpy()
    active_slots = tuple(int(index) for index in np.flatnonzero(active))
    if len(state.orbits) != len(active_slots):
        raise ValueError("official orbit count must match packed active topology")
    slot_to_orbit = {slot: index for index, slot in enumerate(active_slots)}
    lattice = np.asarray(state.lattice.primitive_matrix, dtype=float)
    expanded = SpaceGroupConditionedWyckoffExpander().expand_many(
        state.orbits,
        lattice,
        require_target_space_group=False,
        require_distinct_orbit_instances=False,
    )
    coordinates = np.asarray(expanded.fractional_coordinates, dtype=float)
    orbit_sites = tuple(coordinates[start:stop] for start, stop in expanded.orbit_slices)
    candidate_orbit_index = len(orbit_sites) - 1
    candidate_slot = active_slots[-1]
    candidate_sites = orbit_sites[candidate_orbit_index]
    edge_state = np.zeros((1, graph.edge_count, 14), dtype=float)
    for edge_slot in range(graph.edge_count):
        if not bool(graph.edge_mask[0, edge_slot]):
            continue
        anchor_slot = int(graph.edge_index[0, edge_slot])
        if anchor_slot == candidate_slot:
            raise ValueError("candidate-to-existing edge cannot self-reference")
        anchor_sites = orbit_sites[slot_to_orbit[anchor_slot]]
        distance, displacement = _nearest_pair(candidate_sites, anchor_sites, lattice)
        fourier = np.asarray(
            [
                function(2.0 * np.pi * value)
                for value in displacement
                for function in (np.sin, np.cos)
            ],
            dtype=float,
        )
        shell: np.ndarray = np.zeros(4, dtype=float)
        shell[int(np.searchsorted(calibration.shell_boundaries_angstrom, distance))] = 1.0
        _, cartesian = _minimum_image_displacements(candidate_sites, anchor_sites, lattice)
        relation_count = float(
            np.count_nonzero(
                np.linalg.norm(cartesian, axis=-1)
                <= calibration.coordination_cutoff_angstrom
            )
        )
        coordination = np.asarray(
            [relation_count / len(candidate_sites), relation_count / len(anchor_sites)],
            dtype=float,
        )
        edge_state[0, edge_slot] = np.concatenate(
            (np.asarray([1.0, distance]), fourier, shell, coordination)
        )
    triplet = np.zeros((1, graph.triplet_count, 1), dtype=float)
    for triplet_slot in range(graph.triplet_count):
        if not bool(graph.triplet_mask[0, triplet_slot]):
            continue
        first_slot, second_slot = (
            int(value) for value in graph.triplet_index[0, triplet_slot]
        )
        if candidate_slot in (first_slot, second_slot):
            raise ValueError("candidate-centered triplet anchors must be existing orbits")
        triplet[0, triplet_slot, 0] = _candidate_centered_cosine(
            candidate_sites,
            orbit_sites[slot_to_orbit[first_slot]],
            orbit_sites[slot_to_orbit[second_slot]],
            lattice,
        )
    dtype = graph.active_orbits.dtype
    device = graph.active_orbits.device
    return RealizedRelationsV2(
        expanded=expanded,
        edge_state=torch.as_tensor(edge_state, dtype=dtype, device=device),
        triplet_cosine=torch.as_tensor(triplet, dtype=dtype, device=device),
    )


class RelationConsistencyObjectiveV2:
    def __init__(
        self,
        state: SymmetryAssemblyState,
        prediction: RelationPredictionV2,
        graph: ActiveOrbitGraphV2,
        calibration: RelationGeometryCalibrationV2,
    ) -> None:
        if not isinstance(state, SymmetryAssemblyState):
            raise TypeError("relation adapter requires SymmetryAssemblyState")
        if not isinstance(prediction, RelationPredictionV2) or prediction.batch_size != 1:
            raise TypeError("relation adapter requires one RelationPredictionV2")
        if not isinstance(graph, ActiveOrbitGraphV2) or graph.batch_size != 1:
            raise TypeError("relation adapter requires one ActiveOrbitGraphV2")
        if not isinstance(calibration, RelationGeometryCalibrationV2):
            raise TypeError("relation adapter requires frozen calibration")
        self.state = state
        self.prediction = prediction
        self.graph = graph
        self.calibration = calibration

    def _potential(self, orbits: tuple[OrbitState, ...], lattice: object) -> float:
        if not np.allclose(
            np.asarray(lattice, dtype=float),
            np.asarray(self.state.lattice.primitive_matrix, dtype=float),
        ):
            raise ValueError("relation objective lattice must match the assembly state")
        state = replace(self.state, orbits=orbits)
        realized = calculate_realized_relations_v2(state, self.graph, self.calibration)
        edge_mask = self.graph.edge_mask[0]
        edge = realized.edge_state[0]
        prediction = self.prediction
        total = edge.new_zeros(())
        if bool(edge_mask.any()):
            distance_scale = (
                prediction.edge_distance[0, :, 1].exp()
                * self.calibration.uncertainty_scale
                + self.calibration.uncertainty_floor
            ).clamp_min(1.0e-6)
            distance_residual = (edge[:, 1] - prediction.edge_distance[0, :, 0]) / distance_scale
            direction_scale = (
                prediction.edge_direction_log_scale[0].exp()
                * self.calibration.uncertainty_scale
                + self.calibration.uncertainty_floor
            ).clamp_min(1.0e-6)
            direction = ((edge[:, 2:8] - prediction.edge_direction_fourier[0]) ** 2).reshape(
                edge.shape[0], 3, 2
            ).sum(dim=-1)
            direction_nll = (direction / direction_scale.square()).sum(dim=-1)
            shell_nll = -(
                edge[:, 8:12] * torch.log_softmax(prediction.edge_shell_logits[0], dim=-1)
            ).sum(dim=-1)
            coordination = (
                edge[:, 12:14] - prediction.edge_coordination[0]
            ).square().sum(dim=-1)
            per_edge = distance_residual.square() + direction_nll + shell_nll + coordination
            total = total + per_edge[edge_mask].sum()
        triplet_mask = self.graph.triplet_mask[0]
        if bool(triplet_mask.any()):
            scale = (
                prediction.triplet_angle[0, :, 1].exp()
                * self.calibration.uncertainty_scale
                + self.calibration.uncertainty_floor
            ).clamp_min(1.0e-6)
            residual = (
                realized.triplet_cosine[0, :, 0] - prediction.triplet_angle[0, :, 0]
            ) / scale
            total = total + residual.square()[triplet_mask].sum()
        return float(total.detach().cpu())

    def evaluate(
        self, orbits: tuple[OrbitState, ...], lattice: object
    ) -> RelationEvaluationV2:
        values = _packed(orbits)
        potential = self._potential(orbits, lattice)
        gradient = np.zeros_like(values)
        epsilon = 1.0e-6
        for index in range(values.size):
            plus = values.copy()
            minus = values.copy()
            plus[index] += epsilon
            minus[index] -= epsilon
            gradient[index] = (
                self._potential(_replace_packed(orbits, plus), lattice)
                - self._potential(_replace_packed(orbits, minus), lattice)
            ) / (2.0 * epsilon)
        return RelationEvaluationV2(
            potential=potential,
            gradient=gradient * self.calibration.relation_gradient_scale,
        )


class ProjectedGuideDriftAdapterV2:
    def __init__(
        self,
        state: SymmetryAssemblyState,
        guide: GuideObjectiveProtocolV2,
        relation: RelationConsistencyObjectiveV2,
        *,
        manifold: WyckoffManifoldAdapter | None = None,
        damping_epsilon: float = 1.0e-6,
    ) -> None:
        if not math.isfinite(damping_epsilon) or damping_epsilon <= 0:
            raise ValueError("manifold damping must be finite and positive")
        self.state = state
        self.guide = guide
        self.relation = relation
        self.manifold = manifold or WyckoffManifoldAdapter()
        self.damping_epsilon = float(damping_epsilon)
        self.projected_force_residual_by_orbit: np.ndarray = np.zeros(
            (len(state.orbits), 3), dtype=float
        )
        self.inapplicable_intermediate_count = 0
        self.inapplicable_reason_codes: list[str] = []

    @property
    def projected_force_residual(self) -> np.ndarray:
        return self.projected_force_residual_by_orbit[-1].copy()

    def __call__(
        self,
        u: torch.Tensor,
        tau: torch.Tensor,
        context: torch.Tensor,
        wyckoff_id: torch.Tensor,
        free_parameter_mask: torch.Tensor,
    ) -> GuidanceDriftV2:
        del tau, context, wyckoff_id
        if u.shape[0] != 1:
            raise ValueError("formal Guide drift is serialized at batch size one")
        candidate = self.state.orbits[-1]
        dof = len(candidate.free_parameters)
        sampled = replace(
            candidate,
            free_parameters=tuple(float(value) for value in u[0, :dof].detach().cpu()),
        )
        orbits = (*self.state.orbits[:-1], sampled)
        try:
            linearization = self.manifold.linearize(
                orbits, self.state.lattice.primitive_matrix
            )
        except WyckoffExpansionError as error:
            # A Heun substep can land exactly on a special-position stratum
            # where the requested Wyckoff orbit loses multiplicity.  Physics
            # and relation gradients are undefined there.  Treat guidance as
            # inapplicable for this substep; the registered K=1 sample still
            # proceeds once and the official endpoint expansion/Projector
            # remains the final legality authority.
            self.inapplicable_intermediate_count += 1
            self.inapplicable_reason_codes.append(
                f"GUIDE_INTERMEDIATE_WYCKOFF_INVALID:{error.reason_code}"
            )
            zeros = torch.zeros_like(u) * free_parameter_mask
            metric = torch.eye(3, device=u.device, dtype=u.dtype).unsqueeze(0)
            return GuidanceDriftV2(
                physics_step=zeros,
                relation_step=zeros,
                metric=metric,
            )
        guide = self.guide.evaluate(orbits, self.state.lattice.primitive_matrix)
        forces = guide.cartesian_forces if guide.applicable else np.zeros_like(guide.cartesian_forces)
        generalized_force = project_cartesian_forces(linearization.jacobian, forces)
        relation = self.relation.evaluate(orbits, self.state.lattice.primitive_matrix)
        metric_full = linearization.jacobian.T @ linearization.jacobian
        damped_metric = metric_full + self.damping_epsilon * np.eye(metric_full.shape[0])
        natural_force = np.linalg.solve(damped_metric, generalized_force)
        natural_relation = np.linalg.solve(damped_metric, relation.gradient)
        by_orbit: np.ndarray = np.zeros((len(orbits), 3), dtype=float)
        for orbit_index, (start, stop) in enumerate(linearization.dof_slices):
            by_orbit[orbit_index, : stop - start] = generalized_force[start:stop]
        self.projected_force_residual_by_orbit = by_orbit
        start, stop = linearization.dof_slices[-1]
        physics: np.ndarray = np.zeros(3, dtype=float)
        relation_step: np.ndarray = np.zeros(3, dtype=float)
        physics[:dof] = natural_force[start:stop]
        relation_step[:dof] = natural_relation[start:stop]
        metric = np.eye(3, dtype=float)
        metric[:dof, :dof] = metric_full[start:stop, start:stop]
        return GuidanceDriftV2(
            physics_step=torch.as_tensor(physics, device=u.device, dtype=u.dtype)[None]
            * free_parameter_mask,
            relation_step=torch.as_tensor(relation_step, device=u.device, dtype=u.dtype)[None]
            * free_parameter_mask,
            metric=torch.as_tensor(metric, device=u.device, dtype=u.dtype)[None],
        )


__all__ = [
    "ProjectedGuideDriftAdapterV2",
    "RealizedRelationsV2",
    "RelationConsistencyObjectiveV2",
    "RelationGeometryCalibrationV2",
    "calculate_realized_relations_v2",
    "fit_committed_relation_geometry_calibration_v2",
    "load_relation_geometry_calibration_v2",
    "validate_relation_geometry_calibration_contract_v2",
]
