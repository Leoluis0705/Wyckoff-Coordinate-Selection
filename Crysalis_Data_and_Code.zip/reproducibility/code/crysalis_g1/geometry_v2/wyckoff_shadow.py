from __future__ import annotations

import math
from dataclasses import dataclass, replace
from typing import Iterable, Protocol

import numpy as np
from pymatgen.core import Element, Lattice, Structure
from pyxtal.symmetry import Group

from crysalis_g1.symmetry.wyckoff import (
    OrbitState,
    SpaceGroupConditionedWyckoffExpander,
    SpaceGroupSetting,
)


class ExpandedCoordinatesProtocol(Protocol):
    fractional_coordinates: tuple[tuple[float, float, float], ...]


class OfficialWyckoffExpanderProtocol(Protocol):
    def expand(
        self,
        orbit: OrbitState,
        lattice: Iterable[Iterable[float]],
        *,
        require_target_space_group: bool = True,
        require_distinct_orbit_instances: bool = True,
    ) -> ExpandedCoordinatesProtocol: ...


class ShadowMapMismatchError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class JacobianReceiptV2:
    method: str
    official_roundtrip: bool
    finite_difference_step: float | None = None
    fallback_reason: str | None = None
    step_size_invariance_error: float | None = None
    analytic_comparison_error: float | None = None


@dataclass(frozen=True, slots=True)
class ShadowExpansionV2:
    fractional_coordinates: np.ndarray
    cartesian_coordinates: np.ndarray
    jacobian: np.ndarray
    free_dof: int
    receipt: JacobianReceiptV2


def _finite_lattice(lattice: Iterable[Iterable[float]]) -> np.ndarray:
    matrix = np.asarray(tuple(tuple(row) for row in lattice), dtype=float)
    if matrix.shape != (3, 3) or not np.isfinite(matrix).all():
        raise ValueError("lattice must be a finite 3x3 matrix")
    if abs(float(np.linalg.det(matrix))) <= 1e-8:
        raise ValueError("lattice must be nonsingular")
    return matrix


def _periodic_delta(left: np.ndarray, right: np.ndarray) -> np.ndarray:
    delta = left - right
    return delta - np.round(delta)


def _canonical_coordinates(values: np.ndarray) -> np.ndarray:
    unique: list[np.ndarray] = []
    for value in np.mod(np.asarray(values, dtype=float).reshape(-1, 3), 1.0):
        value[np.isclose(value, 1.0, atol=1e-8)] = 0.0
        if not any(np.max(np.abs(_periodic_delta(value, item))) <= 1e-8 for item in unique):
            unique.append(value)
    return np.asarray(
        sorted(unique, key=lambda item: tuple(round(float(x), 12) for x in item)),
        dtype=float,
    )


def _match_candidate_to_reference(
    reference: np.ndarray, candidate: np.ndarray, *, tolerance: float | None = 1e-8
) -> tuple[np.ndarray, tuple[int, ...]]:
    if reference.shape != candidate.shape:
        raise ShadowMapMismatchError(
            f"shadow/official multiplicity mismatch: {len(candidate)} != {len(reference)}"
        )
    unmatched = list(range(len(candidate)))
    order: list[int] = []
    for coordinate in reference:
        distances = [
            float(np.max(np.abs(_periodic_delta(coordinate, candidate[index]))))
            for index in unmatched
        ]
        selected = int(np.argmin(distances))
        if tolerance is not None and distances[selected] > tolerance:
            raise ShadowMapMismatchError(
                "shadow coordinates do not match the official expansion"
            )
        order.append(unmatched.pop(selected))
    return candidate[np.asarray(order, dtype=int)], tuple(order)


def _affine_shadow(
    orbit: OrbitState,
) -> tuple[np.ndarray, np.ndarray]:
    position = Group(orbit.target_space_group).get_wyckoff_position(
        orbit.wyckoff_letter
    )
    if position is None:
        raise ValueError(
            f"unknown Wyckoff position {orbit.wyckoff_letter!r} for SG {orbit.target_space_group}"
        )
    free_dof = int(position.get_dof())
    zero = np.asarray(position.get_position_from_free_xyzs([0.0] * free_dof), dtype=float)
    embedding: np.ndarray = np.zeros((3, free_dof), dtype=float)
    affine_probe = 0.125
    for index in range(free_dof):
        basis = [0.0] * free_dof
        basis[index] = affine_probe
        probe = np.asarray(position.get_position_from_free_xyzs(basis), dtype=float)
        embedding[:, index] = _periodic_delta(probe, zero) / affine_probe
    generator = np.asarray(
        position.get_position_from_free_xyzs(list(orbit.free_parameters)), dtype=float
    )
    inverse_transform = np.linalg.inv(
        SpaceGroupSetting.for_number(orbit.target_space_group).primitive_transform
    )
    primitive_column_transform = inverse_transform.T
    coordinates: list[np.ndarray] = []
    jacobians: list[np.ndarray] = []
    for operation in position.ops:
        rotation = np.asarray(operation.rotation_matrix, dtype=float)
        translation = np.asarray(operation.translation_vector, dtype=float)
        coordinate = primitive_column_transform @ (rotation @ generator + translation)
        jacobian = primitive_column_transform @ rotation @ embedding
        wrapped = np.mod(coordinate, 1.0)
        if any(
            np.max(np.abs(_periodic_delta(wrapped, existing))) <= 1e-8
            for existing in coordinates
        ):
            continue
        coordinates.append(wrapped)
        jacobians.append(jacobian)
    order = sorted(
        range(len(coordinates)),
        key=lambda index: tuple(round(float(x), 12) for x in coordinates[index]),
    )
    return (
        np.asarray([coordinates[index] for index in order], dtype=float),
        np.asarray([jacobians[index] for index in order], dtype=float),
    )


def _shadow_with_cell_transform(orbit: OrbitState) -> np.ndarray:
    base_orbit = OrbitState.create(
        orbit.target_space_group,
        orbit.wyckoff_letter,
        orbit.species,
        orbit.free_parameters,
        orbit_instance_id=orbit.orbit_instance_id,
    )
    primitive, _ = _affine_shadow(base_orbit)
    structure = Structure(
        Lattice(np.eye(3)),
        [Element.from_Z(orbit.species)] * len(primitive),
        primitive,
        to_unit_cell=True,
    )
    structure.make_supercell(np.asarray(orbit.cell_transform_values, dtype=int))
    return _canonical_coordinates(np.asarray(structure.frac_coords, dtype=float))


class DifferentiableWyckoffShadowMap:
    """PyXtal-table shadow map cross-checked against the official expander."""

    def __init__(
        self,
        *,
        expander: OfficialWyckoffExpanderProtocol | None = None,
        finite_difference_step: float = 1e-5,
    ) -> None:
        if not math.isfinite(finite_difference_step) or finite_difference_step <= 0:
            raise ValueError("finite-difference step must be finite and positive")
        self.expander = expander or SpaceGroupConditionedWyckoffExpander()
        self.finite_difference_step = float(finite_difference_step)

    def recover_free_parameters(
        self,
        target_space_group: int,
        wyckoff_letter: str,
        conventional_coordinates: Iterable[Iterable[float]],
        *,
        tolerance: float = 5e-5,
    ) -> tuple[float, ...]:
        """Recover the official PyXtal parameterization without inventing a repair."""
        position = Group(target_space_group).get_wyckoff_position(wyckoff_letter)
        if position is None:
            raise ValueError(
                f"unknown Wyckoff position {wyckoff_letter!r} for SG {target_space_group}"
            )
        target = _canonical_coordinates(np.asarray(tuple(conventional_coordinates), dtype=float))
        if len(target) != int(position.multiplicity):
            raise ValueError("conventional multiplicity does not match the official Wyckoff position")
        for coordinate in target:
            generator = position.search_generator(
                coordinate, tol=0.05, symmetrize=True
            )
            if generator is None:
                continue
            recovered = tuple(
                float(value) % 1.0 for value in position.get_free_xyzs(generator)
            )
            rebuilt = _canonical_coordinates(
                np.asarray(
                    position.apply_ops(
                        position.get_position_from_free_xyzs(list(recovered))
                    ),
                    dtype=float,
                )
            )
            try:
                _match_candidate_to_reference(target, rebuilt, tolerance=tolerance)
            except ShadowMapMismatchError:
                continue
            return recovered
        raise ShadowMapMismatchError(
            "official Wyckoff parameter recovery could not reproduce the coordinates"
        )

    def _validated_coordinates(
        self, orbit: OrbitState, lattice: np.ndarray
    ) -> tuple[np.ndarray, tuple[int, ...], np.ndarray | None]:
        identity = ((1, 0, 0), (0, 1, 0), (0, 0, 1))
        if orbit.cell_transform_values == identity:
            shadow, analytic = _affine_shadow(orbit)
        else:
            shadow = _shadow_with_cell_transform(orbit)
            analytic = None
        official_result = self.expander.expand(
            orbit,
            lattice,
            require_target_space_group=False,
            require_distinct_orbit_instances=False,
        )
        official = np.asarray(official_result.fractional_coordinates, dtype=float)
        _, order = _match_candidate_to_reference(official, shadow)
        return official, order, analytic

    def _finite_difference(
        self, orbit: OrbitState, lattice: np.ndarray, step: float
    ) -> np.ndarray:
        base, _, _ = self._validated_coordinates(orbit, lattice)
        free_dof = len(orbit.free_parameters)
        result: np.ndarray = np.empty((3 * len(base), free_dof), dtype=float)
        for index in range(free_dof):
            plus = list(orbit.free_parameters)
            minus = list(orbit.free_parameters)
            plus[index] += step
            minus[index] -= step
            plus_coordinates, _, _ = self._validated_coordinates(
                replace(orbit, free_parameters=tuple(plus)), lattice
            )
            minus_coordinates, _, _ = self._validated_coordinates(
                replace(orbit, free_parameters=tuple(minus)), lattice
            )
            plus_aligned, _ = _match_candidate_to_reference(
                base, plus_coordinates, tolerance=None
            )
            minus_aligned, _ = _match_candidate_to_reference(
                base, minus_coordinates, tolerance=None
            )
            fractional_derivative = _periodic_delta(
                plus_aligned, minus_aligned
            ) / (2.0 * step)
            result[:, index] = (fractional_derivative @ lattice).reshape(-1)
        return result

    def expand(
        self,
        orbit: OrbitState,
        lattice: Iterable[Iterable[float]],
        *,
        force_finite_difference: bool = False,
        verify_fallback: bool = False,
    ) -> ShadowExpansionV2:
        matrix = _finite_lattice(lattice)
        official, order, analytic_fractional = self._validated_coordinates(orbit, matrix)
        free_dof = len(orbit.free_parameters)
        analytic_available = (
            analytic_fractional is not None
            and orbit.cell_transform_values == ((1, 0, 0), (0, 1, 0), (0, 0, 1))
        )
        if analytic_available and not force_finite_difference:
            assert analytic_fractional is not None
            ordered = analytic_fractional[np.asarray(order, dtype=int)]
            jacobian = np.asarray(
                [matrix.T @ item for item in ordered], dtype=float
            ).reshape(3 * len(official), free_dof)
            receipt = JacobianReceiptV2(
                method="analytic_affine", official_roundtrip=True
            )
        else:
            step = self.finite_difference_step
            jacobian = self._finite_difference(orbit, matrix, step)
            invariance_error = None
            analytic_error = None
            if verify_fallback or not analytic_available:
                smaller = self._finite_difference(orbit, matrix, step / 2.0)
                invariance_error = float(np.max(np.abs(jacobian - smaller), initial=0.0))
                if analytic_available:
                    assert analytic_fractional is not None
                    analytic = np.asarray(
                        [matrix.T @ item for item in analytic_fractional[np.asarray(order, dtype=int)]],
                        dtype=float,
                    ).reshape(jacobian.shape)
                    analytic_error = float(
                        np.max(np.abs(jacobian - analytic), initial=0.0)
                    )
            receipt = JacobianReceiptV2(
                method="periodic_central_difference",
                official_roundtrip=True,
                finite_difference_step=step,
                fallback_reason=(
                    "FORCED_ENGINEERING_CROSSCHECK"
                    if force_finite_difference
                    else "NONIDENTITY_CELL_TRANSFORM"
                ),
                step_size_invariance_error=invariance_error,
                analytic_comparison_error=analytic_error,
            )
        if not np.isfinite(jacobian).all():
            raise FloatingPointError("non-finite Wyckoff Jacobian")
        return ShadowExpansionV2(
            fractional_coordinates=official.copy(),
            cartesian_coordinates=official @ matrix,
            jacobian=jacobian,
            free_dof=free_dof,
            receipt=receipt,
        )


__all__ = [
    "DifferentiableWyckoffShadowMap",
    "JacobianReceiptV2",
    "OfficialWyckoffExpanderProtocol",
    "ShadowExpansionV2",
    "ShadowMapMismatchError",
]
