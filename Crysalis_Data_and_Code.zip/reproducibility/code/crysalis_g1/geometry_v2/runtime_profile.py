from __future__ import annotations

from collections.abc import Mapping, Sequence

import numpy as np


def _statistics(values: Sequence[float]) -> dict[str, float | int]:
    array = np.asarray(tuple(float(value) for value in values), dtype=float)
    if array.size == 0 or not np.isfinite(array).all():
        raise ValueError("runtime profile values must be non-empty and finite")
    return {
        "count": int(array.size),
        "median_seconds": float(np.median(array)),
        "mean_seconds": float(array.mean()),
        "p90_seconds": float(np.quantile(array, 0.90)),
    }


def summarize_profile_rows_v2(
    rows: Sequence[Mapping[str, object]], *, minimum_measured_per_class: int = 20
) -> dict[str, dict[str, float | int]]:
    if type(minimum_measured_per_class) is not int or minimum_measured_per_class <= 0:
        raise ValueError("minimum measured count must be positive")
    summary: dict[str, dict[str, float | int]] = {}
    for batch_type in ("normal", "formal"):
        selected = [row for row in rows if row.get("batch_type") == batch_type]
        if not selected:
            raise ValueError(f"runtime profile lacks {batch_type} batches")
        measured = selected[1:]
        if len(measured) < minimum_measured_per_class:
            raise ValueError(
                f"runtime profile requires {minimum_measured_per_class} measured {batch_type} batches after warmup"
            )
        stats = _statistics([float(row["total_seconds"]) for row in measured])
        stats["guide_calls_mean"] = float(
            np.mean([float(row.get("guide_calls", 0)) for row in measured])
        )
        summary[batch_type] = stats
    return summary


__all__ = ["summarize_profile_rows_v2"]
