from __future__ import annotations

import itertools
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

import numpy as np
import torch
from torch.nn import functional

from crysalis_g1.full_crysalis.data import (
    IntegratedCorpus,
    IntegratedEvent,
    RelationNormalizer,
    collate_integrated_events,
)
from crysalis_g1.r1.contracts import (
    FrozenArtifact,
    R1Config,
    R1ParentBundle,
    load_r1_bundles,
)
from crysalis_g1.symmetry.assembly import SymmetryAssemblyState
from crysalis_g1.symmetry.wyckoff import orbit_representative_fractional_coordinate
from crysalis_g1.symmetry.wyckoff import OrbitState

from .losses import (
    coordination_loss,
    flow_matching_loss,
    relation_realization_loss,
    shell_pair_loss,
)
from .manifold import WyckoffManifoldAdapter
from .memory import PersistentRelationMemoryV2
from .model import FormalGeometryV2Model
from .relation_interface import (
    ActiveOrbitGraphV2,
    RelationInputProvenanceV2,
    RelationModelInputV2,
)
from .train_fit import (
    MODEL_REALIZED_UNROLL,
    TEACHER_STATE,
    TrainFitBatchV2,
    TrainFitEventV2,
)
from .training import (
    FormalGeometryTrainingBatchV2,
    TrajectorySampleIdentityV2,
)
from .training_batch import build_flow_matching_batch


MAXIMUM_ACTIVE_ORBITS_V2 = 20
MAXIMUM_RELATION_EDGES_V2 = 20
MAXIMUM_RELATION_TRIPLETS_V2 = 190
DEFAULT_SHELL_BOUNDARIES_ANGSTROM = (2.25, 3.25, 4.25)
_FROZEN_ARTIFACT_HASHES = {
    "phase2a_manifest": "4e9c6f5e162e61cc05b2bf2204ecfb692cc30ec060d79301e9f31b60ccd7fea1",
    "canonical_parents": "cb2a4ef9efa26ef96664cc2c2890e115d7af730321b735acf6eae43687e9d21c",
    "canonical_relations": "c8921b42685be030316e3fdd454b6c2c7c614bcf04bfecce39e209d3bdd97772",
    "d_orbit_trajectories": "7507ff8f50278e1a91b52e21e9fa7624e0ff0f53b2ca0cbc3b4c76fa26d072be",
    "d_relation_interface_trajectories": "fe12bbacaf29899b1751e1fac434df2c721b94cdb686569a5f6114ef50990308",
    "structure_ood_manifest": "9c6d0c66da76790d03c4eeaabea0bebbf92802285d4372187cd4c0758cabc40b",
    "recovered_parents": "7ff411f8126b143250a4c13a7a1040e4a6fba1b156a9f0b1c5f33ba3fa383828",
    "c0_manifest": "a391f0a5f5843a1f64e12851fc978e887a87bb93b1e2f4cb49cdf990e8edc7a6",
    "c0_checkpoint": "8cf3a9a2ee27626a1719fa0d8cbc084efd23b9e614c1a60e4f560b92554c91d4",
    "condition_manifest": "0d8308b3d6fdd5539302ae19aca6b38952aecef7016942ec46a8ef7493200961",
    "chgnet_weights": "d14ab7c0f093efe64b60a7bcd540bca10e74fb7f46c86108a079af60524659d1",
}


@dataclass(frozen=True, slots=True)
class Phase2ASupervisionV2:
    equivalent_targets: torch.Tensor
    free_parameter_mask: torch.Tensor
    induced_metric: torch.Tensor
    wyckoff_id: torch.Tensor
    edge_presence: torch.Tensor
    edge_distance: torch.Tensor
    edge_direction_fourier: torch.Tensor
    edge_shell: torch.Tensor
    edge_coordination: torch.Tensor
    triplet_presence: torch.Tensor
    triplet_cosine: torch.Tensor
    states: tuple[SymmetryAssemblyState, ...]


@dataclass(frozen=True, slots=True)
class BuiltPhase2ATrainingBatchV2:
    training_batch: FormalGeometryTrainingBatchV2
    supervision: Phase2ASupervisionV2


def _frozen_phase2a_r1_config_v2(
    *, phase2a_root: str | Path, runtime_artifact_root: str | Path
) -> R1Config:
    phase2a = Path(phase2a_root).resolve()
    runtime = Path(runtime_artifact_root).resolve()
    paths = {
        "phase2a_manifest": phase2a / "phase2a_manifest.json",
        "canonical_parents": phase2a / "canonical_cache/canonical_parents.jsonl",
        "canonical_relations": phase2a / "canonical_cache/canonical_relations.jsonl",
        "d_orbit_trajectories": phase2a / "trajectories/d_orbit.jsonl",
        "d_relation_interface_trajectories": phase2a
        / "trajectories/d_relation_interface.jsonl",
        "structure_ood_manifest": phase2a / "splits/structure_ood_manifest.jsonl",
        "recovered_parents": runtime / "recovered_parent_states.jsonl",
        "c0_manifest": runtime / "C0_SYMMETRY_MANIFEST.json",
        "c0_checkpoint": runtime / "checkpoints/formal_single_seed_best.pt",
        "condition_manifest": runtime / "engineering/condition_manifest.json",
        "chgnet_weights": runtime / "chgnet_0.3.0_e29f68s314m37.pth.tar",
    }
    return R1Config(
        config_path=phase2a / "phase2a_manifest.json",
        raw={},
        root_seed=20260823,
        output_root=phase2a / "geometry_v2_adapter_receipts",
        device="cuda" if torch.cuda.is_available() else "cpu",
        top_space_groups=(225, 139, 12, 63, 189, 194, 123, 164),
        frozen_artifacts={
            name: FrozenArtifact(path=path, sha256=_FROZEN_ARTIFACT_HASHES[name])
            for name, path in paths.items()
        },
        attempt_count=300,
        maximum_orbits=20,
        maximum_sites=256,
        minimum_distance_angstrom=0.5,
        maximum_placement_candidates=16,
        orbit_proposal_namespace="r1:uniform_orbit_proposal",
        placement_pool_namespace="r1:relation_placement_pool",
    )


def load_frozen_phase2a_bundles_v2(
    *, phase2a_root: str | Path, runtime_artifact_root: str | Path
) -> tuple[R1ParentBundle, ...]:
    return load_r1_bundles(
        _frozen_phase2a_r1_config_v2(
            phase2a_root=phase2a_root,
            runtime_artifact_root=runtime_artifact_root,
        )
    )


def load_frozen_phase2a_corpus_v2(
    *, phase2a_root: str | Path, runtime_artifact_root: str | Path
) -> IntegratedCorpus:
    return IntegratedCorpus.build(
        load_frozen_phase2a_bundles_v2(
            phase2a_root=phase2a_root,
            runtime_artifact_root=runtime_artifact_root,
        )
    )


def _wrap_delta(values: Sequence[float]) -> np.ndarray:
    array = np.asarray(values, dtype=float)
    return array - np.ceil(array - 0.5)


def _wyckoff_index(letter: str) -> int:
    normalized = str(letter).strip().lower()
    if len(normalized) != 1 or not "a" <= normalized <= "z":
        raise ValueError(f"invalid Wyckoff letter: {letter!r}")
    return ord(normalized) - ord("a")


def _orbit_feature(
    *,
    species: int,
    wyckoff_index: int,
    multiplicity: int,
    free_parameters: Sequence[float],
    representative: Sequence[float],
    progress: float,
    candidate: bool,
    pooled_relation: Sequence[float],
    physics_feedback: Sequence[float],
) -> torch.Tensor:
    values = torch.zeros(64, dtype=torch.float32)
    dof = len(tuple(free_parameters))
    free = torch.zeros(3, dtype=torch.float32)
    if dof:
        free[:dof] = torch.as_tensor(tuple(free_parameters), dtype=torch.float32)
    representative_tensor = torch.as_tensor(tuple(representative), dtype=torch.float32)
    values[0] = float(species) / 118.0
    values[1] = float(wyckoff_index) / 25.0
    values[2] = float(multiplicity) / 20.0
    values[3] = float(dof) / 3.0
    values[4:7] = free
    values[7:10] = torch.sin(2.0 * math.pi * free)
    values[10:13] = torch.cos(2.0 * math.pi * free)
    values[13:16] = representative_tensor
    values[16:19] = torch.sin(2.0 * math.pi * representative_tensor)
    values[19:22] = torch.cos(2.0 * math.pi * representative_tensor)
    values[22] = float(progress)
    values[23] = float(candidate)
    pooled = torch.as_tensor(tuple(pooled_relation), dtype=torch.float32)
    physics = torch.as_tensor(tuple(physics_feedback), dtype=torch.float32)
    values[24 : 24 + min(8, pooled.numel())] = pooled[:8]
    values[32 : 32 + min(8, physics.numel())] = physics[:8]
    return values


def _candidate_seed_feature(event: IntegratedEvent) -> torch.Tensor:
    candidate = event.candidate_orbit
    if candidate is None:
        raise ValueError("Geometry V2 training excludes terminal events")
    dof = len(candidate.free_parameters)
    seed_parameters = (0.5,) * dof
    seed_orbit = type(candidate).create(
        candidate.target_space_group,
        candidate.wyckoff_letter,
        candidate.species,
        seed_parameters,
        cell_transform=candidate.cell_transform_values,
        orbit_instance_id=f"geometry-v2-seed:{candidate.orbit_instance_id}",
    )
    return _orbit_feature(
        species=candidate.species,
        wyckoff_index=_wyckoff_index(candidate.wyckoff_letter),
        multiplicity=candidate.multiplicity,
        free_parameters=seed_parameters,
        representative=orbit_representative_fractional_coordinate(seed_orbit),
        progress=event.progress,
        candidate=True,
        pooled_relation=event.pooled_relation,
        physics_feedback=event.physics_feedback,
    )


def _assembly_state(
    event: IntegratedEvent,
    active_orbits: Sequence[OrbitState] | None = None,
) -> SymmetryAssemblyState:
    candidate = event.candidate_orbit
    if candidate is None:
        raise ValueError("Geometry V2 training excludes terminal events")
    realized_active = tuple(event.active_orbits if active_orbits is None else active_orbits)
    assembled = (*realized_active, candidate)
    remaining = dict(event.composition)
    for orbit in assembled:
        remaining[orbit.species] -= orbit.multiplicity
    normalized_remaining = tuple(
        sorted((species, count) for species, count in remaining.items() if count)
    )
    if any(count < 0 for _, count in normalized_remaining):
        raise ValueError("teacher assembly state exceeds target composition")
    return SymmetryAssemblyState(
        target_space_group=event.target_space_group,
        composition=event.composition,
        remaining_composition=normalized_remaining,
        lattice=event.lattice,
        orbits=assembled,
    )


def _candidate_metric(state: SymmetryAssemblyState) -> torch.Tensor:
    linearization = WyckoffManifoldAdapter().linearize(
        state.orbits, state.lattice.primitive_matrix
    )
    start, stop = linearization.dof_slices[-1]
    metric = np.zeros((3, 3), dtype=float)
    if stop > start:
        jacobian = linearization.jacobian[:, start:stop]
        metric[: stop - start, : stop - start] = jacobian.T @ jacobian
    return torch.as_tensor(metric, dtype=torch.float32)


def _relation_targets(
    event: IntegratedEvent,
    *,
    shell_boundaries_angstrom: tuple[float, float, float],
) -> tuple[
    torch.Tensor,
    torch.Tensor,
    torch.Tensor,
    torch.Tensor,
    torch.Tensor,
    torch.Tensor,
    torch.Tensor,
]:
    candidate = event.candidate_orbit
    if candidate is None:
        raise ValueError("Geometry V2 training excludes terminal events")
    candidate_coordinate = np.asarray(
        orbit_representative_fractional_coordinate(candidate), dtype=float
    )
    by_existing = {target.existing_orbit_id: target for target in event.relation_targets}
    edge_presence = torch.zeros(MAXIMUM_RELATION_EDGES_V2, 1)
    edge_distance = torch.zeros(MAXIMUM_RELATION_EDGES_V2, 1)
    edge_direction = torch.zeros(MAXIMUM_RELATION_EDGES_V2, 6)
    edge_shell = torch.zeros(MAXIMUM_RELATION_EDGES_V2, 4)
    edge_coordination = torch.zeros(MAXIMUM_RELATION_EDGES_V2, 2)
    anchor_vectors: list[np.ndarray] = []
    for index, existing in enumerate(event.active_orbits):
        target = by_existing.get(existing.orbit_instance_id)
        if target is None:
            raise ValueError("train-fit relation target does not match active topology")
        descriptor = target.descriptor
        edge_presence[index, 0] = descriptor.presence
        edge_distance[index, 0] = descriptor.distance_mean
        existing_coordinate = np.asarray(
            orbit_representative_fractional_coordinate(existing), dtype=float
        )
        displacement = _wrap_delta(candidate_coordinate - existing_coordinate)
        anchor_vectors.append(displacement)
        edge_direction[index] = torch.as_tensor(
            [
                function(2.0 * math.pi * value)
                for value in displacement
                for function in (math.sin, math.cos)
            ],
            dtype=torch.float32,
        )
        shell_index = int(
            np.searchsorted(shell_boundaries_angstrom, descriptor.distance_mean)
        )
        edge_shell[index, shell_index] = 1.0
        edge_coordination[index] = torch.tensor(
            (descriptor.candidate_coordination, descriptor.existing_coordination)
        )
    triplet_presence = torch.zeros(MAXIMUM_RELATION_TRIPLETS_V2, 1)
    triplet_cosine = torch.zeros(MAXIMUM_RELATION_TRIPLETS_V2, 1)
    for slot, (left, right) in enumerate(
        itertools.combinations(range(len(anchor_vectors)), 2)
    ):
        left_cartesian = anchor_vectors[left] @ np.asarray(
            event.lattice.primitive_matrix, dtype=float
        )
        right_cartesian = anchor_vectors[right] @ np.asarray(
            event.lattice.primitive_matrix, dtype=float
        )
        denominator = np.linalg.norm(left_cartesian) * np.linalg.norm(right_cartesian)
        if denominator <= 1.0e-12:
            continue
        triplet_presence[slot, 0] = 1.0
        triplet_cosine[slot, 0] = float(
            np.dot(left_cartesian, right_cartesian) / denominator
        )
    return (
        edge_presence,
        edge_distance,
        edge_direction,
        edge_shell,
        edge_coordination,
        triplet_presence,
        triplet_cosine,
    )


def build_phase2a_training_batch_v2(
    events: Sequence[IntegratedEvent],
    *,
    batch_index: int,
    normalizer: RelationNormalizer,
    device: str | torch.device,
    shell_boundaries_angstrom: tuple[float, float, float] = (
        DEFAULT_SHELL_BOUNDARIES_ANGSTROM
    ),
    state_modes: Sequence[str] | None = None,
    active_orbit_overrides: Sequence[tuple[OrbitState, ...] | None] | None = None,
    memory_overrides: Sequence[PersistentRelationMemoryV2 | None] | None = None,
    sample_identities: Sequence[TrajectorySampleIdentityV2] | None = None,
    training_sample_ids: Sequence[str] | None = None,
) -> BuiltPhase2ATrainingBatchV2:
    if not events or len(events) % 2:
        raise ValueError("Geometry V2 train-fit batches must be non-empty and even")
    if any(event.split != "train_fit" or event.terminal for event in events):
        raise ValueError("Geometry V2 training accepts nonterminal train_fit events only")
    if any(len(event.active_orbits) >= MAXIMUM_ACTIVE_ORBITS_V2 for event in events):
        raise ValueError("candidate would exceed the 20-orbit Geometry V2 limit")
    batch_size = len(events)
    if active_orbit_overrides is None:
        active_orbit_overrides = (None,) * batch_size
    if memory_overrides is None:
        memory_overrides = (None,) * batch_size
    if not (
        len(active_orbit_overrides) == len(memory_overrides) == batch_size
    ):
        raise ValueError("realized state/memory overrides must align with events")
    sample_ids = tuple(
        (event.event_key for event in events)
        if training_sample_ids is None
        else training_sample_ids
    )
    if len(sample_ids) != batch_size or len(set(sample_ids)) != batch_size:
        raise ValueError("training sample IDs must be aligned and unique")
    realized_active_rows: list[tuple[OrbitState, ...]] = []
    for event, override in zip(events, active_orbit_overrides, strict=True):
        active = tuple(event.active_orbits if override is None else override)
        teacher_signature = tuple(
            (
                orbit.orbit_instance_id,
                orbit.species,
                orbit.wyckoff_letter,
                orbit.multiplicity,
            )
            for orbit in event.active_orbits
        )
        realized_signature = tuple(
            (
                orbit.orbit_instance_id,
                orbit.species,
                orbit.wyckoff_letter,
                orbit.multiplicity,
            )
            for orbit in active
        )
        if teacher_signature != realized_signature:
            raise ValueError("model-realized state must preserve the correct action topology")
        realized_active_rows.append(active)
    torch_device = torch.device(device)
    integrated = collate_integrated_events(
        events,
        normalizer=normalizer,
        maximum_orbits=MAXIMUM_ACTIVE_ORBITS_V2,
    )
    active_features = torch.zeros(batch_size, MAXIMUM_ACTIVE_ORBITS_V2, 64)
    active_mask = torch.zeros(batch_size, MAXIMUM_ACTIVE_ORBITS_V2, dtype=torch.bool)
    edge_index = torch.zeros(batch_size, MAXIMUM_RELATION_EDGES_V2, dtype=torch.long)
    edge_mask = torch.zeros(batch_size, MAXIMUM_RELATION_EDGES_V2, dtype=torch.bool)
    triplet_index = torch.zeros(
        batch_size, MAXIMUM_RELATION_TRIPLETS_V2, 2, dtype=torch.long
    )
    triplet_mask = torch.zeros(
        batch_size, MAXIMUM_RELATION_TRIPLETS_V2, dtype=torch.bool
    )
    candidate_query = torch.zeros(batch_size, 64)
    states: list[SymmetryAssemblyState] = []
    metrics: list[torch.Tensor] = []
    target_rows: list[torch.Tensor] = []
    masks: list[torch.Tensor] = []
    relation_rows = []
    for row, event in enumerate(events):
        realized_active = realized_active_rows[row]
        for slot, orbit in enumerate(realized_active):
            active_features[row, slot] = _orbit_feature(
                species=orbit.species,
                wyckoff_index=_wyckoff_index(orbit.wyckoff_letter),
                multiplicity=orbit.multiplicity,
                free_parameters=orbit.free_parameters,
                representative=orbit_representative_fractional_coordinate(orbit),
                progress=event.progress,
                candidate=False,
                pooled_relation=event.pooled_relation,
                physics_feedback=event.physics_feedback,
            )
            active_mask[row, slot] = True
            edge_index[row, slot] = slot
            edge_mask[row, slot] = True
        candidate_slot = len(realized_active)
        candidate_feature = _candidate_seed_feature(event)
        active_features[row, candidate_slot] = candidate_feature
        active_mask[row, candidate_slot] = True
        candidate_query[row] = candidate_feature
        for triplet_slot, (left, right) in enumerate(
            itertools.combinations(range(candidate_slot), 2)
        ):
            triplet_index[row, triplet_slot] = torch.tensor((left, right))
            triplet_mask[row, triplet_slot] = True
        candidate = event.candidate_orbit
        assert candidate is not None
        target = torch.zeros(3)
        mask = torch.zeros(3, dtype=torch.bool)
        if candidate.free_parameters:
            target[: len(candidate.free_parameters)] = torch.tensor(
                candidate.free_parameters
            )
            mask[: len(candidate.free_parameters)] = True
        target_rows.append(target)
        masks.append(mask)
        state = _assembly_state(event, realized_active)
        states.append(state)
        metrics.append(_candidate_metric(state))
        relation_rows.append(
            _relation_targets(
                event, shell_boundaries_angstrom=shell_boundaries_angstrom
            )
        )
    graph = ActiveOrbitGraphV2(
        active_orbits=active_features.to(torch_device),
        active_orbit_mask=active_mask.to(torch_device),
        edge_index=edge_index.to(torch_device),
        edge_mask=edge_mask.to(torch_device),
        triplet_index=triplet_index.to(torch_device),
        triplet_mask=triplet_mask.to(torch_device),
    )
    memories = []
    for replacement in memory_overrides:
        memory = replacement or PersistentRelationMemoryV2.empty(
            1,
            MAXIMUM_ACTIVE_ORBITS_V2,
            MAXIMUM_RELATION_EDGES_V2,
            device=torch_device,
        )
        if (
            memory.batch_size != 1
            or memory.max_orbits != MAXIMUM_ACTIVE_ORBITS_V2
            or memory.max_edges != MAXIMUM_RELATION_EDGES_V2
        ):
            raise ValueError("model-realized memory has incompatible packed dimensions")
        tensors = memory.tensorize()
        memories.append(
            (
                tensors.orbit.to(torch_device),
                tensors.edge.to(torch_device),
                tensors.global_memory.to(torch_device),
            )
        )
    packed_memory = PersistentRelationMemoryV2.from_tensors(
        orbit=torch.cat([item[0] for item in memories], dim=0),
        edge=torch.cat([item[1] for item in memories], dim=0),
        global_memory=torch.cat([item[2] for item in memories], dim=0),
    )
    model_input = RelationModelInputV2.from_mapping(
        {
            "composition": integrated.composition.to(torch_device),
            "target_sg": integrated.target_space_group.to(torch_device),
            "lattice": integrated.lattice.to(torch_device),
            "active_orbit_graph": graph,
            "candidate_query": candidate_query.to(torch_device),
            "persistent_memory": packed_memory,
        },
        provenance=RelationInputProvenanceV2(
            "public_train_fit_forward_deconstruction"
        ),
    )
    train_events = tuple(
        TrainFitEventV2(
            event_id=sample_ids[row],
            source_split="train_fit",
            condition={
                "target_sg": event.target_space_group,
                "candidate_species": event.candidate_orbit.species,
                "candidate_wyckoff": event.candidate_orbit.wyckoff_letter,
            },
            equivalent_targets=(tuple(event.candidate_orbit.free_parameters),),
        )
        for row, event in enumerate(events)
        if event.candidate_orbit is not None
    )
    modes = tuple(
        (
            TEACHER_STATE if row % 2 == 0 else MODEL_REALIZED_UNROLL
            for row in range(batch_size)
        )
        if state_modes is None
        else state_modes
    )
    train_fit = TrainFitBatchV2(
        batch_index=batch_index,
        events=train_events,
        state_modes=modes,
        max_unroll_steps=2 + batch_index % 3,
    )
    identities = tuple(
        (
            TrajectorySampleIdentityV2(
                trajectory_id=f"smoke:{event.parent_id}:{event.event_key}",
                sample_id=sample_ids[row],
                sequence_index=0,
            )
            for row, event in enumerate(events)
        )
        if sample_identities is None
        else sample_identities
    )
    training_batch = FormalGeometryTrainingBatchV2(
        train_fit=train_fit,
        model_input=model_input,
        endpoint=None,
        sample_identities=identities,
    )
    stacked = tuple(zip(*relation_rows, strict=True))
    supervision = Phase2ASupervisionV2(
        equivalent_targets=torch.stack(target_rows).unsqueeze(1).to(torch_device),
        free_parameter_mask=torch.stack(masks).to(torch_device),
        induced_metric=torch.stack(metrics).to(torch_device),
        wyckoff_id=integrated.candidate_wyckoff.to(torch_device),
        edge_presence=torch.stack(stacked[0]).to(torch_device),
        edge_distance=torch.stack(stacked[1]).to(torch_device),
        edge_direction_fourier=torch.stack(stacked[2]).to(torch_device),
        edge_shell=torch.stack(stacked[3]).to(torch_device),
        edge_coordination=torch.stack(stacked[4]).to(torch_device),
        triplet_presence=torch.stack(stacked[5]).to(torch_device),
        triplet_cosine=torch.stack(stacked[6]).to(torch_device),
        states=tuple(states),
    )
    return BuiltPhase2ATrainingBatchV2(training_batch, supervision)


def compute_phase2a_base_loss_v2(
    model: FormalGeometryV2Model,
    batch: FormalGeometryTrainingBatchV2,
    supervision: Phase2ASupervisionV2,
    *,
    generator: torch.Generator,
) -> torch.Tensor:
    model_input, prediction, context = model.condition(batch.model_input)
    device = model_input.composition.device
    dtype = model_input.composition.dtype
    base_noise = torch.rand(
        supervision.free_parameter_mask.shape,
        generator=generator,
        device=device,
        dtype=dtype,
    )
    flow_batch = build_flow_matching_batch(
        base_noise=base_noise,
        equivalent_targets=supervision.equivalent_targets,
        free_parameter_mask=supervision.free_parameter_mask,
        generator=generator,
        metric=supervision.induced_metric,
    )
    velocity = model.flow(
        flow_batch.u_tau,
        flow_batch.tau,
        context,
        supervision.wyckoff_id,
        supervision.free_parameter_mask,
    )
    graph = model_input.active_orbit_graph
    edge_observable = graph.edge_mask.unsqueeze(-1)
    triplet_observable = graph.triplet_mask.unsqueeze(-1)
    presence = functional.binary_cross_entropy_with_logits(
        prediction.edge_presence_logit,
        supervision.edge_presence,
        reduction="none",
    )
    presence = (presence * edge_observable).sum() / edge_observable.sum().clamp_min(1)
    distance = relation_realization_loss(
        prediction.edge_distance[..., :1],
        supervision.edge_distance,
        prediction.edge_distance[..., 1:2],
        edge_observable,
    )
    direction_scale = prediction.edge_direction_log_scale.repeat_interleave(2, dim=-1)
    direction = relation_realization_loss(
        prediction.edge_direction_fourier,
        supervision.edge_direction_fourier,
        direction_scale,
        edge_observable.expand_as(prediction.edge_direction_fourier),
    )
    shell = shell_pair_loss(
        prediction.edge_shell_logits,
        supervision.edge_shell,
        graph.edge_mask,
    )
    coordination = coordination_loss(
        prediction.edge_coordination,
        supervision.edge_coordination,
        edge_observable.expand_as(prediction.edge_coordination),
    )
    triplet_presence = functional.binary_cross_entropy_with_logits(
        prediction.triplet_presence_logit,
        supervision.triplet_presence,
        reduction="none",
    )
    triplet_presence = (
        (triplet_presence * triplet_observable).sum()
        / triplet_observable.sum().clamp_min(1)
    )
    triplet = relation_realization_loss(
        prediction.triplet_angle[..., :1],
        supervision.triplet_cosine,
        prediction.triplet_angle[..., 1:2],
        triplet_observable,
    )
    return (
        flow_matching_loss(velocity, flow_batch)
        + presence
        + distance
        + direction
        + shell
        + coordination
        + triplet_presence
        + triplet
    )


__all__ = [
    "BuiltPhase2ATrainingBatchV2",
    "DEFAULT_SHELL_BOUNDARIES_ANGSTROM",
    "Phase2ASupervisionV2",
    "build_phase2a_training_batch_v2",
    "compute_phase2a_base_loss_v2",
    "load_frozen_phase2a_bundles_v2",
    "load_frozen_phase2a_corpus_v2",
]
