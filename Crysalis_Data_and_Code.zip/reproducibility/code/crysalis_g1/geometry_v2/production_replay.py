from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Sequence

import torch

from .phase2a_trajectory import (
    Phase2ATrajectoryV2,
    deterministic_trajectory_permutation_v2,
)
from .production_config import ProductionTrainingConfigV2
from .replay_buffer import (
    ReplayBufferV2,
    generate_model_realized_replay_v2,
    model_state_sha256_v2,
)


REPLAY_REFRESH_RECEIPT_SCHEMA_V2 = (
    "crysalis-geometry-v2-production-replay-refresh.1.0.0"
)


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


@dataclass(frozen=True, slots=True)
class ProductionReplayRefreshReceiptV2:
    interval_index: int
    unroll_length: int
    trajectory_count: int
    selected_trajectory_ids: tuple[str, ...]
    source_checkpoint_sha256: str
    buffer_sha256: str
    buffer_path: str
    summary: dict[str, object]
    wall_seconds: float
    reused_closed_artifact: bool


class ProductionReplayRefresherV2:
    """Deterministic, checkpoint-bound replay refresh with atomic publication."""

    def __init__(
        self,
        *,
        trajectories: Sequence[Phase2ATrajectoryV2],
        trajectory_count: int,
        partner_event: object,
        normalizer: object,
        guide_objective: object,
        projector: object,
        relation_calibration: object,
        config: ProductionTrainingConfigV2,
        output_root: str | Path,
        device: str | torch.device,
    ) -> None:
        ordered = deterministic_trajectory_permutation_v2(
            trajectories, config.training_seed
        )
        if not 1 <= trajectory_count <= len(ordered):
            raise ValueError("replay trajectory count is outside train_fit")
        self.selected = ordered[:trajectory_count]
        self.partner_event = partner_event
        self.normalizer = normalizer
        self.guide = guide_objective
        self.projector = projector
        self.calibration = relation_calibration
        self.config = config
        self.output_root = Path(output_root)
        self.device = torch.device(device)

    def interval_root(self, interval_index: int) -> Path:
        if type(interval_index) is not int or interval_index <= 0:
            raise ValueError("production refresh interval must be positive")
        return self.output_root / f"interval_{interval_index:04d}"

    def _load_closed(
        self,
        *,
        interval_index: int,
        checkpoint_hash: str,
        unroll_length: int,
    ) -> tuple[ReplayBufferV2, ProductionReplayRefreshReceiptV2] | None:
        root = self.interval_root(interval_index)
        receipt_path = root / "REPLAY_REFRESH_RECEIPT.json"
        if not root.exists():
            return None
        if not receipt_path.is_file():
            raise RuntimeError("replay refresh directory is not atomically complete")
        payload = json.loads(receipt_path.read_text(encoding="utf-8"))
        required = {
            "schema_version",
            "interval_index",
            "unroll_length",
            "trajectory_count",
            "selected_trajectory_ids",
            "source_checkpoint_sha256",
            "buffer_sha256",
            "buffer_path",
            "summary",
            "wall_seconds",
            "records_file_sha256",
        }
        if set(payload) != required or payload["schema_version"] != REPLAY_REFRESH_RECEIPT_SCHEMA_V2:
            raise ValueError("closed replay refresh receipt fields are invalid")
        expected_ids = tuple(item.trajectory_id for item in self.selected)
        if (
            int(payload["interval_index"]) != interval_index
            or int(payload["unroll_length"]) != unroll_length
            or int(payload["trajectory_count"]) != len(self.selected)
            or tuple(payload["selected_trajectory_ids"]) != expected_ids
            or payload["source_checkpoint_sha256"] != checkpoint_hash
        ):
            raise ValueError("closed replay refresh provenance differs from checkpoint")
        buffer_root = root / "buffer"
        buffer = ReplayBufferV2.read(buffer_root)
        records_path = buffer_root / "records.jsonl"
        if (
            buffer.buffer_sha256 != payload["buffer_sha256"]
            or _sha256_file(records_path) != payload["records_file_sha256"]
        ):
            raise ValueError("closed replay refresh hashes do not match")
        return buffer, ProductionReplayRefreshReceiptV2(
            interval_index=interval_index,
            unroll_length=unroll_length,
            trajectory_count=len(self.selected),
            selected_trajectory_ids=expected_ids,
            source_checkpoint_sha256=checkpoint_hash,
            buffer_sha256=buffer.buffer_sha256,
            buffer_path=str(buffer_root),
            summary=dict(payload["summary"]),
            wall_seconds=float(payload["wall_seconds"]),
            reused_closed_artifact=True,
        )

    def refresh(
        self, model: torch.nn.Module, interval_index: int
    ) -> tuple[ReplayBufferV2, ProductionReplayRefreshReceiptV2]:
        checkpoint_hash = model_state_sha256_v2(model)
        unroll_length = self.config.unroll_length(interval_index)
        closed = self._load_closed(
            interval_index=interval_index,
            checkpoint_hash=checkpoint_hash,
            unroll_length=unroll_length,
        )
        if closed is not None:
            return closed
        self.output_root.mkdir(parents=True, exist_ok=True)
        started = time.perf_counter()
        buffer, summary = generate_model_realized_replay_v2(
            model=model,
            trajectories=self.selected,
            partner_event=self.partner_event,
            normalizer=self.normalizer,
            guide_objective=self.guide,
            projector=self.projector,
            relation_calibration=self.calibration,
            unroll_length=unroll_length,
            registered_seed_root=self.config.training_seed,
            buffer_generation_interval=interval_index,
            device=self.device,
        )
        if {record.source_checkpoint_sha256 for record in buffer.records} != {
            checkpoint_hash
        }:
            raise ValueError("refreshed replay records do not match current checkpoint")
        if {record.buffer_generation_interval for record in buffer.records} != {
            interval_index
        }:
            raise ValueError("refreshed replay records carry the wrong interval")
        temporary = Path(
            tempfile.mkdtemp(
                prefix=f".interval_{interval_index:04d}.", dir=self.output_root
            )
        )
        destination = self.interval_root(interval_index)
        try:
            buffer_root = temporary / "buffer"
            buffer.write(buffer_root)
            records_hash = _sha256_file(buffer_root / "records.jsonl")
            wall_seconds = time.perf_counter() - started
            payload = {
                "schema_version": REPLAY_REFRESH_RECEIPT_SCHEMA_V2,
                "interval_index": interval_index,
                "unroll_length": unroll_length,
                "trajectory_count": len(self.selected),
                "selected_trajectory_ids": [
                    item.trajectory_id for item in self.selected
                ],
                "source_checkpoint_sha256": checkpoint_hash,
                "buffer_sha256": buffer.buffer_sha256,
                "buffer_path": str(destination / "buffer"),
                "summary": asdict(summary),
                "wall_seconds": wall_seconds,
                "records_file_sha256": records_hash,
            }
            (temporary / "REPLAY_REFRESH_RECEIPT.json").write_text(
                json.dumps(payload, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            os.replace(temporary, destination)
        finally:
            if temporary.exists():
                shutil.rmtree(temporary)
        return buffer, ProductionReplayRefreshReceiptV2(
            interval_index=interval_index,
            unroll_length=unroll_length,
            trajectory_count=len(self.selected),
            selected_trajectory_ids=tuple(item.trajectory_id for item in self.selected),
            source_checkpoint_sha256=checkpoint_hash,
            buffer_sha256=buffer.buffer_sha256,
            buffer_path=str(destination / "buffer"),
            summary=asdict(summary),
            wall_seconds=time.perf_counter() - started,
            reused_closed_artifact=False,
        )


__all__ = [
    "ProductionReplayRefresherV2",
    "ProductionReplayRefreshReceiptV2",
    "REPLAY_REFRESH_RECEIPT_SCHEMA_V2",
]
