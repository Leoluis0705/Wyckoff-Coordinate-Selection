from __future__ import annotations

from typing import Any, Mapping

import numpy as np
import torch
from pymatgen.core import Lattice, Structure

from crysalis_g1.symmetry.wyckoff import (
    OrbitState,
    SpaceGroupConditionedWyckoffExpander,
    WyckoffExpansionError,
)

from .refinement import GuideEvaluationV2


def _as_numpy(value: Any) -> np.ndarray:
    if hasattr(value, "detach"):
        value = value.detach().cpu().numpy()
    return np.asarray(value, dtype=float)


class ProductionGuideObjectiveV2:
    """Frozen CHGNet Guide with the established partial-state applicability rule."""

    neighbor_applicability_cutoff_angstrom = 5.0

    def __init__(self, predictor: Any) -> None:
        if not callable(getattr(predictor, "predict_structure", None)):
            raise TypeError("production Guide predictor must implement predict_structure")
        self._predictor = predictor
        self._expander = SpaceGroupConditionedWyckoffExpander()
        parameters = getattr(predictor, "parameters", None)
        self.parameter_count = (
            sum(parameter.numel() for parameter in parameters())
            if callable(parameters)
            else int(getattr(predictor, "parameter_count", 0))
        )

    @classmethod
    def from_device(cls, device: str) -> ProductionGuideObjectiveV2:
        from chgnet.model import CHGNet

        predictor = CHGNet.load(model_name="0.3.0", use_device=device, verbose=False)
        predictor.eval()
        for parameter in predictor.parameters():
            parameter.requires_grad_(False)
        return cls(predictor)

    def _structure(
        self,
        orbits: tuple[OrbitState, ...],
        lattice: object,
    ) -> Structure:
        atomic_numbers: list[int] = []
        coordinates: list[tuple[float, float, float]] = []
        for orbit in orbits:
            expanded = self._expander.expand(
                orbit,
                lattice,
                require_target_space_group=False,
                require_distinct_orbit_instances=False,
            )
            atomic_numbers.extend(expanded.atomic_numbers)
            coordinates.extend(expanded.fractional_coordinates)
        return Structure(
            Lattice(np.asarray(lattice, dtype=float)),
            atomic_numbers,
            coordinates,
        )

    def _inapplicable_reason(self, structure: Structure) -> str | None:
        if len(structure) <= 1:
            return "ISOLATED_PARTIAL_PROXY"
        if max(int(site.specie.Z) for site in structure) > 94:
            return "UNSUPPORTED_ELEMENT_PROXY"
        distances = np.asarray(structure.distance_matrix, dtype=float).copy()
        np.fill_diagonal(distances, np.inf)
        if bool(
            np.any(
                distances.min(axis=1)
                > self.neighbor_applicability_cutoff_angstrom
            )
        ):
            return "NO_CHGNET_NEIGHBOR_PROXY"
        return None

    def evaluate(
        self,
        orbits: tuple[OrbitState, ...],
        lattice: object,
    ) -> GuideEvaluationV2:
        try:
            structure = self._structure(orbits, lattice)
        except WyckoffExpansionError as error:
            if error.reason_code not in {
                "MULTIPLICITY_MISMATCH",
                "ORBIT_IDENTITY_CONFLICT",
                "ORBIT_MEMBERSHIP_MISMATCH",
                "ORBIT_INSTANCE_MERGE",
                "TARGET_SPACE_GROUP_MISMATCH",
            }:
                raise
            return GuideEvaluationV2(
                energy=0.0,
                cartesian_forces=np.zeros(
                    (sum(orbit.multiplicity for orbit in orbits), 3), dtype=float
                ),
                applicable=False,
                reason_code=f"GUIDE_GEOMETRY_UNAVAILABLE:{error.reason_code}",
            )
        reason = self._inapplicable_reason(structure)
        if reason is not None:
            return GuideEvaluationV2(
                energy=0.0,
                cartesian_forces=np.zeros((len(structure), 3), dtype=float),
                applicable=False,
                reason_code=reason,
            )
        with torch.enable_grad():
            raw = self._predictor.predict_structure(
                structure, task="ef", batch_size=1
            )
        if not isinstance(raw, Mapping) or "e" not in raw or "f" not in raw:
            raise ValueError("GuideMLIP prediction lacks energy or forces")
        energy_values = _as_numpy(raw["e"]).reshape(-1)
        forces = _as_numpy(raw["f"])
        if energy_values.size != 1 or forces.shape != (len(structure), 3):
            raise ValueError("GuideMLIP prediction shape mismatch")
        energy = float(energy_values[0])
        if not np.isfinite(energy) or not np.isfinite(forces).all():
            raise FloatingPointError("non-finite GuideMLIP energy or force")
        return GuideEvaluationV2(
            energy=energy,
            cartesian_forces=forces,
            applicable=True,
            reason_code=None,
        )


__all__ = ["ProductionGuideObjectiveV2"]
