from __future__ import annotations

from dataclasses import dataclass, replace


CHECKPOINT_SELECTION_FIELDS_V2 = (
    "normalized_flow_loss",
    "normalized_final_relation_nll",
    "normalized_local_metric_error",
    "legality_penalty",
)


@dataclass(frozen=True, slots=True)
class ProductionTrainingConfigV2:
    replay_refresh_interval: int = 250
    effective_batch_size: int = 128
    teacher_count: int = 64
    model_realized_count: int = 64
    microbatch_size: int = 128
    sample_count: int = 1
    sampler_steps: int = 8
    optimizer: str = "AdamW"
    learning_rate: float = 3.0e-4
    weight_decay: float = 1.0e-5
    gradient_clip_norm: float = 1.0
    validation_interval: int = 250
    minimum_updates: int = 3000
    maximum_updates: int = 8000
    early_stopping_patience: int = 6
    training_seed: int = 20260828
    checkpoint_selection_fields: tuple[str, ...] = CHECKPOINT_SELECTION_FIELDS_V2
    formal_training_authorized: bool = False

    def __post_init__(self) -> None:
        if self.replay_refresh_interval != 250:
            raise ValueError("replay refresh interval must remain 250")
        if self.effective_batch_size != 128:
            raise ValueError("effective batch size must remain 128")
        if (
            self.teacher_count != self.model_realized_count
            or self.teacher_count + self.model_realized_count
            != self.effective_batch_size
        ):
            raise ValueError("teacher/model-realized exposure must remain 1:1")
        if self.microbatch_size <= 0 or self.effective_batch_size % self.microbatch_size:
            raise ValueError("microbatch size must divide the effective batch")
        if self.sample_count != 1:
            raise ValueError("formal sampling must remain registered K=1")
        if self.sampler_steps != 8:
            raise ValueError("formal sampler must remain eight-step Heun")
        if self.optimizer != "AdamW":
            raise ValueError("optimizer proposal must remain AdamW")
        if not (self.learning_rate > 0 and self.weight_decay >= 0):
            raise ValueError("optimizer values must be finite positive proposals")
        if self.gradient_clip_norm != 1.0:
            raise ValueError("gradient clipping proposal must remain 1.0")
        if self.validation_interval != self.replay_refresh_interval:
            raise ValueError("validation and replay refresh boundaries must align")
        if not 0 < self.minimum_updates <= self.maximum_updates:
            raise ValueError("training budget proposal is invalid")
        if self.early_stopping_patience != 6:
            raise ValueError("early-stopping patience proposal must remain six intervals")
        if self.training_seed != 20260828:
            raise ValueError("registered training seed must remain 20260828")
        if self.checkpoint_selection_fields != CHECKPOINT_SELECTION_FIELDS_V2:
            raise ValueError("checkpoint selection fields differ from the frozen contract")
        if type(self.formal_training_authorized) is not bool:
            raise TypeError("formal training authorization must be explicit boolean state")

    @classmethod
    def proposed(cls, **overrides: object) -> ProductionTrainingConfigV2:
        return replace(cls(), **overrides)

    @property
    def gradient_accumulation_steps(self) -> int:
        return self.effective_batch_size // self.microbatch_size

    def is_live_endpoint_batch(self, batch_index: int) -> bool:
        if type(batch_index) is not int or batch_index < 0:
            raise ValueError("batch index must be non-negative")
        return batch_index % 4 == 3

    @property
    def live_endpoint_batches(self) -> tuple[int, ...]:
        return tuple(range(3, self.maximum_updates, 4))

    def unroll_length(self, interval_index: int) -> int:
        if type(interval_index) is not int or interval_index < 0:
            raise ValueError("refresh interval index must be non-negative")
        return 2 + interval_index % 3


__all__ = ["CHECKPOINT_SELECTION_FIELDS_V2", "ProductionTrainingConfigV2"]
