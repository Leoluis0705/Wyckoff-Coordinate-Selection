from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import dataclass, replace
from typing import Protocol

import numpy as np

from crysalis_g1.symmetry.assembly import SymmetryAssemblyState
from crysalis_g1.symmetry.wyckoff import OrbitState, WyckoffExpansionError

from .manifold import WyckoffManifoldAdapter, project_cartesian_forces
from .physics_guidance import FROZEN_MANIFOLD_TRUST_RADIUS
from .wyckoff_shadow import ShadowMapMismatchError


MAX_ACCEPTED_REFINEMENT_STEPS = 4
FIXED_LINE_SEARCH_MULTIPLIERS = (1.0, 0.5, 0.25, 0.125)


@dataclass(frozen=True, slots=True)
class GuideEvaluationV2:
    energy: float
    cartesian_forces: np.ndarray
    applicable: bool
    reason_code: str | None

    def __post_init__(self) -> None:
        forces = np.asarray(self.cartesian_forces, dtype=float)
        if not math.isfinite(float(self.energy)) or not np.isfinite(forces).all():
            raise FloatingPointError("non-finite Guide evaluation")
        if forces.ndim != 2 or forces.shape[1] != 3:
            raise ValueError("Guide Cartesian forces must have shape [M,3]")
        if self.applicable and self.reason_code is not None:
            raise ValueError("applicable Guide evaluation cannot have a reason code")
        if not self.applicable and not self.reason_code:
            raise ValueError("inapplicable Guide evaluation requires a reason code")
        object.__setattr__(self, "cartesian_forces", forces)


@dataclass(frozen=True, slots=True)
class RelationEvaluationV2:
    potential: float
    gradient: np.ndarray

    def __post_init__(self) -> None:
        gradient = np.asarray(self.gradient, dtype=float)
        if not math.isfinite(float(self.potential)) or gradient.ndim != 1 or not np.isfinite(gradient).all():
            raise FloatingPointError("non-finite relation evaluation")
        object.__setattr__(self, "gradient", gradient)


class GuideObjectiveProtocolV2(Protocol):
    def evaluate(
        self, orbits: tuple[OrbitState, ...], lattice: object
    ) -> GuideEvaluationV2: ...


class RelationObjectiveProtocolV2(Protocol):
    def evaluate(
        self, orbits: tuple[OrbitState, ...], lattice: object
    ) -> RelationEvaluationV2: ...


class ProjectorDecisionProtocol(Protocol):
    accepted: bool
    reason_codes: tuple[str, ...]
    target_space_group: int
    partial_state: bool
    detected_space_groups: Mapping[float, int]
    orbit_membership_valid: bool
    distinct_orbit_instances_valid: bool
    composition_valid: bool
    multiplicity_valid: bool
    minimum_distance_valid: bool


class ProjectorProtocolV2(Protocol):
    def project(self, state: SymmetryAssemblyState) -> ProjectorDecisionProtocol: ...


@dataclass(frozen=True, slots=True)
class JointRefinementReceiptV2:
    accepted_steps: int
    attempted_proposals: int
    attempted_multipliers: tuple[float, ...]
    line_search_multipliers: tuple[float, ...]
    objective_history: tuple[float, ...]
    rejection_reasons: tuple[tuple[str, ...], ...]
    reason_codes: tuple[str, ...]
    guide_reason_codes: tuple[str, ...]
    partial_state: bool
    zero_dof_case: str
    resampled: bool


@dataclass(frozen=True, slots=True)
class JointRefinementResultV2:
    state: SymmetryAssemblyState
    receipt: JointRefinementReceiptV2


def _pack(orbits: tuple[OrbitState, ...]) -> np.ndarray:
    return np.asarray(
        [value for orbit in orbits for value in orbit.free_parameters], dtype=float
    )


def _replace_parameters(
    state: SymmetryAssemblyState, values: np.ndarray
) -> SymmetryAssemblyState:
    offset = 0
    updated: list[OrbitState] = []
    for orbit in state.orbits:
        count = len(orbit.free_parameters)
        parameters = tuple(float(value % 1.0) for value in values[offset : offset + count])
        updated.append(replace(orbit, free_parameters=parameters))
        offset += count
    return replace(state, orbits=tuple(updated))


def _trust_delta(values: np.ndarray, sampled: np.ndarray) -> np.ndarray:
    delta = np.asarray(values, dtype=float) - np.asarray(sampled, dtype=float)
    return delta - np.round(delta)


def _objective(
    state: SymmetryAssemblyState,
    sampled: np.ndarray,
    guide: GuideObjectiveProtocolV2,
    relation: RelationObjectiveProtocolV2,
    *,
    energy_scale: float,
    trust_weight: float,
) -> tuple[float, GuideEvaluationV2, RelationEvaluationV2]:
    guide_evaluation = guide.evaluate(state.orbits, state.lattice.primitive_matrix)
    relation_evaluation = relation.evaluate(state.orbits, state.lattice.primitive_matrix)
    if relation_evaluation.gradient.size != sampled.size:
        raise ValueError("relation gradient size does not match global free DOF")
    delta = _trust_delta(_pack(state.orbits), sampled)
    value = (
        (guide_evaluation.energy / energy_scale if guide_evaluation.applicable else 0.0)
        + relation_evaluation.potential
        + trust_weight * float(delta @ delta)
    )
    if not math.isfinite(value):
        raise FloatingPointError("non-finite joint refinement objective")
    return value, guide_evaluation, relation_evaluation


def _clip_numpy_metric(step: np.ndarray, metric: np.ndarray) -> np.ndarray:
    norm = math.sqrt(max(float(step @ metric @ step), 0.0))
    if norm > FROZEN_MANIFOLD_TRUST_RADIUS:
        step = step * (FROZEN_MANIFOLD_TRUST_RADIUS / norm)
    linf = float(np.max(np.abs(step), initial=0.0))
    if linf > FROZEN_MANIFOLD_TRUST_RADIUS:
        step = step * (FROZEN_MANIFOLD_TRUST_RADIUS / linf)
    return step


def _invariants_unchanged(
    before: SymmetryAssemblyState, after: SymmetryAssemblyState
) -> bool:
    return bool(
        before.target_space_group == after.target_space_group
        and before.composition == after.composition
        and before.remaining_composition == after.remaining_composition
        and tuple((item.species, item.multiplicity) for item in before.orbits)
        == tuple((item.species, item.multiplicity) for item in after.orbits)
    )


def refine_joint_manifold(
    state: SymmetryAssemblyState,
    *,
    partial_state: bool,
    candidate_free_dof: int,
    guide: GuideObjectiveProtocolV2,
    relation: RelationObjectiveProtocolV2,
    projector: ProjectorProtocolV2,
    adapter: WyckoffManifoldAdapter | None = None,
    energy_scale: float = 1.0,
    trust_weight: float = 1.0,
    epsilon: float = 1e-6,
) -> JointRefinementResultV2:
    if type(partial_state) is not bool:
        raise ValueError("partial_state must be an exact boolean")
    if partial_state != bool(state.remaining_composition):
        raise ValueError("partial_state must match the assembly state's remaining composition")
    if type(candidate_free_dof) is not int or not 0 <= candidate_free_dof <= 3:
        raise ValueError("candidate_free_dof must be an integer from 0 through 3")
    if not math.isfinite(energy_scale) or energy_scale <= 0:
        raise ValueError("energy_scale must be finite and positive")
    if not math.isfinite(trust_weight) or trust_weight < 0:
        raise ValueError("trust_weight must be finite and non-negative")
    if not math.isfinite(epsilon) or epsilon <= 0:
        raise ValueError("epsilon must be finite and positive")
    manifold = adapter or WyckoffManifoldAdapter()
    sampled = _pack(state.orbits)
    global_dof = sampled.size
    zero_case = (
        "GLOBAL_ZERO_DOF"
        if global_dof == 0
        else "CANDIDATE_ZERO_GLOBAL_NONZERO"
        if candidate_free_dof == 0
        else "CANDIDATE_NONZERO_GLOBAL_NONZERO"
    )
    initial_objective, initial_guide, _ = _objective(
        state,
        sampled,
        guide,
        relation,
        energy_scale=energy_scale,
        trust_weight=trust_weight,
    )
    guide_reason_codes: list[str] = []
    if not initial_guide.applicable and initial_guide.reason_code is not None:
        guide_reason_codes.append(initial_guide.reason_code)
    if global_dof == 0:
        return JointRefinementResultV2(
            state=state,
            receipt=JointRefinementReceiptV2(
                accepted_steps=0,
                attempted_proposals=0,
                attempted_multipliers=(),
                line_search_multipliers=(),
                objective_history=(initial_objective,),
                rejection_reasons=(),
                reason_codes=("GLOBAL_ZERO_DOF_EVALUATION_ONLY",),
                guide_reason_codes=tuple(guide_reason_codes),
                partial_state=partial_state,
                zero_dof_case=zero_case,
                resampled=False,
            ),
        )

    current = state
    current_objective = initial_objective
    objective_history = [initial_objective]
    accepted_multipliers: list[float] = []
    rejection_reasons: list[tuple[str, ...]] = []
    attempted = 0
    attempted_multipliers: list[float] = []
    stopped_on_rejection = False
    for _ in range(MAX_ACCEPTED_REFINEMENT_STEPS):
        linearization = manifold.linearize(current.orbits, current.lattice.primitive_matrix)
        _, guide_evaluation, relation_evaluation = _objective(
            current,
            sampled,
            guide,
            relation,
            energy_scale=energy_scale,
            trust_weight=trust_weight,
        )
        if (
            not guide_evaluation.applicable
            and guide_evaluation.reason_code is not None
            and guide_evaluation.reason_code not in guide_reason_codes
        ):
            guide_reason_codes.append(guide_evaluation.reason_code)
        guide_force = (
            guide_evaluation.cartesian_forces
            if guide_evaluation.applicable
            else np.zeros_like(guide_evaluation.cartesian_forces)
        )
        generalized = project_cartesian_forces(linearization.jacobian, guide_force) / energy_scale
        current_values = _pack(current.orbits)
        trust_gradient = 2.0 * trust_weight * _trust_delta(current_values, sampled)
        rhs = generalized - relation_evaluation.gradient - trust_gradient
        metric = linearization.jacobian.T @ linearization.jacobian + epsilon * np.eye(global_dof)
        direction = _clip_numpy_metric(np.linalg.solve(metric, rhs), metric)
        accepted = False
        for multiplier in FIXED_LINE_SEARCH_MULTIPLIERS:
            attempted += 1
            attempted_multipliers.append(multiplier)
            proposal_values = np.mod(current_values + multiplier * direction, 1.0)
            proposal = _replace_parameters(current, proposal_values)
            reasons: list[str] = []
            try:
                proposal_linearization = manifold.linearize(
                    proposal.orbits,
                    proposal.lattice.primitive_matrix,
                    require_target_space_group=not partial_state,
                    require_distinct_orbit_instances=True,
                )
                if not proposal_linearization.diagnostics.finite:
                    reasons.append("NONFINITE_GEOMETRY")
            except WyckoffExpansionError as error:
                reasons.append(
                    "OFFICIAL_TARGET_SPACE_GROUP_MISMATCH"
                    if error.reason_code == "TARGET_SPACE_GROUP_MISMATCH"
                    else f"OFFICIAL_EXPANSION_REJECTED:{error.reason_code}"
                )
            except (
                FloatingPointError,
                ShadowMapMismatchError,
                ValueError,
            ) as error:
                reasons.append(f"OFFICIAL_EXPANSION_REJECTED:{type(error).__name__}")
            if not reasons:
                decision = projector.project(proposal)
                if not decision.accepted:
                    reasons.extend(decision.reason_codes or ("PROJECTOR_REJECTED",))
                elif getattr(decision, "target_space_group", None) != state.target_space_group:
                    reasons.append("PROJECTOR_TARGET_SPACE_GROUP_MISMATCH")
                elif getattr(decision, "partial_state", None) is not partial_state:
                    reasons.append("PROJECTOR_PARTIAL_STATE_MISMATCH")
                elif getattr(decision, "orbit_membership_valid", None) is not True:
                    reasons.append("PROJECTOR_ORBIT_MEMBERSHIP_INVALID")
                elif getattr(decision, "composition_valid", None) is not True:
                    reasons.append("PROJECTOR_COMPOSITION_INVALID")
                elif getattr(decision, "multiplicity_valid", None) is not True:
                    reasons.append("PROJECTOR_MULTIPLICITY_INVALID")
                elif getattr(decision, "minimum_distance_valid", None) is not True:
                    reasons.append("PROJECTOR_MINIMUM_DISTANCE_INVALID")
                elif not partial_state:
                    detected = getattr(decision, "detected_space_groups", None)
                    if not isinstance(detected, Mapping) or detected.get(0.03) != state.target_space_group:
                        reasons.append("PROJECTOR_TARGET_SPACE_GROUP_MISMATCH")
                    elif getattr(
                        decision, "distinct_orbit_instances_valid", None
                    ) is not True:
                        reasons.append("PROJECTOR_ORBIT_INSTANCES_INVALID")
            if not _invariants_unchanged(state, proposal):
                reasons.append("CRYSTAL_INVARIANT_CHANGED")
            if not reasons:
                proposal_objective, proposal_guide, _ = _objective(
                    proposal,
                    sampled,
                    guide,
                    relation,
                    energy_scale=energy_scale,
                    trust_weight=trust_weight,
                )
                if (
                    not proposal_guide.applicable
                    and proposal_guide.reason_code is not None
                    and proposal_guide.reason_code not in guide_reason_codes
                ):
                    guide_reason_codes.append(proposal_guide.reason_code)
                if not proposal_objective < current_objective:
                    reasons.append("OBJECTIVE_NOT_DECREASED")
            if reasons:
                rejection_reasons.append(tuple(reasons))
                continue
            current = proposal
            current_objective = proposal_objective
            objective_history.append(proposal_objective)
            accepted_multipliers.append(multiplier)
            accepted = True
            break
        if not accepted:
            stopped_on_rejection = True
            break

    reason_codes = (
        ("ALL_LINE_SEARCH_PROPOSALS_REJECTED",) if stopped_on_rejection else ()
    )
    return JointRefinementResultV2(
        state=current,
        receipt=JointRefinementReceiptV2(
            accepted_steps=len(accepted_multipliers),
            attempted_proposals=attempted,
            attempted_multipliers=tuple(attempted_multipliers),
            line_search_multipliers=tuple(accepted_multipliers),
            objective_history=tuple(objective_history),
            rejection_reasons=tuple(rejection_reasons),
            reason_codes=reason_codes,
            guide_reason_codes=tuple(guide_reason_codes),
            partial_state=partial_state,
            zero_dof_case=zero_case,
            resampled=False,
        ),
    )


__all__ = [
    "FIXED_LINE_SEARCH_MULTIPLIERS",
    "GuideEvaluationV2",
    "GuideObjectiveProtocolV2",
    "JointRefinementReceiptV2",
    "JointRefinementResultV2",
    "MAX_ACCEPTED_REFINEMENT_STEPS",
    "ProjectorProtocolV2",
    "RelationEvaluationV2",
    "RelationObjectiveProtocolV2",
    "refine_joint_manifold",
]
