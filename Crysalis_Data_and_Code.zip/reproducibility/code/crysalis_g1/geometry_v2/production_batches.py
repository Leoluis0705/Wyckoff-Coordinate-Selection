from __future__ import annotations

from dataclasses import dataclass
import random
from typing import Mapping, Sequence

import torch

from crysalis_g1.full_crysalis.data import IntegratedEvent, RelationNormalizer

from .memory import PersistentRelationMemoryV2
from .phase2a_adapter import (
    BuiltPhase2ATrainingBatchV2,
    build_phase2a_training_batch_v2,
)
from .replay_buffer import ModelRealizedReplayRecordV2
from .replay_buffer import ReplayBufferV2
from .train_fit import MODEL_REALIZED_UNROLL, TEACHER_STATE
from .training import TrajectorySampleIdentityV2


@dataclass(frozen=True, slots=True)
class ProductionBatchReceiptV2:
    batch_index: int
    teacher_event_ids: tuple[str, ...]
    replay_record_ids: tuple[str, ...]
    replay_source_checkpoint_hashes: tuple[str, ...]
    trajectory_ids: tuple[str, ...]
    sequence_indices: tuple[int, ...]
    registered_flow_seeds: tuple[int, ...]
    replay_failures: tuple[tuple[str, tuple[str, ...]], ...]
    buffer_generation_intervals: tuple[int, ...]
    source_split: str
    live_endpoint_scheduled: bool

    def __post_init__(self) -> None:
        if self.source_split != "train_fit":
            raise ValueError("production batches must be train_fit only")
        if len(self.teacher_event_ids) != len(self.replay_record_ids):
            raise ValueError("production teacher/model-realized batch ratio must be 1:1")


@dataclass(frozen=True, slots=True)
class ProductionBatchV2:
    built: BuiltPhase2ATrainingBatchV2
    receipt: ProductionBatchReceiptV2
    teacher_rows: tuple[int, ...]
    replay_rows: tuple[int, ...]


@dataclass(frozen=True, slots=True)
class ProductionBatchCursorV2:
    next_batch_index: int = 0
    teacher_cursor: int = 0
    teacher_epoch: int = 0
    replay_cursor: int = 0
    replay_epoch: int = 0

    def __post_init__(self) -> None:
        if any(
            type(value) is not int or value < 0
            for value in (
                self.next_batch_index,
                self.teacher_cursor,
                self.teacher_epoch,
                self.replay_cursor,
                self.replay_epoch,
            )
        ):
            raise ValueError("production batch cursor values must be non-negative")

    def to_dict(self) -> dict[str, int]:
        return {
            "next_batch_index": self.next_batch_index,
            "teacher_cursor": self.teacher_cursor,
            "teacher_epoch": self.teacher_epoch,
            "replay_cursor": self.replay_cursor,
            "replay_epoch": self.replay_epoch,
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> ProductionBatchCursorV2:
        return cls(**{name: int(payload[name]) for name in cls.__dataclass_fields__})


class ProductionBatchSchedulerV2:
    def __init__(
        self,
        *,
        train_events: Sequence[IntegratedEvent],
        replay_buffer: ReplayBufferV2,
        normalizer: RelationNormalizer,
        device: str | torch.device,
        root_seed: int,
        teacher_count: int = 64,
        model_realized_count: int = 64,
        shell_boundaries_angstrom: tuple[float, float, float] = (2.25, 3.25, 4.25),
    ) -> None:
        if teacher_count != model_realized_count or teacher_count <= 0:
            raise ValueError("production scheduler requires a positive 1:1 batch")
        usable = tuple(
            event for event in train_events if event.split == "train_fit" and not event.terminal
        )
        if len(usable) < teacher_count:
            raise ValueError("train_fit corpus cannot fill one frozen teacher batch")
        if len(replay_buffer.records) < model_realized_count:
            raise ValueError("replay buffer cannot fill one frozen model-realized batch")
        ordered = sorted(usable, key=lambda event: event.event_key)
        random.Random(int(root_seed)).shuffle(ordered)
        self._teacher = tuple(ordered)
        self._records = replay_buffer.records
        self._event_by_id = {event.event_key: event for event in usable}
        self._normalizer = normalizer
        self._device = device
        self._teacher_count = int(teacher_count)
        self._replay_count = int(model_realized_count)
        self._shell_boundaries = shell_boundaries_angstrom
        self.replay_buffer_sha256 = replay_buffer.buffer_sha256

    def replace_replay_buffer(self, replay_buffer: ReplayBufferV2) -> None:
        if len(replay_buffer.records) < self._replay_count:
            raise ValueError("refreshed replay buffer cannot fill one frozen batch")
        self._records = replay_buffer.records
        self.replay_buffer_sha256 = replay_buffer.buffer_sha256

    @staticmethod
    def _cyclic_take(values: Sequence[object], cursor: int, count: int) -> tuple[tuple[object, ...], int, int]:
        selected = tuple(values[(cursor + offset) % len(values)] for offset in range(count))
        total = cursor + count
        return selected, total % len(values), total // len(values)

    def next_batch(
        self, cursor: ProductionBatchCursorV2
    ) -> tuple[ProductionBatchV2, ProductionBatchCursorV2]:
        teachers_raw, teacher_cursor, teacher_epoch_delta = self._cyclic_take(
            self._teacher, cursor.teacher_cursor, self._teacher_count
        )
        records_raw, replay_cursor, replay_epoch_delta = self._cyclic_take(
            self._records, cursor.replay_cursor, self._replay_count
        )
        teachers = tuple(teachers_raw)
        records = tuple(records_raw)
        batch = build_production_batch_v2(
            teacher_events=teachers,
            replay_records=records,
            event_by_id=self._event_by_id,
            batch_index=cursor.next_batch_index,
            normalizer=self._normalizer,
            device=self._device,
            shell_boundaries_angstrom=self._shell_boundaries,
        )
        advanced = ProductionBatchCursorV2(
            next_batch_index=cursor.next_batch_index + 1,
            teacher_cursor=teacher_cursor,
            teacher_epoch=cursor.teacher_epoch + teacher_epoch_delta,
            replay_cursor=replay_cursor,
            replay_epoch=cursor.replay_epoch + replay_epoch_delta,
        )
        return batch, advanced


def build_production_batch_v2(
    *,
    teacher_events: Sequence[IntegratedEvent],
    replay_records: Sequence[ModelRealizedReplayRecordV2],
    event_by_id: Mapping[str, IntegratedEvent],
    batch_index: int,
    normalizer: RelationNormalizer,
    device: str | torch.device,
    shell_boundaries_angstrom: tuple[float, float, float] = (2.25, 3.25, 4.25),
) -> ProductionBatchV2:
    if not teacher_events or len(teacher_events) != len(replay_records):
        raise ValueError("production batch requires a non-empty 1:1 exposure ratio")
    if any(event.split != "train_fit" or event.terminal for event in teacher_events):
        raise ValueError("teacher exposure must use nonterminal train_fit events")

    events: list[IntegratedEvent] = []
    modes: list[str] = []
    active_overrides = []
    memory_overrides: list[PersistentRelationMemoryV2 | None] = []
    identities: list[TrajectorySampleIdentityV2] = []
    training_sample_ids: list[str] = []
    teacher_rows: list[int] = []
    replay_rows: list[int] = []
    for pair_index, (teacher, record) in enumerate(
        zip(teacher_events, replay_records, strict=True)
    ):
        teacher_row = len(events)
        events.append(teacher)
        modes.append(TEACHER_STATE)
        active_overrides.append(None)
        memory_overrides.append(None)
        identities.append(
            TrajectorySampleIdentityV2(
                trajectory_id=f"teacher:{batch_index}:{teacher.event_key}",
                sample_id=teacher.event_key,
                sequence_index=0,
            )
        )
        training_sample_ids.append(teacher.event_key)
        teacher_rows.append(teacher_row)

        replay_event = event_by_id.get(record.train_fit_event_id)
        if replay_event is None:
            raise KeyError(f"replay event missing from train_fit corpus: {record.train_fit_event_id}")
        if replay_event.split != "train_fit" or replay_event.parent_id != record.parent_id:
            raise ValueError("replay provenance does not match its train_fit event")
        pre_state = record.pre_state()
        teacher_signature = tuple(
            orbit.orbit_instance_id for orbit in replay_event.active_orbits
        )
        realized_signature = tuple(orbit.orbit_instance_id for orbit in pre_state.orbits)
        if teacher_signature != realized_signature:
            raise ValueError("replay pre-state does not match the correct action path")
        replay_row = len(events)
        events.append(replay_event)
        modes.append(MODEL_REALIZED_UNROLL)
        active_overrides.append(pre_state.orbits)
        memory_overrides.append(record.memory_before(device=device))
        identities.append(
            TrajectorySampleIdentityV2(
                trajectory_id=f"replay-record:{record.record_id}",
                sample_id=f"replay:{record.record_id}",
                sequence_index=0,
            )
        )
        training_sample_ids.append(f"replay:{record.record_id}")
        replay_rows.append(replay_row)

    built = build_phase2a_training_batch_v2(
        tuple(events),
        batch_index=batch_index,
        normalizer=normalizer,
        device=device,
        shell_boundaries_angstrom=shell_boundaries_angstrom,
        state_modes=tuple(modes),
        active_orbit_overrides=tuple(active_overrides),
        memory_overrides=tuple(memory_overrides),
        sample_identities=tuple(identities),
        training_sample_ids=tuple(training_sample_ids),
    )
    receipt = ProductionBatchReceiptV2(
        batch_index=batch_index,
        teacher_event_ids=tuple(event.event_key for event in teacher_events),
        replay_record_ids=tuple(record.record_id for record in replay_records),
        replay_source_checkpoint_hashes=tuple(
            record.source_checkpoint_sha256 for record in replay_records
        ),
        trajectory_ids=tuple(record.trajectory_id for record in replay_records),
        sequence_indices=tuple(record.sequence_index for record in replay_records),
        registered_flow_seeds=tuple(record.registered_seed for record in replay_records),
        replay_failures=tuple(
            (record.record_id, record.failure_reason_codes)
            for record in replay_records
            if not record.endpoint_accepted
        ),
        buffer_generation_intervals=tuple(
            record.buffer_generation_interval for record in replay_records
        ),
        source_split="train_fit",
        live_endpoint_scheduled=batch_index % 4 == 3,
    )
    return ProductionBatchV2(
        built=built,
        receipt=receipt,
        teacher_rows=tuple(teacher_rows),
        replay_rows=tuple(replay_rows),
    )


__all__ = [
    "ProductionBatchReceiptV2",
    "ProductionBatchCursorV2",
    "ProductionBatchSchedulerV2",
    "ProductionBatchV2",
    "build_production_batch_v2",
]
