from __future__ import annotations

import math
from numbers import Real
from typing import Sequence

from .types import MAX_FREE_DOF, validate_free_parameter_mask


def _finite_vector(values: Sequence[Real], label: str) -> tuple[float, float, float]:
    if len(values) != MAX_FREE_DOF:
        raise ValueError(f"{label} must be a 3-vector")
    normalized = tuple(float(value) for value in values)
    if not all(math.isfinite(value) for value in normalized):
        raise ValueError(f"{label} must be finite")
    return normalized  # type: ignore[return-value]


def _wrap_scalar(value: Real) -> float:
    result = float(value)
    if not math.isfinite(result):
        raise ValueError("torus value must be finite")
    return result - math.floor(result)


def wrap(value: Real | Sequence[Real]) -> float | tuple[float, ...]:
    if isinstance(value, Real):
        return _wrap_scalar(value)
    return tuple(_wrap_scalar(item) for item in value)


def _wrap_delta_scalar(value: Real) -> float:
    result = float(value)
    if not math.isfinite(result):
        raise ValueError("torus delta must be finite")
    return result - math.ceil(result - 0.5)


def wrap_delta(value: Real | Sequence[Real]) -> float | tuple[float, ...]:
    if isinstance(value, Real):
        return _wrap_delta_scalar(value)
    return tuple(_wrap_delta_scalar(item) for item in value)


def torus_geodesic_squared(
    left: Sequence[Real],
    right: Sequence[Real],
    free_parameter_mask: Sequence[bool],
) -> float:
    left_vector = _finite_vector(left, "left torus state")
    right_vector = _finite_vector(right, "right torus state")
    mask = validate_free_parameter_mask(free_parameter_mask)
    return sum(
        _wrap_delta_scalar(first - second) ** 2
        for first, second, is_free in zip(left_vector, right_vector, mask, strict=True)
        if is_free
    )


def torus_geodesic(
    left: Sequence[Real],
    right: Sequence[Real],
    free_parameter_mask: Sequence[bool],
) -> float:
    return math.sqrt(torus_geodesic_squared(left, right, free_parameter_mask))
