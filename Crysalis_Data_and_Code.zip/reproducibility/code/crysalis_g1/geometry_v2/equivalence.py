from __future__ import annotations

from dataclasses import dataclass
from numbers import Real
from typing import Sequence

from .torus import torus_geodesic, wrap
from .types import validate_free_parameter_mask


@dataclass(frozen=True, slots=True)
class EquivalenceDistance:
    distance: float
    selected_target: tuple[float, float, float]
    selected_index: int


def _target_key(
    reference: Sequence[Real], target: Sequence[Real], mask: Sequence[bool], index: int
) -> tuple[float, tuple[float, float, float], int]:
    wrapped = wrap(target)
    if not isinstance(wrapped, tuple) or len(wrapped) != 3:
        raise ValueError("equivalent target must be a 3-vector")
    return (
        torus_geodesic(reference, wrapped, mask),
        wrapped,  # type: ignore[arg-type]
        index,
    )


def nearest_equivalent(
    reference: Sequence[Real],
    equivalent_targets: Sequence[Sequence[Real]],
    free_parameter_mask: Sequence[bool],
) -> EquivalenceDistance:
    mask = validate_free_parameter_mask(free_parameter_mask)
    if not equivalent_targets:
        raise ValueError("equivalence class must contain at least one target")
    candidates = [
        _target_key(reference, target, mask, index)
        for index, target in enumerate(equivalent_targets)
    ]
    minimum_distance = min(candidate[0] for candidate in candidates)
    tied = [candidate for candidate in candidates if candidate[0] == minimum_distance]
    distance, target, index = min(tied, key=lambda candidate: candidate[1:])
    return EquivalenceDistance(
        distance=distance,
        selected_target=target,
        selected_index=index,
    )
