from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Protocol

import torch

from .sampler import VelocityFieldV2


FROZEN_MANIFOLD_TRUST_RADIUS = 0.025
LATE_GUIDANCE_START = 0.5


@dataclass(frozen=True, slots=True)
class GuidanceDriftV2:
    physics_step: torch.Tensor
    relation_step: torch.Tensor
    metric: torch.Tensor


class GuidanceDriftProviderV2(Protocol):
    def __call__(
        self,
        u: torch.Tensor,
        tau: torch.Tensor,
        context: torch.Tensor,
        wyckoff_id: torch.Tensor,
        free_parameter_mask: torch.Tensor,
    ) -> GuidanceDriftV2: ...


def clip_metric_step(
    step: torch.Tensor,
    metric: torch.Tensor,
    free_parameter_mask: torch.Tensor,
    *,
    trust_radius: float = FROZEN_MANIFOLD_TRUST_RADIUS,
) -> torch.Tensor:
    if not math.isfinite(trust_radius) or not 0 < trust_radius <= FROZEN_MANIFOLD_TRUST_RADIUS:
        raise ValueError("trust radius must be in (0, 0.025]")
    if step.ndim != 2 or metric.shape != (*step.shape, step.shape[1]):
        raise ValueError("step must be [B,D] and metric [B,D,D]")
    if free_parameter_mask.shape != step.shape or free_parameter_mask.dtype != torch.bool:
        raise ValueError("free-parameter mask must be boolean [B,D]")
    if not torch.isfinite(step).all() or not torch.isfinite(metric).all():
        raise FloatingPointError("non-finite guidance step or metric")
    masked = step * free_parameter_mask.to(step.dtype)
    squared_norm = torch.einsum("bi,bij,bj->b", masked, metric, masked).clamp_min(0.0)
    metric_norm = torch.sqrt(squared_norm)
    metric_scale = torch.where(
        metric_norm > trust_radius,
        torch.as_tensor(trust_radius, device=step.device, dtype=step.dtype)
        / metric_norm.clamp_min(torch.finfo(step.dtype).eps),
        torch.ones_like(metric_norm),
    )
    clipped = masked * metric_scale[:, None]
    linf = clipped.abs().amax(dim=1)
    linf_scale = torch.where(
        linf > trust_radius,
        torch.as_tensor(trust_radius, device=step.device, dtype=step.dtype)
        / linf.clamp_min(torch.finfo(step.dtype).eps),
        torch.ones_like(linf),
    )
    return clipped * linf_scale[:, None]


class LateSamplingGuidanceV2:
    """Velocity wrapper that evaluates guidance only on the late half of sampling."""

    def __init__(
        self,
        velocity_field: VelocityFieldV2,
        drift_provider: GuidanceDriftProviderV2,
        *,
        trust_radius: float = FROZEN_MANIFOLD_TRUST_RADIUS,
    ) -> None:
        if not 0 < trust_radius <= FROZEN_MANIFOLD_TRUST_RADIUS:
            raise ValueError("trust radius must be in (0, 0.025]")
        self.velocity_field = velocity_field
        self.drift_provider = drift_provider
        self.trust_radius = float(trust_radius)

    def __call__(
        self,
        u: torch.Tensor,
        tau: torch.Tensor,
        context: torch.Tensor,
        wyckoff_id: torch.Tensor,
        free_parameter_mask: torch.Tensor,
    ) -> torch.Tensor:
        velocity = self.velocity_field(
            u, tau, context, wyckoff_id, free_parameter_mask
        )
        if velocity.shape != u.shape or not torch.isfinite(velocity).all():
            raise FloatingPointError("non-finite base velocity")
        late = tau >= LATE_GUIDANCE_START
        if not bool(late.any()):
            return velocity
        drift = self.drift_provider(
            u[late],
            tau[late],
            context[late],
            wyckoff_id[late],
            free_parameter_mask[late],
        )
        if drift.physics_step.shape != u[late].shape or drift.relation_step.shape != u[late].shape:
            raise ValueError("guidance drift steps must match the late torus batch")
        clipped = clip_metric_step(
            drift.physics_step - drift.relation_step,
            drift.metric,
            free_parameter_mask[late],
            trust_radius=self.trust_radius,
        )
        schedule = ((tau[late] - LATE_GUIDANCE_START) / (1.0 - LATE_GUIDANCE_START)).clamp(0.0, 1.0)
        result = velocity.clone()
        result[late] = result[late] + schedule[:, None] * clipped
        if not torch.isfinite(result).all():
            raise FloatingPointError("non-finite guided velocity")
        return result


__all__ = [
    "FROZEN_MANIFOLD_TRUST_RADIUS",
    "GuidanceDriftProviderV2",
    "GuidanceDriftV2",
    "LATE_GUIDANCE_START",
    "LateSamplingGuidanceV2",
    "clip_metric_step",
]
