from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from pathlib import Path
from typing import cast


SCHEMA_VERSION = "crysalis-geometry-v2-v1-immutability-baseline.1"
_OFFICIAL_V1_SOURCES = (
    Path("crysalis_g1/symmetry/wyckoff.py"),
    Path("crysalis_g1/symmetry/assembly.py"),
)


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _relative_files(root: Path, suffix: str | None = None) -> tuple[Path, ...]:
    if not root.is_dir():
        raise FileNotFoundError(f"required V1 scope is missing: {root}")
    return tuple(
        sorted(
            (
                path
                for path in root.rglob("*")
                if path.is_file() and (suffix is None or path.suffix == suffix)
            ),
            key=lambda path: path.as_posix(),
        )
    )


def _file_entry(prefix: str, root: Path, path: Path) -> dict[str, str]:
    return {
        "path": f"{prefix}:{path.relative_to(root).as_posix()}",
        "sha256": _sha256_file(path),
    }


def snapshot_v1_immutability(
    repository_root: str | Path, frozen_results_root: str | Path
) -> dict[str, object]:
    repo = Path(repository_root).resolve()
    results = Path(frozen_results_root).resolve()
    full_crysalis_root = repo / "crysalis_g1/full_crysalis"
    source_files = _relative_files(full_crysalis_root, suffix=".py")
    if not source_files:
        raise FileNotFoundError("V1 full-crysalis source is empty")
    official_sources = tuple(repo / path for path in _OFFICIAL_V1_SOURCES)
    missing_sources = [path for path in official_sources if not path.is_file()]
    if missing_sources:
        raise FileNotFoundError(f"official V1 source is missing: {missing_sources[0]}")
    config_files = tuple(sorted((repo / "configs").glob("g1_full_crysalis*_20260826_v1.json")))
    if not config_files:
        raise FileNotFoundError("frozen V1 full-crysalis configs are missing")
    result_files = _relative_files(results)
    if not result_files:
        raise FileNotFoundError("frozen V1 result tree is empty")

    entries = [
        _file_entry("repo", repo, path)
        for path in (*source_files, *official_sources, *config_files)
    ]
    entries.extend(_file_entry("frozen-results", results, path) for path in result_files)
    entries.sort(key=lambda entry: entry["path"])
    aggregate = hashlib.sha256(
        json.dumps(entries, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    return {
        "schema_version": SCHEMA_VERSION,
        "scope": {
            "v1_full_crysalis_source": "crysalis_g1/full_crysalis/**/*.py",
            "official_expander_projector_legal_compiler_sources": [
                path.as_posix() for path in _OFFICIAL_V1_SOURCES
            ],
            "frozen_v1_configs": "configs/g1_full_crysalis*_20260826_v1.json",
            "frozen_v1_result_tree": str(results),
        },
        "files": entries,
        "file_count": len(entries),
        "aggregate_sha256": aggregate,
    }


def write_v1_immutability_baseline(
    destination: str | Path,
    repository_root: str | Path,
    frozen_results_root: str | Path,
) -> dict[str, object]:
    path = Path(destination)
    if path.exists():
        raise FileExistsError(f"V1 immutability baseline already exists: {path}")
    baseline = snapshot_v1_immutability(repository_root, frozen_results_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(baseline, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return baseline


def compare_v1_immutability(
    baseline: Mapping[str, object],
    repository_root: str | Path,
    frozen_results_root: str | Path,
) -> dict[str, object]:
    observed = snapshot_v1_immutability(repository_root, frozen_results_root)
    raw_files = baseline.get("files")
    if not isinstance(raw_files, list) or any(
        not isinstance(entry, Mapping)
        or not isinstance(entry.get("path"), str)
        or not isinstance(entry.get("sha256"), str)
        for entry in raw_files
    ):
        raise ValueError("V1 immutability baseline file entries are invalid")
    expected_hashes = {str(entry["path"]): str(entry["sha256"]) for entry in raw_files}
    observed_files = cast(list[dict[str, str]], observed["files"])
    observed_hashes = {
        str(entry["path"]): str(entry["sha256"])
        for entry in observed_files
    }
    all_paths = sorted(set(expected_hashes) | set(observed_hashes))
    mismatched = [
        path for path in all_paths if expected_hashes.get(path) != observed_hashes.get(path)
    ]
    aggregate_matches = baseline.get("aggregate_sha256") == observed["aggregate_sha256"]
    byte_identical = not mismatched and aggregate_matches
    return {
        "schema_version": "crysalis-geometry-v2-v1-immutability-audit.1",
        "status": "PASS" if byte_identical else "FAIL",
        "byte_identical": byte_identical,
        "baseline_file_count": baseline.get("file_count"),
        "observed_file_count": observed["file_count"],
        "baseline_aggregate_sha256": baseline.get("aggregate_sha256"),
        "observed_aggregate_sha256": observed["aggregate_sha256"],
        "mismatched_paths": mismatched,
        "observed_files": observed["files"],
        "scope": observed["scope"],
    }
