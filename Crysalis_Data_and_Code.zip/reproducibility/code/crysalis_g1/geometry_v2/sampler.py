from __future__ import annotations

import hashlib
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Protocol

import torch

from .flow import FLOW_CONTEXT_DIM
from .types import ZERO_DOF_BYPASS


REGISTERED_FLOW_NAMESPACE = "geometry_v2:toroidal_flow"
REGISTERED_HEUN_STEPS = 8
COVERAGE_DIAGNOSTIC_K = 8
REGISTERED_SAMPLE_SCHEMA = "crysalis-geometry-v2-registered-sample.1.0.0"


class VelocityFieldV2(Protocol):
    def __call__(
        self,
        u: torch.Tensor,
        tau: torch.Tensor,
        context: torch.Tensor,
        wyckoff_id: torch.Tensor,
        free_parameter_mask: torch.Tensor,
    ) -> torch.Tensor: ...


def wrap_torus_tensor(
    values: torch.Tensor, free_parameter_mask: torch.Tensor
) -> torch.Tensor:
    if values.ndim != 2 or values.shape[1] != 3:
        raise ValueError("torus values must have shape [B,3]")
    if free_parameter_mask.shape != values.shape or free_parameter_mask.dtype != torch.bool:
        raise ValueError("free-parameter mask must be boolean with shape [B,3]")
    if not torch.isfinite(values).all():
        raise FloatingPointError("non-finite torus state")
    return torch.remainder(values, 1.0) * free_parameter_mask.to(values.dtype)


@dataclass(frozen=True, slots=True, eq=False)
class RegisteredSamplingReceiptV2:
    registered_seed: int
    sample_index: int
    namespace: str
    sample_count: int
    integration_steps: int
    velocity_evaluations: int
    wrap_count: int
    zero_dof_bypass: tuple[bool, ...]
    reason_codes: tuple[tuple[str, ...], ...]
    base_noise: torch.Tensor
    free_parameter_mask: torch.Tensor

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, RegisteredSamplingReceiptV2):
            return NotImplemented
        return (
            self.registered_seed == other.registered_seed
            and self.sample_index == other.sample_index
            and self.namespace == other.namespace
            and self.sample_count == other.sample_count
            and self.integration_steps == other.integration_steps
            and self.velocity_evaluations == other.velocity_evaluations
            and self.wrap_count == other.wrap_count
            and self.zero_dof_bypass == other.zero_dof_bypass
            and self.reason_codes == other.reason_codes
            and torch.equal(self.base_noise, other.base_noise)
            and torch.equal(self.free_parameter_mask, other.free_parameter_mask)
        )

    def state_dict(self) -> dict[str, Any]:
        return {
            "registered_seed": self.registered_seed,
            "sample_index": self.sample_index,
            "namespace": self.namespace,
            "sample_count": self.sample_count,
            "integration_steps": self.integration_steps,
            "velocity_evaluations": self.velocity_evaluations,
            "wrap_count": self.wrap_count,
            "zero_dof_bypass": self.zero_dof_bypass,
            "reason_codes": self.reason_codes,
            "base_noise": self.base_noise.detach().clone(),
            "free_parameter_mask": self.free_parameter_mask.detach().clone(),
        }

    @classmethod
    def from_state_dict(
        cls, state: Mapping[str, Any]
    ) -> RegisteredSamplingReceiptV2:
        required = {
            "registered_seed",
            "sample_index",
            "namespace",
            "sample_count",
            "integration_steps",
            "velocity_evaluations",
            "wrap_count",
            "zero_dof_bypass",
            "reason_codes",
            "base_noise",
            "free_parameter_mask",
        }
        if set(state) != required:
            raise ValueError("registered sampling receipt has unexpected fields")
        integer_fields = (
            "registered_seed",
            "sample_index",
            "sample_count",
            "integration_steps",
            "velocity_evaluations",
            "wrap_count",
        )
        if any(type(state[field]) is not int for field in integer_fields):
            raise ValueError("registered sampling receipt integers must be exact ints")
        if state["registered_seed"] < 0:
            raise ValueError("registered sampling seed must be non-negative")
        if state["namespace"] != REGISTERED_FLOW_NAMESPACE:
            raise ValueError("registered sampling namespace is invalid")
        if state["sample_count"] != 1:
            raise ValueError("registered sampling receipt must have K=1 semantics")
        if not 0 <= state["sample_index"] < COVERAGE_DIAGNOSTIC_K:
            raise ValueError("registered sampling index is invalid")
        base_noise = state["base_noise"]
        free_parameter_mask = state["free_parameter_mask"]
        if not isinstance(base_noise, torch.Tensor) or not isinstance(
            free_parameter_mask, torch.Tensor
        ):
            raise ValueError("registered sampling receipt tensors are invalid")
        if (
            base_noise.ndim != 2
            or base_noise.shape[1] != 3
            or not torch.is_floating_point(base_noise)
            or not torch.isfinite(base_noise).all()
        ):
            raise ValueError("registered sampling base noise must be finite [B,3]")
        if (
            free_parameter_mask.shape != base_noise.shape
            or free_parameter_mask.dtype != torch.bool
            or free_parameter_mask.device != base_noise.device
        ):
            raise ValueError("registered sampling free-parameter mask is invalid")
        zero_dof = state["zero_dof_bypass"]
        reason_codes = state["reason_codes"]
        batch_size = base_noise.shape[0]
        if (
            type(zero_dof) is not tuple
            or len(zero_dof) != batch_size
            or any(type(value) is not bool for value in zero_dof)
        ):
            raise ValueError("zero-DOF bypass metadata is invalid")
        if (
            type(reason_codes) is not tuple
            or len(reason_codes) != batch_size
            or any(type(codes) is not tuple for codes in reason_codes)
            or any(type(code) is not str for codes in reason_codes for code in codes)
        ):
            raise ValueError("registered sampling reason codes are invalid")

        active_rows = free_parameter_mask.any(dim=1)
        expected_zero_dof = tuple(bool(value) for value in (~active_rows).tolist())
        expected_reasons = tuple(
            (ZERO_DOF_BYPASS,) if bypass else () for bypass in expected_zero_dof
        )
        if zero_dof != expected_zero_dof or reason_codes != expected_reasons:
            raise ValueError("zero-DOF bypass receipt is inconsistent with its mask")
        active_flow = bool(active_rows.any())
        expected_counts = (
            (REGISTERED_HEUN_STEPS, 2 * REGISTERED_HEUN_STEPS, 2 * REGISTERED_HEUN_STEPS)
            if active_flow
            else (0, 0, 0)
        )
        actual_counts = (
            state["integration_steps"],
            state["velocity_evaluations"],
            state["wrap_count"],
        )
        if actual_counts != expected_counts:
            raise ValueError("registered sampling integration counts are invalid")
        _validate_serialized_torus_tensor(
            base_noise, free_parameter_mask, "registered base noise"
        )
        expected_noise = _registered_base_noise(
            base_noise,
            free_parameter_mask,
            registered_seed=state["registered_seed"],
            sample_index=state["sample_index"],
        )
        if not torch.equal(base_noise, expected_noise):
            raise ValueError("registered base noise is inconsistent with its seed")

        return cls(
            registered_seed=state["registered_seed"],
            sample_index=state["sample_index"],
            namespace=state["namespace"],
            sample_count=state["sample_count"],
            integration_steps=state["integration_steps"],
            velocity_evaluations=state["velocity_evaluations"],
            wrap_count=state["wrap_count"],
            zero_dof_bypass=zero_dof,
            reason_codes=reason_codes,
            base_noise=base_noise,
            free_parameter_mask=free_parameter_mask,
        )


@dataclass(frozen=True, slots=True)
class RegisteredFlowSampleV2:
    values: torch.Tensor
    receipt: RegisteredSamplingReceiptV2

    @property
    def base_noise(self) -> torch.Tensor:
        return self.receipt.base_noise

    def state_dict(self) -> dict[str, Any]:
        return {
            "schema_version": REGISTERED_SAMPLE_SCHEMA,
            "values": self.values.detach().clone(),
            "receipt": self.receipt.state_dict(),
        }

    @classmethod
    def from_state_dict(cls, state: Mapping[str, Any]) -> RegisteredFlowSampleV2:
        if set(state) != {"schema_version", "values", "receipt"}:
            raise ValueError("registered flow sample has unexpected fields")
        if state["schema_version"] != REGISTERED_SAMPLE_SCHEMA:
            raise ValueError("unsupported registered flow sample schema")
        values = state["values"]
        receipt_state = state["receipt"]
        if not isinstance(values, torch.Tensor) or not isinstance(receipt_state, Mapping):
            raise ValueError("registered flow sample state is invalid")
        receipt = RegisteredSamplingReceiptV2.from_state_dict(receipt_state)
        if receipt.sample_index != 0:
            raise ValueError("formal registered sample must be primary index zero")
        if (
            values.shape != receipt.base_noise.shape
            or values.dtype != receipt.base_noise.dtype
            or values.device != receipt.base_noise.device
        ):
            raise ValueError("registered flow sample values are incompatible")
        _validate_serialized_torus_tensor(
            values, receipt.free_parameter_mask, "registered flow sample"
        )
        return cls(values=values, receipt=receipt)


@dataclass(frozen=True, slots=True)
class CoverageDiagnosticV2:
    samples: torch.Tensor
    receipts: tuple[RegisteredSamplingReceiptV2, ...]

    def __post_init__(self) -> None:
        if self.samples.ndim != 3 or self.samples.shape[0] != COVERAGE_DIAGNOSTIC_K:
            raise ValueError("coverage diagnostic must retain all eight samples")
        if len(self.receipts) != COVERAGE_DIAGNOSTIC_K:
            raise ValueError("coverage diagnostic must retain all eight receipts")


def _validate_sampling_inputs(
    context: torch.Tensor,
    wyckoff_id: torch.Tensor,
    free_parameter_mask: torch.Tensor,
) -> None:
    if context.ndim != 2 or context.shape[1] != FLOW_CONTEXT_DIM:
        raise ValueError("context must have shape [B,192]")
    batch_size = context.shape[0]
    if wyckoff_id.shape != (batch_size,) or wyckoff_id.dtype != torch.long:
        raise ValueError("wyckoff_id must be int64 with shape [B]")
    if free_parameter_mask.shape != (batch_size, 3) or free_parameter_mask.dtype != torch.bool:
        raise ValueError("free-parameter mask must be boolean with shape [B,3]")
    if not torch.is_floating_point(context) or not torch.isfinite(context).all():
        raise ValueError("context must be a finite floating tensor")
    if wyckoff_id.device != context.device or free_parameter_mask.device != context.device:
        raise ValueError("sampler tensors must be on the same device")


def _namespaced_generator(
    *, device: torch.device, registered_seed: int, sample_index: int
) -> torch.Generator:
    if type(registered_seed) is not int or registered_seed < 0:
        raise ValueError("registered_seed must be a non-negative integer")
    if type(sample_index) is not int or sample_index < 0:
        raise ValueError("sample_index must be a non-negative integer")
    digest = hashlib.sha256(
        f"{REGISTERED_FLOW_NAMESPACE}:{registered_seed}:{sample_index}".encode("utf-8")
    ).digest()
    derived_seed = int.from_bytes(digest[:8], "big") % (2**63 - 1)
    return torch.Generator(device=device).manual_seed(derived_seed)


def _registered_base_noise(
    template: torch.Tensor,
    free_parameter_mask: torch.Tensor,
    *,
    registered_seed: int,
    sample_index: int,
) -> torch.Tensor:
    base_noise = torch.zeros_like(template)
    active_rows = free_parameter_mask.any(dim=1)
    if bool(active_rows.any()):
        generator = _namespaced_generator(
            device=template.device,
            registered_seed=registered_seed,
            sample_index=sample_index,
        )
        active_mask = free_parameter_mask[active_rows]
        base_noise[active_rows] = torch.rand(
            (int(active_rows.sum()), 3),
            generator=generator,
            device=template.device,
            dtype=template.dtype,
        ) * active_mask.to(template.dtype)
    return base_noise


def _validate_serialized_torus_tensor(
    values: torch.Tensor,
    free_parameter_mask: torch.Tensor,
    label: str,
) -> None:
    if not torch.is_floating_point(values) or not torch.isfinite(values).all():
        raise ValueError(f"{label} must be finite and floating")
    active_values = values.masked_select(free_parameter_mask)
    if bool(((active_values < 0.0) | (active_values >= 1.0)).any()):
        raise ValueError(f"{label} active coordinates must lie in [0,1)")
    fixed_values = values.masked_select(~free_parameter_mask)
    if bool((fixed_values != 0.0).any()):
        raise ValueError(f"{label} fixed coordinates must be exactly zero")


def _sample_once(
    velocity_field: VelocityFieldV2,
    context: torch.Tensor,
    wyckoff_id: torch.Tensor,
    free_parameter_mask: torch.Tensor,
    *,
    registered_seed: int,
    sample_index: int,
) -> RegisteredFlowSampleV2:
    _validate_sampling_inputs(context, wyckoff_id, free_parameter_mask)
    batch_size = context.shape[0]
    active_rows = free_parameter_mask.any(dim=1)
    template = torch.zeros(batch_size, 3, device=context.device, dtype=context.dtype)
    base_noise = _registered_base_noise(
        template,
        free_parameter_mask,
        registered_seed=registered_seed,
        sample_index=sample_index,
    )
    values = base_noise.clone()
    velocity_evaluations = 0
    wrap_count = 0

    if bool(active_rows.any()):
        active_mask = free_parameter_mask[active_rows]
        active_values = base_noise[active_rows]
        active_context = context[active_rows]
        active_wyckoff = wyckoff_id[active_rows]
        step_size = 1.0 / REGISTERED_HEUN_STEPS
        for step in range(REGISTERED_HEUN_STEPS):
            tau = torch.full(
                (active_values.shape[0],),
                step * step_size,
                device=context.device,
                dtype=context.dtype,
            )
            start_velocity = velocity_field(
                active_values, tau, active_context, active_wyckoff, active_mask
            )
            velocity_evaluations += 1
            if start_velocity.shape != active_values.shape or not torch.isfinite(
                start_velocity
            ).all():
                raise FloatingPointError("non-finite flow velocity")
            predictor = wrap_torus_tensor(
                active_values + step_size * start_velocity, active_mask
            )
            wrap_count += 1
            end_tau = torch.full_like(tau, (step + 1) * step_size)
            end_velocity = velocity_field(
                predictor, end_tau, active_context, active_wyckoff, active_mask
            )
            velocity_evaluations += 1
            if end_velocity.shape != active_values.shape or not torch.isfinite(
                end_velocity
            ).all():
                raise FloatingPointError("non-finite flow velocity")
            active_values = wrap_torus_tensor(
                active_values + 0.5 * step_size * (start_velocity + end_velocity),
                active_mask,
            )
            wrap_count += 1
        values[active_rows] = active_values

    zero_dof = tuple(bool(value) for value in (~active_rows).tolist())
    reason_codes = tuple(
        (ZERO_DOF_BYPASS,) if bypass else () for bypass in zero_dof
    )
    receipt = RegisteredSamplingReceiptV2(
        registered_seed=registered_seed,
        sample_index=sample_index,
        namespace=REGISTERED_FLOW_NAMESPACE,
        sample_count=1,
        integration_steps=REGISTERED_HEUN_STEPS if bool(active_rows.any()) else 0,
        velocity_evaluations=velocity_evaluations,
        wrap_count=wrap_count,
        zero_dof_bypass=zero_dof,
        reason_codes=reason_codes,
        base_noise=base_noise,
        free_parameter_mask=free_parameter_mask,
    )
    return RegisteredFlowSampleV2(values=values, receipt=receipt)


def sample_registered_toroidal_flow(
    velocity_field: VelocityFieldV2,
    context: torch.Tensor,
    wyckoff_id: torch.Tensor,
    free_parameter_mask: torch.Tensor,
    *,
    registered_seed: int,
) -> RegisteredFlowSampleV2:
    """Return the sole registered K=1 formal flow sample."""
    return _sample_once(
        velocity_field,
        context,
        wyckoff_id,
        free_parameter_mask,
        registered_seed=registered_seed,
        sample_index=0,
    )


def sample_coverage_diagnostic_toroidal_flow(
    velocity_field: VelocityFieldV2,
    context: torch.Tensor,
    wyckoff_id: torch.Tensor,
    free_parameter_mask: torch.Tensor,
    *,
    registered_seed: int,
) -> CoverageDiagnosticV2:
    """Return all K=8 learned samples; this API has no selection operation."""
    samples = tuple(
        _sample_once(
            velocity_field,
            context,
            wyckoff_id,
            free_parameter_mask,
            registered_seed=registered_seed,
            sample_index=index,
        )
        for index in range(COVERAGE_DIAGNOSTIC_K)
    )
    return CoverageDiagnosticV2(
        samples=torch.stack([sample.values for sample in samples]),
        receipts=tuple(sample.receipt for sample in samples),
    )


__all__ = [
    "COVERAGE_DIAGNOSTIC_K",
    "REGISTERED_FLOW_NAMESPACE",
    "REGISTERED_HEUN_STEPS",
    "REGISTERED_SAMPLE_SCHEMA",
    "CoverageDiagnosticV2",
    "RegisteredFlowSampleV2",
    "RegisteredSamplingReceiptV2",
    "VelocityFieldV2",
    "sample_coverage_diagnostic_toroidal_flow",
    "sample_registered_toroidal_flow",
    "wrap_torus_tensor",
]
