from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass

from .relation_interface import validate_train_fit_input_fields


TEACHER_STATE = "TEACHER_STATE"
MODEL_REALIZED_UNROLL = "MODEL_REALIZED_UNROLL"
_EVENT_FIELDS = frozenset(
    {"event_id", "source_split", "condition", "equivalent_targets"}
)


def _validate_nested_fields(value: object) -> None:
    if isinstance(value, Mapping):
        validate_train_fit_input_fields(value.keys())
        for field_name, nested in value.items():
            if field_name in {"split", "source_split", "dataset_split"} and nested != "train_fit":
                raise ValueError("nested training provenance must remain train_fit")
            _validate_nested_fields(nested)
    elif isinstance(value, (tuple, list)):
        for nested in value:
            _validate_nested_fields(nested)


@dataclass(frozen=True, slots=True)
class TrainFitEventV2:
    event_id: str
    source_split: str
    condition: Mapping[str, object]
    equivalent_targets: tuple[tuple[float, ...], ...]

    def __post_init__(self) -> None:
        if not self.event_id:
            raise ValueError("train-fit event ID must be non-empty")
        if self.source_split != "train_fit":
            raise ValueError("Geometry V2 training events must come from train_fit")
        _validate_nested_fields(self.condition)
        if not self.equivalent_targets:
            raise ValueError("train-fit event requires at least one observed mode")
        width = len(self.equivalent_targets[0])
        if not 0 <= width <= 3 or any(
            len(target) != width for target in self.equivalent_targets
        ):
            raise ValueError("equivalent train-fit targets must have one DOF width in [0,3]")


def adapt_train_fit_event(payload: Mapping[str, object]) -> TrainFitEventV2:
    validate_train_fit_input_fields(payload.keys())
    unexpected = sorted(set(payload) - _EVENT_FIELDS)
    missing = sorted(_EVENT_FIELDS - set(payload))
    if unexpected:
        raise ValueError(
            "forbidden train-fit event fields: " + ", ".join(unexpected)
        )
    if missing:
        raise ValueError("missing train-fit event fields: " + ", ".join(missing))
    condition = payload["condition"]
    targets = payload["equivalent_targets"]
    if not isinstance(condition, Mapping):
        raise TypeError("train-fit condition must be a mapping")
    if not isinstance(targets, (tuple, list)):
        raise TypeError("equivalent targets must be a sequence")
    normalized_targets = tuple(
        tuple(float(value) for value in target)  # type: ignore[arg-type]
        for target in targets
    )
    return TrainFitEventV2(
        event_id=str(payload["event_id"]),
        source_split=str(payload["source_split"]),
        condition=condition,
        equivalent_targets=normalized_targets,
    )


@dataclass(frozen=True, slots=True)
class TrainFitBatchV2:
    batch_index: int
    events: tuple[TrainFitEventV2, ...]
    state_modes: tuple[str, ...]
    max_unroll_steps: int

    def __post_init__(self) -> None:
        if len(self.events) != len(self.state_modes) or not self.events:
            raise ValueError("train-fit events and state modes must align")
        if self.state_modes.count(TEACHER_STATE) != self.state_modes.count(
            MODEL_REALIZED_UNROLL
        ):
            raise ValueError("teacher and model-realized state modes must be 1:1")
        if any(event.source_split != "train_fit" for event in self.events):
            raise ValueError("non-train-fit event entered a training batch")
        if self.max_unroll_steps not in (2, 3, 4):
            raise ValueError("model-realized unroll length must be frozen in [2,4]")


def build_tiny_smoke_train_fit_batches(
    events: Sequence[TrainFitEventV2], *, batch_size: int
) -> tuple[TrainFitBatchV2, ...]:
    if type(batch_size) is not int or batch_size <= 0 or batch_size % 2:
        raise ValueError("tiny-smoke train-fit batch size must be positive and even")
    if batch_size > 128:
        raise ValueError("tiny-smoke train-fit batch size cannot exceed 128")
    if not events or len(events) > 128:
        raise ValueError("tiny-smoke builder requires 1 through 128 train-fit events")
    if len(events) % batch_size:
        raise ValueError("train-fit events must fill complete fixed batches")
    if len({event.event_id for event in events}) != len(events):
        raise ValueError("train-fit event IDs must be unique")
    modes = tuple(
        TEACHER_STATE if index % 2 == 0 else MODEL_REALIZED_UNROLL
        for index in range(batch_size)
    )
    batches = []
    for batch_index, offset in enumerate(range(0, len(events), batch_size)):
        batches.append(
            TrainFitBatchV2(
                batch_index=batch_index,
                events=tuple(events[offset : offset + batch_size]),
                state_modes=modes,
                max_unroll_steps=2 + (batch_index % 3),
            )
        )
    return tuple(batches)


__all__ = [
    "MODEL_REALIZED_UNROLL",
    "TEACHER_STATE",
    "TrainFitBatchV2",
    "TrainFitEventV2",
    "adapt_train_fit_event",
    "build_tiny_smoke_train_fit_batches",
]
