from __future__ import annotations

import torch
from torch import nn

from crysalis_g1.geometry_v2.relation_interface import GeometryConditionV2


GEOMETRY_CONTEXT_DIM = 192


def _masked_mean(values: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    weights = mask.unsqueeze(-1).to(device=values.device, dtype=values.dtype)
    return (values * weights).sum(dim=1) / weights.sum(dim=1).clamp_min(1.0)


class GeometryContextEncoderV2(nn.Module):
    """Masked orbit-level relation/memory encoder for the downstream flow."""

    def __init__(self) -> None:
        super().__init__()
        self.edge_encoder = nn.Sequential(nn.Linear(66, 32), nn.SiLU())
        self.orbit_encoder = nn.Sequential(nn.Linear(128, 64), nn.SiLU())
        self.triplet_encoder = nn.Sequential(nn.Linear(19, 48), nn.SiLU())
        self.global_encoder = nn.Sequential(nn.Linear(225, 64), nn.SiLU())
        self.output = nn.Linear(64 + 48 + 64, GEOMETRY_CONTEXT_DIM)

    def forward(self, condition: GeometryConditionV2) -> torch.Tensor:
        if not isinstance(condition, GeometryConditionV2):
            raise TypeError("context encoder requires sanitized GeometryConditionV2")
        graph = condition.active_orbit_graph
        relation = condition.relation
        device = condition.composition.device
        dtype = condition.composition.dtype
        memory = condition.persistent_memory.tensorize()

        edge_relation = torch.cat(
            (
                relation.edge_presence_logit,
                relation.edge_distance,
                relation.edge_direction_fourier,
                relation.edge_direction_log_scale,
                relation.edge_shell_logits,
                relation.edge_coordination,
                relation.edge_latent,
            ),
            dim=-1,
        ).to(device=device, dtype=dtype)
        edge_input = torch.cat(
            (edge_relation, memory.edge.to(device=device, dtype=dtype)), dim=-1
        )
        edge_message = self.edge_encoder(edge_input)
        edge_message = edge_message * graph.edge_mask.to(device).unsqueeze(-1)

        batch_size, orbit_count = graph.active_orbits.shape[:2]
        orbit_messages = edge_message.new_zeros(batch_size, orbit_count, 32)
        if orbit_count and graph.edge_count:
            safe_index = graph.edge_index.to(device).clamp(0, orbit_count - 1)
            orbit_messages.scatter_add_(
                1, safe_index.unsqueeze(-1).expand_as(edge_message), edge_message
            )
        orbit_input = torch.cat(
            (
                graph.active_orbits.to(device=device, dtype=dtype),
                memory.orbit.to(device=device, dtype=dtype),
                orbit_messages,
            ),
            dim=-1,
        )
        orbit_state = self.orbit_encoder(orbit_input)
        orbit_pool = _masked_mean(
            orbit_state, graph.active_orbit_mask.to(device=device)
        )

        triplet_relation = torch.cat(
            (
                relation.triplet_angle,
                relation.triplet_presence_logit,
                relation.triplet_latent,
            ),
            dim=-1,
        ).to(device=device, dtype=dtype)
        triplet_state = self.triplet_encoder(triplet_relation)
        triplet_pool = _masked_mean(
            triplet_state, graph.triplet_mask.to(device=device)
        )

        global_input = torch.cat(
            (
                condition.composition,
                condition.candidate_query.to(device=device, dtype=dtype),
                condition.lattice.to(device=device, dtype=dtype).flatten(1),
                memory.global_memory.to(device=device, dtype=dtype),
                condition.target_sg.to(device=device, dtype=dtype).unsqueeze(-1)
                / 230.0,
            ),
            dim=-1,
        )
        global_state = self.global_encoder(global_input)
        return self.output(torch.cat((orbit_pool, triplet_pool, global_state), dim=-1))


__all__ = ["GEOMETRY_CONTEXT_DIM", "GeometryContextEncoderV2"]
