from __future__ import annotations

import hashlib
import itertools
import math
from dataclasses import dataclass
from typing import Sequence

import torch

from crysalis_g1.full_crysalis.data import (
    IntegratedEvent,
    RelationNormalizer,
    collate_integrated_events,
)
from crysalis_g1.symmetry.assembly import SymmetryAssemblyState

from .endpoint import _state_with_candidate_sample
from .losses import flow_matching_loss
from .memory import PersistentRelationMemoryV2
from .model import FormalGeometryV2Model
from .phase2a_adapter import (
    MAXIMUM_ACTIVE_ORBITS_V2,
    MAXIMUM_RELATION_EDGES_V2,
    MAXIMUM_RELATION_TRIPLETS_V2,
    Phase2ASupervisionV2,
    _assembly_state,
    _candidate_metric,
    _candidate_seed_feature,
    _orbit_feature,
    _relation_targets,
    _wyckoff_index,
)
from .production_config import CHECKPOINT_SELECTION_FIELDS_V2
from .production_losses import (
    LossScaleNormalizerV2,
    _flow_endpoint_metric,
    _relation_losses,
)
from .relation_interface import (
    ActiveOrbitGraphV2,
    RelationInputProvenanceV2,
    RelationModelInputV2,
)
from .sampler import sample_registered_toroidal_flow
from .training import structure_ood_checkpoint_composite
from .training_batch import build_flow_matching_batch
from crysalis_g1.symmetry.wyckoff import orbit_representative_fractional_coordinate


@dataclass(frozen=True, slots=True)
class StructureOODValidationResultV2:
    metrics: dict[str, float]
    composite: float
    event_count: int
    nonterminal_event_count: int
    terminal_event_count: int
    registered_seed_root: int
    source_split: str = "validation"


@dataclass(frozen=True, slots=True)
class _ValidationBatchV2:
    model_input: RelationModelInputV2
    supervision: Phase2ASupervisionV2
    events: tuple[IntegratedEvent, ...]


def _validation_batch(
    events: Sequence[IntegratedEvent],
    *,
    normalizer: RelationNormalizer,
    device: torch.device,
    shell_boundaries_angstrom: tuple[float, float, float],
) -> _ValidationBatchV2:
    if not events or any(event.split != "validation" or event.terminal for event in events):
        raise ValueError("validation tensor batch requires nonterminal validation events")
    integrated = collate_integrated_events(
        events, normalizer=normalizer, maximum_orbits=MAXIMUM_ACTIVE_ORBITS_V2
    )
    batch_size = len(events)
    active_features = torch.zeros(batch_size, MAXIMUM_ACTIVE_ORBITS_V2, 64)
    active_mask = torch.zeros(batch_size, MAXIMUM_ACTIVE_ORBITS_V2, dtype=torch.bool)
    edge_index = torch.zeros(batch_size, MAXIMUM_RELATION_EDGES_V2, dtype=torch.long)
    edge_mask = torch.zeros(batch_size, MAXIMUM_RELATION_EDGES_V2, dtype=torch.bool)
    triplet_index = torch.zeros(
        batch_size, MAXIMUM_RELATION_TRIPLETS_V2, 2, dtype=torch.long
    )
    triplet_mask = torch.zeros(
        batch_size, MAXIMUM_RELATION_TRIPLETS_V2, dtype=torch.bool
    )
    candidate_query = torch.zeros(batch_size, 64)
    targets: list[torch.Tensor] = []
    masks: list[torch.Tensor] = []
    metrics: list[torch.Tensor] = []
    states: list[SymmetryAssemblyState] = []
    relation_rows = []
    for row, event in enumerate(events):
        for slot, orbit in enumerate(event.active_orbits):
            active_features[row, slot] = _orbit_feature(
                species=orbit.species,
                wyckoff_index=_wyckoff_index(orbit.wyckoff_letter),
                multiplicity=orbit.multiplicity,
                free_parameters=orbit.free_parameters,
                representative=orbit_representative_fractional_coordinate(orbit),
                progress=event.progress,
                candidate=False,
                pooled_relation=event.pooled_relation,
                physics_feedback=event.physics_feedback,
            )
            active_mask[row, slot] = True
            edge_index[row, slot] = slot
            edge_mask[row, slot] = True
        candidate_slot = len(event.active_orbits)
        seed_feature = _candidate_seed_feature(event)
        active_features[row, candidate_slot] = seed_feature
        active_mask[row, candidate_slot] = True
        candidate_query[row] = seed_feature
        for slot, pair in enumerate(itertools.combinations(range(candidate_slot), 2)):
            triplet_index[row, slot] = torch.tensor(pair)
            triplet_mask[row, slot] = True
        candidate = event.candidate_orbit
        assert candidate is not None
        target = torch.zeros(3)
        mask = torch.zeros(3, dtype=torch.bool)
        target[: len(candidate.free_parameters)] = torch.tensor(candidate.free_parameters)
        mask[: len(candidate.free_parameters)] = True
        state = _assembly_state(event)
        targets.append(target)
        masks.append(mask)
        states.append(state)
        metrics.append(_candidate_metric(state))
        relation_rows.append(
            _relation_targets(
                event,
                shell_boundaries_angstrom=shell_boundaries_angstrom,
            )
        )
    graph = ActiveOrbitGraphV2(
        active_features.to(device),
        active_mask.to(device),
        edge_index.to(device),
        edge_mask.to(device),
        triplet_index.to(device),
        triplet_mask.to(device),
    )
    model_input = RelationModelInputV2.from_mapping(
        {
            "composition": integrated.composition.to(device),
            "target_sg": integrated.target_space_group.to(device),
            "lattice": integrated.lattice.to(device),
            "active_orbit_graph": graph,
            "candidate_query": candidate_query.to(device),
            "persistent_memory": PersistentRelationMemoryV2.empty(
                batch_size,
                MAXIMUM_ACTIVE_ORBITS_V2,
                MAXIMUM_RELATION_EDGES_V2,
                device=device,
            ),
        },
        provenance=RelationInputProvenanceV2("current_generation_state"),
    )
    stacked = tuple(zip(*relation_rows, strict=True))
    supervision = Phase2ASupervisionV2(
        equivalent_targets=torch.stack(targets).unsqueeze(1).to(device),
        free_parameter_mask=torch.stack(masks).to(device),
        induced_metric=torch.stack(metrics).to(device),
        wyckoff_id=integrated.candidate_wyckoff.to(device),
        edge_presence=torch.stack(stacked[0]).to(device),
        edge_distance=torch.stack(stacked[1]).to(device),
        edge_direction_fourier=torch.stack(stacked[2]).to(device),
        edge_shell=torch.stack(stacked[3]).to(device),
        edge_coordination=torch.stack(stacked[4]).to(device),
        triplet_presence=torch.stack(stacked[5]).to(device),
        triplet_cosine=torch.stack(stacked[6]).to(device),
        states=tuple(states),
    )
    return _ValidationBatchV2(model_input, supervision, tuple(events))


def _event_seed(root: int, event_key: str) -> int:
    digest = hashlib.sha256(f"{root}:{event_key}".encode()).digest()
    return int.from_bytes(digest[:8], "big") % (2**63 - 1)


def _terminal_state(event: IntegratedEvent) -> SymmetryAssemblyState:
    return SymmetryAssemblyState(
        target_space_group=event.target_space_group,
        composition=event.composition,
        remaining_composition=(),
        lattice=event.lattice,
        orbits=event.active_orbits,
        terminated=True,
    )


def run_structure_ood_validation_v2(
    *,
    model: FormalGeometryV2Model,
    events: Sequence[IntegratedEvent],
    relation_normalizer: RelationNormalizer,
    loss_normalizer: LossScaleNormalizerV2,
    projector: object,
    device: str | torch.device,
    batch_size: int,
    registered_seed_root: int,
    shell_boundaries_angstrom: tuple[float, float, float],
    expected_event_count: int = 2957,
) -> StructureOODValidationResultV2:
    frozen_events = tuple(events)
    if len(frozen_events) != expected_event_count:
        raise ValueError("validation event count differs from the frozen contract")
    if any(event.split != "validation" for event in frozen_events):
        raise ValueError("structure-OOD callback accepts validation split only")
    if type(batch_size) is not int or batch_size <= 0:
        raise ValueError("validation batch size must be positive")
    if len(shell_boundaries_angstrom) != 3 or not all(
        left < right
        for left, right in zip(
            shell_boundaries_angstrom,
            shell_boundaries_angstrom[1:],
        )
    ):
        raise ValueError("validation shell boundaries must be three increasing values")
    torch_device = torch.device(device)
    was_training = model.training
    model.eval()
    nonterminal = tuple(event for event in frozen_events if not event.terminal)
    terminal = tuple(event for event in frozen_events if event.terminal)
    flow_sum = relation_sum = local_sum = 0.0
    legality_failures = 0
    try:
        with torch.inference_mode():
            for offset in range(0, len(nonterminal), batch_size):
                subset = nonterminal[offset : offset + batch_size]
                built = _validation_batch(
                    subset,
                    normalizer=relation_normalizer,
                    device=torch_device,
                    shell_boundaries_angstrom=shell_boundaries_angstrom,
                )
                model_input, prediction, context = model.condition(built.model_input)
                base_rows = []
                tau_rows = []
                for event in subset:
                    generator = torch.Generator(device=torch_device).manual_seed(
                        _event_seed(registered_seed_root, event.event_key)
                    )
                    base_rows.append(torch.rand(3, generator=generator, device=torch_device))
                    tau_rows.append(torch.rand((), generator=generator, device=torch_device))
                flow_generator = torch.Generator(device=torch_device).manual_seed(
                    registered_seed_root + offset
                )
                flow_batch = build_flow_matching_batch(
                    base_noise=torch.stack(base_rows),
                    equivalent_targets=built.supervision.equivalent_targets,
                    free_parameter_mask=built.supervision.free_parameter_mask,
                    generator=flow_generator,
                    tau=torch.stack(tau_rows),
                    metric=built.supervision.induced_metric,
                )
                velocity = model.flow(
                    flow_batch.u_tau,
                    flow_batch.tau,
                    context,
                    built.supervision.wyckoff_id,
                    built.supervision.free_parameter_mask,
                )
                relation, local, _ = _relation_losses(
                    prediction, built.supervision, model_input.active_orbit_graph
                )
                endpoint_proxy = torch.remainder(
                    flow_batch.u_tau
                    + (1.0 - flow_batch.tau).unsqueeze(-1) * velocity,
                    1.0,
                )
                local = local + _flow_endpoint_metric(
                    endpoint_proxy,
                    flow_batch.selected_target,
                    built.supervision.free_parameter_mask,
                    flow_batch.metric,
                )
                count = len(subset)
                flow_sum += float(flow_matching_loss(velocity, flow_batch).cpu()) * count
                relation_sum += float(relation.cpu()) * count
                local_sum += float(local.cpu()) * count
                for row, event in enumerate(subset):
                    seed = _event_seed(registered_seed_root, event.event_key)
                    sampled = sample_registered_toroidal_flow(
                        model.flow,
                        context[row : row + 1],
                        built.supervision.wyckoff_id[row : row + 1],
                        built.supervision.free_parameter_mask[row : row + 1],
                        registered_seed=seed,
                    )
                    state = _state_with_candidate_sample(
                        built.supervision.states[row],
                        sampled.values,
                        built.supervision.free_parameter_mask[row : row + 1],
                        int(built.supervision.free_parameter_mask[row].sum()),
                    )
                    receipt = projector.project(state)
                    legality_failures += int(getattr(receipt, "accepted", False) is not True)
            for event in terminal:
                receipt = projector.project(_terminal_state(event))
                legality_failures += int(getattr(receipt, "accepted", False) is not True)
    finally:
        model.train(was_training)
    if not nonterminal:
        raise ValueError("frozen structure-OOD validation contains no geometry events")
    metrics = {
        "normalized_flow_loss": flow_sum
        / len(nonterminal)
        / float(loss_normalizer.scales["flow"]),
        "normalized_final_relation_nll": relation_sum
        / len(nonterminal)
        / float(loss_normalizer.scales["relation_realization"]),
        "normalized_local_metric_error": local_sum
        / len(nonterminal)
        / float(loss_normalizer.scales["local_metric"]),
        "legality_penalty": legality_failures / len(frozen_events),
    }
    if tuple(metrics) != CHECKPOINT_SELECTION_FIELDS_V2 or not all(
        math.isfinite(value) for value in metrics.values()
    ):
        raise FloatingPointError("structure-OOD validation metrics are invalid")
    return StructureOODValidationResultV2(
        metrics=metrics,
        composite=structure_ood_checkpoint_composite(metrics),
        event_count=len(frozen_events),
        nonterminal_event_count=len(nonterminal),
        terminal_event_count=len(terminal),
        registered_seed_root=int(registered_seed_root),
    )


__all__ = ["StructureOODValidationResultV2", "run_structure_ood_validation_v2"]
