from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass

import torch


MEMORY_SCHEMA_VERSION = "crysalis-geometry-v2-relation-memory.1"


def _validate_finite_tensor(
    name: str,
    value: torch.Tensor,
    shape: tuple[int, ...],
) -> None:
    if value.shape != shape:
        raise ValueError(f"{name} must have shape {shape}")
    if not (value.is_floating_point() and bool(torch.isfinite(value).all())):
        raise ValueError(f"{name} must be a finite floating-point tensor")


def _masked_mean(values: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    weights = mask.unsqueeze(-1).to(values.dtype)
    return (values * weights).sum(dim=1) / weights.sum(dim=1).clamp_min(1.0)


@dataclass(frozen=True, slots=True)
class RefinementReceiptV2:
    accepted_steps: tuple[int, ...]
    trust_region_contractions: tuple[int, ...]
    final_joint_objectives: tuple[float, ...]

    def __post_init__(self) -> None:
        batch_size = len(self.accepted_steps)
        if len(self.trust_region_contractions) != batch_size or len(
            self.final_joint_objectives
        ) != batch_size:
            raise ValueError("refinement receipt fields must share one batch size")
        if any(type(value) is not int or value < 0 for value in self.accepted_steps):
            raise ValueError("accepted steps must be non-negative integers")
        if any(
            type(value) is not int or value < 0
            for value in self.trust_region_contractions
        ):
            raise ValueError("trust-region contractions must be non-negative integers")
        if any(not math.isfinite(float(value)) for value in self.final_joint_objectives):
            raise ValueError("final joint objectives must be finite")


@dataclass(frozen=True, slots=True)
class MemoryUpdateReceiptV2:
    previous_state_hash: str
    next_state_hash: str
    base_latent_namespaces: tuple[str, ...]
    refinement_receipt: RefinementReceiptV2

    def __post_init__(self) -> None:
        if len(self.previous_state_hash) != 64 or len(self.next_state_hash) != 64:
            raise ValueError("memory receipt hashes must be SHA-256 digests")
        if not all(self.base_latent_namespaces):
            raise ValueError("base latent namespaces must be non-empty")


@dataclass(frozen=True, slots=True)
class MemoryTensorizationV2:
    orbit: torch.Tensor
    edge: torch.Tensor
    global_memory: torch.Tensor

    def __post_init__(self) -> None:
        if self.orbit.ndim != 3 or self.orbit.shape[-1] != 32:
            raise ValueError("orbit memory must have shape [B,N,32]")
        if self.edge.ndim != 3 or self.edge.shape[-1] != 16:
            raise ValueError("edge memory must have shape [B,E,16]")
        if self.global_memory.shape != (self.orbit.shape[0], 32):
            raise ValueError("global memory must have shape [B,32]")
        if self.edge.shape[0] != self.orbit.shape[0]:
            raise ValueError("memory tensors must share one batch size")
        for name, value in (
            ("orbit memory", self.orbit),
            ("edge memory", self.edge),
            ("global memory", self.global_memory),
        ):
            if not (value.is_floating_point() and bool(torch.isfinite(value).all())):
                raise ValueError(f"{name} must be finite and floating point")
        object.__setattr__(self, "orbit", self.orbit.detach().clone())
        object.__setattr__(self, "edge", self.edge.detach().clone())
        object.__setattr__(
            self, "global_memory", self.global_memory.detach().clone()
        )


@dataclass(frozen=True, slots=True)
class PersistentRelationMemoryV2:
    _orbit: torch.Tensor
    _edge: torch.Tensor
    _global_memory: torch.Tensor

    def __post_init__(self) -> None:
        snapshot = MemoryTensorizationV2(
            orbit=self._orbit,
            edge=self._edge,
            global_memory=self._global_memory,
        )
        object.__setattr__(self, "_orbit", snapshot.orbit)
        object.__setattr__(self, "_edge", snapshot.edge)
        object.__setattr__(self, "_global_memory", snapshot.global_memory)

    @classmethod
    def from_tensors(
        cls,
        *,
        orbit: torch.Tensor,
        edge: torch.Tensor,
        global_memory: torch.Tensor,
    ) -> PersistentRelationMemoryV2:
        """Build persistent state from an explicitly shaped tensor snapshot."""
        return cls(_orbit=orbit, _edge=edge, _global_memory=global_memory)

    @classmethod
    def empty(
        cls,
        batch_size: int,
        max_orbits: int,
        max_edges: int,
        *,
        dtype: torch.dtype = torch.float32,
        device: torch.device | str | None = None,
    ) -> PersistentRelationMemoryV2:
        if type(batch_size) is not int or batch_size <= 0:
            raise ValueError("memory batch size must be a positive integer")
        if type(max_orbits) is not int or max_orbits < 0:
            raise ValueError("maximum orbit count must be a non-negative integer")
        if type(max_edges) is not int or max_edges < 0:
            raise ValueError("maximum edge count must be a non-negative integer")
        if not dtype.is_floating_point:
            raise ValueError("memory dtype must be floating point")
        return cls(
            _orbit=torch.zeros(
                batch_size, max_orbits, 32, dtype=dtype, device=device
            ),
            _edge=torch.zeros(batch_size, max_edges, 16, dtype=dtype, device=device),
            _global_memory=torch.zeros(batch_size, 32, dtype=dtype, device=device),
        )

    @property
    def batch_size(self) -> int:
        return self._orbit.shape[0]

    @property
    def max_orbits(self) -> int:
        return self._orbit.shape[1]

    @property
    def max_edges(self) -> int:
        return self._edge.shape[1]

    def tensorize(self) -> MemoryTensorizationV2:
        """Return a detached snapshot so callers cannot mutate persistent state."""
        return MemoryTensorizationV2(
            orbit=self._orbit,
            edge=self._edge,
            global_memory=self._global_memory,
        )

    def state_hash(self) -> str:
        digest = hashlib.sha256(MEMORY_SCHEMA_VERSION.encode("utf-8"))
        for value in (self._orbit, self._edge, self._global_memory):
            snapshot = value.detach().cpu().contiguous()
            digest.update(str(snapshot.dtype).encode("ascii"))
            digest.update(str(tuple(snapshot.shape)).encode("ascii"))
            digest.update(snapshot.numpy().tobytes())
        return digest.hexdigest()

    def update(
        self,
        *,
        active_orbit_mask: torch.Tensor,
        edge_mask: torch.Tensor,
        realized_edge_state: torch.Tensor,
        relation_residual: torch.Tensor,
        accepted_u: torch.Tensor,
        flow_uncertainty: torch.Tensor,
        projected_force_residual: torch.Tensor,
        mode_history: torch.Tensor,
        refinement_receipt: RefinementReceiptV2,
        base_latent_namespaces: tuple[str, ...],
    ) -> tuple[PersistentRelationMemoryV2, MemoryUpdateReceiptV2]:
        batch_size, orbit_count, edge_count = (
            self.batch_size,
            self.max_orbits,
            self.max_edges,
        )
        if active_orbit_mask.shape != (batch_size, orbit_count) or (
            active_orbit_mask.dtype is not torch.bool
        ):
            raise ValueError("active orbit mask must be boolean [B,N]")
        if edge_mask.shape != (batch_size, edge_count) or edge_mask.dtype is not torch.bool:
            raise ValueError("edge mask must be boolean [B,E]")
        if len(base_latent_namespaces) != batch_size or not all(
            base_latent_namespaces
        ):
            raise ValueError("one non-empty base latent namespace is required per batch")
        if len(refinement_receipt.accepted_steps) != batch_size:
            raise ValueError("refinement receipt batch size mismatch")

        expected = (
            ("realized edge state", realized_edge_state, (batch_size, edge_count, 14)),
            ("relation residual", relation_residual, (batch_size, edge_count, 2)),
            ("accepted u", accepted_u, (batch_size, orbit_count, 3)),
            ("flow uncertainty", flow_uncertainty, (batch_size, orbit_count, 1)),
            (
                "projected force residual",
                projected_force_residual,
                (batch_size, orbit_count, 3),
            ),
            ("mode history", mode_history, (batch_size, orbit_count, 3)),
        )
        for name, value, shape in expected:
            _validate_finite_tensor(name, value, shape)

        device, dtype = self._orbit.device, self._orbit.dtype
        orbit_mask = active_orbit_mask.to(device=device)
        relation_mask = edge_mask.to(device=device)

        def normalized(value: torch.Tensor) -> torch.Tensor:
            return value.to(device=device, dtype=dtype)

        orbit_values = torch.cat(
            (
                normalized(accepted_u),
                normalized(flow_uncertainty),
                normalized(projected_force_residual),
                normalized(mode_history),
            ),
            dim=-1,
        )
        orbit_values = torch.cat(
            (
                orbit_values,
                torch.zeros(
                    batch_size,
                    orbit_count,
                    22,
                    device=device,
                    dtype=dtype,
                ),
            ),
            dim=-1,
        )
        orbit_values = orbit_values * orbit_mask.unsqueeze(-1).to(dtype)
        edge_values = torch.cat(
            (normalized(realized_edge_state), normalized(relation_residual)), dim=-1
        )
        edge_values = edge_values * relation_mask.unsqueeze(-1).to(dtype)

        orbit_summary = _masked_mean(orbit_values[..., :10], orbit_mask)
        edge_summary = _masked_mean(edge_values, relation_mask)
        refinement = torch.tensor(
            list(
                zip(
                    refinement_receipt.accepted_steps,
                    refinement_receipt.trust_region_contractions,
                    refinement_receipt.final_joint_objectives,
                    strict=True,
                )
            ),
            device=device,
            dtype=dtype,
        )
        namespace_values = torch.tensor(
            [
                int.from_bytes(hashlib.sha256(value.encode()).digest()[:8], "big")
                / float(2**64 - 1)
                for value in base_latent_namespaces
            ],
            device=device,
            dtype=dtype,
        ).unsqueeze(-1)
        counts = torch.stack(
            (orbit_mask.sum(dim=1), relation_mask.sum(dim=1)), dim=-1
        ).to(dtype)
        global_memory = torch.cat(
            (edge_summary, orbit_summary, refinement, namespace_values, counts), dim=-1
        )
        updated = PersistentRelationMemoryV2(
            _orbit=orbit_values,
            _edge=edge_values,
            _global_memory=global_memory,
        )
        receipt = MemoryUpdateReceiptV2(
            previous_state_hash=self.state_hash(),
            next_state_hash=updated.state_hash(),
            base_latent_namespaces=tuple(base_latent_namespaces),
            refinement_receipt=refinement_receipt,
        )
        return updated, receipt


__all__ = [
    "MEMORY_SCHEMA_VERSION",
    "MemoryTensorizationV2",
    "MemoryUpdateReceiptV2",
    "PersistentRelationMemoryV2",
    "RefinementReceiptV2",
]
