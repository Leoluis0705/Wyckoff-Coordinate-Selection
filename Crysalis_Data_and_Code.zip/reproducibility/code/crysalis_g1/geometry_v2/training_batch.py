from __future__ import annotations

from dataclasses import dataclass

import torch


FLOW_METRIC_EPSILON = 1.0e-6


def _validate_mask(mask: torch.Tensor) -> None:
    if mask.ndim != 2 or mask.shape[1] != 3 or mask.dtype != torch.bool:
        raise ValueError("free-parameter mask must be boolean with shape [B,3]")


def _validate_finite(tensor: torch.Tensor, label: str) -> None:
    if not torch.isfinite(tensor).all():
        raise ValueError(f"{label} must be finite")


def induced_cartesian_metric(
    free_parameter_mask: torch.Tensor,
    *,
    jacobian: torch.Tensor | None = None,
    metric: torch.Tensor | None = None,
    epsilon: float = FLOW_METRIC_EPSILON,
) -> torch.Tensor:
    """Build trace-normalized J^T J, or normalize a supplied metric."""
    _validate_mask(free_parameter_mask)
    if jacobian is not None and metric is not None:
        raise ValueError("provide jacobian or metric, not both")
    batch_size = free_parameter_mask.shape[0]
    if jacobian is not None:
        if jacobian.ndim != 3 or jacobian.shape[0] != batch_size or jacobian.shape[2] != 3:
            raise ValueError("jacobian must have shape [B,3M,3]")
        _validate_finite(jacobian, "jacobian")
        raw_metric = jacobian.transpose(1, 2) @ jacobian
        diagonal = torch.diag_embed(
            free_parameter_mask.to(device=jacobian.device, dtype=jacobian.dtype)
        )
        raw_metric = raw_metric + float(epsilon) * diagonal
    elif metric is not None:
        if metric.shape != (batch_size, 3, 3):
            raise ValueError("metric must have shape [B,3,3]")
        _validate_finite(metric, "metric")
        raw_metric = metric
    else:
        raw_metric = torch.diag_embed(free_parameter_mask.to(dtype=torch.float32))

    mask = free_parameter_mask.to(device=raw_metric.device, dtype=raw_metric.dtype)
    raw_metric = raw_metric * mask.unsqueeze(1) * mask.unsqueeze(2)
    degrees = mask.sum(dim=1)
    trace = raw_metric.diagonal(dim1=-2, dim2=-1).sum(dim=1)
    scale = trace / degrees.clamp_min(1.0) + float(epsilon)
    normalized = raw_metric / scale[:, None, None]
    return normalized * (degrees > 0).to(normalized.dtype)[:, None, None]


@dataclass(frozen=True, slots=True)
class FlowMatchingBatchV2:
    base_noise: torch.Tensor
    selected_target: torch.Tensor
    selected_equivalence_index: torch.Tensor
    tau: torch.Tensor
    u_tau: torch.Tensor
    target_velocity: torch.Tensor
    free_parameter_mask: torch.Tensor
    metric: torch.Tensor

    def __post_init__(self) -> None:
        _validate_mask(self.free_parameter_mask)
        batch_size = self.free_parameter_mask.shape[0]
        for label, tensor in (
            ("base_noise", self.base_noise),
            ("selected_target", self.selected_target),
            ("u_tau", self.u_tau),
            ("target_velocity", self.target_velocity),
        ):
            if tensor.shape != (batch_size, 3):
                raise ValueError(f"{label} must have shape [B,3]")
            _validate_finite(tensor, label)
        if self.selected_equivalence_index.shape != (batch_size,):
            raise ValueError("selected equivalence index must have shape [B]")
        if self.selected_equivalence_index.dtype != torch.long:
            raise ValueError("selected equivalence index must be int64")
        if self.tau.shape != (batch_size,):
            raise ValueError("tau must have shape [B]")
        _validate_finite(self.tau, "tau")
        if self.metric.shape != (batch_size, 3, 3):
            raise ValueError("metric must have shape [B,3,3]")
        _validate_finite(self.metric, "metric")


def _wrap_tensor(values: torch.Tensor) -> torch.Tensor:
    return torch.remainder(values, 1.0)


def _wrap_delta_tensor(values: torch.Tensor) -> torch.Tensor:
    return values - torch.ceil(values - 0.5)


def build_flow_matching_batch(
    *,
    base_noise: torch.Tensor,
    equivalent_targets: torch.Tensor,
    free_parameter_mask: torch.Tensor,
    generator: torch.Generator,
    tau: torch.Tensor | None = None,
    jacobian: torch.Tensor | None = None,
    metric: torch.Tensor | None = None,
) -> FlowMatchingBatchV2:
    _validate_mask(free_parameter_mask)
    batch_size = free_parameter_mask.shape[0]
    if base_noise.shape != (batch_size, 3):
        raise ValueError("base_noise must have shape [B,3]")
    if (
        equivalent_targets.ndim != 3
        or equivalent_targets.shape[0] != batch_size
        or equivalent_targets.shape[2] != 3
        or equivalent_targets.shape[1] == 0
    ):
        raise ValueError("equivalent_targets must have shape [B,K,3] with K>0")
    _validate_finite(base_noise, "base_noise")
    _validate_finite(equivalent_targets, "equivalent_targets")
    device = base_noise.device
    if equivalent_targets.device != device or free_parameter_mask.device != device:
        raise ValueError("flow-matching tensors must be on the same device")

    selected_index = torch.randint(
        equivalent_targets.shape[1],
        (batch_size,),
        generator=generator,
        device=device,
    )
    rows = torch.arange(batch_size, device=device)
    mask = free_parameter_mask.to(dtype=base_noise.dtype)
    u0 = _wrap_tensor(base_noise) * mask
    selected_target = _wrap_tensor(equivalent_targets[rows, selected_index]) * mask
    target_velocity = _wrap_delta_tensor(selected_target - u0) * mask
    if tau is None:
        tau = torch.rand(
            batch_size,
            generator=generator,
            device=device,
            dtype=base_noise.dtype,
        )
    if tau.shape != (batch_size,) or tau.device != device:
        raise ValueError("tau must have shape [B] on the batch device")
    _validate_finite(tau, "tau")
    if bool(((tau < 0.0) | (tau > 1.0)).any()):
        raise ValueError("tau must lie in [0,1]")
    u_tau = _wrap_tensor(u0 + tau.unsqueeze(-1) * target_velocity) * mask
    normalized_metric = induced_cartesian_metric(
        free_parameter_mask,
        jacobian=jacobian,
        metric=metric,
    ).to(device=device, dtype=base_noise.dtype)
    return FlowMatchingBatchV2(
        base_noise=u0,
        selected_target=selected_target,
        selected_equivalence_index=selected_index,
        tau=tau,
        u_tau=u_tau,
        target_velocity=target_velocity,
        free_parameter_mask=free_parameter_mask,
        metric=normalized_metric,
    )


__all__ = [
    "FLOW_METRIC_EPSILON",
    "FlowMatchingBatchV2",
    "build_flow_matching_batch",
    "induced_cartesian_metric",
]
