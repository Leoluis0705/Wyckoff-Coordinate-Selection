from __future__ import annotations

import functools
import dis
import inspect
import random
from collections.abc import Mapping
from dataclasses import dataclass, field, fields, is_dataclass, replace
from typing import Any

import torch
import numpy as np

from crysalis_g1.symmetry.assembly import ProjectionReceipt, SymmetryAssemblyState
from crysalis_g1.symmetry.wyckoff import (
    OrbitState,
    SpaceGroupConditionedWyckoffExpander,
    WyckoffExpansionError,
)

from .physics_guidance import GuidanceDriftProviderV2, LateSamplingGuidanceV2
from .memory import MemoryUpdateReceiptV2, PersistentRelationMemoryV2
from .refinement import (
    GuideObjectiveProtocolV2,
    JointRefinementReceiptV2,
    ProjectorProtocolV2,
    RelationObjectiveProtocolV2,
    refine_joint_manifold,
)
from .sampler import (
    RegisteredFlowSampleV2,
    RegisteredSamplingReceiptV2,
    VelocityFieldV2,
    sample_registered_toroidal_flow,
)
from .wyckoff_shadow import OfficialWyckoffExpanderProtocol


FORMAL_ENDPOINT_STAGES = (
    "REGISTERED_K1_NOISE",
    "EIGHT_STEP_HEUN_FLOW",
    "LATE_GUIDE_GUIDANCE",
    "JOINT_MANIFOLD_REFINEMENT",
    "OFFICIAL_WYCKOFF_EXPANSION",
    "PROJECTOR_RECEIPT",
)
GUIDE_ROLE = "GENERATION_GUIDE_ONLY"
EVAL_ROLE = "TERMINAL_EVALUATION_ONLY"

_FORBIDDEN_MODULE_PREFIXES = (
    "crysalis_g1.full_crysalis.geometry",
    "crysalis_g1.full_crysalis.generation",
    "crysalis_g1.full_crysalis.model",
    "crysalis_g1.model.geometry_backends",
    "crysalis_g1.model.local_pilot_model",
    "crysalis_g1.model.unified",
    "crysalis_g1.generation.sampler",
)
_FORBIDDEN_NODE_TOKENS = (
    "sobol",
    "ranker",
    "representativecoordinate",
    "deterministichead",
    "physicshead",
    "terminationhead",
)
_AUDITED_PROTOCOL_METHODS = (
    "__call__",
    "evaluate",
    "project",
    "expand_many",
    "expand",
    "validate",
    "predict",
    "restore",
    "forward",
)


@dataclass(frozen=True, slots=True)
class GuideMLIPDependencyV2:
    objective: GuideObjectiveProtocolV2
    drift_provider: GuidanceDriftProviderV2
    role: str = GUIDE_ROLE

    def __post_init__(self) -> None:
        if self.role != GUIDE_ROLE:
            raise ValueError("GuideMLIP dependency must have generation-guide-only role")
        if not callable(getattr(self.objective, "evaluate", None)):
            raise TypeError("GuideMLIP objective must implement evaluate")
        if not callable(self.drift_provider):
            raise TypeError("GuideMLIP drift provider must be callable")

    def evaluate(self, orbits: tuple[OrbitState, ...], lattice: object) -> Any:
        return self.objective.evaluate(orbits, lattice)

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        return self.drift_provider(*args, **kwargs)


@dataclass(frozen=True, slots=True)
class EvalMLIPDependencyV2:
    evaluator: object
    role: str = EVAL_ROLE


@dataclass(frozen=True, slots=True)
class FormalDependencyAuditReceiptV2:
    runtime_nodes: tuple[str, ...]
    guide_role: str
    eval_mlip_present: bool
    forbidden_nodes: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class FormalEndpointDependenciesV2:
    velocity_field: VelocityFieldV2
    guide: GuideMLIPDependencyV2
    relation: RelationObjectiveProtocolV2
    projector: ProjectorProtocolV2
    official_expander: OfficialWyckoffExpanderProtocol = field(
        default_factory=SpaceGroupConditionedWyckoffExpander
    )

    def __post_init__(self) -> None:
        if isinstance(self.guide, EvalMLIPDependencyV2):
            raise TypeError("EvalMLIP cannot enter Geometry V2 generation or training")
        if not isinstance(self.guide, GuideMLIPDependencyV2):
            raise TypeError("formal endpoint requires a GuideMLIPDependencyV2")
        if not callable(self.velocity_field):
            raise TypeError("formal endpoint velocity field must be callable")
        if not callable(getattr(self.relation, "evaluate", None)):
            raise TypeError("formal endpoint relation objective must implement evaluate")
        if not callable(getattr(self.projector, "project", None)):
            raise TypeError("formal endpoint Projector must implement project")
        if not callable(getattr(self.official_expander, "expand_many", None)):
            raise TypeError("formal endpoint official expander must implement expand_many")
        audit_formal_dependency_graph(self)


def _node_identity(value: object) -> str:
    if isinstance(value, type) or inspect.isroutine(value):
        module = getattr(value, "__module__", type(value).__module__)
        qualname = getattr(value, "__qualname__", type(value).__qualname__)
        return f"{module}.{qualname}"
    kind = type(value)
    return f"{kind.__module__}.{kind.__qualname__}"


def _effective_class_audit_methods(value: type[object]) -> tuple[object, ...]:
    methods: list[object] = []
    for name in ("__new__", "__init__", *_AUDITED_PROTOCOL_METHODS):
        try:
            descriptor = inspect.getattr_static(value, name)
        except AttributeError:
            continue
        if isinstance(descriptor, (staticmethod, classmethod)):
            descriptor = descriptor.__func__
        if inspect.isfunction(descriptor):
            methods.append(descriptor)
    return tuple(dict.fromkeys(methods))


def _referenced_global_objects(function: object) -> tuple[object, ...]:
    if not inspect.isfunction(function):
        return ()
    instructions = tuple(dis.get_instructions(function))
    closure_values: dict[str, object] = {}
    for name, cell in zip(
        function.__code__.co_freevars, function.__closure__ or (), strict=True
    ):
        try:
            closure_values[name] = cell.cell_contents
        except ValueError:
            continue
    referenced: list[object] = []
    for index, instruction in enumerate(instructions):
        if instruction.opname not in {"LOAD_GLOBAL", "LOAD_NAME", "LOAD_DEREF"}:
            continue
        name = instruction.argval
        if not isinstance(name, str):
            continue
        # Pytest assertion rewriting injects bookkeeping globals that are not
        # dependencies of the callable's protocol behavior.
        if name.startswith("@py"):
            continue
        if instruction.opname == "LOAD_DEREF":
            if name not in closure_values:
                continue
            current = closure_values[name]
        else:
            if name not in function.__globals__:
                continue
            current = function.__globals__[name]
        chain: list[object] = [current]
        for following in instructions[index + 1 :]:
            if following.opname not in {"LOAD_ATTR", "LOAD_METHOD"}:
                break
            attribute = following.argval
            if not isinstance(attribute, str):
                break
            try:
                current = inspect.getattr_static(current, attribute)
            except AttributeError:
                break
            chain.append(current)
        final = chain[-1]
        if not inspect.ismodule(chain[0]):
            if inspect.isfunction(final):
                referenced.append(final)
            elif not isinstance(final, type):
                referenced.extend(chain)
            else:
                referenced.append(final)
            continue
        referenced.append(final)
    return tuple(referenced)


def _runtime_objects(
    roots: tuple[object, ...], *, global_depth: int = 4
) -> tuple[object, ...]:
    ignored = (str, bytes, int, float, bool, type(None), torch.Tensor)
    pending = [(value, global_depth) for value in roots]
    visited: set[int] = set()
    result: list[object] = []
    while pending:
        value, global_depth = pending.pop()
        if inspect.ismodule(value) or isinstance(value, ignored) or id(value) in visited:
            continue
        if len(visited) >= 4096:
            raise RuntimeError("formal dependency audit exceeded its bounded object graph")
        visited.add(id(value))
        result.append(value)
        identity = _node_identity(value).lower()
        node = identity.replace("_", "")
        if identity.startswith(_FORBIDDEN_MODULE_PREFIXES) or any(
            token in node for token in _FORBIDDEN_NODE_TOKENS
        ):
            continue
        if isinstance(value, Mapping):
            pending.extend((item, global_depth) for item in value.values())
        elif isinstance(value, (tuple, list, set, frozenset)):
            pending.extend((item, global_depth) for item in value)
        elif is_dataclass(value) and not isinstance(value, type):
            pending.extend(
                (getattr(value, item.name), global_depth) for item in fields(value)
            )
        elif isinstance(value, functools.partial):
            pending.extend(
                (item, global_depth) for item in (value.func, *value.args)
            )
            pending.extend(
                (item, global_depth) for item in (value.keywords or {}).values()
            )
        elif inspect.ismethod(value):
            pending.extend(
                ((value.__func__, global_depth), (value.__self__, global_depth))
            )
        elif inspect.isfunction(value):
            pending.extend((item, global_depth) for item in (value.__defaults__ or ()))
            pending.extend(
                (item, global_depth) for item in (value.__kwdefaults__ or {}).values()
            )
            for cell in value.__closure__ or ():
                try:
                    pending.append((cell.cell_contents, global_depth))
                except ValueError:
                    continue
            if global_depth > 0:
                pending.extend(
                    (item, global_depth - 1)
                    for item in _referenced_global_objects(value)
                )
        elif isinstance(value, type):
            if global_depth > 0:
                pending.extend(
                    (method, global_depth - 1)
                    for method in _effective_class_audit_methods(value)
                )
        elif inspect.isbuiltin(value) or inspect.ismethodwrapper(value):
            continue
        elif isinstance(value, torch.nn.Module):
            pending.extend((item, 0) for item in value.children())
            pending.append((value.forward, 0))
        elif callable(value):
            pending.append((value.__call__, global_depth))
            if hasattr(value, "__dict__"):
                pending.extend(
                    (item, global_depth) for item in vars(value).values()
                )
        elif hasattr(value, "__dict__"):
            pending.extend((item, global_depth) for item in vars(value).values())
    return tuple(result)


def _audit_runtime_objects(
    runtime_objects: tuple[object, ...],
    *,
    allowed_rng_objects: tuple[object, ...] = (),
) -> tuple[str, ...]:
    nodes = tuple(dict.fromkeys(_node_identity(value) for value in runtime_objects))
    forbidden = tuple(
        node
        for node in nodes
        if node.startswith(_FORBIDDEN_MODULE_PREFIXES)
        or any(token in node.lower().replace("_", "") for token in _FORBIDDEN_NODE_TOKENS)
    )
    if any(
        isinstance(value, EvalMLIPDependencyV2) or getattr(value, "role", None) == EVAL_ROLE
        for value in runtime_objects
    ):
        forbidden = (*forbidden, "EvalMLIP")
    if any(
        isinstance(value, type) and issubclass(value, EvalMLIPDependencyV2)
        for value in runtime_objects
    ):
        forbidden = (*forbidden, "EvalMLIP")
    allowed_rng_ids = {id(value) for value in allowed_rng_objects}
    if any(
        isinstance(value, (torch.Generator, random.Random, np.random.Generator))
        and id(value) not in allowed_rng_ids
        for value in runtime_objects
    ):
        forbidden = (*forbidden, "unregistered RNG")
    if forbidden:
        raise ValueError(
            "forbidden formal dependency: " + ", ".join(dict.fromkeys(forbidden))
        )
    return nodes


def audit_formal_runtime_objects(
    *objects: object,
    allowed_rng_objects: tuple[object, ...] = (),
) -> tuple[str, ...]:
    return _audit_runtime_objects(
        _runtime_objects(tuple(objects)), allowed_rng_objects=allowed_rng_objects
    )


def audit_formal_dependency_graph(
    dependencies: FormalEndpointDependenciesV2,
    *,
    extra_dependencies: tuple[object, ...] = (),
) -> FormalDependencyAuditReceiptV2:
    guide_objects = _runtime_objects((dependencies.guide.objective,))
    if any(
        isinstance(value, torch.nn.Module)
        and any(parameter.requires_grad for parameter in value.parameters())
        for value in guide_objects
    ):
        raise ValueError("formal endpoint requires a frozen GuideMLIP artifact")
    protocol_methods = tuple(
        method
        for owner, method_name in (
            (dependencies.guide.objective, "evaluate"),
            (dependencies.relation, "evaluate"),
            (dependencies.projector, "project"),
        )
        if callable(method := getattr(owner, method_name, None))
    )
    roots = (
        dependencies.velocity_field,
        dependencies.guide,
        dependencies.guide.objective,
        dependencies.guide.drift_provider,
        dependencies.relation,
        dependencies.projector,
        dependencies.official_expander,
        *protocol_methods,
        *extra_dependencies,
    )
    nodes = audit_formal_runtime_objects(*roots)
    expander_method = dependencies.official_expander.expand_many
    expander_nodes = _audit_runtime_objects(
        _runtime_objects(
            (expander_method,),
            global_depth=(
                1
                if type(dependencies.official_expander)
                is SpaceGroupConditionedWyckoffExpander
                else 4
            ),
        )
    )
    return FormalDependencyAuditReceiptV2(
        runtime_nodes=tuple(dict.fromkeys((*nodes, *expander_nodes))),
        guide_role=dependencies.guide.role,
        eval_mlip_present=False,
        forbidden_nodes=(),
    )


@dataclass(frozen=True, slots=True)
class OfficialExpansionReceiptV2:
    succeeded: bool
    site_count: int
    failure_reason_codes: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class FormalEndpointReceiptV2:
    stages: tuple[str, ...]
    sampling: RegisteredSamplingReceiptV2
    registered_sample: RegisteredFlowSampleV2
    refinement: JointRefinementReceiptV2
    expansion: OfficialExpansionReceiptV2
    projector: object | None
    dependency_audit: FormalDependencyAuditReceiptV2
    accepted: bool
    failure_reason_codes: tuple[str, ...]
    attempt_count: int
    resampled: bool
    target_space_group: int
    partial_state: bool


@dataclass(frozen=True, slots=True)
class FormalEndpointResultV2:
    state: SymmetryAssemblyState
    endpoint_values: torch.Tensor
    receipt: FormalEndpointReceiptV2
    updated_memory: PersistentRelationMemoryV2 | None = None
    memory_update_receipt: MemoryUpdateReceiptV2 | None = None


@dataclass(frozen=True, slots=True)
class FormalEndpointRuntimeAuditV2:
    passed: bool
    registered_k1_verified: bool
    eight_step_flow_verified: bool
    projector_authority_verified: bool
    guide_eval_boundary_verified: bool
    no_retry_verified: bool


def _state_with_candidate_sample(
    state: SymmetryAssemblyState,
    values: torch.Tensor,
    free_parameter_mask: torch.Tensor,
    candidate_free_dof: int,
) -> SymmetryAssemblyState:
    if values.shape != (1, 3) or free_parameter_mask.shape != (1, 3):
        raise ValueError("formal endpoint currently requires one registered condition")
    if not state.orbits:
        raise ValueError("formal endpoint state must already contain its candidate orbit")
    candidate = state.orbits[-1]
    if len(candidate.free_parameters) != candidate_free_dof:
        raise ValueError("candidate free DOF does not match the candidate orbit")
    expected_mask = torch.zeros_like(free_parameter_mask)
    expected_mask[0, :candidate_free_dof] = True
    if not torch.equal(free_parameter_mask, expected_mask):
        raise ValueError("candidate free-parameter mask is not canonical")
    sampled_parameters = tuple(
        float(value) for value in values[0, :candidate_free_dof].detach()
    )
    sampled_candidate = OrbitState.create(
        state.target_space_group,
        candidate.wyckoff_letter,
        candidate.species,
        sampled_parameters,
        cell_transform=state.lattice.cell_transform_values,
        orbit_instance_id=candidate.orbit_instance_id,
    )
    return replace(state, orbits=(*state.orbits[:-1], sampled_candidate))


def _projector_accepts(receipt: object, state: SymmetryAssemblyState) -> bool:
    partial = bool(state.remaining_composition)
    required = [
        getattr(receipt, "accepted", False) is True,
        getattr(receipt, "target_space_group", None) == state.target_space_group,
        getattr(receipt, "partial_state", None) is partial,
        getattr(receipt, "orbit_membership_valid", None) is True,
        getattr(receipt, "composition_valid", None) is True,
        getattr(receipt, "multiplicity_valid", None) is True,
        getattr(receipt, "minimum_distance_valid", None) is True,
    ]
    if not partial:
        detected = getattr(receipt, "detected_space_groups", None)
        required.extend(
            (
                isinstance(detected, dict)
                and detected.get(0.03) == state.target_space_group,
                getattr(receipt, "distinct_orbit_instances_valid", None) is True,
            )
        )
    return all(required)


def run_formal_endpoint_v2(
    *,
    state: SymmetryAssemblyState,
    context: torch.Tensor,
    wyckoff_id: torch.Tensor,
    free_parameter_mask: torch.Tensor,
    registered_seed: int,
    candidate_free_dof: int,
    dependencies: FormalEndpointDependenciesV2,
) -> FormalEndpointResultV2:
    dependency_audit = audit_formal_dependency_graph(dependencies)
    guided_velocity = LateSamplingGuidanceV2(
        dependencies.velocity_field, dependencies.guide
    )
    sampled = sample_registered_toroidal_flow(
        guided_velocity,
        context,
        wyckoff_id,
        free_parameter_mask,
        registered_seed=registered_seed,
    )
    sampled_state = _state_with_candidate_sample(
        state, sampled.values, free_parameter_mask, candidate_free_dof
    )
    partial = bool(sampled_state.remaining_composition)
    refined = refine_joint_manifold(
        sampled_state,
        partial_state=partial,
        candidate_free_dof=candidate_free_dof,
        guide=dependencies.guide,
        relation=dependencies.relation,
        projector=dependencies.projector,
    )
    expansion_failure: tuple[str, ...] = ()
    projector_receipt: object | None = None
    try:
        expanded = dependencies.official_expander.expand_many(
            refined.state.orbits,
            refined.state.lattice.primitive_matrix,
            require_target_space_group=not partial,
            require_distinct_orbit_instances=not partial,
        )
        expansion = OfficialExpansionReceiptV2(
            succeeded=True,
            site_count=len(expanded.atomic_numbers),
            failure_reason_codes=(),
        )
        projector_receipt = dependencies.projector.project(refined.state)
    except WyckoffExpansionError as error:
        expansion_failure = (f"OFFICIAL_EXPANSION_REJECTED:{error.reason_code}",)
        expansion = OfficialExpansionReceiptV2(False, 0, expansion_failure)
    except (FloatingPointError, ValueError) as error:
        expansion_failure = (
            f"OFFICIAL_EXPANSION_REJECTED:{type(error).__name__}",
        )
        expansion = OfficialExpansionReceiptV2(False, 0, expansion_failure)

    accepted = projector_receipt is not None and _projector_accepts(
        projector_receipt, refined.state
    )
    refined_candidate = torch.zeros_like(sampled.values)
    if candidate_free_dof:
        refined_candidate[0, :candidate_free_dof] = torch.as_tensor(
            refined.state.orbits[-1].free_parameters,
            device=sampled.values.device,
            dtype=sampled.values.dtype,
        )
    endpoint_values = sampled.values + (
        refined_candidate - sampled.values.detach()
    ) * free_parameter_mask.to(sampled.values.dtype)
    failure_reasons = list(expansion_failure)
    if projector_receipt is not None and not accepted:
        reason_codes = getattr(projector_receipt, "reason_codes", ())
        failure_reasons.extend(reason_codes or ("PROJECTOR_RECEIPT_INVALID",))
    return FormalEndpointResultV2(
        state=refined.state,
        endpoint_values=endpoint_values,
        receipt=FormalEndpointReceiptV2(
            stages=FORMAL_ENDPOINT_STAGES,
            sampling=sampled.receipt,
            registered_sample=sampled,
            refinement=refined.receipt,
            expansion=expansion,
            projector=projector_receipt,
            dependency_audit=dependency_audit,
            accepted=accepted,
            failure_reason_codes=tuple(failure_reasons),
            attempt_count=1,
            resampled=False,
            target_space_group=refined.state.target_space_group,
            partial_state=partial,
        ),
    )


def audit_formal_endpoint_receipt(
    receipt: FormalEndpointReceiptV2,
) -> FormalEndpointRuntimeAuditV2:
    if not isinstance(receipt, FormalEndpointReceiptV2):
        raise TypeError("runtime receipt audit requires FormalEndpointReceiptV2")
    try:
        registered_sample = RegisteredFlowSampleV2.from_state_dict(
            receipt.registered_sample.state_dict()
        )
    except (TypeError, ValueError, FloatingPointError) as error:
        raise ValueError(
            "formal endpoint runtime receipt has an invalid registered sample"
        ) from error
    registered_k1 = (
        registered_sample.receipt == receipt.sampling
        and registered_sample.receipt.sample_count == 1
        and registered_sample.receipt.sample_index == 0
    )
    active_flow = not all(registered_sample.receipt.zero_dof_bypass)
    eight_step = registered_sample.receipt.integration_steps == (
        8 if active_flow else 0
    )
    projector = receipt.projector
    projector_authority = False
    if not receipt.expansion.succeeded:
        projector_authority = projector is None
    elif isinstance(projector, ProjectionReceipt):
        structural_evidence = (
            projector.target_space_group == receipt.target_space_group
            and projector.partial_state is receipt.partial_state
            and projector.correction_amount == 0.0
            and projector.repaired is False
            and len(projector.atomic_numbers) == receipt.expansion.site_count
            and len(projector.fractional_coordinates) == receipt.expansion.site_count
            and len(projector.lattice) == 3
            and all(len(row) == 3 for row in projector.lattice)
        )
        if receipt.accepted:
            required_acceptance = (
                projector.accepted is True
                and projector.orbit_membership_valid is True
                and projector.composition_valid is True
                and projector.multiplicity_valid is True
                and projector.minimum_distance_valid is True
                and (
                    receipt.partial_state
                    or (
                        projector.distinct_orbit_instances_valid is True
                        and projector.detected_space_groups.get(0.03)
                        == receipt.target_space_group
                    )
                )
            )
            projector_authority = structural_evidence and required_acceptance
        else:
            projector_authority = (
                structural_evidence
                and projector.accepted is False
                and bool(projector.reason_codes)
                and all(code in receipt.failure_reason_codes for code in projector.reason_codes)
            )
    guide_boundary = (
        receipt.dependency_audit.guide_role == GUIDE_ROLE
        and not receipt.dependency_audit.eval_mlip_present
        and not receipt.dependency_audit.forbidden_nodes
    )
    no_retry = (
        receipt.attempt_count == 1
        and receipt.resampled is False
        and receipt.refinement.resampled is False
    )
    accepted_consistent = not receipt.accepted or (
        receipt.expansion.succeeded
        and isinstance(receipt.projector, ProjectionReceipt)
        and receipt.projector.accepted is True
        and not receipt.failure_reason_codes
    )
    failed_consistent = receipt.accepted or bool(receipt.failure_reason_codes)
    checks = (
        receipt.stages == FORMAL_ENDPOINT_STAGES,
        registered_k1,
        eight_step,
        projector_authority,
        guide_boundary,
        no_retry,
        accepted_consistent,
        failed_consistent,
    )
    if not all(checks):
        raise ValueError("formal endpoint runtime receipt violates the frozen contract")
    return FormalEndpointRuntimeAuditV2(
        passed=True,
        registered_k1_verified=registered_k1,
        eight_step_flow_verified=eight_step,
        projector_authority_verified=projector_authority,
        guide_eval_boundary_verified=guide_boundary,
        no_retry_verified=no_retry,
    )


class InferenceGeometryAdapterV2:
    endpoint = staticmethod(run_formal_endpoint_v2)

    def run(self, **request: Any) -> FormalEndpointResultV2:
        return self.endpoint(**request)


class TrainingGeometryAdapterV2:
    endpoint = staticmethod(run_formal_endpoint_v2)

    @staticmethod
    def requires_formal_alignment(batch_index: int) -> bool:
        if type(batch_index) is not int or batch_index < 0:
            raise ValueError("batch index must be a non-negative integer")
        return (batch_index + 1) % 4 == 0

    def run_alignment(
        self, batch_index: int, **request: Any
    ) -> FormalEndpointResultV2 | None:
        if not self.requires_formal_alignment(batch_index):
            return None
        return self.endpoint(**request)


__all__ = [
    "EVAL_ROLE",
    "FORMAL_ENDPOINT_STAGES",
    "GUIDE_ROLE",
    "EvalMLIPDependencyV2",
    "FormalDependencyAuditReceiptV2",
    "FormalEndpointDependenciesV2",
    "FormalEndpointReceiptV2",
    "FormalEndpointResultV2",
    "FormalEndpointRuntimeAuditV2",
    "GuideMLIPDependencyV2",
    "InferenceGeometryAdapterV2",
    "OfficialExpansionReceiptV2",
    "TrainingGeometryAdapterV2",
    "audit_formal_dependency_graph",
    "audit_formal_endpoint_receipt",
    "audit_formal_runtime_objects",
    "run_formal_endpoint_v2",
]
