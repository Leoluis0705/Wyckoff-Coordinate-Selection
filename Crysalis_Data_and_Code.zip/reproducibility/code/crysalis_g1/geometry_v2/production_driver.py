from __future__ import annotations

import math
import json
import os
import random
import tempfile
import time
from copy import deepcopy
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import torch

from .endpoint import audit_formal_endpoint_receipt
from .formal_adapters import RelationGeometryCalibrationV2
from .model import FormalGeometryV2Model
from .production_batches import (
    ProductionBatchCursorV2,
    ProductionBatchSchedulerV2,
)
from .production_config import ProductionTrainingConfigV2
from .production_losses import (
    LossScaleNormalizerV2,
    build_projected_guide_teacher_targets_v2,
    compute_formal_endpoint_alignment_loss_v2,
    compute_production_losses_v2,
)
from .production_validation import run_structure_ood_validation_v2
from .production_replay import ProductionReplayRefresherV2
from .training import TrainingGeometryAdapterV2, _slice_model_input
from .training import (
    AtomicCheckpointStoreV2,
    RegisteredRngV2,
    capture_training_rng_state_v2,
    restore_training_rng_state_v2,
)


PRODUCTION_CHECKPOINT_SCHEMA_V2 = "crysalis-geometry-v2-production-checkpoint.1.0.0"


def validate_precheck_run_authorization_v2(
    *, update_count: int, formal_training_authorized: bool, scientific_use: bool
) -> None:
    if type(update_count) is not int or update_count <= 0:
        raise ValueError("production update count must be positive")
    if not formal_training_authorized:
        if scientific_use or update_count > 4:
            raise PermissionError(
                "formal training is not authorized; only a four-batch non-scientific dry run is allowed"
            )
    elif not scientific_use:
        raise ValueError("authorized formal training must be marked scientific_use=true")


def should_stop_early_v2(
    *,
    next_batch_index: int,
    best_batch_index: int | None,
    config: ProductionTrainingConfigV2,
) -> bool:
    if next_batch_index < config.minimum_updates or best_batch_index is None:
        return False
    intervals_without_improvement = (
        next_batch_index - 1 - best_batch_index
    ) // config.validation_interval
    return intervals_without_improvement >= config.early_stopping_patience


@dataclass(frozen=True, slots=True)
class ProductionResumeStateV2:
    batch_cursor: ProductionBatchCursorV2
    current_refresh_interval: int
    validation_history: tuple[tuple[int, float], ...]
    best_composite: float
    best_batch_index: int | None
    best_model_state: Mapping[str, Any] | None
    best_optimizer_state: Mapping[str, Any] | None
    loss_normalizer: LossScaleNormalizerV2
    gradient_accumulation_state: Mapping[str, Any]
    replay_buffer_sha256: str
    config: Mapping[str, Any]


class ProductionCheckpointStoreV2:
    def __init__(self, path: str | Path) -> None:
        self._store = AtomicCheckpointStoreV2(path)

    @property
    def path(self) -> Path:
        return self._store.path

    def save(
        self,
        *,
        model: FormalGeometryV2Model,
        optimizer: torch.optim.Optimizer,
        batch_cursor: ProductionBatchCursorV2,
        replay_buffer_sha256: str,
        current_refresh_interval: int,
        validation_history: tuple[tuple[int, float], ...],
        best_composite: float,
        best_batch_index: int | None,
        best_model_state: Mapping[str, Any] | None,
        loss_normalizer: LossScaleNormalizerV2,
        registered_generators: Mapping[str, RegisteredRngV2],
        gradient_accumulation_state: Mapping[str, Any],
        config: ProductionTrainingConfigV2,
        best_optimizer_state: Mapping[str, Any] | None = None,
        scheduler_state: Mapping[str, Any] | None = None,
        best_scheduler_state: Mapping[str, Any] | None = None,
    ) -> None:
        if len(replay_buffer_sha256) != 64:
            raise ValueError("production checkpoint requires a replay-buffer SHA-256")
        if current_refresh_interval < 0:
            raise ValueError("refresh interval index must be non-negative")
        if not math.isfinite(float(best_composite)):
            raise ValueError("best validation composite must be finite")
        payload = {
            "schema_version": PRODUCTION_CHECKPOINT_SCHEMA_V2,
            "current_model_state": deepcopy(model.state_dict()),
            "current_optimizer_state": deepcopy(optimizer.state_dict()),
            "current_scheduler_state": deepcopy(scheduler_state),
            "best_model_state": deepcopy(best_model_state),
            "best_optimizer_state": deepcopy(
                optimizer.state_dict() if best_optimizer_state is None and best_model_state is not None else best_optimizer_state
            ),
            "best_scheduler_state": deepcopy(best_scheduler_state),
            "batch_cursor": batch_cursor.to_dict(),
            "replay_buffer_sha256": replay_buffer_sha256,
            "current_refresh_interval": int(current_refresh_interval),
            "replay_refresh_interval": config.replay_refresh_interval,
            "validation_history": tuple(
                (int(index), float(value)) for index, value in validation_history
            ),
            "best_composite": float(best_composite),
            "best_batch_index": best_batch_index,
            "training_rng_state": capture_training_rng_state_v2(registered_generators),
            "registered_flow_rng_names": tuple(sorted(registered_generators)),
            "loss_normalizer": loss_normalizer.to_dict(),
            "gradient_accumulation_state": deepcopy(dict(gradient_accumulation_state)),
            "config": asdict(config),
        }
        self._store.save(payload)

    def restore(
        self,
        *,
        model: FormalGeometryV2Model,
        optimizer: torch.optim.Optimizer,
        expected_replay_buffer_sha256: str,
        registered_generators: Mapping[str, RegisteredRngV2],
    ) -> ProductionResumeStateV2:
        payload = self._store.load()
        required = {
            "schema_version",
            "current_model_state",
            "current_optimizer_state",
            "current_scheduler_state",
            "best_model_state",
            "best_optimizer_state",
            "best_scheduler_state",
            "batch_cursor",
            "replay_buffer_sha256",
            "current_refresh_interval",
            "replay_refresh_interval",
            "validation_history",
            "best_composite",
            "best_batch_index",
            "training_rng_state",
            "registered_flow_rng_names",
            "loss_normalizer",
            "gradient_accumulation_state",
            "config",
        }
        if set(payload) != required or payload["schema_version"] != PRODUCTION_CHECKPOINT_SCHEMA_V2:
            raise ValueError("production resume checkpoint fields are invalid")
        if payload["replay_buffer_sha256"] != expected_replay_buffer_sha256:
            raise ValueError("production replay-buffer hash differs from checkpoint")
        if tuple(payload["registered_flow_rng_names"]) != tuple(
            sorted(registered_generators)
        ):
            raise ValueError("registered RNG namespaces differ from checkpoint")
        model.load_state_dict(payload["current_model_state"], strict=True)
        optimizer.load_state_dict(payload["current_optimizer_state"])
        restore_training_rng_state_v2(payload["training_rng_state"], registered_generators)
        return ProductionResumeStateV2(
            batch_cursor=ProductionBatchCursorV2.from_dict(payload["batch_cursor"]),
            current_refresh_interval=int(payload["current_refresh_interval"]),
            validation_history=tuple(
                (int(index), float(value))
                for index, value in payload["validation_history"]
            ),
            best_composite=float(payload["best_composite"]),
            best_batch_index=(
                None
                if payload["best_batch_index"] is None
                else int(payload["best_batch_index"])
            ),
            best_model_state=payload["best_model_state"],
            best_optimizer_state=payload["best_optimizer_state"],
            loss_normalizer=LossScaleNormalizerV2.from_dict(
                payload["loss_normalizer"]
            ),
            gradient_accumulation_state=payload["gradient_accumulation_state"],
            replay_buffer_sha256=str(payload["replay_buffer_sha256"]),
            config=payload["config"],
        )


@dataclass(frozen=True, slots=True)
class ProductionRunReceiptV2:
    status: str
    scientific_use: bool
    started_from_batch: int
    next_batch_index: int
    completed_batch_count: int
    live_endpoint_batches: tuple[int, ...]
    validation_history: tuple[tuple[int, float], ...]
    batch_selection_hashes: tuple[str, ...]
    replay_buffer_sha256: str
    checkpoint_path: str
    metrics_path: str
    wall_seconds: float


def _atomic_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
            json.dump(payload, stream, indent=2, sort_keys=True)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary_name, path)
    finally:
        try:
            os.unlink(temporary_name)
        except FileNotFoundError:
            pass


def _append_jsonl(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(payload, sort_keys=True, allow_nan=False) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def _selection_hash(receipt: object) -> str:
    import hashlib

    payload = {
        "batch_index": receipt.batch_index,
        "teacher_event_ids": receipt.teacher_event_ids,
        "replay_record_ids": receipt.replay_record_ids,
        "registered_flow_seeds": receipt.registered_flow_seeds,
    }
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


class ProductionDriverV2:
    """Real-data production orchestration; precheck authorization is fail-closed."""

    def __init__(
        self,
        *,
        model: FormalGeometryV2Model,
        optimizer: torch.optim.Optimizer,
        scheduler: ProductionBatchSchedulerV2,
        validation_events: Sequence[object],
        relation_normalizer: object,
        loss_normalizer: LossScaleNormalizerV2,
        guide_objective: object,
        projector: object,
        relation_calibration: RelationGeometryCalibrationV2,
        config: ProductionTrainingConfigV2,
        device: str | torch.device,
        checkpoint_path: str | Path,
        metrics_path: str | Path,
        replay_refresher: ProductionReplayRefresherV2 | None = None,
    ) -> None:
        if not isinstance(model, FormalGeometryV2Model):
            raise TypeError("production driver requires FormalGeometryV2Model")
        self.model = model
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.validation_events = tuple(validation_events)
        self.relation_normalizer = relation_normalizer
        self.loss_normalizer = loss_normalizer
        self.guide = guide_objective
        self.projector = projector
        self.calibration = relation_calibration
        self.config = config
        self.device = torch.device(device)
        self.checkpoints = ProductionCheckpointStoreV2(checkpoint_path)
        self.metrics_path = Path(metrics_path)
        self.replay_refresher = replay_refresher
        self.current_refresh_interval = 0
        self.flow_generator = torch.Generator(device=self.device).manual_seed(
            config.training_seed
        )
        self.registered_generators: dict[str, RegisteredRngV2] = {
            "flow_training": self.flow_generator
        }

    def _save(
        self,
        *,
        cursor: ProductionBatchCursorV2,
        validation_history: tuple[tuple[int, float], ...],
        best: float,
        best_batch: int | None,
        best_model: Mapping[str, Any] | None,
        best_optimizer: Mapping[str, Any] | None,
    ) -> None:
        self.checkpoints.save(
            model=self.model,
            optimizer=self.optimizer,
            batch_cursor=cursor,
            replay_buffer_sha256=self.scheduler.replay_buffer_sha256,
            current_refresh_interval=self.current_refresh_interval,
            validation_history=validation_history,
            best_composite=best,
            best_batch_index=best_batch,
            best_model_state=best_model,
            best_optimizer_state=best_optimizer,
            loss_normalizer=self.loss_normalizer,
            registered_generators=self.registered_generators,
            gradient_accumulation_state={
                "microbatch_index": 0,
                "gradient_tensors": {},
                "effective_batch_size": self.config.effective_batch_size,
                "microbatch_size": self.config.microbatch_size,
                "gradient_accumulation_steps": self.config.gradient_accumulation_steps,
            },
            config=self.config,
        )

    def _live_endpoint(
        self, batch: object, batch_index: int
    ) -> tuple[torch.Tensor | None, Mapping[str, Any] | None]:
        if not self.config.is_live_endpoint_batch(batch_index):
            return None, None
        sample_index = batch.replay_rows[0]
        built = batch.built
        request_input = _slice_model_input(
            built.training_batch.model_input, sample_index
        )
        seed = self.config.training_seed + 1_000_003 * (batch_index + 1)
        prepared = self.model.prepare_endpoint(
            state=built.supervision.states[sample_index],
            model_input=request_input,
            wyckoff_id=built.supervision.wyckoff_id[sample_index : sample_index + 1],
            free_parameter_mask=built.supervision.free_parameter_mask[
                sample_index : sample_index + 1
            ],
            registered_seed=seed,
            candidate_free_dof=int(
                built.supervision.free_parameter_mask[sample_index].sum().item()
            ),
            guide_objective=self.guide,
            projector=self.projector,
            relation_calibration=self.calibration,
        )
        if prepared.endpoint_kwargs["dependencies"].velocity_field is not self.model.flow:
            raise RuntimeError("live formal endpoint is not using the current model flow")
        result = TrainingGeometryAdapterV2().run_alignment(
            batch_index, **prepared.endpoint_kwargs
        )
        if result is None:
            raise RuntimeError("scheduled live formal endpoint did not execute")
        result = self.model.apply_memory_transition(result, prepared)
        audit_formal_endpoint_receipt(result.receipt)
        loss = compute_formal_endpoint_alignment_loss_v2(
            prepared=prepared,
            result=result,
            supervision=built.supervision,
            sample_index=sample_index,
            calibration=self.calibration,
        )
        projector = result.receipt.projector
        summary = {
            "registered_seed": seed,
            "sample_count": result.receipt.sampling.sample_count,
            "integration_steps": result.receipt.sampling.integration_steps,
            "accepted": result.receipt.accepted,
            "failure_reason_codes": result.receipt.failure_reason_codes,
            "guide_inapplicable_intermediate_count": (
                prepared.drift.inapplicable_intermediate_count
            ),
            "guide_inapplicable_reason_codes": tuple(
                prepared.drift.inapplicable_reason_codes
            ),
            "resampled": result.receipt.resampled,
            "projector_called": projector is not None,
        }
        return loss, summary

    def run(
        self,
        *,
        stop_after_batch: int,
        resume: bool,
        scientific_use: bool,
        formal_training_authorized: bool,
        run_final_validation: bool,
        expected_validation_event_count: int = 2957,
        interrupt_after_completed_batches: int | None = None,
    ) -> ProductionRunReceiptV2:
        validate_precheck_run_authorization_v2(
            update_count=stop_after_batch,
            formal_training_authorized=formal_training_authorized,
            scientific_use=scientific_use,
        )
        started = time.perf_counter()
        if resume:
            restored = self.checkpoints.restore(
                model=self.model,
                optimizer=self.optimizer,
                expected_replay_buffer_sha256=self.scheduler.replay_buffer_sha256,
                registered_generators=self.registered_generators,
            )
            cursor = restored.batch_cursor
            validation_history = restored.validation_history
            best = restored.best_composite
            best_batch = restored.best_batch_index
            best_model = restored.best_model_state
            best_optimizer = restored.best_optimizer_state
            self.current_refresh_interval = restored.current_refresh_interval
        else:
            random.seed(self.config.training_seed)
            np.random.seed(self.config.training_seed)
            torch.manual_seed(self.config.training_seed)
            if self.device.type == "cuda":
                torch.cuda.manual_seed_all(self.config.training_seed)
            cursor = ProductionBatchCursorV2()
            validation_history = ()
            best = float(torch.finfo(torch.float64).max)
            best_batch = None
            best_model = None
            best_optimizer = None
            self.metrics_path.unlink(missing_ok=True)
            self._save(
                cursor=cursor,
                validation_history=validation_history,
                best=best,
                best_batch=best_batch,
                best_model=best_model,
                best_optimizer=best_optimizer,
            )
        started_from = cursor.next_batch_index
        if cursor.next_batch_index > stop_after_batch:
            raise ValueError("resume checkpoint is beyond requested dry-run boundary")
        live_batches: list[int] = []
        selection_hashes: list[str] = []
        completed_this_call = 0
        status = "COMPLETE"
        try:
            while cursor.next_batch_index < stop_after_batch:
                desired_interval = (
                    cursor.next_batch_index // self.config.replay_refresh_interval
                )
                if desired_interval != self.current_refresh_interval:
                    if desired_interval != self.current_refresh_interval + 1:
                        raise RuntimeError("production replay refresh interval skipped")
                    if self.replay_refresher is None:
                        raise RuntimeError(
                            "production replay refresh is due but no refresher is wired"
                        )
                    refreshed, refresh_receipt = self.replay_refresher.refresh(
                        self.model, desired_interval
                    )
                    self.scheduler.replace_replay_buffer(refreshed)
                    self.current_refresh_interval = desired_interval
                    cursor = ProductionBatchCursorV2(
                        next_batch_index=cursor.next_batch_index,
                        teacher_cursor=cursor.teacher_cursor,
                        teacher_epoch=cursor.teacher_epoch,
                        replay_cursor=0,
                        replay_epoch=0,
                    )
                    self._save(
                        cursor=cursor,
                        validation_history=validation_history,
                        best=best,
                        best_batch=best_batch,
                        best_model=best_model,
                        best_optimizer=best_optimizer,
                    )
                    _atomic_json(
                        self.metrics_path.with_name(
                            f"replay_refresh_{desired_interval:04d}.json"
                        ),
                        asdict(refresh_receipt),
                    )
                batch_index = cursor.next_batch_index
                batch, advanced = self.scheduler.next_batch(cursor)
                selection = _selection_hash(batch.receipt)
                physics_targets, physics_receipt = build_projected_guide_teacher_targets_v2(
                    batch.built.supervision.states,
                    self.guide,
                    device=self.device,
                )
                endpoint_loss, endpoint_receipt = self._live_endpoint(batch, batch_index)
                losses = compute_production_losses_v2(
                    self.model,
                    batch.built.training_batch,
                    batch.built.supervision,
                    generator=self.flow_generator,
                    projected_physics_targets=physics_targets,
                    normalizer=self.loss_normalizer,
                    formal_endpoint_component=endpoint_loss,
                )
                self.optimizer.zero_grad(set_to_none=True)
                losses.total.backward()
                gradient_norm = torch.nn.utils.clip_grad_norm_(
                    self.model.parameters(), self.config.gradient_clip_norm
                )
                self.optimizer.step()
                if not bool(torch.isfinite(torch.as_tensor(gradient_norm))):
                    raise FloatingPointError("production gradient norm is non-finite")
                cursor = advanced
                completed_this_call += 1
                selection_hashes.append(selection)
                if endpoint_receipt is not None:
                    live_batches.append(batch_index)
                _append_jsonl(
                    self.metrics_path,
                    {
                        "schema_version": "crysalis-geometry-v2-production-metric.1.0.0",
                        "scientific_use": scientific_use,
                        "batch_index": batch_index,
                        "selection_hash": selection,
                        "batch_receipt": asdict(batch.receipt),
                        "raw_losses": losses.detached_row(),
                        "normalized_losses": {
                            name: float(value.detach().cpu())
                            for name, value in losses.normalized.items()
                        },
                        "total_loss": float(losses.total.detach().cpu()),
                        "gradient_norm": float(torch.as_tensor(gradient_norm).detach().cpu()),
                        "physics_teacher": asdict(physics_receipt),
                        "live_endpoint": endpoint_receipt,
                    },
                )
                reached_validation_boundary = (
                    formal_training_authorized
                    and cursor.next_batch_index % self.config.validation_interval == 0
                )
                if reached_validation_boundary:
                    validation = run_structure_ood_validation_v2(
                        model=self.model,
                        events=self.validation_events,
                        relation_normalizer=self.relation_normalizer,
                        loss_normalizer=self.loss_normalizer,
                        projector=self.projector,
                        device=self.device,
                        batch_size=self.config.microbatch_size,
                        registered_seed_root=self.config.training_seed,
                        shell_boundaries_angstrom=(
                            self.calibration.shell_boundaries_angstrom
                        ),
                        expected_event_count=expected_validation_event_count,
                    )
                    validation_batch = cursor.next_batch_index - 1
                    validation_history = (
                        *validation_history,
                        (validation_batch, validation.composite),
                    )
                    if validation.composite < best:
                        best = validation.composite
                        best_batch = validation_batch
                        best_model = deepcopy(self.model.state_dict())
                        best_optimizer = deepcopy(self.optimizer.state_dict())
                    _append_jsonl(
                        self.metrics_path.with_name("production_validation.jsonl"),
                        {
                            "schema_version": (
                                "crysalis-geometry-v2-production-validation.1.0.0"
                            ),
                            "scientific_use": scientific_use,
                            "batch_index": validation_batch,
                            "metrics": validation.metrics,
                            "composite": validation.composite,
                            "event_count": validation.event_count,
                            "nonterminal_event_count": (
                                validation.nonterminal_event_count
                            ),
                            "terminal_event_count": validation.terminal_event_count,
                        },
                    )
                self._save(
                    cursor=cursor,
                    validation_history=validation_history,
                    best=best,
                    best_batch=best_batch,
                    best_model=best_model,
                    best_optimizer=best_optimizer,
                )
                if (
                    reached_validation_boundary
                    and should_stop_early_v2(
                        next_batch_index=cursor.next_batch_index,
                        best_batch_index=best_batch,
                        config=self.config,
                    )
                ):
                    status = "EARLY_STOPPED"
                    break
                if (
                    interrupt_after_completed_batches is not None
                    and completed_this_call >= interrupt_after_completed_batches
                ):
                    raise KeyboardInterrupt
        except KeyboardInterrupt:
            status = "INTERRUPTED"

        final_validation_already_recorded = bool(
            validation_history
            and validation_history[-1][0] == cursor.next_batch_index - 1
        )
        if (
            status == "COMPLETE"
            and run_final_validation
            and not final_validation_already_recorded
        ):
            validation = run_structure_ood_validation_v2(
                model=self.model,
                events=self.validation_events,
                relation_normalizer=self.relation_normalizer,
                loss_normalizer=self.loss_normalizer,
                projector=self.projector,
                device=self.device,
                batch_size=self.config.microbatch_size,
                registered_seed_root=self.config.training_seed,
                shell_boundaries_angstrom=self.calibration.shell_boundaries_angstrom,
                expected_event_count=expected_validation_event_count,
            )
            validation_history = (
                *validation_history,
                (cursor.next_batch_index - 1, validation.composite),
            )
            if validation.composite < best:
                best = validation.composite
                best_batch = cursor.next_batch_index - 1
                best_model = deepcopy(self.model.state_dict())
                best_optimizer = deepcopy(self.optimizer.state_dict())
            self._save(
                cursor=cursor,
                validation_history=validation_history,
                best=best,
                best_batch=best_batch,
                best_model=best_model,
                best_optimizer=best_optimizer,
            )
            _atomic_json(
                self.metrics_path.with_suffix(".validation.json"),
                {
                    "schema_version": "crysalis-geometry-v2-production-validation.1.0.0",
                    "scientific_use": scientific_use,
                    "metrics": validation.metrics,
                    "composite": validation.composite,
                    "event_count": validation.event_count,
                    "nonterminal_event_count": validation.nonterminal_event_count,
                    "terminal_event_count": validation.terminal_event_count,
                },
            )
        return ProductionRunReceiptV2(
            status=status,
            scientific_use=scientific_use,
            started_from_batch=started_from,
            next_batch_index=cursor.next_batch_index,
            completed_batch_count=completed_this_call,
            live_endpoint_batches=tuple(live_batches),
            validation_history=validation_history,
            batch_selection_hashes=tuple(selection_hashes),
            replay_buffer_sha256=self.scheduler.replay_buffer_sha256,
            checkpoint_path=str(self.checkpoints.path),
            metrics_path=str(self.metrics_path),
            wall_seconds=time.perf_counter() - started,
        )


__all__ = [
    "PRODUCTION_CHECKPOINT_SCHEMA_V2",
    "ProductionCheckpointStoreV2",
    "ProductionResumeStateV2",
    "ProductionDriverV2",
    "ProductionRunReceiptV2",
    "should_stop_early_v2",
    "validate_precheck_run_authorization_v2",
]
