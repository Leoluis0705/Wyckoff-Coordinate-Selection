from __future__ import annotations

import json
import math
import os
import random
import tempfile
import time
from copy import deepcopy
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, TypeAlias, cast

import torch
import numpy as np

from crysalis_g1.symmetry.assembly import SymmetryAssemblyState

from .endpoint import (
    FormalEndpointDependenciesV2,
    FormalEndpointReceiptV2,
    FormalEndpointResultV2,
    TrainingGeometryAdapterV2,
    audit_formal_runtime_objects,
    audit_formal_endpoint_receipt,
)
from .model import FormalGeometryV2Model
from .formal_adapters import (
    RelationGeometryCalibrationV2,
    validate_relation_geometry_calibration_contract_v2,
)
from .memory import PersistentRelationMemoryV2
from .refinement import GuideObjectiveProtocolV2, ProjectorProtocolV2
from .relation_interface import ActiveOrbitGraphV2, RelationModelInputV2
from .train_fit import TrainFitBatchV2


CHECKPOINT_SELECTION_FIELDS = frozenset(
    {
        "normalized_flow_loss",
        "normalized_final_relation_nll",
        "normalized_local_metric_error",
        "legality_penalty",
    }
)
TRAINING_METRIC_SCHEMA = "crysalis-geometry-v2-training-metric.1.0.0"
TRAINING_CHECKPOINT_SCHEMA = "crysalis-geometry-v2-training-checkpoint.4.0.0"
TRAINING_RNG_SCHEMA = "crysalis-geometry-v2-rng-state.2.0.0"
RegisteredRngV2: TypeAlias = (
    torch.Generator | random.Random | np.random.Generator
)


def _validate_registered_generators(
    generators: Mapping[str, RegisteredRngV2] | None,
) -> dict[str, RegisteredRngV2]:
    normalized = {} if generators is None else dict(generators)
    if any(
        not isinstance(name, str)
        or not name
        or not isinstance(
            generator, (torch.Generator, random.Random, np.random.Generator)
        )
        for name, generator in normalized.items()
    ):
        raise TypeError(
            "registered RNG generators require named torch, Python, or NumPy generators"
        )
    return normalized


def _encode_numpy_generator_state(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return {"__numpy_array__": value.tolist(), "dtype": str(value.dtype)}
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.floating):
        return float(value)
    if isinstance(value, Mapping):
        return {
            str(key): _encode_numpy_generator_state(item)
            for key, item in value.items()
        }
    if isinstance(value, (tuple, list)):
        return [_encode_numpy_generator_state(item) for item in value]
    if isinstance(value, (str, int, float, bool, type(None))):
        return value
    raise TypeError("NumPy generator state contains an unsupported value")


def _decode_numpy_generator_state(value: Any) -> Any:
    if isinstance(value, Mapping):
        if set(value) == {"__numpy_array__", "dtype"}:
            return np.asarray(value["__numpy_array__"], dtype=str(value["dtype"]))
        return {
            str(key): _decode_numpy_generator_state(item)
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [_decode_numpy_generator_state(item) for item in value]
    return value


def _capture_registered_rng(generator: RegisteredRngV2) -> dict[str, Any]:
    if isinstance(generator, torch.Generator):
        return {"kind": "torch", "state": generator.get_state().clone()}
    if isinstance(generator, random.Random):
        state = generator.getstate()
        return {
            "kind": "python",
            "version": int(state[0]),
            "state": tuple(int(value) for value in state[1]),
            "gaussian": None if state[2] is None else float(state[2]),
        }
    return {
        "kind": "numpy",
        "state": _encode_numpy_generator_state(generator.bit_generator.state),
    }


def capture_training_rng_state_v2(
    registered_generators: Mapping[str, RegisteredRngV2] | None = None,
) -> dict[str, Any]:
    generators = _validate_registered_generators(registered_generators)
    python_state = random.getstate()
    numpy_state = cast(tuple[Any, Any, Any, Any, Any], np.random.get_state())
    return {
        "schema_version": TRAINING_RNG_SCHEMA,
        "torch_cpu": torch.get_rng_state().clone(),
        "torch_cuda_all": tuple(state.clone() for state in torch.cuda.get_rng_state_all()),
        "python_version": int(python_state[0]),
        "python_state": tuple(int(value) for value in python_state[1]),
        "python_gaussian": (
            None if python_state[2] is None else float(python_state[2])
        ),
        "numpy_bit_generator": str(numpy_state[0]),
        "numpy_state": torch.as_tensor(
            numpy_state[1].astype(np.int64, copy=True), dtype=torch.int64
        ),
        "numpy_position": int(numpy_state[2]),
        "numpy_has_gaussian": int(numpy_state[3]),
        "numpy_cached_gaussian": float(numpy_state[4]),
        "registered_generators": {
            name: _capture_registered_rng(generator)
            for name, generator in sorted(generators.items())
        },
    }


def restore_training_rng_state_v2(
    payload: Mapping[str, Any],
    registered_generators: Mapping[str, RegisteredRngV2] | None = None,
) -> None:
    required = {
        "schema_version",
        "torch_cpu",
        "torch_cuda_all",
        "python_version",
        "python_state",
        "python_gaussian",
        "numpy_bit_generator",
        "numpy_state",
        "numpy_position",
        "numpy_has_gaussian",
        "numpy_cached_gaussian",
        "registered_generators",
    }
    if set(payload) != required or payload["schema_version"] != TRAINING_RNG_SCHEMA:
        raise ValueError("training RNG checkpoint fields are invalid")
    cpu = payload["torch_cpu"]
    cuda = payload["torch_cuda_all"]
    numpy_values = payload["numpy_state"]
    if not isinstance(cpu, torch.Tensor) or cpu.dtype is not torch.uint8:
        raise ValueError("training CPU RNG state is invalid")
    if not isinstance(cuda, (tuple, list)) or any(
        not isinstance(state, torch.Tensor) or state.dtype is not torch.uint8
        for state in cuda
    ):
        raise ValueError("training CUDA RNG states are invalid")
    if cuda and not torch.cuda.is_available():
        raise RuntimeError("checkpoint has CUDA RNG state but CUDA is unavailable")
    if not isinstance(numpy_values, torch.Tensor) or numpy_values.dtype is not torch.int64:
        raise ValueError("training NumPy RNG state is invalid")
    generators = _validate_registered_generators(registered_generators)
    saved_generators = payload["registered_generators"]
    if not isinstance(saved_generators, Mapping) or set(saved_generators) != set(generators):
        raise ValueError("registered RNG generator identities do not match checkpoint")
    torch.set_rng_state(cpu)
    if cuda:
        torch.cuda.set_rng_state_all(list(cuda))
    random.setstate(
        (
            int(payload["python_version"]),
            tuple(int(value) for value in payload["python_state"]),
            (
                None
                if payload["python_gaussian"] is None
                else float(payload["python_gaussian"])
            ),
        )
    )
    np.random.set_state(
        (
            str(payload["numpy_bit_generator"]),
            numpy_values.cpu().numpy().astype(np.uint32),
            int(payload["numpy_position"]),
            int(payload["numpy_has_gaussian"]),
            float(payload["numpy_cached_gaussian"]),
        )
    )
    for name, generator in generators.items():
        state = saved_generators[name]
        if not isinstance(state, Mapping):
            raise ValueError("registered RNG generator state is invalid")
        kind = state.get("kind")
        if isinstance(generator, torch.Generator) and kind == "torch":
            tensor_state = state.get("state")
            if not isinstance(tensor_state, torch.Tensor) or (
                tensor_state.dtype is not torch.uint8
            ):
                raise ValueError("registered torch generator state is invalid")
            generator.set_state(tensor_state)
        elif isinstance(generator, random.Random) and kind == "python":
            generator.setstate(
                (
                    int(state["version"]),
                    tuple(int(value) for value in state["state"]),
                    None if state["gaussian"] is None else float(state["gaussian"]),
                )
            )
        elif isinstance(generator, np.random.Generator) and kind == "numpy":
            generator.bit_generator.state = _decode_numpy_generator_state(
                state.get("state")
            )
        else:
            raise ValueError("registered RNG generator kind differs from checkpoint")


@dataclass(frozen=True, slots=True)
class TrajectorySampleIdentityV2:
    trajectory_id: str
    sample_id: str
    sequence_index: int

    def __post_init__(self) -> None:
        if not self.trajectory_id or self.trajectory_id.strip() != self.trajectory_id:
            raise ValueError("trajectory ID must be immutable and non-empty")
        if not self.sample_id or self.sample_id.strip() != self.sample_id:
            raise ValueError("sample ID must be immutable and non-empty")
        if type(self.sequence_index) is not int or self.sequence_index < 0:
            raise ValueError("trajectory sequence index must be non-negative")


class TrajectoryMemoryStoreV2:
    def __init__(self) -> None:
        self._entries: dict[str, tuple[int, PersistentRelationMemoryV2]] = {}

    def validate_batch(
        self, identities: tuple[TrajectorySampleIdentityV2, ...]
    ) -> None:
        if not identities or any(
            not isinstance(identity, TrajectorySampleIdentityV2)
            for identity in identities
        ):
            raise TypeError("trajectory identities must be a non-empty typed tuple")
        names = tuple(identity.trajectory_id for identity in identities)
        if len(set(names)) != len(names):
            raise ValueError("duplicate trajectory IDs in one batch are forbidden")
        sample_ids = tuple(identity.sample_id for identity in identities)
        if len(set(sample_ids)) != len(sample_ids):
            raise ValueError("duplicate sample IDs in one batch are forbidden")

    def resolve(self, identity: TrajectorySampleIdentityV2) -> PersistentRelationMemoryV2:
        if not isinstance(identity, TrajectorySampleIdentityV2):
            raise TypeError("trajectory memory lookup requires typed identity")
        entry = self._entries.get(identity.trajectory_id)
        if entry is None:
            raise KeyError(identity.trajectory_id)
        next_index, memory = entry
        if identity.sequence_index != next_index:
            raise ValueError("trajectory sequence is out of order")
        return memory

    def memory_for(
        self,
        identity: TrajectorySampleIdentityV2,
        initial: PersistentRelationMemoryV2,
    ) -> PersistentRelationMemoryV2:
        if not isinstance(initial, PersistentRelationMemoryV2) or initial.batch_size != 1:
            raise TypeError("initial trajectory memory must contain one sample")
        if identity.trajectory_id not in self._entries:
            if identity.sequence_index != 0:
                raise ValueError("new trajectory must start at sequence zero")
            return initial
        return self.resolve(identity)

    def advance(
        self,
        identity: TrajectorySampleIdentityV2,
        memory: PersistentRelationMemoryV2,
    ) -> None:
        if not isinstance(memory, PersistentRelationMemoryV2) or memory.batch_size != 1:
            raise TypeError("trajectory registry stores one typed memory sample")
        entry = self._entries.get(identity.trajectory_id)
        expected = 0 if entry is None else entry[0]
        if identity.sequence_index != expected:
            raise ValueError("trajectory sequence is out of order")
        self._entries[identity.trajectory_id] = (expected + 1, memory)

    def state_dict(self) -> dict[str, Any]:
        entries = []
        for trajectory_id, (next_index, memory) in sorted(self._entries.items()):
            tensors = memory.tensorize()
            entries.append(
                {
                    "trajectory_id": trajectory_id,
                    "next_sequence_index": next_index,
                    "orbit": tensors.orbit,
                    "edge": tensors.edge,
                    "global_memory": tensors.global_memory,
                }
            )
        return {
            "schema_version": "crysalis-geometry-v2-trajectory-memory.1.0.0",
            "entries": entries,
        }

    @classmethod
    def from_state_dict(cls, payload: Mapping[str, Any]) -> TrajectoryMemoryStoreV2:
        if set(payload) != {"schema_version", "entries"} or payload[
            "schema_version"
        ] != "crysalis-geometry-v2-trajectory-memory.1.0.0":
            raise ValueError("trajectory memory checkpoint fields are invalid")
        store = cls()
        for item in payload["entries"]:
            memory = PersistentRelationMemoryV2.from_tensors(
                orbit=item["orbit"],
                edge=item["edge"],
                global_memory=item["global_memory"],
            )
            trajectory_id = str(item["trajectory_id"])
            next_index = int(item["next_sequence_index"])
            if trajectory_id in store._entries or next_index <= 0:
                raise ValueError("trajectory memory checkpoint entry is invalid")
            store._entries[trajectory_id] = (next_index, memory)
        return store


def structure_ood_checkpoint_composite(metrics: Mapping[str, float]) -> float:
    unexpected = sorted(set(metrics) - CHECKPOINT_SELECTION_FIELDS)
    missing = sorted(CHECKPOINT_SELECTION_FIELDS - set(metrics))
    if unexpected or missing:
        detail = []
        if unexpected:
            detail.append("unexpected=" + ",".join(unexpected))
        if missing:
            detail.append("missing=" + ",".join(missing))
        raise ValueError(
            "checkpoint selection requires only the frozen structure-OOD composite ("
            + "; ".join(detail)
            + ")"
        )
    values = tuple(float(metrics[field]) for field in sorted(CHECKPOINT_SELECTION_FIELDS))
    if not all(math.isfinite(value) for value in values):
        raise FloatingPointError("structure-OOD checkpoint metrics must be finite")
    return float(sum(values))


class AtomicCheckpointStoreV2:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)

    def save(self, payload: Mapping[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temporary_name = tempfile.mkstemp(
            prefix=f".{self.path.name}.", suffix=".tmp", dir=self.path.parent
        )
        os.close(descriptor)
        temporary = Path(temporary_name)
        try:
            torch.save(dict(payload), temporary)
            with temporary.open("r+b") as source:
                os.fsync(source.fileno())
            os.replace(temporary, self.path)
        finally:
            if temporary.exists():
                temporary.unlink()

    def load(self) -> dict[str, Any]:
        if not self.path.is_file():
            raise FileNotFoundError(self.path)
        payload = torch.load(self.path, map_location="cpu", weights_only=True)
        if not isinstance(payload, dict):
            raise ValueError("Geometry V2 checkpoint must contain a mapping")
        return payload


@dataclass(frozen=True, slots=True)
class TrainingResumeStateV2:
    next_batch_index: int
    best_structure_ood_composite: float
    best_batch_index: int | None
    best_model_state: Mapping[str, Any] | None
    best_optimizer_state: Mapping[str, Any] | None
    trajectory_memory_store: TrajectoryMemoryStoreV2
    best_trajectory_memory_state: Mapping[str, Any] | None
    best_training_rng_state: Mapping[str, Any] | None
    validation_history: tuple[tuple[int, float], ...]


def restore_training_checkpoint(
    model: FormalGeometryV2Model,
    optimizer: torch.optim.Optimizer,
    store: AtomicCheckpointStoreV2,
    registered_generators: Mapping[str, RegisteredRngV2] | None = None,
) -> TrainingResumeStateV2:
    payload = store.load()
    required = {
        "schema_version",
        "next_batch_index",
        "current_model_state",
        "current_optimizer_state",
        "trajectory_memory_store_state",
        "training_rng_state",
        "best_structure_ood_composite",
        "best_batch_index",
        "best_model_state",
        "best_optimizer_state",
        "best_trajectory_memory_store_state",
        "best_training_rng_state",
        "validation_history",
    }
    if set(payload) != required or payload["schema_version"] != TRAINING_CHECKPOINT_SCHEMA:
        raise ValueError("Geometry V2 resume checkpoint fields are invalid")
    next_batch = payload["next_batch_index"]
    best = payload["best_structure_ood_composite"]
    if type(next_batch) is not int or next_batch < 0:
        raise ValueError("resume checkpoint next batch index is invalid")
    if not isinstance(best, (int, float)) or math.isnan(float(best)):
        raise ValueError("resume checkpoint best composite is invalid")
    best_batch = payload["best_batch_index"]
    if best_batch is not None and (type(best_batch) is not int or best_batch < 0):
        raise ValueError("resume checkpoint best batch index is invalid")
    raw_history = payload["validation_history"]
    if not isinstance(raw_history, (tuple, list)):
        raise ValueError("resume checkpoint validation history is invalid")
    history = tuple((int(item[0]), float(item[1])) for item in raw_history)
    model.load_state_dict(payload["current_model_state"])
    optimizer.load_state_dict(payload["current_optimizer_state"])
    rng_state = payload["training_rng_state"]
    if not isinstance(rng_state, Mapping):
        raise ValueError("resume checkpoint RNG state is invalid")
    restore_training_rng_state_v2(rng_state, registered_generators)
    trajectory_store = TrajectoryMemoryStoreV2.from_state_dict(
        payload["trajectory_memory_store_state"]
    )
    best_rng_state = payload["best_training_rng_state"]
    if best_rng_state is not None and not isinstance(best_rng_state, Mapping):
        raise ValueError("best checkpoint RNG state is invalid")
    return TrainingResumeStateV2(
        next_batch,
        float(best),
        best_batch,
        payload["best_model_state"],
        payload["best_optimizer_state"],
        trajectory_store,
        payload["best_trajectory_memory_store_state"],
        best_rng_state,
        history,
    )


class TrainingJournalV2:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)

    def append(
        self,
        *,
        batch_index: int,
        loss: float,
        resource_telemetry: Mapping[str, int | float | str | None],
        formal_endpoint_loss: float | None = None,
        formal_endpoint_receipt: FormalEndpointReceiptV2 | None = None,
    ) -> None:
        if type(batch_index) is not int or batch_index < 0:
            raise ValueError("training metric batch index must be non-negative")
        if not math.isfinite(float(loss)):
            raise FloatingPointError("training loss must be finite")
        record = {
            "schema_version": TRAINING_METRIC_SCHEMA,
            "batch_index": batch_index,
            "loss": float(loss),
            "resource_telemetry": dict(resource_telemetry),
            "formal_endpoint_loss": formal_endpoint_loss,
            "formal_endpoint_receipt": (
                _endpoint_receipt_summary(formal_endpoint_receipt)
                if formal_endpoint_receipt is not None
                else None
            ),
        }
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8", newline="\n") as target:
            target.write(json.dumps(record, sort_keys=True) + "\n")
            target.flush()
            os.fsync(target.fileno())


def collect_resource_telemetry(started_at: float) -> dict[str, int | float | None]:
    rss_bytes: int | None = None
    try:
        import psutil

        rss_bytes = int(psutil.Process().memory_info().rss)
    except ImportError:
        pass
    cuda_peak = (
        int(torch.cuda.max_memory_allocated()) if torch.cuda.is_available() else None
    )
    return {
        "wall_seconds": float(time.perf_counter() - started_at),
        "rss_bytes": rss_bytes,
        "cuda_peak_allocated_bytes": cuda_peak,
    }


@dataclass(frozen=True, slots=True)
class TrainingRunReceiptV2:
    status: str
    resumed_from_batch: int
    next_batch_index: int
    best_structure_ood_composite: float
    checkpoint_path: str
    metrics_path: str
    formal_alignments: tuple[FormalTrainingAlignmentReceiptV2, ...]


@dataclass(frozen=True, slots=True)
class FormalEndpointTrainingRequestV2:
    state: SymmetryAssemblyState
    context: torch.Tensor
    wyckoff_id: torch.Tensor
    free_parameter_mask: torch.Tensor
    registered_seed: int
    candidate_free_dof: int
    dependencies: FormalEndpointDependenciesV2
    loss_builder: Callable[[FormalEndpointResultV2], torch.Tensor]

    def __post_init__(self) -> None:
        if not isinstance(self.state, SymmetryAssemblyState):
            raise TypeError("formal alignment request requires SymmetryAssemblyState")
        if not isinstance(self.dependencies, FormalEndpointDependenciesV2):
            raise TypeError("formal alignment request requires validated dependencies")
        if not callable(self.loss_builder):
            raise TypeError("formal alignment request loss builder must be callable")

    def endpoint_kwargs(self) -> dict[str, Any]:
        return {
            "state": self.state,
            "context": self.context,
            "wyckoff_id": self.wyckoff_id,
            "free_parameter_mask": self.free_parameter_mask,
            "registered_seed": self.registered_seed,
            "candidate_free_dof": self.candidate_free_dof,
            "dependencies": self.dependencies,
        }


@dataclass(frozen=True, slots=True)
class FormalEndpointBatchRequestV2:
    state: SymmetryAssemblyState
    wyckoff_id: torch.Tensor
    free_parameter_mask: torch.Tensor
    registered_seed: int
    candidate_free_dof: int
    guide_objective: GuideObjectiveProtocolV2
    projector: ProjectorProtocolV2
    loss_builder: Callable[[FormalEndpointResultV2], torch.Tensor]
    sample_index: int
    relation_calibration: RelationGeometryCalibrationV2

    def __post_init__(self) -> None:
        if not isinstance(self.state, SymmetryAssemblyState):
            raise TypeError("formal batch endpoint requires SymmetryAssemblyState")
        if not callable(getattr(self.guide_objective, "evaluate", None)):
            raise TypeError("formal batch requires an injected Guide objective")
        if not callable(getattr(self.projector, "project", None)):
            raise TypeError("formal batch requires a Projector")
        if not callable(self.loss_builder):
            raise TypeError("formal batch loss builder must be callable")
        if type(self.sample_index) is not int or self.sample_index < 0:
            raise ValueError("formal endpoint sample index must be non-negative")
        if not isinstance(self.relation_calibration, RelationGeometryCalibrationV2):
            raise TypeError("formal batch requires frozen relation calibration")


@dataclass(frozen=True, slots=True)
class FormalGeometryTrainingBatchV2:
    train_fit: TrainFitBatchV2
    model_input: RelationModelInputV2
    endpoint: FormalEndpointBatchRequestV2 | None
    sample_identities: tuple[TrajectorySampleIdentityV2, ...]

    def __post_init__(self) -> None:
        if not isinstance(self.train_fit, TrainFitBatchV2):
            raise TypeError("Geometry V2 requires sanitized TrainFitBatchV2")
        if not isinstance(self.model_input, RelationModelInputV2):
            raise TypeError("Geometry V2 requires sanitized RelationModelInputV2")
        if self.model_input.provenance.kind != "public_train_fit_forward_deconstruction":
            raise ValueError("training model input must have train-fit provenance")
        if self.endpoint is not None and not isinstance(
            self.endpoint, FormalEndpointBatchRequestV2
        ):
            raise TypeError("formal endpoint request must be typed")
        cardinality = self.model_input.active_orbit_graph.batch_size
        if not (
            len(self.train_fit.events)
            == len(self.sample_identities)
            == cardinality
        ):
            raise ValueError(
                "event, model-input, and trajectory identity cardinality must match"
            )
        if any(
            not isinstance(identity, TrajectorySampleIdentityV2)
            for identity in self.sample_identities
        ):
            raise TypeError("training batch trajectory identities must be typed")
        if len({item.trajectory_id for item in self.sample_identities}) != cardinality:
            raise ValueError("duplicate trajectory IDs in one batch are forbidden")
        if len({item.sample_id for item in self.sample_identities}) != cardinality:
            raise ValueError("duplicate sample IDs in one batch are forbidden")
        if any(
            identity.sample_id != event.event_id
            for identity, event in zip(
                self.sample_identities, self.train_fit.events, strict=True
            )
        ):
            raise ValueError("trajectory sample IDs must match train-fit event IDs")
        if self.endpoint is not None and self.endpoint.sample_index >= cardinality:
            raise ValueError("formal endpoint sample index is outside the batch")


@dataclass(frozen=True, slots=True)
class FormalTrainingAlignmentReceiptV2:
    batch_index: int
    loss: float
    endpoint_receipt: FormalEndpointReceiptV2


def _endpoint_receipt_summary(receipt: FormalEndpointReceiptV2) -> dict[str, Any]:
    projector = receipt.projector
    return {
        "accepted": receipt.accepted,
        "failure_reason_codes": receipt.failure_reason_codes,
        "attempt_count": receipt.attempt_count,
        "resampled": receipt.resampled,
        "sampling": {
            "registered_seed": receipt.sampling.registered_seed,
            "sample_index": receipt.sampling.sample_index,
            "namespace": receipt.sampling.namespace,
            "sample_count": receipt.sampling.sample_count,
            "integration_steps": receipt.sampling.integration_steps,
            "velocity_evaluations": receipt.sampling.velocity_evaluations,
            "wrap_count": receipt.sampling.wrap_count,
        },
        "projector": projector.to_dict() if hasattr(projector, "to_dict") else None,
    }


def _memory_sample(
    memory: PersistentRelationMemoryV2, index: int
) -> PersistentRelationMemoryV2:
    if type(index) is not int or not 0 <= index < memory.batch_size:
        raise IndexError("trajectory memory sample index is outside the batch")
    tensors = memory.tensorize()
    return PersistentRelationMemoryV2.from_tensors(
        orbit=tensors.orbit[index : index + 1],
        edge=tensors.edge[index : index + 1],
        global_memory=tensors.global_memory[index : index + 1],
    )


def _stack_memories(
    memories: Sequence[PersistentRelationMemoryV2],
) -> PersistentRelationMemoryV2:
    if not memories:
        raise ValueError("cannot assemble an empty trajectory memory batch")
    shapes = {(item.max_orbits, item.max_edges) for item in memories}
    if len(shapes) != 1 or any(item.batch_size != 1 for item in memories):
        raise ValueError("trajectory memories must be compatible single samples")
    tensors = [item.tensorize() for item in memories]
    return PersistentRelationMemoryV2.from_tensors(
        orbit=torch.cat([item.orbit for item in tensors], dim=0),
        edge=torch.cat([item.edge for item in tensors], dim=0),
        global_memory=torch.cat([item.global_memory for item in tensors], dim=0),
    )


def _replace_memory_sample(
    memory: PersistentRelationMemoryV2,
    index: int,
    replacement: PersistentRelationMemoryV2,
) -> PersistentRelationMemoryV2:
    samples = [_memory_sample(memory, item) for item in range(memory.batch_size)]
    if replacement.batch_size != 1:
        raise ValueError("endpoint memory transition must contain one sample")
    samples[index] = replacement
    return _stack_memories(samples)


def _slice_model_input(
    model_input: RelationModelInputV2, index: int
) -> RelationModelInputV2:
    graph = model_input.active_orbit_graph
    if type(index) is not int or not 0 <= index < graph.batch_size:
        raise IndexError("formal endpoint sample index is outside the batch")
    sliced_graph = ActiveOrbitGraphV2(
        active_orbits=graph.active_orbits[index : index + 1],
        active_orbit_mask=graph.active_orbit_mask[index : index + 1],
        edge_index=graph.edge_index[index : index + 1],
        edge_mask=graph.edge_mask[index : index + 1],
        triplet_index=graph.triplet_index[index : index + 1],
        triplet_mask=graph.triplet_mask[index : index + 1],
    )
    return RelationModelInputV2(
        composition=model_input.composition[index : index + 1],
        target_sg=model_input.target_sg[index : index + 1],
        lattice=model_input.lattice[index : index + 1],
        active_orbit_graph=sliced_graph,
        candidate_query=model_input.candidate_query[index : index + 1],
        persistent_memory=_memory_sample(model_input.persistent_memory, index),
        provenance=model_input.provenance,
    )


def _checkpoint_payload(
    model: FormalGeometryV2Model,
    optimizer: torch.optim.Optimizer,
    *,
    next_batch_index: int,
    best_structure_ood_composite: float,
    best_batch_index: int | None,
    best_model_state: Mapping[str, Any] | None,
    best_optimizer_state: Mapping[str, Any] | None,
    trajectory_memory_store: TrajectoryMemoryStoreV2,
    best_trajectory_memory_state: Mapping[str, Any] | None,
    best_training_rng_state: Mapping[str, Any] | None,
    registered_generators: Mapping[str, RegisteredRngV2],
    validation_history: tuple[tuple[int, float], ...],
) -> dict[str, Any]:
    return {
        "schema_version": TRAINING_CHECKPOINT_SCHEMA,
        "next_batch_index": next_batch_index,
        "current_model_state": deepcopy(model.state_dict()),
        "current_optimizer_state": deepcopy(optimizer.state_dict()),
        "trajectory_memory_store_state": deepcopy(trajectory_memory_store.state_dict()),
        "training_rng_state": capture_training_rng_state_v2(registered_generators),
        "best_structure_ood_composite": best_structure_ood_composite,
        "best_batch_index": best_batch_index,
        "best_model_state": deepcopy(best_model_state),
        "best_optimizer_state": deepcopy(best_optimizer_state),
        "best_trajectory_memory_store_state": deepcopy(
            best_trajectory_memory_state
        ),
        "best_training_rng_state": deepcopy(best_training_rng_state),
        "validation_history": validation_history,
    }


def run_geometry_v2_training(
    *,
    model: FormalGeometryV2Model,
    optimizer: torch.optim.Optimizer,
    batches: Sequence[FormalGeometryTrainingBatchV2],
    train_step: Callable[[FormalGeometryV2Model, FormalGeometryTrainingBatchV2, int], torch.Tensor],
    validation_metrics: Callable[[], Mapping[str, float]],
    validation_interval: int,
    checkpoint_path: str | Path,
    metrics_path: str | Path,
    resume: bool,
    registered_generators: Mapping[str, RegisteredRngV2] | None = None,
) -> TrainingRunReceiptV2:
    if not isinstance(model, FormalGeometryV2Model):
        raise TypeError("production training requires FormalGeometryV2Model")
    generators = _validate_registered_generators(registered_generators)
    audit_formal_runtime_objects(
        model,
        train_step,
        validation_metrics,
        batches,
        allowed_rng_objects=tuple(generators.values()),
    )
    if type(validation_interval) is not int or validation_interval <= 0:
        raise ValueError("frozen validation interval must be a positive integer")
    if any(not isinstance(batch, FormalGeometryTrainingBatchV2) for batch in batches):
        raise TypeError("production training requires sanitized typed batches")
    for batch in batches:
        if batch.endpoint is not None:
            validate_relation_geometry_calibration_contract_v2(
                batch.endpoint.relation_calibration
            )
    store = AtomicCheckpointStoreV2(checkpoint_path)
    journal = TrainingJournalV2(metrics_path)
    start_batch = 0
    best = math.inf
    best_batch: int | None = None
    best_model_state: Mapping[str, Any] | None = None
    best_optimizer_state: Mapping[str, Any] | None = None
    best_trajectory_memory_state: Mapping[str, Any] | None = None
    best_training_rng_state: Mapping[str, Any] | None = None
    trajectory_store = TrajectoryMemoryStoreV2()
    validation_history: tuple[tuple[int, float], ...] = ()
    if resume:
        if not store.path.is_file():
            raise FileNotFoundError("resume requested but checkpoint is missing")
        resume_state = restore_training_checkpoint(
            model, optimizer, store, generators
        )
        start_batch = resume_state.next_batch_index
        best = resume_state.best_structure_ood_composite
        best_batch = resume_state.best_batch_index
        best_model_state = resume_state.best_model_state
        best_optimizer_state = resume_state.best_optimizer_state
        trajectory_store = resume_state.trajectory_memory_store
        best_trajectory_memory_state = (
            resume_state.best_trajectory_memory_state
        )
        best_training_rng_state = resume_state.best_training_rng_state
        validation_history = resume_state.validation_history
    if start_batch > len(batches):
        raise ValueError("resume checkpoint is beyond the frozen training batches")

    started_at = time.perf_counter()
    next_batch = start_batch
    alignments: list[FormalTrainingAlignmentReceiptV2] = []
    adapter = TrainingGeometryAdapterV2()
    if not resume:
        store.save(
            _checkpoint_payload(
                model,
                optimizer,
                next_batch_index=0,
                best_structure_ood_composite=best,
                best_batch_index=best_batch,
                best_model_state=best_model_state,
                best_optimizer_state=best_optimizer_state,
                trajectory_memory_store=trajectory_store,
                best_trajectory_memory_state=best_trajectory_memory_state,
                best_training_rng_state=best_training_rng_state,
                registered_generators=generators,
                validation_history=validation_history,
            )
        )
    try:
        for batch_index in range(start_batch, len(batches)):
            supplied_batch = batches[batch_index]
            if supplied_batch.train_fit.batch_index != batch_index:
                raise ValueError("typed train-fit batch index does not match frozen order")
            trajectory_store.validate_batch(supplied_batch.sample_identities)
            initial_memory = supplied_batch.model_input.persistent_memory
            assembled_memory = _stack_memories(
                tuple(
                    trajectory_store.memory_for(
                        identity, _memory_sample(initial_memory, sample_index)
                    )
                    for sample_index, identity in enumerate(
                        supplied_batch.sample_identities
                    )
                )
            )
            effective_input = replace(
                supplied_batch.model_input, persistent_memory=assembled_memory
            )
            batch = replace(supplied_batch, model_input=effective_input)
            audit_formal_runtime_objects(
                batch,
                train_step,
                validation_metrics,
                allowed_rng_objects=tuple(generators.values()),
            )
            request = batch.endpoint
            scheduled = adapter.requires_formal_alignment(batch_index)
            if scheduled and not isinstance(request, FormalEndpointBatchRequestV2):
                raise ValueError("scheduled formal alignment batch lacks a valid request")
            if not scheduled and request is not None:
                raise ValueError("formal endpoint request supplied on a non-alignment batch")
            endpoint_loss: torch.Tensor | None = None
            endpoint_receipt: FormalEndpointReceiptV2 | None = None
            if scheduled:
                assert request is not None
                prepared = model.prepare_endpoint(
                    state=request.state,
                    model_input=_slice_model_input(
                        batch.model_input, request.sample_index
                    ),
                    wyckoff_id=request.wyckoff_id,
                    free_parameter_mask=request.free_parameter_mask,
                    registered_seed=request.registered_seed,
                    candidate_free_dof=request.candidate_free_dof,
                    guide_objective=request.guide_objective,
                    projector=request.projector,
                    relation_calibration=request.relation_calibration,
                )
                dependencies = prepared.endpoint_kwargs["dependencies"]
                if not isinstance(dependencies, FormalEndpointDependenciesV2) or (
                    dependencies.velocity_field is not model.flow
                ):
                    raise RuntimeError(
                        "scheduled formal endpoint must use the checkpointed model flow"
                    )
                audit_formal_runtime_objects(
                    model,
                    train_step,
                    validation_metrics,
                    batch,
                    request.loss_builder,
                    dependencies,
                    allowed_rng_objects=tuple(generators.values()),
                )
                result = adapter.run_alignment(batch_index, **prepared.endpoint_kwargs)
                if result is None:
                    raise RuntimeError("scheduled formal alignment did not run")
                result = model.apply_memory_transition(result, prepared)
                audit_formal_endpoint_receipt(result.receipt)
                endpoint_loss = request.loss_builder(result)
                if (
                    not isinstance(endpoint_loss, torch.Tensor)
                    or endpoint_loss.ndim != 0
                    or not bool(torch.isfinite(endpoint_loss))
                ):
                    raise ValueError("scheduled formal endpoint loss must be a finite scalar")
                endpoint_receipt = result.receipt
                if not isinstance(result.updated_memory, PersistentRelationMemoryV2):
                    raise RuntimeError(
                        "scheduled formal endpoint did not return typed memory"
                    )
                assembled_memory = _replace_memory_sample(
                    assembled_memory,
                    request.sample_index,
                    result.updated_memory,
                )
                effective_input = replace(
                    effective_input, persistent_memory=assembled_memory
                )
                batch = replace(batch, model_input=effective_input)
            base_loss = train_step(model, batch, batch_index)
            if (
                not isinstance(base_loss, torch.Tensor)
                or base_loss.ndim != 0
                or not bool(torch.isfinite(base_loss))
            ):
                raise ValueError("Geometry V2 train step must return a finite scalar tensor")
            total_loss = base_loss + (
                endpoint_loss if endpoint_loss is not None else base_loss.new_zeros(())
            )
            optimizer.zero_grad(set_to_none=True)
            total_loss.backward()
            optimizer.step()
            loss = float(total_loss.detach().cpu().item())
            if not math.isfinite(loss):
                raise FloatingPointError("Geometry V2 training loss is non-finite")
            endpoint_loss_value = (
                float(endpoint_loss.detach().cpu().item())
                if endpoint_loss is not None
                else None
            )
            candidate_store = TrajectoryMemoryStoreV2.from_state_dict(
                trajectory_store.state_dict()
            )
            for sample_index, identity in enumerate(batch.sample_identities):
                candidate_store.advance(
                    identity, _memory_sample(assembled_memory, sample_index)
                )
            next_batch = batch_index + 1
            if next_batch % validation_interval == 0 or next_batch == len(batches):
                composite = structure_ood_checkpoint_composite(validation_metrics())
                validation_history = (*validation_history, (batch_index, composite))
                if composite < best:
                    best = composite
                    best_batch = batch_index
                    best_model_state = deepcopy(model.state_dict())
                    best_optimizer_state = deepcopy(optimizer.state_dict())
                    best_trajectory_memory_state = deepcopy(
                        candidate_store.state_dict()
                    )
                    best_training_rng_state = capture_training_rng_state_v2(
                        generators
                    )
            store.save(
                _checkpoint_payload(
                    model,
                    optimizer,
                    next_batch_index=next_batch,
                    best_structure_ood_composite=best,
                    best_batch_index=best_batch,
                    best_model_state=best_model_state,
                    best_optimizer_state=best_optimizer_state,
                    trajectory_memory_store=candidate_store,
                    best_trajectory_memory_state=best_trajectory_memory_state,
                    best_training_rng_state=best_training_rng_state,
                    registered_generators=generators,
                    validation_history=validation_history,
                )
            )
            trajectory_store = candidate_store
            journal.append(
                batch_index=batch_index,
                loss=loss,
                resource_telemetry=collect_resource_telemetry(started_at),
                formal_endpoint_loss=endpoint_loss_value,
                formal_endpoint_receipt=endpoint_receipt,
            )
            if endpoint_receipt is not None and endpoint_loss_value is not None:
                alignments.append(
                    FormalTrainingAlignmentReceiptV2(
                        batch_index=batch_index,
                        loss=endpoint_loss_value,
                        endpoint_receipt=endpoint_receipt,
                    )
                )
    except KeyboardInterrupt:
        durable = restore_training_checkpoint(model, optimizer, store, generators)
        return TrainingRunReceiptV2(
            status="INTERRUPTED",
            resumed_from_batch=start_batch,
            next_batch_index=durable.next_batch_index,
            best_structure_ood_composite=durable.best_structure_ood_composite,
            checkpoint_path=str(store.path),
            metrics_path=str(journal.path),
            formal_alignments=tuple(alignments),
        )

    if not batches and best_model_state is None:
        composite = structure_ood_checkpoint_composite(validation_metrics())
        best = composite
        best_batch = 0
        best_model_state = deepcopy(model.state_dict())
        best_optimizer_state = deepcopy(optimizer.state_dict())
        best_trajectory_memory_state = deepcopy(trajectory_store.state_dict())
        best_training_rng_state = capture_training_rng_state_v2(generators)
        validation_history = ((0, composite),)
    if best_model_state is None or best_optimizer_state is None:
        raise RuntimeError("training completed without a frozen validation candidate")
    model.load_state_dict(best_model_state)
    optimizer.load_state_dict(dict(best_optimizer_state))
    if best_trajectory_memory_state is None or best_training_rng_state is None:
        raise RuntimeError("training completed without complete best state")
    trajectory_store = TrajectoryMemoryStoreV2.from_state_dict(
        best_trajectory_memory_state
    )
    restore_training_rng_state_v2(best_training_rng_state, generators)
    store.save(
        _checkpoint_payload(
            model,
            optimizer,
            next_batch_index=len(batches),
            best_structure_ood_composite=best,
            best_batch_index=best_batch,
            best_model_state=best_model_state,
            best_optimizer_state=best_optimizer_state,
            trajectory_memory_store=trajectory_store,
            best_trajectory_memory_state=best_trajectory_memory_state,
            best_training_rng_state=best_training_rng_state,
            registered_generators=generators,
            validation_history=validation_history,
        )
    )
    return TrainingRunReceiptV2(
        status="COMPLETE",
        resumed_from_batch=start_batch,
        next_batch_index=len(batches),
        best_structure_ood_composite=best,
        checkpoint_path=str(store.path),
        metrics_path=str(journal.path),
        formal_alignments=tuple(alignments),
    )


__all__ = [
    "CHECKPOINT_SELECTION_FIELDS",
    "TRAINING_CHECKPOINT_SCHEMA",
    "TRAINING_METRIC_SCHEMA",
    "TRAINING_RNG_SCHEMA",
    "AtomicCheckpointStoreV2",
    "FormalEndpointTrainingRequestV2",
    "FormalEndpointBatchRequestV2",
    "FormalGeometryTrainingBatchV2",
    "FormalTrainingAlignmentReceiptV2",
    "TrainingJournalV2",
    "TrainingResumeStateV2",
    "TrainingRunReceiptV2",
    "TrajectoryMemoryStoreV2",
    "TrajectorySampleIdentityV2",
    "collect_resource_telemetry",
    "capture_training_rng_state_v2",
    "restore_training_checkpoint",
    "restore_training_rng_state_v2",
    "run_geometry_v2_training",
    "structure_ood_checkpoint_composite",
]
