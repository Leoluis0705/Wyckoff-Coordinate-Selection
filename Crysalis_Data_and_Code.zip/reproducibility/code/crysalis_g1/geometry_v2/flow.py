from __future__ import annotations

import math
from collections.abc import Mapping
from typing import Any

import torch
from torch import nn


FLOW_CONTEXT_DIM = 192
TIME_EMBEDDING_DIM = 16
FLOW_WIDTH = 256
FLOW_RESIDUAL_BLOCKS = 4
FLOW_CHECKPOINT_SCHEMA = "crysalis-geometry-v2-flow.1.0.0"


def _validate_torus_inputs(u: torch.Tensor, mask: torch.Tensor) -> None:
    if u.ndim != 2 or u.shape[1] != 3:
        raise ValueError("torus coordinates must have shape [B,3]")
    if mask.shape != u.shape or mask.dtype != torch.bool:
        raise ValueError("free-parameter mask must be boolean with shape [B,3]")
    if not torch.isfinite(u).all():
        raise ValueError("torus coordinates must be finite")


def periodic_coordinate_encoding(
    u: torch.Tensor, free_parameter_mask: torch.Tensor
) -> torch.Tensor:
    """Interleaved sin/cos features with fixed axes explicitly masked."""
    _validate_torus_inputs(u, free_parameter_mask)
    phase = 2.0 * math.pi * torch.remainder(u, 1.0)
    encoded = torch.stack((torch.sin(phase), torch.cos(phase)), dim=-1)
    weights = free_parameter_mask.to(device=u.device, dtype=u.dtype).unsqueeze(-1)
    return (encoded * weights).flatten(1)


def sinusoidal_time_embedding(tau: torch.Tensor) -> torch.Tensor:
    if tau.ndim == 2 and tau.shape[1] == 1:
        tau = tau[:, 0]
    if tau.ndim != 1 or not torch.is_floating_point(tau):
        raise ValueError("tau must be a floating tensor with shape [B]")
    if not torch.isfinite(tau).all():
        raise ValueError("tau must be finite")
    frequencies = torch.arange(
        1,
        TIME_EMBEDDING_DIM // 2 + 1,
        device=tau.device,
        dtype=tau.dtype,
    )
    phase = 2.0 * math.pi * tau.unsqueeze(-1) * frequencies
    return torch.stack((torch.sin(phase), torch.cos(phase)), dim=-1).flatten(1)


class ResidualVelocityBlockV2(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.linear_in = nn.Linear(FLOW_WIDTH, FLOW_WIDTH)
        self.linear_out = nn.Linear(FLOW_WIDTH, FLOW_WIDTH)
        self.activation = nn.SiLU()

    def forward(self, hidden: torch.Tensor) -> torch.Tensor:
        residual = self.linear_out(self.activation(self.linear_in(hidden)))
        return self.activation(hidden + residual)


class ConditionalToroidalFlowV2(nn.Module):
    """Conditional velocity field on masked Wyckoff torus coordinates."""

    def __init__(self, *, max_wyckoff_positions: int = 256) -> None:
        super().__init__()
        if type(max_wyckoff_positions) is not int or max_wyckoff_positions <= 0:
            raise ValueError("max_wyckoff_positions must be a positive integer")
        self.max_wyckoff_positions = max_wyckoff_positions
        self.wyckoff_embedding = nn.Embedding(max_wyckoff_positions, 16)
        input_width = 6 + TIME_EMBEDDING_DIM + FLOW_CONTEXT_DIM + 16 + 3
        self.input_projection = nn.Linear(input_width, FLOW_WIDTH)
        self.input_activation = nn.SiLU()
        self.residual_blocks = nn.ModuleList(
            ResidualVelocityBlockV2() for _ in range(FLOW_RESIDUAL_BLOCKS)
        )
        self.output_projection = nn.Linear(FLOW_WIDTH, 3)

    def forward(
        self,
        u: torch.Tensor,
        tau: torch.Tensor,
        context: torch.Tensor,
        wyckoff_id: torch.Tensor,
        free_parameter_mask: torch.Tensor,
    ) -> torch.Tensor:
        _validate_torus_inputs(u, free_parameter_mask)
        batch_size = u.shape[0]
        if context.shape != (batch_size, FLOW_CONTEXT_DIM):
            raise ValueError("context must have shape [B,192]")
        if not torch.isfinite(context).all():
            raise ValueError("context must be finite")
        if wyckoff_id.shape != (batch_size,) or wyckoff_id.dtype != torch.long:
            raise ValueError("wyckoff_id must be int64 with shape [B]")
        if bool(((wyckoff_id < 0) | (wyckoff_id >= self.max_wyckoff_positions)).any()):
            raise ValueError("wyckoff_id is outside the configured embedding range")
        time = sinusoidal_time_embedding(tau)
        if time.shape[0] != batch_size:
            raise ValueError("tau batch size must match torus coordinates")

        dtype = context.dtype
        device = context.device
        if u.device != device or free_parameter_mask.device != device:
            raise ValueError("flow tensors must be on the same device")
        features = torch.cat(
            (
                periodic_coordinate_encoding(u.to(dtype), free_parameter_mask),
                time.to(device=device, dtype=dtype),
                context,
                self.wyckoff_embedding(wyckoff_id.to(device)),
                free_parameter_mask.to(dtype=dtype),
            ),
            dim=-1,
        )
        hidden = self.input_activation(self.input_projection(features))
        for block in self.residual_blocks:
            hidden = block(hidden)
        velocity = self.output_projection(hidden)
        return velocity * free_parameter_mask.to(dtype=velocity.dtype)

    def checkpoint_state(self) -> dict[str, Any]:
        return {
            "schema_version": FLOW_CHECKPOINT_SCHEMA,
            "config": {"max_wyckoff_positions": self.max_wyckoff_positions},
            "model_state_dict": self.state_dict(),
        }

    @classmethod
    def from_checkpoint_state(
        cls, payload: Mapping[str, Any]
    ) -> ConditionalToroidalFlowV2:
        if set(payload) != {"schema_version", "config", "model_state_dict"}:
            raise ValueError("flow checkpoint has unexpected fields")
        if payload["schema_version"] != FLOW_CHECKPOINT_SCHEMA:
            raise ValueError("unsupported flow checkpoint schema")
        config = payload["config"]
        if not isinstance(config, Mapping) or set(config) != {"max_wyckoff_positions"}:
            raise ValueError("flow checkpoint config is invalid")
        state_dict = payload["model_state_dict"]
        if not isinstance(state_dict, Mapping):
            raise ValueError("flow checkpoint state_dict is invalid")
        model = cls(max_wyckoff_positions=int(config["max_wyckoff_positions"]))
        model.load_state_dict(state_dict, strict=True)
        return model


__all__ = [
    "FLOW_CHECKPOINT_SCHEMA",
    "FLOW_CONTEXT_DIM",
    "FLOW_RESIDUAL_BLOCKS",
    "FLOW_WIDTH",
    "TIME_EMBEDDING_DIM",
    "ConditionalToroidalFlowV2",
    "ResidualVelocityBlockV2",
    "periodic_coordinate_encoding",
    "sinusoidal_time_embedding",
]
