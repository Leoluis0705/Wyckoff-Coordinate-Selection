from __future__ import annotations

import torch
from scipy.optimize import linear_sum_assignment  # type: ignore[import-untyped]
from torch.nn import functional as functional

from .training_batch import FlowMatchingBatchV2


def _masked_mean(values: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    if mask.shape != values.shape:
        raise ValueError("loss mask must match the value shape")
    weights = mask.to(device=values.device, dtype=values.dtype)
    return (values * weights).sum() / weights.sum().clamp_min(1.0)


def flow_matching_loss(
    predicted_velocity: torch.Tensor, batch: FlowMatchingBatchV2
) -> torch.Tensor:
    if predicted_velocity.shape != batch.target_velocity.shape:
        raise ValueError("predicted velocity must have shape [B,3]")
    error = (predicted_velocity - batch.target_velocity).unsqueeze(-1)
    quadratic = error.transpose(1, 2).bmm(batch.metric).bmm(error).flatten()
    degrees = batch.free_parameter_mask.sum(dim=1)
    per_row = quadratic / degrees.clamp_min(1).to(quadratic.dtype)
    return _masked_mean(per_row, degrees > 0)


def relation_realization_loss(
    predicted_mean: torch.Tensor,
    realized_target: torch.Tensor,
    predicted_log_scale: torch.Tensor,
    observable_mask: torch.Tensor,
) -> torch.Tensor:
    if not (
        predicted_mean.shape
        == realized_target.shape
        == predicted_log_scale.shape
        == observable_mask.shape
    ):
        raise ValueError("relation tensors and observable mask must share a shape")
    residual = predicted_mean - realized_target
    nll = 0.5 * residual.square() * torch.exp(-2.0 * predicted_log_scale)
    nll = nll + predicted_log_scale
    return _masked_mean(nll, observable_mask)


def nearest_neighbor_loss(
    predicted_distance: torch.Tensor,
    target_distance: torch.Tensor,
    pair_mask: torch.Tensor,
) -> torch.Tensor:
    if predicted_distance.shape != target_distance.shape:
        raise ValueError("nearest-neighbor tensors must share a shape")
    return _masked_mean(
        functional.smooth_l1_loss(predicted_distance, target_distance, reduction="none"),
        pair_mask,
    )


def shell_pair_loss(
    predicted_logits: torch.Tensor,
    target_probabilities: torch.Tensor,
    pair_mask: torch.Tensor,
) -> torch.Tensor:
    if predicted_logits.shape != target_probabilities.shape:
        raise ValueError("shell logits and target probabilities must share a shape")
    if pair_mask.shape != predicted_logits.shape[:-1]:
        raise ValueError("shell-pair mask must match all non-class dimensions")
    cross_entropy = -(
        target_probabilities * functional.log_softmax(predicted_logits, dim=-1)
    ).sum(dim=-1)
    return _masked_mean(cross_entropy, pair_mask)


def angle_loss(
    predicted_angle: torch.Tensor,
    target_angle: torch.Tensor,
    angle_mask: torch.Tensor,
) -> torch.Tensor:
    if predicted_angle.shape != target_angle.shape:
        raise ValueError("angle tensors must share a shape")
    return _masked_mean(1.0 - torch.cos(predicted_angle - target_angle), angle_mask)


def coordination_loss(
    predicted_coordination: torch.Tensor,
    target_coordination: torch.Tensor,
    coordination_mask: torch.Tensor,
) -> torch.Tensor:
    if predicted_coordination.shape != target_coordination.shape:
        raise ValueError("coordination tensors must share a shape")
    return _masked_mean(
        functional.smooth_l1_loss(
            predicted_coordination, target_coordination, reduction="none"
        ),
        coordination_mask,
    )


def equivalent_orbit_rmsd_loss(
    predicted_cartesian: torch.Tensor,
    equivalent_target_cartesian: torch.Tensor,
    atom_mask: torch.Tensor,
) -> torch.Tensor:
    if predicted_cartesian.ndim != 3 or predicted_cartesian.shape[-1] != 3:
        raise ValueError("predicted Cartesian coordinates must have shape [B,M,3]")
    if (
        equivalent_target_cartesian.ndim != 4
        or equivalent_target_cartesian.shape[0] != predicted_cartesian.shape[0]
        or equivalent_target_cartesian.shape[2:] != predicted_cartesian.shape[1:]
        or equivalent_target_cartesian.shape[1] == 0
    ):
        raise ValueError("equivalent Cartesian targets must have shape [B,K,M,3]")
    if atom_mask.shape != predicted_cartesian.shape[:2]:
        raise ValueError("atom mask must have shape [B,M]")
    batch_losses: list[torch.Tensor] = []
    for batch_index in range(predicted_cartesian.shape[0]):
        active = atom_mask[batch_index].nonzero(as_tuple=False).flatten()
        if not len(active):
            batch_losses.append(predicted_cartesian[batch_index].sum() * 0.0)
            continue
        predicted = predicted_cartesian[batch_index, active]
        mode_losses: list[torch.Tensor] = []
        for target_mode in equivalent_target_cartesian[batch_index]:
            target = target_mode[active]
            assignment_cost = (
                predicted[:, None] - target[None, :]
            ).square().sum(dim=-1)
            rows, columns = linear_sum_assignment(
                assignment_cost.detach().cpu().numpy()
            )
            matched = predicted[rows] - target[columns]
            mode_losses.append(torch.sqrt(matched.square().sum() / len(active)))
        batch_losses.append(torch.stack(mode_losses).min())
    return torch.stack(batch_losses).mean()


def physics_aware_loss(
    predicted_projected_direction: torch.Tensor,
    target_projected_direction: torch.Tensor,
    free_parameter_mask: torch.Tensor,
) -> torch.Tensor:
    if not (
        predicted_projected_direction.shape
        == target_projected_direction.shape
        == free_parameter_mask.shape
    ):
        raise ValueError("physics direction tensors and mask must share a shape")
    weights = free_parameter_mask.to(predicted_projected_direction.dtype)
    predicted = predicted_projected_direction * weights
    target = target_projected_direction.detach() * weights
    cosine = (predicted * target).sum(dim=-1) / (
        predicted.norm(dim=-1).clamp_min(1.0e-8)
        * target.norm(dim=-1).clamp_min(1.0e-8)
    )
    active = free_parameter_mask.any(dim=-1)
    return _masked_mean(1.0 - cosine, active)


def formal_endpoint_loss(
    *,
    relation_realization: torch.Tensor,
    nearest_neighbor: torch.Tensor,
    shell_pair: torch.Tensor,
    angle: torch.Tensor,
    coordination: torch.Tensor,
    equivalent_orbit_rmsd: torch.Tensor,
    legality_barrier: torch.Tensor,
) -> torch.Tensor:
    components = (
        relation_realization,
        nearest_neighbor,
        shell_pair,
        angle,
        coordination,
        equivalent_orbit_rmsd,
        legality_barrier,
    )
    if any(component.ndim != 0 for component in components):
        raise ValueError("formal endpoint components must be scalar tensors")
    return sum(components)


def memory_consistency_loss(
    *,
    next_relation_nll: torch.Tensor,
    previous_relation_nll: torch.Tensor,
    stale_residual: torch.Tensor,
) -> torch.Tensor:
    if not (
        next_relation_nll.shape
        == previous_relation_nll.shape
        == stale_residual.shape
    ):
        raise ValueError("memory consistency tensors must share a shape")
    return (
        functional.relu(next_relation_nll - previous_relation_nll)
        + stale_residual.square()
    ).mean()


__all__ = [
    "angle_loss",
    "coordination_loss",
    "equivalent_orbit_rmsd_loss",
    "flow_matching_loss",
    "formal_endpoint_loss",
    "memory_consistency_loss",
    "nearest_neighbor_loss",
    "physics_aware_loss",
    "relation_realization_loss",
    "shell_pair_loss",
]
