from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable

import numpy as np

from crysalis_g1.symmetry.wyckoff import (
    OrbitState,
    SpaceGroupConditionedWyckoffExpander,
)

from .wyckoff_shadow import DifferentiableWyckoffShadowMap


@dataclass(frozen=True, slots=True)
class JacobianDiagnosticsV2:
    global_free_dof: int
    rank: int
    condition_number: float | None
    finite: bool


@dataclass(frozen=True, slots=True)
class ManifoldLinearizationV2:
    fractional_coordinates: np.ndarray
    cartesian_coordinates: np.ndarray
    jacobian: np.ndarray
    dof_slices: tuple[tuple[int, int], ...]
    diagnostics: JacobianDiagnosticsV2


class WyckoffManifoldAdapter:
    def __init__(self, shadow_map: DifferentiableWyckoffShadowMap | None = None) -> None:
        self.shadow_map = shadow_map or DifferentiableWyckoffShadowMap()

    def linearize(
        self,
        orbits: Iterable[OrbitState],
        lattice: Iterable[Iterable[float]],
        *,
        require_target_space_group: bool = False,
        require_distinct_orbit_instances: bool = False,
    ) -> ManifoldLinearizationV2:
        orbit_tuple = tuple(orbits)
        if not orbit_tuple:
            raise ValueError("manifold linearization requires at least one orbit")
        matrix = np.asarray(tuple(tuple(row) for row in lattice), dtype=float)
        expansions = tuple(self.shadow_map.expand(orbit, matrix) for orbit in orbit_tuple)
        official = SpaceGroupConditionedWyckoffExpander().expand_many(
            orbit_tuple,
            matrix,
            require_target_space_group=require_target_space_group,
            require_distinct_orbit_instances=require_distinct_orbit_instances,
        )
        fractional = np.concatenate(
            [item.fractional_coordinates for item in expansions], axis=0
        )
        official_fractional = np.asarray(official.fractional_coordinates, dtype=float)
        if fractional.shape != official_fractional.shape or not np.allclose(
            fractional, official_fractional, atol=1e-10
        ):
            raise RuntimeError("per-orbit shadow ordering disagrees with official expansion")
        total_rows = 3 * len(fractional)
        total_dof = sum(item.free_dof for item in expansions)
        jacobian: np.ndarray = np.zeros((total_rows, total_dof), dtype=float)
        dof_slices: list[tuple[int, int]] = []
        row_start = 0
        column_start = 0
        for item in expansions:
            row_stop = row_start + item.jacobian.shape[0]
            column_stop = column_start + item.free_dof
            jacobian[row_start:row_stop, column_start:column_stop] = item.jacobian
            dof_slices.append((column_start, column_stop))
            row_start, column_start = row_stop, column_stop
        finite = bool(
            np.isfinite(fractional).all()
            and np.isfinite(jacobian).all()
            and np.isfinite(matrix).all()
        )
        rank = int(np.linalg.matrix_rank(jacobian)) if total_dof else 0
        condition = float(np.linalg.cond(jacobian)) if total_dof else None
        return ManifoldLinearizationV2(
            fractional_coordinates=fractional,
            cartesian_coordinates=fractional @ matrix,
            jacobian=jacobian,
            dof_slices=tuple(dof_slices),
            diagnostics=JacobianDiagnosticsV2(
                global_free_dof=total_dof,
                rank=rank,
                condition_number=condition,
                finite=finite,
            ),
        )


def project_cartesian_forces(
    jacobian: np.ndarray, cartesian_forces: np.ndarray
) -> np.ndarray:
    matrix = np.asarray(jacobian, dtype=float)
    forces = np.asarray(cartesian_forces, dtype=float)
    if matrix.ndim != 2 or forces.ndim not in (1, 2):
        raise ValueError("Jacobian and Cartesian forces must be matrices/vectors")
    flat = forces.reshape(-1)
    if matrix.shape[0] != flat.size:
        raise ValueError("Cartesian force size does not match Jacobian rows")
    if not np.isfinite(matrix).all() or not np.isfinite(flat).all():
        raise FloatingPointError("non-finite Jacobian or Cartesian force")
    return matrix.T @ flat


def damped_natural_step(
    jacobian: np.ndarray,
    cartesian_forces: np.ndarray,
    *,
    epsilon: float = 1e-6,
    eta: float = 1.0,
) -> np.ndarray:
    if not math.isfinite(epsilon) or epsilon <= 0:
        raise ValueError("epsilon must be finite and positive")
    if not math.isfinite(eta):
        raise ValueError("eta must be finite")
    matrix = np.asarray(jacobian, dtype=float)
    generalized = project_cartesian_forces(matrix, cartesian_forces)
    if generalized.size == 0:
        return generalized
    metric = matrix.T @ matrix + epsilon * np.eye(matrix.shape[1])
    result = float(eta) * np.linalg.solve(metric, generalized)
    if not np.isfinite(result).all():
        raise FloatingPointError("non-finite damped natural step")
    return result


__all__ = [
    "JacobianDiagnosticsV2",
    "ManifoldLinearizationV2",
    "WyckoffManifoldAdapter",
    "damped_natural_step",
    "project_cartesian_forces",
]
