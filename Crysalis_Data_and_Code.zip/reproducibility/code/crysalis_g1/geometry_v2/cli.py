from __future__ import annotations

import argparse
import importlib
import json
import sys
from collections.abc import Callable, Mapping, Sequence
from dataclasses import asdict
from typing import Any

from .gates import (
    FormalGateAuthorizationV2,
    run_authorized_geometry_gate,
)
from .training import run_geometry_v2_training


def _load_callable(reference: str) -> Callable[..., Any]:
    module_name, separator, attribute = reference.partition(":")
    if not separator or not module_name or not attribute:
        raise ValueError("executor/driver must use module:callable syntax")
    candidate = getattr(importlib.import_module(module_name), attribute)
    if not callable(candidate):
        raise TypeError("executor/driver reference is not callable")
    return candidate


def _authorization(args: argparse.Namespace) -> FormalGateAuthorizationV2:
    return FormalGateAuthorizationV2(
        server_authorized=args.server_authorized,
        formal_authorized=args.formal_authorized,
        execution_environment=args.execution_environment,
    )


def training_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Authorized Geometry V2 formal training entrypoint"
    )
    parser.add_argument("--driver", required=True, help="server driver as module:callable")
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--metrics", required=True)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--server-authorized", action="store_true")
    parser.add_argument("--formal-authorized", action="store_true")
    parser.add_argument(
        "--execution-environment", choices=("local", "server"), default="local"
    )
    return parser


def training_main(argv: Sequence[str] | None = None) -> int:
    args = training_parser().parse_args(argv)
    try:
        _authorization(args).require()
        driver = _load_callable(args.driver)
        components = driver()
        if not isinstance(components, Mapping):
            raise TypeError("Geometry V2 training driver must return a mapping")
        required = {
            "model",
            "optimizer",
            "batches",
            "train_step",
            "validation_metrics",
            "validation_interval",
            "registered_generators",
        }
        if set(components) != required:
            raise ValueError("Geometry V2 training driver fields are invalid")
        receipt = run_geometry_v2_training(
            model=components["model"],
            optimizer=components["optimizer"],
            batches=components["batches"],
            train_step=components["train_step"],
            validation_metrics=components["validation_metrics"],
            validation_interval=components["validation_interval"],
            checkpoint_path=args.checkpoint,
            metrics_path=args.metrics,
            resume=args.resume,
            registered_generators=components["registered_generators"],
        )
    except (ImportError, AttributeError, OSError, TypeError, ValueError, PermissionError) as error:
        print(str(error), file=sys.stderr)
        return 2
    payload = asdict(receipt)
    payload["formal_alignments"] = [
        {
            "batch_index": item.batch_index,
            "loss": item.loss,
            "accepted": item.endpoint_receipt.accepted,
            "failure_reason_codes": item.endpoint_receipt.failure_reason_codes,
        }
        for item in receipt.formal_alignments
    ]
    print(json.dumps(payload, sort_keys=True))
    return 0 if receipt.status == "COMPLETE" else 3


def gate_parser(gate: str) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=f"Authorized frozen Geometry V2 {gate} entrypoint"
    )
    parser.add_argument("--executor", required=True, help="server executor as module:callable")
    parser.add_argument("--prior-status", action="append", default=[])
    parser.add_argument("--server-authorized", action="store_true")
    parser.add_argument("--formal-authorized", action="store_true")
    parser.add_argument(
        "--execution-environment", choices=("local", "server"), default="local"
    )
    return parser


def _prior_statuses(values: Sequence[str]) -> dict[str, str]:
    result: dict[str, str] = {}
    for value in values:
        name, separator, status = value.partition("=")
        if not separator or name not in {"G0", "G1", "G2"} or status not in {
            "PASS",
            "FAIL",
        }:
            raise ValueError("prior statuses must use G0=PASS/G1=PASS/G2=PASS syntax")
        if name in result:
            raise ValueError("prior gate status was supplied more than once")
        result[name] = status
    return result


def gate_main(gate: str, argv: Sequence[str] | None = None) -> int:
    args = gate_parser(gate).parse_args(argv)
    try:
        authorization = _authorization(args)
        authorization.require()
        statuses = _prior_statuses(args.prior_status)
        executor = _load_callable(args.executor)
        receipt = run_authorized_geometry_gate(
            gate,
            authorization,
            statuses,
            executor,
        )
    except (ImportError, AttributeError, OSError, TypeError, ValueError, PermissionError) as error:
        print(str(error), file=sys.stderr)
        return 2
    print(json.dumps(asdict(receipt), sort_keys=True))
    return 0 if receipt.status == "PASS" else 3


__all__ = ["gate_main", "gate_parser", "training_main", "training_parser"]
