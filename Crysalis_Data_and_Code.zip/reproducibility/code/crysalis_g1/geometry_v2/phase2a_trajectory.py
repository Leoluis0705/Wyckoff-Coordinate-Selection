from __future__ import annotations

import hashlib
import random
from dataclasses import dataclass
from typing import Sequence

from crysalis_g1.data.structural_operators import StructuralTrajectory
from crysalis_g1.full_crysalis.data import IntegratedCorpus, IntegratedEvent


def _active_ids(event: IntegratedEvent) -> tuple[str, ...]:
    return tuple(sorted(orbit.orbit_instance_id for orbit in event.active_orbits))


@dataclass(frozen=True, slots=True)
class Phase2ATrajectoryStepV2:
    event: IntegratedEvent
    sequence_index: int
    action_path_hash: str

    def __post_init__(self) -> None:
        if self.event.split != "train_fit" or self.event.terminal:
            raise ValueError("production trajectories contain nonterminal train_fit only")
        if type(self.sequence_index) is not int or self.sequence_index < 0:
            raise ValueError("trajectory sequence index must be non-negative")
        if len(self.action_path_hash) != 64:
            raise ValueError("action path hash must be SHA-256")


@dataclass(frozen=True, slots=True)
class Phase2ATrajectoryV2:
    trajectory_id: str
    parent_id: str
    path_index: int
    source_split: str
    sequence_hash: str
    steps: tuple[Phase2ATrajectoryStepV2, ...]

    def __post_init__(self) -> None:
        if self.source_split != "train_fit":
            raise ValueError("production replay trajectories must be train_fit")
        if not self.trajectory_id or not self.steps:
            raise ValueError("trajectory identity and steps must be non-empty")
        if tuple(step.sequence_index for step in self.steps) != tuple(
            range(len(self.steps))
        ):
            raise ValueError("trajectory steps must be contiguous")
        active: set[str] = set()
        for step in self.steps:
            candidate = step.event.candidate_orbit
            assert candidate is not None
            if set(_active_ids(step.event)) != active:
                raise ValueError("event topology does not follow the inverse action path")
            active.add(candidate.orbit_instance_id)


def build_phase2a_trajectories_v2(
    corpus: IntegratedCorpus,
    structural_trajectories: Sequence[StructuralTrajectory],
) -> tuple[Phase2ATrajectoryV2, ...]:
    if corpus.validation_events and not corpus.train_events:
        raise ValueError("structure_ood events cannot form train_fit replay trajectories")
    by_topology: dict[tuple[str, tuple[str, ...], str], IntegratedEvent] = {}
    for event in corpus.train_events:
        if event.split != "train_fit":
            raise ValueError("production trajectory source must remain train_fit")
        if event.terminal:
            continue
        assert event.candidate_orbit is not None
        key = (event.parent_id, _active_ids(event), event.candidate_orbit.orbit_instance_id)
        if key in by_topology:
            raise ValueError("duplicate integrated event topology")
        by_topology[key] = event
    train_parent_ids = {event.parent_id for event in corpus.train_events}
    validation_parent_ids = {event.parent_id for event in corpus.validation_events}

    result: list[Phase2ATrajectoryV2] = []
    seen_ids: set[str] = set()
    for structural in structural_trajectories:
        if structural.operator != "D_orbit":
            continue
        if structural.parent_structure_id in validation_parent_ids:
            continue
        if structural.parent_structure_id not in train_parent_ids:
            raise ValueError("formal trajectory parent is absent from the corpus")
        active: set[str] = set()
        steps: list[Phase2ATrajectoryStepV2] = []
        for sequence_index, action in enumerate(structural.inverse_actions):
            if action.mode != "RESTORE":
                raise ValueError("inverse trajectory contains a non-RESTORE action")
            key = (
                structural.parent_structure_id,
                tuple(sorted(active)),
                action.target_id,
            )
            event = by_topology.get(key)
            if event is None:
                raise ValueError("formal inverse action has no matching integrated event")
            prefix = structural.inverse_actions[: sequence_index + 1]
            action_hash = hashlib.sha256(
                "|".join(
                    f"{item.operator}:{item.mode}:{item.target_id}" for item in prefix
                ).encode("utf-8")
            ).hexdigest()
            steps.append(Phase2ATrajectoryStepV2(event, sequence_index, action_hash))
            active.add(action.target_id)
        trajectory_id = (
            f"phase2a:{structural.parent_structure_id}:"
            f"{structural.path_index}:{structural.sequence_hash}"
        )
        if trajectory_id in seen_ids:
            raise ValueError("duplicate formal trajectory identity")
        seen_ids.add(trajectory_id)
        result.append(
            Phase2ATrajectoryV2(
                trajectory_id=trajectory_id,
                parent_id=structural.parent_structure_id,
                path_index=structural.path_index,
                source_split="train_fit",
                sequence_hash=structural.sequence_hash,
                steps=tuple(steps),
            )
        )
    if not result:
        raise ValueError("no train_fit D_orbit trajectories were constructed")
    return tuple(sorted(result, key=lambda item: item.trajectory_id))


def deterministic_trajectory_permutation_v2(
    trajectories: Sequence[Phase2ATrajectoryV2], root_seed: int
) -> tuple[Phase2ATrajectoryV2, ...]:
    if not trajectories:
        raise ValueError("trajectory permutation requires at least one trajectory")
    ordered = sorted(trajectories, key=lambda item: item.trajectory_id)
    random.Random(int(root_seed)).shuffle(ordered)
    return tuple(ordered)


__all__ = [
    "Phase2ATrajectoryStepV2",
    "Phase2ATrajectoryV2",
    "build_phase2a_trajectories_v2",
    "deterministic_trajectory_permutation_v2",
]
