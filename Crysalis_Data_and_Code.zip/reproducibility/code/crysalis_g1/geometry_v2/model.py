from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any

import torch
from torch import nn

from .context_encoder import GeometryContextEncoderV2
from .endpoint import (
    FormalEndpointDependenciesV2,
    FormalEndpointResultV2,
    GuideMLIPDependencyV2,
    InferenceGeometryAdapterV2,
)
from .formal_adapters import (
    ProjectedGuideDriftAdapterV2,
    RelationConsistencyObjectiveV2,
    RelationGeometryCalibrationV2,
    calculate_realized_relations_v2,
    validate_relation_geometry_calibration_contract_v2,
)
from .flow import ConditionalToroidalFlowV2
from .memory import RefinementReceiptV2
from .manifold import project_cartesian_forces
from .refinement import GuideObjectiveProtocolV2, ProjectorProtocolV2
from .relation_interface import (
    GeometryConditionV2,
    RelationFunctionBackendV2,
    RelationModelInputV2,
    RelationPredictionV2,
)


ConditionalToroidalFlowGeometryDecoder = ConditionalToroidalFlowV2


@dataclass(frozen=True, slots=True)
class PreparedFormalEndpointV2:
    endpoint_kwargs: dict[str, Any]
    model_input: RelationModelInputV2
    prediction: RelationPredictionV2
    drift: ProjectedGuideDriftAdapterV2
    calibration: RelationGeometryCalibrationV2


class FormalGeometryV2Model(nn.Module):
    """Single checkpointed relation/context/flow bundle used by train and inference."""

    def __init__(self) -> None:
        super().__init__()
        self.relation = RelationFunctionBackendV2(hidden_dim=96, grid_size=15)
        self.context = GeometryContextEncoderV2()
        self.flow = ConditionalToroidalFlowGeometryDecoder()

    def condition(
        self, model_input: RelationModelInputV2
    ) -> tuple[RelationModelInputV2, RelationPredictionV2, torch.Tensor]:
        if not isinstance(model_input, RelationModelInputV2):
            raise TypeError("formal model requires sanitized RelationModelInputV2")
        prediction = self.relation.predict(model_input)
        context = self.context(GeometryConditionV2(model_input, prediction))
        return model_input, prediction, context

    def prepare_endpoint(
        self,
        *,
        state: object,
        model_input: RelationModelInputV2,
        wyckoff_id: torch.Tensor,
        free_parameter_mask: torch.Tensor,
        registered_seed: int,
        candidate_free_dof: int,
        guide_objective: GuideObjectiveProtocolV2,
        projector: ProjectorProtocolV2,
        relation_calibration: RelationGeometryCalibrationV2,
    ) -> PreparedFormalEndpointV2:
        from crysalis_g1.symmetry.assembly import SymmetryAssemblyState

        if not isinstance(state, SymmetryAssemblyState):
            raise TypeError("formal endpoint requires SymmetryAssemblyState")
        validate_relation_geometry_calibration_contract_v2(relation_calibration)
        owned_input, prediction, context = self.condition(model_input)
        relation = RelationConsistencyObjectiveV2(
            state,
            prediction,
            owned_input.active_orbit_graph,
            relation_calibration,
        )
        drift = ProjectedGuideDriftAdapterV2(state, guide_objective, relation)
        dependencies = FormalEndpointDependenciesV2(
            velocity_field=self.flow,
            guide=GuideMLIPDependencyV2(
                objective=guide_objective,
                drift_provider=drift,
            ),
            relation=relation,
            projector=projector,
        )
        if dependencies.velocity_field is not self.flow:
            raise RuntimeError("formal endpoint velocity must be the checkpointed model flow")
        return PreparedFormalEndpointV2(
            endpoint_kwargs={
                "state": state,
                "context": context,
                "wyckoff_id": wyckoff_id,
                "free_parameter_mask": free_parameter_mask,
                "registered_seed": registered_seed,
                "candidate_free_dof": candidate_free_dof,
                "dependencies": dependencies,
            },
            model_input=owned_input,
            prediction=prediction,
            drift=drift,
            calibration=relation_calibration,
        )

    def apply_memory_transition(
        self,
        result: FormalEndpointResultV2,
        prepared: PreparedFormalEndpointV2,
    ) -> FormalEndpointResultV2:
        previous = prepared.model_input.persistent_memory
        if not result.receipt.accepted:
            return replace(result, updated_memory=previous, memory_update_receipt=None)
        graph = prepared.model_input.active_orbit_graph
        dtype = prepared.model_input.composition.dtype
        device = prepared.model_input.composition.device
        orbit_count = graph.orbit_count
        edge_count = graph.edge_count
        accepted_u = torch.zeros(1, orbit_count, 3, dtype=dtype, device=device)
        active_slots = tuple(
            int(index)
            for index in torch.nonzero(
                graph.active_orbit_mask[0], as_tuple=False
            ).flatten()
        )
        if len(active_slots) != len(result.state.orbits):
            raise RuntimeError("accepted structure does not match active orbit topology")
        for slot, orbit in zip(active_slots, result.state.orbits, strict=True):
            values = torch.as_tensor(
                orbit.free_parameters, dtype=dtype, device=device
            )
            accepted_u[0, slot, : len(values)] = values
        realized = calculate_realized_relations_v2(
            result.state, graph, prepared.calibration
        )
        realized_edge_state = realized.edge_state.to(device=device, dtype=dtype)
        distance_scale = prepared.prediction.edge_distance[..., 1:2].exp().clamp_min(
            torch.finfo(dtype).eps
        ).to(device=device, dtype=dtype)
        distance_residual = (
            realized_edge_state[..., 1:2]
            - prepared.prediction.edge_distance[..., :1].to(device=device, dtype=dtype)
        ) / distance_scale
        direction_scale = prepared.prediction.edge_direction_log_scale.exp().clamp_min(
            torch.finfo(dtype).eps
        ).to(device=device, dtype=dtype)
        direction_residual = (
            (realized_edge_state[..., 2:8]
             - prepared.prediction.edge_direction_fourier.to(device=device, dtype=dtype))
            .square()
            .reshape(1, edge_count, 3, 2)
            .sum(dim=-1)
            / direction_scale.square()
        ).mean(dim=-1, keepdim=True)
        relation_residual = torch.cat((distance_residual, direction_residual), dim=-1)
        edge_uncertainty = (
            distance_scale + direction_scale.mean(dim=-1, keepdim=True)
        ) / 2.0
        edge_uncertainty = edge_uncertainty * graph.edge_mask.to(device)[..., None]
        edge_anchor = graph.edge_index.to(device).clamp(0, max(orbit_count - 1, 0))
        flow_uncertainty = torch.zeros(1, orbit_count, 1, dtype=dtype, device=device)
        if orbit_count and edge_count:
            flow_uncertainty.scatter_add_(
                1, edge_anchor.unsqueeze(-1), edge_uncertainty
            )
            flow_uncertainty[:, active_slots[-1] : active_slots[-1] + 1] = (
                edge_uncertainty.sum(dim=1, keepdim=True)
                / graph.edge_mask.to(device).sum(dim=1, keepdim=True).clamp_min(1)[..., None]
            )
        final_linearization = prepared.drift.manifold.linearize(
            result.state.orbits, result.state.lattice.primitive_matrix
        )
        final_guide = prepared.drift.guide.evaluate(
            result.state.orbits, result.state.lattice.primitive_matrix
        )
        final_forces = (
            final_guide.cartesian_forces
            if final_guide.applicable
            else final_guide.cartesian_forces * 0.0
        )
        generalized_force = project_cartesian_forces(
            final_linearization.jacobian, final_forces
        )
        projected_by_orbit = torch.zeros(
            len(active_slots), 3, dtype=dtype, device=device
        )
        for orbit_index, (start, stop) in enumerate(final_linearization.dof_slices):
            projected_by_orbit[orbit_index, : stop - start] = torch.as_tensor(
                generalized_force[start:stop], dtype=dtype, device=device
            )
        raw_projected_force = torch.as_tensor(
            projected_by_orbit,
            dtype=dtype,
            device=device,
        )
        if raw_projected_force.shape != (len(active_slots), 3):
            raise RuntimeError("Guide projected-force residuals do not match active orbits")
        projected_force = torch.zeros(1, orbit_count, 3, dtype=dtype, device=device)
        projected_force[0, torch.as_tensor(active_slots, device=device)] = raw_projected_force
        old_orbit = previous.tensorize().orbit.to(device=device, dtype=dtype)
        mode_history = accepted_u - old_orbit[..., :3]
        refinement = result.receipt.refinement
        memory_refinement = RefinementReceiptV2(
            accepted_steps=(refinement.accepted_steps,),
            trust_region_contractions=(
                max(refinement.attempted_proposals - refinement.accepted_steps, 0),
            ),
            final_joint_objectives=(float(refinement.objective_history[-1]),),
        )
        updated, receipt = previous.update(
            active_orbit_mask=graph.active_orbit_mask.to(device),
            edge_mask=graph.edge_mask.to(device),
            realized_edge_state=realized_edge_state,
            relation_residual=relation_residual,
            accepted_u=accepted_u,
            flow_uncertainty=flow_uncertainty,
            projected_force_residual=projected_force,
            mode_history=mode_history,
            refinement_receipt=memory_refinement,
            base_latent_namespaces=(
                f"{result.receipt.sampling.namespace}:{result.receipt.sampling.registered_seed}",
            ),
        )
        return replace(
            result,
            updated_memory=updated,
            memory_update_receipt=receipt,
        )

    def run_inference(self, **request: Any) -> FormalEndpointResultV2:
        prepared = self.prepare_endpoint(**request)
        result = InferenceGeometryAdapterV2().run(**prepared.endpoint_kwargs)
        return self.apply_memory_transition(result, prepared)


__all__ = [
    "ConditionalToroidalFlowGeometryDecoder",
    "FormalGeometryV2Model",
    "PreparedFormalEndpointV2",
]
