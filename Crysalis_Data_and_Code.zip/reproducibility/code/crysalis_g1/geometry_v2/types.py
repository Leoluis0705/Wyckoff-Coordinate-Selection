from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Sequence


MAX_FREE_DOF = 3
ZERO_DOF_BYPASS = "ZERO_DOF_BYPASS"


def validate_free_parameter_mask(mask: Sequence[bool]) -> tuple[bool, bool, bool]:
    if len(mask) != MAX_FREE_DOF or any(type(value) is not bool for value in mask):
        raise ValueError("free-parameter mask must be a boolean 3-vector")
    return bool(mask[0]), bool(mask[1]), bool(mask[2])


@dataclass(frozen=True, slots=True)
class TorusManifold:
    wyckoff_position_id: str
    free_dof: int

    def __post_init__(self) -> None:
        if not self.wyckoff_position_id:
            raise ValueError("wyckoff_position_id must be non-empty")
        if type(self.free_dof) is not int or not 0 <= self.free_dof <= MAX_FREE_DOF:
            raise ValueError("free_dof must be an integer from 0 through 3")

    @property
    def free_parameter_mask(self) -> tuple[bool, bool, bool]:
        return tuple(index < self.free_dof for index in range(MAX_FREE_DOF))  # type: ignore[return-value]

    @property
    def free_parameter_count(self) -> int:
        return self.free_dof


@dataclass(frozen=True, slots=True)
class TorusState:
    manifold: TorusManifold
    values: tuple[float, float, float]

    def __post_init__(self) -> None:
        if len(self.values) != MAX_FREE_DOF:
            raise ValueError("torus state must be a 3-vector")
        normalized = tuple(float(value) for value in self.values)
        if not all(math.isfinite(value) for value in normalized):
            raise ValueError("torus state values must be finite")
        if any(
            value != 0.0
            for value, is_free in zip(
                normalized, self.manifold.free_parameter_mask, strict=True
            )
            if not is_free
        ):
            raise ValueError("masked torus coordinates must be zero")
        object.__setattr__(self, "values", normalized)


@dataclass(frozen=True, slots=True)
class TorusSampleReceipt:
    state: TorusState
    zero_dof_bypass: bool
    reason_codes: tuple[str, ...]

    def __post_init__(self) -> None:
        if self.state.manifold.free_dof == 0:
            if not self.zero_dof_bypass or self.reason_codes != (
                ZERO_DOF_BYPASS,
            ):
                raise ValueError("d=0 requires ZERO_DOF_BYPASS")
        elif self.zero_dof_bypass or ZERO_DOF_BYPASS in self.reason_codes:
            raise ValueError("ZERO_DOF_BYPASS requires zero_dof_bypass=true")


def zero_dof_bypass(manifold: TorusManifold) -> TorusSampleReceipt:
    if manifold.free_dof != 0:
        raise ValueError("ZERO_DOF_BYPASS requires d=0")
    return TorusSampleReceipt(
        state=TorusState(manifold, (0.0, 0.0, 0.0)),
        zero_dof_bypass=True,
        reason_codes=(ZERO_DOF_BYPASS,),
    )
