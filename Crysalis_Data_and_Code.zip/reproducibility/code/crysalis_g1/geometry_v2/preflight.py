from __future__ import annotations

import time
from collections.abc import Mapping
from typing import Any

import numpy as np
import torch
import yaml
from pathlib import Path

from crysalis_g1.symmetry.assembly import C0SymmetryProjector, SymmetryAssemblyState
from crysalis_g1.symmetry.wyckoff import (
    OrbitState,
    SpaceGroupConditionedWyckoffExpander,
    SpaceGroupConstrainedLatticeHead,
)

from .context_encoder import GEOMETRY_CONTEXT_DIM
from .endpoint import (
    audit_formal_endpoint_receipt,
)
from .flow import (
    FLOW_RESIDUAL_BLOCKS,
    FLOW_WIDTH,
    TIME_EMBEDDING_DIM,
)
from .formal_adapters import (
    load_relation_geometry_calibration_v2,
    validate_relation_geometry_calibration_contract_v2,
)
from .memory import PersistentRelationMemoryV2
from .model import FormalGeometryV2Model
from .physics_guidance import FROZEN_MANIFOLD_TRUST_RADIUS
from .refinement import (
    MAX_ACCEPTED_REFINEMENT_STEPS,
    GuideEvaluationV2,
)
from .relation_interface import (
    ActiveOrbitGraphV2,
    RelationInputProvenanceV2,
    RelationModelInputV2,
)


G0_EVIDENCE_IDS = tuple("ABCDEFGHIJKLMN")


def _as_numpy(value: object) -> np.ndarray:
    if hasattr(value, "detach"):
        value = value.detach().cpu().numpy()  # type: ignore[union-attr]
    return np.asarray(value, dtype=float)


def frozen_architecture_receipt(model: FormalGeometryV2Model) -> dict[str, Any]:
    if not isinstance(model, FormalGeometryV2Model):
        raise TypeError("architecture receipt requires FormalGeometryV2Model")
    return {
        "relation_hidden_dim": 96,
        "relation_grid_size": 15,
        "context_dim": GEOMETRY_CONTEXT_DIM,
        "flow_width": FLOW_WIDTH,
        "flow_residual_blocks": FLOW_RESIDUAL_BLOCKS,
        "time_embedding_dim": TIME_EMBEDDING_DIM,
        "formal_sample_count": 1,
        "sampler_steps": 8,
        "max_refinement_accepted_steps": MAX_ACCEPTED_REFINEMENT_STEPS,
        "trust_radius_linf": FROZEN_MANIFOLD_TRUST_RADIUS,
        "trainable_parameter_count": sum(parameter.numel() for parameter in model.parameters()),
    }


def validate_g0_evidence(evidence: Mapping[str, Mapping[str, str]]) -> dict[str, Any]:
    if tuple(sorted(evidence)) != G0_EVIDENCE_IDS:
        raise ValueError("G0 evidence must contain exactly A through N")
    invalid = tuple(
        item
        for item in G0_EVIDENCE_IDS
        if evidence[item].get("status") not in {"PASS", "FAIL"}
        or not evidence[item].get("evidence")
    )
    if invalid:
        raise ValueError("each G0 item requires PASS/FAIL and non-empty evidence")
    failed = tuple(item for item in G0_EVIDENCE_IDS if evidence[item]["status"] != "PASS")
    return {"status": "PASS" if not failed else "FAIL", "failed_items": failed}


class _ZeroGuideObjective:
    parameter_count = 0

    def evaluate(
        self, orbits: tuple[OrbitState, ...], lattice: object
    ) -> GuideEvaluationV2:
        del lattice
        return GuideEvaluationV2(
            energy=0.0,
            cartesian_forces=np.zeros((sum(orbit.multiplicity for orbit in orbits), 3)),
            applicable=True,
            reason_code=None,
        )


class _CHGNetGuideObjective:
    def __init__(self, device: str) -> None:
        from chgnet.model import CHGNet

        self._model = CHGNet.load(model_name="0.3.0", use_device=device, verbose=False)
        self._model.eval()
        for parameter in self._model.parameters():
            parameter.requires_grad_(False)
        self._expander = SpaceGroupConditionedWyckoffExpander()
        self.parameter_count = sum(parameter.numel() for parameter in self._model.parameters())

    def evaluate(
        self, orbits: tuple[OrbitState, ...], lattice: object
    ) -> GuideEvaluationV2:
        from pymatgen.core import Lattice, Structure

        expanded = self._expander.expand_many(orbits, lattice)
        structure = Structure(
            Lattice(np.asarray(lattice, dtype=float)),
            expanded.atomic_numbers,
            expanded.fractional_coordinates,
        )
        raw = self._model.predict_structure(structure, task="ef", batch_size=1)
        energy = float(_as_numpy(raw["e"]).reshape(-1)[0])
        forces = _as_numpy(raw["f"])
        return GuideEvaluationV2(
            energy=energy,
            cartesian_forces=forces,
            applicable=True,
            reason_code=None,
        )


def _representative_state() -> SymmetryAssemblyState:
    lattice = SpaceGroupConstrainedLatticeHead().constrain(
        1, (4.1, 5.2, 6.3, 79.0, 96.0, 108.0)
    )
    return SymmetryAssemblyState(
        target_space_group=1,
        composition=((1, 1), (8, 1)),
        remaining_composition=(),
        lattice=lattice,
        orbits=(
            OrbitState.create(
                1, "a", 1, (0.1, 0.2, 0.3), orbit_instance_id="preflight-existing"
            ),
            OrbitState.create(
                1, "a", 8, (0.37, 0.48, 0.59), orbit_instance_id="preflight-candidate"
            ),
        ),
    )


def run_representative_inference_preflight(
    *, device: str, include_chgnet: bool
) -> dict[str, Any]:
    torch_device = torch.device(device)
    if torch_device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")
    if torch_device.type == "cuda":
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats(torch_device)
    torch.manual_seed(20260828)
    if torch_device.type == "cuda":
        torch.cuda.manual_seed_all(20260828)
    started = time.perf_counter()
    repository_root = Path(__file__).resolve().parents[2]
    server_config = yaml.safe_load(
        (repository_root / "configs/geometry_v2_server_training_20260828_v1.yaml").read_bytes()
    )
    calibration_config = server_config["normalizers"]["relation_geometry_calibration"]
    relation_calibration = load_relation_geometry_calibration_v2(
        repository_root / calibration_config["artifact_path"],
        expected_sha256=calibration_config["artifact_sha256"],
    )
    validate_relation_geometry_calibration_contract_v2(relation_calibration)
    model = FormalGeometryV2Model().to(torch_device).eval()
    graph = ActiveOrbitGraphV2(
        active_orbits=torch.zeros(1, 2, 64, device=torch_device),
        active_orbit_mask=torch.tensor([[True, True]], device=torch_device),
        edge_index=torch.tensor([[0, 0]], dtype=torch.long, device=torch_device),
        edge_mask=torch.tensor([[True, False]], device=torch_device),
        triplet_index=torch.tensor([[[0, 0]]], dtype=torch.long, device=torch_device),
        triplet_mask=torch.tensor([[False]], device=torch_device),
    )
    model_input = RelationModelInputV2.from_mapping(
        {
            "composition": torch.zeros(1, 119, device=torch_device),
            "target_sg": torch.ones(1, dtype=torch.long, device=torch_device),
            "lattice": torch.eye(3, device=torch_device).unsqueeze(0),
            "active_orbit_graph": graph,
            "candidate_query": torch.zeros(1, 64, device=torch_device),
            "persistent_memory": PersistentRelationMemoryV2.empty(
                1, 2, 2, device=torch_device
            ),
        },
        provenance=RelationInputProvenanceV2("current_generation_state"),
    )
    guide_objective = (
        _CHGNetGuideObjective(device) if include_chgnet else _ZeroGuideObjective()
    )
    result = model.run_inference(
        state=_representative_state(),
        model_input=model_input,
        wyckoff_id=torch.tensor([1], dtype=torch.long, device=torch_device),
        free_parameter_mask=torch.tensor(
            [[True, True, True]], device=torch_device
        ),
        registered_seed=20260828,
        candidate_free_dof=3,
        guide_objective=guide_objective,
        projector=C0SymmetryProjector(minimum_distance=0.1),
        relation_calibration=relation_calibration,
    )
    runtime = audit_formal_endpoint_receipt(result.receipt)
    if torch_device.type == "cuda":
        torch.cuda.synchronize(torch_device)
    wall_time = time.perf_counter() - started
    finite_output = bool(torch.isfinite(result.endpoint_values).all())
    peak_allocated = (
        int(torch.cuda.max_memory_allocated(torch_device))
        if torch_device.type == "cuda"
        else 0
    )
    peak_reserved = (
        int(torch.cuda.max_memory_reserved(torch_device))
        if torch_device.type == "cuda"
        else 0
    )
    architecture = frozen_architecture_receipt(model)
    return {
        "status": "PASS" if runtime.passed and finite_output else "FAIL",
        "scientific_use": False,
        "device": str(torch_device),
        "formal_endpoint_called": True,
        "sample_count": result.receipt.sampling.sample_count,
        "sampler_steps": result.receipt.sampling.integration_steps,
        "accepted_refinement_steps": result.receipt.refinement.accepted_steps,
        "resampled": result.receipt.resampled,
        "accepted": result.receipt.accepted,
        "finite_output": finite_output,
        "endpoint_values": result.endpoint_values.detach().cpu().tolist(),
        "trainable_parameter_count": architecture["trainable_parameter_count"],
        "guide_parameter_count": int(guide_objective.parameter_count),
        "peak_allocated_bytes": peak_allocated,
        "peak_reserved_bytes": peak_reserved,
        "wall_time_seconds": wall_time,
        "architecture": architecture,
        "guide_mode": "CHGNET_0.3.0_SERIAL" if include_chgnet else "FINITE_INTERFACE_STUB",
    }


__all__ = [
    "G0_EVIDENCE_IDS",
    "FormalGeometryV2Model",
    "frozen_architecture_receipt",
    "run_representative_inference_preflight",
    "validate_g0_evidence",
]
