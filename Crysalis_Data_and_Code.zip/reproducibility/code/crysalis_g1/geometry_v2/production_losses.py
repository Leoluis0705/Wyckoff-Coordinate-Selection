from __future__ import annotations

import math
from contextlib import nullcontext
from collections.abc import Callable
from dataclasses import dataclass
from typing import ContextManager, Mapping, Protocol, Sequence

import numpy as np
import torch
from torch.nn import functional

from .endpoint import FormalEndpointResultV2
from .formal_adapters import (
    RelationGeometryCalibrationV2,
    calculate_realized_relations_v2,
)
from .losses import (
    coordination_loss,
    flow_matching_loss,
    formal_endpoint_loss,
    memory_consistency_loss,
    nearest_neighbor_loss,
    physics_aware_loss,
    relation_realization_loss,
    shell_pair_loss,
)
from .manifold import WyckoffManifoldAdapter, damped_natural_step
from .model import FormalGeometryV2Model, PreparedFormalEndpointV2
from .phase2a_adapter import Phase2ASupervisionV2
from .train_fit import MODEL_REALIZED_UNROLL
from .training import FormalGeometryTrainingBatchV2
from .training_batch import build_flow_matching_batch


NAMED_PRODUCTION_LOSSES_V2 = (
    "flow",
    "relation_realization",
    "local_metric",
    "physics_aware",
    "formal_endpoint",
    "memory_consistency",
)

RuntimeProfileScopeV2 = Callable[[str], ContextManager[None]]


def _profile_scope(
    runtime_profile: RuntimeProfileScopeV2 | None, label: str
) -> ContextManager[None]:
    return nullcontext() if runtime_profile is None else runtime_profile(label)


def _masked_mean(values: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    weights = mask.to(device=values.device, dtype=values.dtype)
    return (values * weights).sum() / weights.sum().clamp_min(1.0)


@dataclass(frozen=True, slots=True)
class LossScaleNormalizerV2:
    scales: Mapping[str, float]
    source_split: str
    fit_count: int

    def __post_init__(self) -> None:
        if tuple(self.scales) != NAMED_PRODUCTION_LOSSES_V2:
            raise ValueError("loss scale fields do not match the full named objective")
        if self.source_split != "train_fit":
            raise ValueError("loss scales may be fit from train_fit only")
        if self.fit_count <= 0:
            raise ValueError("loss scale fit count must be positive")
        if any(not math.isfinite(float(value)) or float(value) <= 0 for value in self.scales.values()):
            raise ValueError("loss scales must be finite and positive")

    @classmethod
    def identity(cls) -> LossScaleNormalizerV2:
        return cls({name: 1.0 for name in NAMED_PRODUCTION_LOSSES_V2}, "train_fit", 1)

    @classmethod
    def fit(
        cls,
        rows: Sequence[Mapping[str, float]],
        *,
        source_split: str,
        epsilon: float = 1.0e-8,
    ) -> LossScaleNormalizerV2:
        if source_split != "train_fit" or not rows:
            raise ValueError("loss scale audit requires non-empty train_fit rows")
        if any(tuple(row) != NAMED_PRODUCTION_LOSSES_V2 for row in rows):
            raise ValueError("loss scale row fields do not match the named objective")
        scales: dict[str, float] = {}
        for name in NAMED_PRODUCTION_LOSSES_V2:
            values = np.asarray([float(row[name]) for row in rows], dtype=float)
            if not np.isfinite(values).all() or np.any(values < 0):
                raise ValueError("raw loss audit values must be finite and non-negative")
            median = float(np.median(values))
            mad = float(np.median(np.abs(values - median))) * 1.4826
            p90 = float(np.quantile(values, 0.9))
            scales[name] = max(median, mad, p90, float(epsilon))
        return cls(scales, source_split, len(rows))

    def normalize(
        self, raw: Mapping[str, torch.Tensor]
    ) -> dict[str, torch.Tensor]:
        if tuple(raw) != NAMED_PRODUCTION_LOSSES_V2:
            raise ValueError("raw loss fields do not match the named objective")
        return {name: raw[name] / float(self.scales[name]) for name in raw}

    def to_dict(self) -> dict[str, object]:
        return {
            "source_split": self.source_split,
            "fit_count": self.fit_count,
            "scales": dict(self.scales),
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> LossScaleNormalizerV2:
        scales = payload["scales"]
        if not isinstance(scales, Mapping):
            raise TypeError("serialized loss scales must be a mapping")
        return cls(
            {name: float(scales[name]) for name in NAMED_PRODUCTION_LOSSES_V2},
            str(payload["source_split"]),
            int(payload["fit_count"]),
        )


@dataclass(frozen=True, slots=True)
class ProductionLossResultV2:
    raw: Mapping[str, torch.Tensor]
    normalized: Mapping[str, torch.Tensor]
    total: torch.Tensor

    def detached_row(self) -> dict[str, float]:
        return {name: float(self.raw[name].detach().cpu()) for name in NAMED_PRODUCTION_LOSSES_V2}


class GuideTeacherProtocolV2(Protocol):
    def evaluate(self, orbits: tuple[object, ...], lattice: object) -> object: ...


@dataclass(frozen=True, slots=True)
class GuideTeacherTargetReceiptV2:
    applicable: tuple[bool, ...]
    zero_dof: tuple[bool, ...]
    failure_reason_codes: tuple[str | None, ...]


def build_projected_guide_teacher_targets_v2(
    states: Sequence[object],
    guide: GuideTeacherProtocolV2,
    *,
    device: str | torch.device,
) -> tuple[torch.Tensor, GuideTeacherTargetReceiptV2]:
    manifold = WyckoffManifoldAdapter()
    rows: list[torch.Tensor] = []
    applicable: list[bool] = []
    zero_dof: list[bool] = []
    reasons: list[str | None] = []
    for state in states:
        orbits = tuple(getattr(state, "orbits"))
        lattice = getattr(state, "lattice").primitive_matrix
        linearization = manifold.linearize(orbits, lattice)
        start, stop = linearization.dof_slices[-1]
        is_zero = stop == start
        evaluation = guide.evaluate(orbits, lattice)
        is_applicable = bool(getattr(evaluation, "applicable", False))
        reason = getattr(evaluation, "reason_code", None)
        row = np.zeros(3, dtype=float)
        if is_applicable and not is_zero:
            natural = damped_natural_step(
                linearization.jacobian,
                np.asarray(getattr(evaluation, "cartesian_forces"), dtype=float),
            )
            row[: stop - start] = natural[start:stop]
        rows.append(torch.as_tensor(row, dtype=torch.float32, device=device))
        applicable.append(is_applicable)
        zero_dof.append(is_zero)
        reasons.append(None if is_applicable else str(reason or "GUIDE_NOT_APPLICABLE"))
    return torch.stack(rows), GuideTeacherTargetReceiptV2(
        tuple(applicable), tuple(zero_dof), tuple(reasons)
    )


def _relation_losses(
    prediction: object,
    supervision: Phase2ASupervisionV2,
    graph: object,
    *,
    runtime_profile: RuntimeProfileScopeV2 | None = None,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    edge_mask = graph.edge_mask
    triplet_mask = graph.triplet_mask
    edge_observable = edge_mask.unsqueeze(-1)
    triplet_observable = triplet_mask.unsqueeze(-1)
    with _profile_scope(runtime_profile, "relation_loss"):
        presence = functional.binary_cross_entropy_with_logits(
            prediction.edge_presence_logit,
            supervision.edge_presence,
            reduction="none",
        )
        presence = _masked_mean(presence, edge_observable)
        distance = relation_realization_loss(
            prediction.edge_distance[..., :1],
            supervision.edge_distance,
            prediction.edge_distance[..., 1:2],
            edge_observable,
        )
        direction = relation_realization_loss(
            prediction.edge_direction_fourier,
            supervision.edge_direction_fourier,
            prediction.edge_direction_log_scale.repeat_interleave(2, dim=-1),
            edge_observable.expand_as(prediction.edge_direction_fourier),
        )
    with _profile_scope(runtime_profile, "local_metric_loss"):
        shell = shell_pair_loss(
            prediction.edge_shell_logits, supervision.edge_shell, edge_mask
        )
        coordination = coordination_loss(
            prediction.edge_coordination,
            supervision.edge_coordination,
            edge_observable.expand_as(prediction.edge_coordination),
        )
    with _profile_scope(runtime_profile, "relation_loss"):
        triplet_presence = functional.binary_cross_entropy_with_logits(
            prediction.triplet_presence_logit,
            supervision.triplet_presence,
            reduction="none",
        )
        triplet_presence = _masked_mean(triplet_presence, triplet_observable)
        triplet = relation_realization_loss(
            prediction.triplet_angle[..., :1],
            supervision.triplet_cosine,
            prediction.triplet_angle[..., 1:2],
            triplet_observable,
        )
        relation = presence + distance + direction + triplet_presence + triplet
        distance_scale = prediction.edge_distance[..., 1:2].exp().clamp_min(1.0e-8)
        distance_residual = (
            prediction.edge_distance[..., :1] - supervision.edge_distance
        ) / distance_scale
        direction_scale = prediction.edge_direction_log_scale.exp().clamp_min(1.0e-8)
        direction_residual = (
            (prediction.edge_direction_fourier - supervision.edge_direction_fourier)
            .square()
            .reshape(prediction.batch_size, prediction.edge_count, 3, 2)
            .sum(dim=-1)
            / direction_scale.square()
        ).mean(dim=-1, keepdim=True)
        residual = torch.cat((distance_residual, direction_residual), dim=-1)
    with _profile_scope(runtime_profile, "local_metric_loss"):
        local_relation_metric = (
            nearest_neighbor_loss(
                prediction.edge_distance[..., :1],
                supervision.edge_distance,
                edge_observable,
            )
            + shell
            + coordination
            + _masked_mean(
                functional.smooth_l1_loss(
                    prediction.triplet_angle[..., :1],
                    supervision.triplet_cosine,
                    reduction="none",
                ),
                triplet_observable,
            )
        )
    return relation, local_relation_metric, residual


def _flow_endpoint_metric(
    predicted_endpoint: torch.Tensor,
    target: torch.Tensor,
    mask: torch.Tensor,
    metric: torch.Tensor,
) -> torch.Tensor:
    difference = predicted_endpoint - target
    difference = difference - torch.ceil(difference - 0.5)
    difference = difference * mask.to(difference.dtype)
    quadratic = (
        difference.unsqueeze(1).bmm(metric).bmm(difference.unsqueeze(-1)).flatten()
    )
    active = mask.any(dim=-1)
    return _masked_mean(quadratic, active)


def _memory_loss(
    batch: FormalGeometryTrainingBatchV2,
    current_residual: torch.Tensor,
) -> torch.Tensor:
    replay_rows = torch.tensor(
        [mode == MODEL_REALIZED_UNROLL for mode in batch.train_fit.state_modes],
        dtype=torch.bool,
        device=current_residual.device,
    )
    if not bool(replay_rows.any()):
        return current_residual.sum() * 0.0
    graph_mask = batch.model_input.active_orbit_graph.edge_mask.to(current_residual.device)
    stored = batch.model_input.persistent_memory.tensorize().edge.to(
        current_residual.device, current_residual.dtype
    )[..., 14:16]
    weights = graph_mask.unsqueeze(-1).to(current_residual.dtype)
    denominator = weights.sum(dim=(1, 2)).clamp_min(1.0)
    next_nll = (current_residual.square() * weights).sum(dim=(1, 2)) / denominator
    previous_nll = (stored.square() * weights).sum(dim=(1, 2)) / denominator
    stale = ((current_residual - stored).square() * weights).sum(dim=(1, 2)) / denominator
    # memory_consistency_loss squares this argument.  Passing sqrt(stale)
    # directly is algebraically correct but has an undefined derivative at
    # stale == 0 (sqrt(0).square() produces a NaN backward in PyTorch).  The
    # offset and subtraction preserve the intended value while keeping the
    # zero-residual gradient finite.
    epsilon = torch.finfo(stale.dtype).eps
    return memory_consistency_loss(
        next_relation_nll=next_nll[replay_rows],
        previous_relation_nll=previous_nll[replay_rows],
        stale_residual=(stale[replay_rows] + epsilon).sqrt(),
    ) - epsilon


def compute_production_losses_v2(
    model: FormalGeometryV2Model,
    batch: FormalGeometryTrainingBatchV2,
    supervision: Phase2ASupervisionV2,
    *,
    generator: torch.Generator,
    projected_physics_targets: torch.Tensor,
    normalizer: LossScaleNormalizerV2,
    formal_endpoint_component: torch.Tensor | None = None,
    weights: Mapping[str, float] | None = None,
    runtime_profile: RuntimeProfileScopeV2 | None = None,
) -> ProductionLossResultV2:
    model_input, prediction, context = model.condition(batch.model_input)
    device = model_input.composition.device
    dtype = model_input.composition.dtype
    if projected_physics_targets.shape != supervision.free_parameter_mask.shape:
        raise ValueError("projected Guide targets must have shape [B,3]")
    with _profile_scope(runtime_profile, "flow_loss_forward"):
        base_noise = torch.rand(
            supervision.free_parameter_mask.shape,
            generator=generator,
            device=device,
            dtype=dtype,
        )
        flow_batch = build_flow_matching_batch(
            base_noise=base_noise,
            equivalent_targets=supervision.equivalent_targets,
            free_parameter_mask=supervision.free_parameter_mask,
            generator=generator,
            metric=supervision.induced_metric,
        )
        velocity = model.flow(
            flow_batch.u_tau,
            flow_batch.tau,
            context,
            supervision.wyckoff_id,
            supervision.free_parameter_mask,
        )
        predicted_endpoint = torch.remainder(
            flow_batch.u_tau + (1.0 - flow_batch.tau).unsqueeze(-1) * velocity,
            1.0,
        )
        parameter_metric = _flow_endpoint_metric(
            predicted_endpoint,
            flow_batch.selected_target,
            supervision.free_parameter_mask,
            flow_batch.metric,
        )
        flow_loss = flow_matching_loss(velocity, flow_batch)
    relation, local_relation, relation_residual = _relation_losses(
        prediction,
        supervision,
        model_input.active_orbit_graph,
        runtime_profile=runtime_profile,
    )
    physics_mask = supervision.free_parameter_mask & (
        projected_physics_targets.to(device).norm(dim=-1, keepdim=True) > 1.0e-12
    )
    with _profile_scope(runtime_profile, "physics_aware_loss"):
        physics = physics_aware_loss(
            velocity,
            projected_physics_targets.to(device=device, dtype=dtype),
            physics_mask,
        )
    formal = (
        velocity.sum() * 0.0
        if formal_endpoint_component is None
        else formal_endpoint_component
    )
    if formal.ndim != 0 or not bool(torch.isfinite(formal)):
        raise ValueError("formal endpoint component must be a finite scalar")
    with _profile_scope(runtime_profile, "memory_consistency_loss"):
        memory_loss = _memory_loss(batch, relation_residual)
    raw: dict[str, torch.Tensor] = {
        "flow": flow_loss,
        "relation_realization": relation,
        "local_metric": local_relation + parameter_metric,
        "physics_aware": physics,
        "formal_endpoint": formal,
        "memory_consistency": memory_loss,
    }
    with _profile_scope(runtime_profile, "loss_normalization"):
        normalized = normalizer.normalize(raw)
        frozen_weights = {name: 1.0 for name in NAMED_PRODUCTION_LOSSES_V2}
        if weights is not None:
            if tuple(weights) != NAMED_PRODUCTION_LOSSES_V2:
                raise ValueError("loss weights must cover exactly the named objective")
            frozen_weights = {name: float(weights[name]) for name in NAMED_PRODUCTION_LOSSES_V2}
        total = sum(normalized[name] * frozen_weights[name] for name in NAMED_PRODUCTION_LOSSES_V2)
    if total.ndim != 0 or not bool(torch.isfinite(total)):
        raise FloatingPointError("normalized production loss is non-finite")
    return ProductionLossResultV2(raw, normalized, total)


def compute_formal_endpoint_alignment_loss_v2(
    *,
    prepared: PreparedFormalEndpointV2,
    result: FormalEndpointResultV2,
    supervision: Phase2ASupervisionV2,
    sample_index: int,
    calibration: RelationGeometryCalibrationV2,
) -> torch.Tensor:
    graph = prepared.model_input.active_orbit_graph
    prediction = prepared.prediction
    realized = calculate_realized_relations_v2(result.state, graph, calibration)
    edge_mask = graph.edge_mask.unsqueeze(-1)
    triplet_mask = graph.triplet_mask.unsqueeze(-1)
    target_distance = supervision.edge_distance[sample_index : sample_index + 1]
    target_direction = supervision.edge_direction_fourier[
        sample_index : sample_index + 1
    ]
    target_shell = supervision.edge_shell[sample_index : sample_index + 1]
    target_coordination = supervision.edge_coordination[
        sample_index : sample_index + 1
    ]
    target_triplet = supervision.triplet_cosine[sample_index : sample_index + 1]
    relation = relation_realization_loss(
        prediction.edge_distance[..., :1],
        realized.edge_state[..., 1:2],
        prediction.edge_distance[..., 1:2],
        edge_mask,
    ) + relation_realization_loss(
        prediction.edge_direction_fourier,
        realized.edge_state[..., 2:8],
        prediction.edge_direction_log_scale.repeat_interleave(2, dim=-1),
        edge_mask.expand_as(prediction.edge_direction_fourier),
    )
    nearest = nearest_neighbor_loss(
        realized.edge_state[..., 1:2], target_distance, edge_mask
    )
    shell = _masked_mean(
        functional.smooth_l1_loss(
            realized.edge_state[..., 8:12], target_shell, reduction="none"
        ),
        edge_mask.expand_as(target_shell),
    )
    angle = _masked_mean(
        functional.smooth_l1_loss(
            realized.triplet_cosine, target_triplet, reduction="none"
        ),
        triplet_mask,
    )
    coordination = coordination_loss(
        realized.edge_state[..., 12:14],
        target_coordination,
        edge_mask.expand_as(target_coordination),
    )
    target = supervision.equivalent_targets[sample_index, 0].unsqueeze(0)
    mask = supervision.free_parameter_mask[sample_index : sample_index + 1]
    metric = supervision.induced_metric[sample_index : sample_index + 1]
    torus_metric = _flow_endpoint_metric(result.endpoint_values, target, mask, metric)
    legality = result.endpoint_values.sum() * 0.0 + (0.0 if result.receipt.accepted else 1.0)
    return formal_endpoint_loss(
        relation_realization=relation,
        nearest_neighbor=nearest,
        shell_pair=shell,
        angle=angle,
        coordination=coordination,
        equivalent_orbit_rmsd=torus_metric,
        legality_barrier=legality,
    )


__all__ = [
    "GuideTeacherTargetReceiptV2",
    "LossScaleNormalizerV2",
    "NAMED_PRODUCTION_LOSSES_V2",
    "ProductionLossResultV2",
    "build_projected_guide_teacher_targets_v2",
    "compute_formal_endpoint_alignment_loss_v2",
    "compute_production_losses_v2",
]
