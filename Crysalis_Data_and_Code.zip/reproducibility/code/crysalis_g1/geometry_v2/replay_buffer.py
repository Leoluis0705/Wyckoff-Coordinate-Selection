from __future__ import annotations

import hashlib
import json
import os
import tempfile
import time
from collections import Counter
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import torch

from crysalis_g1.symmetry.assembly import SymmetryAssemblyState
from crysalis_g1.symmetry.wyckoff import ConstrainedLattice, OrbitState

from .memory import PersistentRelationMemoryV2


REPLAY_RECORD_SCHEMA_V2 = "crysalis-geometry-v2-model-realized-replay.1.0.0"
REPLAY_BUFFER_SCHEMA_V2 = "crysalis-geometry-v2-replay-buffer.1.0.0"


def _canonical_bytes(payload: object) -> bytes:
    return json.dumps(
        payload, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")


def _sha256_payload(payload: object) -> str:
    return hashlib.sha256(_canonical_bytes(payload)).hexdigest()


def _jsonable(value: object) -> object:
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().tolist()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_jsonable(item) for item in value]
    if isinstance(value, np.generic):
        return value.item()
    return value


def _canonicalize_rollout_state_and_memory_v2(
    state: SymmetryAssemblyState,
    memory: PersistentRelationMemoryV2,
) -> tuple[SymmetryAssemblyState, PersistentRelationMemoryV2]:
    count = len(state.orbits)
    order = tuple(
        sorted(
            range(count),
            key=lambda index: state.orbits[index].orbit_instance_id,
        )
    )
    if order == tuple(range(count)):
        return state, memory
    tensors = memory.tensorize()
    orbit = tensors.orbit.clone()
    edge = tensors.edge.clone()
    indices = torch.as_tensor(order, dtype=torch.long, device=orbit.device)
    orbit[:, :count] = tensors.orbit.index_select(1, indices)
    edge[:, :count] = tensors.edge.index_select(1, indices.to(edge.device))
    canonical_memory = PersistentRelationMemoryV2.from_tensors(
        orbit=orbit,
        edge=edge,
        global_memory=tensors.global_memory,
    )
    canonical_state = replace(
        state,
        orbits=tuple(state.orbits[index] for index in order),
    )
    return canonical_state, canonical_memory


def assembly_state_to_payload_v2(state: SymmetryAssemblyState) -> dict[str, Any]:
    return {
        "target_space_group": state.target_space_group,
        "composition": state.composition,
        "remaining_composition": state.remaining_composition,
        "lattice": state.lattice.to_dict(),
        "orbits": [orbit.to_dict() for orbit in state.orbits],
        "terminated": state.terminated,
    }


def assembly_state_from_payload_v2(payload: Mapping[str, Any]) -> SymmetryAssemblyState:
    lattice_payload = dict(payload["lattice"])
    lattice = ConstrainedLattice(
        target_space_group=int(lattice_payload["target_space_group"]),
        crystal_system=str(lattice_payload["crystal_system"]),
        conventional_parameters=tuple(
            float(value) for value in lattice_payload["conventional_parameters"]
        ),
        conventional_matrix=tuple(
            tuple(float(value) for value in row)
            for row in lattice_payload["conventional_matrix"]
        ),
        base_primitive_matrix=tuple(
            tuple(float(value) for value in row)
            for row in lattice_payload["base_primitive_matrix"]
        ),
        primitive_matrix=tuple(
            tuple(float(value) for value in row)
            for row in lattice_payload["primitive_matrix"]
        ),
        cell_transform_values=tuple(
            tuple(int(value) for value in row)
            for row in lattice_payload["cell_transform_values"]
        ),
    )
    return SymmetryAssemblyState(
        target_space_group=int(payload["target_space_group"]),
        composition=tuple(
            (int(species), int(count)) for species, count in payload["composition"]
        ),
        remaining_composition=tuple(
            (int(species), int(count))
            for species, count in payload["remaining_composition"]
        ),
        lattice=lattice,
        orbits=tuple(OrbitState.from_dict(dict(item)) for item in payload["orbits"]),
        terminated=bool(payload.get("terminated", False)),
    )


def memory_to_payload_v2(memory: PersistentRelationMemoryV2) -> dict[str, Any]:
    tensors = memory.tensorize()
    return {
        "orbit": tensors.orbit.cpu().tolist(),
        "edge": tensors.edge.cpu().tolist(),
        "global_memory": tensors.global_memory.cpu().tolist(),
    }


def memory_from_payload_v2(
    payload: Mapping[str, Any], *, device: str | torch.device = "cpu"
) -> PersistentRelationMemoryV2:
    return PersistentRelationMemoryV2.from_tensors(
        orbit=torch.tensor(payload["orbit"], dtype=torch.float32, device=device),
        edge=torch.tensor(payload["edge"], dtype=torch.float32, device=device),
        global_memory=torch.tensor(
            payload["global_memory"], dtype=torch.float32, device=device
        ),
    )


@dataclass(frozen=True, slots=True)
class ModelRealizedReplayRecordV2:
    schema_version: str
    record_id: str
    source_split: str
    source_checkpoint_sha256: str
    train_fit_event_id: str
    parent_id: str
    trajectory_id: str
    sequence_index: int
    unroll_length: int
    registered_seed: int
    action_path_hash: str
    pre_state_hash: str
    post_state_hash: str
    memory_before_hash: str
    memory_after_hash: str
    endpoint_accepted: bool
    failure_reason_codes: tuple[str, ...]
    projector_receipt: Mapping[str, Any]
    sampling_receipt: Mapping[str, Any]
    pre_state_payload: Mapping[str, Any]
    post_state_payload: Mapping[str, Any]
    memory_before_payload: Mapping[str, Any]
    memory_after_payload: Mapping[str, Any]
    buffer_generation_interval: int

    def __post_init__(self) -> None:
        if self.schema_version != REPLAY_RECORD_SCHEMA_V2:
            raise ValueError("unsupported replay record schema")
        if self.source_split != "train_fit":
            raise ValueError("replay records must be train_fit only")
        for label, value in (
            ("record", self.record_id),
            ("checkpoint", self.source_checkpoint_sha256),
            ("action path", self.action_path_hash),
            ("pre state", self.pre_state_hash),
            ("post state", self.post_state_hash),
            ("memory before", self.memory_before_hash),
            ("memory after", self.memory_after_hash),
        ):
            if len(value) != 64:
                raise ValueError(f"{label} hash must be SHA-256")
        if self.unroll_length not in (2, 3, 4):
            raise ValueError("replay unroll length must be 2, 3, or 4")
        if self.endpoint_accepted and self.failure_reason_codes:
            raise ValueError("accepted replay record cannot carry failure codes")
        if not self.endpoint_accepted and not self.failure_reason_codes:
            raise ValueError("failed replay record must preserve a failure code")
        expected = self._computed_record_id()
        if self.record_id != expected:
            raise ValueError("replay record content hash mismatch")

    def _content(self) -> dict[str, Any]:
        payload = asdict(self)
        payload.pop("record_id", None)
        return payload

    def _computed_record_id(self) -> str:
        return _sha256_payload(self._content())

    @classmethod
    def create(
        cls,
        *,
        source_checkpoint_sha256: str,
        train_fit_event_id: str,
        parent_id: str,
        trajectory_id: str,
        sequence_index: int,
        unroll_length: int,
        registered_seed: int,
        action_path_hash: str,
        pre_state: SymmetryAssemblyState,
        post_state: SymmetryAssemblyState,
        memory_before: PersistentRelationMemoryV2,
        memory_after: PersistentRelationMemoryV2,
        endpoint_accepted: bool,
        failure_reason_codes: Sequence[str],
        projector_receipt: Mapping[str, Any],
        sampling_receipt: Mapping[str, Any],
        buffer_generation_interval: int,
    ) -> ModelRealizedReplayRecordV2:
        pre_payload = assembly_state_to_payload_v2(pre_state)
        post_payload = assembly_state_to_payload_v2(post_state)
        before_payload = memory_to_payload_v2(memory_before)
        after_payload = memory_to_payload_v2(memory_after)
        kwargs: dict[str, Any] = {
            "schema_version": REPLAY_RECORD_SCHEMA_V2,
            "record_id": "0" * 64,
            "source_split": "train_fit",
            "source_checkpoint_sha256": source_checkpoint_sha256,
            "train_fit_event_id": train_fit_event_id,
            "parent_id": parent_id,
            "trajectory_id": trajectory_id,
            "sequence_index": int(sequence_index),
            "unroll_length": int(unroll_length),
            "registered_seed": int(registered_seed),
            "action_path_hash": action_path_hash,
            "pre_state_hash": _sha256_payload(pre_payload),
            "post_state_hash": _sha256_payload(post_payload),
            "memory_before_hash": memory_before.state_hash(),
            "memory_after_hash": memory_after.state_hash(),
            "endpoint_accepted": bool(endpoint_accepted),
            "failure_reason_codes": tuple(str(value) for value in failure_reason_codes),
            "projector_receipt": _jsonable(dict(projector_receipt)),
            "sampling_receipt": _jsonable(dict(sampling_receipt)),
            "pre_state_payload": pre_payload,
            "post_state_payload": post_payload,
            "memory_before_payload": before_payload,
            "memory_after_payload": after_payload,
            "buffer_generation_interval": int(buffer_generation_interval),
        }
        provisional = object.__new__(cls)
        for field, value in kwargs.items():
            object.__setattr__(provisional, field, value)
        kwargs["record_id"] = provisional._computed_record_id()
        return cls(**kwargs)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> ModelRealizedReplayRecordV2:
        normalized = dict(payload)
        normalized["failure_reason_codes"] = tuple(normalized["failure_reason_codes"])
        return cls(**normalized)

    def pre_state(self) -> SymmetryAssemblyState:
        return assembly_state_from_payload_v2(self.pre_state_payload)

    def post_state(self) -> SymmetryAssemblyState:
        return assembly_state_from_payload_v2(self.post_state_payload)

    def memory_before(
        self, *, device: str | torch.device = "cpu"
    ) -> PersistentRelationMemoryV2:
        return memory_from_payload_v2(self.memory_before_payload, device=device)

    def memory_after(
        self, *, device: str | torch.device = "cpu"
    ) -> PersistentRelationMemoryV2:
        return memory_from_payload_v2(self.memory_after_payload, device=device)


@dataclass(frozen=True, slots=True)
class ReplayBufferV2:
    records: tuple[ModelRealizedReplayRecordV2, ...]
    cursor: int
    buffer_sha256: str

    def __post_init__(self) -> None:
        if not self.records:
            raise ValueError("replay buffer must retain at least one record")
        if not 0 <= self.cursor <= len(self.records):
            raise ValueError("replay cursor is outside the immutable buffer")
        if len({record.record_id for record in self.records}) != len(self.records):
            raise ValueError("replay record IDs must be unique")
        expected = _sha256_payload([record.to_dict() for record in self.records])
        if self.buffer_sha256 != expected:
            raise ValueError("replay buffer hash mismatch")

    @classmethod
    def create(
        cls, records: Sequence[ModelRealizedReplayRecordV2], *, cursor: int = 0
    ) -> ReplayBufferV2:
        frozen = tuple(records)
        return cls(
            frozen,
            int(cursor),
            _sha256_payload([record.to_dict() for record in frozen]),
        )

    def take(
        self, count: int
    ) -> tuple[tuple[ModelRealizedReplayRecordV2, ...], ReplayBufferV2]:
        if type(count) is not int or count <= 0:
            raise ValueError("replay take count must be positive")
        stop = self.cursor + count
        if stop > len(self.records):
            raise IndexError("replay buffer exhausted; refill is forbidden")
        return self.records[self.cursor : stop], replace(self, cursor=stop)

    def write(self, root: str | Path) -> None:
        directory = Path(root)
        directory.mkdir(parents=True, exist_ok=False)
        records_path = directory / "records.jsonl"
        manifest_path = directory / "manifest.json"
        records_bytes = b"".join(
            _canonical_bytes(record.to_dict()) + b"\n" for record in self.records
        )
        records_path.write_bytes(records_bytes)
        manifest = {
            "schema_version": REPLAY_BUFFER_SCHEMA_V2,
            "record_count": len(self.records),
            "cursor": self.cursor,
            "buffer_sha256": self.buffer_sha256,
            "records_file_sha256": hashlib.sha256(records_bytes).hexdigest(),
        }
        _atomic_write(manifest_path, json.dumps(manifest, indent=2, sort_keys=True).encode() + b"\n")

    @classmethod
    def read(cls, root: str | Path) -> ReplayBufferV2:
        directory = Path(root)
        manifest = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
        if manifest.get("schema_version") != REPLAY_BUFFER_SCHEMA_V2:
            raise ValueError("unsupported replay buffer manifest")
        records_bytes = (directory / "records.jsonl").read_bytes()
        if hashlib.sha256(records_bytes).hexdigest() != manifest["records_file_sha256"]:
            raise ValueError("replay records file hash mismatch")
        records = tuple(
            ModelRealizedReplayRecordV2.from_dict(json.loads(line))
            for line in records_bytes.splitlines()
            if line.strip()
        )
        if len(records) != int(manifest["record_count"]):
            raise ValueError("replay record count mismatch")
        return cls(records, int(manifest["cursor"]), str(manifest["buffer_sha256"]))


@dataclass(frozen=True, slots=True)
class ReplayGenerationSummaryV2:
    trajectory_count: int
    record_count: int
    requested_unroll_length: int
    completed_endpoint_count: int
    finite_endpoint_count: int
    projector_accept_count: int
    composition_valid_count: int
    multiplicity_valid_count: int
    target_sg_context_valid_count: int
    short_contact_count: int
    memory_serialization_success_count: int
    failure_taxonomy: Mapping[str, int]
    mean_unroll_completion: float
    wall_seconds: float
    endpoint_per_second: float
    trajectory_per_second: float
    peak_vram_bytes: int


def model_state_sha256_v2(model: torch.nn.Module) -> str:
    digest = hashlib.sha256(b"crysalis-geometry-v2-model-state.1")
    for name, tensor in sorted(model.state_dict().items()):
        value = tensor.detach().cpu().contiguous()
        digest.update(name.encode())
        digest.update(str(value.dtype).encode())
        digest.update(str(tuple(value.shape)).encode())
        digest.update(value.numpy().tobytes())
    return digest.hexdigest()


def _registered_replay_seed(
    root_seed: int, trajectory_id: str, sequence_index: int, checkpoint_hash: str
) -> int:
    digest = hashlib.sha256(
        f"{root_seed}:{trajectory_id}:{sequence_index}:{checkpoint_hash}".encode()
    ).digest()
    return int.from_bytes(digest[:8], "big") % (2**63 - 1)


def generate_model_realized_replay_v2(
    *,
    model: torch.nn.Module,
    trajectories: Sequence[object],
    partner_event: object,
    normalizer: object,
    guide_objective: object,
    projector: object,
    relation_calibration: object,
    unroll_length: int,
    registered_seed_root: int,
    buffer_generation_interval: int,
    device: str | torch.device,
) -> tuple[ReplayBufferV2, ReplayGenerationSummaryV2]:
    from .model import FormalGeometryV2Model
    from .phase2a_adapter import build_phase2a_training_batch_v2
    from .training import _slice_model_input

    if not isinstance(model, FormalGeometryV2Model):
        raise TypeError("replay generation requires FormalGeometryV2Model")
    if unroll_length not in (2, 3, 4):
        raise ValueError("replay unroll length must be 2, 3, or 4")
    if not trajectories:
        raise ValueError("replay generation requires registered train_fit trajectories")
    if getattr(partner_event, "split", None) != "train_fit" or getattr(
        partner_event, "terminal", True
    ):
        raise ValueError("replay tensorization partner must be a real train_fit event")
    torch_device = torch.device(device)
    if torch_device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(torch_device)
    checkpoint_hash = model_state_sha256_v2(model)
    was_training = model.training
    model.eval()
    started = time.perf_counter()
    records: list[ModelRealizedReplayRecordV2] = []
    failure_taxonomy: Counter[str] = Counter()
    completed_by_job: list[int] = []
    finite_count = accepted_count = composition_count = multiplicity_count = 0
    sg_count = short_contact_count = memory_serialized = 0
    try:
        with torch.no_grad():
            for trajectory in trajectories:
                if getattr(trajectory, "source_split", None) != "train_fit":
                    raise ValueError("validation/test trajectory entered replay generation")
                steps = tuple(getattr(trajectory, "steps"))[:unroll_length]
                if not steps:
                    completed_by_job.append(0)
                    continue
                first_event = steps[0].event
                current = SymmetryAssemblyState.empty(
                    target_space_group=first_event.target_space_group,
                    composition=first_event.composition,
                    lattice=first_event.lattice,
                )
                memory = PersistentRelationMemoryV2.empty(
                    1, 20, 20, device=torch_device
                )
                completed = 0
                for step in steps:
                    event = step.event
                    expected_ids = tuple(
                        orbit.orbit_instance_id for orbit in event.active_orbits
                    )
                    current_ids = tuple(orbit.orbit_instance_id for orbit in current.orbits)
                    if current_ids != expected_ids:
                        raise ValueError("model-realized rollout departed from the correct action path")
                    built = build_phase2a_training_batch_v2(
                        (event, partner_event),
                        batch_index=0,
                        normalizer=normalizer,
                        device=torch_device,
                        shell_boundaries_angstrom=relation_calibration.shell_boundaries_angstrom,
                        active_orbit_overrides=(current.orbits, None),
                        memory_overrides=(memory, None),
                    )
                    model_input = _slice_model_input(built.training_batch.model_input, 0)
                    supervision = built.supervision
                    state_for_endpoint = _state_from_current_and_event(current, event)
                    registered_seed = _registered_replay_seed(
                        registered_seed_root,
                        trajectory.trajectory_id,
                        step.sequence_index,
                        checkpoint_hash,
                    )
                    result = model.run_inference(
                        state=state_for_endpoint,
                        model_input=model_input,
                        wyckoff_id=supervision.wyckoff_id[:1],
                        free_parameter_mask=supervision.free_parameter_mask[:1],
                        registered_seed=registered_seed,
                        candidate_free_dof=int(
                            supervision.free_parameter_mask[0].sum().item()
                        ),
                        guide_objective=guide_objective,
                        projector=projector,
                        relation_calibration=relation_calibration,
                    )
                    finite = bool(torch.isfinite(result.endpoint_values).all())
                    finite_count += int(finite)
                    accepted_count += int(result.receipt.accepted)
                    projector_payload = (
                        result.receipt.projector.to_dict()
                        if hasattr(result.receipt.projector, "to_dict")
                        else {}
                    )
                    composition_count += int(
                        projector_payload.get("composition_valid") is True
                    )
                    multiplicity_count += int(
                        projector_payload.get("multiplicity_valid") is True
                    )
                    sg_count += int(
                        result.receipt.target_space_group == event.target_space_group
                    )
                    short_contact_count += int(
                        "SHORT_CONTACT" in result.receipt.failure_reason_codes
                        or projector_payload.get("minimum_distance_valid") is False
                    )
                    for reason in result.receipt.failure_reason_codes:
                        failure_taxonomy[str(reason)] += 1
                    memory_after = result.updated_memory or memory
                    post_state = result.state
                    if result.receipt.accepted:
                        post_state, memory_after = (
                            _canonicalize_rollout_state_and_memory_v2(
                                post_state, memory_after
                            )
                        )
                    try:
                        round_trip = memory_from_payload_v2(
                            memory_to_payload_v2(memory_after), device=torch_device
                        )
                        memory_serialized += int(
                            round_trip.state_hash() == memory_after.state_hash()
                        )
                    except (TypeError, ValueError, FloatingPointError):
                        failure_taxonomy["MEMORY_SERIALIZATION_FAILURE"] += 1
                    failure_codes = result.receipt.failure_reason_codes
                    if not result.receipt.accepted and not failure_codes:
                        failure_codes = ("ENDPOINT_REJECTED_WITHOUT_REASON",)
                        failure_taxonomy[failure_codes[0]] += 1
                    record = ModelRealizedReplayRecordV2.create(
                        source_checkpoint_sha256=checkpoint_hash,
                        train_fit_event_id=event.event_key,
                        parent_id=event.parent_id,
                        trajectory_id=trajectory.trajectory_id,
                        sequence_index=step.sequence_index,
                        unroll_length=unroll_length,
                        registered_seed=registered_seed,
                        action_path_hash=step.action_path_hash,
                        pre_state=current,
                        post_state=post_state,
                        memory_before=memory,
                        memory_after=memory_after,
                        endpoint_accepted=result.receipt.accepted,
                        failure_reason_codes=failure_codes,
                        projector_receipt=projector_payload,
                        sampling_receipt=result.receipt.sampling.state_dict(),
                        buffer_generation_interval=buffer_generation_interval,
                    )
                    records.append(record)
                    completed += 1
                    if not result.receipt.accepted:
                        break
                    current = post_state
                    memory = memory_after
                completed_by_job.append(completed)
    finally:
        model.train(was_training)
    wall = time.perf_counter() - started
    if not records:
        raise RuntimeError("registered replay jobs produced no preserved records")
    buffer = ReplayBufferV2.create(records)
    summary = ReplayGenerationSummaryV2(
        trajectory_count=len(trajectories),
        record_count=len(records),
        requested_unroll_length=unroll_length,
        completed_endpoint_count=len(records),
        finite_endpoint_count=finite_count,
        projector_accept_count=accepted_count,
        composition_valid_count=composition_count,
        multiplicity_valid_count=multiplicity_count,
        target_sg_context_valid_count=sg_count,
        short_contact_count=short_contact_count,
        memory_serialization_success_count=memory_serialized,
        failure_taxonomy=dict(sorted(failure_taxonomy.items())),
        mean_unroll_completion=float(
            np.mean([value / unroll_length for value in completed_by_job])
        ),
        wall_seconds=wall,
        endpoint_per_second=len(records) / max(wall, 1.0e-12),
        trajectory_per_second=len(trajectories) / max(wall, 1.0e-12),
        peak_vram_bytes=(
            int(torch.cuda.max_memory_allocated(torch_device))
            if torch_device.type == "cuda"
            else 0
        ),
    )
    return buffer, summary


def _state_from_current_and_event(current: SymmetryAssemblyState, event: object) -> SymmetryAssemblyState:
    candidate = event.candidate_orbit
    if candidate is None:
        raise ValueError("replay endpoint requires a candidate event")
    remaining = current.remaining
    remaining[candidate.species] -= candidate.multiplicity
    if remaining[candidate.species] < 0:
        raise ValueError("correct action path exceeds remaining composition")
    if remaining[candidate.species] == 0:
        del remaining[candidate.species]
    return replace(
        current,
        remaining_composition=tuple(sorted(remaining.items())),
        orbits=(*current.orbits, candidate),
    )


def _atomic_write(path: Path, payload: bytes) -> None:
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary_name, path)
    finally:
        try:
            os.unlink(temporary_name)
        except FileNotFoundError:
            pass


__all__ = [
    "ModelRealizedReplayRecordV2",
    "REPLAY_BUFFER_SCHEMA_V2",
    "REPLAY_RECORD_SCHEMA_V2",
    "ReplayBufferV2",
    "ReplayGenerationSummaryV2",
    "assembly_state_from_payload_v2",
    "assembly_state_to_payload_v2",
    "memory_from_payload_v2",
    "memory_to_payload_v2",
    "generate_model_realized_replay_v2",
    "model_state_sha256_v2",
]
