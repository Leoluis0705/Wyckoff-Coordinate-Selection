from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Collection, Mapping

import torch
from torch import nn

from crysalis_g1.experiments.local_relation_learning import LinearSplineKANLayer
from crysalis_g1.geometry_v2.memory import PersistentRelationMemoryV2


ORBIT_FEATURE_DIM = 64
CANDIDATE_FEATURE_DIM = 64
EDGE_FEATURE_DIM = 50
TRIPLET_FEATURE_DIM = 19

_FORBIDDEN_TRAIN_FIT_FIELDS = frozenset(
    {
        "parent_id",
        "validation_coordinates",
        "test_coordinates",
        "target_free_parameters",
        "future_free_parameters",
        "future_action_sequence",
        "future_realized_relation",
        "database_lookup_data",
        "database_lookup_hit",
    }
)
_MODEL_INPUT_FIELDS = frozenset(
    {
        "composition",
        "target_sg",
        "lattice",
        "active_orbit_graph",
        "candidate_query",
        "persistent_memory",
    }
)
_ALLOWED_PROVENANCE = frozenset(
    {
        "public_train_fit_forward_deconstruction",
        "current_generation_state",
    }
)


def validate_train_fit_input_fields(fields: Collection[str]) -> None:
    if any(not isinstance(field, str) or not field for field in fields):
        raise ValueError("train-fit input field names must be non-empty strings")
    forbidden = sorted(set(fields) & _FORBIDDEN_TRAIN_FIT_FIELDS)
    if forbidden:
        raise ValueError(f"forbidden train-fit input fields: {', '.join(forbidden)}")


def _validate_finite(name: str, value: torch.Tensor) -> None:
    if not (value.is_floating_point() and bool(torch.isfinite(value).all())):
        raise ValueError(f"{name} must be finite and floating point")


@dataclass(frozen=True, slots=True)
class ActiveOrbitGraphV2:
    active_orbits: torch.Tensor
    active_orbit_mask: torch.Tensor
    edge_index: torch.Tensor
    edge_mask: torch.Tensor
    triplet_index: torch.Tensor
    triplet_mask: torch.Tensor

    def __post_init__(self) -> None:
        if self.active_orbits.ndim != 3 or self.active_orbits.shape[-1] != 64:
            raise ValueError("active orbits must have shape [B,N,64]")
        batch_size, orbit_count = self.active_orbits.shape[:2]
        if orbit_count > 20:
            raise ValueError("graph permits at most 20 active-orbit slots")
        if self.active_orbit_mask.shape != (batch_size, orbit_count) or (
            self.active_orbit_mask.dtype is not torch.bool
        ):
            raise ValueError("active orbit mask must be boolean [B,N]")
        if self.edge_index.ndim != 2 or self.edge_index.shape[0] != batch_size:
            raise ValueError("edge index must have shape [B,E]")
        if self.edge_index.dtype is not torch.long:
            raise ValueError("edge index must use torch.long packed indices")
        edge_count = self.edge_index.shape[1]
        if edge_count > orbit_count:
            raise ValueError("edge slots cannot exceed orbit slots")
        if self.edge_mask.shape != (batch_size, edge_count) or (
            self.edge_mask.dtype is not torch.bool
        ):
            raise ValueError("edge mask must be boolean [B,E]")
        if self.triplet_index.ndim != 3 or self.triplet_index.shape[:1] != (
            batch_size,
        ) or self.triplet_index.shape[-1] != 2:
            raise ValueError("triplet index must have shape [B,T,2]")
        if self.triplet_index.dtype is not torch.long:
            raise ValueError("triplet index must use torch.long packed indices")
        triplet_count = self.triplet_index.shape[1]
        if triplet_count > orbit_count * (orbit_count - 1) // 2:
            raise ValueError("triplet slots exceed N(N-1)/2")
        if self.triplet_mask.shape != (batch_size, triplet_count) or (
            self.triplet_mask.dtype is not torch.bool
        ):
            raise ValueError("triplet mask must be boolean [B,T]")
        _validate_finite("active orbits", self.active_orbits)

        active_counts = self.active_orbit_mask.sum(dim=1).cpu()
        if bool((self.edge_mask.sum(dim=1).cpu() > active_counts).any()):
            raise ValueError("active edge count exceeds active orbit count")
        maximum_triplets = active_counts * (active_counts - 1) // 2
        if bool((self.triplet_mask.sum(dim=1).cpu() > maximum_triplets).any()):
            raise ValueError("active triplet count exceeds n_active*(n_active-1)/2")
        repeated_anchor = self.triplet_index[..., 0] == self.triplet_index[..., 1]
        if bool((self.triplet_mask.to(repeated_anchor.device) & repeated_anchor).any()):
            raise ValueError("active triplets require two distinct anchor orbits")

        if bool(self.edge_mask.any()):
            batch = torch.arange(batch_size, device=self.edge_index.device)[:, None]
            valid_index = (self.edge_index >= 0) & (self.edge_index < orbit_count)
            safe_index = self.edge_index.clamp(0, max(orbit_count - 1, 0))
            references_active = (
                self.active_orbit_mask.to(self.edge_index.device)[batch, safe_index]
                if orbit_count
                else torch.zeros_like(self.edge_mask)
            )
            if bool((self.edge_mask & ~(valid_index & references_active)).any()):
                raise ValueError("edge index must reference an active orbit")
        if bool(self.triplet_mask.any()):
            batch = torch.arange(batch_size, device=self.triplet_index.device)[
                :, None, None
            ]
            valid_index = (self.triplet_index >= 0) & (
                self.triplet_index < orbit_count
            )
            safe_index = self.triplet_index.clamp(0, max(orbit_count - 1, 0))
            references_active = (
                self.active_orbit_mask.to(self.triplet_index.device)[batch, safe_index]
                if orbit_count
                else torch.zeros_like(self.triplet_mask[..., None])
            )
            valid_triplet = (valid_index & references_active).all(dim=-1)
            if bool((self.triplet_mask & ~valid_triplet).any()):
                raise ValueError("triplet index must reference active orbits")

    @property
    def batch_size(self) -> int:
        return self.active_orbits.shape[0]

    @property
    def orbit_count(self) -> int:
        return self.active_orbits.shape[1]

    @property
    def edge_count(self) -> int:
        return self.edge_index.shape[1]

    @property
    def triplet_count(self) -> int:
        return self.triplet_index.shape[1]


@dataclass(frozen=True, slots=True)
class RelationInputProvenanceV2:
    kind: str

    def __post_init__(self) -> None:
        if self.kind not in _ALLOWED_PROVENANCE:
            raise ValueError("forbidden or unsupported provenance")


@dataclass(frozen=True, slots=True)
class RelationModelInputV2:
    composition: torch.Tensor
    target_sg: torch.Tensor
    lattice: torch.Tensor
    active_orbit_graph: ActiveOrbitGraphV2
    candidate_query: torch.Tensor
    persistent_memory: PersistentRelationMemoryV2
    provenance: RelationInputProvenanceV2

    def __post_init__(self) -> None:
        if not isinstance(self.provenance, RelationInputProvenanceV2):
            raise TypeError("model input requires validated provenance")
        if not isinstance(self.active_orbit_graph, ActiveOrbitGraphV2):
            raise TypeError("model input requires a validated active-orbit graph")
        if not isinstance(self.persistent_memory, PersistentRelationMemoryV2):
            raise TypeError("model input requires validated persistent memory")
        tensors = (
            self.composition,
            self.target_sg,
            self.lattice,
            self.candidate_query,
        )
        if any(not isinstance(value, torch.Tensor) for value in tensors):
            raise TypeError("model input tensor fields must be torch tensors")
        graph = self.active_orbit_graph
        batch_size = graph.batch_size
        if self.composition.shape != (batch_size, 119):
            raise ValueError("composition must have shape [B,119]")
        if self.target_sg.shape != (batch_size,) or self.target_sg.dtype not in (
            torch.int32,
            torch.int64,
        ):
            raise ValueError("target space group must be an integer tensor [B]")
        if self.lattice.shape != (batch_size, 3, 3):
            raise ValueError("lattice must have shape [B,3,3]")
        if self.candidate_query.shape != (batch_size, 64):
            raise ValueError("candidate query must have shape [B,64]")
        for name, value in (
            ("composition", self.composition),
            ("lattice", self.lattice),
            ("candidate query", self.candidate_query),
        ):
            _validate_finite(name, value)
        if bool(((self.target_sg < 1) | (self.target_sg > 230)).any()):
            raise ValueError("target space group must be from 1 through 230")
        if (
            self.persistent_memory.batch_size != batch_size
            or self.persistent_memory.max_orbits != graph.orbit_count
            or self.persistent_memory.max_edges != graph.edge_count
        ):
            raise ValueError("persistent memory does not match packed graph")

    @classmethod
    def from_mapping(
        cls,
        payload: Mapping[str, object],
        *,
        provenance: RelationInputProvenanceV2,
    ) -> RelationModelInputV2:
        validate_train_fit_input_fields(payload.keys())
        supplied = set(payload)
        unexpected = sorted(supplied - _MODEL_INPUT_FIELDS)
        missing = sorted(_MODEL_INPUT_FIELDS - supplied)
        if unexpected:
            raise ValueError(
                f"forbidden or unsupported model input fields: {', '.join(unexpected)}"
            )
        if missing:
            raise ValueError(f"missing model input fields: {', '.join(missing)}")
        return cls(
            composition=payload["composition"],  # type: ignore[arg-type]
            target_sg=payload["target_sg"],  # type: ignore[arg-type]
            lattice=payload["lattice"],  # type: ignore[arg-type]
            active_orbit_graph=payload["active_orbit_graph"],  # type: ignore[arg-type]
            candidate_query=payload["candidate_query"],  # type: ignore[arg-type]
            persistent_memory=payload["persistent_memory"],  # type: ignore[arg-type]
            provenance=provenance,
        )


@dataclass(frozen=True, slots=True)
class RelationPredictionV2:
    edge_presence_logit: torch.Tensor
    edge_distance: torch.Tensor
    edge_direction_fourier: torch.Tensor
    edge_direction_log_scale: torch.Tensor
    edge_shell_logits: torch.Tensor
    edge_coordination: torch.Tensor
    edge_latent: torch.Tensor
    triplet_angle: torch.Tensor
    triplet_presence_logit: torch.Tensor
    triplet_latent: torch.Tensor

    def __post_init__(self) -> None:
        batch_size, edge_count = self.edge_distance.shape[:2]
        edge_shapes = {
            "edge presence logit": (self.edge_presence_logit, 1),
            "edge distance": (self.edge_distance, 2),
            "edge direction Fourier": (self.edge_direction_fourier, 6),
            "edge direction log scale": (self.edge_direction_log_scale, 3),
            "edge shell logits": (self.edge_shell_logits, 4),
            "edge coordination": (self.edge_coordination, 2),
            "edge latent": (self.edge_latent, 32),
        }
        for name, (value, width) in edge_shapes.items():
            if value.shape != (batch_size, edge_count, width):
                raise ValueError(f"{name} must have shape [B,E,{width}]")
            _validate_finite(name, value)
        if self.triplet_angle.ndim != 3 or self.triplet_angle.shape[-1] != 2:
            raise ValueError("triplet angle must have shape [B,T,2]")
        triplet_count = self.triplet_angle.shape[1]
        triplet_shapes = {
            "triplet angle": (self.triplet_angle, 2),
            "triplet presence logit": (self.triplet_presence_logit, 1),
            "triplet latent": (self.triplet_latent, 16),
        }
        for name, (value, width) in triplet_shapes.items():
            if value.shape != (batch_size, triplet_count, width):
                raise ValueError(f"{name} must have shape [B,T,{width}]")
            _validate_finite(name, value)

    @classmethod
    def zeros(
        cls,
        batch_size: int,
        edge_count: int,
        triplet_count: int,
        *,
        dtype: torch.dtype = torch.float32,
        device: torch.device | str | None = None,
    ) -> RelationPredictionV2:
        def edge(width: int) -> torch.Tensor:
            return torch.zeros(
                batch_size, edge_count, width, dtype=dtype, device=device
            )

        def triplet(width: int) -> torch.Tensor:
            return torch.zeros(
                batch_size, triplet_count, width, dtype=dtype, device=device
            )

        return cls(
            edge_presence_logit=edge(1),
            edge_distance=edge(2),
            edge_direction_fourier=edge(6),
            edge_direction_log_scale=edge(3),
            edge_shell_logits=edge(4),
            edge_coordination=edge(2),
            edge_latent=edge(32),
            triplet_angle=triplet(2),
            triplet_presence_logit=triplet(1),
            triplet_latent=triplet(16),
        )

    @property
    def batch_size(self) -> int:
        return self.edge_distance.shape[0]

    @property
    def edge_count(self) -> int:
        return self.edge_distance.shape[1]

    @property
    def triplet_count(self) -> int:
        return self.triplet_angle.shape[1]

    def with_edge_distance(self, value: torch.Tensor) -> RelationPredictionV2:
        if value.shape != self.edge_distance.shape:
            raise ValueError("replacement edge distance shape mismatch")
        _validate_finite("edge distance", value)
        return replace(self, edge_distance=value)

    def masked(
        self, edge_mask: torch.Tensor, triplet_mask: torch.Tensor
    ) -> RelationPredictionV2:
        if edge_mask.shape != (self.batch_size, self.edge_count):
            raise ValueError("relation edge mask shape mismatch")
        if triplet_mask.shape != (self.batch_size, self.triplet_count):
            raise ValueError("relation triplet mask shape mismatch")
        edge_weights = edge_mask.unsqueeze(-1).to(self.edge_distance.dtype)
        triplet_weights = triplet_mask.unsqueeze(-1).to(self.triplet_angle.dtype)
        return RelationPredictionV2(
            edge_presence_logit=self.edge_presence_logit * edge_weights,
            edge_distance=self.edge_distance * edge_weights,
            edge_direction_fourier=self.edge_direction_fourier * edge_weights,
            edge_direction_log_scale=self.edge_direction_log_scale * edge_weights,
            edge_shell_logits=self.edge_shell_logits * edge_weights,
            edge_coordination=self.edge_coordination * edge_weights,
            edge_latent=self.edge_latent * edge_weights,
            triplet_angle=self.triplet_angle * triplet_weights,
            triplet_presence_logit=self.triplet_presence_logit * triplet_weights,
            triplet_latent=self.triplet_latent * triplet_weights,
        )


@dataclass(frozen=True, slots=True)
class GeometryConditionV2:
    model_input: RelationModelInputV2
    relation: RelationPredictionV2

    def __post_init__(self) -> None:
        if not isinstance(self.model_input, RelationModelInputV2):
            raise TypeError("condition requires sanitized RelationModelInputV2")
        graph = self.model_input.active_orbit_graph
        if (
            self.relation.batch_size != graph.batch_size
            or self.relation.edge_count != graph.edge_count
            or self.relation.triplet_count != graph.triplet_count
        ):
            raise ValueError("relation prediction does not match packed graph")

    @property
    def composition(self) -> torch.Tensor:
        return self.model_input.composition

    @property
    def target_sg(self) -> torch.Tensor:
        return self.model_input.target_sg

    @property
    def lattice(self) -> torch.Tensor:
        return self.model_input.lattice

    @property
    def active_orbit_graph(self) -> ActiveOrbitGraphV2:
        return self.model_input.active_orbit_graph

    @property
    def candidate_query(self) -> torch.Tensor:
        return self.model_input.candidate_query

    @property
    def persistent_memory(self) -> PersistentRelationMemoryV2:
        return self.model_input.persistent_memory

    @property
    def edge_mask(self) -> torch.Tensor:
        return self.active_orbit_graph.edge_mask

    @property
    def triplet_mask(self) -> torch.Tensor:
        return self.active_orbit_graph.triplet_mask


def _gather_orbits(values: torch.Tensor, index: torch.Tensor) -> torch.Tensor:
    batch_size, orbit_count, width = values.shape
    if orbit_count == 0:
        return values.new_zeros((*index.shape, width))
    safe_index = index.clamp(0, orbit_count - 1)
    batch_shape = (batch_size,) + (1,) * (index.ndim - 1)
    batch = torch.arange(batch_size, device=index.device).reshape(batch_shape)
    return values.to(index.device)[batch, safe_index]


class RelationFunctionBackendV2(nn.Module):
    """KAN-backed structured relation predictor; it never emits coordinates."""

    def __init__(self, hidden_dim: int = 96, grid_size: int = 15) -> None:
        super().__init__()
        if type(hidden_dim) is not int or hidden_dim <= 0:
            raise ValueError("relation hidden dimension must be positive")
        if type(grid_size) is not int or grid_size < 3:
            raise ValueError("relation KAN grid size must be at least three")
        edge_input_dim = 119 + 64 + 9 + 32 + 64 + 32 + 16
        triplet_input_dim = 119 + 64 + 9 + 32 + 2 * 64 + 2 * 32
        self.edge_backbone = nn.ModuleList(
            (
                LinearSplineKANLayer(edge_input_dim, hidden_dim, grid_size),
                LinearSplineKANLayer(hidden_dim, hidden_dim, grid_size),
            )
        )
        self.triplet_backbone = nn.ModuleList(
            (
                LinearSplineKANLayer(triplet_input_dim, hidden_dim, grid_size),
                LinearSplineKANLayer(hidden_dim, hidden_dim, grid_size),
            )
        )
        self.edge_head = nn.Linear(hidden_dim, EDGE_FEATURE_DIM)
        self.triplet_head = nn.Linear(hidden_dim, TRIPLET_FEATURE_DIM)

    @staticmethod
    def _kan_forward(
        values: torch.Tensor, layers: nn.ModuleList
    ) -> torch.Tensor:
        hidden = torch.sigmoid(values)
        for layer in layers:
            hidden = torch.sigmoid(layer(hidden))
        return hidden

    def predict(self, model_input: RelationModelInputV2) -> RelationPredictionV2:
        if not isinstance(model_input, RelationModelInputV2):
            raise TypeError("backend requires sanitized RelationModelInputV2")
        return self._predict_sanitized(
            condition=model_input.composition,
            active_orbit_graph=model_input.active_orbit_graph,
            candidate_orbit=model_input.candidate_query,
            persistent_memory=model_input.persistent_memory,
            lattice_context=model_input.lattice,
        )

    def _predict_sanitized(
        self,
        condition: torch.Tensor,
        active_orbit_graph: ActiveOrbitGraphV2,
        candidate_orbit: torch.Tensor,
        persistent_memory: PersistentRelationMemoryV2,
        lattice_context: torch.Tensor,
    ) -> RelationPredictionV2:
        batch_size = active_orbit_graph.batch_size
        if condition.shape != (batch_size, 119):
            raise ValueError("relation condition must have shape [B,119]")
        if candidate_orbit.shape != (batch_size, 64):
            raise ValueError("candidate orbit must have shape [B,64]")
        if lattice_context.shape != (batch_size, 3, 3):
            raise ValueError("lattice context must have shape [B,3,3]")
        for name, value in (
            ("relation condition", condition),
            ("candidate orbit", candidate_orbit),
            ("lattice context", lattice_context),
        ):
            _validate_finite(name, value)
        graph = active_orbit_graph
        if (
            persistent_memory.batch_size != batch_size
            or persistent_memory.max_orbits != graph.orbit_count
            or persistent_memory.max_edges != graph.edge_count
        ):
            raise ValueError("persistent memory does not match relation graph")

        memory = persistent_memory.tensorize()
        common = torch.cat(
            (
                condition,
                candidate_orbit,
                lattice_context.flatten(1),
                memory.global_memory.to(condition.device, condition.dtype),
            ),
            dim=-1,
        )
        anchor = _gather_orbits(graph.active_orbits, graph.edge_index).to(
            condition.device, condition.dtype
        )
        anchor_memory = _gather_orbits(memory.orbit, graph.edge_index).to(
            condition.device, condition.dtype
        )
        edge_features = torch.cat(
            (
                common[:, None, :].expand(-1, graph.edge_count, -1),
                anchor,
                anchor_memory,
                memory.edge.to(condition.device, condition.dtype),
            ),
            dim=-1,
        )
        edge_hidden = self._kan_forward(
            edge_features.reshape(-1, edge_features.shape[-1]), self.edge_backbone
        )
        edge_output = self.edge_head(edge_hidden).reshape(
            batch_size, graph.edge_count, EDGE_FEATURE_DIM
        )

        triplet_anchor = _gather_orbits(
            graph.active_orbits, graph.triplet_index
        ).to(condition.device, condition.dtype)
        triplet_memory = _gather_orbits(memory.orbit, graph.triplet_index).to(
            condition.device, condition.dtype
        )
        triplet_features = torch.cat(
            (
                common[:, None, :].expand(-1, graph.triplet_count, -1),
                triplet_anchor.flatten(2),
                triplet_memory.flatten(2),
            ),
            dim=-1,
        )
        triplet_hidden = self._kan_forward(
            triplet_features.reshape(-1, triplet_features.shape[-1]),
            self.triplet_backbone,
        )
        triplet_output = self.triplet_head(triplet_hidden).reshape(
            batch_size, graph.triplet_count, TRIPLET_FEATURE_DIM
        )

        prediction = RelationPredictionV2(
            edge_presence_logit=edge_output[..., 0:1],
            edge_distance=edge_output[..., 1:3],
            edge_direction_fourier=edge_output[..., 3:9],
            edge_direction_log_scale=edge_output[..., 9:12],
            edge_shell_logits=edge_output[..., 12:16],
            edge_coordination=edge_output[..., 16:18],
            edge_latent=edge_output[..., 18:50],
            triplet_angle=triplet_output[..., 0:2],
            triplet_presence_logit=triplet_output[..., 2:3],
            triplet_latent=triplet_output[..., 3:19],
        )
        return prediction.masked(
            graph.edge_mask.to(condition.device),
            graph.triplet_mask.to(condition.device),
        )

    def forward(
        self, model_input: RelationModelInputV2
    ) -> RelationPredictionV2:
        return self.predict(model_input)


__all__ = [
    "ActiveOrbitGraphV2",
    "GeometryConditionV2",
    "RelationInputProvenanceV2",
    "RelationFunctionBackendV2",
    "RelationModelInputV2",
    "RelationPredictionV2",
    "validate_train_fit_input_fields",
]
