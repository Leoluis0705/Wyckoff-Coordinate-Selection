"""Training-seed replication for the integrated Full Crysalis system."""

from crysalis_g1.full_replication.config import ReplicationConfig

__all__ = ["ReplicationConfig"]
