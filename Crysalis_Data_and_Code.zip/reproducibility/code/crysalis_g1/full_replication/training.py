from __future__ import annotations

import hashlib
import json
import math
import os
import random
import threading
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping

import numpy as np
import psutil
import torch

from crysalis_g1.full_crysalis.config import LOSS_WEIGHTS
from crysalis_g1.full_crysalis.data import IntegratedCorpus
from crysalis_g1.full_crysalis.geometry import GeometryGeneratorConfig
from crysalis_g1.full_crysalis.model import FullCrysalisModel
from crysalis_g1.full_crysalis.relation import RelationBackendConfig
from crysalis_g1.full_crysalis.training import (
    TrainingLoopConfig,
    train_on_corpus,
)
from crysalis_g1.full_replication.config import ReplicationConfig


NEW_TRAINING_SEEDS = (20260824, 20260825)


@dataclass(frozen=True, slots=True)
class ReplicationTrainingConfig:
    root_seed: int
    device: str
    minimum_updates: int
    maximum_updates: int
    batch_size: int
    validation_batch_size: int
    validation_interval: int
    early_stopping_patience: int
    learning_rate: float
    weight_decay: float
    gradient_clip_norm: float
    relation_config: RelationBackendConfig
    geometry_config: GeometryGeneratorConfig
    loss_weights: Mapping[str, float]

    def __post_init__(self) -> None:
        if self.root_seed not in NEW_TRAINING_SEEDS:
            raise ValueError("replication training seed must be 20260824 or 20260825")
        if self.device not in {"cpu", "cuda"}:
            raise ValueError("replication training device must be cpu or cuda")
        counts = (
            self.minimum_updates,
            self.maximum_updates,
            self.batch_size,
            self.validation_batch_size,
            self.validation_interval,
            self.early_stopping_patience,
        )
        if any(type(value) is not int or value <= 0 for value in counts):
            raise ValueError("replication training counts must be positive integers")
        if self.minimum_updates > self.maximum_updates:
            raise ValueError("minimum updates cannot exceed maximum updates")
        scalars = (self.learning_rate, self.gradient_clip_norm)
        if any(not math.isfinite(value) or value <= 0 for value in scalars):
            raise ValueError("replication training scales must be finite and positive")
        if not math.isfinite(self.weight_decay) or self.weight_decay < 0:
            raise ValueError("weight decay must be finite and non-negative")
        if {name: float(value) for name, value in self.loss_weights.items()} != (
            LOSS_WEIGHTS
        ):
            raise ValueError("replication loss weights drifted")

    @classmethod
    def from_frozen(
        cls,
        base: TrainingLoopConfig,
        training_seed: int,
    ) -> ReplicationTrainingConfig:
        payload = asdict(base)
        payload["root_seed"] = int(training_seed)
        payload["relation_config"] = base.relation_config
        payload["geometry_config"] = base.geometry_config
        payload["loss_weights"] = dict(base.loss_weights)
        replica = cls(**payload)
        base_without_seed = asdict(base)
        replica_without_seed = asdict(replica)
        base_without_seed.pop("root_seed")
        replica_without_seed.pop("root_seed")
        if replica_without_seed != base_without_seed:
            raise ValueError("replication training protocol differs beyond seed")
        return replica


class PeakResourceMonitor:
    def __init__(self, *, interval_seconds: float = 0.1) -> None:
        if interval_seconds <= 0:
            raise ValueError("resource monitor interval must be positive")
        self.interval_seconds = float(interval_seconds)
        self.peak_rss_bytes = 0
        self.peak_cuda_allocated_bytes = 0
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._process = psutil.Process()

    def _sample(self) -> None:
        self.peak_rss_bytes = max(
            self.peak_rss_bytes,
            int(self._process.memory_info().rss),
        )
        if torch.cuda.is_available():
            self.peak_cuda_allocated_bytes = max(
                self.peak_cuda_allocated_bytes,
                int(torch.cuda.memory_allocated()),
            )

    def _run(self) -> None:
        while not self._stop.wait(self.interval_seconds):
            self._sample()

    def __enter__(self) -> PeakResourceMonitor:
        if self._thread is not None:
            raise RuntimeError("resource monitor cannot be entered twice")
        self._sample()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *_: object) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=max(1.0, self.interval_seconds * 4))
        self._sample()


def _seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed % (2**32))
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _model_state_sha256(model: torch.nn.Module) -> str:
    digest = hashlib.sha256()
    for name, value in sorted(model.state_dict().items()):
        tensor = value.detach().cpu().contiguous()
        digest.update(name.encode("utf-8"))
        digest.update(str(tensor.dtype).encode("ascii"))
        digest.update(json.dumps(tuple(tensor.shape)).encode("ascii"))
        digest.update(tensor.numpy().tobytes())
    return digest.hexdigest()


def _fresh_model(config: ReplicationTrainingConfig) -> FullCrysalisModel:
    _seed_everything(config.root_seed)
    return FullCrysalisModel(
        relation_config=config.relation_config,
        geometry_config=config.geometry_config,
        loss_weights=config.loss_weights,
    )


def model_initialization_sha256(config: ReplicationTrainingConfig) -> str:
    model = _fresh_model(config)
    digest = _model_state_sha256(model)
    del model
    return digest


def _canonical_sha256(payload: object) -> str:
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _write_json_new(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(
            payload,
            stream,
            ensure_ascii=False,
            allow_nan=False,
            indent=2,
            sort_keys=True,
        )
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def train_replication_seed(
    config: ReplicationConfig,
    *,
    training_seed: int,
    output_dir: str | Path,
    corpus: IntegratedCorpus | None = None,
) -> dict[str, Any]:
    if training_seed not in config.new_training_seeds:
        raise ValueError("formal replication may train only the two new seeds")
    base_config = config.load_base_config()
    base_loop = TrainingLoopConfig.from_full_config(base_config)
    loop = ReplicationTrainingConfig.from_frozen(base_loop, training_seed)
    corpus = corpus or IntegratedCorpus.from_config(base_config)
    output = Path(output_dir)
    receipt_path = output / "replication_training_receipt.json"
    if receipt_path.exists():
        raise FileExistsError(f"training receipt refuses to overwrite: {receipt_path}")

    fresh_model = _fresh_model(loop)
    initial_state_sha256 = _model_state_sha256(fresh_model)
    trainable_parameter_count = sum(
        parameter.numel()
        for parameter in fresh_model.parameters()
        if parameter.requires_grad
    )
    total_parameter_count = sum(
        parameter.numel() for parameter in fresh_model.parameters()
    )
    if trainable_parameter_count != total_parameter_count:
        raise RuntimeError("not all Full Crysalis model parameters are trainable")
    del fresh_model

    started = time.perf_counter()
    with PeakResourceMonitor() as resources:
        report = train_on_corpus(corpus, loop, output_dir=output)
    wrapper_wall_seconds = time.perf_counter() - started
    checkpoint_path = output / "best.pt"
    checkpoint = torch.load(
        checkpoint_path,
        map_location="cpu",
        weights_only=False,
    )
    if int(checkpoint.get("root_seed", -1)) != training_seed:
        raise ValueError("trained checkpoint seed differs from requested seed")
    if checkpoint.get("generation_metrics_used") is not False:
        raise ValueError("replication checkpoint used generation metrics")
    if checkpoint.get("ablation_performed") is not False:
        raise ValueError("replication checkpoint records forbidden ablation")
    protocol = asdict(loop)
    protocol.pop("root_seed")
    receipt = {
        "schema_version": "g1-full-crysalis-replication-training.1.0.0",
        "status": "PASS",
        "training_seed": training_seed,
        "fresh_initialization": True,
        "warm_start": False,
        "warm_start_checkpoint": None,
        "initial_state_sha256": initial_state_sha256,
        "trainable_parameter_count": trainable_parameter_count,
        "total_parameter_count": total_parameter_count,
        "all_model_parameters_trainable": True,
        "trainable_components": [
            "KAN_RELATION_FUNCTION_BACKEND",
            "RELATION_CONDITIONED_PERIODIC_EGNN",
            "LATTICE_AND_CELL_HEADS",
            "GEOMETRY_HEADS",
            "PHYSICS_PROXY_HEAD",
            "TERMINATION_HEAD",
        ],
        "frozen_components": [
            "PUBLIC_DATA_AND_SPLIT",
            "CONDITION_MANIFEST",
            "CRYSTALLOGRAPHIC_HARD_LAYER",
            "GUIDE_MLIP",
            "EVAL_MLIP",
            "C0_FROZEN_REFERENCE",
        ],
        "frozen_protocol_sha256": _canonical_sha256(protocol),
        "checkpoint_sha256": report["checkpoint_sha256"],
        "checkpoint_selection_metric": report["checkpoint_selection_metric"],
        "generation_metrics_used": False,
        "completed_updates": report["completed_updates"],
        "best_update": report["best_update"],
        "training_wall_seconds": report["wall_seconds"],
        "wrapper_wall_seconds": wrapper_wall_seconds,
        "peak_rss_bytes": resources.peak_rss_bytes,
        "peak_cuda_allocated_bytes": max(
            resources.peak_cuda_allocated_bytes,
            int(report["peak_allocated_vram_bytes"]),
        ),
        "retry_count": 0,
        "refill_count": 0,
        "sealed_or_blind_data_accessed": False,
        "ablation_performed": False,
        "module_audit_performed": False,
    }
    _write_json_new(receipt_path, receipt)
    return receipt
