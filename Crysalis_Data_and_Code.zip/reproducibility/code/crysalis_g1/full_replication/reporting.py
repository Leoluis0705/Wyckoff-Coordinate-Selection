from __future__ import annotations

import json
import math
import os
import platform
import shutil
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np

from crysalis_g1.full_crysalis.config import sha256_file
from crysalis_g1.full_crysalis.reporting import _strict_c0_records
from crysalis_g1.full_replication.analysis import (
    across_seed_statistics,
    by_space_group_for_seed,
    classify_replication,
    paired_condition_rows,
    summarize_seed_system,
)
from crysalis_g1.full_replication.bootstrap import hierarchical_bootstrap
from crysalis_g1.full_replication.config import (
    REQUIRED_OUTPUTS,
    ReplicationConfig,
)
from crysalis_g1.full_replication.novelty import dual_cohort_novelty


def _canonical_json(payload: object, *, indent: int | None = None) -> str:
    return json.dumps(
        payload,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":") if indent is None else None,
        indent=indent,
    )


def _render_payload(path: Path, payload: object) -> str:
    if path.suffix == ".md":
        if not isinstance(payload, str):
            raise TypeError(f"Markdown payload must be text: {path.name}")
        return payload if payload.endswith("\n") else payload + "\n"
    elif path.suffix == ".jsonl":
        if isinstance(payload, (str, bytes)) or not isinstance(payload, Sequence):
            raise TypeError(f"JSONL payload must be a sequence: {path.name}")
        return "".join(_canonical_json(row) + "\n" for row in payload)
    return _canonical_json(payload, indent=2) + "\n"


def _write_payload(path: Path, payload: object) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    text = _render_payload(path, payload)
    temporary.write_text(text, encoding="utf-8", newline="\n")
    os.replace(temporary, path)


def _contains_forbidden_module_conclusion(payload: object) -> bool:
    forbidden = (
        "relation_useless=true",
        "memory_useless=true",
        "physics_useless=true",
        "kan_useless=true",
        "relation_restoration_hypothesis_rejected=true",
        "reversible_deconstruction_not_supported=true",
    )
    if isinstance(payload, Mapping):
        return any(
            _contains_forbidden_module_conclusion(key)
            or _contains_forbidden_module_conclusion(value)
            for key, value in payload.items()
        )
    if isinstance(payload, (list, tuple)):
        return any(_contains_forbidden_module_conclusion(value) for value in payload)
    if isinstance(payload, str):
        normalized = payload.lower().replace(" ", "")
        return any(item in normalized for item in forbidden)
    return False


def write_replication_artifacts(
    output_root: str | Path,
    payloads: Mapping[str, object],
    *,
    manifest_metadata: Mapping[str, Any],
) -> dict[str, Any]:
    output = Path(output_root)
    manifest_name = "FULL_REPLICATION_MANIFEST.json"
    expected = set(REQUIRED_OUTPUTS) - {manifest_name}
    if set(payloads) != expected:
        raise ValueError(
            "replication payload names differ from required outputs: "
            f"missing={sorted(expected - set(payloads))}, "
            f"extra={sorted(set(payloads) - expected)}"
        )
    if manifest_metadata.get("ablation_performed") is not False:
        raise ValueError("replication manifest must prove no ablation")
    if _contains_forbidden_module_conclusion(payloads):
        raise ValueError("forbidden isolated-module conclusion in replication report")
    output.mkdir(parents=True, exist_ok=True)
    unexpected_files = sorted(
        path.name
        for path in output.iterdir()
        if path.is_file() and path.name not in REQUIRED_OUTPUTS
    )
    if unexpected_files:
        raise ValueError(
            f"unexpected top-level files in replication output: {unexpected_files}"
        )
    unexpected_directories = sorted(
        path.name
        for path in output.iterdir()
        if path.is_dir() and path.name != "engineering"
    )
    if unexpected_directories:
        raise ValueError(
            "unexpected top-level entries in replication output: "
            f"{unexpected_directories}"
        )
    manifest_path = output / manifest_name
    if manifest_path.exists():
        raise FileExistsError("replication artifact writer refuses overwrite")
    for name in REQUIRED_OUTPUTS:
        if name != manifest_name:
            path = output / name
            if path.exists():
                if path.read_text(encoding="utf-8") != _render_payload(
                    path, payloads[name]
                ):
                    raise ValueError(
                        f"existing pre-manifest artifact differs: {name}"
                    )
            else:
                _write_payload(path, payloads[name])
    artifact_sha256 = {
        name: sha256_file(output / name)
        for name in REQUIRED_OUTPUTS
        if name != manifest_name
    }
    manifest = {
        "schema_version": "g1-full-crysalis-replication-manifest.1.0.0",
        **dict(manifest_metadata),
        "required_artifact_count": len(REQUIRED_OUTPUTS),
        "required_artifacts": list(REQUIRED_OUTPUTS),
        "artifact_sha256": artifact_sha256,
        "manifest_self_hash_included": False,
        "manifest_written_after_other_artifacts": True,
        "stop_after_replication_report": True,
        "external_benchmark_started": False,
        "leave_one_out_started": False,
    }
    _write_payload(manifest_path, manifest)
    return manifest


def archive_existing_replication_artifacts(
    output_root: str | Path,
) -> dict[str, Any]:
    output = Path(output_root)
    missing = [name for name in REQUIRED_OUTPUTS if not (output / name).is_file()]
    if missing:
        raise FileNotFoundError(f"cannot archive incomplete replication: {missing}")
    manifest = _read_json(output / "FULL_REPLICATION_MANIFEST.json")
    for name, expected in manifest["artifact_sha256"].items():
        if sha256_file(output / name) != expected:
            raise ValueError(f"pre-revision artifact hash mismatch: {name}")
    archive = output / "engineering" / "final_artifact_revisions" / "revision_0"
    if archive.exists():
        raise FileExistsError(f"replication revision archive already exists: {archive}")
    archive.mkdir(parents=True, exist_ok=False)
    source_hashes = {}
    for name in REQUIRED_OUTPUTS:
        source = output / name
        shutil.copy2(source, archive / name)
        source_hashes[name] = sha256_file(source)
    final_receipt = output / "engineering" / "receipts" / "final.json"
    copied_receipt = None
    if final_receipt.is_file():
        copied_receipt = "original_final_stage_receipt.json"
        shutil.copy2(final_receipt, archive / copied_receipt)
    receipt = {
        "schema_version": ("g1-full-crysalis-replication-final-artifact-archive.1.0.0"),
        "archived_at_utc": datetime.now(UTC).isoformat(),
        "reason": ("recoverable report-layer revision after independent code review"),
        "source_artifact_sha256": source_hashes,
        "source_manifest_sha256": source_hashes["FULL_REPLICATION_MANIFEST.json"],
        "copied_original_final_stage_receipt": copied_receipt,
        "scientific_training_generation_evaluation_reexecuted": False,
        "ablation_performed": False,
    }
    _write_payload(archive / "archive_receipt.json", receipt)
    for name, expected in source_hashes.items():
        if sha256_file(archive / name) != expected:
            raise RuntimeError(f"replication archive verification failed: {name}")
    return receipt


def revise_final_replication_artifacts(
    config: ReplicationConfig,
    *,
    repo_root: str | Path,
) -> dict[str, Any]:
    required_supplemental = (
        config.output_root
        / "engineering"
        / "supplemental_dependency_closure_audit.json",
        config.output_root / "engineering" / "supplemental_stage_provenance.json",
    )
    missing = [str(path) for path in required_supplemental if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"supplemental revision evidence is missing: {missing}")
    archive = archive_existing_replication_artifacts(config.output_root)
    rebuilt = build_final_replication_artifacts(
        config,
        repo_root=repo_root,
        write_outputs=False,
    )
    revision_root = config.output_root / "engineering" / "final_artifact_revisions"
    archived_root = revision_root / "revision_0"
    invariant_sections = (
        "system",
        "training",
        "initialization",
        "mechanism",
        "novelty",
        "by_space_group",
        "deltas",
        "paired_condition_summary",
        "paired_condition_deltas",
        "catastrophic_failure",
        "catastrophic_failure_reasons",
    )
    for seed in config.training_seeds:
        name = f"FULL_REPLICATION_SEED_{seed}.json"
        prior = _read_json(archived_root / name)
        revised = rebuilt["payloads"][name]
        if any(prior[key] != revised[key] for key in invariant_sections):
            raise ValueError(f"scientific seed results changed during revision: {seed}")
    prior_bootstrap = _read_json(
        archived_root / "FULL_REPLICATION_HIERARCHICAL_BOOTSTRAP.json"
    )
    if (
        prior_bootstrap
        != rebuilt["payloads"]["FULL_REPLICATION_HIERARCHICAL_BOOTSTRAP.json"]
    ):
        raise ValueError("hierarchical bootstrap changed during report revision")
    prior_manifest = _read_json(archived_root / "FULL_REPLICATION_MANIFEST.json")
    if (
        prior_manifest["FULL_CRYSALIS_REPLICATED_SIGNAL"]
        != rebuilt["manifest_metadata"]["FULL_CRYSALIS_REPLICATED_SIGNAL"]
    ):
        raise ValueError("replication decision changed during report revision")
    staging = revision_root / "revision_1_staging"
    completed = revision_root / "revision_1"
    if staging.exists() or completed.exists():
        raise FileExistsError("replication revision 1 already exists")
    staging.mkdir(parents=True, exist_ok=False)
    staged_manifest = write_replication_artifacts(
        staging,
        rebuilt["payloads"],
        manifest_metadata=rebuilt["manifest_metadata"],
    )
    non_manifest = [
        name for name in REQUIRED_OUTPUTS if name != "FULL_REPLICATION_MANIFEST.json"
    ]
    for name in non_manifest:
        os.replace(staging / name, config.output_root / name)
    os.replace(
        staging / "FULL_REPLICATION_MANIFEST.json",
        config.output_root / "FULL_REPLICATION_MANIFEST.json",
    )
    staging.rmdir()
    completed.mkdir(parents=False, exist_ok=False)
    revised_hashes = {
        name: sha256_file(config.output_root / name) for name in REQUIRED_OUTPUTS
    }
    receipt = {
        "schema_version": (
            "g1-full-crysalis-replication-final-artifact-revision.1.0.0"
        ),
        "status": "COMPLETE",
        "completed_at_utc": datetime.now(UTC).isoformat(),
        "revision": 1,
        "superseded_manifest_sha256": archive["source_manifest_sha256"],
        "revised_artifact_sha256": revised_hashes,
        "revised_manifest_signal": staged_manifest["FULL_CRYSALIS_REPLICATED_SIGNAL"],
        "report_layer_recomputed_from_verified_engineering_evidence": True,
        "scientific_invariants_reverified_against_revision_0": True,
        "scientific_training_generation_evaluation_reexecuted": False,
        "scientific_numbers_changed": False,
        "ablation_performed": False,
    }
    _write_payload(completed / "revision_receipt.json", receipt)
    rewrite_canonical_final_receipt(
        config,
        repo_root=repo_root,
        artifact_revision=1,
    )
    return receipt


def rewrite_canonical_final_receipt(
    config: ReplicationConfig,
    *,
    repo_root: str | Path,
    artifact_revision: int,
) -> dict[str, Any]:
    output = config.output_root
    revision_receipt = (
        output
        / "engineering"
        / "final_artifact_revisions"
        / f"revision_{artifact_revision}"
        / "revision_receipt.json"
    )
    revision = _read_json(revision_receipt)
    expected_hashes = revision["revised_artifact_sha256"]
    for name, expected in expected_hashes.items():
        if sha256_file(output / name) != expected:
            raise ValueError(f"revised artifact hash drifted before receipt: {name}")
    canonical_path = output / "engineering" / "receipts" / "final.json"
    current = _read_json(canonical_path)
    if current.get("artifact_revision") == artifact_revision:
        if current.get("output_sha256") != expected_hashes:
            raise ValueError("canonical revision receipt output hashes drifted")
        return current
    archived_original = (
        output
        / "engineering"
        / "final_artifact_revisions"
        / "revision_0"
        / "original_final_stage_receipt.json"
    )
    if not archived_original.is_file():
        raise FileNotFoundError("archived original final receipt is missing")
    git = _git_receipt(Path(repo_root))
    manifest = _read_json(output / "FULL_REPLICATION_MANIFEST.json")
    canonical = {
        "schema_version": "g1-full-crysalis-replication-stage.1.1.0",
        "stage": "final",
        "status": "COMPLETE",
        "completed_at_utc": datetime.now(UTC).isoformat(),
        "config_sha256": sha256_file(config.config_path),
        "reference_commit": config.reference_commit,
        "execution_commit": git["commit"],
        "execution_dirty_status": git["dirty_status"],
        "report_generation_commit": manifest["git"]["commit"],
        "artifact_revision": artifact_revision,
        "boundary_audit_status": manifest["supplemental_evidence"][
            "dependency_closure"
        ]["status"],
        "core_implementation_file_count": manifest[
            "source_dependency_file_count"
        ],
        "source_dependency_closure_sha256": manifest[
            "source_dependency_closure_sha256"
        ],
        "output_sha256": expected_hashes,
        "revision_receipt_path": revision_receipt.relative_to(output).as_posix(),
        "revision_receipt_sha256": sha256_file(revision_receipt),
        "superseded_original_receipt_path": archived_original.relative_to(
            output
        ).as_posix(),
        "retry_count": 0,
        "refill_count": 0,
        "sealed_or_blind_data_accessed": False,
        "server_used": False,
        "dft_used": False,
        "ablation_performed": False,
        "module_audit_performed": False,
    }
    _write_payload(canonical_path, canonical)
    return canonical


def _fmt(value: Any) -> str:
    return "NA" if value is None else f"{float(value):.6f}"


def final_report_markdown(
    *,
    decision: Mapping[str, Any],
    seed_rows: Sequence[Mapping[str, Any]],
    bootstrap: Mapping[str, Any],
) -> str:
    signal = str(decision["FULL_CRYSALIS_REPLICATED_SIGNAL"])
    lines = [
        "# FULL CRYSALIS System Replication V1",
        "",
        f"System-level replication result: **{signal}**.",
        "",
        "This result concerns the complete coupled Crysalis system across independent "
        "training initializations. It does not estimate any isolated module effect.",
        "",
    ]
    if seed_rows:
        lines.extend(
            (
                "## Three training seeds",
                "",
                "| Training seed | Legal terminal | SHORT_CONTACT rejection | "
                "Fixed strict survival | Cell strict survival | Force p90 (eV/A) |",
                "|---:|---:|---:|---:|---:|---:|",
            )
        )
        for row in seed_rows:
            generation = row["system"]["generation"]
            physics = row["system"]["physics"]
            lines.append(
                f"| {row['training_seed']} | "
                f"{generation['legal_terminal_rate']:.6f} | "
                f"{generation['short_contact_rejection_rate']:.6f} | "
                f"{physics['fixed_cell_fire300']['strict_symmetry_survival_rate']:.6f} | "
                f"{physics['cell_relax_fire300']['strict_symmetry_survival_rate']:.6f} | "
                f"{_fmt(physics['initial_max_force_ev_per_angstrom']['p90'])} |"
            )
        lines.append("")
    metrics = bootstrap.get("metrics", {})
    if metrics:
        lines.extend(
            (
                "## Paired hierarchical bootstrap",
                "",
                "The table reports FULL minus frozen C0. The hierarchy resamples training "
                "seed, then paired frozen conditions within the sampled seed.",
                "",
                "| Endpoint | Mean delta | 95% hierarchical CI |",
                "|---|---:|---:|",
            )
        )
        for name, metric in metrics.items():
            interval = metric["confidence_interval_95"]
            lines.append(
                f"| {name} | {metric['mean_system_delta']:.6f} | "
                f"[{interval[0]:.6f}, {interval[1]:.6f}] |"
            )
        lines.extend(
            (
                "",
                "Only three training seeds are available; seed-level interval precision "
                "must not be overstated.",
                "",
            )
        )
    lines.extend(("## Preregistered A-F decision", ""))
    for criterion, passed in decision.get("criteria", {}).items():
        lines.append(f"- {criterion}: `{bool(passed)}`")
    lines.append("")
    if signal == "SUPPORTED":
        lines.extend(
            (
                "NEXT_RECOMMENDED_STAGE = EXTERNAL_MODEL_BENCHMARK",
                "",
                "That recommendation was not executed. Broader novelty auditing and "
                "later leave-one-out scientific ablation remain possible future work; "
                "leave-one-out was not started in this run.",
                "",
            )
        )
    else:
        lines.extend(
            (
                "The per-seed mechanism counters, failure taxonomy, gradient/provenance "
                "checks, and SG heterogeneity are preserved in the companion artifacts. "
                "No isolated contribution search, redesign, or leave-one-out was started.",
                "",
            )
        )
    lines.extend(
        (
            "## Stop boundary",
            "",
            "Execution stops after this integrated replication report. No ablation, "
            "KAN-vs-MLP comparison, new operator, server run, or DFT was launched.",
            "",
        )
    )
    return "\n".join(lines)


def _read_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _records(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, Mapping):
        payload = payload["records"]
    return [dict(row) for row in payload]


def _historical_mechanism(
    records: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    steps = [step for record in records for step in record["steps"]]
    successful = len(steps)
    updates = sum(
        step["relation_state_before_hash"] != step["relation_state_after_hash"]
        for step in steps
    )
    guide_entries = sum(bool(step["guide_feedback_enters_geometry"]) for step in steps)
    guide_changes = sum(
        bool(step["guide_feedback_changed_geometry_output"]) for step in steps
    )
    return {
        "instrumentation_scope": "DERIVED_FROM_FROZEN_STEP_RECORDS",
        "exact_call_level_instrumentation_available": False,
        "model_forward_calls": None,
        "relation_conditioned_geometry_calls": None,
        "guide_feedback_calls": None,
        "guide_feedback_item_count": None,
        "crystallographic_projector_calls": None,
        "crystallographic_projector_rejections": None,
        "projector_call_rejection_rate": None,
        "successful_add_orbit_steps": successful,
        "persistent_relation_state_updates": updates,
        "guide_feedback_enters_geometry_steps": guide_entries,
        "guide_feedback_changes_geometry": guide_changes,
        "persistent_relation_state_update_coverage": updates / max(successful, 1),
        "guide_feedback_geometry_entry_coverage": guide_entries / max(successful, 1),
        "guide_feedback_geometry_change_coverage": guide_changes / max(successful, 1),
        "connectivity_status": (
            "PASS"
            if successful > 0 and updates == successful and guide_changes == successful
            else "FAIL"
        ),
        "implementation_correctness_only": True,
        "scientific_module_audit": False,
    }


def _finite_payload(payload: object) -> bool:
    if isinstance(payload, Mapping):
        return all(_finite_payload(value) for value in payload.values())
    if isinstance(payload, (list, tuple)):
        return all(_finite_payload(value) for value in payload)
    if isinstance(payload, float):
        return math.isfinite(payload)
    return True


def _paired_summary(rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    binary = {
        "legal_terminal_rate": "legal_terminal_delta",
        "short_contact_rejection_rate": "short_contact_rejection_delta",
        "fixed_strict_survival_rate": "fixed_strict_survival_delta",
        "cell_strict_survival_rate": "cell_strict_survival_delta",
    }
    output = {
        name: float(np.mean([float(row[key]) for row in rows]))
        for name, key in binary.items()
    }
    finite = [
        row
        for row in rows
        if row.get("initial_force_full") is not None
        and row.get("initial_force_c0") is not None
    ]
    output["initial_force_p90_ev_per_angstrom"] = (
        None
        if not finite
        else float(
            np.quantile([row["initial_force_full"] for row in finite], 0.90)
            - np.quantile([row["initial_force_c0"] for row in finite], 0.90)
        )
    )
    output["initial_force_paired_condition_count"] = len(finite)
    return output


def _seed_root(config: ReplicationConfig, seed: int) -> Path:
    return config.output_root / "engineering" / "seeds" / str(seed)


def _load_seed_evidence(
    config: ReplicationConfig,
    seed: int,
) -> dict[str, Any]:
    if seed == config.frozen_reference_seed:
        root = config.reference_output_root
        training = _read_json(root / "training" / "training_report.json")
        generation = _read_json(root / "generation" / "generation_records.json")
        generation_summary = _read_json(
            root / "generation" / "generation_summary.json"
        )
        physics = _read_json(root / "evaluation" / "physics_results.json")
        mechanism = _historical_mechanism(generation)
        resources = {
            "training_wall_seconds": training.get("wall_seconds"),
            "training_peak_ram_bytes": None,
            "training_peak_ram_status": "NOT_RECORDED_IN_FROZEN_REFERENCE",
            "training_peak_vram_bytes": training.get("peak_allocated_vram_bytes"),
            "generation_wall_seconds": None,
            "generation_peak_ram_bytes": None,
            "generation_peak_vram_bytes": None,
            "generation_resource_status": "NOT_RECORDED_IN_FROZEN_REFERENCE",
            "evaluation_wall_seconds": None,
            "evaluation_peak_ram_bytes": None,
            "evaluation_peak_vram_bytes": None,
            "evaluation_resource_status": "NOT_RECORDED_IN_FROZEN_REFERENCE",
        }
        initialization = {
            "fresh_initialization": True,
            "warm_start": False,
            "initial_state_sha256": None,
            "initial_state_status": "NOT_RECORDED_IN_FROZEN_REFERENCE",
        }
        exact_artifact_status = "FROZEN_POSITIVE_REFERENCE"
    else:
        root = _seed_root(config, seed)
        training = _read_json(root / "training" / "training_report.json")
        training_receipt = _read_json(
            root / "training" / "replication_training_receipt.json"
        )
        generation = _read_json(root / "generation" / "generation_records.json")
        generation_summary = _read_json(
            root / "generation" / "generation_summary.json"
        )
        physics = _read_json(root / "evaluation" / "physics_results.json")
        mechanism = _read_json(
            root / "generation" / "replication_mechanism_summary.json"
        )
        evaluation_receipt = _read_json(
            root / "evaluation" / "replication_evaluation_receipt.json"
        )
        resources = {
            "training_wall_seconds": training_receipt["training_wall_seconds"],
            "training_peak_ram_bytes": training_receipt["peak_rss_bytes"],
            "training_peak_ram_status": "RECORDED",
            "training_peak_vram_bytes": training_receipt[
                "peak_cuda_allocated_bytes"
            ],
            "generation_wall_seconds": generation_summary[
                "generation_wall_seconds"
            ],
            "generation_peak_ram_bytes": generation_summary["peak_rss_bytes"],
            "generation_peak_vram_bytes": generation_summary[
                "peak_cuda_allocated_bytes"
            ],
            "generation_resource_status": "RECORDED",
            "evaluation_wall_seconds": evaluation_receipt[
                "evaluation_wall_seconds"
            ],
            "evaluation_peak_ram_bytes": evaluation_receipt["peak_rss_bytes"],
            "evaluation_peak_vram_bytes": evaluation_receipt[
                "peak_cuda_allocated_bytes"
            ],
            "evaluation_resource_status": "RECORDED",
        }
        initialization = {
            "fresh_initialization": training_receipt["fresh_initialization"],
            "warm_start": training_receipt["warm_start"],
            "initial_state_sha256": training_receipt["initial_state_sha256"],
            "initial_state_status": "RECORDED",
        }
        exact_artifact_status = "INDEPENDENT_REPLICATION_TRAINING"
    return {
        "root": root,
        "training": training,
        "generation": generation,
        "generation_summary": generation_summary,
        "physics": physics,
        "mechanism": mechanism,
        "resources": resources,
        "initialization": initialization,
        "artifact_status": exact_artifact_status,
    }


def _failures_for_seed(
    seed: int,
    evidence: Mapping[str, Any],
) -> list[dict[str, Any]]:
    failures = []
    for record in evidence["generation"]:
        if record.get("failure_code") is not None:
            failures.append(
                {
                    "training_seed": seed,
                    "condition_id": record["condition"]["condition_id"],
                    "space_group": record["condition"]["space_group"],
                    "stage": "generation",
                    "failure_code": record["failure_code"],
                    "reason_codes": record.get("projector_rejection_reasons", ()),
                    "retry_count": 0,
                    "refill_count": 0,
                }
            )
    for protocol in ("fixed_cell_fire300", "cell_relax_fire300"):
        for record in evidence["physics"][protocol]["records"]:
            if record.get("status") not in {
                "EVALUATED",
                "SKIPPED_GENERATION_FAILURE",
            }:
                failures.append(
                    {
                        "training_seed": seed,
                        "condition_id": record["condition_id"],
                        "stage": protocol,
                        "failure_code": record["status"],
                        "exception_type": record.get("exception_type"),
                        "exception_message": record.get("exception_message"),
                        "retry_count": 0,
                        "refill_count": 0,
                    }
                )
    return failures


def _implementation_audit_markdown(
    *,
    config: ReplicationConfig,
    audit: Mapping[str, Any],
    seeds: Sequence[Mapping[str, Any]],
) -> str:
    lines = [
        "# FULL CRYSALIS Replication Implementation Audit",
        "",
        f"- Frozen positive commit: `{config.reference_commit}`.",
        f"- Frozen reference generator: `{config.reference_baseline['system_name']}`; "
        f"checkpoint SHA-256: `{audit['c0_checkpoint_sha256']}`.",
        f"- Core dependency snapshot: `{audit['core_implementation_file_count']}` files, "
        "all matched before formal execution.",
        f"- Frozen condition manifest: `{audit['condition_manifest_sha256']}`; "
        "the same ordered 300 conditions were used for all seeds.",
        f"- GuideMLIP and EvalMLIP artifact: `{audit['guide_mlip_artifact_sha256']}`; "
        "instances and roles remained separate.",
        "- The positive run depended on then-uncommitted R1 files. Their omission from "
        "the old commit is a provenance limitation; this replication froze and verified "
        "their exact per-file hashes before either new training run.",
        "",
    ]
    closure_path = (
        config.output_root
        / "engineering"
        / "supplemental_dependency_closure_audit.json"
    )
    if closure_path.is_file():
        closure = _read_json(closure_path)
        lines.extend(
            [
                "## Supplemental transitive dependency closure",
                "",
                f"- Static local import closure: "
                f"`{closure['source_dependency_file_count']}` source/config files; "
                f"closure SHA-256: `{closure['source_dependency_closure_sha256']}`.",
                f"- `{closure['reference_commit_exact_match_count']}` newly discovered "
                "paths exactly match the frozen commit; "
                f"`{closure['retrospective_dirty_path_count']}` path is supported only "
                "by retrospective evidence.",
                "- Provenance limitation: the positive run recorded the dirty "
                "`local_free_rollout.py` path but did not preserve its SHA-256. Its "
                "current mtime predates the positive audit, and both new seeds used the "
                "same current file; this is not described as pre-run cryptographic proof.",
                "",
            ]
        )
    provenance_path = (
        config.output_root / "engineering" / "supplemental_stage_provenance.json"
    )
    if provenance_path.is_file():
        provenance = _read_json(provenance_path)
        lines.extend(
            [
                "## Supplemental stage provenance",
                "",
                f"- Scientific execution commit: "
                f"`{provenance['scientific_execution_commit']}`; wrapper source files "
                f"hashed: `{provenance['replication_wrapper_source_file_count']}`.",
                "- Every original scientific-stage output was reverified against its "
                "receipt. The original receipts omitted exact stage-time dirty status; "
                "that missing fact was not reconstructed.",
                "",
            ]
        )
    lines.extend(
        [
            "## Independent training and integrated-path checks",
            "",
        ]
    )
    for row in seeds:
        training = row["training"]
        mechanism = row["mechanism"]
        lines.extend(
            (
                f"### Seed {row['training_seed']}",
                "",
                f"- Artifact status: `{row['artifact_status']}`; completed updates: "
                f"`{training['completed_updates']}`; best update: "
                f"`{training['best_update']}`; validation-only checkpoint metric: "
                f"`{training['checkpoint_selection_metric']}`.",
                f"- Fresh initialization: `{row['initialization']['fresh_initialization']}`; "
                f"warm start: `{row['initialization']['warm_start']}`; initialization hash "
                f"status: `{row['initialization']['initial_state_status']}`.",
                f"- Successful ADD_ORBIT steps: "
                f"`{mechanism['successful_add_orbit_steps']}`; persistent relation-state "
                f"updates: `{mechanism['persistent_relation_state_updates']}`; Guide "
                f"geometry changes: `{mechanism['guide_feedback_changes_geometry']}`.",
                f"- Relation-state update coverage: "
                f"`{mechanism['persistent_relation_state_update_coverage']:.6f}`; Guide "
                f"geometry-change coverage: "
                f"`{mechanism['guide_feedback_geometry_change_coverage']:.6f}`; connectivity: "
                f"`{mechanism['connectivity_status']}`.",
                "",
            )
        )
    lines.extend(
        (
            "## Scientific boundary",
            "",
            "Only engineering correctness and complete-system replication were assessed. "
            "No isolated Relation, Memory, Physics, KAN, or geometry-backend scientific "
            "audit was run. No contribution lock, promotion/deletion gate, leave-one-out "
            "ablation, server computation, sealed/blind access, DFT, retry, or refill occurred.",
            "",
        )
    )
    return "\n".join(lines)


def _across_metric(
    seeds: Sequence[Mapping[str, Any]],
    getter: Any,
) -> dict[str, Any]:
    return across_seed_statistics([float(getter(row)) for row in seeds])


def _across_optional_metric(
    seeds: Sequence[Mapping[str, Any]],
    getter: Any,
) -> dict[str, Any]:
    raw = [getter(row) for row in seeds]
    available = np.asarray(
        [float(value) for value in raw if value is not None], dtype=float
    )
    if available.size == 0:
        return {
            "mean": None,
            "std": None,
            "min": None,
            "max": None,
            "seed_count": 3,
            "finite_seed_count": 0,
        }
    return {
        "mean": float(available.mean()),
        "std": (
            None if available.size < 2 else float(available.std(ddof=1))
        ),
        "min": float(available.min()),
        "max": float(available.max()),
        "seed_count": 3,
        "finite_seed_count": int(available.size),
    }


def _git_receipt(repo_root: Path) -> dict[str, Any]:
    safe = f"safe.directory={repo_root.as_posix()}"
    commit = subprocess.check_output(
        ["git", "-c", safe, "rev-parse", "HEAD"],
        cwd=repo_root,
        text=True,
    ).strip()
    status = subprocess.check_output(
        ["git", "-c", safe, "status", "--short"],
        cwd=repo_root,
        text=True,
    ).splitlines()
    return {"commit": commit, "dirty_status": status}


def _manifest_metadata(
    config: ReplicationConfig,
    *,
    decision: Mapping[str, Any],
    repo_root: str | Path,
) -> dict[str, Any]:
    base = config.load_base_config()
    metadata = {
        "FULL_CRYSALIS_REPLICATED_SIGNAL": decision[
            "FULL_CRYSALIS_REPLICATED_SIGNAL"
        ],
        "FULL_CRYSALIS_REPLICATION_MIXED": decision[
            "FULL_CRYSALIS_REPLICATION_MIXED"
        ],
        "preregistered_criteria": decision["criteria"],
        "config_path": str(config.config_path.resolve()),
        "config_sha256": sha256_file(config.config_path),
        "reference_commit": config.reference_commit,
        "reference_output_root": str(config.reference_output_root.resolve()),
        "reference_baseline": dict(config.reference_baseline),
        "training_seeds": list(config.training_seeds),
        "new_training_seeds": list(config.new_training_seeds),
        "frozen_generation_root_seed": config.frozen_generation_root_seed,
        "condition_manifest_sha256": base.artifacts["condition_manifest"].sha256,
        "condition_count_per_seed": config.condition_count_per_seed,
        "full_generation_attempt_count": (
            len(config.training_seeds) * config.condition_count_per_seed
        ),
        "bootstrap_seed": config.bootstrap_seed,
        "bootstrap_replicates": config.bootstrap_replicates,
        "core_implementation_sha256": dict(config.core_implementation_sha256),
        "frozen_input_sha256": dict(config.frozen_artifact_sha256),
        "positive_reference_artifact_sha256": dict(
            config.positive_artifact_sha256
        ),
        "git": _git_receipt(Path(repo_root)),
        "python": sys.version,
        "platform": platform.platform(),
        "public_only": True,
        "reference_baseline_frozen": True,
        "trainable_components_reinitialized_per_new_seed": True,
        "frozen_components_identical_across_seeds": True,
        "retry_count": 0,
        "refill_count": 0,
        "server_used": False,
        "dft_used": False,
        "sealed_or_blind_data_accessed": False,
        "new_module_added": False,
        "ablation_performed": False,
        "contribution_lock_performed": False,
        "module_audit_performed": False,
        "kan_vs_mlp_performed": False,
        "e3nn_comparison_performed": False,
    }
    supplemental = {
        "dependency_closure": (
            config.output_root
            / "engineering"
            / "supplemental_dependency_closure_audit.json"
        ),
        "stage_provenance": (
            config.output_root / "engineering" / "supplemental_stage_provenance.json"
        ),
    }
    metadata["supplemental_evidence"] = {}
    for name, path in supplemental.items():
        if path.is_file():
            payload = _read_json(path)
            metadata["supplemental_evidence"][name] = {
                "path": path.relative_to(config.output_root).as_posix(),
                "sha256": sha256_file(path),
                "status": payload["status"],
            }
            if name == "dependency_closure":
                metadata["source_dependency_closure_sha256"] = payload[
                    "source_dependency_closure_sha256"
                ]
                metadata["source_dependency_file_count"] = payload[
                    "source_dependency_file_count"
                ]
    archive_receipt = (
        config.output_root
        / "engineering"
        / "final_artifact_revisions"
        / "revision_0"
        / "archive_receipt.json"
    )
    if archive_receipt.is_file():
        metadata["artifact_revision"] = 1
        metadata["superseded_revision_archive"] = {
            "path": archive_receipt.relative_to(config.output_root).as_posix(),
            "sha256": sha256_file(archive_receipt),
        }
    else:
        metadata["artifact_revision"] = 0
    return metadata


def resume_replication_manifest(
    config: ReplicationConfig,
    *,
    repo_root: str | Path,
) -> dict[str, Any]:
    manifest_name = "FULL_REPLICATION_MANIFEST.json"
    names = tuple(name for name in REQUIRED_OUTPUTS if name != manifest_name)
    if (config.output_root / manifest_name).exists() or any(
        not (config.output_root / name).is_file() for name in names
    ):
        raise ValueError("manifest-only recovery requires exactly eleven artifacts")
    rebuilt = build_final_replication_artifacts(
        config,
        repo_root=repo_root,
        write_outputs=False,
    )
    return write_replication_artifacts(
        config.output_root,
        rebuilt["payloads"],
        manifest_metadata=rebuilt["manifest_metadata"],
    )


def _catastrophic_failure_reasons(
    *,
    training: Mapping[str, Any],
    system: Mapping[str, Any],
    mechanism: Mapping[str, Any],
) -> list[str]:
    reasons: list[str] = []
    if training.get("status") != "PASS":
        reasons.append("TRAINING_NOT_COMPLETE")
    generation = system["generation"]
    if int(generation["legal_terminal_count"]) == 0:
        reasons.append("ZERO_GENERATION")
    if (
        mechanism["persistent_relation_state_updates"] <= 0
        or mechanism["connectivity_status"] != "PASS"
    ):
        reasons.append("RELATION_STATE_DISCONNECTED")
    if mechanism["guide_feedback_changes_geometry"] <= 0:
        reasons.append("GUIDE_FEEDBACK_DISCONNECTED")
    if (
        generation["legal_terminal_count"] > 0
        and generation["target_space_group_validity"]["count"] == 0
    ):
        reasons.append("SYMMETRY_COLLAPSE")
    if not _finite_payload({"system": system}):
        reasons.append("NONFINITE_SYSTEM_RESULT")
    return reasons


def build_final_replication_artifacts(
    config: ReplicationConfig,
    *,
    repo_root: str | Path,
    write_outputs: bool = True,
) -> dict[str, Any]:
    audit_path = config.output_root / "engineering" / "reference_audit.json"
    if not audit_path.is_file():
        raise FileNotFoundError("reference audit is missing before finalization")
    audit = _read_json(audit_path)
    base = config.load_base_config()
    c0_generation = _records(_read_json(base.artifacts["c0_generation_records"].path))
    c0_fixed = list(
        _strict_c0_records(
            _records(_read_json(base.artifacts["c0_fixed_cell_records"].path))
        )
    )
    c0_cell = list(
        _strict_c0_records(
            _records(_read_json(base.artifacts["c0_cell_relax_records"].path))
        )
    )
    c0_system = summarize_seed_system(
        training_seed=0,
        generation_records=c0_generation,
        fixed_records=c0_fixed,
        cell_records=c0_cell,
    )
    c0_by_sg = by_space_group_for_seed(
        generation_records=c0_generation,
        fixed_records=c0_fixed,
        cell_records=c0_cell,
        expected_space_groups=config.space_groups,
    )

    phase2a_root = Path(base.artifacts["phase2a_manifest"].path).parent
    seed_reports: list[dict[str, Any]] = []
    paired_by_seed: dict[int, Sequence[Mapping[str, Any]]] = {}
    failures: list[dict[str, Any]] = []
    for seed in config.training_seeds:
        evidence = _load_seed_evidence(config, seed)
        fixed = evidence["physics"]["fixed_cell_fire300"]["records"]
        cell = evidence["physics"]["cell_relax_fire300"]["records"]
        system = summarize_seed_system(
            training_seed=seed,
            generation_records=evidence["generation"],
            fixed_records=fixed,
            cell_records=cell,
        )
        by_sg = by_space_group_for_seed(
            generation_records=evidence["generation"],
            fixed_records=fixed,
            cell_records=cell,
            expected_space_groups=config.space_groups,
        )
        paired = paired_condition_rows(
            full_generation=evidence["generation"],
            full_fixed=fixed,
            full_cell=cell,
            c0_generation=c0_generation,
            c0_fixed=c0_fixed,
            c0_cell=c0_cell,
        )
        paired_by_seed[seed] = paired
        paired_summary = _paired_summary(paired)
        novelty = dual_cohort_novelty(
            evidence["generation"],
            phase2a_root=phase2a_root,
            split_manifest=base.artifacts["structure_ood_manifest"].path,
            recovered_parent_cache=base.artifacts["recovered_parents"].path,
        )
        deltas = {
            "legal_terminal_rate": paired_summary["legal_terminal_rate"],
            "short_contact_rejection_rate": paired_summary[
                "short_contact_rejection_rate"
            ],
            "fixed_strict_survival_rate": paired_summary[
                "fixed_strict_survival_rate"
            ],
            "cell_strict_survival_rate": paired_summary[
                "cell_strict_survival_rate"
            ],
            "initial_force_p90_ev_per_angstrom": paired_summary[
                "initial_force_p90_ev_per_angstrom"
            ],
            "initial_force_median_ev_per_angstrom": (
                None
                if system["physics"]["initial_max_force_ev_per_angstrom"][
                    "median"
                ]
                is None
                else system["physics"]["initial_max_force_ev_per_angstrom"][
                    "median"
                ]
                - c0_system["physics"]["initial_max_force_ev_per_angstrom"][
                    "median"
                ]
            ),
            "sg_macro_legal_terminal_rate": (
                by_sg["macro"]["legal_terminal_rate"]
                - c0_by_sg["macro"]["legal_terminal_rate"]
            ),
            "sg_macro_short_contact_rejection_rate": (
                by_sg["macro"]["short_contact_rejection_rate"]
                - c0_by_sg["macro"]["short_contact_rejection_rate"]
            ),
        }
        mechanism = evidence["mechanism"]
        catastrophic_reasons = _catastrophic_failure_reasons(
            training=evidence["training"],
            system=system,
            mechanism=mechanism,
        )
        if not _finite_payload({"by_space_group": by_sg, "deltas": deltas}):
            if "NONFINITE_SYSTEM_RESULT" not in catastrophic_reasons:
                catastrophic_reasons.append("NONFINITE_SYSTEM_RESULT")
        seed_report = {
            "schema_version": "g1-full-crysalis-replication-seed.1.0.0",
            "training_seed": seed,
            "artifact_status": evidence["artifact_status"],
            "condition_manifest_sha256": base.artifacts[
                "condition_manifest"
            ].sha256,
            "attempt_count": config.condition_count_per_seed,
            "system": system,
            "training": evidence["training"],
            "initialization": evidence["initialization"],
            "mechanism": mechanism,
            "resources": evidence["resources"],
            "novelty": novelty,
            "by_space_group": by_sg,
            "frozen_reference_system": c0_system,
            "deltas": deltas,
            "paired_condition_summary": paired_summary,
            "paired_condition_deltas": list(paired),
            "catastrophic_failure": bool(catastrophic_reasons),
            "catastrophic_failure_reasons": catastrophic_reasons,
            "retry_count": 0,
            "refill_count": 0,
            "server_used": False,
            "dft_used": False,
            "sealed_or_blind_data_accessed": False,
            "ablation_performed": False,
            "module_audit_performed": False,
        }
        seed_reports.append(seed_report)
        failures.extend(_failures_for_seed(seed, evidence))

    bootstrap = hierarchical_bootstrap(
        paired_by_seed,
        bootstrap_seed=config.bootstrap_seed,
        replicates=config.bootstrap_replicates,
        condition_count=config.condition_count_per_seed,
    )
    decision = classify_replication(seed_reports)
    training_summary = {
        "schema_version": "g1-full-crysalis-replication-training-summary.1.0.0",
        "training_seeds": list(config.training_seeds),
        "frozen_protocol": dict(config.frozen_protocol),
        "per_seed": {
            str(row["training_seed"]): {
                "artifact_status": row["artifact_status"],
                "completed_updates": row["training"]["completed_updates"],
                "best_update": row["training"]["best_update"],
                "checkpoint_sha256": row["training"]["checkpoint_sha256"],
                "checkpoint_selection_metric": row["training"][
                    "checkpoint_selection_metric"
                ],
                "initialization": row["initialization"],
                "training_wall_seconds": row["resources"]["training_wall_seconds"],
                "peak_ram_bytes": row["resources"]["training_peak_ram_bytes"],
                "peak_ram_status": row["resources"]["training_peak_ram_status"],
                "peak_vram_bytes": row["resources"]["training_peak_vram_bytes"],
            }
            for row in seed_reports
        },
        "across_seed": {
            "completed_updates": _across_metric(
                seed_reports, lambda row: row["training"]["completed_updates"]
            ),
            "best_update": _across_metric(
                seed_reports, lambda row: row["training"]["best_update"]
            ),
            "training_wall_seconds": _across_metric(
                seed_reports,
                lambda row: row["resources"]["training_wall_seconds"],
            ),
            "peak_ram_bytes": _across_optional_metric(
                seed_reports,
                lambda row: row["resources"]["training_peak_ram_bytes"],
            ),
            "peak_vram_bytes": _across_optional_metric(
                seed_reports,
                lambda row: row["resources"]["training_peak_vram_bytes"],
            ),
        },
        "warm_start_used": False,
        "generation_or_chgnet_checkpoint_selection_used": False,
        "ablation_performed": False,
    }
    generation_metric_getters = {
        "legal_terminal_rate": lambda row: row["system"]["generation"][
            "legal_terminal_rate"
        ],
        "short_contact_rejection_rate": lambda row: row["system"]["generation"][
            "short_contact_rejection_rate"
        ],
        "projector_rejection_attempt_rate": lambda row: row["system"][
            "generation"
        ]["projector_rejection_attempt_rate"],
        "no_legal_action_rate": lambda row: row["system"]["generation"][
            "no_legal_action_rate"
        ],
        "composition_validity_rate": lambda row: row["system"]["generation"][
            "composition_validity"
        ]["rate"],
        "multiplicity_validity_rate": lambda row: row["system"]["generation"][
            "multiplicity_validity"
        ]["rate"],
        "wyckoff_validity_rate": lambda row: row["system"]["generation"][
            "wyckoff_validity"
        ]["rate"],
        "target_space_group_validity_rate": lambda row: row["system"]["generation"][
            "target_space_group_validity"
        ]["rate"],
        "latency_mean_seconds": lambda row: row["system"]["generation"][
            "latency_seconds"
        ]["mean"],
        "latency_median_seconds": lambda row: row["system"]["generation"][
            "latency_seconds"
        ]["median"],
        "latency_p90_seconds": lambda row: row["system"]["generation"][
            "latency_seconds"
        ]["p90"],
        "unique_structure_count": lambda row: row["novelty"]["unique_structure_count"],
        "unique_structure_rate": lambda row: row["novelty"]["unique_structure_rate"],
        "novel_to_train_fit_count": lambda row: row["novelty"]["relative_to_train_fit"][
            "novel_count"
        ],
        "novel_to_train_fit_rate": lambda row: row["novelty"]["relative_to_train_fit"][
            "novelty_rate"
        ],
        "novel_to_frozen_parent_count": lambda row: row["novelty"][
            "relative_to_frozen_parent_cohort"
        ]["novel_count"],
        "novel_to_frozen_parent_rate": lambda row: row["novelty"][
            "relative_to_frozen_parent_cohort"
        ]["novelty_rate"],
        "successful_add_orbit_steps": lambda row: row["mechanism"][
            "successful_add_orbit_steps"
        ],
        "persistent_relation_state_updates": lambda row: row["mechanism"][
            "persistent_relation_state_updates"
        ],
        "guide_feedback_changes_geometry": lambda row: row["mechanism"][
            "guide_feedback_changes_geometry"
        ],
    }
    generation_optional_metric_getters = {
        "relation_conditioned_geometry_calls": lambda row: row["mechanism"].get(
            "relation_conditioned_geometry_calls"
        ),
        "guide_feedback_calls": lambda row: row["mechanism"].get(
            "guide_feedback_calls"
        ),
        "crystallographic_projector_calls": lambda row: row["mechanism"].get(
            "crystallographic_projector_calls"
        ),
        "crystallographic_projector_rejections": lambda row: row["mechanism"].get(
            "crystallographic_projector_rejections"
        ),
        "projector_call_rejection_rate": lambda row: row["mechanism"].get(
            "projector_call_rejection_rate"
        ),
        "generation_wall_seconds": lambda row: row["resources"].get(
            "generation_wall_seconds"
        ),
        "generation_peak_ram_bytes": lambda row: row["resources"].get(
            "generation_peak_ram_bytes"
        ),
        "generation_peak_vram_bytes": lambda row: row["resources"].get(
            "generation_peak_vram_bytes"
        ),
    }
    generation_summary = {
        "schema_version": "g1-full-crysalis-replication-generation-summary.1.0.0",
        "attempt_count_per_seed": config.condition_count_per_seed,
        "pooled_attempt_count": len(seed_reports) * config.condition_count_per_seed,
        "per_seed": {
            str(row["training_seed"]): {
                **row["system"]["generation"],
                "mechanism": row["mechanism"],
                "novelty": row["novelty"],
                "resources": {
                    key: value
                    for key, value in row["resources"].items()
                    if key.startswith("generation_")
                },
            }
            for row in seed_reports
        },
        "across_seed": {
            **{
                name: _across_metric(seed_reports, getter)
                for name, getter in generation_metric_getters.items()
            },
            **{
                name: _across_optional_metric(seed_reports, getter)
                for name, getter in generation_optional_metric_getters.items()
            },
        },
        "pooled_supplementary": {
            "legal_terminal_count": sum(
                row["system"]["generation"]["legal_terminal_count"]
                for row in seed_reports
            ),
            "short_contact_rejection_count": sum(
                row["system"]["generation"]["short_contact_rejection_count"]
                for row in seed_reports
            ),
        },
        "pooled_does_not_replace_seed_level_results": True,
        "retry_count": 0,
        "refill_count": 0,
        "ablation_performed": False,
    }
    physics_getters = {
        "initial_force_mean": lambda row: row["system"]["physics"][
            "initial_max_force_ev_per_angstrom"
        ]["mean"],
        "initial_force_median": lambda row: row["system"]["physics"][
            "initial_max_force_ev_per_angstrom"
        ]["median"],
        "initial_force_p90": lambda row: row["system"]["physics"][
            "initial_max_force_ev_per_angstrom"
        ]["p90"],
        "initial_force_p95": lambda row: row["system"]["physics"][
            "initial_max_force_ev_per_angstrom"
        ]["p95"],
        "initial_force_max": lambda row: row["system"]["physics"][
            "initial_max_force_ev_per_angstrom"
        ]["max"],
        "fixed_convergence_rate": lambda row: row["system"]["physics"][
            "fixed_cell_fire300"
        ]["convergence_rate"],
        "fixed_physical_survival_rate": lambda row: row["system"]["physics"][
            "fixed_cell_fire300"
        ]["physical_survival_rate"],
        "fixed_strict_survival_rate": lambda row: row["system"]["physics"][
            "fixed_cell_fire300"
        ]["strict_symmetry_survival_rate"],
        "fixed_post_relax_target_space_group_rate": lambda row: row["system"][
            "physics"
        ]["fixed_cell_fire300"]["post_relax_target_space_group_rate"],
        "cell_convergence_rate": lambda row: row["system"]["physics"][
            "cell_relax_fire300"
        ]["convergence_rate"],
        "cell_physical_survival_rate": lambda row: row["system"]["physics"][
            "cell_relax_fire300"
        ]["physical_survival_rate"],
        "cell_strict_survival_rate": lambda row: row["system"]["physics"][
            "cell_relax_fire300"
        ]["strict_symmetry_survival_rate"],
        "cell_post_relax_target_space_group_rate": lambda row: row["system"]["physics"][
            "cell_relax_fire300"
        ]["post_relax_target_space_group_rate"],
        "evaluation_wall_seconds": lambda row: row["resources"].get(
            "evaluation_wall_seconds"
        ),
        "evaluation_peak_ram_bytes": lambda row: row["resources"].get(
            "evaluation_peak_ram_bytes"
        ),
        "evaluation_peak_vram_bytes": lambda row: row["resources"].get(
            "evaluation_peak_vram_bytes"
        ),
    }
    physics_summary = {
        "schema_version": "g1-full-crysalis-replication-physics-summary.1.0.0",
        "per_seed": {
            str(row["training_seed"]): {
                **row["system"]["physics"],
                "resources": {
                    key: value
                    for key, value in row["resources"].items()
                    if key.startswith("evaluation_")
                },
            }
            for row in seed_reports
        },
        "across_seed": {
            name: _across_optional_metric(seed_reports, getter)
            for name, getter in physics_getters.items()
        },
        "guide_eval_boundary_preserved": True,
        "eval_results_returned_to_generation": False,
        "dft_used": False,
        "ablation_performed": False,
    }
    sg_metrics = (
        "legal_terminal_rate",
        "short_contact_rejection_rate",
        "fixed_cell_strict_symmetry_survival_rate",
        "cell_relax_strict_symmetry_survival_rate",
        "initial_force_median",
        "initial_force_p90",
    )
    by_space_group = {
        "schema_version": "g1-full-crysalis-replication-by-space-group.1.0.0",
        "space_group_order": list(config.space_groups),
        "frozen_reference": c0_by_sg,
        "per_seed": {
            str(row["training_seed"]): row["by_space_group"]
            for row in seed_reports
        },
        "across_seed_by_space_group": {
            str(space_group): {
                metric: _across_optional_metric(
                    seed_reports,
                    lambda row, sg=str(space_group), metric_name=metric: row[
                        "by_space_group"
                    ]["space_groups"][sg][metric_name],
                )
                for metric in sg_metrics
            }
            for space_group in config.space_groups
        },
        "across_seed_macro": {
            metric: across_seed_statistics(
                [float(row["by_space_group"]["macro"][metric]) for row in seed_reports]
            )
            for metric in (
                "legal_terminal_rate",
                "short_contact_rejection_rate",
                "fixed_cell_strict_symmetry_survival_rate",
            )
        },
        "ablation_performed": False,
    }
    audit_markdown = _implementation_audit_markdown(
        config=config,
        audit=audit,
        seeds=seed_reports,
    )
    final_markdown = final_report_markdown(
        decision=decision,
        seed_rows=seed_reports,
        bootstrap=bootstrap,
    )
    payloads: dict[str, object] = {
        f"FULL_REPLICATION_SEED_{row['training_seed']}.json": row
        for row in seed_reports
    }
    payloads.update(
        {
            "FULL_REPLICATION_TRAINING_SUMMARY.json": training_summary,
            "FULL_REPLICATION_GENERATION_SUMMARY.json": generation_summary,
            "FULL_REPLICATION_PHYSICS_SUMMARY.json": physics_summary,
            "FULL_REPLICATION_BY_SPACE_GROUP.json": by_space_group,
            "FULL_REPLICATION_HIERARCHICAL_BOOTSTRAP.json": bootstrap,
            "FULL_REPLICATION_FAILURES.jsonl": failures,
            "FULL_REPLICATION_IMPLEMENTATION_AUDIT.md": audit_markdown,
            "FULL_REPLICATION_FINAL_REPORT.md": final_markdown,
        }
    )
    manifest_metadata = _manifest_metadata(
        config,
        decision=decision,
        repo_root=repo_root,
    )
    if not write_outputs:
        return {
            "payloads": payloads,
            "manifest_metadata": manifest_metadata,
            "decision": decision,
            "seed_reports": seed_reports,
            "bootstrap": bootstrap,
        }
    manifest = write_replication_artifacts(
        config.output_root,
        payloads,
        manifest_metadata=manifest_metadata,
    )
    return {
        "manifest": manifest,
        "decision": decision,
        "seed_reports": seed_reports,
        "bootstrap": bootstrap,
    }
