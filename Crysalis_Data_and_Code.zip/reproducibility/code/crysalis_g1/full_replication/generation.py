from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any, Mapping, Sequence

from pymatgen.core import Structure

from crysalis_g1.full_crysalis import generation as core_generation
from crysalis_g1.full_crysalis.config import sha256_file
from crysalis_g1.full_crysalis.generation import (
    GenerationRuntimeConfig,
    load_frozen_conditions,
    load_full_checkpoint,
    summarize_generation,
)
from crysalis_g1.full_crysalis.guide_mlip import GuideMLIP
from crysalis_g1.full_crysalis.state import PhysicsFeedback
from crysalis_g1.full_replication.config import ReplicationConfig
from crysalis_g1.full_replication.training import PeakResourceMonitor
from crysalis_g1.symmetry.assembly import C0SymmetryProjector, ProjectionReceipt


MECHANISM_COVERAGE_MINIMUM = 0.90


class _CountingGuide:
    def __init__(self, delegate: Any, counters: dict[str, int]) -> None:
        self._delegate = delegate
        self._counters = counters
        self.provenance = delegate.provenance

    def evaluate_candidates(
        self,
        structures: Sequence[Structure],
        candidate_slices: Sequence[tuple[int, int]],
    ) -> tuple[PhysicsFeedback, ...]:
        self._counters["guide_feedback_calls"] += 1
        result = self._delegate.evaluate_candidates(structures, candidate_slices)
        self._counters["guide_feedback_item_count"] += len(result)
        return result


def instrumented_generate_condition(
    model: Any,
    guide: Any,
    condition: Mapping[str, Any],
    *,
    normalizer: Any | None = None,
    runtime: GenerationRuntimeConfig | None = None,
) -> dict[str, Any]:
    """Observe one unchanged core generation call with scoped counters."""

    counters = {
        "model_forward_calls": 0,
        "relation_conditioned_geometry_calls": 0,
        "guide_feedback_calls": 0,
        "guide_feedback_item_count": 0,
        "crystallographic_projector_calls": 0,
        "crystallographic_projector_rejections": 0,
    }
    original_forward = core_generation._model_forward
    original_project = C0SymmetryProjector.project

    def observed_forward(
        observed_model: Any,
        event: Any,
        observed_normalizer: Any,
        *,
        physics_override: PhysicsFeedback | None = None,
    ) -> tuple[Any, Any]:
        counters["model_forward_calls"] += 1
        if event.candidate_orbit is not None:
            counters["relation_conditioned_geometry_calls"] += 1
        return original_forward(
            observed_model,
            event,
            observed_normalizer,
            physics_override=physics_override,
        )

    def observed_project(
        projector: C0SymmetryProjector,
        state: Any,
    ) -> ProjectionReceipt:
        counters["crystallographic_projector_calls"] += 1
        receipt = original_project(projector, state)
        if not receipt.accepted:
            counters["crystallographic_projector_rejections"] += 1
        return receipt

    counted_guide = _CountingGuide(guide, counters)
    core_generation._model_forward = observed_forward
    C0SymmetryProjector.project = observed_project
    try:
        record = core_generation.generate_condition(
            model,
            counted_guide,
            condition,
            normalizer=normalizer,
            runtime=runtime,
        )
    finally:
        core_generation._model_forward = original_forward
        C0SymmetryProjector.project = original_project

    steps = tuple(record["steps"])
    successful_steps = len(steps)
    relation_updates = sum(
        step["relation_state_before_hash"] != step["relation_state_after_hash"]
        for step in steps
    )
    guide_enters = sum(
        bool(step["guide_feedback_enters_geometry"]) for step in steps
    )
    guide_changes = sum(
        bool(step["guide_feedback_changed_geometry_output"]) for step in steps
    )
    record["replication_instrumentation"] = {
        **counters,
        "successful_add_orbit_steps": successful_steps,
        "persistent_relation_state_updates": relation_updates,
        "guide_feedback_enters_geometry_steps": guide_enters,
        "guide_feedback_changes_geometry": guide_changes,
        "retry_count": 0,
        "refill_count": 0,
    }
    return record


def _ratio(numerator: int, denominator: int) -> float:
    return 0.0 if denominator == 0 else numerator / denominator


def summarize_mechanism_counts(
    records: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    if not records:
        raise ValueError("mechanism summary requires generation records")
    keys = (
        "model_forward_calls",
        "relation_conditioned_geometry_calls",
        "guide_feedback_calls",
        "guide_feedback_item_count",
        "crystallographic_projector_calls",
        "crystallographic_projector_rejections",
        "successful_add_orbit_steps",
        "persistent_relation_state_updates",
        "guide_feedback_enters_geometry_steps",
        "guide_feedback_changes_geometry",
        "retry_count",
        "refill_count",
    )
    totals = {
        key: sum(
            int(record["replication_instrumentation"][key])
            for record in records
        )
        for key in keys
    }
    steps = totals["successful_add_orbit_steps"]
    relation_coverage = _ratio(
        totals["persistent_relation_state_updates"], steps
    )
    guide_entry_coverage = _ratio(
        totals["guide_feedback_enters_geometry_steps"], steps
    )
    guide_change_coverage = _ratio(
        totals["guide_feedback_changes_geometry"], steps
    )
    connected = bool(
        steps > 0
        and totals["persistent_relation_state_updates"] > 0
        and totals["guide_feedback_changes_geometry"] > 0
        and relation_coverage >= MECHANISM_COVERAGE_MINIMUM
        and guide_entry_coverage >= MECHANISM_COVERAGE_MINIMUM
        and guide_change_coverage >= MECHANISM_COVERAGE_MINIMUM
    )
    return {
        "schema_version": "g1-full-crysalis-replication-mechanism.1.0.0",
        "attempt_count": len(records),
        **totals,
        "persistent_relation_state_update_coverage": relation_coverage,
        "guide_feedback_geometry_entry_coverage": guide_entry_coverage,
        "guide_feedback_geometry_change_coverage": guide_change_coverage,
        "projector_call_rejection_rate": _ratio(
            totals["crystallographic_projector_rejections"],
            totals["crystallographic_projector_calls"],
        ),
        "minimum_required_mechanism_coverage": MECHANISM_COVERAGE_MINIMUM,
        "connectivity_status": "PASS" if connected else "FAIL",
        "implementation_correctness_only": True,
        "scientific_module_audit": False,
    }


def _write_json_new(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(
            payload,
            stream,
            ensure_ascii=False,
            allow_nan=False,
            indent=2,
            sort_keys=True,
        )
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def run_replication_generation(
    config: ReplicationConfig,
    *,
    training_seed: int,
    seed_root: str | Path,
) -> dict[str, Any]:
    if training_seed not in config.new_training_seeds:
        raise ValueError("instrumented generation is only for new replication seeds")
    base = config.load_base_config()
    root = Path(seed_root)
    generation_dir = root / "generation"
    records_path = generation_dir / "generation_records.json"
    summary_path = generation_dir / "generation_summary.json"
    mechanism_path = generation_dir / "replication_mechanism_summary.json"
    receipt_path = generation_dir / "replication_generation_receipt.json"
    journal_path = generation_dir / "replication_generation_journal.jsonl"
    protected = (
        records_path,
        summary_path,
        mechanism_path,
        receipt_path,
        journal_path,
    )
    if any(path.exists() for path in protected):
        raise FileExistsError("replication generation refuses to overwrite evidence")
    checkpoint_path = root / "training" / "best.pt"
    if not checkpoint_path.is_file():
        raise FileNotFoundError(f"replication checkpoint is missing: {checkpoint_path}")

    model, normalizer, checkpoint = load_full_checkpoint(
        checkpoint_path,
        device=base.training.device,
    )
    if int(checkpoint.get("root_seed", -1)) != training_seed:
        raise ValueError("replication checkpoint has the wrong training seed")
    guide = GuideMLIP.from_config(base)
    conditions = load_frozen_conditions(
        base.artifacts["condition_manifest"].path,
        attempt_count=config.condition_count_per_seed,
        root_seed=config.frozen_generation_root_seed,
    )
    runtime = GenerationRuntimeConfig.from_full_config(base)
    records: list[dict[str, Any]] = []
    generation_dir.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    with PeakResourceMonitor() as resources, journal_path.open(
        "x", encoding="utf-8", newline="\n"
    ) as journal:
        for index, condition in enumerate(conditions, start=1):
            record = instrumented_generate_condition(
                model,
                guide,
                condition,
                normalizer=normalizer,
                runtime=runtime,
            )
            records.append(record)
            journal.write(
                json.dumps(
                    record,
                    ensure_ascii=False,
                    allow_nan=False,
                    sort_keys=True,
                    separators=(",", ":"),
                )
                + "\n"
            )
            journal.flush()
            os.fsync(journal.fileno())
            if index % 10 == 0 or index == len(conditions):
                print(
                    f"replication generation seed={training_seed} "
                    f"attempts={index}/{len(conditions)}",
                    flush=True,
                )
    wall_seconds = time.perf_counter() - started
    if len(records) != config.condition_count_per_seed:
        raise RuntimeError("replication generation denominator is incomplete")

    summary = summarize_generation(records)
    mechanism = summarize_mechanism_counts(records)
    _write_json_new(records_path, records)
    summary = {
        **summary,
        "training_seed": training_seed,
        "checkpoint_sha256": sha256_file(checkpoint_path),
        "condition_manifest_sha256": base.artifacts[
            "condition_manifest"
        ].sha256,
        "generation_records_sha256": sha256_file(records_path),
        "generation_wall_seconds": wall_seconds,
        "peak_rss_bytes": resources.peak_rss_bytes,
        "peak_cuda_allocated_bytes": resources.peak_cuda_allocated_bytes,
    }
    _write_json_new(summary_path, summary)
    _write_json_new(mechanism_path, mechanism)
    receipt = {
        "schema_version": "g1-full-crysalis-replication-generation-receipt.1.0.0",
        "status": "PASS" if mechanism["connectivity_status"] == "PASS" else "FAIL",
        "training_seed": training_seed,
        "attempt_count": len(records),
        "condition_manifest_sha256": base.artifacts[
            "condition_manifest"
        ].sha256,
        "checkpoint_sha256": sha256_file(checkpoint_path),
        "records_sha256": sha256_file(records_path),
        "journal_sha256": sha256_file(journal_path),
        "summary_sha256": sha256_file(summary_path),
        "mechanism_sha256": sha256_file(mechanism_path),
        "frozen_generation_root_seed": base.root_seed,
        "training_seed_changes_generation_rng": False,
        "retry_count": 0,
        "refill_count": 0,
        "ablation_performed": False,
        "module_audit_performed": False,
    }
    _write_json_new(receipt_path, receipt)
    if receipt["status"] != "PASS":
        raise RuntimeError("integrated generation mechanism is disconnected")
    return {"records": records, "summary": summary, "mechanism": mechanism}
