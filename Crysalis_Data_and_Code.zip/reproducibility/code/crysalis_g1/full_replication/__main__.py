from __future__ import annotations

import argparse
from pathlib import Path

from crysalis_g1.full_replication.config import ReplicationConfig
from crysalis_g1.full_replication.runner import FORMAL_STAGE_ORDER, run_all, run_stage


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Run frozen FULL_CRYSALIS_SYSTEM_REPLICATION_V1 stages."
    )
    parser.add_argument("--config", required=True)
    parser.add_argument(
        "--stage",
        required=True,
        choices=(*FORMAL_STAGE_ORDER, "all"),
    )
    arguments = parser.parse_args()
    config = ReplicationConfig.from_json(arguments.config)
    repo_root = Path(__file__).resolve().parents[2]
    if arguments.stage == "all":
        result = run_all(config, repo_root=repo_root)
    else:
        result = run_stage(
            config,
            stage=arguments.stage,
            repo_root=repo_root,
        )
    print(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
