from __future__ import annotations

import json
import os
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Callable, Mapping

from crysalis_g1.full_crysalis.config import sha256_file
from crysalis_g1.full_crysalis.data import IntegratedCorpus
from crysalis_g1.full_crysalis.training import (
    TrainingLoopConfig,
    run_engineering_preflight,
)
from crysalis_g1.full_replication.config import (
    REQUIRED_OUTPUTS,
    ReplicationConfig,
    audit_frozen_reference,
)
from crysalis_g1.full_replication.evaluation import run_replication_evaluation
from crysalis_g1.full_replication.generation import run_replication_generation
from crysalis_g1.full_replication.reporting import (
    build_final_replication_artifacts,
    resume_replication_manifest,
)
from crysalis_g1.full_replication.training import (
    ReplicationTrainingConfig,
    model_initialization_sha256,
    train_replication_seed,
)


FORMAL_STAGE_ORDER = (
    "audit",
    "preflight",
    "train_20260824",
    "generate_20260824",
    "evaluate_20260824",
    "train_20260825",
    "generate_20260825",
    "evaluate_20260825",
    "final",
)


def _write_json_new(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(
            payload,
            stream,
            ensure_ascii=False,
            allow_nan=False,
            indent=2,
            sort_keys=True,
        )
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def _config_sha256(config: ReplicationConfig) -> str:
    return sha256_file(config.config_path)


def _receipt_path(config: ReplicationConfig, stage: str) -> Path:
    return config.output_root / "engineering" / "receipts" / f"{stage}.json"


def _relative(config: ReplicationConfig, path: Path) -> str:
    return path.resolve().relative_to(config.output_root.resolve()).as_posix()


def _verify_receipt(
    config: ReplicationConfig,
    stage: str,
) -> dict[str, Any]:
    path = _receipt_path(config, stage)
    if not path.is_file():
        raise FileNotFoundError(f"prior replication stage receipt is missing: {path}")
    receipt = json.loads(path.read_text(encoding="utf-8"))
    if receipt.get("stage") != stage or receipt.get("status") != "COMPLETE":
        raise ValueError(f"invalid replication stage receipt: {stage}")
    if receipt.get("config_sha256") != _config_sha256(config):
        raise ValueError(f"replication stage config hash drifted: {stage}")
    outputs = receipt.get("output_sha256")
    if not isinstance(outputs, Mapping) or not outputs:
        raise ValueError(f"replication stage receipt has no outputs: {stage}")
    for relative, expected in outputs.items():
        target = config.output_root / str(relative)
        if not target.is_file():
            raise FileNotFoundError(f"replication stage output is missing: {target}")
        if sha256_file(target) != expected:
            raise ValueError(f"replication stage output hash drifted: {target}")
    return receipt


def _verify_prior_receipts(config: ReplicationConfig, stage: str) -> None:
    index = FORMAL_STAGE_ORDER.index(stage)
    for prior in FORMAL_STAGE_ORDER[:index]:
        _verify_receipt(config, prior)


def _write_stage_receipt(
    config: ReplicationConfig,
    *,
    stage: str,
    outputs: tuple[Path, ...],
    boundary_audit: Mapping[str, Any],
    repo_root: Path,
) -> dict[str, Any]:
    if any(not path.is_file() for path in outputs):
        raise RuntimeError(f"replication {stage} did not produce all declared outputs")
    safe = f"safe.directory={repo_root.as_posix()}"
    execution_commit = subprocess.check_output(
        ["git", "-c", safe, "rev-parse", "HEAD"],
        cwd=repo_root,
        text=True,
    ).strip()
    execution_dirty_status = subprocess.check_output(
        ["git", "-c", safe, "status", "--short"],
        cwd=repo_root,
        text=True,
    ).splitlines()
    wrapper_source_sha256 = {
        path.relative_to(repo_root).as_posix(): sha256_file(path)
        for path in sorted(
            (repo_root / "crysalis_g1" / "full_replication").glob("*.py")
        )
    }
    receipt = {
        "schema_version": "g1-full-crysalis-replication-stage.1.0.0",
        "stage": stage,
        "status": "COMPLETE",
        "completed_at_utc": datetime.now(UTC).isoformat(),
        "config_sha256": _config_sha256(config),
        "reference_commit": config.reference_commit,
        "execution_commit": execution_commit,
        "execution_dirty_status": execution_dirty_status,
        "replication_wrapper_source_sha256": wrapper_source_sha256,
        "boundary_audit_status": boundary_audit["status"],
        "core_implementation_file_count": boundary_audit[
            "core_implementation_file_count"
        ],
        "source_dependency_file_count": boundary_audit[
            "source_dependency_file_count"
        ],
        "source_dependency_closure_sha256": boundary_audit[
            "source_dependency_closure_sha256"
        ],
        "source_dependency_closure_status": boundary_audit[
            "source_dependency_closure_status"
        ],
        "output_sha256": {
            _relative(config, path): sha256_file(path) for path in outputs
        },
        "retry_count": 0,
        "refill_count": 0,
        "sealed_or_blind_data_accessed": False,
        "server_used": False,
        "dft_used": False,
        "ablation_performed": False,
        "module_audit_performed": False,
    }
    _write_json_new(_receipt_path(config, stage), receipt)
    return receipt


def _append_failure(
    config: ReplicationConfig,
    *,
    stage: str,
    error: BaseException,
) -> None:
    path = config.output_root / "engineering" / "runner_failures.jsonl"
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": "g1-full-crysalis-replication-runner-failure.1.0.0",
        "recorded_at_utc": datetime.now(UTC).isoformat(),
        "stage": stage,
        "exception_type": type(error).__name__,
        "exception_message": str(error),
        "retry_count": 0,
        "refill_count": 0,
        "sealed_or_blind_data_accessed": False,
        "ablation_performed": False,
    }
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(
            json.dumps(
                payload,
                ensure_ascii=False,
                allow_nan=False,
                sort_keys=True,
                separators=(",", ":"),
            )
            + "\n"
        )
        stream.flush()
        os.fsync(stream.fileno())


def _verify_formal_boundary_closure(
    config: ReplicationConfig,
    *,
    stage: str,
    boundary: Mapping[str, Any],
) -> None:
    if stage == "audit":
        return
    audit_path = config.output_root / "engineering" / "reference_audit.json"
    initial = json.loads(audit_path.read_text(encoding="utf-8"))
    expected = initial.get("source_dependency_closure_sha256")
    if expected is None:
        supplemental = (
            config.output_root
            / "engineering"
            / "supplemental_dependency_closure_audit.json"
        )
        if not supplemental.is_file():
            raise ValueError("formal dependency closure receipt is missing")
        expected = json.loads(supplemental.read_text(encoding="utf-8"))[
            "source_dependency_closure_sha256"
        ]
    if boundary["source_dependency_closure_sha256"] != expected:
        raise ValueError(f"formal dependency closure drifted before stage: {stage}")


def _seed_root(config: ReplicationConfig, seed: int) -> Path:
    return config.output_root / "engineering" / "seeds" / str(seed)


def _run_audit(
    config: ReplicationConfig,
    repo_root: Path,
    boundary: Mapping[str, Any],
) -> tuple[Path, ...]:
    if config.output_root.exists():
        raise FileExistsError(
            f"replication audit refuses existing output root: {config.output_root}"
        )
    config.output_root.mkdir(parents=True, exist_ok=False)
    target = config.output_root / "engineering" / "reference_audit.json"
    _write_json_new(target, dict(boundary))
    return (target,)


def _run_preflight(
    config: ReplicationConfig,
    repo_root: Path,
    boundary: Mapping[str, Any],
) -> tuple[Path, ...]:
    del repo_root, boundary
    base = config.load_base_config()
    corpus = IntegratedCorpus.from_config(base)
    core_path = config.output_root / "engineering" / "core_preflight.json"
    core = run_engineering_preflight(base, corpus=corpus, output_path=core_path)
    base_loop = TrainingLoopConfig.from_full_config(base)
    initialization_hashes = {
        str(seed): model_initialization_sha256(
            ReplicationTrainingConfig.from_frozen(base_loop, seed)
        )
        for seed in config.new_training_seeds
    }
    if len(set(initialization_hashes.values())) != len(initialization_hashes):
        raise RuntimeError("new replication seeds have identical initial states")
    target = config.output_root / "engineering" / "replication_preflight.json"
    report = {
        "schema_version": "g1-full-crysalis-replication-preflight.1.0.0",
        "status": "PASS",
        "core_engineering_preflight": core,
        "new_seed_initial_state_sha256": initialization_hashes,
        "new_seed_initial_states_are_distinct": True,
        "formal_training_protocol": dict(config.frozen_protocol),
        "corpus_report": dict(corpus.report),
        "full_model_only": True,
        "retry_count": 0,
        "refill_count": 0,
        "sealed_or_blind_data_accessed": False,
        "ablation_performed": False,
        "module_audit_performed": False,
    }
    _write_json_new(target, report)
    return (core_path, target)


def _run_train(
    config: ReplicationConfig,
    seed: int,
) -> tuple[Path, ...]:
    root = _seed_root(config, seed) / "training"
    train_replication_seed(config, training_seed=seed, output_dir=root)
    return (
        root / "best.pt",
        root / "metrics.jsonl",
        root / "training_report.json",
        root / "replication_training_receipt.json",
    )


def _run_generate(
    config: ReplicationConfig,
    seed: int,
) -> tuple[Path, ...]:
    root = _seed_root(config, seed)
    run_replication_generation(config, training_seed=seed, seed_root=root)
    output = root / "generation"
    return (
        output / "replication_generation_journal.jsonl",
        output / "generation_records.json",
        output / "generation_summary.json",
        output / "replication_mechanism_summary.json",
        output / "replication_generation_receipt.json",
    )


def _run_evaluate(
    config: ReplicationConfig,
    seed: int,
) -> tuple[Path, ...]:
    root = _seed_root(config, seed)
    run_replication_evaluation(config, training_seed=seed, seed_root=root)
    output = root / "evaluation"
    return (
        output / "fixed_cell_fire300_records.jsonl",
        output / "cell_relax_fire300_records.jsonl",
        output / "physics_results.json",
        output / "replication_evaluation_receipt.json",
    )


def _run_final(
    config: ReplicationConfig,
    repo_root: Path,
) -> tuple[Path, ...]:
    manifest_name = "FULL_REPLICATION_MANIFEST.json"
    prior_names = tuple(
        name for name in REQUIRED_OUTPUTS if name != manifest_name
    )
    if all((config.output_root / name).is_file() for name in prior_names) and not (
        config.output_root / manifest_name
    ).exists():
        resume_replication_manifest(config, repo_root=repo_root)
    else:
        build_final_replication_artifacts(config, repo_root=repo_root)
    return tuple(config.output_root / name for name in REQUIRED_OUTPUTS)


def _dispatch(
    config: ReplicationConfig,
    stage: str,
    repo_root: Path,
    boundary: Mapping[str, Any],
) -> tuple[Path, ...]:
    if stage == "audit":
        return _run_audit(config, repo_root, boundary)
    if stage == "preflight":
        return _run_preflight(config, repo_root, boundary)
    if stage == "final":
        return _run_final(config, repo_root)
    action, seed_text = stage.rsplit("_", 1)
    seed = int(seed_text)
    functions: dict[str, Callable[[ReplicationConfig, int], tuple[Path, ...]]] = {
        "train": _run_train,
        "generate": _run_generate,
        "evaluate": _run_evaluate,
    }
    return functions[action](config, seed)


def run_stage(
    config: ReplicationConfig,
    *,
    stage: str,
    repo_root: str | Path,
) -> dict[str, Any]:
    if stage not in FORMAL_STAGE_ORDER:
        raise ValueError(f"unsupported replication stage: {stage}")
    repo = Path(repo_root).resolve()
    try:
        if (config.output_root / "FULL_REPLICATION_MANIFEST.json").exists():
            raise FileExistsError("final replication manifest already exists")
        _verify_prior_receipts(config, stage)
        if _receipt_path(config, stage).exists():
            raise FileExistsError(f"replication stage already completed: {stage}")
        boundary = audit_frozen_reference(config, repo)
        _verify_formal_boundary_closure(
            config,
            stage=stage,
            boundary=boundary,
        )
        outputs = _dispatch(config, stage, repo, boundary)
        return _write_stage_receipt(
            config,
            stage=stage,
            outputs=outputs,
            boundary_audit=boundary,
            repo_root=repo,
        )
    except BaseException as error:
        _append_failure(config, stage=stage, error=error)
        raise


def run_all(
    config: ReplicationConfig,
    *,
    repo_root: str | Path,
) -> dict[str, Any]:
    receipts = [
        run_stage(config, stage=stage, repo_root=repo_root)
        for stage in FORMAL_STAGE_ORDER
    ]
    return {
        "schema_version": "g1-full-crysalis-replication-run-complete.1.0.0",
        "status": "COMPLETE",
        "completed_stages": [receipt["stage"] for receipt in receipts],
        "stopped_after": "final",
        "ablation_started": False,
    }
