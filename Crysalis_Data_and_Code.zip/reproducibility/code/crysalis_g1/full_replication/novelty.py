from __future__ import annotations

import json
import math
from collections import Counter
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
from pymatgen.analysis.structure_matcher import StructureMatcher
from pymatgen.core import Lattice, Structure

from crysalis_g1.experiments.c0_symmetry_data import verify_frozen_phase2a
from crysalis_g1.experiments.c0_symmetry_oracle import load_recovered_parents


FormulaKey = tuple[tuple[int, int], ...]


def _formula_key(structure: Structure) -> FormulaKey:
    counts = Counter(int(site.specie.Z) for site in structure)
    divisor = math.gcd(*counts.values()) if counts else 1
    return tuple(
        sorted(
            (atomic_number, count // divisor)
            for atomic_number, count in counts.items()
        )
    )


def _buckets(
    structures: Iterable[Structure],
) -> dict[FormulaKey, list[Structure]]:
    result: dict[FormulaKey, list[Structure]] = {}
    for structure in structures:
        result.setdefault(_formula_key(structure), []).append(structure)
    return result


def _match_novelty_counts(
    generated: Sequence[Structure],
    *,
    train_parents: Sequence[Structure],
    all_parents: Sequence[Structure],
    matcher: StructureMatcher,
) -> dict[str, Any]:
    train = _buckets(train_parents)
    all_cohort = _buckets(all_parents)
    failures = 0

    def count(reference: Mapping[FormulaKey, Sequence[Structure]]) -> int:
        nonlocal failures
        novel = 0
        for structure in generated:
            try:
                is_novel = not any(
                    matcher.fit(structure, parent)
                    for parent in reference.get(_formula_key(structure), ())
                )
            except Exception:
                failures += 1
                is_novel = False
            novel += int(is_novel)
        return novel

    train_novel = count(train)
    all_novel = count(all_cohort)
    denominator = len(generated)
    return {
        "relative_to_train_fit": {
            "reference_structure_count": len(train_parents),
            "novel_count": train_novel,
            "novelty_rate": train_novel / max(denominator, 1),
        },
        "relative_to_frozen_parent_cohort": {
            "reference_structure_count": len(all_parents),
            "novel_count": all_novel,
            "novelty_rate": all_novel / max(denominator, 1),
        },
        "matcher_failure_count": failures,
    }


def _candidate_structure(candidate: Mapping[str, Any]) -> Structure:
    return Structure(
        Lattice(np.asarray(candidate["lattice"], dtype=float)),
        [int(value) for value in candidate["atomic_numbers"]],
        np.asarray(candidate["fractional_coordinates"], dtype=float),
        to_unit_cell=True,
    )


def _parent_structure(parent: Any) -> Structure:
    return Structure(
        Lattice(parent.lattice.primitive_matrix),
        parent.reconstructed_atomic_numbers,
        parent.reconstructed_fractional_coordinates,
        to_unit_cell=True,
    )


def dual_cohort_novelty(
    generation_records: Sequence[Mapping[str, Any]],
    *,
    phase2a_root: str | Path,
    split_manifest: str | Path,
    recovered_parent_cache: str | Path,
) -> dict[str, Any]:
    verify_frozen_phase2a(Path(phase2a_root))
    matcher = StructureMatcher(
        primitive_cell=False,
        scale=True,
        attempt_supercell=False,
        ltol=0.2,
        stol=0.3,
        angle_tol=5.0,
    )
    parsed: list[Structure] = []
    parse_failures = 0
    for record in generation_records:
        if not record.get("legal_terminal_crystal"):
            continue
        try:
            parsed.append(_candidate_structure(record["candidate"]))
        except Exception:
            parse_failures += 1

    unique_buckets: dict[FormulaKey, list[Structure]] = {}
    dedup_failures = 0
    for structure in parsed:
        bucket = unique_buckets.setdefault(_formula_key(structure), [])
        try:
            duplicate = any(matcher.fit(structure, prior) for prior in bucket)
        except Exception:
            dedup_failures += 1
            duplicate = False
        if not duplicate:
            bucket.append(structure)
    unique = [item for bucket in unique_buckets.values() for item in bucket]

    train_ids = set()
    with Path(split_manifest).open(encoding="utf-8") as stream:
        for line in stream:
            row = json.loads(line)
            if row["split"] == "train_fit":
                train_ids.add(str(row["material_id"]))
    parents = load_recovered_parents(recovered_parent_cache)
    all_parent_structures = [
        _parent_structure(parent) for parent in parents.values()
    ]
    train_parent_structures = [
        _parent_structure(parents[material_id])
        for material_id in sorted(train_ids)
        if material_id in parents
    ]
    novelty = _match_novelty_counts(
        unique,
        train_parents=train_parent_structures,
        all_parents=all_parent_structures,
        matcher=matcher,
    )
    return {
        "schema_version": "g1-full-crysalis-replication-novelty.1.0.0",
        "scope": "symmetry-valid legal terminal structures only",
        "legal_terminal_structure_count": len(parsed),
        "unique_structure_count": len(unique),
        "unique_structure_rate": len(unique) / max(len(parsed), 1),
        "candidate_parse_failure_count": parse_failures,
        "deduplication_matcher_failure_count": dedup_failures,
        **novelty,
        "structure_matcher": {
            "primitive_cell": False,
            "scale": True,
            "attempt_supercell": False,
            "ltol": 0.2,
            "stol": 0.3,
            "angle_tol": 5.0,
        },
        "external_database_matching_performed": False,
        "external_databases_not_queried": [
            "MP_FULL",
            "COD",
            "OQMD",
            "AFLOW",
            "ICSD",
        ],
    }
