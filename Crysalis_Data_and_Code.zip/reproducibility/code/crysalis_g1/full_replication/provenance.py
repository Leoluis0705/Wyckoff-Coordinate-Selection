from __future__ import annotations

import hashlib
import json
import subprocess
from pathlib import Path
from typing import Any

from crysalis_g1.full_crysalis.config import sha256_file
from crysalis_g1.full_replication.config import ReplicationConfig


SCIENTIFIC_STAGES = (
    "audit",
    "preflight",
    "train_20260824",
    "generate_20260824",
    "evaluate_20260824",
    "train_20260825",
    "generate_20260825",
    "evaluate_20260825",
)


def _git(repo: Path, *arguments: str, text: bool = True) -> str | bytes:
    return subprocess.check_output(
        ["git", "-c", f"safe.directory={repo.as_posix()}", *arguments],
        cwd=repo,
        text=text,
    )


def _commit_source_hashes(repo: Path, commit: str) -> dict[str, str]:
    names = str(
        _git(
            repo,
            "ls-tree",
            "-r",
            "--name-only",
            commit,
            "--",
            "crysalis_g1/full_replication",
        )
    ).splitlines()
    paths = sorted(name for name in names if name.endswith(".py"))
    if not paths:
        raise ValueError("execution commit has no replication wrapper sources")
    result = {}
    for relative in paths:
        content = _git(repo, "show", f"{commit}:{relative}", text=False)
        if not isinstance(content, bytes):
            raise TypeError("git blob retrieval unexpectedly returned text")
        result[relative] = hashlib.sha256(content).hexdigest()
    return result


def build_supplemental_stage_provenance(
    config: ReplicationConfig,
    repo_root: str | Path,
    *,
    scientific_execution_commit: str,
) -> dict[str, Any]:
    repo = Path(repo_root).resolve()
    resolved_commit = str(_git(repo, "rev-parse", scientific_execution_commit)).strip()
    source_hashes = _commit_source_hashes(repo, resolved_commit)
    receipts = {}
    for stage in SCIENTIFIC_STAGES:
        path = config.output_root / "engineering" / "receipts" / f"{stage}.json"
        receipt = json.loads(path.read_text(encoding="utf-8"))
        if receipt["stage"] != stage or receipt["status"] != "COMPLETE":
            raise ValueError(f"invalid original stage receipt: {stage}")
        for relative, expected in receipt["output_sha256"].items():
            if sha256_file(config.output_root / relative) != expected:
                raise ValueError(f"stage output hash drifted: {stage}/{relative}")
        receipts[stage] = {
            "completed_at_utc": receipt["completed_at_utc"],
            "receipt_sha256": sha256_file(path),
            "config_sha256": receipt["config_sha256"],
            "output_sha256": dict(receipt["output_sha256"]),
            "outputs_reverified": True,
        }
    return {
        "schema_version": (
            "g1-full-crysalis-replication-supplemental-stage-provenance.1.0.0"
        ),
        "status": "PASS_WITH_ORIGINAL_RECEIPT_LIMITATION",
        "scientific_execution_commit": resolved_commit,
        "scientific_execution_commit_evidence": (
            "reconstructed from the orchestrating session history"
        ),
        "original_receipts_recorded_execution_commit": False,
        "original_receipts_recorded_dirty_status": False,
        "execution_dirty_status": None,
        "execution_dirty_status_limitation": (
            "The exact stage-time dirty status was not embedded in the original "
            "receipts and is not reconstructed as fact."
        ),
        "replication_wrapper_source_sha256_at_execution_commit": source_hashes,
        "replication_wrapper_source_file_count": len(source_hashes),
        "scientific_stages": receipts,
        "scientific_model_training_generation_evaluation_reexecuted": False,
        "ablation_performed": False,
        "module_audit_performed": False,
    }


def write_supplemental_provenance_evidence(
    config: ReplicationConfig,
    *,
    dependency_closure: dict[str, Any],
    stage_provenance: dict[str, Any],
) -> tuple[Path, Path]:
    engineering = config.output_root / "engineering"
    paths_and_payloads = (
        (
            engineering / "supplemental_dependency_closure_audit.json",
            dependency_closure,
        ),
        (
            engineering / "supplemental_stage_provenance.json",
            stage_provenance,
        ),
    )
    for path, payload in paths_and_payloads:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(
                payload,
                stream,
                ensure_ascii=False,
                allow_nan=False,
                indent=2,
                sort_keys=True,
            )
            stream.write("\n")
    return tuple(path for path, _ in paths_and_payloads)
