from __future__ import annotations

import math
from collections import Counter
from typing import Any, Mapping, Sequence

import numpy as np


def _condition_id(record: Mapping[str, Any]) -> str:
    if "condition" in record:
        return str(record["condition"]["condition_id"])
    return str(record["condition_id"])


def _keyed(
    records: Sequence[Mapping[str, Any]],
) -> dict[str, Mapping[str, Any]]:
    result = {_condition_id(record): record for record in records}
    if len(result) != len(records):
        raise ValueError("duplicate condition IDs")
    return result


def _short_contact_rejected(record: Mapping[str, Any]) -> bool:
    return "SHORT_CONTACT" in record.get("projector_rejection_reasons", ())


def _force_summary(records: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    values = np.asarray(
        [
            float(record["pre_max_force_ev_per_angstrom"])
            for record in records
            if record.get("pre_max_force_ev_per_angstrom") is not None
        ],
        dtype=float,
    )
    if values.size == 0:
        return {
            "sample_count": 0,
            "mean": None,
            "median": None,
            "p90": None,
            "p95": None,
            "max": None,
        }
    if not np.isfinite(values).all():
        raise FloatingPointError("non-finite initial EvalMLIP force")
    return {
        "sample_count": int(values.size),
        "mean": float(values.mean()),
        "median": float(np.median(values)),
        "p90": float(np.quantile(values, 0.90)),
        "p95": float(np.quantile(values, 0.95)),
        "max": float(values.max()),
    }


def _protocol_summary(
    records: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    if not records:
        raise ValueError("physics protocol records must not be empty")
    count = len(records)
    converged = sum(bool(record.get("converged")) for record in records)
    physical = sum(bool(record.get("post_relax_survival")) for record in records)
    strict = sum(
        bool(record.get("strict_symmetry_preserving_survival"))
        for record in records
    )
    target_sg = sum(
        bool(record.get("strict_0_03_space_group_match")) for record in records
    )
    return {
        "attempt_count": count,
        "all_attempt_denominator": True,
        "evaluated_count": sum(
            record.get("status") == "EVALUATED" for record in records
        ),
        "convergence_count": converged,
        "convergence_rate": converged / count,
        "physical_survival_count": physical,
        "physical_survival_rate": physical / count,
        "strict_symmetry_survival_count": strict,
        "strict_symmetry_survival_rate": strict / count,
        "post_relax_target_space_group_count": target_sg,
        "post_relax_target_space_group_rate": target_sg / count,
        "failure_taxonomy": dict(
            sorted(Counter(str(record.get("status")) for record in records).items())
        ),
    }


def summarize_seed_system(
    *,
    training_seed: int,
    generation_records: Sequence[Mapping[str, Any]],
    fixed_records: Sequence[Mapping[str, Any]],
    cell_records: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    count = len(generation_records)
    if count == 0 or len(fixed_records) != count or len(cell_records) != count:
        raise ValueError("per-seed generation/evaluation denominators differ")
    expected_ids = set(_keyed(generation_records))
    if set(_keyed(fixed_records)) != expected_ids or set(
        _keyed(cell_records)
    ) != expected_ids:
        raise ValueError("per-seed generation/evaluation condition IDs differ")

    legal = sum(bool(record.get("legal_terminal_crystal")) for record in generation_records)
    short = sum(_short_contact_rejected(record) for record in generation_records)
    projector_failures = sum(
        record.get("failure_code") == "NO_PROJECTOR_LEGAL_GEOMETRY"
        for record in generation_records
    )
    no_legal = sum(
        record.get("failure_code") == "NO_LEGAL_ADD_ORBIT_ACTION"
        for record in generation_records
    )

    def validity(key: str) -> dict[str, Any]:
        valid = sum(bool(record.get(key)) for record in generation_records)
        return {"count": valid, "rate": valid / count}

    latencies = np.asarray(
        [float(record["latency_seconds"]) for record in generation_records],
        dtype=float,
    )
    if not np.isfinite(latencies).all():
        raise FloatingPointError("non-finite generation latency")
    return {
        "schema_version": "g1-full-crysalis-replication-seed-system.1.0.0",
        "training_seed": int(training_seed),
        "attempt_count": count,
        "generation": {
            "all_attempt_denominator": True,
            "legal_terminal_count": legal,
            "legal_terminal_rate": legal / count,
            "short_contact_rejection_count": short,
            "short_contact_rejection_rate": short / count,
            "projector_rejection_attempt_count": projector_failures,
            "projector_rejection_attempt_rate": projector_failures / count,
            "projector_rejection_definition": "NO_PROJECTOR_LEGAL_GEOMETRY",
            "no_legal_action_count": no_legal,
            "no_legal_action_rate": no_legal / count,
            "composition_validity": validity("composition_valid"),
            "multiplicity_validity": validity("multiplicity_valid"),
            "wyckoff_validity": validity("wyckoff_orbit_valid"),
            "target_space_group_validity": validity(
                "post_projector_target_space_group_match"
            ),
            "failure_taxonomy": dict(
                sorted(
                    Counter(
                        str(record.get("failure_code") or "NONE")
                        for record in generation_records
                    ).items()
                )
            ),
            "latency_seconds": {
                "mean": float(latencies.mean()),
                "median": float(np.median(latencies)),
                "p90": float(np.quantile(latencies, 0.90)),
            },
        },
        "physics": {
            "initial_max_force_ev_per_angstrom": _force_summary(fixed_records),
            "fixed_cell_fire300": _protocol_summary(fixed_records),
            "cell_relax_fire300": _protocol_summary(cell_records),
        },
        "retry_count": 0,
        "refill_count": 0,
        "ablation_performed": False,
        "module_audit_performed": False,
    }


def by_space_group_for_seed(
    *,
    generation_records: Sequence[Mapping[str, Any]],
    fixed_records: Sequence[Mapping[str, Any]],
    cell_records: Sequence[Mapping[str, Any]],
    expected_space_groups: Sequence[int],
) -> dict[str, Any]:
    fixed = _keyed(fixed_records)
    cell = _keyed(cell_records)
    groups: dict[int, list[Mapping[str, Any]]] = {
        int(space_group): [] for space_group in expected_space_groups
    }
    for record in generation_records:
        group = int(record["condition"]["space_group"])
        if group not in groups:
            raise ValueError(f"unexpected space group: {group}")
        groups[group].append(record)
    if any(not records for records in groups.values()):
        raise ValueError("one or more expected space groups have no attempts")

    output: dict[str, Any] = {}
    for space_group in expected_space_groups:
        records = groups[int(space_group)]
        ids = [_condition_id(record) for record in records]
        count = len(ids)
        force_values = [
            float(fixed[item]["pre_max_force_ev_per_angstrom"])
            for item in ids
            if fixed[item].get("pre_max_force_ev_per_angstrom") is not None
        ]
        output[str(space_group)] = {
            "attempt_count": count,
            "legal_terminal_rate": sum(
                bool(record.get("legal_terminal_crystal")) for record in records
            )
            / count,
            "short_contact_rejection_rate": sum(
                _short_contact_rejected(record) for record in records
            )
            / count,
            "fixed_cell_strict_symmetry_survival_rate": sum(
                bool(fixed[item].get("strict_symmetry_preserving_survival"))
                for item in ids
            )
            / count,
            "cell_relax_strict_symmetry_survival_rate": sum(
                bool(cell[item].get("strict_symmetry_preserving_survival"))
                for item in ids
            )
            / count,
            "initial_force_sample_count": len(force_values),
            "initial_force_median": (
                None if not force_values else float(np.median(force_values))
            ),
            "initial_force_p90": (
                None if not force_values else float(np.quantile(force_values, 0.90))
            ),
        }
    macro_metrics = (
        "legal_terminal_rate",
        "short_contact_rejection_rate",
        "fixed_cell_strict_symmetry_survival_rate",
    )
    return {
        "space_groups": output,
        "macro": {
            metric: float(np.mean([row[metric] for row in output.values()]))
            for metric in macro_metrics
        },
        "macro_is_unweighted_across_space_groups": True,
    }


def paired_condition_rows(
    *,
    full_generation: Sequence[Mapping[str, Any]],
    full_fixed: Sequence[Mapping[str, Any]],
    full_cell: Sequence[Mapping[str, Any]],
    c0_generation: Sequence[Mapping[str, Any]],
    c0_fixed: Sequence[Mapping[str, Any]],
    c0_cell: Sequence[Mapping[str, Any]],
) -> tuple[dict[str, Any], ...]:
    sources = tuple(
        _keyed(records)
        for records in (
            full_generation,
            full_fixed,
            full_cell,
            c0_generation,
            c0_fixed,
            c0_cell,
        )
    )
    ids = [_condition_id(record) for record in full_generation]
    expected = set(ids)
    if any(set(source) != expected for source in sources):
        raise ValueError("paired condition IDs differ")
    fg, ff, fc, cg, cf, cc = sources
    rows = []
    for condition_id in ids:
        full_force = ff[condition_id].get("pre_max_force_ev_per_angstrom")
        c0_force = cf[condition_id].get("pre_max_force_ev_per_angstrom")
        rows.append(
            {
                "condition_id": condition_id,
                "space_group": int(fg[condition_id]["condition"]["space_group"]),
                "legal_terminal_delta": int(
                    bool(fg[condition_id].get("legal_terminal_crystal"))
                )
                - int(bool(cg[condition_id].get("legal_terminal_crystal"))),
                "short_contact_rejection_delta": int(
                    _short_contact_rejected(fg[condition_id])
                )
                - int(_short_contact_rejected(cg[condition_id])),
                "fixed_strict_survival_delta": int(
                    bool(ff[condition_id].get("strict_symmetry_preserving_survival"))
                )
                - int(
                    bool(cf[condition_id].get("strict_symmetry_preserving_survival"))
                ),
                "cell_strict_survival_delta": int(
                    bool(fc[condition_id].get("strict_symmetry_preserving_survival"))
                )
                - int(
                    bool(cc[condition_id].get("strict_symmetry_preserving_survival"))
                ),
                "initial_force_full": (
                    None if full_force is None else float(full_force)
                ),
                "initial_force_c0": None if c0_force is None else float(c0_force),
            }
        )
    return tuple(rows)


def across_seed_statistics(values: Sequence[float]) -> dict[str, Any]:
    array = np.asarray(tuple(float(value) for value in values), dtype=float)
    if len(array) != 3 or not np.isfinite(array).all():
        raise ValueError("across-seed statistics require three finite values")
    return {
        "mean": float(array.mean()),
        "std": float(array.std(ddof=1)),
        "min": float(array.min()),
        "max": float(array.max()),
        "seed_count": 3,
    }


def classify_replication(
    seed_results: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    if len(seed_results) != 3:
        raise ValueError("replication decision requires exactly three training seeds")
    deltas = [result["deltas"] for result in seed_results]
    required_names = (
        "legal_terminal_rate",
        "short_contact_rejection_rate",
        "fixed_strict_survival_rate",
        "cell_strict_survival_rate",
        "sg_macro_legal_terminal_rate",
        "sg_macro_short_contact_rejection_rate",
    )
    finite = all(
        math.isfinite(float(delta[name]))
        for delta in deltas
        for name in required_names
    )
    legal = [float(delta["legal_terminal_rate"]) for delta in deltas]
    short = [float(delta["short_contact_rejection_rate"]) for delta in deltas]
    fixed = [float(delta["fixed_strict_survival_rate"]) for delta in deltas]
    cell = [float(delta["cell_strict_survival_rate"]) for delta in deltas]
    sg_legal = [float(delta["sg_macro_legal_terminal_rate"]) for delta in deltas]
    sg_short = [
        float(delta["sg_macro_short_contact_rejection_rate"])
        for delta in deltas
    ]
    criteria = {
        "A_3_of_3_legal_terminal_above_reference": all(value > 0 for value in legal),
        "B_3_of_3_short_contact_below_reference": all(
            value < 0 for value in short
        ),
        "C_fixed_at_least_2_of_3_and_mean_positive": bool(
            sum(value > 0 for value in fixed) >= 2 and np.mean(fixed) > 0
        ),
        "D_cell_three_seed_mean_positive": bool(np.mean(cell) > 0),
        "E_sg_macro_legal_positive_and_short_negative": bool(
            np.mean(sg_legal) > 0 and np.mean(sg_short) < 0
        ),
        "F_no_catastrophic_system_failure": bool(
            finite
            and not any(
                bool(result.get("catastrophic_failure"))
                for result in seed_results
            )
        ),
    }
    supported = all(criteria.values())
    mean_directions = {
        "legal_terminal": bool(np.mean(legal) > 0),
        "short_contact": bool(np.mean(short) < 0),
        "fixed_strict_survival": bool(np.mean(fixed) > 0),
        "cell_strict_survival": bool(np.mean(cell) > 0),
    }
    mostly_consistent = bool(
        sum(mean_directions.values()) >= 3
        and criteria["F_no_catastrophic_system_failure"]
    )
    signal = "SUPPORTED" if supported else ("MIXED" if mostly_consistent else "NOT_SUPPORTED")
    return {
        "FULL_CRYSALIS_REPLICATED_SIGNAL": signal,
        "FULL_CRYSALIS_REPLICATION_MIXED": signal == "MIXED",
        "criteria": criteria,
        "mean_primary_directions": mean_directions,
        "mixed_rule": (
            "at least three of four mean primary directions improve, without "
            "catastrophic failure, when A-F are not all satisfied"
        ),
        "not_supported_rule": (
            "fewer than three mean primary directions improve or a "
            "catastrophic system failure occurs"
        ),
        "system_level_decision_only": True,
        "ablation_performed": False,
    }
