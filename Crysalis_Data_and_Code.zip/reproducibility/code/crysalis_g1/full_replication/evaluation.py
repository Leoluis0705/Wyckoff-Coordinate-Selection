from __future__ import annotations

import json
import os
import time
from dataclasses import replace
from pathlib import Path
from typing import Any, Mapping

from crysalis_g1.full_crysalis.config import sha256_file
from crysalis_g1.full_crysalis.evaluation import run_full_evaluation
from crysalis_g1.full_replication.config import ReplicationConfig
from crysalis_g1.full_replication.training import PeakResourceMonitor


def validate_terminal_evaluation(
    result: Mapping[str, Any],
    *,
    attempt_count: int,
) -> dict[str, Any]:
    provenance = result.get("provenance", {})
    boundary_preserved = bool(
        provenance.get("role") == "TERMINAL_EVALUATION_ONLY"
        and provenance.get("writes_generation_state") is False
        and provenance.get("enters_training_loss") is False
        and provenance.get("checkpoint_selection") is False
        and provenance.get("separate_from_guide_instance") is True
    )
    if not boundary_preserved:
        raise ValueError("GuideMLIP/EvalMLIP boundary is not preserved")
    if int(result.get("attempt_count", -1)) != attempt_count:
        raise ValueError("terminal evaluation attempt denominator drifted")
    condition_sets = []
    for name in ("fixed_cell_fire300", "cell_relax_fire300"):
        protocol = result[name]
        records = tuple(protocol["records"])
        if len(records) != attempt_count:
            raise ValueError(f"{name} record denominator drifted")
        if int(protocol["summary"].get("attempt_count", -1)) != attempt_count:
            raise ValueError(f"{name} summary denominator drifted")
        ids = tuple(str(record["condition_id"]) for record in records)
        if len(set(ids)) != attempt_count:
            raise ValueError(f"{name} condition IDs are not unique")
        condition_sets.append(ids)
    if condition_sets[0] != condition_sets[1]:
        raise ValueError("fixed/cell evaluation condition ordering drifted")
    forbidden = {
        "retry_count": 0,
        "refill_count": 0,
        "dft_used": False,
        "ablation_performed": False,
    }
    if any(result.get(key) != value for key, value in forbidden.items()):
        raise ValueError("terminal evaluation violated a frozen boundary")
    return {
        "status": "PASS",
        "condition_count": attempt_count,
        "guide_eval_boundary_preserved": True,
        "fixed_and_cell_condition_order_identical": True,
        "retry_count": 0,
        "refill_count": 0,
        "dft_used": False,
        "ablation_performed": False,
    }


def _write_json_new(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(
            payload,
            stream,
            ensure_ascii=False,
            allow_nan=False,
            indent=2,
            sort_keys=True,
        )
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def run_replication_evaluation(
    config: ReplicationConfig,
    *,
    training_seed: int,
    seed_root: str | Path,
) -> dict[str, Any]:
    if training_seed not in config.new_training_seeds:
        raise ValueError("formal evaluation wrapper is only for new seeds")
    root = Path(seed_root)
    generation_path = root / "generation" / "generation_records.json"
    generation_receipt = (
        root / "generation" / "replication_generation_receipt.json"
    )
    if not generation_path.is_file() or not generation_receipt.is_file():
        raise FileNotFoundError("generation evidence is incomplete before EvalMLIP")
    evaluation_dir = root / "evaluation"
    receipt_path = evaluation_dir / "replication_evaluation_receipt.json"
    protected = (
        evaluation_dir / "fixed_cell_fire300_records.jsonl",
        evaluation_dir / "cell_relax_fire300_records.jsonl",
        evaluation_dir / "physics_results.json",
        receipt_path,
    )
    if any(path.exists() for path in protected):
        raise FileExistsError("replication evaluation refuses to overwrite evidence")

    base = config.load_base_config()
    seed_config = replace(base, output_root=str(root))
    started = time.perf_counter()
    with PeakResourceMonitor() as resources:
        result = run_full_evaluation(seed_config)
    wall_seconds = time.perf_counter() - started
    validation = validate_terminal_evaluation(
        result,
        attempt_count=config.condition_count_per_seed,
    )
    physics_path = evaluation_dir / "physics_results.json"
    fixed_path = evaluation_dir / "fixed_cell_fire300_records.jsonl"
    cell_path = evaluation_dir / "cell_relax_fire300_records.jsonl"
    receipt = {
        "schema_version": "g1-full-crysalis-replication-evaluation-receipt.1.0.0",
        **validation,
        "training_seed": training_seed,
        "evaluation_wall_seconds": wall_seconds,
        "peak_rss_bytes": resources.peak_rss_bytes,
        "peak_cuda_allocated_bytes": resources.peak_cuda_allocated_bytes,
        "generation_records_sha256": sha256_file(generation_path),
        "physics_results_sha256": sha256_file(physics_path),
        "fixed_cell_journal_sha256": sha256_file(fixed_path),
        "cell_relax_journal_sha256": sha256_file(cell_path),
        "eval_mlip_artifact_identical_to_guide": True,
        "eval_mlip_instance_separate_from_guide": True,
        "server_used": False,
        "sealed_or_blind_data_accessed": False,
        "module_audit_performed": False,
    }
    _write_json_new(receipt_path, receipt)
    return {"result": result, "receipt": receipt}
