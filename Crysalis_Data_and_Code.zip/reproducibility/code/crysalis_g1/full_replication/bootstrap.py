from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

import numpy as np


TRAINING_SEEDS = (20260823, 20260824, 20260825)
BINARY_METRICS = {
    "legal_terminal_rate": "legal_terminal_delta",
    "short_contact_rejection_rate": "short_contact_rejection_delta",
    "fixed_cell_strict_symmetry_survival_rate": (
        "fixed_strict_survival_delta"
    ),
    "cell_relax_strict_symmetry_survival_rate": "cell_strict_survival_delta",
}


def _interval(values: np.ndarray) -> list[float]:
    return [
        float(np.quantile(values, 0.025)),
        float(np.quantile(values, 0.975)),
    ]


def hierarchical_bootstrap(
    paired_rows_by_seed: Mapping[int, Sequence[Mapping[str, Any]]],
    *,
    bootstrap_seed: int = 20260826,
    replicates: int = 10_000,
    condition_count: int = 300,
) -> dict[str, Any]:
    if tuple(sorted(paired_rows_by_seed)) != TRAINING_SEEDS:
        raise ValueError("hierarchical bootstrap requires the three frozen seeds")
    if type(replicates) is not int or replicates <= 0:
        raise ValueError("bootstrap replicates must be a positive integer")
    if type(condition_count) is not int or condition_count <= 0:
        raise ValueError("condition count must be a positive integer")

    rows = [tuple(paired_rows_by_seed[seed]) for seed in TRAINING_SEEDS]
    if any(len(seed_rows) != condition_count for seed_rows in rows):
        raise ValueError("bootstrap condition denominator drifted")
    condition_ids = tuple(str(row["condition_id"]) for row in rows[0])
    if len(set(condition_ids)) != condition_count or any(
        tuple(str(row["condition_id"]) for row in seed_rows) != condition_ids
        for seed_rows in rows[1:]
    ):
        raise ValueError("bootstrap paired condition IDs differ")

    binary = {
        name: np.asarray(
            [
                [float(row[key]) for row in seed_rows]
                for seed_rows in rows
            ],
            dtype=float,
        )
        for name, key in BINARY_METRICS.items()
    }
    if any(not np.isfinite(values).all() for values in binary.values()):
        raise FloatingPointError("non-finite paired binary delta")

    force_pairs: list[tuple[np.ndarray, np.ndarray]] = []
    for seed_rows in rows:
        pairs = [
            (float(row["initial_force_full"]), float(row["initial_force_c0"]))
            for row in seed_rows
            if row.get("initial_force_full") is not None
            and row.get("initial_force_c0") is not None
        ]
        if not pairs:
            raise ValueError("force-p90 bootstrap has no finite paired conditions")
        full, c0 = (np.asarray(item, dtype=float) for item in zip(*pairs, strict=True))
        if not np.isfinite(full).all() or not np.isfinite(c0).all():
            raise FloatingPointError("non-finite paired force observation")
        force_pairs.append((full, c0))

    rng = np.random.default_rng(bootstrap_seed)
    binary_bootstrap = {
        name: np.empty(replicates, dtype=float) for name in BINARY_METRICS
    }
    force_bootstrap = np.empty(replicates, dtype=float)
    for replicate in range(replicates):
        sampled_seeds = rng.integers(0, len(TRAINING_SEEDS), size=3)
        binary_values = {name: [] for name in BINARY_METRICS}
        force_values = []
        for seed_index in sampled_seeds:
            condition_indices = rng.integers(0, condition_count, size=condition_count)
            for name, values in binary.items():
                binary_values[name].append(
                    float(values[seed_index, condition_indices].mean())
                )
            full_force, c0_force = force_pairs[int(seed_index)]
            force_indices = rng.integers(0, len(full_force), size=len(full_force))
            force_values.append(
                float(np.quantile(full_force[force_indices], 0.90))
                - float(np.quantile(c0_force[force_indices], 0.90))
            )
        for name in BINARY_METRICS:
            binary_bootstrap[name][replicate] = float(
                np.mean(binary_values[name])
            )
        force_bootstrap[replicate] = float(np.mean(force_values))

    metrics: dict[str, Any] = {}
    for name, values in binary.items():
        per_seed = values.mean(axis=1)
        boot = binary_bootstrap[name]
        metrics[name] = {
            "mean_system_delta": float(per_seed.mean()),
            "raw_seed_deltas": {
                str(seed): float(value)
                for seed, value in zip(TRAINING_SEEDS, per_seed, strict=True)
            },
            "bootstrap_mean_delta": float(boot.mean()),
            "confidence_interval_95": _interval(boot),
            "paired_condition_count_by_seed": {
                str(seed): condition_count for seed in TRAINING_SEEDS
            },
        }
    force_seed_deltas = np.asarray(
        [
            float(np.quantile(full, 0.90)) - float(np.quantile(c0, 0.90))
            for full, c0 in force_pairs
        ],
        dtype=float,
    )
    metrics["initial_force_p90_ev_per_angstrom"] = {
        "mean_system_delta": float(force_seed_deltas.mean()),
        "raw_seed_deltas": {
            str(seed): float(value)
            for seed, value in zip(TRAINING_SEEDS, force_seed_deltas, strict=True)
        },
        "bootstrap_mean_delta": float(force_bootstrap.mean()),
        "confidence_interval_95": _interval(force_bootstrap),
        "paired_condition_count_by_seed": {
            str(seed): len(force_pairs[index][0])
            for index, seed in enumerate(TRAINING_SEEDS)
        },
        "estimand": (
            "within-seed paired finite-condition p90(FULL) minus p90(C0), "
            "averaged across training seeds"
        ),
    }
    if not all(
        math.isfinite(metric["mean_system_delta"])
        and all(math.isfinite(value) for value in metric["confidence_interval_95"])
        for metric in metrics.values()
    ):
        raise FloatingPointError("non-finite hierarchical bootstrap result")
    return {
        "schema_version": "g1-full-crysalis-hierarchical-bootstrap.1.0.0",
        "bootstrap_seed": bootstrap_seed,
        "replicate_count": replicates,
        "confidence_level": 0.95,
        "training_seeds": list(TRAINING_SEEDS),
        "condition_count_per_seed": condition_count,
        "hierarchy": ["training_seed", "paired_condition"],
        "seed_level_resampling_with_replacement": True,
        "condition_level_resampling_with_replacement": True,
        "pairing_preserved_within_condition": True,
        "metrics": metrics,
        "seed_level_sample_is_limited": True,
        "precision_caveat": (
            "Only three training seeds are available; hierarchical confidence "
            "interval precision at the seed level must not be overstated."
        ),
        "ablation_performed": False,
    }
