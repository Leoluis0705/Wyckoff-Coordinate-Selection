from __future__ import annotations

import ast
import hashlib
import importlib.metadata
import json
import subprocess
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Mapping

from crysalis_g1.full_crysalis.config import (
    FullCrysalisConfig,
    sha256_file,
    verify_frozen_artifacts,
)
from crysalis_g1.r1.descriptors import descriptor_schema_sha256


SCHEMA_VERSION = "g1-full-crysalis-system-replication.1.0.0"
TRAINING_SEEDS = (20260823, 20260824, 20260825)
NEW_TRAINING_SEEDS = (20260824, 20260825)
SPACE_GROUPS = (225, 139, 12, 63, 189, 194, 123, 164)
REQUIRED_OUTPUTS = (
    "FULL_REPLICATION_MANIFEST.json",
    "FULL_REPLICATION_SEED_20260823.json",
    "FULL_REPLICATION_SEED_20260824.json",
    "FULL_REPLICATION_SEED_20260825.json",
    "FULL_REPLICATION_TRAINING_SUMMARY.json",
    "FULL_REPLICATION_GENERATION_SUMMARY.json",
    "FULL_REPLICATION_PHYSICS_SUMMARY.json",
    "FULL_REPLICATION_BY_SPACE_GROUP.json",
    "FULL_REPLICATION_HIERARCHICAL_BOOTSTRAP.json",
    "FULL_REPLICATION_FAILURES.jsonl",
    "FULL_REPLICATION_IMPLEMENTATION_AUDIT.md",
    "FULL_REPLICATION_FINAL_REPORT.md",
)
FORBIDDEN_AUTHORIZATIONS = (
    "server",
    "dft",
    "sealed_or_blind_access",
    "retry",
    "refill",
    "new_module",
    "ablation",
    "contribution_lock",
    "module_audit",
    "kan_vs_mlp",
    "relation_only_test",
    "physics_only_test",
    "memory_only_test",
    "e3nn_comparison",
)


def _hash_map(value: Mapping[str, Any], *, label: str) -> dict[str, str]:
    result = {str(name): str(digest) for name, digest in value.items()}
    if not result:
        raise ValueError(f"{label} must not be empty")
    for name, digest in result.items():
        if len(digest) != 64:
            raise ValueError(f"invalid SHA-256 for {label}/{name}")
        try:
            bytes.fromhex(digest)
        except ValueError as error:
            raise ValueError(f"invalid SHA-256 for {label}/{name}") from error
    return result


def _authorization_map(value: Mapping[str, Any]) -> dict[str, bool]:
    result: dict[str, bool] = {}
    for name, enabled in value.items():
        if type(enabled) is not bool:
            raise ValueError(f"authorization/{name} must be boolean")
        result[str(name)] = enabled
    return result


@dataclass(frozen=True, slots=True)
class ReplicationConfig:
    config_path: Path
    reference_commit: str
    reference_output_root: Path
    output_root: Path
    base_config_path: Path
    base_config_sha256: str
    training_seeds: tuple[int, ...]
    frozen_reference_seed: int
    new_training_seeds: tuple[int, ...]
    frozen_generation_root_seed: int
    condition_count_per_seed: int
    bootstrap_seed: int
    bootstrap_replicates: int
    bootstrap_confidence_level: float
    expected_dependencies: Mapping[str, str]
    relation_schema_version: str
    relation_schema_sha256: str
    positive_artifact_sha256: Mapping[str, str]
    frozen_artifact_sha256: Mapping[str, str]
    core_implementation_sha256: Mapping[str, str]
    frozen_protocol: Mapping[str, Any]
    reference_baseline: Mapping[str, str]
    space_groups: tuple[int, ...]
    authorization: Mapping[str, bool]
    required_outputs: tuple[str, ...]

    def __post_init__(self) -> None:
        if len(self.reference_commit) != 40:
            raise ValueError("reference commit must be a full SHA-1")
        if self.training_seeds != TRAINING_SEEDS:
            raise ValueError("replication training seeds drifted")
        if self.new_training_seeds != NEW_TRAINING_SEEDS:
            raise ValueError("new replication training seeds drifted")
        if self.frozen_reference_seed != 20260823:
            raise ValueError("frozen reference training seed drifted")
        if self.frozen_generation_root_seed != 20260823:
            raise ValueError("frozen generation root seed drifted")
        if self.condition_count_per_seed != 300:
            raise ValueError("replication condition denominator must remain 300")
        if self.bootstrap_seed != 20260826 or self.bootstrap_replicates != 10_000:
            raise ValueError("hierarchical bootstrap contract drifted")
        if self.bootstrap_confidence_level != 0.95:
            raise ValueError("bootstrap confidence level must remain 0.95")
        if self.space_groups != SPACE_GROUPS:
            raise ValueError("replication space-group set/order drifted")
        if self.required_outputs != REQUIRED_OUTPUTS:
            raise ValueError("replication output contract drifted")
        if self.reference_baseline.get("system_name") != "C0_FROZEN":
            raise ValueError("reference baseline must remain exact frozen C0")
        for name in ("local_training", "local_generation", "local_chgnet_evaluation"):
            if self.authorization.get(name) is not True:
                raise ValueError(f"{name} must remain authorized")
        for name in FORBIDDEN_AUTHORIZATIONS:
            if self.authorization.get(name) is not False:
                raise ValueError(f"{name} must remain forbidden")

    @classmethod
    def from_json(cls, path: str | Path) -> ReplicationConfig:
        config_path = Path(path)
        payload = json.loads(config_path.read_text(encoding="utf-8"))
        if payload.get("schema_version") != SCHEMA_VERSION:
            raise ValueError("unsupported replication config schema")
        bootstrap = payload["bootstrap"]
        base = payload["base_config"]
        relation = payload["relation_schema"]
        return cls(
            config_path=config_path,
            reference_commit=str(payload["reference_commit"]),
            reference_output_root=Path(payload["reference_output_root"]),
            output_root=Path(payload["output_root"]),
            base_config_path=Path(base["path"]),
            base_config_sha256=str(base["sha256"]),
            training_seeds=tuple(int(value) for value in payload["training_seeds"]),
            frozen_reference_seed=int(payload["frozen_reference_seed"]),
            new_training_seeds=tuple(
                int(value) for value in payload["new_training_seeds"]
            ),
            frozen_generation_root_seed=int(
                payload["frozen_generation_root_seed"]
            ),
            condition_count_per_seed=int(payload["condition_count_per_seed"]),
            bootstrap_seed=int(bootstrap["seed"]),
            bootstrap_replicates=int(bootstrap["replicates"]),
            bootstrap_confidence_level=float(bootstrap["confidence_level"]),
            expected_dependencies={
                str(name): str(version)
                for name, version in payload["expected_dependencies"].items()
            },
            relation_schema_version=str(relation["schema_version"]),
            relation_schema_sha256=str(relation["sha256"]),
            positive_artifact_sha256=_hash_map(
                payload["positive_artifact_sha256"], label="positive artifact"
            ),
            frozen_artifact_sha256=_hash_map(
                payload["frozen_artifact_sha256"], label="frozen artifact"
            ),
            core_implementation_sha256=_hash_map(
                payload["core_implementation_sha256"], label="core implementation"
            ),
            frozen_protocol=dict(payload["frozen_protocol"]),
            reference_baseline={
                str(name): str(value)
                for name, value in payload["reference_baseline"].items()
            },
            space_groups=tuple(int(value) for value in payload["space_groups"]),
            authorization=_authorization_map(payload["authorization"]),
            required_outputs=tuple(str(value) for value in payload["required_outputs"]),
        )

    def load_base_config(self) -> FullCrysalisConfig:
        return FullCrysalisConfig.from_json(self.base_config_path)


def _verify_hash_map(
    expected: Mapping[str, str],
    *,
    root: Path,
    label: str,
) -> dict[str, str]:
    observed: dict[str, str] = {}
    for relative, digest in expected.items():
        path = root / relative
        if not path.is_file():
            raise FileNotFoundError(f"{label} is missing: {path}")
        actual = sha256_file(path)
        if actual != digest:
            raise ValueError(
                f"{label} hash mismatch: {relative}: expected {digest}, "
                f"observed {actual}"
            )
        observed[relative] = actual
    return observed


def verify_core_snapshot(
    config: ReplicationConfig,
    repo_root: str | Path,
) -> dict[str, str]:
    return _verify_hash_map(
        config.core_implementation_sha256,
        root=Path(repo_root),
        label="core implementation",
    )


def _git_output(repo_root: Path, *arguments: str) -> str:
    return subprocess.check_output(
        ["git", "-c", f"safe.directory={repo_root.as_posix()}", *arguments],
        cwd=repo_root,
        text=True,
    ).strip()


def _python_module_name(relative: str) -> str:
    path = Path(relative).with_suffix("")
    parts = list(path.parts)
    if parts[-1] == "__init__":
        parts.pop()
    return ".".join(parts)


def _resolve_local_module(repo: Path, module: str) -> str | None:
    if not module.startswith("crysalis_g1"):
        return None
    stem = Path(*module.split("."))
    for candidate in (stem.with_suffix(".py"), stem / "__init__.py"):
        if (repo / candidate).is_file():
            return candidate.as_posix()
    return None


def _static_local_python_import_closure(
    repo: Path,
    starting_paths: tuple[str, ...],
) -> tuple[str, ...]:
    queue = [path for path in starting_paths if path.endswith(".py")]
    closure: set[str] = set()
    while queue:
        relative = queue.pop()
        if relative in closure:
            continue
        closure.add(relative)
        module = _python_module_name(relative)
        package = module.rsplit(".", 1)[0] if "." in module else ""
        tree = ast.parse(
            (repo / relative).read_text(encoding="utf-8"),
            filename=relative,
        )
        imported_modules: list[str] = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imported_modules.extend(alias.name for alias in node.names)
                continue
            if not isinstance(node, ast.ImportFrom):
                continue
            if node.level:
                package_parts = package.split(".") if package else []
                keep = len(package_parts) - node.level + 1
                base_parts = package_parts[: max(keep, 0)]
                if node.module:
                    base_parts.extend(node.module.split("."))
                base = ".".join(base_parts)
            else:
                base = node.module or ""
            if base:
                imported_modules.append(base)
                imported_modules.extend(
                    f"{base}.{alias.name}" for alias in node.names if alias.name != "*"
                )
        for imported in imported_modules:
            resolved = _resolve_local_module(repo, imported)
            if resolved is not None and resolved not in closure:
                queue.append(resolved)
    return tuple(sorted(closure))


def _reference_blob_sha256(
    repo: Path,
    commit: str,
    relative: str,
) -> str | None:
    try:
        content = subprocess.check_output(
            [
                "git",
                "-c",
                f"safe.directory={repo.as_posix()}",
                "show",
                f"{commit}:{relative}",
            ],
            cwd=repo,
            stderr=subprocess.DEVNULL,
        )
    except subprocess.CalledProcessError:
        return None
    return hashlib.sha256(content).hexdigest()


def audit_transitive_local_dependency_closure(
    config: ReplicationConfig,
    repo_root: str | Path,
) -> dict[str, Any]:
    repo = Path(repo_root).resolve()
    configured = dict(config.core_implementation_sha256)
    for relative, expected in configured.items():
        if sha256_file(repo / relative) != expected:
            raise ValueError(f"configured dependency hash mismatch: {relative}")
    python_closure = _static_local_python_import_closure(
        repo,
        tuple(configured),
    )
    source_paths = tuple(sorted(set(configured) | set(python_closure)))
    source_hashes = {
        relative: sha256_file(repo / relative) for relative in source_paths
    }
    missing = tuple(sorted(set(python_closure) - set(configured)))

    positive_manifest = json.loads(
        (config.reference_output_root / "FULL_CRYSALIS_MANIFEST.json").read_text(
            encoding="utf-8"
        )
    )
    positive_dirty = tuple(positive_manifest.get("git", {}).get("dirty_status", ()))
    positive_audit_complete = json.loads(
        (
            config.reference_output_root / "engineering" / "audit_complete.json"
        ).read_text(encoding="utf-8")
    )
    positive_audit_time = datetime.fromisoformat(
        positive_audit_complete["completed_at_utc"]
    )

    details: dict[str, Any] = {}
    exact_count = 0
    retrospective_count = 0
    for relative in missing:
        current = source_hashes[relative]
        reference = _reference_blob_sha256(
            repo,
            config.reference_commit,
            relative,
        )
        modified_at = datetime.fromtimestamp(
            (repo / relative).stat().st_mtime,
            tz=UTC,
        )
        if reference == current:
            status = "MATCHES_REFERENCE_COMMIT"
            exact_count += 1
        elif (
            any(line.endswith(relative) for line in positive_dirty)
            and modified_at <= positive_audit_time
        ):
            status = "RETROSPECTIVE_CURRENT_HASH_WITH_PRE_RUN_MTIME_AND_POSITIVE_DIRTY_STATUS"
            retrospective_count += 1
        else:
            raise ValueError(
                f"transitive implementation hash mismatch without frozen evidence: {relative}"
            )
        details[relative] = {
            "sha256": current,
            "reference_commit_sha256": reference,
            "matches_reference_commit": reference == current,
            "positive_manifest_recorded_path_dirty": any(
                line.endswith(relative) for line in positive_dirty
            ),
            "current_file_mtime_utc": modified_at.isoformat(),
            "positive_audit_completed_at_utc": positive_audit_time.isoformat(),
            "mtime_precedes_positive_audit_completion": (
                modified_at <= positive_audit_time
            ),
            "evidence_status": status,
        }

    closure_digest = hashlib.sha256(
        json.dumps(
            source_hashes,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()
    return {
        "schema_version": (
            "g1-full-crysalis-replication-transitive-dependency-closure.1.0.0"
        ),
        "status": (
            "PASS_WITH_DOCUMENTED_RETROSPECTIVE_LIMITATION"
            if retrospective_count
            else "PASS"
        ),
        "method": "static AST closure over local crysalis_g1 imports",
        "dynamic_imports_not_proven_by_static_closure": True,
        "configured_snapshot_file_count": len(configured),
        "static_python_import_closure_count": len(python_closure),
        "source_dependency_file_count": len(source_paths),
        "unconfigured_transitive_path_count": len(missing),
        "reference_commit_exact_match_count": exact_count,
        "retrospective_dirty_path_count": retrospective_count,
        "source_dependency_sha256": source_hashes,
        "source_dependency_closure_sha256": closure_digest,
        "unconfigured_transitive_paths": details,
        "retrospective_limitation": (
            "The positive run recorded the dirty path but not its SHA-256. Its current "
            "hash is supported by a pre-run filesystem mtime, not by a pre-run "
            "cryptographic receipt. Both new seeds used this same current file."
            if retrospective_count
            else None
        ),
        "ablation_performed": False,
        "module_audit_performed": False,
    }


def _dependency_versions() -> dict[str, str]:
    names = ("chgnet", "numpy", "pymatgen", "pyxtal", "spglib", "torch")
    return {name: importlib.metadata.version(name) for name in names}


def audit_frozen_reference(
    config: ReplicationConfig,
    repo_root: str | Path,
) -> dict[str, Any]:
    repo = Path(repo_root).resolve()
    _git_output(repo, "cat-file", "-e", f"{config.reference_commit}^{{commit}}")
    tracked_paths = tuple(
        relative
        for relative in config.core_implementation_sha256
        if _git_output(repo, "ls-files", "--", relative)
    )
    diff_text = _git_output(
        repo,
        "diff",
        "--name-only",
        config.reference_commit,
        "--",
        *tracked_paths,
    )
    tracked_diff = [] if not diff_text else diff_text.splitlines()
    if tracked_diff:
        raise ValueError(
            f"tracked core differs from frozen reference commit: {tracked_diff}"
        )
    core = verify_core_snapshot(config, repo)
    closure = audit_transitive_local_dependency_closure(config, repo)
    positive = _verify_hash_map(
        config.positive_artifact_sha256,
        root=config.reference_output_root,
        label="positive reference artifact",
    )
    if sha256_file(repo / config.base_config_path) != config.base_config_sha256:
        raise ValueError("frozen base config hash mismatch")
    base_config = config.load_base_config()
    frozen = verify_frozen_artifacts(base_config)
    if frozen != dict(config.frozen_artifact_sha256):
        raise ValueError("frozen input artifact map drifted")
    dependencies = _dependency_versions()
    if dependencies != dict(config.expected_dependencies):
        raise ValueError(
            f"replication dependency versions drifted: {dependencies}"
        )
    relation_hash = descriptor_schema_sha256()
    if relation_hash != config.relation_schema_sha256:
        raise ValueError("relation descriptor schema hash drifted")
    manifest = json.loads(
        (
            config.reference_output_root / "FULL_CRYSALIS_MANIFEST.json"
        ).read_text(encoding="utf-8")
    )
    if manifest.get("full_crysalis_signal") != "POSITIVE":
        raise ValueError("frozen positive run no longer records POSITIVE")
    if manifest.get("git", {}).get("commit") != config.reference_commit:
        raise ValueError("positive manifest commit differs from frozen reference")
    comparison = json.loads(
        (config.reference_output_root / "FULL_CRYSALIS_VS_C0.json").read_text(
            encoding="utf-8"
        )
    )
    if tuple(comparison.get("comparison_systems", ())) != (
        "C0_FROZEN",
        "FULL_CRYSALIS",
    ):
        raise ValueError("positive comparison reference baseline drifted")
    return {
        "schema_version": "g1-full-crysalis-replication-audit.1.0.0",
        "status": "PASS",
        "reference_commit": config.reference_commit,
        "reference_baseline": "C0_FROZEN",
        "reference_output_root": str(config.reference_output_root.resolve()),
        "core_implementation_file_count": len(core),
        "core_implementation_sha256": core,
        "source_dependency_file_count": closure[
            "source_dependency_file_count"
        ],
        "source_dependency_closure_sha256": closure[
            "source_dependency_closure_sha256"
        ],
        "source_dependency_closure_status": closure["status"],
        "transitive_local_dependency_closure": closure,
        "positive_artifact_count": len(positive),
        "positive_artifact_sha256": positive,
        "frozen_artifact_count": len(frozen),
        "frozen_artifact_sha256": frozen,
        "tracked_core_diff_from_reference_commit": tracked_diff,
        "dependencies": dependencies,
        "relation_schema_version": config.relation_schema_version,
        "relation_schema_sha256": relation_hash,
        "condition_manifest_sha256": frozen["condition_manifest"],
        "guide_mlip_artifact_sha256": frozen["chgnet_weights"],
        "eval_mlip_artifact_sha256": frozen["chgnet_weights"],
        "c0_checkpoint_sha256": frozen["c0_checkpoint"],
        "uncommitted_r1_positive_run_hashes_previously_recorded": False,
        "uncommitted_r1_frozen_now_before_replication": True,
        "sealed_or_blind_data_accessed": False,
        "server_used": False,
        "dft_used": False,
        "retry_count": 0,
        "refill_count": 0,
        "ablation_performed": False,
        "module_audit_performed": False,
    }
