from __future__ import annotations

import hashlib
from dataclasses import dataclass, replace
from math import isfinite

from crysalis_assembly.periodic import canonical_periodic_edge_key


@dataclass(frozen=True)
class PersistentPeriodicEdgeState:
    edge_id: str
    source_id: str
    target_id: str
    image: tuple[int, int, int]
    relation_type: str
    relative_vector: tuple[float, float, float]
    distance: float
    coordination_role: str | None
    bond_valence_residual: float | None
    feasibility_score: float
    local_energy: float | None
    assembly_age: int
    memory: tuple[float, ...]

    @classmethod
    def create(
        cls,
        *,
        source_id: str,
        target_id: str,
        image: tuple[int, int, int],
        relation_type: str,
        memory: tuple[float, ...] = (),
        relative_vector: tuple[float, float, float] = (0.0, 0.0, 0.0),
        distance: float = 0.0,
        assembly_age: int = 0,
    ) -> PersistentPeriodicEdgeState:
        key = canonical_periodic_edge_key(source_id, target_id, image)
        identity = f"{key.source_id}|{key.target_id}|{key.image}"
        edge_id = "edge-" + hashlib.sha256(identity.encode()).hexdigest()[:16]
        return cls(
            edge_id=edge_id,
            source_id=key.source_id,
            target_id=key.target_id,
            image=key.image,
            relation_type=relation_type,
            relative_vector=relative_vector,
            distance=float(distance),
            coordination_role=None,
            bond_valence_residual=None,
            feasibility_score=1.0,
            local_energy=None,
            assembly_age=assembly_age,
            memory=tuple(float(value) for value in memory),
        )

    def __post_init__(self) -> None:
        if not self.edge_id or not self.relation_type:
            raise ValueError("edge identity and relation type must be non-empty")
        if len(self.image) != 3 or any(type(value) is not int for value in self.image):
            raise ValueError("periodic image must contain three integers")
        if len(self.relative_vector) != 3 or any(
            not isfinite(value) for value in self.relative_vector
        ):
            raise ValueError("relative vector must be finite")
        if not isfinite(self.distance) or self.distance < 0:
            raise ValueError("distance must be finite and non-negative")

    def with_memory(self, memory: tuple[float, ...]) -> PersistentPeriodicEdgeState:
        return replace(self, memory=tuple(float(value) for value in memory))

