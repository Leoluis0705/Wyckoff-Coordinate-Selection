from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass
from math import isfinite
from typing import Any, Literal, cast

from crysalis_assembly.serialization import canonical_payload_json

from .motif import MotifFactor
from .orbit import OrbitState
from .periodic_edge import PersistentPeriodicEdgeState


@dataclass(frozen=True)
class LatticeState:
    matrix: tuple[tuple[float, float, float], ...]
    source: Literal["generated", "updated"]

    def __post_init__(self) -> None:
        if len(self.matrix) != 3 or any(len(row) != 3 for row in self.matrix):
            raise ValueError("lattice matrix must be 3x3")
        if any(not isfinite(value) for row in self.matrix for value in row):
            raise ValueError("lattice matrix must be finite")
        a = self.matrix
        determinant = (
            a[0][0] * (a[1][1] * a[2][2] - a[1][2] * a[2][1])
            - a[0][1] * (a[1][0] * a[2][2] - a[1][2] * a[2][0])
            + a[0][2] * (a[1][0] * a[2][1] - a[1][1] * a[2][0])
        )
        if determinant <= 0:
            raise ValueError("lattice determinant must be positive")


@dataclass(frozen=True)
class FeasibilityRecord:
    score: float
    reason_codes: tuple[str, ...]
    termination_ready: bool


@dataclass(frozen=True)
class ProvenanceRecord:
    namespace: str
    seed: int
    split: str
    schema_version: str = "g1.0.0"


@dataclass(frozen=True)
class ActionReceipt:
    legal: bool
    reason_codes: tuple[str, ...]
    before_hash: str
    after_hash: str
    repair_magnitude: float = 0.0


@dataclass(frozen=True)
class MaterialEmbryoState:
    state_id: str
    composition: tuple[tuple[int, int], ...]
    remaining_composition: tuple[tuple[int, int], ...]
    target_properties: tuple[tuple[str, float], ...]
    chemistry_domain: str | None
    space_group: int | None
    space_group_source: Literal["condition", "sampled", "unset"]
    lattice_state: LatticeState | None
    orbit_states: tuple[OrbitState, ...]
    periodic_edges: tuple[PersistentPeriodicEdgeState, ...]
    motif_factors: tuple[MotifFactor, ...]
    assembly_step: int
    terminated: bool
    feasibility: FeasibilityRecord
    history: tuple[ActionReceipt, ...]
    provenance: ProvenanceRecord

    def __post_init__(self) -> None:
        if self.composition != tuple(sorted(self.composition)):
            raise ValueError("composition must be sorted")
        if self.remaining_composition != tuple(sorted(self.remaining_composition)):
            raise ValueError("remaining composition must be sorted")
        if any(not 1 <= z <= 118 or count <= 0 for z, count in self.composition):
            raise ValueError("composition entries must be positive")
        total = dict(self.composition)
        if any(total.get(z, 0) < count for z, count in self.remaining_composition):
            raise ValueError("remaining composition exceeds total composition")
        if self.space_group is not None and not 1 <= self.space_group <= 230:
            raise ValueError("space group must be from 1 to 230")
        if self.assembly_step < 0:
            raise ValueError("assembly_step must be non-negative")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def content_hash(self) -> str:
        payload = self.to_dict()
        payload.pop("state_id", None)
        payload.pop("history", None)
        return hashlib.sha256(canonical_payload_json(payload).encode()).hexdigest()


def _normalize_composition(composition: dict[int, int]) -> tuple[tuple[int, int], ...]:
    normalized = tuple(sorted((int(z), int(count)) for z, count in composition.items()))
    if not normalized or any(not 1 <= z <= 118 or count <= 0 for z, count in normalized):
        raise ValueError("composition must contain positive counts for atomic numbers 1..118")
    if sum(count for _, count in normalized) > 12:
        raise ValueError("smoke embryo supports at most 12 sites")
    return normalized


def initialize_embryo(
    composition: dict[int, int],
    *,
    space_group: int | None,
    seed: int,
    target_properties: dict[str, float] | None = None,
    chemistry_domain: str | None = None,
) -> MaterialEmbryoState:
    normalized = _normalize_composition(composition)
    atom_count = sum(count for _, count in normalized)
    length = 3.0 + atom_count ** (1 / 3)
    lattice = LatticeState(
        matrix=((length, 0.0, 0.0), (0.0, length, 0.0), (0.0, 0.0, length)),
        source="generated",
    )
    properties = tuple(sorted((target_properties or {}).items()))
    embryo_payload = {
        "composition": normalized,
        "properties": properties,
        "chemistry_domain": chemistry_domain,
        "space_group": space_group,
        "seed": seed,
    }
    embryo_id = "embryo-" + hashlib.sha256(
        canonical_payload_json(embryo_payload).encode()
    ).hexdigest()[:16]
    state = MaterialEmbryoState(
        state_id=embryo_id,
        composition=normalized,
        remaining_composition=normalized,
        target_properties=properties,
        chemistry_domain=chemistry_domain,
        space_group=space_group if space_group is not None else 1,
        space_group_source="condition" if space_group is not None else "sampled",
        lattice_state=lattice,
        orbit_states=(),
        periodic_edges=(),
        motif_factors=(),
        assembly_step=0,
        terminated=False,
        feasibility=FeasibilityRecord(1.0, (), False),
        history=(),
        provenance=ProvenanceRecord("g1-smoke", seed, "synthetic_smoke"),
    )
    return state


def state_from_dict(payload: dict[str, Any]) -> MaterialEmbryoState:
    lattice_payload = payload.get("lattice_state")
    lattice = None
    if lattice_payload is not None:
        lattice = LatticeState(
            matrix=tuple(
                cast(tuple[float, float, float], tuple(float(value) for value in row))
                for row in lattice_payload["matrix"]
            ),
            source=lattice_payload["source"],
        )
    orbits = tuple(
        OrbitState(
            orbit_id=item["orbit_id"],
            wyckoff_letter=item["wyckoff_letter"],
            multiplicity=int(item["multiplicity"]),
            atomic_number=item["atomic_number"],
            oxidation_state=item["oxidation_state"],
            occupancy=float(item["occupancy"]),
            free_parameters=tuple(float(value) for value in item["free_parameters"]),
            free_parameter_mask=tuple(bool(value) for value in item["free_parameter_mask"]),
            expanded_fractional_coordinates=tuple(
                cast(
                    tuple[float, float, float],
                    tuple(float(value) for value in coordinate),
                )
                for coordinate in item["expanded_fractional_coordinates"]
            ),
            added_step=int(item["added_step"]),
            legality_status=item["legality_status"],
            uncertainty=float(item["uncertainty"]),
        )
        for item in payload["orbit_states"]
    )
    edges = tuple(
        PersistentPeriodicEdgeState(
            edge_id=item["edge_id"],
            source_id=item["source_id"],
            target_id=item["target_id"],
            image=cast(tuple[int, int, int], tuple(int(value) for value in item["image"])),
            relation_type=item["relation_type"],
            relative_vector=cast(
                tuple[float, float, float],
                tuple(float(value) for value in item["relative_vector"]),
            ),
            distance=float(item["distance"]),
            coordination_role=item["coordination_role"],
            bond_valence_residual=item["bond_valence_residual"],
            feasibility_score=float(item["feasibility_score"]),
            local_energy=item["local_energy"],
            assembly_age=int(item["assembly_age"]),
            memory=tuple(float(value) for value in item["memory"]),
        )
        for item in payload["periodic_edges"]
    )
    motifs = tuple(MotifFactor(**item) for item in payload["motif_factors"])
    history = tuple(
        ActionReceipt(
            legal=bool(item["legal"]),
            reason_codes=tuple(item["reason_codes"]),
            before_hash=item["before_hash"],
            after_hash=item["after_hash"],
            repair_magnitude=float(item["repair_magnitude"]),
        )
        for item in payload["history"]
    )
    feasibility_payload = payload["feasibility"]
    provenance_payload = payload["provenance"]
    return MaterialEmbryoState(
        state_id=payload["state_id"],
        composition=tuple(
            cast(tuple[int, int], tuple(int(value) for value in item))
            for item in payload["composition"]
        ),
        remaining_composition=tuple(
            cast(tuple[int, int], tuple(int(value) for value in item))
            for item in payload["remaining_composition"]
        ),
        target_properties=tuple(
            (str(name), float(value)) for name, value in payload["target_properties"]
        ),
        chemistry_domain=payload["chemistry_domain"],
        space_group=payload["space_group"],
        space_group_source=payload["space_group_source"],
        lattice_state=lattice,
        orbit_states=orbits,
        periodic_edges=edges,
        motif_factors=motifs,
        assembly_step=int(payload["assembly_step"]),
        terminated=bool(payload["terminated"]),
        feasibility=FeasibilityRecord(
            float(feasibility_payload["score"]),
            tuple(feasibility_payload["reason_codes"]),
            bool(feasibility_payload["termination_ready"]),
        ),
        history=history,
        provenance=ProvenanceRecord(
            provenance_payload["namespace"],
            int(provenance_payload["seed"]),
            provenance_payload["split"],
            provenance_payload["schema_version"],
        ),
    )
