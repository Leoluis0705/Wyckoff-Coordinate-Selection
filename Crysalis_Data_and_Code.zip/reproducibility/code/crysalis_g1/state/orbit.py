from __future__ import annotations

from dataclasses import dataclass
from math import isfinite


@dataclass(frozen=True)
class OrbitState:
    orbit_id: str
    wyckoff_letter: str
    multiplicity: int
    atomic_number: int | None
    oxidation_state: float | None
    occupancy: float
    free_parameters: tuple[float, ...]
    free_parameter_mask: tuple[bool, ...]
    expanded_fractional_coordinates: tuple[tuple[float, float, float], ...]
    added_step: int
    legality_status: str
    uncertainty: float

    def __post_init__(self) -> None:
        if not self.orbit_id or not self.wyckoff_letter:
            raise ValueError("orbit identity and Wyckoff letter must be non-empty")
        if self.multiplicity <= 0:
            raise ValueError("orbit multiplicity must be positive")
        if self.atomic_number is not None and not 1 <= self.atomic_number <= 118:
            raise ValueError("atomic_number must be from 1 to 118")
        if not 0 < self.occupancy <= 1 or not isfinite(self.occupancy):
            raise ValueError("occupancy must be finite and in (0, 1]")
        if len(self.free_parameters) != len(self.free_parameter_mask):
            raise ValueError("free parameter mask length mismatch")
        if len(self.expanded_fractional_coordinates) != self.multiplicity:
            raise ValueError("expanded coordinate count must equal multiplicity")
        for coordinate in self.expanded_fractional_coordinates:
            if len(coordinate) != 3 or any(not isfinite(value) for value in coordinate):
                raise ValueError("fractional coordinates must be finite 3-vectors")

