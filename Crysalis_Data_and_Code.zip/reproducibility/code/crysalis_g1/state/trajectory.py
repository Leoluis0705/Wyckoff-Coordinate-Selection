from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass

from crysalis_assembly.serialization import canonical_payload_json

from crysalis_g1.actions import AssemblyAction
from crysalis_g1.constraints.projector import CrystallographicProjector

from .embryo import ActionReceipt, MaterialEmbryoState, state_from_dict


@dataclass(frozen=True)
class TrajectoryStep:
    action: AssemblyAction
    expected_state_hash: str
    receipt: ActionReceipt


@dataclass(frozen=True)
class Trajectory:
    trajectory_id: str
    initial_state: MaterialEmbryoState
    steps: tuple[TrajectoryStep, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": "g1.0.0",
            "trajectory_id": self.trajectory_id,
            "initial_state": self.initial_state.to_dict(),
            "steps": [
                {
                    "action": step.action.to_dict(),
                    "expected_state_hash": step.expected_state_hash,
                    "receipt": {
                        "legal": step.receipt.legal,
                        "reason_codes": list(step.receipt.reason_codes),
                        "before_hash": step.receipt.before_hash,
                        "after_hash": step.receipt.after_hash,
                        "repair_magnitude": step.receipt.repair_magnitude,
                    },
                }
                for step in self.steps
            ],
        }

    def to_json(self) -> str:
        return canonical_payload_json(self.to_dict())

    def content_hash(self) -> str:
        return hashlib.sha256(self.to_json().encode()).hexdigest()

    @classmethod
    def from_json(cls, encoded: str) -> Trajectory:
        payload = json.loads(encoded)
        if payload.get("schema_version") != "g1.0.0":
            raise ValueError("unsupported trajectory schema")
        steps = []
        for item in payload["steps"]:
            receipt = item["receipt"]
            steps.append(
                TrajectoryStep(
                    AssemblyAction.from_dict(item["action"]),
                    item["expected_state_hash"],
                    ActionReceipt(
                        bool(receipt["legal"]),
                        tuple(receipt["reason_codes"]),
                        receipt["before_hash"],
                        receipt["after_hash"],
                        float(receipt["repair_magnitude"]),
                    ),
                )
            )
        return cls(
            payload["trajectory_id"],
            state_from_dict(payload["initial_state"]),
            tuple(steps),
        )

    def replay(self, projector: CrystallographicProjector) -> MaterialEmbryoState:
        state = self.initial_state
        for index, step in enumerate(self.steps):
            state, receipt = projector.apply(state, step.action)
            if not receipt.legal:
                raise ValueError(f"trajectory step {index} became illegal")
            if state.content_hash() != step.expected_state_hash:
                raise ValueError(f"trajectory step {index} hash mismatch")
        return state

