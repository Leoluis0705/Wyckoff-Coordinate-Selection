from __future__ import annotations

from dataclasses import dataclass


SUPPORTED_MOTIFS = {
    "coordination_shell",
    "tetrahedron",
    "octahedron",
    "chain",
    "layer",
    "sublattice",
}


@dataclass(frozen=True)
class MotifFactor:
    motif_id: str
    motif_type: str
    member_ids: tuple[str, ...]
    edge_ids: tuple[str, ...]
    confidence: float
    source_rule: str
    created_step: int

    def __post_init__(self) -> None:
        if self.motif_type not in SUPPORTED_MOTIFS:
            raise ValueError(f"unsupported motif type {self.motif_type}")
        if not self.member_ids or len(self.member_ids) != len(set(self.member_ids)):
            raise ValueError("motif members must be non-empty and unique")
        if not 0 <= self.confidence <= 1:
            raise ValueError("motif confidence must be in [0, 1]")

