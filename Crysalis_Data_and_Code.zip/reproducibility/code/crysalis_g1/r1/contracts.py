from __future__ import annotations

import hashlib
import json
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator, Mapping, Sequence

from crysalis_g1.data.canonical import (
    CanonicalOrbitRecord,
    CanonicalParentRecord,
    SymmetrySignature,
)
from crysalis_g1.data.structural_operators import (
    CanonicalRelationRecord,
    OperatorReplayError,
    RelationInterfaceGroup,
    RelationRegistry,
    StructuralTrajectory,
    replay_trajectory,
)
from crysalis_g1.experiments.c0_symmetry_reconstruction import RecoveredParent


@dataclass(frozen=True, slots=True)
class RelationAuditBundle:
    parent: CanonicalParentRecord
    registry: RelationRegistry
    trajectory: StructuralTrajectory


@dataclass(frozen=True, slots=True)
class R1ParentBundle:
    parent: CanonicalParentRecord
    registry: RelationRegistry
    recovered_parent: RecoveredParent
    d_orbit_trajectories: tuple[StructuralTrajectory, ...]
    relation_trajectory: StructuralTrajectory | None
    split: str


def load_r1_bundles(config: R1Config) -> tuple[R1ParentBundle, ...]:
    verify_frozen_artifacts(config)
    artifacts = config.frozen_artifacts
    splits: dict[str, str] = {}
    for payload in _iter_jsonl(artifacts["structure_ood_manifest"].path):
        material_id = str(payload["material_id"])
        if material_id in splits:
            raise ValueError(f"duplicate Structure-OOD parent: {material_id}")
        splits[material_id] = ensure_public_split(str(payload["split"]))
    if len(splits) != 7838:
        raise ValueError(f"frozen Structure-OOD parent count drifted: {len(splits)}")
    selected = set(splits)
    parents = {
        str(payload["material_id"]): _canonical_parent_from_dict(payload)
        for payload in _iter_jsonl(artifacts["canonical_parents"].path)
        if str(payload["material_id"]) in selected
    }
    registries = {
        str(payload["material_id"]): _relation_registry_from_dict(payload)
        for payload in _iter_jsonl(artifacts["canonical_relations"].path)
        if str(payload["material_id"]) in selected
    }
    recovered = {
        str(payload["material_id"]): RecoveredParent.from_dict(payload)
        for payload in _iter_jsonl(artifacts["recovered_parents"].path)
        if str(payload["material_id"]) in selected
    }
    d_orbit: dict[str, list[StructuralTrajectory]] = defaultdict(list)
    for payload, encoded in _iter_jsonl_with_source(artifacts["d_orbit_trajectories"].path):
        material_id = str(payload["parent_structure_id"])
        if material_id in selected:
            d_orbit[material_id].append(StructuralTrajectory.from_json(encoded))
    d_relation: dict[str, StructuralTrajectory] = {}
    for payload, encoded in _iter_jsonl_with_source(
        artifacts["d_relation_interface_trajectories"].path
    ):
        material_id = str(payload["parent_structure_id"])
        if material_id not in selected:
            raise ValueError(f"formal relation trajectory outside cohort: {material_id}")
        if material_id in d_relation:
            raise ValueError(f"duplicate formal relation trajectory: {material_id}")
        d_relation[material_id] = StructuralTrajectory.from_json(encoded)
    for label, values in (
        ("canonical parents", parents),
        ("canonical relation registries", registries),
        ("recovered C0 parents", recovered),
        ("D_orbit trajectories", d_orbit),
    ):
        if set(values) != selected:
            missing = sorted(selected - set(values))[:5]
            extra = sorted(set(values) - selected)[:5]
            raise ValueError(f"{label} cohort mismatch: missing={missing}, extra={extra}")
    if sum(len(items) for items in d_orbit.values()) != 31352:
        raise ValueError("frozen D_orbit trajectory count drifted")
    if len(d_relation) != 7835:
        raise ValueError("frozen D_relation_interface trajectory count drifted")
    if sum(len(item.relations) for item in registries.values()) != 129821:
        raise ValueError("frozen relation count drifted")
    if sum(len(item.interface_groups) for item in registries.values()) != 40093:
        raise ValueError("frozen relation-interface group count drifted")
    bundles = []
    for material_id in sorted(selected):
        trajectories = tuple(sorted(d_orbit[material_id], key=lambda item: item.path_index))
        if len(trajectories) != 4 or tuple(item.path_index for item in trajectories) != (
            0,
            1,
            2,
            3,
        ):
            raise ValueError(f"parent lacks four ordered D_orbit paths: {material_id}")
        registry = registries[material_id]
        relation_trajectory = d_relation.get(material_id)
        if bool(registry.interface_groups) != (relation_trajectory is not None):
            raise ValueError(f"formal relation eligibility mismatch: {material_id}")
        bundles.append(
            R1ParentBundle(
                parent=parents[material_id],
                registry=registry,
                recovered_parent=recovered[material_id],
                d_orbit_trajectories=trajectories,
                relation_trajectory=relation_trajectory,
                split=splits[material_id],
            )
        )
    return tuple(bundles)


def _iter_jsonl(path: Path) -> Iterator[dict[str, Any]]:
    for payload, _ in _iter_jsonl_with_source(path):
        yield payload


def _iter_jsonl_with_source(
    path: Path,
) -> Iterator[tuple[dict[str, Any], str]]:
    with path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            try:
                payload = json.loads(line)
            except json.JSONDecodeError as error:
                raise ValueError(f"invalid JSONL at {path}:{line_number}") from error
            if not isinstance(payload, dict):
                raise ValueError(f"JSONL row is not an object at {path}:{line_number}")
            yield payload, line


def _canonical_parent_from_dict(
    payload: Mapping[str, object],
) -> CanonicalParentRecord:
    return CanonicalParentRecord(
        material_id=str(payload["material_id"]),
        source_partition=str(payload["source_partition"]),
        source_prototype_family=str(payload["source_prototype_family"]),
        source_structure_hash=str(payload["source_structure_hash"]),
        canonical_structure_hash=str(payload["canonical_structure_hash"]),
        lattice=tuple(
            tuple(float(value) for value in row)
            for row in payload["lattice"]  # type: ignore[union-attr]
        ),
        atomic_numbers=tuple(
            int(value)
            for value in payload["atomic_numbers"]  # type: ignore[union-attr]
        ),
        fractional_coordinates=tuple(
            tuple(float(value) for value in row)
            for row in payload["fractional_coordinates"]  # type: ignore[union-attr]
        ),
        canonical_to_source_site=tuple(
            int(value)
            for value in payload["canonical_to_source_site"]  # type: ignore[union-attr]
        ),
        source_space_group=int(payload["source_space_group"]),
        space_group=int(payload["space_group"]),
        symmetry_status=str(payload["symmetry_status"]),
        observations=tuple(
            SymmetrySignature(
                symprec=float(item["symprec"]),
                space_group=int(item["space_group"]),
                equivalent_atoms=tuple(int(value) for value in item["equivalent_atoms"]),
                wyckoff_letters=tuple(str(value) for value in item["wyckoff_letters"]),
            )
            for item in payload["observations"]  # type: ignore[union-attr]
        ),
        orbits=tuple(
            CanonicalOrbitRecord(
                orbit_id=str(item["orbit_id"]),
                canonical_site_indices=tuple(
                    int(value) for value in item["canonical_site_indices"]
                ),
                source_site_indices=tuple(int(value) for value in item["source_site_indices"]),
                atomic_number=int(item["atomic_number"]),
                multiplicity=int(item["multiplicity"]),
                wyckoff_letter=str(item["wyckoff_letter"]),
            )
            for item in payload["orbits"]  # type: ignore[union-attr]
        ),
        reduced_formula_key=tuple(
            (int(item[0]), int(item[1]))
            for item in payload["reduced_formula_key"]  # type: ignore[union-attr]
        ),
    )


def _relation_registry_from_dict(
    payload: Mapping[str, object],
) -> RelationRegistry:
    return RelationRegistry(
        material_id=str(payload["material_id"]),
        canonical_structure_hash=str(payload["canonical_structure_hash"]),
        relations=tuple(
            CanonicalRelationRecord(
                relation_id=str(item["relation_id"]),
                source_site_index=int(item["source_site_index"]),
                target_site_index=int(item["target_site_index"]),
                source_orbit_id=str(item["source_orbit_id"]),
                target_orbit_id=str(item["target_orbit_id"]),
                image=tuple(int(value) for value in item["image"]),
                distance=float(item["distance"]),
            )
            for item in payload["relations"]  # type: ignore[union-attr]
        ),
        interface_groups=tuple(
            RelationInterfaceGroup(
                group_id=str(item["group_id"]),
                source_orbit_id=str(item["source_orbit_id"]),
                target_orbit_id=str(item["target_orbit_id"]),
                relation_ids=tuple(str(value) for value in item["relation_ids"]),
            )
            for item in payload["interface_groups"]  # type: ignore[union-attr]
        ),
    )


@dataclass(frozen=True, slots=True)
class FrozenArtifact:
    path: Path
    sha256: str


@dataclass(frozen=True, slots=True)
class R1Config:
    config_path: Path
    raw: Mapping[str, Any]
    root_seed: int
    output_root: Path
    device: str
    top_space_groups: tuple[int, ...]
    frozen_artifacts: Mapping[str, FrozenArtifact]
    attempt_count: int
    maximum_orbits: int
    maximum_sites: int
    minimum_distance_angstrom: float
    maximum_placement_candidates: int
    orbit_proposal_namespace: str
    placement_pool_namespace: str

    @classmethod
    def from_json(cls, path: str | Path) -> R1Config:
        source = Path(path).resolve()
        payload = json.loads(source.read_text(encoding="utf-8"))
        if payload.get("schema_version") != ("g1-crysalis-r1-relation-restoration.1.0.0"):
            raise ValueError("unsupported R1 configuration schema")
        if int(payload.get("root_seed", -1)) != 20260823:
            raise ValueError("R1 root seed must remain 20260823")
        if payload.get("device") not in {"cpu", "cuda"}:
            raise ValueError("R1 device must be cpu or cuda")
        top_space_groups = tuple(int(value) for value in payload["top_space_groups"])
        if top_space_groups != (225, 139, 12, 63, 189, 194, 123, 164):
            raise ValueError("R1 top-space-group cohort drifted")
        raw_artifacts = payload.get("frozen_artifacts")
        if not isinstance(raw_artifacts, dict) or not raw_artifacts:
            raise ValueError("R1 frozen artifacts must be a non-empty mapping")
        artifacts: dict[str, FrozenArtifact] = {}
        for label, declaration in raw_artifacts.items():
            if not isinstance(declaration, dict) or set(declaration) != {
                "path",
                "sha256",
            }:
                raise ValueError(f"invalid R1 frozen artifact declaration: {label}")
            artifact_path = Path(str(declaration["path"]))
            if not artifact_path.is_absolute():
                artifact_path = (source.parent / artifact_path).resolve()
            digest = str(declaration["sha256"]).lower()
            if len(digest) != 64 or any(value not in "0123456789abcdef" for value in digest):
                raise ValueError(f"invalid R1 frozen artifact SHA-256: {label}")
            artifacts[str(label)] = FrozenArtifact(artifact_path, digest)
        required_artifacts = {
            "phase2a_manifest",
            "canonical_parents",
            "canonical_relations",
            "d_orbit_trajectories",
            "d_relation_interface_trajectories",
            "structure_ood_manifest",
            "recovered_parents",
            "c0_manifest",
            "c0_checkpoint",
            "condition_manifest",
            "chgnet_weights",
        }
        if set(artifacts) != required_artifacts:
            raise ValueError("R1 frozen artifact set drifted")
        authorization = payload.get("authorization")
        if not isinstance(authorization, dict):
            raise ValueError("R1 authorization block is missing")
        required_local = {
            "local_implementation",
            "local_training",
            "local_generation",
            "local_chgnet",
        }
        if any(authorization.get(label) is not True for label in required_local):
            raise ValueError("required local R1 authorization is disabled")
        forbidden = {
            "server",
            "dft",
            "physics",
            "phase2a_rebuild",
            "orbit_policy_training",
            "graph_viability",
            "cssd_extension",
            "motif",
            "sublattice",
            "distortion",
            "three_training_seeds",
        }
        enabled = sorted(label for label in forbidden if authorization.get(label))
        if enabled:
            raise ValueError(f"forbidden R1 authorization enabled: {enabled}")
        model = payload["model"]
        if any(bool(model[label]) for label in ("kan", "physics", "e3nn_new_model")):
            raise ValueError("R1 first-stage model extensions must remain disabled")
        generation = payload["generation"]
        if (
            int(generation["attempt_count"]) != 300
            or int(generation["maximum_placement_candidates"]) != 16
            or generation["orbit_proposal_namespace"] != "r1:uniform_orbit_proposal"
            or generation["retry"] is not False
            or generation["refill"] is not False
            or tuple(generation["arms"])
            != (
                "U0_FROZEN",
                "FIRST_LEGAL_SEARCH",
                "RELATION_RESTORATION",
            )
        ):
            raise ValueError("R1 generation contract drifted")
        formal_training = payload["formal_training"]
        if (
            int(payload["preflight"]["updates"]) != 500
            or int(formal_training["minimum_updates"]) != 3000
            or int(formal_training["maximum_updates"]) != 8000
            or int(formal_training["validation_interval"]) != 250
            or int(formal_training["early_stopping_patience"]) != 5
        ):
            raise ValueError("R1 training budget drifted")
        if (
            int(payload["statistics"]["paired_bootstrap_resamples"]) != 10_000
            or payload["statistics"]["delta_orientation"] != "RELATION_MINUS_COMPARATOR"
        ):
            raise ValueError("R1 statistics contract drifted")
        output_root = Path(str(payload["output_root"]))
        if not output_root.is_absolute():
            output_root = (source.parent / output_root).resolve()
        return cls(
            config_path=source,
            raw=payload,
            root_seed=20260823,
            output_root=output_root,
            device=str(payload["device"]),
            top_space_groups=top_space_groups,
            frozen_artifacts=artifacts,
            attempt_count=300,
            maximum_orbits=int(generation["maximum_orbits"]),
            maximum_sites=int(generation["maximum_sites"]),
            minimum_distance_angstrom=float(generation["minimum_distance_angstrom"]),
            maximum_placement_candidates=16,
            orbit_proposal_namespace=str(generation["orbit_proposal_namespace"]),
            placement_pool_namespace=str(generation["placement_pool_namespace"]),
        )


def verify_frozen_artifacts(config: R1Config) -> set[str]:
    for label, artifact in config.frozen_artifacts.items():
        verify_sha256(artifact.path, artifact.sha256, label=label)
    return set(config.frozen_artifacts)


def verify_sha256(path: str | Path, expected: str, *, label: str) -> None:
    source = Path(path)
    digest = hashlib.sha256()
    with source.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    observed = digest.hexdigest()
    if observed != expected.lower():
        raise ValueError(
            f"frozen input hash mismatch for {label}: {observed} != {expected.lower()}"
        )


def ensure_public_split(split: str) -> str:
    if split not in {"train_fit", "validation"}:
        raise ValueError(f"invalid public Structure-OOD split: {split!r}")
    return split


def audit_relation_operator(
    bundles: Sequence[RelationAuditBundle],
) -> dict[str, Any]:
    if not bundles:
        raise ValueError("formal relation audit requires at least one bundle")
    parent_ids: set[str] = set()
    action_count = 0
    relation_count = 0
    group_count = 0
    for bundle in bundles:
        parent_id = bundle.parent.material_id
        if parent_id in parent_ids:
            raise ValueError(f"duplicate formal relation parent: {parent_id}")
        parent_ids.add(parent_id)
        trajectory = bundle.trajectory
        if trajectory.operator != "D_relation_interface":
            raise ValueError(f"unexpected formal relation operator: {trajectory.operator}")
        group_ids = {group.group_id for group in bundle.registry.interface_groups}
        targets = tuple(action.target_id for action in trajectory.forward_actions)
        if len(targets) != len(group_ids) or set(targets) != group_ids:
            raise ValueError(f"formal relation groups are not exact for {parent_id}")
        try:
            result = replay_trajectory(
                bundle.parent,
                bundle.registry,
                trajectory,
            )
        except (OperatorReplayError, ValueError) as error:
            raise ValueError(
                f"formal D_relation_interface replay failure for {parent_id}: {error}"
            ) from error
        if not result.passed:
            raise ValueError(f"formal D_relation_interface replay failure for {parent_id}")
        action_count += len(trajectory.forward_actions)
        relation_count += len(bundle.registry.relations)
        group_count += len(bundle.registry.interface_groups)
    return {
        "trajectory_count": len(bundles),
        "unique_parent_count": len(parent_ids),
        "formal_replay_pass_count": len(bundles),
        "relation_count": relation_count,
        "relation_interface_group_count": group_count,
        "relation_interface_action_count": action_count,
        "formal_contract": {
            "state_before": {
                "serialized": False,
                "replay_source": "materialized active orbit/relation IDs before action",
            },
            "state_after": {
                "serialized": False,
                "serialized_proxy": "forward_state_hashes/inverse_state_hashes",
            },
            "removed_orbit": {
                "serialized": False,
                "operator_target": "relation-interface group ID",
            },
            "affected_relation_ids": {
                "serialized": False,
                "resolved_from": "relation registry interface_groups[].relation_ids",
            },
            "relation_members": {
                "fields": [
                    "relation_id",
                    "source_site_index",
                    "target_site_index",
                    "source_orbit_id",
                    "target_orbit_id",
                    "image",
                    "distance",
                ]
            },
            "relation_feature_fields": {
                "discrete_relation_type": "implicit constant stable_neighbor",
                "periodic_distance": "distance",
                "displacement_or_invariant_distance_descriptor": "image and distance",
                "coordination_or_neighbor_descriptor": None,
                "species_pair_information": None,
                "wyckoff_or_orbit_pair_information": (
                    "orbit IDs only; Wyckoff requires canonical-orbit join"
                ),
                "geometry_dependent_values": ["image", "distance"],
            },
            "inverse_action": {
                "operator": "D_relation_interface",
                "mode": "RESTORE",
                "target": "relation-interface group ID",
            },
            "serialization_contract": {
                "trajectory_schema": "g1-phase2a-operators.1.0.0",
                "registry_storage": "canonical_cache/canonical_relations.jsonl",
            },
            "round_trip_contract": (
                "forward and inverse state hashes replay and final hash equals initial hash"
            ),
        },
    }
