"""Crysalis-R1 relation-restoration experiment."""
