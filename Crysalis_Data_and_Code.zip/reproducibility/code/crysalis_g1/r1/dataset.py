from __future__ import annotations

import hashlib
import json
import math
from collections import Counter
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

import numpy as np
import torch
from pymatgen.core import Lattice
from pymatgen.util.coord import pbc_shortest_vectors

from crysalis_g1.r1.contracts import R1ParentBundle, ensure_public_split
from crysalis_g1.r1.descriptors import (
    CONTINUOUS_FIELDS,
    ExplicitOrbitGeometry,
    PersistentRelationState,
    RelationInterfaceDescriptor,
    descriptor_from_members,
)


def _hash_payload(payload: object) -> str:
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class RelationPairExample:
    parent_id: str
    split: str
    event_key: str
    pair_key: str
    candidate_orbit_id: str
    existing_orbit_id: str
    target_space_group: int
    candidate_species: int
    candidate_wyckoff_letter: str
    candidate_multiplicity: int
    candidate_free_parameter_count: int
    existing_species: int
    existing_wyckoff_letter: str
    existing_multiplicity: int
    existing_free_parameter_count: int
    existing_geometry: tuple[float, float, float, float, float]
    composition: tuple[tuple[int, int], ...]
    remaining_composition: tuple[tuple[int, int], ...]
    lattice_invariants: tuple[float, float, float, float, float, float, float]
    assembly_progress: float
    pooled_relation_state: tuple[float, ...]
    target_group_id: str | None
    target: RelationInterfaceDescriptor

    def model_features(self) -> Mapping[str, Any]:
        return {
            "target_space_group": self.target_space_group,
            "candidate_species": self.candidate_species,
            "candidate_wyckoff_letter": self.candidate_wyckoff_letter,
            "candidate_multiplicity": self.candidate_multiplicity,
            "candidate_free_parameter_count": self.candidate_free_parameter_count,
            "existing_species": self.existing_species,
            "existing_wyckoff_letter": self.existing_wyckoff_letter,
            "existing_multiplicity": self.existing_multiplicity,
            "existing_free_parameter_count": self.existing_free_parameter_count,
            "existing_geometry": self.existing_geometry,
            "composition": self.composition,
            "remaining_composition": self.remaining_composition,
            "lattice_invariants": self.lattice_invariants,
            "assembly_progress": self.assembly_progress,
            "pooled_relation_state": self.pooled_relation_state,
        }


@dataclass(frozen=True, slots=True)
class RelationRestorationCorpus:
    train_examples: tuple[RelationPairExample, ...]
    validation_examples: tuple[RelationPairExample, ...]
    report: Mapping[str, Any]

    @classmethod
    def build(
        cls,
        bundles: Sequence[R1ParentBundle],
    ) -> RelationRestorationCorpus:
        if not bundles:
            raise ValueError("R1 relation corpus requires public parent bundles")
        train: list[RelationPairExample] = []
        validation: list[RelationPairExample] = []
        event_keys: set[str] = set()
        positive_group_ids: set[str] = set()
        formal_group_ids: set[str] = set()
        intra_orbit_group_ids: set[str] = set()
        raw_transition_count = 0
        empty_retained_event_count = 0
        event_split: Counter[str] = Counter()
        for bundle in bundles:
            split = ensure_public_split(bundle.split)
            if bundle.relation_trajectory is None:
                continue
            formal_group_ids.update(group.group_id for group in bundle.registry.interface_groups)
            intra_orbit_group_ids.update(
                group.group_id
                for group in bundle.registry.interface_groups
                if group.source_orbit_id == group.target_orbit_id
            )
            destination = train if split == "train_fit" else validation
            orbit_states = {
                orbit.orbit_instance_id: orbit for orbit in bundle.recovered_parent.orbits
            }
            canonical_orbits = {orbit.orbit_id: orbit for orbit in bundle.parent.orbits}
            if set(orbit_states) != set(canonical_orbits):
                raise ValueError(
                    f"recovered/canonical orbit identity mismatch: {bundle.parent.material_id}"
                )
            geometries = _recovered_orbit_geometries(bundle)
            composition_counter: Counter[int] = Counter()
            for orbit in orbit_states.values():
                composition_counter[orbit.species] += orbit.multiplicity
            composition = tuple(sorted(composition_counter.items()))
            total_sites = sum(composition_counter.values())
            lattice_matrix = bundle.recovered_parent.lattice.primitive_matrix
            invariants = lattice_invariants(lattice_matrix, total_sites=total_sites)
            existing_geometry_by_id = {
                orbit_id: existing_orbit_geometry(
                    lattice_matrix,
                    geometry.fractional_coordinates,
                )
                for orbit_id, geometry in geometries.items()
            }
            persistent_by_retained: dict[tuple[str, ...], PersistentRelationState] = {}
            relation_by_id = {
                relation.relation_id: relation for relation in bundle.registry.relations
            }
            group_by_pair = {
                frozenset((group.source_orbit_id, group.target_orbit_id)): group
                for group in bundle.registry.interface_groups
            }
            if len(group_by_pair) != len(bundle.registry.interface_groups):
                raise ValueError("multiple formal relation groups share one orbit pair")
            for trajectory in bundle.d_orbit_trajectories:
                active = set(orbit_states)
                for action in trajectory.forward_actions:
                    raw_transition_count += 1
                    if action.operator != "D_orbit" or action.mode != "REMOVE":
                        raise ValueError("R1 dataset accepts only formal D_orbit removals")
                    candidate_id = action.target_id
                    if candidate_id not in active:
                        raise ValueError("formal D_orbit transition removes an inactive orbit")
                    active.remove(candidate_id)
                    retained = tuple(sorted(active))
                    event_key = _hash_payload(
                        {
                            "parent_id": bundle.parent.material_id,
                            "candidate_orbit_id": candidate_id,
                            "retained_orbit_ids": retained,
                        }
                    )
                    if event_key in event_keys:
                        continue
                    event_keys.add(event_key)
                    event_split[split] += 1
                    if not retained:
                        empty_retained_event_count += 1
                        continue
                    persistent = persistent_by_retained.get(retained)
                    if persistent is None:
                        partial_geometries = tuple(geometries[orbit_id] for orbit_id in retained)
                        persistent = PersistentRelationState.from_orbit_geometries(
                            lattice=lattice_matrix,
                            orbits=partial_geometries,
                        )
                        persistent_by_retained[retained] = persistent
                    active_counts: Counter[int] = Counter()
                    for orbit_id in retained:
                        orbit = orbit_states[orbit_id]
                        active_counts[orbit.species] += orbit.multiplicity
                    remaining = composition_counter - active_counts
                    remaining_composition = tuple(sorted(remaining.items()))
                    candidate = orbit_states[candidate_id]
                    for existing_id in retained:
                        existing = orbit_states[existing_id]
                        group = group_by_pair.get(frozenset((candidate_id, existing_id)))
                        distances: tuple[float, ...] = ()
                        group_id = None
                        if group is not None:
                            group_id = group.group_id
                            positive_group_ids.add(group_id)
                            distances = tuple(
                                float(relation_by_id[relation_id].distance)
                                for relation_id in group.relation_ids
                            )
                        target = descriptor_from_members(
                            distances=distances,
                            candidate_multiplicity=candidate.multiplicity,
                            existing_multiplicity=existing.multiplicity,
                        )
                        pair_key = _hash_payload(
                            {
                                "event_key": event_key,
                                "existing_orbit_id": existing_id,
                            }
                        )
                        destination.append(
                            RelationPairExample(
                                parent_id=bundle.parent.material_id,
                                split=split,
                                event_key=event_key,
                                pair_key=pair_key,
                                candidate_orbit_id=candidate_id,
                                existing_orbit_id=existing_id,
                                target_space_group=bundle.recovered_parent.target_space_group,
                                candidate_species=candidate.species,
                                candidate_wyckoff_letter=candidate.wyckoff_letter,
                                candidate_multiplicity=candidate.multiplicity,
                                candidate_free_parameter_count=len(candidate.free_parameters),
                                existing_species=existing.species,
                                existing_wyckoff_letter=existing.wyckoff_letter,
                                existing_multiplicity=existing.multiplicity,
                                existing_free_parameter_count=len(existing.free_parameters),
                                existing_geometry=existing_geometry_by_id[existing_id],
                                composition=composition,
                                remaining_composition=remaining_composition,
                                lattice_invariants=invariants,
                                assembly_progress=sum(active_counts.values()) / total_sites,
                                pooled_relation_state=persistent.pooled,
                                target_group_id=group_id,
                                target=target,
                            )
                        )
        examples = (*train, *validation)
        if not examples:
            raise ValueError("R1 relation corpus contains no pairwise examples")
        if len({example.pair_key for example in examples}) != len(examples):
            raise ValueError("R1 pair deduplication failed")
        train_parents = {example.parent_id for example in train}
        validation_parents = {example.parent_id for example in validation}
        if train_parents & validation_parents:
            raise ValueError("R1 Structure-OOD parent leakage detected")
        missing_cross_orbit_groups = formal_group_ids - intra_orbit_group_ids - positive_group_ids
        if missing_cross_orbit_groups:
            raise ValueError(
                "formal cross-orbit relation groups lack pair supervision: "
                f"{len(missing_cross_orbit_groups)}"
            )
        positive = sum(int(example.target.presence) for example in examples)
        pair_count = len(examples)
        report = {
            "schema_version": "g1-r1-relation-dataset-report.1.0.0",
            "sample_count": len(event_keys) - empty_retained_event_count,
            "unique_deconstruction_event_count": len(event_keys),
            "raw_d_orbit_transition_count": raw_transition_count,
            "deduplicated_transition_count": raw_transition_count - len(event_keys),
            "empty_retained_event_count": empty_retained_event_count,
            "interface_group_count": len(formal_group_ids),
            "supervised_inter_orbit_interface_group_count": len(positive_group_ids),
            "excluded_intra_orbit_interface_group_count": len(intra_orbit_group_ids),
            "pair_count": pair_count,
            "train_fit_pair_count": len(train),
            "validation_pair_count": len(validation),
            "descriptor_coverage": positive / pair_count,
            "missing_value_rate": (pair_count - positive) / pair_count,
            "space_group_distribution": dict(
                sorted(Counter(str(example.target_space_group) for example in examples).items())
            ),
            "orbit_multiplicity_distribution": dict(
                sorted(Counter(str(example.candidate_multiplicity) for example in examples).items())
            ),
            "relation_type_distribution": {
                "stable_neighbor": positive,
                "absent": pair_count - positive,
            },
            "event_split_distribution": dict(sorted(event_split.items())),
            "next_action_label_present": False,
            "removal_order_loss_present": False,
            "sealed_or_blind_data_accessed": False,
        }
        return cls(tuple(train), tuple(validation), report)


@dataclass(frozen=True, slots=True)
class RelationNormalizer:
    mean: tuple[float, ...]
    std: tuple[float, ...]

    @classmethod
    def fit(cls, examples: Sequence[RelationPairExample]) -> RelationNormalizer:
        if not examples:
            raise ValueError("relation normalization requires train_fit examples")
        if any(example.split != "train_fit" for example in examples):
            raise ValueError("relation normalization may use train_fit only")
        available = np.asarray(
            [
                example.target.continuous_values
                for example in examples
                if example.target.continuous_availability == 1.0
            ],
            dtype=float,
        )
        if available.ndim != 2 or available.shape[1] != len(CONTINUOUS_FIELDS):
            raise ValueError("train_fit contains no available relation descriptors")
        mean = available.mean(axis=0)
        std = np.maximum(available.std(axis=0), 1e-6)
        if not np.isfinite(mean).all() or not np.isfinite(std).all():
            raise FloatingPointError("non-finite relation normalization")
        return cls(tuple(float(value) for value in mean), tuple(float(value) for value in std))

    def normalize(self, descriptor: RelationInterfaceDescriptor) -> tuple[float, ...]:
        if not descriptor.continuous_availability:
            return (0.0,) * len(CONTINUOUS_FIELDS)
        values = (
            np.asarray(descriptor.continuous_values, dtype=float)
            - np.asarray(self.mean, dtype=float)
        ) / np.asarray(self.std, dtype=float)
        return tuple(float(value) for value in values)


@dataclass(frozen=True, slots=True)
class RelationBatch:
    target_space_group: torch.Tensor
    candidate_species: torch.Tensor
    candidate_wyckoff: torch.Tensor
    existing_species: torch.Tensor
    existing_wyckoff: torch.Tensor
    numeric_features: torch.Tensor
    presence_target: torch.Tensor
    continuous_target: torch.Tensor
    continuous_mask: torch.Tensor
    parent_ids: tuple[str, ...]
    pair_keys: tuple[str, ...]

    def to(self, device: str | torch.device) -> RelationBatch:
        return RelationBatch(
            target_space_group=self.target_space_group.to(device),
            candidate_species=self.candidate_species.to(device),
            candidate_wyckoff=self.candidate_wyckoff.to(device),
            existing_species=self.existing_species.to(device),
            existing_wyckoff=self.existing_wyckoff.to(device),
            numeric_features=self.numeric_features.to(device),
            presence_target=self.presence_target.to(device),
            continuous_target=self.continuous_target.to(device),
            continuous_mask=self.continuous_mask.to(device),
            parent_ids=self.parent_ids,
            pair_keys=self.pair_keys,
        )


def collate_relation_examples(
    examples: Sequence[RelationPairExample],
    *,
    normalizer: RelationNormalizer,
) -> RelationBatch:
    if not examples:
        raise ValueError("cannot collate an empty relation batch")
    numeric = []
    continuous = []
    for example in examples:
        composition = _composition_vector(example.composition)
        remaining = _composition_vector(example.remaining_composition)
        numeric.append(
            (
                example.candidate_multiplicity / 20.0,
                example.candidate_free_parameter_count / 3.0,
                example.existing_multiplicity / 20.0,
                example.existing_free_parameter_count / 3.0,
                *example.existing_geometry,
                *composition,
                *remaining,
                *example.lattice_invariants,
                example.assembly_progress,
                *example.pooled_relation_state,
            )
        )
        continuous.append(normalizer.normalize(example.target))
    batch = RelationBatch(
        target_space_group=torch.tensor(
            [example.target_space_group for example in examples], dtype=torch.long
        ),
        candidate_species=torch.tensor(
            [example.candidate_species for example in examples], dtype=torch.long
        ),
        candidate_wyckoff=torch.tensor(
            [_wyckoff_index(example.candidate_wyckoff_letter) for example in examples],
            dtype=torch.long,
        ),
        existing_species=torch.tensor(
            [example.existing_species for example in examples], dtype=torch.long
        ),
        existing_wyckoff=torch.tensor(
            [_wyckoff_index(example.existing_wyckoff_letter) for example in examples],
            dtype=torch.long,
        ),
        numeric_features=torch.tensor(numeric, dtype=torch.float32),
        presence_target=torch.tensor(
            [[example.target.presence] for example in examples], dtype=torch.float32
        ),
        continuous_target=torch.tensor(continuous, dtype=torch.float32),
        continuous_mask=torch.tensor(
            [[example.target.continuous_availability] for example in examples],
            dtype=torch.float32,
        ),
        parent_ids=tuple(example.parent_id for example in examples),
        pair_keys=tuple(example.pair_key for example in examples),
    )
    for tensor in (
        batch.numeric_features,
        batch.presence_target,
        batch.continuous_target,
        batch.continuous_mask,
    ):
        if not torch.isfinite(tensor).all():
            raise FloatingPointError("non-finite relation batch")
    return batch


def _composition_vector(composition: Sequence[tuple[int, int]]) -> tuple[float, ...]:
    vector = np.zeros(118, dtype=float)
    total = sum(int(count) for _, count in composition)
    if total <= 0:
        return tuple(float(value) for value in vector)
    for atomic_number, count in composition:
        if not 1 <= int(atomic_number) <= 118 or int(count) <= 0:
            raise ValueError("composition contains an invalid entry")
        vector[int(atomic_number) - 1] = int(count) / total
    return tuple(float(value) for value in vector)


def _wyckoff_index(letter: str) -> int:
    if len(letter) != 1 or not "a" <= letter <= "z":
        raise ValueError(f"unsupported Wyckoff letter: {letter!r}")
    return ord(letter) - ord("a")


def _recovered_orbit_geometries(
    bundle: R1ParentBundle,
) -> dict[str, ExplicitOrbitGeometry]:
    coordinates = bundle.recovered_parent.reconstructed_fractional_coordinates
    result = {}
    start = 0
    for orbit in bundle.recovered_parent.orbits:
        stop = start + orbit.multiplicity
        fractional = tuple(tuple(float(value) for value in row) for row in coordinates[start:stop])
        if len(fractional) != orbit.multiplicity:
            raise ValueError("recovered orbit coordinate slice is incomplete")
        result[orbit.orbit_instance_id] = ExplicitOrbitGeometry(
            orbit_instance_id=orbit.orbit_instance_id,
            species=orbit.species,
            wyckoff_letter=orbit.wyckoff_letter,
            multiplicity=orbit.multiplicity,
            free_parameter_count=len(orbit.free_parameters),
            fractional_coordinates=fractional,
        )
        start = stop
    if start != len(coordinates):
        raise ValueError("recovered parent has trailing coordinates")
    return result


def existing_orbit_geometry(
    lattice: Sequence[Sequence[float]],
    fractional_coordinates: Sequence[Sequence[float]],
) -> tuple[float, float, float, float, float]:
    coordinates = np.asarray(fractional_coordinates, dtype=float)
    if len(coordinates) <= 1:
        return (0.0, 0.0, 0.0, 0.0, 0.0)
    _, squared = pbc_shortest_vectors(
        Lattice(np.asarray(lattice, dtype=float)),
        coordinates,
        coordinates,
        return_d2=True,
    )
    values = np.sqrt(np.maximum(0.0, np.asarray(squared, dtype=float)))[
        np.triu_indices(len(coordinates), 1)
    ]
    return (
        float(values.min()),
        float(values.mean()),
        float(values.std()),
        float(values.max()),
        1.0,
    )


def lattice_invariants(
    lattice: Sequence[Sequence[float]],
    *,
    total_sites: int,
) -> tuple[float, float, float, float, float, float, float]:
    matrix = np.asarray(lattice, dtype=float)
    if matrix.shape != (3, 3) or not np.isfinite(matrix).all() or total_sites <= 0:
        raise ValueError("lattice invariants require a finite lattice and sites")
    lengths = np.linalg.norm(matrix, axis=1)
    volume = abs(float(np.linalg.det(matrix)))
    if np.any(lengths <= 0) or volume <= 0:
        raise ValueError("lattice invariants require positive geometry")
    cosines = (
        float(np.dot(matrix[1], matrix[2]) / (lengths[1] * lengths[2])),
        float(np.dot(matrix[0], matrix[2]) / (lengths[0] * lengths[2])),
        float(np.dot(matrix[0], matrix[1]) / (lengths[0] * lengths[1])),
    )
    values = (
        math.log(float(lengths[0])),
        math.log(float(lengths[1])),
        math.log(float(lengths[2])),
        *cosines,
        math.log(volume / total_sites),
    )
    return tuple(float(round(value, 12)) for value in values)  # type: ignore[return-value]
