from __future__ import annotations

import hashlib
import json
import warnings
from dataclasses import dataclass
from functools import lru_cache
from typing import Any, Iterable, Sequence

import numpy as np
from pymatgen.core import Element, Lattice
from pymatgen.util.coord import pbc_shortest_vectors

from crysalis_g1.symmetry.assembly import C0SymmetryProjector, SymmetryAssemblyState


CONTINUOUS_FIELDS = (
    "relation_fraction",
    "distance_min",
    "distance_mean",
    "distance_std",
    "distance_max",
    "candidate_coordination",
    "existing_coordination",
)
ALPHA_VALUES = (1.25, 1.30, 1.35)
MAXIMUM_DISTANCE_ANGSTROM = 5.0
RADIUS_FALLBACK_ANGSTROM = 1.0


def _canonical(value: float) -> float:
    return float(round(float(value), 12))


@dataclass(frozen=True, slots=True)
class RelationInterfaceDescriptor:
    presence: float
    relation_count: int
    pair_count: int
    relation_fraction: float
    distance_min: float
    distance_mean: float
    distance_std: float
    distance_max: float
    candidate_coordination: float
    existing_coordination: float
    continuous_availability: float

    @property
    def continuous_values(self) -> tuple[float, ...]:
        return tuple(float(getattr(self, field)) for field in CONTINUOUS_FIELDS)


@dataclass(frozen=True, slots=True)
class PersistentPairRecord:
    candidate_orbit_id: str
    existing_orbit_id: str
    descriptor: RelationInterfaceDescriptor
    confidence: float
    available: bool


@dataclass(frozen=True, slots=True)
class ExplicitOrbitGeometry:
    orbit_instance_id: str
    species: int
    wyckoff_letter: str
    multiplicity: int
    free_parameter_count: int
    fractional_coordinates: tuple[tuple[float, float, float], ...]


@dataclass(frozen=True, slots=True)
class PersistentRelationState:
    present_orbit_ids: tuple[str, ...]
    orbit_metadata: tuple[dict[str, Any], ...]
    pairwise_relation_records: tuple[PersistentPairRecord, ...]
    pooled: tuple[float, ...]

    @classmethod
    def from_orbit_geometries(
        cls,
        *,
        lattice: Sequence[Sequence[float]],
        orbits: Sequence[ExplicitOrbitGeometry],
    ) -> PersistentRelationState:
        if not orbits:
            return cls((), (), (), (0.0,) * 8)
        by_id = {orbit.orbit_instance_id: orbit for orbit in orbits}
        if len(by_id) != len(orbits):
            raise ValueError("persistent relation orbit IDs must be unique")
        ordered_ids = tuple(sorted(by_id))
        metadata = tuple(
            {
                "orbit_instance_id": orbit_id,
                "species": int(by_id[orbit_id].species),
                "wyckoff_letter": str(by_id[orbit_id].wyckoff_letter),
                "multiplicity": int(by_id[orbit_id].multiplicity),
                "free_parameter_count": int(by_id[orbit_id].free_parameter_count),
            }
            for orbit_id in ordered_ids
        )
        records = []
        for left_index, left_id in enumerate(ordered_ids):
            left = by_id[left_id]
            if len(left.fractional_coordinates) != left.multiplicity:
                raise ValueError("persistent orbit coordinates do not match multiplicity")
            for right_id in ordered_ids[left_index + 1 :]:
                right = by_id[right_id]
                if len(right.fractional_coordinates) != right.multiplicity:
                    raise ValueError("persistent orbit coordinates do not match multiplicity")
                descriptor = descriptor_from_orbit_pair(
                    lattice=lattice,
                    candidate_species=left.species,
                    candidate_fractional=left.fractional_coordinates,
                    existing_species=right.species,
                    existing_fractional=right.fractional_coordinates,
                )
                records.append(
                    PersistentPairRecord(
                        candidate_orbit_id=left_id,
                        existing_orbit_id=right_id,
                        descriptor=descriptor,
                        confidence=1.0,
                        available=bool(descriptor.presence),
                    )
                )
        pair_records = tuple(records)
        return cls(ordered_ids, metadata, pair_records, _pool_state(ordered_ids, pair_records))

    @classmethod
    def from_assembly_state(
        cls,
        state: SymmetryAssemblyState,
        projector: C0SymmetryProjector,
    ) -> PersistentRelationState:
        if not state.orbits:
            return cls((), (), (), (0.0,) * 8)
        receipt = projector.project(state)
        if not receipt.accepted:
            raise ValueError(
                "cannot construct PersistentRelationState from rejected assembly: "
                + ",".join(receipt.reason_codes)
            )
        coordinates = np.asarray(receipt.fractional_coordinates, dtype=float)
        geometries = []
        start = 0
        for orbit in state.orbits:
            stop = start + orbit.multiplicity
            geometries.append(
                ExplicitOrbitGeometry(
                    orbit_instance_id=orbit.orbit_instance_id,
                    species=orbit.species,
                    wyckoff_letter=orbit.wyckoff_letter,
                    multiplicity=orbit.multiplicity,
                    free_parameter_count=len(orbit.free_parameters),
                    fractional_coordinates=tuple(
                        tuple(float(value) for value in row) for row in coordinates[start:stop]
                    ),
                )
            )
            start = stop
        if start != len(coordinates):
            raise ValueError("expanded coordinates do not match current orbit multiplicities")
        return cls.from_orbit_geometries(
            lattice=receipt.lattice,
            orbits=tuple(geometries),
        )


def _pool_state(
    ordered_ids: Sequence[str],
    pair_records: Sequence[PersistentPairRecord],
) -> tuple[float, ...]:
    present = [record.descriptor for record in pair_records if record.available]
    pair_count = len(pair_records)
    return (
        _canonical(len(ordered_ids) / 20.0),
        _canonical(pair_count / 190.0),
        _canonical(len(present) / pair_count) if pair_count else 0.0,
        _canonical(sum(record.descriptor.relation_fraction for record in pair_records) / pair_count)
        if pair_count
        else 0.0,
        _canonical(sum(item.distance_min for item in present) / len(present)) if present else 0.0,
        _canonical(sum(item.distance_mean for item in present) / len(present)) if present else 0.0,
        _canonical(sum(item.distance_std for item in present) / len(present)) if present else 0.0,
        _canonical(
            sum(
                (item.candidate_coordination + item.existing_coordination) / 2.0 for item in present
            )
            / len(present)
        )
        if present
        else 0.0,
    )


def descriptor_from_members(
    *,
    distances: Iterable[float],
    candidate_multiplicity: int,
    existing_multiplicity: int,
) -> RelationInterfaceDescriptor:
    if candidate_multiplicity <= 0 or existing_multiplicity <= 0:
        raise ValueError("relation endpoint multiplicities must be positive")
    values = np.asarray(tuple(float(value) for value in distances), dtype=float)
    if values.size and (not np.isfinite(values).all() or np.any(values <= 0)):
        raise ValueError("relation distances must be finite and positive")
    relation_count = int(values.size)
    pair_count = int(candidate_multiplicity * existing_multiplicity)
    if relation_count > pair_count:
        raise ValueError("relation member count exceeds the endpoint pair count")
    if relation_count == 0:
        return RelationInterfaceDescriptor(
            presence=0.0,
            relation_count=0,
            pair_count=pair_count,
            relation_fraction=0.0,
            distance_min=0.0,
            distance_mean=0.0,
            distance_std=0.0,
            distance_max=0.0,
            candidate_coordination=0.0,
            existing_coordination=0.0,
            continuous_availability=0.0,
        )
    return RelationInterfaceDescriptor(
        presence=1.0,
        relation_count=relation_count,
        pair_count=pair_count,
        relation_fraction=_canonical(relation_count / pair_count),
        distance_min=_canonical(values.min()),
        distance_mean=_canonical(values.mean()),
        distance_std=_canonical(values.std()),
        distance_max=_canonical(values.max()),
        candidate_coordination=_canonical(relation_count / candidate_multiplicity),
        existing_coordination=_canonical(relation_count / existing_multiplicity),
        continuous_availability=1.0,
    )


@lru_cache(maxsize=256)
def _atomic_radius(atomic_number: int) -> float:
    element = Element.from_Z(int(atomic_number))
    if element.atomic_radius is not None and float(element.atomic_radius) > 0:
        return float(element.atomic_radius)
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="No data available.*")
        calculated = element.atomic_radius_calculated
    if calculated is not None and float(calculated) > 0:
        return float(calculated)
    return RADIUS_FALLBACK_ANGSTROM


def descriptor_from_orbit_pair(
    *,
    lattice: Sequence[Sequence[float]],
    candidate_species: int,
    candidate_fractional: Sequence[Sequence[float]],
    existing_species: int,
    existing_fractional: Sequence[Sequence[float]],
) -> RelationInterfaceDescriptor:
    candidate = np.asarray(candidate_fractional, dtype=float)
    existing = np.asarray(existing_fractional, dtype=float)
    matrix = np.asarray(lattice, dtype=float)
    if (
        candidate.ndim != 2
        or existing.ndim != 2
        or candidate.shape[1:] != (3,)
        or existing.shape[1:] != (3,)
        or len(candidate) == 0
        or len(existing) == 0
    ):
        raise ValueError("relation endpoint coordinates must be non-empty Nx3 arrays")
    if matrix.shape != (3, 3) or not np.isfinite(matrix).all():
        raise ValueError("relation lattice must be a finite 3x3 matrix")
    if not 1 <= int(candidate_species) <= 118 or not 1 <= int(existing_species) <= 118:
        raise ValueError("relation endpoint species must be atomic numbers")
    _, squared = pbc_shortest_vectors(
        Lattice(matrix),
        candidate,
        existing,
        return_d2=True,
    )
    distances = np.sqrt(np.maximum(0.0, np.asarray(squared, dtype=float)))
    radius_sum = _atomic_radius(candidate_species) + _atomic_radius(existing_species)
    stable = np.zeros_like(distances, dtype=bool)
    for index in np.ndindex(distances.shape):
        distance = float(distances[index])
        stable_count = sum(
            distance <= min(MAXIMUM_DISTANCE_ANGSTROM, alpha * radius_sum) + 1e-12
            for alpha in ALPHA_VALUES
        )
        stable[index] = stable_count >= 2
    return descriptor_from_members(
        distances=distances[stable].tolist(),
        candidate_multiplicity=len(candidate),
        existing_multiplicity=len(existing),
    )


def relation_descriptor_schema() -> dict[str, Any]:
    return {
        "schema_version": "g1-r1-relation-descriptor.1.0.0",
        "source": "R1 deterministic derivative of frozen Phase2A parent/partial structures",
        "relation_type": "stable_neighbor",
        "relation_type_serialized_in_phase2a": False,
        "presence_field": "presence",
        "continuous_fields": list(CONTINUOUS_FIELDS),
        "continuous_mask_field": "continuous_availability",
        "alpha_values": list(ALPHA_VALUES),
        "stable_threshold_count": 2,
        "maximum_distance_angstrom": MAXIMUM_DISTANCE_ANGSTROM,
        "radius_fallback_angstrom": RADIUS_FALLBACK_ANGSTROM,
        "rotation_invariant": True,
        "translation_invariant": True,
        "periodic_image_correct": True,
        "parent_lookup_required_at_inference": False,
    }


def descriptor_schema_sha256() -> str:
    encoded = json.dumps(
        relation_descriptor_schema(),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()
