from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any


class ActionType(str, Enum):
    ADD_ORBIT = "ADD_ORBIT"
    ASSIGN_SPECIES = "ASSIGN_SPECIES"
    ADD_MOTIF = "ADD_MOTIF"
    ADD_PERIODIC_EDGE = "ADD_PERIODIC_EDGE"
    UPDATE_LATTICE = "UPDATE_LATTICE"
    REFINE_GEOMETRY = "REFINE_GEOMETRY"
    TERMINATE = "TERMINATE"


@dataclass(frozen=True)
class AssemblyAction:
    action_type: ActionType
    parameters: tuple[tuple[str, Any], ...]

    def __post_init__(self) -> None:
        if not isinstance(self.action_type, ActionType):
            raise ValueError("action_type must be an ActionType")
        names = tuple(name for name, _ in self.parameters)
        if len(names) != len(set(names)):
            raise ValueError("action parameter names must be unique")

    @property
    def params(self) -> dict[str, Any]:
        return dict(self.parameters)

    def to_dict(self) -> dict[str, Any]:
        return {
            "action_type": self.action_type.value,
            "parameters": [[name, value] for name, value in self.parameters],
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> AssemblyAction:
        return cls(
            ActionType(payload["action_type"]),
            tuple((str(name), value) for name, value in payload["parameters"]),
        )

