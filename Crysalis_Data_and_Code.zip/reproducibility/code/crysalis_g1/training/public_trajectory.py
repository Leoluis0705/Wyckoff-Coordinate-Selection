from __future__ import annotations

import hashlib
import json
import math
import os
import random
import re
import time
from collections import Counter, defaultdict
from collections.abc import Iterable
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, cast

import numpy as np
import torch
from pymatgen.core import Lattice
from torch.nn import functional as F

from crysalis_assembly.serialization import canonical_payload_json
from crysalis_g1.actions import ActionType
from crysalis_g1.data.public_precheck import (
    ParentCrystal,
    PublicCacheError,
    load_public_parents,
)
from crysalis_g1.model.orbit_policy import OrbitAssemblyPolicy, PolicyOutput, StateBatch


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _write_json(path: Path, payload: object) -> None:
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
        + "\n",
        encoding="utf-8",
    )


@dataclass(frozen=True)
class PublicTrajectoryConfig:
    public_cache_path: str
    public_cache_sha256: str
    trajectory_path: str
    trajectory_sha256: str
    output_root: str
    code_commit_sha: str
    seed: int
    batch_size: int
    fp32_batches: int
    benchmark_updates: int
    extended_updates: int
    learning_rate: float
    device: str
    train_family_limit: int
    validation_family_limit: int
    validation_interval: int

    def __post_init__(self) -> None:
        if any(
            value <= 0
            for value in (
                self.batch_size,
                self.fp32_batches,
                self.benchmark_updates,
                self.extended_updates,
                self.train_family_limit,
                self.validation_family_limit,
                self.validation_interval,
            )
        ):
            raise ValueError("training counts must be positive")
        if self.extended_updates < self.benchmark_updates:
            raise ValueError("extended updates must cover benchmark updates")
        if not math.isfinite(self.learning_rate) or self.learning_rate <= 0:
            raise ValueError("learning rate must be finite and positive")
        if self.device not in {"cpu", "cuda"}:
            raise ValueError("device must be cpu or cuda")
        if any(len(value) != 64 for value in (self.public_cache_sha256, self.trajectory_sha256)):
            raise ValueError("source SHA-256 values must have length 64")
        if self.code_commit_sha != "AUTO" and not re.fullmatch(
            r"[0-9a-f]{40}", self.code_commit_sha
        ):
            raise ValueError("code commit SHA must be AUTO or a 40-character SHA")

    @classmethod
    def from_json(cls, path: str | Path) -> PublicTrajectoryConfig:
        return cls(**json.loads(Path(path).read_text(encoding="utf-8")))

    def resolved_code_commit_sha(self) -> str:
        value = (
            os.environ.get("CRYSALIS_G1_CODE_SHA", "")
            if self.code_commit_sha == "AUTO"
            else self.code_commit_sha
        )
        if not re.fullmatch(r"[0-9a-f]{40}", value):
            raise PublicCacheError(
                "CRYSALIS_G1_CODE_SHA must contain the frozen 40-character commit SHA"
            )
        return value

    def sha256(self) -> str:
        payload = asdict(self)
        payload["code_commit_sha"] = self.resolved_code_commit_sha()
        return hashlib.sha256(canonical_payload_json(payload).encode()).hexdigest()


@dataclass(frozen=True)
class TeacherTarget:
    action_index: int
    atomic_number: int
    multiplicity: int
    orbit_index: int
    free_parameters: tuple[float, float, float]
    lattice_parameters: tuple[float, float, float, float, float, float]
    has_orbit_target: bool


@dataclass(frozen=True)
class TeacherExample:
    composition: tuple[tuple[int, int], ...]
    remaining_composition: tuple[tuple[int, int], ...]
    space_group: int
    assembly_step: int
    current_orbits: tuple[
        tuple[int, int, tuple[float, float, float]], ...
    ]
    partition: str
    prototype_family: str
    target: TeacherTarget

    def model_input_bytes(self) -> bytes:
        payload = {
            "composition": self.composition,
            "remaining_composition": self.remaining_composition,
            "space_group": self.space_group,
            "assembly_step": self.assembly_step,
            "current_orbits": self.current_orbits,
        }
        return canonical_payload_json(payload).encode()


@dataclass(frozen=True)
class TeacherBatch:
    inputs: StateBatch
    action: torch.Tensor
    species: torch.Tensor
    multiplicity: torch.Tensor
    orbit_index: torch.Tensor
    free_parameters: torch.Tensor
    lattice_parameters: torch.Tensor
    orbit_target_mask: torch.Tensor

    def to(self, device: torch.device | str) -> TeacherBatch:
        return TeacherBatch(
            self.inputs.to(device),
            self.action.to(device),
            self.species.to(device),
            self.multiplicity.to(device),
            self.orbit_index.to(device),
            self.free_parameters.to(device),
            self.lattice_parameters.to(device),
            self.orbit_target_mask.to(device),
        )


@dataclass(frozen=True)
class _TrajectoryRecord:
    parent_structure_id: str
    path_index: int
    inverse_orbit_order: tuple[int, ...]


class PublicTrajectoryCorpus:
    def __init__(
        self,
        parents: dict[str, ParentCrystal],
        trajectories: tuple[_TrajectoryRecord, ...],
    ) -> None:
        self.parents = parents
        self.trajectories = trajectories
        self._by_key = {
            (item.parent_structure_id, item.path_index): item for item in trajectories
        }

    @classmethod
    def load(
        cls,
        *,
        public_cache_path: str | Path,
        public_cache_sha256: str,
        trajectory_path: str | Path,
        trajectory_sha256: str,
    ) -> PublicTrajectoryCorpus:
        path = Path(trajectory_path)
        if _sha256(path) != trajectory_sha256:
            raise PublicCacheError("trajectory SHA-256 mismatch")
        parents = {
            parent.material_id: parent
            for parent in load_public_parents(
                public_cache_path, expected_sha256=public_cache_sha256
            )
        }
        trajectories = []
        with path.open("r", encoding="utf-8") as handle:
            for line in handle:
                payload = json.loads(line)
                parent_id = str(payload["parent_structure_id"])
                if parent_id not in parents:
                    raise PublicCacheError(f"trajectory parent missing: {parent_id}")
                trajectories.append(
                    _TrajectoryRecord(
                        parent_id,
                        int(payload["path_index"]),
                        tuple(int(value) for value in payload["inverse_orbit_order"]),
                    )
                )
        if not trajectories:
            raise PublicCacheError("trajectory cache is empty")
        return cls(parents, tuple(trajectories))

    @staticmethod
    def _orbit(parent: ParentCrystal, orbit_index: int) -> tuple[int, int, tuple[float, float, float]]:
        site_indices = dict(parent.orbit_groups)[orbit_index]
        species = {parent.atomic_numbers[index] for index in site_indices}
        if len(species) != 1:
            raise PublicCacheError("orbit contains multiple species")
        coordinate = parent.fractional_coordinates[site_indices[0]]
        return next(iter(species)), len(site_indices), coordinate

    def example(
        self, parent_structure_id: str, *, path_index: int, assembly_step: int
    ) -> TeacherExample:
        parent = self.parents[parent_structure_id]
        trajectory = self._by_key[(parent_structure_id, path_index)]
        order = trajectory.inverse_orbit_order
        if not 0 <= assembly_step <= len(order):
            raise IndexError("assembly step out of range")
        current = tuple(
            self._orbit(parent, orbit_index) for orbit_index in order[:assembly_step]
        )
        remaining = Counter(parent.atomic_numbers)
        for atomic_number, multiplicity, _ in current:
            remaining[atomic_number] -= multiplicity
        remaining_composition = tuple(
            sorted((number, count) for number, count in remaining.items() if count > 0)
        )
        lattice = Lattice(np.asarray(parent.lattice, dtype=float))
        lattice_parameters = cast(
            tuple[float, float, float, float, float, float],
            (
                *(float(value) / 10.0 for value in lattice.lengths),
                *(float(value) / 180.0 for value in lattice.angles),
            ),
        )
        if assembly_step == len(order):
            target = TeacherTarget(
                list(ActionType).index(ActionType.TERMINATE),
                0,
                0,
                0,
                (0.0, 0.0, 0.0),
                lattice_parameters,
                False,
            )
        else:
            next_orbit = order[assembly_step]
            atomic_number, multiplicity, coordinate = self._orbit(parent, next_orbit)
            orbit_rank = tuple(index for index, _ in parent.orbit_groups).index(next_orbit)
            target = TeacherTarget(
                list(ActionType).index(ActionType.ADD_ORBIT),
                atomic_number,
                multiplicity,
                orbit_rank,
                coordinate,
                lattice_parameters,
                True,
            )
        return TeacherExample(
            tuple(sorted(Counter(parent.atomic_numbers).items())),
            remaining_composition,
            parent.space_group,
            assembly_step,
            current,
            parent.partition,
            parent.prototype_family,
            target,
        )

    def indices_for_families(
        self, partition: str, *, family_limit: int, seed: int
    ) -> tuple[tuple[str, int, int], ...]:
        family_parents: dict[str, set[str]] = defaultdict(set)
        for parent in self.parents.values():
            if parent.partition == partition:
                family_parents[parent.prototype_family].add(parent.material_id)
        families = sorted(
            family_parents,
            key=lambda family: (
                hashlib.sha256(f"g1-family:{seed}:{partition}:{family}".encode()).hexdigest(),
                family,
            ),
        )[:family_limit]
        accepted_ids = set().union(*(family_parents[family] for family in families))
        indices = []
        for trajectory in self.trajectories:
            if trajectory.parent_structure_id not in accepted_ids:
                continue
            for step in range(len(trajectory.inverse_orbit_order) + 1):
                indices.append(
                    (trajectory.parent_structure_id, trajectory.path_index, step)
                )
        return tuple(indices)

    def collate(self, examples: Iterable[TeacherExample]) -> TeacherBatch:
        rows = tuple(examples)
        if not rows:
            raise ValueError("teacher batch must not be empty")
        batch_size = len(rows)
        maximum_orbits = max(1, max(len(row.current_orbits) for row in rows))
        composition = torch.zeros((batch_size, 119))
        remaining = torch.zeros_like(composition)
        space_group = torch.zeros(batch_size, dtype=torch.long)
        assembly_step = torch.zeros((batch_size, 1))
        orbit_atomic_numbers = torch.zeros((batch_size, maximum_orbits), dtype=torch.long)
        orbit_multiplicities = torch.zeros_like(orbit_atomic_numbers)
        orbit_coordinates = torch.zeros((batch_size, maximum_orbits, 3))
        orbit_mask = torch.zeros((batch_size, maximum_orbits), dtype=torch.bool)
        for row_index, row in enumerate(rows):
            for atomic_number, count in row.composition:
                composition[row_index, atomic_number] = count
            for atomic_number, count in row.remaining_composition:
                remaining[row_index, atomic_number] = count
            space_group[row_index] = row.space_group
            assembly_step[row_index, 0] = row.assembly_step / 12.0
            for column, (atomic_number, multiplicity, coordinate) in enumerate(
                row.current_orbits
            ):
                orbit_atomic_numbers[row_index, column] = atomic_number
                orbit_multiplicities[row_index, column] = multiplicity
                orbit_coordinates[row_index, column] = torch.tensor(coordinate)
                orbit_mask[row_index, column] = True
        targets = tuple(row.target for row in rows)
        return TeacherBatch(
            StateBatch(
                composition,
                remaining,
                space_group,
                assembly_step,
                orbit_atomic_numbers,
                orbit_multiplicities,
                orbit_coordinates,
                orbit_mask,
            ),
            torch.tensor([target.action_index for target in targets]),
            torch.tensor([target.atomic_number for target in targets]),
            torch.tensor([target.multiplicity for target in targets]),
            torch.tensor([target.orbit_index for target in targets]),
            torch.tensor([target.free_parameters for target in targets]),
            torch.tensor([target.lattice_parameters for target in targets]),
            torch.tensor([target.has_orbit_target for target in targets]),
        )


def _losses(
    output: PolicyOutput, batch: TeacherBatch
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    action = F.cross_entropy(output.action_logits, batch.action)
    mask = batch.orbit_target_mask
    if bool(mask.any()):
        species = F.cross_entropy(output.species_logits[mask], batch.species[mask])
        multiplicity = F.cross_entropy(
            output.multiplicity_logits[mask], batch.multiplicity[mask]
        )
        orbit = F.cross_entropy(output.orbit_index_logits[mask], batch.orbit_index[mask])
        coordinate = F.mse_loss(output.free_parameters[mask], batch.free_parameters[mask])
    else:
        zero = output.action_logits.sum() * 0.0
        species = multiplicity = orbit = coordinate = zero
    lattice = F.mse_loss(output.lattice_parameters, batch.lattice_parameters)
    feasibility = F.binary_cross_entropy_with_logits(
        output.feasibility_logit, torch.ones_like(output.feasibility_logit)
    )
    components = {
        "action": action,
        "species": species,
        "multiplicity": multiplicity,
        "orbit": orbit,
        "coordinate": coordinate,
        "lattice": lattice,
        "feasibility": feasibility,
    }
    total = (
        action
        + species
        + multiplicity
        + orbit
        + coordinate
        + 0.1 * lattice
        + feasibility
    )
    return total, components


def _sample_batch(
    corpus: PublicTrajectoryCorpus,
    indices: tuple[tuple[str, int, int], ...],
    *,
    batch_size: int,
    generator: torch.Generator,
) -> TeacherBatch:
    selected = torch.randint(len(indices), (batch_size,), generator=generator).tolist()
    return corpus.collate(
        corpus.example(parent_id, path_index=path_index, assembly_step=step)
        for parent_id, path_index, step in (indices[index] for index in selected)
    )


def _gradient_norm(parameters: tuple[torch.nn.Parameter, ...]) -> float:
    squared = torch.zeros((), device=parameters[0].device)
    for parameter in parameters:
        if parameter.grad is not None:
            squared += parameter.grad.detach().float().square().sum()
    return float(torch.sqrt(squared))


def _component_gradient_diagnostics(
    components: dict[str, torch.Tensor], parameters: tuple[torch.nn.Parameter, ...]
) -> dict[str, object]:
    flattened: dict[str, torch.Tensor] = {}
    norms: dict[str, float] = {}
    for name, loss in components.items():
        gradients = torch.autograd.grad(
            loss, parameters, retain_graph=True, allow_unused=True
        )
        vector = torch.cat(
            [
                (torch.zeros_like(parameter) if gradient is None else gradient)
                .detach()
                .float()
                .flatten()
                for parameter, gradient in zip(parameters, gradients, strict=True)
            ]
        )
        flattened[name] = vector
        norms[name] = float(torch.linalg.vector_norm(vector))
    cosine: dict[str, float] = {}
    names = tuple(components)
    for first_index, first in enumerate(names):
        for second in names[first_index + 1 :]:
            denominator = norms[first] * norms[second]
            cosine[f"{first}|{second}"] = (
                float(torch.dot(flattened[first], flattened[second]) / denominator)
                if denominator > 0
                else 0.0
            )
    return {"per_loss_gradient_norm": norms, "pairwise_gradient_cosine": cosine}


def _checkpoint(
    path: Path,
    *,
    model: OrbitAssemblyPolicy,
    optimizer: torch.optim.Optimizer,
    completed_updates: int,
    config: PublicTrajectoryConfig,
) -> None:
    torch.save(
        {
            "schema_version": "g1-public-trajectory-1",
            "model_state_dict": model.state_dict(),
            "optimizer_state_dict": optimizer.state_dict(),
            "completed_updates": completed_updates,
            "config_sha256": config.sha256(),
            "public_cache_sha256": config.public_cache_sha256,
            "trajectory_sha256": config.trajectory_sha256,
            "code_commit_sha": config.resolved_code_commit_sha(),
        },
        path,
    )


def run_public_trajectory_benchmark(config: PublicTrajectoryConfig) -> dict[str, Any]:
    output_root = Path(config.output_root)
    if output_root.exists() and any(output_root.iterdir()):
        raise PublicCacheError(f"benchmark output directory is not empty: {output_root}")
    output_root.mkdir(parents=True, exist_ok=True)
    if config.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable")
    random.seed(config.seed)
    np.random.seed(config.seed)
    torch.manual_seed(config.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(config.seed)
    corpus = PublicTrajectoryCorpus.load(
        public_cache_path=config.public_cache_path,
        public_cache_sha256=config.public_cache_sha256,
        trajectory_path=config.trajectory_path,
        trajectory_sha256=config.trajectory_sha256,
    )
    train_indices = corpus.indices_for_families(
        "train_fit", family_limit=config.train_family_limit, seed=config.seed
    )
    validation_indices = corpus.indices_for_families(
        "validation", family_limit=config.validation_family_limit, seed=config.seed
    )
    if not train_indices or not validation_indices:
        raise PublicCacheError("public train or validation trajectory subset is empty")
    device = torch.device(config.device)
    model = OrbitAssemblyPolicy().to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config.learning_rate)
    amp_enabled = device.type == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=amp_enabled)
    parameters = tuple(parameter for parameter in model.parameters() if parameter.requires_grad)
    generator = torch.Generator().manual_seed(config.seed + 1)
    metrics_path = output_root / "metrics.jsonl"
    all_finite = True
    start = time.perf_counter()
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)

    with metrics_path.open("w", encoding="utf-8") as metrics:
        for batch_index in range(config.fp32_batches):
            batch = _sample_batch(
                corpus,
                train_indices,
                batch_size=config.batch_size,
                generator=generator,
            ).to(device)
            model.zero_grad(set_to_none=True)
            total, components = _losses(model(batch.inputs), batch)
            diagnostics = (
                _component_gradient_diagnostics(components, parameters)
                if batch_index == 0
                else {}
            )
            total.backward()
            values = {name: float(value.detach()) for name, value in components.items()}
            finite = all(math.isfinite(value) for value in values.values())
            finite = finite and math.isfinite(_gradient_norm(parameters))
            all_finite = all_finite and finite
            if not finite:
                raise FloatingPointError("non-finite public trajectory fp32 smoke")
            metrics.write(
                canonical_payload_json(
                    {
                        "stage": "real_trajectory_fp32",
                        "batch": batch_index + 1,
                        "finite": finite,
                        "train_total": float(total.detach()),
                        "gradient_norm": _gradient_norm(parameters),
                        **values,
                        **diagnostics,
                    }
                )
                + "\n"
            )
            metrics.flush()

        for update in range(1, config.extended_updates + 1):
            batch = _sample_batch(
                corpus,
                train_indices,
                batch_size=config.batch_size,
                generator=generator,
            ).to(device)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(
                device_type=device.type, dtype=torch.float16, enabled=amp_enabled
            ):
                total, components = _losses(model(batch.inputs), batch)
            diagnostics = (
                _component_gradient_diagnostics(components, parameters)
                if update in {1, config.benchmark_updates, config.extended_updates}
                else {}
            )
            if amp_enabled:
                scaler.scale(total).backward()
                scaler.unscale_(optimizer)
            else:
                total.backward()
            gradient_norm = _gradient_norm(parameters)
            values = {name: float(value.detach()) for name, value in components.items()}
            finite = all(math.isfinite(value) for value in values.values())
            finite = finite and math.isfinite(gradient_norm)
            all_finite = all_finite and finite
            if not finite:
                raise FloatingPointError("non-finite public trajectory benchmark")
            optimizer_step_skipped = False
            if amp_enabled:
                previous_scale = scaler.get_scale()
                scaler.step(optimizer)
                scaler.update()
                optimizer_step_skipped = scaler.get_scale() < previous_scale
            else:
                optimizer.step()
            record: dict[str, object] = {
                "stage": "real_trajectory_update",
                "update": update,
                "finite": finite,
                "train_total": float(total.detach()),
                "gradient_norm": gradient_norm,
                "mixed_precision": amp_enabled,
                "optimizer_step_skipped": optimizer_step_skipped,
                **values,
                **diagnostics,
            }
            if update % config.validation_interval == 0 or update in {
                config.benchmark_updates,
                config.extended_updates,
            }:
                model.eval()
                with torch.no_grad():
                    validation_batch = _sample_batch(
                        corpus,
                        validation_indices,
                        batch_size=config.batch_size,
                        generator=generator,
                    ).to(device)
                    validation_total, _ = _losses(
                        model(validation_batch.inputs), validation_batch
                    )
                model.train()
                record["validation_total"] = float(validation_total)
                if not math.isfinite(float(validation_total)):
                    raise FloatingPointError("non-finite public validation loss")
            metrics.write(canonical_payload_json(record) + "\n")
            metrics.flush()
            if update == config.benchmark_updates:
                _checkpoint(
                    output_root / f"checkpoint_{update}.pt",
                    model=model,
                    optimizer=optimizer,
                    completed_updates=update,
                    config=config,
                )

    if config.extended_updates != config.benchmark_updates:
        _checkpoint(
            output_root / f"checkpoint_{config.extended_updates}.pt",
            model=model,
            optimizer=optimizer,
            completed_updates=config.extended_updates,
            config=config,
        )
    wall_seconds = time.perf_counter() - start
    peak_vram = int(torch.cuda.max_memory_allocated(device)) if device.type == "cuda" else 0
    summary: dict[str, Any] = {
        "status": "PASS",
        "scientific_scope": "PUBLIC_REAL_ORBIT_TRAJECTORY_BENCHMARK",
        "all_losses_finite": all_finite,
        "fp32_batches": config.fp32_batches,
        "completed_updates": config.extended_updates,
        "benchmark_milestone_updates": config.benchmark_updates,
        "train_example_count": len(train_indices),
        "validation_example_count": len(validation_indices),
        "parameter_count": model.trainable_parameter_count(),
        "wall_seconds": wall_seconds,
        "updates_per_second": config.extended_updates / max(wall_seconds, 1e-9),
        "peak_vram_bytes": peak_vram,
        "device": str(device),
        "mixed_precision_enabled": amp_enabled,
        "public_cache_sha256": config.public_cache_sha256,
        "trajectory_sha256": config.trajectory_sha256,
        "config_sha256": config.sha256(),
        "code_commit_sha": config.resolved_code_commit_sha(),
        "sealed_or_blind_accessed": False,
        "formal_matrix_started": False,
    }
    _write_json(output_root / "benchmark_exit.json", summary)
    return summary
