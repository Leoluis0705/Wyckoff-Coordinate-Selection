from __future__ import annotations

import hashlib
import json
import platform
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import torch

from crysalis_assembly.serialization import canonical_payload_json
from crysalis_g1.model.unified import (
    AssemblyTensorBatch,
    ArmSwitches,
    UnifiedCrysalisG1,
    UnifiedG1Config,
    summarize_projector_metrics,
)


STANDARD_ARM_IDS = ("C0", "C1", "C2", "C3-Full")
DIAGNOSTIC_ARM_IDS = ("C1-P",)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _write_json(path: Path, payload: object) -> None:
    path.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n",
        encoding="utf-8",
    )


def _git_commit() -> str:
    result = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        check=True,
        capture_output=True,
        text=True,
    )
    return result.stdout.strip()


@dataclass(frozen=True)
class Phase2BPreflightConfig:
    schema_version: str
    implementation_scope: str
    phase2a_exit_path: str
    expected_phase2a_manifest_sha256: str
    output_root: str
    root_seed: int
    device: str
    batch_size: int
    max_orbits: int
    max_relations: int
    composition_dim: int
    condition_dim: int
    orbit_invariant_dim: int
    relation_invariant_dim: int
    guide_physics_dim: int
    hidden_dim: int
    relation_prior_dim: int
    relation_memory_dim: int
    action_count: int
    termination_action_index: int
    projector_min_distance: float
    relation_library_backend: str
    relation_library_artifact_sha256: str
    phase2b_model_implementation_authorized: bool
    server_deployment_authorized: bool
    formal_training_started: bool
    three_seed_authorized: bool

    def __post_init__(self) -> None:
        if self.schema_version != "g1-phase2b-preflight.1.0.0":
            raise ValueError("unsupported Phase 2B preflight schema")
        if self.implementation_scope != "LOCAL_MODEL_SKELETON_PREFLIGHT_ONLY":
            raise ValueError("Phase 2B preflight must remain local and skeleton-only")
        if not self.phase2b_model_implementation_authorized:
            raise ValueError("Phase 2B model implementation is not authorized")
        if self.server_deployment_authorized:
            raise ValueError("server deployment is not authorized")
        if self.formal_training_started:
            raise ValueError("formal training must remain false in preflight")
        if self.three_seed_authorized:
            raise ValueError("three-seed execution is not authorized")
        if self.device not in {"cpu", "cuda"}:
            raise ValueError("device must be cpu or cuda")
        positive_integers = (
            self.batch_size,
            self.max_orbits,
            self.max_relations,
            self.composition_dim,
            self.condition_dim,
            self.orbit_invariant_dim,
            self.relation_invariant_dim,
            self.guide_physics_dim,
            self.hidden_dim,
            self.relation_prior_dim,
            self.relation_memory_dim,
            self.action_count,
        )
        if any(type(value) is not int or value <= 0 for value in positive_integers):
            raise ValueError("preflight dimensions must be positive integers")
        if self.batch_size < 2 or self.max_orbits < 2 or self.max_relations < 2:
            raise ValueError("preflight requires at least two samples, orbits, and relations")
        try:
            digest = bytes.fromhex(self.expected_phase2a_manifest_sha256)
        except ValueError as error:
            raise ValueError("expected Phase 2A manifest SHA-256 is invalid") from error
        if len(digest) != 32:
            raise ValueError("expected Phase 2A manifest SHA-256 is invalid")

    @classmethod
    def from_json(cls, path: str | Path) -> Phase2BPreflightConfig:
        with Path(path).open("r", encoding="utf-8") as handle:
            return cls(**json.load(handle))

    def sha256(self) -> str:
        return hashlib.sha256(
            canonical_payload_json(asdict(self)).encode("utf-8")
        ).hexdigest()

    def model_config(self, arm_id: str) -> UnifiedG1Config:
        switches = ArmSwitches.for_arm(arm_id)
        return UnifiedG1Config(
            schema_version="g1-unified-skeleton.1.0.0",
            implementation_scope=self.implementation_scope,
            arm_id=arm_id,
            use_relation_memory=switches.use_relation_memory,
            use_relation_library=switches.use_relation_library,
            use_stepwise_physics=switches.use_stepwise_physics,
            composition_dim=self.composition_dim,
            condition_dim=self.condition_dim,
            orbit_invariant_dim=self.orbit_invariant_dim,
            relation_invariant_dim=self.relation_invariant_dim,
            guide_physics_dim=self.guide_physics_dim,
            hidden_dim=self.hidden_dim,
            relation_prior_dim=self.relation_prior_dim,
            relation_memory_dim=self.relation_memory_dim,
            action_count=self.action_count,
            termination_action_index=self.termination_action_index,
            projector_min_distance=self.projector_min_distance,
            relation_library_backend=(
                self.relation_library_backend
                if switches.use_relation_library
                else "none"
            ),
            relation_library_artifact_sha256=(
                self.relation_library_artifact_sha256
                if switches.use_relation_library
                else ""
            ),
            phase2b_model_implementation_authorized=(
                self.phase2b_model_implementation_authorized
            ),
            server_deployment_authorized=self.server_deployment_authorized,
            formal_training_started=self.formal_training_started,
            three_seed_authorized=self.three_seed_authorized,
        )


def _verify_phase2a(config: Phase2BPreflightConfig) -> dict[str, Any]:
    exit_path = Path(config.phase2a_exit_path).resolve()
    if not exit_path.is_file():
        raise FileNotFoundError(f"Phase 2A exit receipt not found: {exit_path}")
    with exit_path.open("r", encoding="utf-8") as handle:
        receipt = json.load(handle)
    if receipt.get("status") != "PASS":
        raise RuntimeError("Phase 2A PASS is required before Phase 2B preflight")
    if receipt.get("structure_ood_pass") is not True:
        raise RuntimeError("Phase 2A Structure-OOD gate did not pass")
    if receipt.get("composition_ood_pass") is not True:
        raise RuntimeError("Phase 2A Composition-OOD gate did not pass")
    if receipt.get("authorized_excluded_parent_ids") != ["mp-1173150"]:
        raise RuntimeError("Phase 2A canonical exclusion receipt is not exact")
    if receipt.get("no_refill") is not True:
        raise RuntimeError("Phase 2A no-refill receipt is missing")
    trajectory_count = receipt.get("trajectory_count")
    replay_count = receipt.get("successful_replay_count")
    if (
        type(trajectory_count) is not int
        or trajectory_count <= 0
        or replay_count != trajectory_count
    ):
        raise RuntimeError("Phase 2A full replay gate did not pass")
    manifest_path = exit_path.parent / "phase2a_manifest.json"
    if not manifest_path.is_file():
        raise FileNotFoundError("Phase 2A manifest is missing")
    manifest_sha = _sha256(manifest_path)
    expected = config.expected_phase2a_manifest_sha256.lower()
    if manifest_sha != expected or receipt.get("phase2a_manifest_sha256") != expected:
        raise RuntimeError("Phase 2A manifest SHA-256 mismatch")
    with manifest_path.open("r", encoding="utf-8") as handle:
        manifest = json.load(handle)
    file_hashes = manifest.get("file_sha256", {})
    if not isinstance(file_hashes, dict):
        raise RuntimeError("Phase 2A file hash manifest is invalid")
    for relative, expected_file_sha in file_hashes.items():
        artifact = exit_path.parent / relative
        if not artifact.is_file() or _sha256(artifact) != expected_file_sha:
            raise RuntimeError(f"Phase 2A artifact hash mismatch: {relative}")
    return {
        "status": "PASS",
        "exit_path": str(exit_path),
        "manifest_sha256": manifest_sha,
        "trajectory_count": trajectory_count,
        "successful_replay_count": replay_count,
        "authorized_excluded_parent_ids": receipt["authorized_excluded_parent_ids"],
        "no_refill": True,
        "all_manifest_file_hashes_verified": True,
        "manifest_file_count": len(file_hashes),
    }


def _synthetic_batch(config: Phase2BPreflightConfig) -> AssemblyTensorBatch:
    generator = torch.Generator(device="cpu").manual_seed(config.root_seed + 1)
    batch_size = config.batch_size
    node_count = config.max_orbits
    relation_count = config.max_relations
    composition = torch.zeros((batch_size, config.composition_dim))
    for row in range(batch_size):
        composition[row, 8] = float(1 + row % 2)
        composition[row, 14] = float(1 + (row + 1) % 2)
    conditions = torch.rand(
        (batch_size, config.condition_dim), generator=generator
    )
    orbit_invariants = torch.rand(
        (batch_size, node_count, config.orbit_invariant_dim), generator=generator
    )
    base_fractional = torch.tensor(
        [
            [0.10, 0.10, 0.10],
            [0.55, 0.10, 0.10],
            [0.10, 0.55, 0.10],
            [0.10, 0.10, 0.55],
            [0.55, 0.55, 0.10],
            [0.55, 0.10, 0.55],
            [0.10, 0.55, 0.55],
            [0.55, 0.55, 0.55],
        ]
    )
    if node_count > base_fractional.shape[0]:
        raise ValueError("local preflight supports at most eight synthetic orbits")
    fractional = base_fractional[:node_count].repeat(batch_size, 1, 1)
    lattice = torch.zeros((batch_size, 3, 3))
    for row in range(batch_size):
        scale = 4.0 + 0.25 * row
        lattice[row] = torch.tensor(
            [[scale, 0.0, 0.0], [0.15, scale + 0.2, 0.0], [0.10, 0.20, scale + 0.4]]
        )
    positions = fractional @ lattice
    node_mask = torch.ones((batch_size, node_count), dtype=torch.bool)
    sources = torch.empty((batch_size, relation_count), dtype=torch.long)
    targets = torch.empty_like(sources)
    vectors = torch.empty((batch_size, relation_count, 3))
    relation_invariants = torch.zeros(
        (batch_size, relation_count, config.relation_invariant_dim)
    )
    relation_availability = torch.zeros_like(
        relation_invariants, dtype=torch.bool
    )
    relation_availability[..., (0, 1, 2, 3, 10)] = True
    for row in range(batch_size):
        for edge in range(relation_count):
            source = edge % node_count
            target = (edge + 1 + edge // node_count) % node_count
            if source == target:
                target = (target + 1) % node_count
            sources[row, edge] = source
            targets[row, edge] = target
            delta = fractional[row, target] - fractional[row, source]
            delta = delta - torch.round(delta)
            vector = delta @ lattice[row]
            vectors[row, edge] = vector
            relation_invariants[row, edge, 0] = torch.linalg.vector_norm(vector)
            relation_invariants[row, edge, 1] = 0.0
            relation_invariants[row, edge, 2] = float(2 + edge % 3)
            relation_invariants[row, edge, 3] = float(2 + (edge + 1) % 3)
            relation_invariants[row, edge, 10] = float(edge + 1) / relation_count
    relation_mask = torch.ones((batch_size, relation_count), dtype=torch.bool)
    legal_action_mask = torch.ones(
        (batch_size, config.action_count), dtype=torch.bool
    )
    termination_legal = torch.tensor(
        [row % 2 == 0 for row in range(batch_size)], dtype=torch.bool
    )
    legal_action_mask[:, config.termination_action_index] = termination_legal
    guide = torch.rand(
        (batch_size, config.guide_physics_dim), generator=generator
    )
    applicability = torch.tensor(
        [row % 2 == 0 for row in range(batch_size)], dtype=torch.bool
    )
    space_groups = torch.tensor(
        ([1, 2, 14, 225] * ((batch_size + 3) // 4))[:batch_size], dtype=torch.long
    )
    return AssemblyTensorBatch(
        composition=composition,
        condition_invariants=conditions,
        orbit_invariants=orbit_invariants,
        cartesian_positions=positions,
        node_mask=node_mask,
        relation_invariants=relation_invariants,
        relation_availability=relation_availability,
        relation_vectors=vectors,
        relation_sources=sources,
        relation_targets=targets,
        relation_mask=relation_mask,
        lattice=lattice,
        legal_action_mask=legal_action_mask,
        termination_legal=termination_legal,
        guide_physics_invariants=guide,
        partial_physics_applicability_mask=applicability,
        relation_memory=torch.zeros((batch_size, config.relation_memory_dim)),
        space_group=space_groups,
    )


def _tensor_state_sha256(model: UnifiedCrysalisG1, prefixes: tuple[str, ...]) -> str:
    digest = hashlib.sha256()
    for name, tensor in sorted(model.state_dict().items()):
        if not name.startswith(prefixes):
            continue
        value = tensor.detach().cpu().contiguous()
        digest.update(name.encode("utf-8"))
        digest.update(str(value.dtype).encode("ascii"))
        digest.update(str(tuple(value.shape)).encode("ascii"))
        digest.update(value.numpy().tobytes())
    return digest.hexdigest()


def _module_parameter_counts(model: UnifiedCrysalisG1) -> dict[str, dict[str, int]]:
    records: dict[str, dict[str, int]] = {}
    for name in model.module_contract():
        module = getattr(model, name)
        parameters = list(module.parameters())
        records[name] = {
            "total": sum(parameter.numel() for parameter in parameters),
            "trainable": sum(
                parameter.numel() for parameter in parameters if parameter.requires_grad
            ),
        }
    return records


def _forward_finite(output: Any) -> bool:
    always_finite = (
        output.embryo_state,
        output.lattice_metric,
        output.geometry_delta,
        output.pre_projector_positions,
        output.projected_positions,
        output.projected_lattice,
        output.relation_prior,
        output.physics_feedback,
        output.next_relation_memory,
        output.projector_result.correction_amount,
    )
    if not all(bool(torch.isfinite(value).all()) for value in always_finite):
        return False
    if not bool(torch.isfinite(output.action_logits[output.compiled_action_mask]).all()):
        return False
    legal_termination = ~torch.isneginf(output.termination_logit)
    return bool(torch.isfinite(output.termination_logit[legal_termination]).all())


def _parameter_storage_independent(models: list[UnifiedCrysalisG1]) -> bool:
    pointer_sets = [
        {parameter.data_ptr() for parameter in model.parameters()} for model in models
    ]
    for left in range(len(pointer_sets)):
        for right in range(left + 1, len(pointer_sets)):
            if pointer_sets[left] & pointer_sets[right]:
                return False
    return True


def run_phase2b_preflight(config: Phase2BPreflightConfig) -> dict[str, Any]:
    phase2a_evidence = _verify_phase2a(config)
    output_root = Path(config.output_root).resolve()
    if output_root.exists():
        raise FileExistsError(
            f"Phase 2B preflight refuses to overwrite existing output: {output_root}"
        )
    if config.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested for preflight but unavailable")
    output_root.mkdir(parents=True, exist_ok=False)
    device = torch.device(config.device)
    batch = _synthetic_batch(config).to(device)
    models: list[UnifiedCrysalisG1] = []
    arm_results: list[dict[str, Any]] = []
    core_hashes: list[str] = []
    relation_library_hashes: dict[str, str] = {}
    core_prefixes = (
        "material_embryo_planner.",
        "orbit_level_assembly_policy.",
        "lattice_head.",
        "periodic_equivariant_geometry_generator.",
        "termination_head.",
    )
    for arm_id in STANDARD_ARM_IDS + DIAGNOSTIC_ARM_IDS:
        torch.manual_seed(config.root_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(config.root_seed)
        model = UnifiedCrysalisG1(config.model_config(arm_id)).to(device)
        model.zero_grad(set_to_none=True)
        output = model(batch)
        forward_finite = _forward_finite(output)
        finite_action = output.action_logits[output.compiled_action_mask]
        finite_termination = output.termination_logit[
            ~torch.isneginf(output.termination_logit)
        ]
        loss = (
            finite_action.square().mean()
            + finite_termination.square().mean()
            + output.lattice_metric.square().mean()
            + output.geometry_delta.square().mean()
            + output.next_relation_memory.square().mean()
        )
        loss.backward()
        backward_finite = bool(torch.isfinite(loss.detach())) and all(
            parameter.grad is None or bool(torch.isfinite(parameter.grad).all())
            for parameter in model.parameters()
            if parameter.requires_grad
        )
        switches = ArmSwitches.for_arm(arm_id)
        projector_metrics = summarize_projector_metrics(
            output.projector_result, batch.space_group
        )
        core_hashes.append(_tensor_state_sha256(model, core_prefixes))
        relation_library_hashes[arm_id] = _tensor_state_sha256(
            model, ("relation_library.",)
        )
        arm_results.append(
            {
                "arm_id": arm_id,
                "arm_role": (
                    "STANDARD_PILOT_ARM"
                    if arm_id in STANDARD_ARM_IDS
                    else "CONTRACT_DIAGNOSTIC_ONLY"
                ),
                "root_seed": config.root_seed,
                "switches": asdict(switches),
                "forward_finite": forward_finite,
                "backward_finite": backward_finite,
                "diagnostic_loss": float(loss.detach()),
                "optimizer_steps": 0,
                "checkpoint_written": False,
                "trainable_parameter_count": model.trainable_parameter_count(),
                "module_parameter_counts": _module_parameter_counts(model),
                "module_contract": model.module_contract(),
                "state_lifecycle_contract": model.state_lifecycle_contract(),
                "physics_backend_contract": model.physics_backend_contract(),
                "physics_applied_count": int(output.physics_applied_mask.sum()),
                "projector_metrics": projector_metrics,
                "projector_rejection_reason_codes": [
                    list(codes) for codes in output.projector_result.reason_codes
                ],
                "output_shapes": {
                    "action_logits": list(output.action_logits.shape),
                    "lattice_metric": list(output.lattice_metric.shape),
                    "geometry_delta": list(output.geometry_delta.shape),
                    "termination_logit": list(output.termination_logit.shape),
                    "relation_prior": list(output.relation_prior.shape),
                    "relation_memory": list(output.next_relation_memory.shape),
                },
            }
        )
        models.append(model)
    common_core_equal = len(set(core_hashes)) == 1
    independent_storage = _parameter_storage_independent(models)
    relation_library_equal = (
        relation_library_hashes["C2"] == relation_library_hashes["C3-Full"]
    )
    all_finite = all(
        record["forward_finite"] and record["backward_finite"]
        for record in arm_results
    )
    status = (
        "PASS"
        if all_finite
        and common_core_equal
        and independent_storage
        and relation_library_equal
        else "STOPPED"
    )
    report: dict[str, Any] = {
        "schema_version": config.schema_version,
        "status": status,
        "implementation_scope": config.implementation_scope,
        "candidate_configuration_status": "PREFLIGHT_ONLY_NOT_FROZEN_FOR_TRAINING",
        "phase2b_model_implementation_authorized": True,
        "server_deployment_authorized": False,
        "formal_training_started": False,
        "three_seed_authorized": False,
        "optimizer_steps": 0,
        "checkpoints_written": 0,
        "root_seed": config.root_seed,
        "same_synthetic_batch_for_all_arms": True,
        "standard_arm_ids": list(STANDARD_ARM_IDS),
        "diagnostic_arm_ids": list(DIAGNOSTIC_ARM_IDS),
        "common_core_initialization_equal": common_core_equal,
        "parameter_storage_independent": independent_storage,
        "c2_c3_relation_library_state_equal": relation_library_equal,
        "relation_library_artifact_status": (
            "SYNTHETIC_INTERFACE_FIXTURE_NOT_A_TRAINED_ARTIFACT"
        ),
        "relation_library_backend": config.relation_library_backend,
        "declared_preflight_relation_library_identifier_sha256": (
            config.relation_library_artifact_sha256
        ),
        "relation_library_state_sha256_by_arm": relation_library_hashes,
        "continuous_relation_schema_dim": config.relation_invariant_dim,
        "relation_availability_bits_dim": config.relation_invariant_dim,
        "geometry_backend": "SCALAR_WEIGHTED_L1_EQUIVARIANT_PREFLIGHT_OPERATOR",
        "e3nn_production_backend_claimed": False,
        "phase2a_evidence": phase2a_evidence,
        "config_sha256": config.sha256(),
        "code_commit_sha": _git_commit(),
        "device": str(device),
        "arm_results": arm_results,
    }
    report_path = output_root / "phase2b_preflight_report.json"
    _write_json(report_path, report)
    manifest = {
        "schema_version": config.schema_version,
        "status": status,
        "config_sha256": config.sha256(),
        "code_commit_sha": report["code_commit_sha"],
        "phase2a_manifest_sha256": config.expected_phase2a_manifest_sha256,
        "formal_training_started": False,
        "server_deployment_authorized": False,
        "three_seed_authorized": False,
        "dependency_versions": {
            "python": platform.python_version(),
            "torch": torch.__version__,
        },
        "file_sha256": {
            report_path.name: _sha256(report_path),
        },
    }
    manifest_path = output_root / "phase2b_preflight_manifest.json"
    _write_json(manifest_path, manifest)
    exit_receipt = {
        **report,
        "phase2b_preflight_manifest_sha256": _sha256(manifest_path),
    }
    _write_json(output_root / "phase2b_preflight_exit.json", exit_receipt)
    return exit_receipt
