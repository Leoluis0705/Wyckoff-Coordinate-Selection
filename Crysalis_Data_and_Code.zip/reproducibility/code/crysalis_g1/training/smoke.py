from __future__ import annotations

import hashlib
import json
import math
import random
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch.nn import functional as F

from crysalis_assembly.serialization import canonical_payload_json
from crysalis_g1.actions import ActionType
from crysalis_g1.generation.sampler import generate_smoke_candidates
from crysalis_g1.model.orbit_policy import (
    OrbitAssemblyPolicy,
    StateBatch,
    encode_states,
)


@dataclass(frozen=True)
class SmokeConfig:
    seed: int
    fixture_count: int
    fp32_batches: int
    benchmark_updates: int
    batch_size: int
    learning_rate: float
    device: str
    output_root: str

    def __post_init__(self) -> None:
        if self.fixture_count <= 0 or self.fp32_batches <= 0:
            raise ValueError("fixture_count and fp32_batches must be positive")
        if self.benchmark_updates <= 0 or self.batch_size <= 0:
            raise ValueError("benchmark_updates and batch_size must be positive")
        if not math.isfinite(self.learning_rate) or self.learning_rate <= 0:
            raise ValueError("learning rate must be finite and positive")

    @classmethod
    def from_json(cls, path: str | Path) -> SmokeConfig:
        with Path(path).open("r", encoding="utf-8") as handle:
            payload = json.load(handle)
        return cls(**payload)

    def sha256(self) -> str:
        return hashlib.sha256(canonical_payload_json(asdict(self)).encode()).hexdigest()


def _write_json(path: Path, payload: object) -> None:
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
        + "\n",
        encoding="utf-8",
    )


def _select_device(requested: str) -> torch.device:
    if requested == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable")
    return torch.device(requested)


def _batch_slice(batch: StateBatch, indices: torch.Tensor) -> StateBatch:
    return StateBatch(
        batch.composition[indices],
        batch.remaining[indices],
        batch.space_group[indices],
        batch.assembly_step[indices],
        None if batch.orbit_atomic_numbers is None else batch.orbit_atomic_numbers[indices],
        None if batch.orbit_multiplicities is None else batch.orbit_multiplicities[indices],
        None if batch.orbit_coordinates is None else batch.orbit_coordinates[indices],
        None if batch.orbit_mask is None else batch.orbit_mask[indices],
    )


def _targets(batch: StateBatch, seed: int) -> dict[str, torch.Tensor]:
    species = batch.remaining.argmax(dim=1)
    generator = torch.Generator(device="cpu").manual_seed(seed)
    free_parameters = torch.rand((batch.composition.shape[0], 3), generator=generator)
    atom_count = batch.composition.sum(dim=1)
    lattice_length = 3.0 + atom_count.pow(1 / 3)
    zeros = torch.zeros_like(lattice_length)
    lattice = torch.stack(
        (lattice_length, lattice_length, lattice_length, zeros, zeros, zeros), dim=1
    )
    return {
        "action": torch.full(
            (batch.composition.shape[0],),
            list(ActionType).index(ActionType.ADD_ORBIT),
            dtype=torch.long,
        ),
        "species": species.long(),
        "free_parameters": free_parameters,
        "lattice": lattice,
        "feasibility": torch.ones(batch.composition.shape[0]),
    }


def _losses(
    model: OrbitAssemblyPolicy, batch: StateBatch, seed: int
) -> tuple[torch.Tensor, dict[str, float]]:
    output = model(batch)
    targets = _targets(batch, seed)
    action = F.cross_entropy(
        output.action_logits, targets["action"].to(output.action_logits.device)
    )
    species = F.cross_entropy(
        output.species_logits, targets["species"].to(output.species_logits.device)
    )
    coordinate = F.mse_loss(
        output.free_parameters, targets["free_parameters"].to(output.free_parameters.device)
    )
    lattice = F.mse_loss(
        output.lattice_parameters, targets["lattice"].to(output.lattice_parameters.device)
    )
    feasibility = F.binary_cross_entropy_with_logits(
        output.feasibility_logit, targets["feasibility"].to(output.feasibility_logit.device)
    )
    total = action + species + coordinate + 0.1 * lattice + feasibility
    values = {
        "loss_action": float(action.detach()),
        "loss_species": float(species.detach()),
        "loss_coordinate": float(coordinate.detach()),
        "loss_lattice": float(lattice.detach()),
        "loss_feasibility": float(feasibility.detach()),
        "train_total": float(total.detach()),
    }
    return total, values


def _gradient_norm(model: OrbitAssemblyPolicy) -> float:
    squared = torch.zeros((), device=next(model.parameters()).device)
    for parameter in model.parameters():
        if parameter.grad is not None:
            squared = squared + parameter.grad.detach().float().square().sum()
    return float(torch.sqrt(squared))


def run_smoke(config: SmokeConfig) -> dict[str, Any]:
    output_root = Path(config.output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    metrics_path = output_root / "metrics.jsonl"
    random.seed(config.seed)
    np.random.seed(config.seed)
    torch.manual_seed(config.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(config.seed)
    device = _select_device(config.device)
    candidates = generate_smoke_candidates(count=config.fixture_count, seed=config.seed)
    states = [candidate.trajectory.initial_state for candidate in candidates]
    encoded = encode_states(states)
    model = OrbitAssemblyPolicy().to(device)
    parameter_count = model.trainable_parameter_count()
    optimizer = torch.optim.AdamW(model.parameters(), lr=config.learning_rate)
    generator = torch.Generator().manual_seed(config.seed + 1)
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    start_time = time.perf_counter()
    all_finite = True

    with metrics_path.open("w", encoding="utf-8") as metrics:
        for batch_index in range(config.fp32_batches):
            indices = torch.randint(
                len(states), (config.batch_size,), generator=generator
            )
            batch = _batch_slice(encoded, indices).to(device)
            model.zero_grad(set_to_none=True)
            total, values = _losses(model, batch, config.seed + batch_index)
            total.backward()
            finite = all(math.isfinite(value) for value in values.values())
            finite = finite and all(
                parameter.grad is None or torch.isfinite(parameter.grad).all().item()
                for parameter in model.parameters()
            )
            all_finite = all_finite and finite
            record = {
                "stage": "fp32_forward_backward",
                "batch": batch_index + 1,
                "finite": finite,
                "gradient_norm": _gradient_norm(model),
                **values,
            }
            metrics.write(canonical_payload_json(record) + "\n")
            metrics.flush()
            if not finite:
                raise FloatingPointError("non-finite fp32 smoke metric")

        model.train()
        for update in range(config.benchmark_updates):
            indices = torch.randint(
                len(states), (config.batch_size,), generator=generator
            )
            batch = _batch_slice(encoded, indices).to(device)
            optimizer.zero_grad(set_to_none=True)
            total, values = _losses(
                model, batch, config.seed + config.fp32_batches + update
            )
            total.backward()
            gradient_norm = _gradient_norm(model)
            finite = all(math.isfinite(value) for value in values.values()) and math.isfinite(
                gradient_norm
            )
            all_finite = all_finite and finite
            if not finite:
                raise FloatingPointError("non-finite benchmark metric")
            optimizer.step()
            record = {
                "stage": "benchmark_update",
                "update": update + 1,
                "finite": finite,
                "gradient_norm": gradient_norm,
                **values,
            }
            metrics.write(canonical_payload_json(record) + "\n")
            metrics.flush()

    wall_seconds = time.perf_counter() - start_time
    peak_vram = (
        int(torch.cuda.max_memory_allocated(device)) if device.type == "cuda" else 0
    )
    checkpoint = {
        "schema_version": "g1-smoke-1",
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "completed_updates": config.benchmark_updates,
        "config_sha256": config.sha256(),
        "parameter_count": parameter_count,
    }
    torch.save(checkpoint, output_root / "checkpoint.pt")
    generation_summary = {
        "candidate_count": len(candidates),
        "terminated_count": sum(item.final_state.terminated for item in candidates),
        "composition_complete_count": sum(
            not item.final_state.remaining_composition for item in candidates
        ),
        "exact_replay_count": sum(
            item.replay_hash == item.final_state.content_hash() for item in candidates
        ),
        "parent_information_supplied": False,
        "space_group_source": "condition",
    }
    _write_json(output_root / "generation_summary.json", generation_summary)
    summary: dict[str, Any] = {
        "status": "COMPLETED",
        "scientific_scope": "ENGINEERING_SMOKE_ONLY",
        "formal_training_started": False,
        "sealed_or_blind_accessed": False,
        "all_losses_finite": all_finite,
        "fp32_batches": config.fp32_batches,
        "completed_updates": config.benchmark_updates,
        "parameter_count": parameter_count,
        "wall_seconds": wall_seconds,
        "updates_per_second": config.benchmark_updates / max(wall_seconds, 1e-9),
        "device": str(device),
        "peak_vram_bytes": peak_vram,
        "config_sha256": config.sha256(),
        "generation": generation_summary,
    }
    _write_json(output_root / "smoke_exit.json", summary)
    return summary
