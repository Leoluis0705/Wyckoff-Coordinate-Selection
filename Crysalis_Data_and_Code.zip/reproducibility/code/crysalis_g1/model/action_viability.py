from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass
from types import MappingProxyType
from typing import Literal, Protocol, Sequence

import torch
from torch import nn

FeatureMode = Literal["GRAPH_VIABILITY", "FINAL_SET_MEMBERSHIP"]

MAX_ATOMIC_NUMBER = 118
MAX_SPACE_GROUP = 230
MAX_SITES = 20
WYCKOFF_LETTERS = "abcdefghijklmnopqrstuvwxyz"

_FEATURE_BLOCK_SIZES = (
    ("target_space_group", MAX_SPACE_GROUP),
    ("full_composition", MAX_ATOMIC_NUMBER),
    ("remaining_composition", MAX_ATOMIC_NUMBER),
    ("current_wyckoff", len(WYCKOFF_LETTERS)),
    ("current_species", MAX_ATOMIC_NUMBER),
    ("current_multiplicity", MAX_SITES),
    ("lattice", 6),
    ("progress", 3),
    ("action_wyckoff", len(WYCKOFF_LETTERS)),
    ("action_species", MAX_ATOMIC_NUMBER),
    ("action_multiplicity", 1),
    ("action_free_parameter_count", 1),
)


def _block_slices() -> MappingProxyType[str, slice]:
    offset = 0
    blocks: dict[str, slice] = {}
    for name, width in _FEATURE_BLOCK_SIZES:
        blocks[name] = slice(offset, offset + width)
        offset += width
    return MappingProxyType(blocks)


FEATURE_BLOCK_SLICES = _block_slices()
FEATURE_DIMENSION = sum(width for _, width in _FEATURE_BLOCK_SIZES)


class SafeActionDescription(Protocol):
    operator: str
    wyckoff_letter: str
    atomic_number: int
    multiplicity: int
    free_parameter_count: int


@dataclass(frozen=True, slots=True)
class CurrentOrbitSummary:
    wyckoff_letter: str
    atomic_number: int
    multiplicity: int

    def __post_init__(self) -> None:
        _wyckoff_index(self.wyckoff_letter)
        if not 1 <= self.atomic_number <= MAX_ATOMIC_NUMBER:
            raise ValueError("atomic_number must be in 1..118")
        if not 1 <= self.multiplicity <= MAX_SITES:
            raise ValueError("multiplicity must be in 1..20")


@dataclass(frozen=True, slots=True)
class ActionViabilityConfig:
    input_dimension: int = FEATURE_DIMENSION
    hidden_width: int = 64

    def __post_init__(self) -> None:
        if self.input_dimension != FEATURE_DIMENSION:
            raise ValueError("input_dimension must match the frozen feature schema")
        if self.hidden_width <= 0:
            raise ValueError("hidden_width must be positive")


class ActionViabilityScorer(nn.Module):
    """Shared two-layer state/action MLP for both contribution arms."""

    def __init__(self, config: ActionViabilityConfig) -> None:
        super().__init__()
        self.config = config
        self.input_layer = nn.Linear(config.input_dimension, config.hidden_width)
        self.output_layer = nn.Linear(config.hidden_width, 1)
        self.reset_parameters()

    def reset_parameters(self) -> None:
        nn.init.xavier_uniform_(self.input_layer.weight)
        nn.init.zeros_(self.input_layer.bias)
        nn.init.xavier_uniform_(self.output_layer.weight)
        nn.init.zeros_(self.output_layer.bias)

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        hidden = torch.relu(self.input_layer(features))
        return self.output_layer(hidden).squeeze(-1)

    def trainable_parameter_count(self) -> int:
        return sum(parameter.numel() for parameter in self.parameters())


def state_dict_sha256(model: nn.Module) -> str:
    digest = hashlib.sha256()
    for name, tensor in sorted(model.state_dict().items()):
        value = tensor.detach().cpu().contiguous()
        digest.update(name.encode("utf-8"))
        digest.update(str(tuple(value.shape)).encode("ascii"))
        digest.update(value.numpy().tobytes())
    return digest.hexdigest()


def _wyckoff_index(letter: str) -> int:
    if len(letter) != 1 or letter not in WYCKOFF_LETTERS:
        raise ValueError("wyckoff_letter must be one lowercase letter")
    return WYCKOFF_LETTERS.index(letter)


def _composition_vector(
    composition: Sequence[tuple[int, int]],
) -> tuple[list[float], int]:
    vector = [0.0] * MAX_ATOMIC_NUMBER
    total = 0
    seen: set[int] = set()
    for atomic_number, count in composition:
        if atomic_number in seen:
            raise ValueError("composition contains a duplicate atomic number")
        if not 1 <= atomic_number <= MAX_ATOMIC_NUMBER or count < 0:
            raise ValueError("invalid composition entry")
        seen.add(atomic_number)
        vector[atomic_number - 1] = count / MAX_SITES
        total += count
    if total > MAX_SITES:
        raise ValueError("composition exceeds the frozen maximum-sites contract")
    return vector, total


def _action_vector(action: SafeActionDescription) -> list[float]:
    if action.operator != "D_orbit":
        raise ValueError("action scorer supports only D_orbit descriptions")
    if not 1 <= action.atomic_number <= MAX_ATOMIC_NUMBER:
        raise ValueError("action atomic_number must be in 1..118")
    if not 1 <= action.multiplicity <= MAX_SITES:
        raise ValueError("action multiplicity must be in 1..20")
    if not 0 <= action.free_parameter_count <= 3:
        raise ValueError("action free_parameter_count must be in 0..3")
    values = [0.0] * (len(WYCKOFF_LETTERS) + MAX_ATOMIC_NUMBER + 2)
    values[_wyckoff_index(action.wyckoff_letter)] = 1.0
    species_offset = len(WYCKOFF_LETTERS)
    values[species_offset + action.atomic_number - 1] = 1.0
    values[-2] = action.multiplicity / MAX_SITES
    values[-1] = action.free_parameter_count / 3.0
    return values


def _lattice_vector(lattice_degrees: Sequence[float]) -> list[float]:
    if len(lattice_degrees) != 6:
        raise ValueError("lattice_degrees must contain a, b, c, alpha, beta, gamma")
    values = [float(value) for value in lattice_degrees]
    if not all(math.isfinite(value) for value in values):
        raise FloatingPointError("non-finite lattice degree")
    if any(value <= 0.0 for value in values[:3]):
        raise ValueError("lattice lengths must be positive")
    if any(not 0.0 < value <= 180.0 for value in values[3:]):
        raise ValueError("lattice angles must be in (0, 180]")
    return [value / MAX_SITES for value in values[:3]] + [
        value / 180.0 for value in values[3:]
    ]


def encode_state_action_features(
    *,
    mode: FeatureMode,
    target_space_group: int,
    full_composition: Sequence[tuple[int, int]],
    remaining_composition: Sequence[tuple[int, int]],
    present_orbits: Sequence[CurrentOrbitSummary],
    lattice_degrees: Sequence[float],
    action: SafeActionDescription,
) -> torch.Tensor:
    """Encode only structural values available to both scorer arms."""

    if mode not in ("GRAPH_VIABILITY", "FINAL_SET_MEMBERSHIP"):
        raise ValueError("unknown action-viability feature mode")
    if not 1 <= target_space_group <= MAX_SPACE_GROUP:
        raise ValueError("target_space_group must be in 1..230")
    full_vector, full_sites = _composition_vector(full_composition)
    remaining_vector, remaining_sites = _composition_vector(remaining_composition)
    if remaining_sites > full_sites:
        raise ValueError("remaining composition exceeds full composition")

    target_vector = [0.0] * MAX_SPACE_GROUP
    target_vector[target_space_group - 1] = 1.0
    current_wyckoff = [0.0] * len(WYCKOFF_LETTERS)
    current_species = [0.0] * MAX_ATOMIC_NUMBER
    current_multiplicity = [0.0] * MAX_SITES
    present_sites = 0
    for orbit in present_orbits:
        current_wyckoff[_wyckoff_index(orbit.wyckoff_letter)] += 1.0 / MAX_SITES
        current_species[orbit.atomic_number - 1] += orbit.multiplicity / MAX_SITES
        current_multiplicity[orbit.multiplicity - 1] += 1.0 / MAX_SITES
        present_sites += orbit.multiplicity
    if present_sites > MAX_SITES or len(present_orbits) > MAX_SITES:
        raise ValueError("present orbits exceed the frozen maximum-sites contract")

    progress = [
        present_sites / MAX_SITES,
        remaining_sites / MAX_SITES,
        len(present_orbits) / MAX_SITES,
    ]
    if mode == "FINAL_SET_MEMBERSHIP":
        remaining_vector = [0.0] * MAX_ATOMIC_NUMBER
        current_wyckoff = [0.0] * len(WYCKOFF_LETTERS)
        current_species = [0.0] * MAX_ATOMIC_NUMBER
        current_multiplicity = [0.0] * MAX_SITES
        progress = [0.0, 0.0, 0.0]

    encoded = torch.tensor(
        target_vector
        + full_vector
        + remaining_vector
        + current_wyckoff
        + current_species
        + current_multiplicity
        + _lattice_vector(lattice_degrees)
        + progress
        + _action_vector(action),
        dtype=torch.float32,
    )
    if encoded.shape != (FEATURE_DIMENSION,):
        raise RuntimeError("action-viability feature schema dimension drifted")
    if not bool(torch.isfinite(encoded).all()):
        raise FloatingPointError("non-finite action-viability feature")
    return encoded
