from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn
from torch.nn import functional as F

from crysalis_g1.experiments.c0_symmetry_data import C0SymmetryBatch


@dataclass(frozen=True, slots=True)
class C0SymmetryConfig:
    hidden_dim: int = 96
    num_blocks: int = 3
    radial_basis_count: int = 16
    maximum_orbits: int = 20
    maximum_sites: int = 20
    maximum_cell_index: int = 2
    coordinate_step_scale: float = 0.02

    def __post_init__(self) -> None:
        if self.hidden_dim <= 0 or self.num_blocks <= 0:
            raise ValueError("hidden_dim and num_blocks must be positive")
        if self.radial_basis_count < 2:
            raise ValueError("radial_basis_count must be at least two")
        if (
            self.maximum_orbits <= 0
            or self.maximum_sites <= 0
            or self.maximum_cell_index <= 0
        ):
            raise ValueError("maximum sizes must be positive")


@dataclass(slots=True)
class C0SymmetryOutput:
    terminate_logits: torch.Tensor
    wyckoff_logits: torch.Tensor
    species_logits: torch.Tensor
    free_parameter_prediction: torch.Tensor
    lattice_degree_prediction: torch.Tensor
    cell_index_logits: torch.Tensor
    multiplicity_logits: torch.Tensor
    orbit_free_parameter_delta: torch.Tensor


class _OrbitPeriodicEGNNBlock(nn.Module):
    def __init__(self, hidden_dim: int, radial_basis_count: int) -> None:
        super().__init__()
        edge_dim = hidden_dim * 2 + radial_basis_count
        self.message = nn.Sequential(
            nn.Linear(edge_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(),
        )
        self.node_update = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.coordinate_weight = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, 1, bias=False),
        )
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(
        self,
        hidden: torch.Tensor,
        fractional: torch.Tensor,
        lattice: torch.Tensor,
        node_mask: torch.Tensor,
        radial_centers: torch.Tensor,
        radial_gamma: float,
        coordinate_step_scale: float,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        node_count = hidden.shape[1]
        delta_fractional = fractional[:, None, :, :] - fractional[:, :, None, :]
        delta_fractional = delta_fractional - torch.round(delta_fractional)
        delta_cartesian = torch.einsum(
            "bijd,bdk->bijk", delta_fractional, lattice
        )
        distance = torch.linalg.vector_norm(delta_cartesian, dim=-1)
        radial = torch.exp(
            -radial_gamma
            * (distance[..., None] - radial_centers[None, None, None, :]).square()
        )
        left = hidden[:, :, None, :].expand(-1, -1, node_count, -1)
        right = hidden[:, None, :, :].expand(-1, node_count, -1, -1)
        message = self.message(torch.cat((left, right, radial), dim=-1))
        pair_mask = node_mask[:, :, None] & node_mask[:, None, :]
        identity = torch.eye(node_count, dtype=torch.bool, device=hidden.device)
        pair_mask = pair_mask & ~identity[None, :, :]
        message = message * pair_mask[..., None]
        degree = pair_mask.sum(dim=2, keepdim=True).clamp_min(1).to(hidden.dtype)
        aggregate = message.sum(dim=2) / degree
        hidden = self.norm(
            hidden + self.node_update(torch.cat((hidden, aggregate), dim=-1))
        )
        hidden = hidden * node_mask[..., None]
        coefficient = self.coordinate_weight(message)
        cartesian_update = (coefficient * delta_cartesian).sum(dim=2) / degree
        inverse_lattice = torch.linalg.inv(lattice)
        fractional_update = torch.einsum(
            "bid,bdk->bik", cartesian_update, inverse_lattice
        )
        fractional = torch.remainder(
            fractional
            + coordinate_step_scale * fractional_update * node_mask[..., None],
            1.0,
        )
        return hidden, fractional


class C0SymmetryModel(nn.Module):
    """Orbit-manifold C0 policy; equivalent atomic sites are never model nodes."""

    def __init__(self, config: C0SymmetryConfig) -> None:
        super().__init__()
        self.config = config
        hidden = config.hidden_dim
        self.species_embedding = nn.Embedding(119, 24, padding_idx=0)
        self.wyckoff_embedding = nn.Embedding(26, 16)
        self.multiplicity_embedding = nn.Embedding(
            config.maximum_sites + 1, 12, padding_idx=0
        )
        self.space_group_embedding = nn.Embedding(231, 32, padding_idx=0)
        self.composition_encoder = nn.Sequential(
            nn.Linear(236, hidden), nn.SiLU(), nn.Linear(hidden, hidden)
        )
        self.condition_encoder = nn.Sequential(
            nn.Linear(hidden + 32 + 1 + 6, hidden),
            nn.SiLU(),
            nn.Linear(hidden, hidden),
        )
        self.node_input = nn.Sequential(
            nn.Linear(24 + 16 + 12 + 3 + hidden, hidden),
            nn.SiLU(),
            nn.Linear(hidden, hidden),
        )
        self.blocks = nn.ModuleList(
            _OrbitPeriodicEGNNBlock(hidden, config.radial_basis_count)
            for _ in range(config.num_blocks)
        )
        self.empty_orbit = nn.Parameter(torch.zeros(hidden))
        self.pool_norm = nn.LayerNorm(hidden * 2)
        self.terminate_head = nn.Linear(hidden * 2, 2)
        self.wyckoff_head = nn.Linear(hidden * 2, 26)
        self.species_head = nn.Linear(hidden * 2, 119)
        self.free_parameter_head = nn.Linear(hidden * 2, 3)
        self.lattice_head = nn.Linear(hidden * 2, 6)
        self.cell_index_head = nn.Linear(
            hidden * 2, config.maximum_cell_index + 1
        )
        self.multiplicity_head = nn.Linear(hidden * 2, config.maximum_sites + 1)
        self.orbit_free_delta_head = nn.Linear(hidden, 3)
        centers = torch.linspace(0.0, 8.0, config.radial_basis_count)
        self.register_buffer("radial_centers", centers)
        spacing = float(centers[1] - centers[0])
        self.radial_gamma = 1.0 / (spacing * spacing)

    def forward(self, batch: C0SymmetryBatch) -> C0SymmetryOutput:
        composition = torch.cat(
            (batch.composition[:, 1:], batch.remaining_composition[:, 1:]), dim=-1
        ) / float(self.config.maximum_sites)
        composition_context = self.composition_encoder(composition)
        condition = self.condition_encoder(
            torch.cat(
                (
                    composition_context,
                    self.space_group_embedding(batch.target_space_group),
                    batch.progress,
                    batch.lattice_degrees,
                ),
                dim=-1,
            )
        )
        node_condition = condition[:, None, :].expand(
            -1, batch.orbit_species.shape[1], -1
        )
        node = torch.cat(
            (
                self.species_embedding(batch.orbit_species),
                self.wyckoff_embedding(batch.orbit_wyckoff),
                self.multiplicity_embedding(batch.orbit_multiplicity),
                batch.orbit_free_parameters,
                node_condition,
            ),
            dim=-1,
        )
        hidden = self.node_input(node) * batch.orbit_mask[..., None]
        fractional = batch.orbit_fractional_coordinates
        for block in self.blocks:
            hidden, fractional = block(
                hidden,
                fractional,
                batch.lattice,
                batch.orbit_mask,
                self.radial_centers,
                self.radial_gamma,
                self.config.coordinate_step_scale,
            )
        count = batch.orbit_mask.sum(dim=1, keepdim=True).clamp_min(1).to(hidden.dtype)
        pooled = hidden.sum(dim=1) / count
        has_orbit = batch.orbit_mask.any(dim=1, keepdim=True)
        pooled = torch.where(has_orbit, pooled, self.empty_orbit[None, :])
        global_state = self.pool_norm(torch.cat((condition, pooled), dim=-1))
        wyckoff_logits = self.wyckoff_head(global_state).masked_fill(
            ~batch.legal_wyckoff_mask, -1e9
        )
        species_logits = self.species_head(global_state).masked_fill(
            ~batch.legal_species_mask, -1e9
        )
        orbit_delta = (
            0.05
            * torch.tanh(self.orbit_free_delta_head(hidden))
            * batch.orbit_mask[..., None]
        )
        return C0SymmetryOutput(
            terminate_logits=self.terminate_head(global_state),
            wyckoff_logits=wyckoff_logits,
            species_logits=species_logits,
            free_parameter_prediction=torch.sigmoid(
                self.free_parameter_head(global_state)
            ),
            lattice_degree_prediction=self.lattice_head(global_state),
            cell_index_logits=self.cell_index_head(global_state),
            multiplicity_logits=self.multiplicity_head(global_state),
            orbit_free_parameter_delta=orbit_delta,
        )

    def trainable_parameter_count(self) -> int:
        return sum(parameter.numel() for parameter in self.parameters())


def _masked_mean(values: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    active = mask.to(values.dtype)
    return (values * active).sum() / active.sum().clamp_min(1.0)


def compute_c0_symmetry_losses(
    output: C0SymmetryOutput, batch: C0SymmetryBatch
) -> dict[str, torch.Tensor]:
    termination = F.cross_entropy(output.terminate_logits, batch.target_terminate)
    action = batch.target_terminate == 0
    if action.any():
        wyckoff = F.cross_entropy(
            output.wyckoff_logits[action], batch.target_wyckoff[action]
        )
        species = F.cross_entropy(
            output.species_logits[action], batch.target_species[action]
        )
        multiplicity = F.cross_entropy(
            output.multiplicity_logits[action], batch.target_multiplicity[action]
        )
    else:
        zero = output.terminate_logits.sum() * 0.0
        wyckoff = zero
        species = zero
        multiplicity = zero
    free_error = (
        output.free_parameter_prediction - batch.target_free_parameters
    ).square()
    free_parameters = _masked_mean(
        free_error, batch.target_free_parameter_mask & action[:, None]
    )
    lattice = F.smooth_l1_loss(
        output.lattice_degree_prediction, batch.target_lattice_degrees
    )
    cell_index = F.cross_entropy(output.cell_index_logits, batch.target_cell_index)
    orbit_geometry_regularization = output.orbit_free_parameter_delta.square().mean()
    total = (
        termination
        + wyckoff
        + species
        + 0.5 * multiplicity
        + 2.0 * free_parameters
        + lattice
        + 0.5 * cell_index
        + 0.01 * orbit_geometry_regularization
    )
    if not torch.isfinite(total):
        raise FloatingPointError("non-finite C0-Symmetry loss")
    return {
        "total": total,
        "termination": termination,
        "wyckoff": wyckoff,
        "species": species,
        "multiplicity": multiplicity,
        "free_parameters": free_parameters,
        "lattice": lattice,
        "cell_index": cell_index,
        "orbit_geometry_regularization": orbit_geometry_regularization,
    }
