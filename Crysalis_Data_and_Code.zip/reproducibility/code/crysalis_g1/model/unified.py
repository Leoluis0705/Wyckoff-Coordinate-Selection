from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

import torch
from torch import nn

from crysalis_g1.actions import ActionType


@dataclass(frozen=True)
class ArmSwitches:
    use_relation_memory: bool
    use_relation_library: bool
    use_stepwise_physics: bool

    @classmethod
    def for_arm(cls, arm_id: str) -> ArmSwitches:
        matrix = {
            "C0": cls(False, False, False),
            "C1": cls(True, False, False),
            "C2": cls(True, True, False),
            "C3-Full": cls(True, True, True),
            "C1-P": cls(True, False, True),
        }
        try:
            return matrix[arm_id]
        except KeyError as error:
            raise ValueError(f"unknown Crysalis-G1 arm: {arm_id}") from error


@dataclass(frozen=True)
class UnifiedG1Config:
    schema_version: str
    implementation_scope: str
    arm_id: str
    use_relation_memory: bool
    use_relation_library: bool
    use_stepwise_physics: bool
    composition_dim: int
    condition_dim: int
    orbit_invariant_dim: int
    relation_invariant_dim: int
    guide_physics_dim: int
    hidden_dim: int
    relation_prior_dim: int
    relation_memory_dim: int
    action_count: int
    termination_action_index: int
    projector_min_distance: float
    relation_library_backend: str
    relation_library_artifact_sha256: str
    phase2b_model_implementation_authorized: bool
    server_deployment_authorized: bool
    formal_training_started: bool
    three_seed_authorized: bool

    def __post_init__(self) -> None:
        if self.schema_version != "g1-unified-skeleton.1.0.0":
            raise ValueError("unsupported unified model schema")
        if self.implementation_scope != "LOCAL_MODEL_SKELETON_PREFLIGHT_ONLY":
            raise ValueError("unified model is restricted to local skeleton preflight")
        expected = ArmSwitches.for_arm(self.arm_id)
        received = ArmSwitches(
            self.use_relation_memory,
            self.use_relation_library,
            self.use_stepwise_physics,
        )
        if received != expected:
            raise ValueError(f"arm switch matrix mismatch for {self.arm_id}")
        if not self.phase2b_model_implementation_authorized:
            raise ValueError("Phase 2B model implementation is not authorized")
        if self.server_deployment_authorized:
            raise ValueError("local preflight cannot authorize server deployment")
        if self.formal_training_started:
            raise ValueError("local preflight cannot start formal training")
        if self.three_seed_authorized:
            raise ValueError("local preflight cannot authorize three seeds")
        dimensions = (
            self.composition_dim,
            self.condition_dim,
            self.orbit_invariant_dim,
            self.relation_invariant_dim,
            self.guide_physics_dim,
            self.hidden_dim,
            self.relation_prior_dim,
            self.relation_memory_dim,
            self.action_count,
        )
        if any(type(value) is not int or value <= 0 for value in dimensions):
            raise ValueError("all model dimensions must be positive integers")
        if self.composition_dim != 119:
            raise ValueError("composition schema width must be 119")
        if self.relation_invariant_dim != 11:
            raise ValueError("continuous relation invariant schema width must be 11")
        if self.action_count != len(ActionType):
            raise ValueError("action count must match the typed action registry")
        if self.termination_action_index != list(ActionType).index(ActionType.TERMINATE):
            raise ValueError("termination action index must match ActionType.TERMINATE")
        if not math.isfinite(self.projector_min_distance) or self.projector_min_distance <= 0:
            raise ValueError("projector minimum distance must be finite and positive")
        if self.use_relation_library:
            if not self.use_relation_memory:
                raise ValueError("relation library requires relation memory")
            if self.relation_library_backend not in {
                "student_mlp",
                "matched_mlp",
                "preflight_invariant_mlp",
            }:
                raise ValueError("unsupported relation library backend")
            try:
                digest = bytes.fromhex(self.relation_library_artifact_sha256)
            except ValueError as error:
                raise ValueError("relation library artifact SHA-256 is invalid") from error
            if len(digest) != 32:
                raise ValueError("relation library artifact SHA-256 is invalid")
        elif (
            self.relation_library_backend != "none"
            or self.relation_library_artifact_sha256
        ):
            raise ValueError("disabled relation library must not load an artifact")


@dataclass(frozen=True)
class AssemblyTensorBatch:
    composition: torch.Tensor
    condition_invariants: torch.Tensor
    orbit_invariants: torch.Tensor
    cartesian_positions: torch.Tensor
    node_mask: torch.Tensor
    relation_invariants: torch.Tensor
    relation_availability: torch.Tensor
    relation_vectors: torch.Tensor
    relation_sources: torch.Tensor
    relation_targets: torch.Tensor
    relation_mask: torch.Tensor
    lattice: torch.Tensor
    legal_action_mask: torch.Tensor
    termination_legal: torch.Tensor
    guide_physics_invariants: torch.Tensor
    partial_physics_applicability_mask: torch.Tensor
    relation_memory: torch.Tensor
    space_group: torch.Tensor

    def to(self, device: torch.device | str) -> AssemblyTensorBatch:
        return AssemblyTensorBatch(
            **{
                field: getattr(self, field).to(device)
                for field in self.__dataclass_fields__
            }
        )


@dataclass(frozen=True)
class ProjectionResult:
    positions: torch.Tensor
    lattice: torch.Tensor
    pre_valid: torch.Tensor
    post_valid: torch.Tensor
    rejected: torch.Tensor
    correction_amount: torch.Tensor
    reason_codes: tuple[tuple[str, ...], ...]


@dataclass(frozen=True)
class UnifiedG1Output:
    embryo_state: torch.Tensor
    action_logits: torch.Tensor
    compiled_action_mask: torch.Tensor
    lattice_metric: torch.Tensor
    geometry_delta: torch.Tensor
    pre_projector_positions: torch.Tensor
    projected_positions: torch.Tensor
    projected_lattice: torch.Tensor
    termination_logit: torch.Tensor
    relation_prior: torch.Tensor
    physics_feedback: torch.Tensor
    physics_applied_mask: torch.Tensor
    next_relation_memory: torch.Tensor
    projector_result: ProjectionResult


def _masked_mean(values: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    weights = mask.to(values.dtype).unsqueeze(-1)
    denominator = weights.sum(dim=1).clamp_min(1.0)
    return (values * weights).sum(dim=1) / denominator


class MaterialEmbryoPlanner(nn.Module):
    """Creates a parent-free embryo representation from composition and conditions."""

    def __init__(self, composition_dim: int, condition_dim: int, hidden_dim: int) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(composition_dim + condition_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )

    def forward(
        self, composition: torch.Tensor, condition_invariants: torch.Tensor
    ) -> torch.Tensor:
        return self.network(torch.cat((composition, condition_invariants), dim=-1))


class InvariantRelationLibrary(nn.Module):
    """Read-only cross-sample relation prior; it has no directional input lane."""

    def __init__(
        self, relation_invariant_dim: int, hidden_dim: int, relation_prior_dim: int
    ) -> None:
        super().__init__()
        self.relation_invariant_dim = relation_invariant_dim
        self.network = nn.Sequential(
            nn.Linear(relation_invariant_dim * 2, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, relation_prior_dim),
        )

    def forward(
        self,
        relation_invariants: torch.Tensor,
        relation_availability: torch.Tensor,
        relation_mask: torch.Tensor,
    ) -> torch.Tensor:
        if relation_invariants.ndim != 3 or relation_invariants.shape[-1] != (
            self.relation_invariant_dim
        ):
            raise ValueError(
                f"relation invariant width must be {self.relation_invariant_dim}"
            )
        if relation_availability.shape != relation_invariants.shape:
            raise ValueError("relation availability must match invariant shape")
        if relation_availability.dtype is not torch.bool:
            raise ValueError("relation availability must be boolean")
        if relation_mask.shape != relation_invariants.shape[:2]:
            raise ValueError("relation mask shape mismatch")
        available_values = torch.where(
            relation_availability,
            relation_invariants,
            torch.zeros_like(relation_invariants),
        )
        invariant_lane = torch.cat(
            (available_values, relation_availability.to(relation_invariants.dtype)),
            dim=-1,
        )
        return self.network(invariant_lane) * relation_mask.unsqueeze(-1)


class PhysicsFeedbackOperator(nn.Module):
    """GuideMLIP feedback adapter; it never receives or returns a structure state."""

    def __init__(self, guide_dim: int, hidden_dim: int, feedback_dim: int) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(guide_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, feedback_dim),
            nn.Tanh(),
        )

    def forward(
        self,
        guide_invariants: torch.Tensor,
        applicability_mask: torch.Tensor,
        *,
        enabled: bool,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        applied = applicability_mask if enabled else torch.zeros_like(applicability_mask)
        if enabled:
            feedback = self.network(guide_invariants) * applied.unsqueeze(-1)
        else:
            feedback = guide_invariants.new_zeros(
                (guide_invariants.shape[0], self.network[-2].out_features)
            )
        return feedback, applied


class TrajectoryRelationMemory(nn.Module):
    """Updates caller-owned per-rollout state without retaining samples internally."""

    def __init__(
        self,
        relation_invariant_dim: int,
        relation_prior_dim: int,
        feedback_dim: int,
        memory_dim: int,
    ) -> None:
        super().__init__()
        self.memory_dim = memory_dim
        self.updater = nn.GRUCell(
            relation_invariant_dim + relation_prior_dim + feedback_dim,
            memory_dim,
        )

    def forward(
        self,
        current_memory: torch.Tensor,
        pooled_relation_invariants: torch.Tensor,
        pooled_relation_prior: torch.Tensor,
        physics_feedback: torch.Tensor,
        *,
        enabled: bool,
    ) -> torch.Tensor:
        if not enabled:
            return current_memory.new_zeros(current_memory.shape)
        updater_input = torch.cat(
            (
                pooled_relation_invariants,
                pooled_relation_prior,
                physics_feedback,
            ),
            dim=-1,
        )
        return self.updater(updater_input, current_memory)


class OrbitLevelAssemblyPolicy(nn.Module):
    """Independent inverse-action policy; it does not invert the relation library."""

    def __init__(
        self,
        orbit_invariant_dim: int,
        hidden_dim: int,
        relation_prior_dim: int,
        relation_memory_dim: int,
        action_count: int,
    ) -> None:
        super().__init__()
        self.orbit_encoder = nn.Sequential(
            nn.Linear(orbit_invariant_dim, hidden_dim),
            nn.SiLU(),
        )
        self.context = nn.Sequential(
            nn.Linear(
                hidden_dim * 2 + relation_prior_dim + relation_memory_dim,
                hidden_dim,
            ),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(),
        )
        self.action_head = nn.Linear(hidden_dim, action_count)

    def forward(
        self,
        embryo_state: torch.Tensor,
        orbit_invariants: torch.Tensor,
        node_mask: torch.Tensor,
        relation_prior: torch.Tensor,
        relation_mask: torch.Tensor,
        current_relation_memory: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        orbit_state = _masked_mean(self.orbit_encoder(orbit_invariants), node_mask)
        prior_state = _masked_mean(relation_prior, relation_mask)
        context = self.context(
            torch.cat(
                (embryo_state, orbit_state, prior_state, current_relation_memory),
                dim=-1,
            )
        )
        return self.action_head(context), context


class LegalActionCompiler(nn.Module):
    """Applies the typed pre-sampling legality set without learned repair."""

    def __init__(self, termination_action_index: int) -> None:
        super().__init__()
        self.termination_action_index = termination_action_index

    def forward(
        self,
        action_logits: torch.Tensor,
        legal_action_mask: torch.Tensor,
        termination_legal: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        compiled = legal_action_mask.clone()
        compiled[:, self.termination_action_index] &= termination_legal
        if not compiled.any(dim=1).all():
            raise ValueError("every sample must retain at least one legal action")
        return action_logits.masked_fill(~compiled, -torch.inf), compiled


class LatticeHead(nn.Module):
    """Produces an SPD metric update and its canonical lower-triangular lattice."""

    def __init__(self, hidden_dim: int) -> None:
        super().__init__()
        self.update_head = nn.Linear(hidden_dim, 6)

    def forward(
        self, context: torch.Tensor, current_lattice: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        raw = self.update_head(context)
        update_factor = raw.new_zeros((raw.shape[0], 3, 3))
        update_factor[:, 0, 0] = raw[:, 0]
        update_factor[:, 1, 0] = raw[:, 1]
        update_factor[:, 1, 1] = raw[:, 2]
        update_factor[:, 2, 0] = raw[:, 3]
        update_factor[:, 2, 1] = raw[:, 4]
        update_factor[:, 2, 2] = raw[:, 5]
        base_metric = current_lattice @ current_lattice.transpose(-1, -2)
        metric = base_metric + update_factor @ update_factor.transpose(-1, -2)
        epsilon = torch.finfo(metric.dtype).eps
        metric = metric + torch.eye(3, device=metric.device, dtype=metric.dtype) * epsilon
        return metric, torch.linalg.cholesky(metric)


class PeriodicEquivariantGeometryGenerator(nn.Module):
    """Exact scalar-weighted l=1 message passing used by the local preflight.

    Direction vectors stay in the vector lane. Ordinary neural layers see only
    rotation-invariant relation and orbit features.
    """

    def __init__(
        self, relation_invariant_dim: int, orbit_invariant_dim: int, hidden_dim: int
    ) -> None:
        super().__init__()
        self.relation_invariant_dim = relation_invariant_dim
        self.edge_scalar = nn.Sequential(
            nn.Linear(relation_invariant_dim * 2, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, 1, bias=False),
        )
        self.node_scalar_gate = nn.Sequential(
            nn.Linear(orbit_invariant_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid(),
        )

    def forward(
        self,
        orbit_invariants: torch.Tensor,
        node_mask: torch.Tensor,
        relation_invariants: torch.Tensor,
        relation_availability: torch.Tensor,
        relation_vectors: torch.Tensor,
        relation_sources: torch.Tensor,
        relation_targets: torch.Tensor,
        relation_mask: torch.Tensor,
    ) -> torch.Tensor:
        available_values = torch.where(
            relation_availability,
            relation_invariants,
            torch.zeros_like(relation_invariants),
        )
        invariant_lane = torch.cat(
            (available_values, relation_availability.to(relation_invariants.dtype)),
            dim=-1,
        )
        coefficient = self.edge_scalar(invariant_lane) * relation_mask[..., None]
        vector_message = coefficient * relation_vectors
        node_count = orbit_invariants.shape[1]
        source_index = relation_sources[..., None].expand(-1, -1, 3)
        target_index = relation_targets[..., None].expand(-1, -1, 3)
        zeros = relation_vectors.new_zeros(
            (relation_vectors.shape[0], node_count, 3)
        )
        incoming = zeros.scatter_add(1, target_index, vector_message)
        outgoing = zeros.scatter_add(1, source_index, vector_message)
        one = coefficient.new_ones(coefficient.shape) * relation_mask[..., None]
        degree = coefficient.new_zeros(
            (coefficient.shape[0], node_count, 1)
        )
        degree = degree.scatter_add(1, relation_sources[..., None], one)
        degree = degree.scatter_add(1, relation_targets[..., None], one)
        gate = self.node_scalar_gate(orbit_invariants)
        return (
            (incoming - outgoing)
            / degree.clamp_min(1.0)
            * gate
            * node_mask[..., None]
        )


class TerminationHead(nn.Module):
    def __init__(self, hidden_dim: int, feedback_dim: int) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(hidden_dim + feedback_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(
        self,
        context: torch.Tensor,
        physics_feedback: torch.Tensor,
        termination_legal: torch.Tensor,
    ) -> torch.Tensor:
        logit = self.network(torch.cat((context, physics_feedback), dim=-1)).squeeze(-1)
        return logit.masked_fill(~termination_legal, -torch.inf)


class CrystallographicTensorProjector(nn.Module):
    """Fail-closed tensor projector with explicit correction and rejection evidence."""

    def __init__(self, *, min_distance: float) -> None:
        super().__init__()
        self.min_distance = float(min_distance)

    def _distance_valid(
        self,
        fractional_positions: torch.Tensor,
        lattice: torch.Tensor,
        node_mask: torch.Tensor,
    ) -> bool:
        active = fractional_positions[node_mask]
        translations = torch.cartesian_prod(
            *(
                torch.tensor(
                    [-1.0, 0.0, 1.0],
                    device=lattice.device,
                    dtype=lattice.dtype,
                )
                for _ in range(3)
            )
        )
        for source in range(active.shape[0]):
            for target in range(source + 1, active.shape[0]):
                delta = active[target] - active[source]
                vectors = (delta[None, :] + translations) @ lattice
                if (
                    float(torch.linalg.vector_norm(vectors, dim=-1).min().detach())
                    < self.min_distance
                ):
                    return False
        return True

    def forward(
        self,
        positions: torch.Tensor,
        lattice: torch.Tensor,
        node_mask: torch.Tensor,
    ) -> ProjectionResult:
        if positions.ndim != 3 or positions.shape[-1] != 3:
            raise ValueError("positions must have shape [batch, nodes, 3]")
        if lattice.shape != (positions.shape[0], 3, 3):
            raise ValueError("lattice must have shape [batch, 3, 3]")
        if node_mask.shape != positions.shape[:2] or node_mask.dtype is not torch.bool:
            raise ValueError("node mask shape or dtype mismatch")
        projected: list[torch.Tensor] = []
        corrections: list[torch.Tensor] = []
        pre_valid: list[bool] = []
        post_valid: list[bool] = []
        reasons: list[tuple[str, ...]] = []
        for row in range(positions.shape[0]):
            row_positions = positions[row]
            row_lattice = lattice[row]
            row_mask = node_mask[row]
            row_reasons: list[str] = []
            finite = bool(
                torch.isfinite(row_lattice).all()
                and torch.isfinite(row_positions[row_mask]).all()
            )
            determinant = (
                float(torch.linalg.det(row_lattice).detach()) if finite else 0.0
            )
            if not finite:
                row_reasons.append("NONFINITE_STATE")
            if not finite or abs(determinant) <= torch.finfo(row_lattice.dtype).eps:
                row_reasons.append("SINGULAR_LATTICE")
                projected.append(row_positions)
                corrections.append(row_positions.new_zeros(()))
                pre_valid.append(False)
                post_valid.append(False)
                reasons.append(tuple(dict.fromkeys(row_reasons)))
                continue
            inverse = torch.linalg.inv(row_lattice)
            fractional = row_positions @ inverse
            active_fractional = fractional[row_mask]
            inside = bool(
                ((active_fractional >= 0.0) & (active_fractional < 1.0)).all()
            )
            distance_valid_before = self._distance_valid(
                fractional, row_lattice, row_mask
            )
            if not inside:
                row_reasons.append("OUTSIDE_UNIT_CELL")
            if not distance_valid_before:
                row_reasons.append("MIN_DISTANCE_VIOLATION")
            pre_valid.append(inside and distance_valid_before)
            if inside:
                wrapped_fractional = fractional
                corrected = row_positions
            else:
                wrapped_fractional = fractional - torch.floor(fractional)
                corrected = wrapped_fractional @ row_lattice
            distance_valid_after = self._distance_valid(
                wrapped_fractional, row_lattice, row_mask
            )
            accepted = bool(distance_valid_after)
            if not distance_valid_after and "MIN_DISTANCE_VIOLATION" not in row_reasons:
                row_reasons.append("MIN_DISTANCE_VIOLATION")
            post_valid.append(accepted)
            if accepted:
                projected.append(corrected)
                displacement = torch.linalg.vector_norm(
                    corrected[row_mask] - row_positions[row_mask], dim=-1
                )
                corrections.append(displacement.mean())
            else:
                projected.append(row_positions)
                corrections.append(row_positions.new_zeros(()))
            reasons.append(tuple(row_reasons))
        pre_tensor = torch.tensor(pre_valid, device=positions.device, dtype=torch.bool)
        post_tensor = torch.tensor(post_valid, device=positions.device, dtype=torch.bool)
        return ProjectionResult(
            positions=torch.stack(projected),
            lattice=lattice,
            pre_valid=pre_tensor,
            post_valid=post_tensor,
            rejected=~post_tensor,
            correction_amount=torch.stack(corrections),
            reason_codes=tuple(reasons),
        )


def summarize_projector_metrics(
    result: ProjectionResult, space_group: torch.Tensor
) -> dict[str, Any]:
    if space_group.shape != result.pre_valid.shape:
        raise ValueError("space group shape must match projector batch")

    def summarize(indices: torch.Tensor) -> dict[str, float]:
        pre = result.pre_valid[indices].float()
        post = result.post_valid[indices].float()
        rejected = result.rejected[indices].float()
        correction = result.correction_amount[indices].detach().float()
        return {
            "pre_valid_rate": float(pre.mean()),
            "post_valid_rate": float(post.mean()),
            "rejection_rate": float(rejected.mean()),
            "correction_rate": float((correction > 1e-8).float().mean()),
            "correction_amount_mean": float(correction.mean()),
            "correction_amount_p50": float(torch.quantile(correction, 0.50)),
            "correction_amount_p95": float(torch.quantile(correction, 0.95)),
        }

    all_indices = torch.arange(space_group.shape[0], device=space_group.device)
    by_space_group: dict[str, dict[str, float]] = {}
    for value in sorted(set(int(item) for item in space_group.detach().cpu().tolist())):
        by_space_group[str(value)] = summarize(
            torch.nonzero(space_group == value, as_tuple=False).squeeze(-1)
        )
    macro = {
        key: sum(group[key] for group in by_space_group.values())
        / len(by_space_group)
        for key in next(iter(by_space_group.values()))
    }
    return {
        "micro": summarize(all_indices),
        "by_space_group": by_space_group,
        "space_group_macro": macro,
    }


class UnifiedCrysalisG1(nn.Module):
    """Unified Crysalis-G1 generator skeleton shared by all authorized arms."""

    def __init__(self, config: UnifiedG1Config) -> None:
        super().__init__()
        self.config = config
        self.material_embryo_planner = MaterialEmbryoPlanner(
            config.composition_dim, config.condition_dim, config.hidden_dim
        )
        self.relation_library = InvariantRelationLibrary(
            config.relation_invariant_dim,
            config.hidden_dim,
            config.relation_prior_dim,
        )
        self.orbit_level_assembly_policy = OrbitLevelAssemblyPolicy(
            config.orbit_invariant_dim,
            config.hidden_dim,
            config.relation_prior_dim,
            config.relation_memory_dim,
            config.action_count,
        )
        self.legal_action_compiler = LegalActionCompiler(
            config.termination_action_index
        )
        self.lattice_head = LatticeHead(config.hidden_dim)
        self.periodic_equivariant_geometry_generator = (
            PeriodicEquivariantGeometryGenerator(
                config.relation_invariant_dim,
                config.orbit_invariant_dim,
                config.hidden_dim,
            )
        )
        self.physics_feedback_operator = PhysicsFeedbackOperator(
            config.guide_physics_dim,
            config.hidden_dim,
            config.relation_memory_dim,
        )
        self.trajectory_relation_memory = TrajectoryRelationMemory(
            config.relation_invariant_dim,
            config.relation_prior_dim,
            config.relation_memory_dim,
            config.relation_memory_dim,
        )
        self.termination_head = TerminationHead(
            config.hidden_dim, config.relation_memory_dim
        )
        self.crystallographic_projector = CrystallographicTensorProjector(
            min_distance=config.projector_min_distance
        )
        for parameter in self.relation_library.parameters():
            parameter.requires_grad_(False)
        if not config.use_relation_memory:
            for parameter in self.trajectory_relation_memory.parameters():
                parameter.requires_grad_(False)
        if not config.use_stepwise_physics:
            for parameter in self.physics_feedback_operator.parameters():
                parameter.requires_grad_(False)

    @staticmethod
    def module_contract() -> dict[str, str]:
        return {
            "material_embryo_planner": "CORE_GENERATOR",
            "orbit_level_assembly_policy": "CORE_GENERATOR",
            "lattice_head": "CORE_GENERATOR",
            "periodic_equivariant_geometry_generator": "CORE_GENERATOR",
            "termination_head": "CORE_GENERATOR",
            "legal_action_compiler": "CORE_GENERATOR",
            "crystallographic_projector": "CORE_GENERATOR",
            "trajectory_relation_memory": "OPTIONAL_PER_SAMPLE_STATE",
            "relation_library": "OPTIONAL_READ_ONLY_PRIOR",
            "physics_feedback_operator": "OPTIONAL_READ_ONLY_FEEDBACK",
        }

    @staticmethod
    def state_lifecycle_contract() -> dict[str, str]:
        return {
            "relation_library": "CROSS_SAMPLE_READ_ONLY_ARTIFACT",
            "relation_memory": "PER_ROLLOUT_PER_SAMPLE_DYNAMIC_STATE",
        }

    @staticmethod
    def physics_backend_contract() -> dict[str, str]:
        return {
            "generation_feedback": "GuideMLIP",
            "terminal_evaluation": "EvalMLIP_EXTERNAL",
            "high_fidelity_review": "EXTERNAL_NOT_IN_GENERATOR",
        }

    def _validate_batch(self, batch: AssemblyTensorBatch) -> None:
        config = self.config
        if batch.composition.ndim != 2:
            raise ValueError("composition must have shape [batch, features]")
        batch_size = batch.composition.shape[0]
        node_count = batch.orbit_invariants.shape[1]
        relation_count = batch.relation_invariants.shape[1]
        expected_shapes = {
            "composition": (batch_size, config.composition_dim),
            "condition_invariants": (batch_size, config.condition_dim),
            "orbit_invariants": (
                batch_size,
                node_count,
                config.orbit_invariant_dim,
            ),
            "cartesian_positions": (batch_size, node_count, 3),
            "node_mask": (batch_size, node_count),
            "relation_invariants": (
                batch_size,
                relation_count,
                config.relation_invariant_dim,
            ),
            "relation_availability": (
                batch_size,
                relation_count,
                config.relation_invariant_dim,
            ),
            "relation_vectors": (batch_size, relation_count, 3),
            "relation_sources": (batch_size, relation_count),
            "relation_targets": (batch_size, relation_count),
            "relation_mask": (batch_size, relation_count),
            "lattice": (batch_size, 3, 3),
            "legal_action_mask": (batch_size, config.action_count),
            "termination_legal": (batch_size,),
            "guide_physics_invariants": (batch_size, config.guide_physics_dim),
            "partial_physics_applicability_mask": (batch_size,),
            "relation_memory": (batch_size, config.relation_memory_dim),
            "space_group": (batch_size,),
        }
        for name, expected in expected_shapes.items():
            if tuple(getattr(batch, name).shape) != expected:
                raise ValueError(f"{name} shape mismatch: expected {expected}")
        boolean_fields = (
            "node_mask",
            "relation_availability",
            "relation_mask",
            "legal_action_mask",
            "termination_legal",
            "partial_physics_applicability_mask",
        )
        if any(getattr(batch, name).dtype is not torch.bool for name in boolean_fields):
            raise ValueError("all mask fields must be boolean")
        if not batch.node_mask.any(dim=1).all():
            raise ValueError("every sample requires at least one active orbit")
        if not batch.legal_action_mask.any(dim=1).all():
            raise ValueError("every sample requires at least one legal action")
        if (batch.composition < 0).any():
            raise ValueError("composition counts must be non-negative")
        float_fields = (
            "composition",
            "condition_invariants",
            "orbit_invariants",
            "cartesian_positions",
            "relation_invariants",
            "relation_vectors",
            "lattice",
            "guide_physics_invariants",
            "relation_memory",
        )
        if any(not torch.isfinite(getattr(batch, name)).all() for name in float_fields):
            raise ValueError("model inputs must be finite")
        if (batch.space_group < 1).any() or (batch.space_group > 230).any():
            raise ValueError("space group must be in [1, 230]")
        for indices in (batch.relation_sources, batch.relation_targets):
            active = indices[batch.relation_mask]
            if active.numel() and ((active < 0).any() or (active >= node_count).any()):
                raise ValueError("active relation endpoint is out of bounds")

    def forward(self, batch: AssemblyTensorBatch) -> UnifiedG1Output:
        self._validate_batch(batch)
        embryo = self.material_embryo_planner(
            batch.composition, batch.condition_invariants
        )
        if self.config.use_relation_library:
            relation_prior = self.relation_library(
                batch.relation_invariants,
                batch.relation_availability,
                batch.relation_mask,
            )
        else:
            relation_prior = batch.relation_invariants.new_zeros(
                (
                    batch.relation_invariants.shape[0],
                    batch.relation_invariants.shape[1],
                    self.config.relation_prior_dim,
                )
            )
        action_logits, policy_context = self.orbit_level_assembly_policy(
            embryo,
            batch.orbit_invariants,
            batch.node_mask,
            relation_prior,
            batch.relation_mask,
            (
                batch.relation_memory
                if self.config.use_relation_memory
                else torch.zeros_like(batch.relation_memory)
            ),
        )
        action_logits, compiled_action_mask = self.legal_action_compiler(
            action_logits, batch.legal_action_mask, batch.termination_legal
        )
        lattice_metric, candidate_lattice = self.lattice_head(
            policy_context, batch.lattice
        )
        geometry_delta = self.periodic_equivariant_geometry_generator(
            batch.orbit_invariants,
            batch.node_mask,
            batch.relation_invariants,
            batch.relation_availability,
            batch.relation_vectors,
            batch.relation_sources,
            batch.relation_targets,
            batch.relation_mask,
        )
        fractional_positions = batch.cartesian_positions @ torch.linalg.inv(
            batch.lattice
        )
        candidate_positions = fractional_positions @ candidate_lattice + geometry_delta
        projection = self.crystallographic_projector(
            candidate_positions, candidate_lattice, batch.node_mask
        )
        physics_feedback, physics_applied = self.physics_feedback_operator(
            batch.guide_physics_invariants,
            batch.partial_physics_applicability_mask,
            enabled=self.config.use_stepwise_physics,
        )
        available_relations = torch.where(
            batch.relation_availability,
            batch.relation_invariants,
            torch.zeros_like(batch.relation_invariants),
        )
        next_memory = self.trajectory_relation_memory(
            batch.relation_memory,
            _masked_mean(available_relations, batch.relation_mask),
            _masked_mean(relation_prior, batch.relation_mask),
            physics_feedback,
            enabled=self.config.use_relation_memory,
        )
        termination_logit = self.termination_head(
            policy_context, physics_feedback, batch.termination_legal
        )
        return UnifiedG1Output(
            embryo_state=embryo,
            action_logits=action_logits,
            compiled_action_mask=compiled_action_mask,
            lattice_metric=lattice_metric,
            geometry_delta=geometry_delta,
            pre_projector_positions=candidate_positions,
            projected_positions=projection.positions,
            projected_lattice=projection.lattice,
            termination_logit=termination_logit,
            relation_prior=relation_prior,
            physics_feedback=physics_feedback,
            physics_applied_mask=physics_applied,
            next_relation_memory=next_memory,
            projector_result=projection,
        )

    def trainable_parameter_count(self) -> int:
        return sum(
            parameter.numel()
            for parameter in self.parameters()
            if parameter.requires_grad
        )
