from __future__ import annotations

from dataclasses import dataclass, replace
from functools import lru_cache

import torch
from e3nn import nn as e3nn_nn
from e3nn import o3
from torch import nn


@dataclass(frozen=True, slots=True)
class GeometryBackendConfig:
    backend: str
    node_invariant_dim: int
    relation_invariant_dim: int
    num_blocks: int
    radial_basis_count: int
    cutoff_angstrom: float
    coordinate_step_scale: float
    periodic_hidden_dim: int
    e3nn_scalar_channels: int
    e3nn_vector_channels: int
    e3nn_tensor_channels: int
    e3nn_l_max: int

    def __post_init__(self) -> None:
        if self.backend not in {"periodic_egnn", "e3nn_lite"}:
            raise ValueError(f"unsupported geometry backend: {self.backend}")
        positive = (
            self.node_invariant_dim,
            self.relation_invariant_dim,
            self.num_blocks,
            self.radial_basis_count,
        )
        if any(type(value) is not int or value <= 0 for value in positive):
            raise ValueError("geometry dimensions and counts must be positive integers")
        if self.radial_basis_count < 2:
            raise ValueError("radial basis count must be at least two")
        if self.cutoff_angstrom <= 0 or self.coordinate_step_scale <= 0:
            raise ValueError("geometry distance scales must be positive")
        if self.backend == "e3nn_lite":
            if self.num_blocks != 3:
                raise ValueError("e3nn-lite requires exactly three equivariant blocks")
            if self.e3nn_l_max != 2:
                raise ValueError("e3nn-lite requires l_max=2")
            if min(
                self.e3nn_scalar_channels,
                self.e3nn_vector_channels,
                self.e3nn_tensor_channels,
            ) <= 0:
                raise ValueError("e3nn-lite channel counts must be positive")
        elif self.periodic_hidden_dim <= 0:
            raise ValueError("periodic-EGNN hidden width must be positive")


@dataclass(frozen=True, slots=True)
class GeometryBackendBatch:
    node_invariants: torch.Tensor
    node_mask: torch.Tensor
    relation_invariants: torch.Tensor
    relation_availability: torch.Tensor
    relation_vectors: torch.Tensor
    relation_sources: torch.Tensor
    relation_targets: torch.Tensor
    relation_mask: torch.Tensor

    def to(self, device: torch.device | str) -> GeometryBackendBatch:
        return GeometryBackendBatch(
            **{
                name: getattr(self, name).to(device)
                for name in self.__dataclass_fields__
            }
        )


@dataclass(frozen=True, slots=True)
class GeometryParameterMatch:
    periodic_config: GeometryBackendConfig
    e3nn_config: GeometryBackendConfig
    periodic_parameter_count: int
    e3nn_parameter_count: int
    relative_difference: float


class _GeometryBackend(nn.Module):
    geometry_only = True

    def __init__(self, config: GeometryBackendConfig) -> None:
        super().__init__()
        self.config = config
        self.backend_name = config.backend
        self.num_blocks = config.num_blocks

    def _validate(self, batch: GeometryBackendBatch) -> None:
        if batch.node_invariants.ndim != 3:
            raise ValueError("node invariants must have shape [B, N, D]")
        batch_size, node_count, width = batch.node_invariants.shape
        if width != self.config.node_invariant_dim:
            raise ValueError("node invariant width mismatch")
        if batch.node_mask.shape != (batch_size, node_count):
            raise ValueError("node mask shape mismatch")
        if batch.node_mask.dtype is not torch.bool:
            raise ValueError("node mask must be boolean")
        relation_shape = batch.relation_invariants.shape
        if len(relation_shape) != 3 or relation_shape[0] != batch_size:
            raise ValueError("relation invariants must have shape [B, E, D]")
        relation_count = relation_shape[1]
        if relation_shape[2] != self.config.relation_invariant_dim:
            raise ValueError("relation invariant width mismatch")
        if batch.relation_availability.shape != relation_shape:
            raise ValueError("relation availability shape mismatch")
        if batch.relation_availability.dtype is not torch.bool:
            raise ValueError("relation availability must be boolean")
        expected = {
            "relation_vectors": (batch_size, relation_count, 3),
            "relation_sources": (batch_size, relation_count),
            "relation_targets": (batch_size, relation_count),
            "relation_mask": (batch_size, relation_count),
        }
        for name, shape in expected.items():
            if tuple(getattr(batch, name).shape) != shape:
                raise ValueError(f"{name} shape mismatch")
        if batch.relation_mask.dtype is not torch.bool:
            raise ValueError("relation mask must be boolean")
        if not torch.isfinite(batch.node_invariants).all():
            raise ValueError("node invariants must be finite")
        if not torch.isfinite(batch.relation_invariants).all():
            raise ValueError("relation invariants must be finite")
        if not torch.isfinite(batch.relation_vectors).all():
            raise ValueError("relation vectors must be finite")
        for endpoints in (batch.relation_sources, batch.relation_targets):
            active = endpoints[batch.relation_mask]
            if active.numel() and ((active < 0).any() or (active >= node_count).any()):
                raise ValueError("active relation endpoint is out of range")

    def trainable_parameter_count(self) -> int:
        return sum(
            parameter.numel()
            for parameter in self.parameters()
            if parameter.requires_grad
        )


def _edge_tensors(
    batch: GeometryBackendBatch,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    batch_size, node_count = batch.node_mask.shape
    offsets = (
        torch.arange(batch_size, device=batch.relation_sources.device)[:, None]
        * node_count
    )
    active = batch.relation_mask
    source = (batch.relation_sources + offsets)[active]
    target = (batch.relation_targets + offsets)[active]
    vectors = batch.relation_vectors[active]
    values = torch.where(
        batch.relation_availability,
        batch.relation_invariants,
        torch.zeros_like(batch.relation_invariants),
    )[active]
    availability = batch.relation_availability[active].to(values.dtype)
    return (
        torch.cat((source, target)),
        torch.cat((target, source)),
        torch.cat((vectors, -vectors)),
        torch.cat((values, values)),
        torch.cat((availability, availability)),
    )


class _PeriodicEGNNBlock(nn.Module):
    def __init__(self, config: GeometryBackendConfig) -> None:
        super().__init__()
        hidden = config.periodic_hidden_dim
        edge_width = (
            hidden * 2
            + config.relation_invariant_dim * 2
            + config.radial_basis_count
        )
        self.message = nn.Sequential(
            nn.Linear(edge_width, hidden),
            nn.SiLU(),
            nn.Linear(hidden, hidden),
            nn.SiLU(),
        )
        self.node_update = nn.Sequential(
            nn.Linear(hidden * 2, hidden),
            nn.SiLU(),
            nn.Linear(hidden, hidden),
        )
        self.coordinate_weight = nn.Sequential(
            nn.Linear(hidden, hidden),
            nn.SiLU(),
            nn.Linear(hidden, 1, bias=False),
        )
        self.norm = nn.LayerNorm(hidden)

    def forward(
        self,
        features: torch.Tensor,
        source: torch.Tensor,
        target: torch.Tensor,
        vectors: torch.Tensor,
        relation_lane: torch.Tensor,
        radial: torch.Tensor,
        node_mask: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if source.numel() == 0:
            return features, vectors.new_zeros((features.shape[0], 3))
        message = self.message(
            torch.cat(
                (features[source], features[target], relation_lane, radial), dim=-1
            )
        ).to(features.dtype)
        aggregate = features.new_zeros(features.shape).index_add(0, target, message)
        degree = features.new_zeros((features.shape[0], 1)).index_add(
            0, target, torch.ones_like(message[:, :1])
        )
        aggregate = aggregate / degree.clamp_min(1.0)
        features = self.norm(
            features + self.node_update(torch.cat((features, aggregate), dim=-1))
        )
        features = features * node_mask[:, None]
        coefficient = self.coordinate_weight(message)
        coordinate = vectors.new_zeros((features.shape[0], 3)).index_add(
            0, target, coefficient * vectors
        )
        coordinate = coordinate / degree.clamp_min(1.0)
        return features, coordinate * node_mask[:, None]


class PeriodicEGNNGeometry(_GeometryBackend):
    l_max = 1

    def __init__(self, config: GeometryBackendConfig) -> None:
        super().__init__(config)
        hidden = config.periodic_hidden_dim
        self.node_input = nn.Linear(config.node_invariant_dim, hidden)
        self.blocks = nn.ModuleList(_PeriodicEGNNBlock(config) for _ in range(config.num_blocks))
        centers = torch.linspace(0.0, config.cutoff_angstrom, config.radial_basis_count)
        self.register_buffer("radial_centers", centers)
        spacing = config.cutoff_angstrom / (config.radial_basis_count - 1)
        self.radial_gamma = 1.0 / (spacing * spacing)

    def forward(self, batch: GeometryBackendBatch) -> torch.Tensor:
        self._validate(batch)
        batch_size, node_count, _ = batch.node_invariants.shape
        flat_mask = batch.node_mask.reshape(-1)
        features = self.node_input(batch.node_invariants).reshape(
            batch_size * node_count, -1
        )
        features = features * flat_mask[:, None]
        source, target, vectors, values, availability = _edge_tensors(batch)
        distances = torch.linalg.vector_norm(vectors, dim=-1)
        radial = torch.exp(
            -self.radial_gamma
            * (distances[:, None] - self.radial_centers[None, :]).square()
        )
        relation_lane = torch.cat((values, availability), dim=-1)
        total = vectors.new_zeros((batch_size * node_count, 3))
        for block in self.blocks:
            features, delta = block(
                features,
                source,
                target,
                vectors,
                relation_lane,
                radial,
                flat_mask,
            )
            total = total + delta
        return (
            total.reshape(batch_size, node_count, 3)
            * self.config.coordinate_step_scale
        )


class _E3nnConvolutionBlock(nn.Module):
    def __init__(
        self,
        *,
        irreps_hidden: o3.Irreps,
        irreps_sh: o3.Irreps,
        relation_lane_dim: int,
        radial_basis_count: int,
        radial_hidden: int,
    ) -> None:
        super().__init__()
        self.tensor_product = o3.FullyConnectedTensorProduct(
            irreps_hidden,
            irreps_sh,
            irreps_hidden,
            shared_weights=False,
        )
        self.radial_network = nn.Sequential(
            nn.Linear(relation_lane_dim + radial_basis_count, radial_hidden),
            nn.SiLU(),
            nn.Linear(radial_hidden, self.tensor_product.weight_numel),
        )
        self.self_connection = o3.Linear(irreps_hidden, irreps_hidden)
        self.activation = e3nn_nn.NormActivation(
            irreps_hidden,
            scalar_nonlinearity=torch.nn.functional.silu,
            normalize=True,
            epsilon=1e-3,
        )

    def forward(
        self,
        features: torch.Tensor,
        source: torch.Tensor,
        target: torch.Tensor,
        edge_sh: torch.Tensor,
        relation_lane: torch.Tensor,
        radial: torch.Tensor,
        node_mask: torch.Tensor,
    ) -> torch.Tensor:
        residual = self.self_connection(features)
        if source.numel() == 0:
            activated = torch.zeros_like(residual)
            if bool(node_mask.any()):
                activated[node_mask] = self.activation(residual[node_mask]).to(
                    residual.dtype
                )
            return activated
        weights = self.radial_network(torch.cat((relation_lane, radial), dim=-1))
        messages = self.tensor_product(features[source], edge_sh, weights).to(
            features.dtype
        )
        aggregate = features.new_zeros(features.shape).index_add(0, target, messages)
        degree = features.new_zeros((features.shape[0], 1)).index_add(
            0, target, torch.ones_like(messages[:, :1])
        )
        aggregate = aggregate / degree.clamp_min(1.0).sqrt()
        updated = residual + aggregate
        activated = torch.zeros_like(updated)
        if bool(node_mask.any()):
            activated[node_mask] = self.activation(updated[node_mask]).to(
                updated.dtype
            )
        return activated


class E3nnLiteGeometry(_GeometryBackend):
    l_max = 2

    def __init__(self, config: GeometryBackendConfig) -> None:
        super().__init__(config)
        self.irreps_hidden = o3.Irreps(
            f"{config.e3nn_scalar_channels}x0e + "
            f"{config.e3nn_vector_channels}x1o + "
            f"{config.e3nn_tensor_channels}x2e"
        )
        self.irreps_sh = o3.Irreps.spherical_harmonics(config.e3nn_l_max)
        self.input_linear = o3.Linear(
            o3.Irreps(f"{config.node_invariant_dim}x0e"), self.irreps_hidden
        )
        radial_hidden = max(16, config.e3nn_scalar_channels)
        relation_lane_dim = config.relation_invariant_dim * 2
        self.blocks = nn.ModuleList(
            _E3nnConvolutionBlock(
                irreps_hidden=self.irreps_hidden,
                irreps_sh=self.irreps_sh,
                relation_lane_dim=relation_lane_dim,
                radial_basis_count=config.radial_basis_count,
                radial_hidden=radial_hidden,
            )
            for _ in range(config.num_blocks)
        )
        self.vector_output = o3.Linear(self.irreps_hidden, o3.Irreps("1x1o"))
        centers = torch.linspace(0.0, config.cutoff_angstrom, config.radial_basis_count)
        self.register_buffer("radial_centers", centers)
        spacing = config.cutoff_angstrom / (config.radial_basis_count - 1)
        self.radial_gamma = 1.0 / (spacing * spacing)

    def forward(self, batch: GeometryBackendBatch) -> torch.Tensor:
        self._validate(batch)
        batch_size, node_count, _ = batch.node_invariants.shape
        flat_mask = batch.node_mask.reshape(-1)
        features = self.input_linear(
            batch.node_invariants.reshape(batch_size * node_count, -1)
        )
        features = features * flat_mask[:, None]
        source, target, vectors, values, availability = _edge_tensors(batch)
        distances = torch.linalg.vector_norm(vectors, dim=-1)
        radial = torch.exp(
            -self.radial_gamma
            * (distances[:, None] - self.radial_centers[None, :]).square()
        )
        relation_lane = torch.cat((values, availability), dim=-1)
        edge_sh = o3.spherical_harmonics(
            self.irreps_sh,
            vectors,
            normalize=True,
            normalization="component",
        )
        for block in self.blocks:
            features = block(
                features,
                source,
                target,
                edge_sh,
                relation_lane,
                radial,
                flat_mask,
            )
        vector = self.vector_output(features)
        return (
            vector.reshape(batch_size, node_count, 3)
            * flat_mask.reshape(batch_size, node_count, 1)
            * self.config.coordinate_step_scale
        )


def build_geometry_backend(config: GeometryBackendConfig) -> _GeometryBackend:
    if config.backend == "periodic_egnn":
        return PeriodicEGNNGeometry(config)
    return E3nnLiteGeometry(config)


@lru_cache(maxsize=32)
def match_periodic_width(
    e3nn_config: GeometryBackendConfig,
    *,
    maximum_relative_difference: float,
) -> GeometryParameterMatch:
    if e3nn_config.backend != "e3nn_lite":
        raise ValueError("parameter matching requires an e3nn-lite reference")
    if not 0 < maximum_relative_difference < 1:
        raise ValueError("parameter-match tolerance must lie in (0, 1)")
    e3nn_count = build_geometry_backend(e3nn_config).trainable_parameter_count()
    candidates: list[tuple[float, int, GeometryBackendConfig]] = []
    for width in range(4, 513):
        periodic_config = replace(
            e3nn_config,
            backend="periodic_egnn",
            periodic_hidden_dim=width,
            e3nn_scalar_channels=0,
            e3nn_vector_channels=0,
            e3nn_tensor_channels=0,
            e3nn_l_max=0,
        )
        count = build_geometry_backend(periodic_config).trainable_parameter_count()
        difference = abs(count - e3nn_count) / max(e3nn_count, 1)
        candidates.append((difference, count, periodic_config))
    difference, count, periodic_config = min(candidates, key=lambda item: item[:2])
    if difference > maximum_relative_difference:
        raise RuntimeError(
            "no periodic-EGNN width meets parameter-match tolerance: "
            f"best relative difference is {difference:.6f}"
        )
    return GeometryParameterMatch(
        periodic_config=periodic_config,
        e3nn_config=e3nn_config,
        periodic_parameter_count=count,
        e3nn_parameter_count=e3nn_count,
        relative_difference=difference,
    )
