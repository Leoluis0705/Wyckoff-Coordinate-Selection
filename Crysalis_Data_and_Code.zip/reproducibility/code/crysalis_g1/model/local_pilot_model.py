from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Literal

import torch
import torch.nn.functional as F
from torch import nn

from crysalis_g1.actions import ActionType
from crysalis_g1.experiments.local_pilot_data import (
    AssemblyTrainingBatch,
    FORMAL_DECONSTRUCTION_OPERATORS,
)
from crysalis_g1.model.geometry_backends import (
    GeometryBackendBatch,
    GeometryBackendConfig,
    build_geometry_backend,
)
from crysalis_g1.model.unified import (
    CrystallographicTensorProjector,
    ProjectionResult,
)


@dataclass(frozen=True, slots=True)
class PilotArmSwitches:
    use_relation_memory: bool
    use_relation_library: bool
    use_stepwise_physics: bool

    @classmethod
    def for_arm(cls, arm_id: str) -> PilotArmSwitches:
        matrix = {
            "C0": cls(False, False, False),
            "C1": cls(True, False, False),
            "C2": cls(True, True, False),
            "C3-Full": cls(True, True, True),
            "C1-P": cls(True, False, True),
        }
        try:
            return matrix[arm_id]
        except KeyError as error:
            raise ValueError(f"unknown Crysalis-G1 pilot arm: {arm_id}") from error


@dataclass(frozen=True, slots=True)
class PilotModelConfig:
    schema_version: str
    arm_id: str
    use_relation_memory: bool
    use_relation_library: bool
    use_stepwise_physics: bool
    geometry: GeometryBackendConfig
    hidden_dim: int
    orbit_attention_blocks: int
    orbit_attention_heads: int
    relation_prior_dim: int
    relation_memory_dim: int
    physics_feedback_dim: int
    projector_min_distance: float
    physics_update_mode: Literal["feedback_only", "state_update"]
    relation_library_backend: Literal["matched_mlp", "student_mlp"]

    def __post_init__(self) -> None:
        if self.schema_version != "g1-local-pilot-model.1.0.0":
            raise ValueError("unsupported local pilot model schema")
        expected = PilotArmSwitches.for_arm(self.arm_id)
        observed = PilotArmSwitches(
            self.use_relation_memory,
            self.use_relation_library,
            self.use_stepwise_physics,
        )
        if observed != expected:
            raise ValueError(f"arm switch matrix mismatch for {self.arm_id}")
        dimensions = (
            self.hidden_dim,
            self.orbit_attention_blocks,
            self.orbit_attention_heads,
            self.relation_prior_dim,
            self.relation_memory_dim,
            self.physics_feedback_dim,
        )
        if any(type(value) is not int or value <= 0 for value in dimensions):
            raise ValueError("pilot model dimensions must be positive integers")
        if self.hidden_dim % self.orbit_attention_heads:
            raise ValueError("hidden width must be divisible by attention heads")
        if self.geometry.node_invariant_dim != 5:
            raise ValueError("geometry node invariant width must be five")
        if self.geometry.relation_invariant_dim != 11:
            raise ValueError("relation invariant width must be eleven")
        if not math.isfinite(self.projector_min_distance) or self.projector_min_distance <= 0:
            raise ValueError("projector minimum distance must be finite and positive")


@dataclass(frozen=True, slots=True)
class PhysicsStateUpdateResult:
    positions: torch.Tensor
    lattice: torch.Tensor
    requires_second_projector: bool


class PhysicsStateUpdateOperator(nn.Module):
    """Retains both feedback-only and projector-guarded state-update paths."""

    supported_modes = ("feedback_only", "state_update")

    def __init__(
        self,
        *,
        feedback_dim: int,
        mode: Literal["feedback_only", "state_update"],
    ) -> None:
        super().__init__()
        if mode not in self.supported_modes:
            raise ValueError(f"unsupported physics state update mode: {mode}")
        self.mode = mode
        self.isotropic_update = nn.Linear(feedback_dim, 2)

    def forward(
        self,
        feedback: torch.Tensor,
        positions: torch.Tensor,
        lattice: torch.Tensor,
    ) -> PhysicsStateUpdateResult:
        if self.mode == "feedback_only":
            return PhysicsStateUpdateResult(positions, lattice, False)
        scales = torch.tanh(self.isotropic_update(feedback)) * 0.02
        updated_positions = positions * (1.0 + scales[:, :1, None])
        updated_lattice = lattice * (1.0 + scales[:, 1:, None])
        return PhysicsStateUpdateResult(updated_positions, updated_lattice, True)


class MaterialEmbryoPlanner(nn.Module):
    def __init__(self, hidden_dim: int) -> None:
        super().__init__()
        self.element_embedding = nn.Embedding(119, hidden_dim, padding_idx=0)
        self.space_group_embedding = nn.Embedding(231, hidden_dim, padding_idx=0)
        self.condition = nn.Sequential(
            nn.Linear(hidden_dim * 3 + 1, hidden_dim * 2),
            nn.SiLU(),
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.LayerNorm(hidden_dim),
        )

    def _composition_token(self, counts: torch.Tensor) -> torch.Tensor:
        indices = torch.arange(119, device=counts.device)
        embedded = self.element_embedding(indices)
        return counts @ embedded / counts.sum(dim=1, keepdim=True).clamp_min(1.0)

    def forward(
        self,
        composition: torch.Tensor,
        remaining: torch.Tensor,
        space_group: torch.Tensor,
        progress: torch.Tensor,
    ) -> torch.Tensor:
        return self.condition(
            torch.cat(
                (
                    self._composition_token(composition),
                    self._composition_token(remaining),
                    self.space_group_embedding(space_group.clamp(0, 230)),
                    progress,
                ),
                dim=-1,
            )
        )


class OrbitSetEncoder(nn.Module):
    def __init__(self, hidden_dim: int, blocks: int, heads: int) -> None:
        super().__init__()
        self.element_embedding = nn.Embedding(119, hidden_dim, padding_idx=0)
        self.multiplicity_embedding = nn.Embedding(13, hidden_dim, padding_idx=0)
        self.wyckoff_embedding = nn.Embedding(26, hidden_dim)
        self.invariant_projection = nn.Linear(5, hidden_dim)
        layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim,
            nhead=heads,
            dim_feedforward=hidden_dim * 4,
            dropout=0.0,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(layer, num_layers=blocks)

    @staticmethod
    def invariants(batch: AssemblyTrainingBatch) -> torch.Tensor:
        progress = batch.progress[:, None, :].expand(
            -1, batch.node_atomic_numbers.shape[1], -1
        )
        return torch.cat(
            (
                batch.node_atomic_numbers[..., None].float() / 118.0,
                batch.node_multiplicities[..., None].float() / 12.0,
                batch.node_wyckoff_indices[..., None].float() / 25.0,
                progress,
                batch.node_mask[..., None].float(),
            ),
            dim=-1,
        )

    def forward(
        self, batch: AssemblyTrainingBatch, embryo: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        invariants = self.invariants(batch)
        orbit_tokens = (
            self.element_embedding(batch.node_atomic_numbers.clamp(0, 118))
            + self.multiplicity_embedding(batch.node_multiplicities.clamp(0, 12))
            + self.wyckoff_embedding(batch.node_wyckoff_indices.clamp(0, 25))
            + self.invariant_projection(invariants)
        )
        tokens = torch.cat((embryo[:, None, :], orbit_tokens), dim=1)
        padding = torch.cat(
            (
                torch.zeros(
                    (batch.node_mask.shape[0], 1),
                    dtype=torch.bool,
                    device=batch.node_mask.device,
                ),
                ~batch.node_mask,
            ),
            dim=1,
        )
        encoded = self.encoder(tokens, src_key_padding_mask=padding)
        return encoded[:, 0], encoded[:, 1:], invariants


class InvariantRelationLibrary(nn.Module):
    """Frozen cross-sample relation function with no directional input."""

    def __init__(self, hidden_dim: int, prior_dim: int) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(22, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, prior_dim),
        )
        for parameter in self.parameters():
            parameter.requires_grad_(False)

    def forward(
        self,
        relation_invariants: torch.Tensor,
        relation_availability: torch.Tensor,
        relation_mask: torch.Tensor,
    ) -> torch.Tensor:
        values = torch.where(
            relation_availability,
            relation_invariants,
            torch.zeros_like(relation_invariants),
        )
        invariant_lane = torch.cat(
            (values, relation_availability.to(values.dtype)), dim=-1
        )
        return self.network(invariant_lane) * relation_mask[..., None]


class AnalyticPhysicsFeedback(nn.Module):
    def __init__(self, hidden_dim: int, feedback_dim: int) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(4, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, feedback_dim),
            nn.Tanh(),
        )

    def forward(
        self, batch: AssemblyTrainingBatch, *, enabled: bool
    ) -> tuple[torch.Tensor, torch.Tensor]:
        node_count = batch.node_mask.sum(dim=1)
        applicable = node_count >= 2
        if not enabled:
            applicable = torch.zeros_like(applicable)
        relation_distance = torch.where(
            batch.relation_mask,
            batch.relation_invariants[..., 0],
            torch.full_like(batch.relation_invariants[..., 0], torch.inf),
        ).amin(dim=1)
        relation_distance = torch.where(
            torch.isfinite(relation_distance), relation_distance, torch.zeros_like(relation_distance)
        )
        atom_count = batch.composition.sum(dim=1).clamp_min(1.0)
        remaining_fraction = batch.remaining.sum(dim=1) / atom_count
        volume_per_atom = torch.linalg.det(batch.input_lattice).abs() / atom_count
        invariants = torch.stack(
            (
                node_count.float() / 8.0,
                relation_distance / 6.0,
                volume_per_atom / 20.0,
                remaining_fraction,
            ),
            dim=-1,
        )
        feedback = self.network(invariants) * applicable[:, None]
        return feedback, applicable


class TrajectoryRelationMemory(nn.Module):
    def __init__(
        self, relation_prior_dim: int, physics_dim: int, memory_dim: int
    ) -> None:
        super().__init__()
        self.cell = nn.GRUCell(11 + relation_prior_dim + physics_dim, memory_dim)

    def forward(
        self,
        current: torch.Tensor,
        pooled_relations: torch.Tensor,
        pooled_prior: torch.Tensor,
        physics_feedback: torch.Tensor,
        *,
        enabled: bool,
    ) -> torch.Tensor:
        if not enabled:
            return torch.zeros_like(current)
        return self.cell(
            torch.cat(
                (pooled_relations, pooled_prior, physics_feedback), dim=-1
            ),
            current,
        )


class OrbitLevelAssemblyPolicy(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(input_dim, hidden_dim * 2),
            nn.SiLU(),
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.SiLU(),
        )
        self.action_head = nn.Linear(hidden_dim, len(ActionType))
        self.species_head = nn.Linear(hidden_dim, 119)
        self.multiplicity_head = nn.Linear(hidden_dim, 13)
        self.wyckoff_head = nn.Linear(hidden_dim, 26)
        self.coordinate_head = nn.Linear(hidden_dim, 3)
        self.termination_head = nn.Linear(hidden_dim, 1)

    def forward(
        self, value: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        hidden = self.network(value)
        return (
            hidden,
            self.action_head(hidden),
            self.species_head(hidden),
            self.multiplicity_head(hidden),
            self.wyckoff_head(hidden),
            torch.sigmoid(self.coordinate_head(hidden)),
            self.termination_head(hidden).squeeze(-1),
        )


class LegalActionCompiler(nn.Module):
    def forward(
        self,
        action_logits: torch.Tensor,
        remaining: torch.Tensor,
        node_mask: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        batch_size = action_logits.shape[0]
        legal = torch.zeros_like(action_logits, dtype=torch.bool)
        remaining_atoms = remaining.sum(dim=1)
        node_count = node_mask.sum(dim=1)
        legal[:, list(ActionType).index(ActionType.ADD_ORBIT)] = remaining_atoms > 0
        legal[:, list(ActionType).index(ActionType.ADD_PERIODIC_EDGE)] = node_count >= 2
        legal[:, list(ActionType).index(ActionType.UPDATE_LATTICE)] = True
        legal[:, list(ActionType).index(ActionType.REFINE_GEOMETRY)] = node_count >= 1
        legal[:, list(ActionType).index(ActionType.TERMINATE)] = remaining_atoms == 0
        if not legal.any(dim=1).all() or legal.shape[0] != batch_size:
            raise RuntimeError("legal action compiler produced an empty action set")
        return action_logits.masked_fill(~legal, -torch.inf), legal


class LatticeHead(nn.Module):
    def __init__(self, hidden_dim: int) -> None:
        super().__init__()
        self.head = nn.Linear(hidden_dim, 6)

    def forward(self, context: torch.Tensor) -> torch.Tensor:
        raw = self.head(context)
        factor = raw.new_zeros((raw.shape[0], 3, 3))
        factor[:, 0, 0] = F.softplus(raw[:, 0]) + 2.0
        factor[:, 1, 0] = torch.tanh(raw[:, 1])
        factor[:, 1, 1] = F.softplus(raw[:, 2]) + 2.0
        factor[:, 2, 0] = torch.tanh(raw[:, 3])
        factor[:, 2, 1] = torch.tanh(raw[:, 4])
        factor[:, 2, 2] = F.softplus(raw[:, 5]) + 2.0
        return factor


@dataclass(frozen=True, slots=True)
class LocalPilotOutput:
    action_logits: torch.Tensor
    legal_action_mask: torch.Tensor
    species_logits: torch.Tensor
    multiplicity_logits: torch.Tensor
    wyckoff_logits: torch.Tensor
    predicted_fractional_coordinate: torch.Tensor
    predicted_lattice: torch.Tensor
    termination_logit: torch.Tensor
    relation_pair_logits: torch.Tensor
    relation_distance: torch.Tensor
    relation_prior: torch.Tensor
    next_relation_memory: torch.Tensor
    physics_feedback: torch.Tensor
    physics_applied: torch.Tensor
    geometry_delta: torch.Tensor
    first_projection: ProjectionResult
    final_projection: ProjectionResult
    second_projector_applied: bool


class UnifiedLocalPilotModel(nn.Module):
    def __init__(self, config: PilotModelConfig) -> None:
        super().__init__()
        self.config = config
        hidden = config.hidden_dim
        self.material_embryo_planner = MaterialEmbryoPlanner(hidden)
        self.orbit_set_encoder = OrbitSetEncoder(
            hidden, config.orbit_attention_blocks, config.orbit_attention_heads
        )
        self.relation_library = InvariantRelationLibrary(
            hidden, config.relation_prior_dim
        )
        self.physics_feedback_operator = AnalyticPhysicsFeedback(
            hidden, config.physics_feedback_dim
        )
        self.trajectory_relation_memory = TrajectoryRelationMemory(
            config.relation_prior_dim,
            config.physics_feedback_dim,
            config.relation_memory_dim,
        )
        policy_input = (
            hidden * 2
            + config.relation_prior_dim
            + config.relation_memory_dim
            + config.physics_feedback_dim
        )
        self.orbit_level_assembly_policy = OrbitLevelAssemblyPolicy(
            policy_input, hidden
        )
        self.legal_action_compiler = LegalActionCompiler()
        self.lattice_head = LatticeHead(hidden)
        self.periodic_equivariant_geometry_generator = build_geometry_backend(
            config.geometry
        )
        self.relation_source_projection = nn.Linear(hidden, hidden, bias=False)
        self.relation_target_projection = nn.Linear(hidden, hidden, bias=False)
        self.relation_distance_head = nn.Linear(hidden, 1)
        self.crystallographic_projector = CrystallographicTensorProjector(
            min_distance=config.projector_min_distance
        )
        self.physics_state_update = PhysicsStateUpdateOperator(
            feedback_dim=config.physics_feedback_dim,
            mode=config.physics_update_mode,
        )
        self.second_crystallographic_projector = CrystallographicTensorProjector(
            min_distance=config.projector_min_distance
        )

    @staticmethod
    def _masked_mean(values: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        weights = mask[..., None].to(values.dtype)
        return (values * weights).sum(dim=1) / weights.sum(dim=1).clamp_min(1.0)

    def _query_geometry_batch(
        self,
        batch: AssemblyTrainingBatch,
        node_invariants: torch.Tensor,
        species_logits: torch.Tensor,
        multiplicity_logits: torch.Tensor,
        wyckoff_logits: torch.Tensor,
        base_fractional: torch.Tensor,
    ) -> GeometryBackendBatch:
        batch_size, node_count = batch.node_mask.shape
        query_active = batch.remaining.sum(dim=1) > 0
        species_probability = torch.softmax(species_logits, dim=-1)
        species_indices = torch.arange(119, device=species_logits.device).float()
        expected_species = (species_probability * species_indices).sum(dim=-1) / 118.0
        multiplicity_probability = torch.softmax(multiplicity_logits, dim=-1)
        multiplicity_indices = torch.arange(13, device=species_logits.device).float()
        expected_multiplicity = (
            multiplicity_probability * multiplicity_indices
        ).sum(dim=-1) / 12.0
        wyckoff_probability = torch.softmax(wyckoff_logits, dim=-1)
        wyckoff_indices = torch.arange(26, device=species_logits.device).float()
        expected_wyckoff = (wyckoff_probability * wyckoff_indices).sum(dim=-1) / 25.0
        query_invariants = torch.stack(
            (
                expected_species,
                expected_multiplicity,
                expected_wyckoff,
                batch.progress.squeeze(-1),
                query_active.float(),
            ),
            dim=-1,
        )
        geometry_nodes = torch.cat((node_invariants, query_invariants[:, None, :]), dim=1)
        geometry_mask = torch.cat((batch.node_mask, query_active[:, None]), dim=1)

        delta_fractional = base_fractional[:, None, :] - batch.node_fractional_coordinates
        delta_fractional = delta_fractional - torch.round(delta_fractional)
        query_vectors = torch.einsum(
            "bnd,bdk->bnk", delta_fractional, batch.input_lattice
        )
        query_distance = torch.linalg.vector_norm(query_vectors, dim=-1)
        query_relations = batch.relation_invariants.new_zeros(
            (batch_size, node_count, 11)
        )
        query_relations[..., 0] = query_distance
        query_relations[..., 2] = batch.relation_mask.sum(dim=1)[:, None].float()
        query_relations[..., 3] = batch.node_mask.sum(dim=1)[:, None].float()
        query_relations[..., 10] = batch.progress
        query_availability = torch.zeros_like(query_relations, dtype=torch.bool)
        query_availability[..., 0] = True
        query_availability[..., 2] = True
        query_availability[..., 3] = True
        query_availability[..., 10] = True
        query_mask = batch.node_mask & query_active[:, None]
        query_sources = torch.arange(
            node_count, device=batch.node_mask.device
        )[None, :].expand(batch_size, -1)
        query_targets = torch.full_like(query_sources, node_count)
        return GeometryBackendBatch(
            node_invariants=geometry_nodes,
            node_mask=geometry_mask,
            relation_invariants=torch.cat(
                (batch.relation_invariants, query_relations), dim=1
            ),
            relation_availability=torch.cat(
                (batch.relation_availability, query_availability), dim=1
            ),
            relation_vectors=torch.cat(
                (batch.relation_vectors, query_vectors), dim=1
            ),
            relation_sources=torch.cat(
                (batch.relation_sources, query_sources), dim=1
            ),
            relation_targets=torch.cat(
                (batch.relation_targets, query_targets), dim=1
            ),
            relation_mask=torch.cat((batch.relation_mask, query_mask), dim=1),
        )

    def forward(
        self,
        batch: AssemblyTrainingBatch,
        relation_memory: torch.Tensor | None = None,
    ) -> LocalPilotOutput:
        embryo = self.material_embryo_planner(
            batch.composition, batch.remaining, batch.space_group, batch.progress
        )
        orbit_context, orbit_tokens, node_invariants = self.orbit_set_encoder(
            batch, embryo
        )
        if self.config.use_relation_library:
            relation_prior = self.relation_library(
                batch.relation_invariants,
                batch.relation_availability,
                batch.relation_mask,
            )
        else:
            relation_prior = batch.relation_invariants.new_zeros(
                (
                    batch.relation_invariants.shape[0],
                    batch.relation_invariants.shape[1],
                    self.config.relation_prior_dim,
                )
            )
        available_relations = torch.where(
            batch.relation_availability,
            batch.relation_invariants,
            torch.zeros_like(batch.relation_invariants),
        )
        pooled_relations = self._masked_mean(
            available_relations, batch.relation_mask
        )
        pooled_prior = self._masked_mean(relation_prior, batch.relation_mask)
        physics_feedback, physics_applied = self.physics_feedback_operator(
            batch, enabled=self.config.use_stepwise_physics
        )
        if relation_memory is None:
            relation_memory = batch.composition.new_zeros(
                (batch.composition.shape[0], self.config.relation_memory_dim)
            )
        next_memory = self.trajectory_relation_memory(
            relation_memory,
            pooled_relations,
            pooled_prior,
            physics_feedback,
            enabled=self.config.use_relation_memory,
        )
        (
            policy_context,
            raw_action_logits,
            species_logits,
            multiplicity_logits,
            wyckoff_logits,
            base_fractional,
            termination_logit,
        ) = self.orbit_level_assembly_policy(
            torch.cat(
                (
                    embryo,
                    orbit_context,
                    pooled_prior,
                    next_memory,
                    physics_feedback,
                ),
                dim=-1,
            )
        )
        action_logits, legal_action_mask = self.legal_action_compiler(
            raw_action_logits, batch.remaining, batch.node_mask
        )
        species_legal = batch.remaining > 0
        empty_species = ~species_legal.any(dim=1)
        species_legal[empty_species, 0] = True
        species_logits = species_logits.masked_fill(~species_legal, -torch.inf)
        maximum_remaining = batch.remaining.amax(dim=1).long()
        multiplicity_indices = torch.arange(13, device=batch.remaining.device)[None, :]
        multiplicity_legal = (
            (multiplicity_indices >= 1)
            & (multiplicity_indices <= maximum_remaining[:, None])
        )
        multiplicity_legal[maximum_remaining == 0, 0] = True
        multiplicity_logits = multiplicity_logits.masked_fill(
            ~multiplicity_legal, -torch.inf
        )
        predicted_lattice = self.lattice_head(policy_context).float()
        geometry_batch = self._query_geometry_batch(
            batch,
            node_invariants,
            species_logits,
            multiplicity_logits,
            wyckoff_logits,
            base_fractional,
        )
        geometry_delta = self.periodic_equivariant_geometry_generator(
            geometry_batch
        )
        query_delta = geometry_delta[:, -1].float()
        fractional_delta = torch.einsum(
            "bd,bdk->bk", query_delta, torch.linalg.inv(predicted_lattice)
        )
        predicted_fractional = torch.remainder(base_fractional + fractional_delta, 1.0)
        all_fractional = torch.cat(
            (batch.node_fractional_coordinates, predicted_fractional[:, None, :]),
            dim=1,
        )
        query_active = (batch.remaining.sum(dim=1) > 0)[:, None]
        all_mask = torch.cat((batch.node_mask, query_active), dim=1)
        candidate_positions = torch.einsum(
            "bnd,bdk->bnk", all_fractional, predicted_lattice
        )
        first_projection = self.crystallographic_projector(
            candidate_positions, predicted_lattice, all_mask
        )
        physics_update = self.physics_state_update(
            physics_feedback,
            first_projection.positions,
            first_projection.lattice,
        )
        if physics_update.requires_second_projector:
            final_projection = self.second_crystallographic_projector(
                physics_update.positions, physics_update.lattice, all_mask
            )
        else:
            final_projection = first_projection

        source_features = self.relation_source_projection(orbit_tokens)
        target_features = self.relation_target_projection(orbit_tokens)
        relation_pair_logits = torch.einsum(
            "bnh,bmh->bnm", source_features, target_features
        ) / math.sqrt(self.config.hidden_dim)
        pair_mask = batch.node_mask[:, :, None] & batch.node_mask[:, None, :]
        relation_pair_logits = relation_pair_logits.masked_fill(~pair_mask, -torch.inf)
        relation_distance = F.softplus(
            self.relation_distance_head(policy_context).squeeze(-1)
        )
        return LocalPilotOutput(
            action_logits=action_logits,
            legal_action_mask=legal_action_mask,
            species_logits=species_logits,
            multiplicity_logits=multiplicity_logits,
            wyckoff_logits=wyckoff_logits,
            predicted_fractional_coordinate=predicted_fractional,
            predicted_lattice=predicted_lattice,
            termination_logit=termination_logit,
            relation_pair_logits=relation_pair_logits,
            relation_distance=relation_distance,
            relation_prior=relation_prior,
            next_relation_memory=next_memory,
            physics_feedback=physics_feedback,
            physics_applied=physics_applied,
            geometry_delta=geometry_delta,
            first_projection=first_projection,
            final_projection=final_projection,
            second_projector_applied=physics_update.requires_second_projector,
        )

    @staticmethod
    def module_contract() -> dict[str, object]:
        return {
            "material_embryo_planner": "REQUIRED",
            "orbit_level_assembly_policy": "REQUIRED",
            "lattice_head": "REQUIRED",
            "periodic_equivariant_geometry_generator": "REQUIRED",
            "termination_head": "IN_ORBIT_POLICY",
            "legal_action_compiler": "REQUIRED",
            "crystallographic_projector": "REQUIRED",
            "physics_state_update": "FEEDBACK_ONLY_RUN_WITH_STATE_UPDATE_PATH_RETAINED",
            "second_projector": "REQUIRED_FOR_STATE_UPDATE_MODE",
            "geometry_backend_interface": "REQUIRED",
            "formal_deconstruction_operators": FORMAL_DECONSTRUCTION_OPERATORS,
            "unimplemented_operators": (
                "D_motif",
                "D_sublattice",
                "D_distortion",
            ),
        }

    def trainable_parameter_count(self) -> int:
        return sum(
            parameter.numel()
            for parameter in self.parameters()
            if parameter.requires_grad
        )

    def non_geometry_parameter_count(self) -> int:
        geometry_parameters = {
            id(parameter)
            for parameter in self.periodic_equivariant_geometry_generator.parameters()
            if parameter.requires_grad
        }
        return sum(
            parameter.numel()
            for parameter in self.parameters()
            if parameter.requires_grad and id(parameter) not in geometry_parameters
        )


@dataclass(frozen=True, slots=True)
class PilotLossScales:
    action_loss: float
    orbit_loss: float
    relation_loss: float
    geometry_loss: float
    lattice_loss: float
    termination_loss: float

    def __post_init__(self) -> None:
        if any(
            not math.isfinite(value) or value <= 0
            for value in (
                self.action_loss,
                self.orbit_loss,
                self.relation_loss,
                self.geometry_loss,
                self.lattice_loss,
                self.termination_loss,
            )
        ):
            raise ValueError("pilot loss scales must be finite and positive")

    @classmethod
    def unit(cls) -> PilotLossScales:
        return cls(1.0, 1.0, 1.0, 1.0, 1.0, 1.0)


@dataclass(frozen=True, slots=True)
class PilotLossOutput:
    validation_objective: torch.Tensor
    components: dict[str, torch.Tensor]


def _zero(output: LocalPilotOutput) -> torch.Tensor:
    return output.termination_logit.sum() * 0.0


def compute_pilot_losses(
    output: LocalPilotOutput,
    batch: AssemblyTrainingBatch,
    scales: PilotLossScales,
) -> PilotLossOutput:
    action = F.cross_entropy(output.action_logits, batch.target_action)
    orbit_mask = batch.target_orbit_mask
    if bool(orbit_mask.any()):
        species = F.cross_entropy(
            output.species_logits[orbit_mask], batch.target_atomic_number[orbit_mask]
        )
        multiplicity = F.cross_entropy(
            output.multiplicity_logits[orbit_mask],
            batch.target_multiplicity[orbit_mask],
        )
        wyckoff = F.cross_entropy(
            output.wyckoff_logits[orbit_mask], batch.target_wyckoff_index[orbit_mask]
        )
        orbit = (species + multiplicity + wyckoff) / 3.0
        periodic_error = (
            output.predicted_fractional_coordinate[orbit_mask]
            - batch.target_fractional_coordinates[orbit_mask]
        )
        periodic_error = periodic_error - torch.round(periodic_error)
        geometry = periodic_error.square().mean()
    else:
        orbit = geometry = _zero(output)

    relation_mask = batch.target_relation_mask
    if bool(relation_mask.any()):
        pair_logits = output.relation_pair_logits[relation_mask].flatten(1)
        node_count = output.relation_pair_logits.shape[1]
        pair_target = (
            batch.target_relation_sources[relation_mask] * node_count
            + batch.target_relation_targets[relation_mask]
        )
        pair = F.cross_entropy(pair_logits, pair_target)
        distance = F.mse_loss(
            output.relation_distance[relation_mask],
            batch.target_relation_distance[relation_mask],
        )
        relation = pair + distance
    else:
        relation = _zero(output)

    predicted_metric = output.predicted_lattice @ output.predicted_lattice.transpose(-1, -2)
    target_metric = batch.target_lattice @ batch.target_lattice.transpose(-1, -2)
    metric_scale = target_metric.square().mean(dim=(-1, -2)).sqrt().clamp_min(1.0)
    lattice = (
        (predicted_metric - target_metric).square().mean(dim=(-1, -2))
        / metric_scale.square()
    ).mean()
    termination_target = (
        batch.target_action == list(ActionType).index(ActionType.TERMINATE)
    ).to(output.termination_logit.dtype)
    termination = F.binary_cross_entropy_with_logits(
        output.termination_logit, termination_target
    )
    raw = {
        "action_loss": action,
        "orbit_loss": orbit,
        "relation_loss": relation,
        "geometry_loss": geometry,
        "lattice_loss": lattice,
        "termination_loss": termination,
    }
    normalized = {
        name: value / getattr(scales, name) for name, value in raw.items()
    }
    return PilotLossOutput(sum(normalized.values()), normalized)
