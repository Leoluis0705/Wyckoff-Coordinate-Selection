from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn

from crysalis_g1.actions import ActionType
from crysalis_g1.state.embryo import MaterialEmbryoState


@dataclass(frozen=True)
class StateBatch:
    composition: torch.Tensor
    remaining: torch.Tensor
    space_group: torch.Tensor
    assembly_step: torch.Tensor
    orbit_atomic_numbers: torch.Tensor | None = None
    orbit_multiplicities: torch.Tensor | None = None
    orbit_coordinates: torch.Tensor | None = None
    orbit_mask: torch.Tensor | None = None

    def to(self, device: torch.device | str) -> StateBatch:
        return StateBatch(
            self.composition.to(device),
            self.remaining.to(device),
            self.space_group.to(device),
            self.assembly_step.to(device),
            None if self.orbit_atomic_numbers is None else self.orbit_atomic_numbers.to(device),
            None if self.orbit_multiplicities is None else self.orbit_multiplicities.to(device),
            None if self.orbit_coordinates is None else self.orbit_coordinates.to(device),
            None if self.orbit_mask is None else self.orbit_mask.to(device),
        )

    def permute_orbits(self, order: torch.Tensor) -> StateBatch:
        if any(
            value is None
            for value in (
                self.orbit_atomic_numbers,
                self.orbit_multiplicities,
                self.orbit_coordinates,
                self.orbit_mask,
            )
        ):
            raise ValueError("orbit tensors are unavailable")
        atomic_numbers = self.orbit_atomic_numbers
        multiplicities = self.orbit_multiplicities
        coordinates = self.orbit_coordinates
        mask = self.orbit_mask
        assert atomic_numbers is not None
        assert multiplicities is not None
        assert coordinates is not None
        assert mask is not None
        coordinate_order = order.unsqueeze(-1).expand(-1, -1, 3)
        return StateBatch(
            self.composition,
            self.remaining,
            self.space_group,
            self.assembly_step,
            torch.gather(atomic_numbers, 1, order),
            torch.gather(multiplicities, 1, order),
            torch.gather(coordinates, 1, coordinate_order),
            torch.gather(mask, 1, order),
        )


@dataclass(frozen=True)
class PolicyOutput:
    action_logits: torch.Tensor
    species_logits: torch.Tensor
    multiplicity_logits: torch.Tensor
    orbit_index_logits: torch.Tensor
    free_parameters: torch.Tensor
    lattice_parameters: torch.Tensor
    feasibility_logit: torch.Tensor


def encode_states(states: list[MaterialEmbryoState]) -> StateBatch:
    if not states:
        raise ValueError("states must not be empty")
    composition = torch.zeros((len(states), 119), dtype=torch.float32)
    remaining = torch.zeros_like(composition)
    space_group = torch.zeros(len(states), dtype=torch.long)
    assembly_step = torch.zeros((len(states), 1), dtype=torch.float32)
    maximum_orbits = max(1, max(len(state.orbit_states) for state in states))
    orbit_atomic_numbers = torch.zeros((len(states), maximum_orbits), dtype=torch.long)
    orbit_multiplicities = torch.zeros_like(orbit_atomic_numbers)
    orbit_coordinates = torch.zeros((len(states), maximum_orbits, 3))
    orbit_mask = torch.zeros((len(states), maximum_orbits), dtype=torch.bool)
    for row, state in enumerate(states):
        for atomic_number, count in state.composition:
            composition[row, atomic_number] = float(count)
        for atomic_number, count in state.remaining_composition:
            remaining[row, atomic_number] = float(count)
        space_group[row] = int(state.space_group or 0)
        assembly_step[row, 0] = float(state.assembly_step) / 32.0
        for column, orbit in enumerate(state.orbit_states):
            orbit_atomic_numbers[row, column] = int(orbit.atomic_number or 0)
            orbit_multiplicities[row, column] = orbit.multiplicity
            coordinate = orbit.expanded_fractional_coordinates[0]
            orbit_coordinates[row, column] = torch.tensor(coordinate)
            orbit_mask[row, column] = True
    return StateBatch(
        composition,
        remaining,
        space_group,
        assembly_step,
        orbit_atomic_numbers,
        orbit_multiplicities,
        orbit_coordinates,
        orbit_mask,
    )


class ResidualFeedForward(nn.Module):
    def __init__(self, hidden_size: int, expansion: int) -> None:
        super().__init__()
        self.norm = nn.LayerNorm(hidden_size)
        self.network = nn.Sequential(
            nn.Linear(hidden_size, expansion),
            nn.SiLU(),
            nn.Linear(expansion, hidden_size),
        )

    def forward(self, value: torch.Tensor) -> torch.Tensor:
        return value + self.network(self.norm(value))


class OrbitAssemblyPolicy(nn.Module):
    """Permutation-invariant orbit policy used by the engineering smoke path."""

    def __init__(self, hidden_size: int = 128, expansion: int = 1024) -> None:
        super().__init__()
        self.element_embedding = nn.Embedding(119, hidden_size)
        self.multiplicity_embedding = nn.Embedding(13, hidden_size)
        self.orbit_coordinate_projection = nn.Linear(3, hidden_size)
        self.space_group_embedding = nn.Embedding(231, hidden_size)
        self.step_projection = nn.Linear(1, hidden_size)
        self.input_projection = nn.Linear(hidden_size * 4, hidden_size)
        self.condition_blocks = nn.ModuleList(
            ResidualFeedForward(hidden_size, expansion) for _ in range(4)
        )
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_size,
            nhead=4,
            dim_feedforward=expansion,
            dropout=0.0,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.orbit_transformer = nn.TransformerEncoder(encoder_layer, num_layers=4)
        self.edge_memory_blocks = nn.ModuleList(
            ResidualFeedForward(hidden_size, expansion) for _ in range(4)
        )
        self.action_head = nn.Linear(hidden_size, len(ActionType))
        self.species_head = nn.Linear(hidden_size, 119)
        self.multiplicity_head = nn.Linear(hidden_size, 13)
        self.orbit_index_head = nn.Linear(hidden_size, 12)
        self.free_parameter_head = nn.Linear(hidden_size, 3)
        self.lattice_head = nn.Linear(hidden_size, 6)
        self.feasibility_head = nn.Linear(hidden_size, 1)

    def _composition_token(self, counts: torch.Tensor) -> torch.Tensor:
        indices = torch.arange(119, device=counts.device)
        embedded = self.element_embedding(indices)
        denominator = counts.sum(dim=1, keepdim=True).clamp_min(1.0)
        return counts @ embedded / denominator

    def forward(self, batch: StateBatch) -> PolicyOutput:
        composition = self._composition_token(batch.composition)
        remaining = self._composition_token(batch.remaining)
        sg = self.space_group_embedding(batch.space_group.clamp(0, 230))
        step = self.step_projection(batch.assembly_step)
        hidden = self.input_projection(torch.cat((composition, remaining, sg, step), dim=-1))
        for block in self.condition_blocks:
            hidden = block(hidden)
        batch_size = hidden.shape[0]
        if batch.orbit_atomic_numbers is None:
            orbit_tokens = hidden.new_zeros((batch_size, 1, hidden.shape[-1]))
            orbit_mask = torch.zeros((batch_size, 1), dtype=torch.bool, device=hidden.device)
        else:
            assert batch.orbit_multiplicities is not None
            assert batch.orbit_coordinates is not None
            assert batch.orbit_mask is not None
            orbit_tokens = (
                self.element_embedding(batch.orbit_atomic_numbers.clamp(0, 118))
                + self.multiplicity_embedding(batch.orbit_multiplicities.clamp(0, 12))
                + self.orbit_coordinate_projection(batch.orbit_coordinates)
            )
            orbit_mask = batch.orbit_mask
        tokens = torch.cat((hidden.unsqueeze(1), orbit_tokens), dim=1)
        padding_mask = torch.cat(
            (
                torch.zeros((batch_size, 1), dtype=torch.bool, device=hidden.device),
                ~orbit_mask,
            ),
            dim=1,
        )
        hidden = self.orbit_transformer(
            tokens, src_key_padding_mask=padding_mask
        )[:, 0]
        for block in self.edge_memory_blocks:
            hidden = block(hidden)
        return PolicyOutput(
            self.action_head(hidden),
            self.species_head(hidden),
            self.multiplicity_head(hidden),
            self.orbit_index_head(hidden),
            torch.sigmoid(self.free_parameter_head(hidden)),
            self.lattice_head(hidden),
            self.feasibility_head(hidden).squeeze(-1),
        )

    def trainable_parameter_count(self) -> int:
        return sum(parameter.numel() for parameter in self.parameters() if parameter.requires_grad)
