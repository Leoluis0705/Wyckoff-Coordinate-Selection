from __future__ import annotations

from dataclasses import dataclass, fields

import torch
from torch import nn
from torch.nn import functional


MIXTURE_COMPONENTS = 8
MAXIMUM_ORBITS = 8


@dataclass(frozen=True, slots=True)
class GeometryMDNBatch:
    composition: torch.Tensor
    target_sg: torch.Tensor
    lattice: torch.Tensor
    active_species: torch.Tensor
    active_wyckoff: torch.Tensor
    active_multiplicity: torch.Tensor
    active_dof: torch.Tensor
    active_rank: torch.Tensor
    active_free_parameters: torch.Tensor
    active_mask: torch.Tensor
    candidate_species: torch.Tensor
    candidate_wyckoff: torch.Tensor
    candidate_multiplicity: torch.Tensor
    candidate_dof: torch.Tensor
    candidate_rank: torch.Tensor
    path_index: torch.Tensor
    step_index: torch.Tensor
    removed_ranks: torch.Tensor
    removed_mask: torch.Tensor
    relation_features: torch.Tensor
    relation_mask: torch.Tensor
    free_dof_mask: torch.Tensor

    def to(self, device: torch.device | str) -> GeometryMDNBatch:
        return GeometryMDNBatch(
            **{
                field.name: getattr(self, field.name).to(device)
                for field in fields(self)
            }
        )


@dataclass(frozen=True, slots=True)
class WrappedMDNOutput:
    logits: torch.Tensor
    mean_angles: torch.Tensor
    concentration: torch.Tensor


def _masked_mean(values: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    weights = mask.to(values.dtype).unsqueeze(-1)
    return (values * weights).sum(dim=1) / weights.sum(dim=1).clamp_min(1.0)


class WrappedMixtureDensityDecoder(nn.Module):
    """Small K=8 relation-compatible wrapped mixture decoder."""

    def __init__(self) -> None:
        super().__init__()
        self.species_embedding = nn.Embedding(119, 16, padding_idx=0)
        self.wyckoff_embedding = nn.Embedding(26, 8)
        self.space_group_embedding = nn.Embedding(231, 16)
        self.rank_embedding = nn.Embedding(MAXIMUM_ORBITS, 4)
        self.dof_embedding = nn.Embedding(4, 4)
        self.path_embedding = nn.Embedding(4, 4)
        self.step_embedding = nn.Embedding(MAXIMUM_ORBITS, 4)
        self.composition_encoder = nn.Sequential(
            nn.Linear(119, 32), nn.SiLU(), nn.Linear(32, 32), nn.SiLU()
        )
        self.lattice_encoder = nn.Sequential(
            nn.Linear(9, 32), nn.SiLU(), nn.Linear(32, 32), nn.SiLU()
        )
        self.active_encoder = nn.Sequential(
            nn.Linear(39, 64), nn.SiLU(), nn.Linear(64, 64), nn.SiLU()
        )
        self.candidate_encoder = nn.Sequential(
            nn.Linear(33, 32), nn.SiLU(), nn.Linear(32, 32), nn.SiLU()
        )
        self.relation_encoder = nn.Sequential(
            nn.Linear(11, 32), nn.SiLU(), nn.Linear(32, 32), nn.SiLU()
        )
        self.context_encoder = nn.Sequential(
            nn.Linear(220, 128), nn.SiLU(), nn.Linear(128, 128), nn.SiLU()
        )
        self.mdn_head = nn.Sequential(
            nn.Linear(128, 128),
            nn.SiLU(),
            nn.Linear(128, MIXTURE_COMPONENTS * (1 + 6 + 3)),
        )

    def forward(self, batch: GeometryMDNBatch) -> WrappedMDNOutput:
        composition = self.composition_encoder(batch.composition)
        lattice = self.lattice_encoder(batch.lattice.reshape(len(batch.target_sg), 9))
        space_group = self.space_group_embedding(batch.target_sg)

        active_parameters = batch.active_free_parameters
        active_circular = torch.stack(
            (
                torch.sin(2.0 * torch.pi * active_parameters),
                torch.cos(2.0 * torch.pi * active_parameters),
            ),
            dim=-1,
        ).flatten(-2)
        active_tokens = torch.cat(
            (
                self.species_embedding(batch.active_species),
                self.wyckoff_embedding(batch.active_wyckoff),
                batch.active_multiplicity.unsqueeze(-1),
                self.dof_embedding(batch.active_dof),
                self.rank_embedding(batch.active_rank),
                active_circular,
            ),
            dim=-1,
        )
        active = _masked_mean(self.active_encoder(active_tokens), batch.active_mask)

        candidate_tokens = torch.cat(
            (
                self.species_embedding(batch.candidate_species),
                self.wyckoff_embedding(batch.candidate_wyckoff),
                batch.candidate_multiplicity.unsqueeze(-1),
                self.dof_embedding(batch.candidate_dof),
                self.rank_embedding(batch.candidate_rank),
            ),
            dim=-1,
        )
        candidate = self.candidate_encoder(candidate_tokens)

        relation_tokens = self.relation_encoder(batch.relation_features)
        relation = _masked_mean(relation_tokens, batch.relation_mask)
        removed = _masked_mean(
            self.rank_embedding(batch.removed_ranks), batch.removed_mask
        )
        action = torch.cat(
            (
                self.path_embedding(batch.path_index),
                self.step_embedding(batch.step_index),
                removed,
            ),
            dim=-1,
        )
        context = self.context_encoder(
            torch.cat(
                (
                    composition,
                    lattice,
                    space_group,
                    active,
                    candidate,
                    relation,
                    action,
                ),
                dim=-1,
            )
        )
        raw = self.mdn_head(context).reshape(
            len(batch.target_sg), MIXTURE_COMPONENTS, 10
        )
        logits = raw[..., 0]
        mean_vector = raw[..., 1:7].reshape(
            len(batch.target_sg), MIXTURE_COMPONENTS, 3, 2
        )
        mean_angles = torch.atan2(mean_vector[..., 0], mean_vector[..., 1])
        concentration = functional.softplus(raw[..., 7:10]).clamp(max=100.0) + 1e-4
        return WrappedMDNOutput(logits, mean_angles, concentration)


__all__ = [
    "GeometryMDNBatch",
    "MAXIMUM_ORBITS",
    "MIXTURE_COMPONENTS",
    "WrappedMDNOutput",
    "WrappedMixtureDensityDecoder",
]

