from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Literal, Mapping, Sequence

import torch

from crysalis_g1.geometry_mdn.model import GeometryMDNBatch, MAXIMUM_ORBITS
from crysalis_g1.geometry_mdn.targets import CanonicalGeometryTarget


SCHEMA_VERSION = "canonical-geometry-mdn.1.0.0"
RELATION_SCALES = torch.tensor(
    [1.0, 64.0, 64.0, 1.0, 5.0, 5.0, 5.0, 5.0, 32.0, 32.0, 1.0]
)


def _wyckoff_index(letter: str) -> int:
    return ord(letter.strip().lower()) - ord("a")


@dataclass(frozen=True, slots=True)
class PackedGeometryDataset:
    tensors: Mapping[str, torch.Tensor]
    event_ids: tuple[str, ...]
    parent_ids: tuple[str, ...]
    candidate_orbit_ids: tuple[str, ...]

    def __len__(self) -> int:
        return len(self.event_ids)

    @property
    def active_dof_indices(self) -> torch.Tensor:
        return torch.nonzero(self.tensors["free_dof_mask"].any(dim=1)).flatten()

    def batch(
        self,
        indices: torch.Tensor,
        *,
        relation_mode: Literal["direct", "oracle", "predicted"],
        predicted_relation_features: torch.Tensor | None = None,
    ) -> tuple[GeometryMDNBatch, torch.Tensor, torch.Tensor, tuple[str, ...]]:
        rows = indices.to(dtype=torch.long, device="cpu")
        selected = {name: tensor.index_select(0, rows) for name, tensor in self.tensors.items() if name not in {"target_values", "target_offsets"}}
        if relation_mode == "direct":
            relation_features = torch.zeros_like(selected["relation_features"])
            relation_mask = torch.zeros_like(selected["relation_mask"])
        elif relation_mode == "oracle":
            relation_features = selected["relation_features"]
            relation_mask = selected["relation_mask"]
        elif relation_mode == "predicted":
            if predicted_relation_features is None:
                raise ValueError("predicted relation mode requires frozen predictions")
            if predicted_relation_features.shape != selected["relation_features"].shape:
                raise ValueError("predicted relation feature shape mismatch")
            relation_features = predicted_relation_features
            relation_mask = selected["relation_mask"]
        else:
            raise ValueError("unknown relation mode")
        model_batch = GeometryMDNBatch(
            composition=selected["composition"],
            target_sg=selected["target_sg"],
            lattice=selected["lattice"],
            active_species=selected["active_species"],
            active_wyckoff=selected["active_wyckoff"],
            active_multiplicity=selected["active_multiplicity"],
            active_dof=selected["active_dof"],
            active_rank=selected["active_rank"],
            active_free_parameters=selected["active_free_parameters"],
            active_mask=selected["active_mask"],
            candidate_species=selected["candidate_species"],
            candidate_wyckoff=selected["candidate_wyckoff"],
            candidate_multiplicity=selected["candidate_multiplicity"],
            candidate_dof=selected["candidate_dof"],
            candidate_rank=selected["candidate_rank"],
            path_index=selected["path_index"],
            step_index=selected["step_index"],
            removed_ranks=selected["removed_ranks"],
            removed_mask=selected["removed_mask"],
            relation_features=relation_features,
            relation_mask=relation_mask,
            free_dof_mask=selected["free_dof_mask"],
        )
        offsets = self.tensors["target_offsets"]
        target_rows = [
            self.tensors["target_values"][int(offsets[index]) : int(offsets[index + 1])]
            for index in rows.tolist()
        ]
        maximum = max(len(item) for item in target_rows)
        targets = torch.zeros(len(rows), maximum, 3, dtype=torch.float32)
        target_mask = torch.zeros(len(rows), maximum, dtype=torch.bool)
        for row, values in enumerate(target_rows):
            targets[row, : len(values)] = values
            target_mask[row, : len(values)] = True
        keys = tuple(self.event_ids[index] for index in rows.tolist())
        return model_batch, targets, target_mask, keys


def pack_targets(targets: Sequence[CanonicalGeometryTarget]) -> PackedGeometryDataset:
    if not targets:
        raise ValueError("cannot pack an empty target dataset")
    count = len(targets)
    composition = torch.zeros(count, 119, dtype=torch.float32)
    target_sg = torch.empty(count, dtype=torch.long)
    lattice = torch.empty(count, 3, 3, dtype=torch.float32)
    active_species = torch.zeros(count, MAXIMUM_ORBITS, dtype=torch.long)
    active_wyckoff = torch.zeros(count, MAXIMUM_ORBITS, dtype=torch.long)
    active_multiplicity = torch.zeros(count, MAXIMUM_ORBITS, dtype=torch.float32)
    active_dof = torch.zeros(count, MAXIMUM_ORBITS, dtype=torch.long)
    active_rank = torch.zeros(count, MAXIMUM_ORBITS, dtype=torch.long)
    active_free_parameters = torch.zeros(count, MAXIMUM_ORBITS, 3)
    active_mask = torch.zeros(count, MAXIMUM_ORBITS, dtype=torch.bool)
    candidate_species = torch.empty(count, dtype=torch.long)
    candidate_wyckoff = torch.empty(count, dtype=torch.long)
    candidate_multiplicity = torch.empty(count)
    candidate_dof = torch.empty(count, dtype=torch.long)
    candidate_rank = torch.empty(count, dtype=torch.long)
    path_index = torch.empty(count, dtype=torch.long)
    step_index = torch.empty(count, dtype=torch.long)
    removed_ranks = torch.zeros(count, MAXIMUM_ORBITS, dtype=torch.long)
    removed_mask = torch.zeros(count, MAXIMUM_ORBITS, dtype=torch.bool)
    relation_features = torch.zeros(count, MAXIMUM_ORBITS, 11)
    relation_mask = torch.zeros(count, MAXIMUM_ORBITS, dtype=torch.bool)
    free_dof_mask = torch.empty(count, 3, dtype=torch.bool)
    target_values = []
    target_offsets = [0]
    for row, target in enumerate(targets):
        total_atoms = sum(item[1] for item in target.composition)
        for species, atoms in target.composition:
            composition[row, species] = float(atoms) / float(total_atoms)
        target_sg[row] = target.target_space_group
        lattice[row] = torch.tensor(target.lattice, dtype=torch.float32) / 10.0
        if len(target.active_orbits) > MAXIMUM_ORBITS:
            raise ValueError("active orbit count exceeds the frozen maximum")
        for index, orbit in enumerate(target.active_orbits):
            active_species[row, index] = orbit.species
            active_wyckoff[row, index] = _wyckoff_index(orbit.wyckoff_letter)
            active_multiplicity[row, index] = orbit.multiplicity / 12.0
            active_dof[row, index] = orbit.free_dof
            active_rank[row, index] = orbit.instance_rank
            active_free_parameters[row, index, : orbit.free_dof] = torch.tensor(
                orbit.free_parameters
            )
            active_mask[row, index] = True
        candidate = target.candidate_orbit
        candidate_species[row] = candidate.species
        candidate_wyckoff[row] = _wyckoff_index(candidate.wyckoff_letter)
        candidate_multiplicity[row] = candidate.multiplicity / 12.0
        candidate_dof[row] = candidate.free_dof
        candidate_rank[row] = candidate.instance_rank
        path_index[row] = target.action_context.path_index
        step_index[row] = target.action_context.step_index
        removed = target.action_context.removed_instance_ranks
        removed_ranks[row, : len(removed)] = torch.tensor(removed, dtype=torch.long)
        removed_mask[row, : len(removed)] = True
        for index, values in enumerate(target.relation_features):
            relation_features[row, index] = torch.tensor(values) / RELATION_SCALES
            relation_mask[row, index] = True
        free_dof_mask[row] = torch.tensor(target.free_dof_mask)
        target_values.extend(target.target_equivalents)
        target_offsets.append(len(target_values))
    tensors = {
        "composition": composition,
        "target_sg": target_sg,
        "lattice": lattice,
        "active_species": active_species,
        "active_wyckoff": active_wyckoff,
        "active_multiplicity": active_multiplicity,
        "active_dof": active_dof,
        "active_rank": active_rank,
        "active_free_parameters": active_free_parameters,
        "active_mask": active_mask,
        "candidate_species": candidate_species,
        "candidate_wyckoff": candidate_wyckoff,
        "candidate_multiplicity": candidate_multiplicity,
        "candidate_dof": candidate_dof,
        "candidate_rank": candidate_rank,
        "path_index": path_index,
        "step_index": step_index,
        "removed_ranks": removed_ranks,
        "removed_mask": removed_mask,
        "relation_features": relation_features,
        "relation_mask": relation_mask,
        "free_dof_mask": free_dof_mask,
        "target_values": torch.tensor(target_values, dtype=torch.float32),
        "target_offsets": torch.tensor(target_offsets, dtype=torch.long),
    }
    return PackedGeometryDataset(
        tensors=tensors,
        event_ids=tuple(target.event_id for target in targets),
        parent_ids=tuple(target.parent_id for target in targets),
        candidate_orbit_ids=tuple(
            target.candidate_orbit.orbit_instance_id for target in targets
        ),
    )


def save_packed_dataset(dataset: PackedGeometryDataset, path: str | Path) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    torch.save(
        {
            "schema_version": SCHEMA_VERSION,
            "tensors": dict(dataset.tensors),
            "event_ids": dataset.event_ids,
            "parent_ids": dataset.parent_ids,
            "candidate_orbit_ids": dataset.candidate_orbit_ids,
        },
        temporary,
    )
    os.replace(temporary, destination)


def load_packed_dataset(path: str | Path) -> PackedGeometryDataset:
    payload = torch.load(Path(path), map_location="cpu", weights_only=False)
    if payload.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("packed canonical geometry schema mismatch")
    dataset = PackedGeometryDataset(
        tensors=payload["tensors"],
        event_ids=tuple(payload["event_ids"]),
        parent_ids=tuple(payload["parent_ids"]),
        candidate_orbit_ids=tuple(payload["candidate_orbit_ids"]),
    )
    if not (
        len(dataset.parent_ids)
        == len(dataset.candidate_orbit_ids)
        == len(dataset.event_ids)
    ):
        raise ValueError("packed canonical geometry metadata count mismatch")
    return dataset


__all__ = [
    "PackedGeometryDataset",
    "load_packed_dataset",
    "pack_targets",
    "save_packed_dataset",
]
