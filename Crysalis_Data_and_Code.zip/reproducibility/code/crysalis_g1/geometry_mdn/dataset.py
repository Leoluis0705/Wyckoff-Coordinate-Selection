from __future__ import annotations

import hashlib
import json
from collections import defaultdict
from collections.abc import Mapping, Sequence
from typing import Any, Literal

import numpy as np

from crysalis_g1.geometry_mdn.equivalence import torus_delta
from crysalis_g1.geometry_mdn.targets import (
    CanonicalActionContext,
    CanonicalGeometryTarget,
    target_from_integrated_event,
)


def _hash_payload(payload: object) -> str:
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def canonical_event_key(
    parent_id: str, candidate_orbit_id: str, active_orbit_ids: Sequence[str]
) -> str:
    return _hash_payload(
        {
            "parent_id": str(parent_id),
            "candidate_orbit_id": str(candidate_orbit_id),
            "active_orbit_ids": tuple(sorted(str(item) for item in active_orbit_ids)),
        }
    )


def collect_action_contexts(
    bundles: Sequence[Any],
) -> dict[str, CanonicalActionContext]:
    contexts: dict[str, CanonicalActionContext] = {}
    for bundle in bundles:
        parent_id = str(bundle.parent.material_id)
        orbit_ids = tuple(
            sorted(str(orbit.orbit_instance_id) for orbit in bundle.recovered_parent.orbits)
        )
        rank_by_id = {orbit_id: index for index, orbit_id in enumerate(orbit_ids)}
        for trajectory in sorted(
            bundle.d_orbit_trajectories, key=lambda item: int(item.path_index)
        ):
            active = set(orbit_ids)
            removed_ranks: list[int] = []
            for step_index, action in enumerate(trajectory.forward_actions):
                if action.operator != "D_orbit" or action.mode != "REMOVE":
                    raise ValueError("canonical geometry accepts only D_orbit removals")
                candidate_id = str(action.target_id)
                if candidate_id not in active:
                    raise ValueError("action removes an inactive canonical orbit")
                active.remove(candidate_id)
                removed_ranks.append(rank_by_id[candidate_id])
                active_ids = tuple(sorted(active))
                event_key = canonical_event_key(parent_id, candidate_id, active_ids)
                context = CanonicalActionContext(
                    path_index=int(trajectory.path_index),
                    step_index=step_index,
                    removed_instance_ranks=tuple(removed_ranks),
                    active_instance_ranks=tuple(rank_by_id[item] for item in active_ids),
                )
                existing = contexts.get(event_key)
                if existing is None or context.consumed_features() < existing.consumed_features():
                    contexts[event_key] = context
    return contexts


def build_canonical_targets(
    bundles: Sequence[Any], corpus: Any
) -> tuple[CanonicalGeometryTarget, ...]:
    contexts = collect_action_contexts(bundles)
    rank_by_parent = {
        str(bundle.parent.material_id): {
            orbit_id: index
            for index, orbit_id in enumerate(
                sorted(
                    str(orbit.orbit_instance_id)
                    for orbit in bundle.recovered_parent.orbits
                )
            )
        }
        for bundle in bundles
    }
    targets = []
    for event in (*corpus.train_events, *corpus.validation_events):
        if event.candidate_orbit is None:
            continue
        event_key = str(event.event_key)
        if event_key not in contexts:
            raise ValueError(f"canonical action context missing for event {event_key}")
        targets.append(
            target_from_integrated_event(
                event,
                orbit_rank_by_id=rank_by_parent[str(event.parent_id)],
                action_context=contexts[event_key],
            )
        )
    if len(targets) != int(corpus.report["unique_deconstruction_event_count"]):
        raise ValueError("canonical geometry event count drifted from Phase-2A corpus")
    if len({target.event_id for target in targets}) != len(targets):
        raise ValueError("canonical geometry event IDs are not unique")
    return tuple(targets)


def _targets_equivalent(
    first: CanonicalGeometryTarget,
    second: CanonicalGeometryTarget,
    *,
    tolerance: float = 1e-7,
) -> bool:
    if first.free_dof_mask != second.free_dof_mask:
        return False
    active = np.asarray(first.free_dof_mask, dtype=bool)
    first_values = [np.asarray(item, dtype=float) for item in first.target_equivalents]
    second_values = [np.asarray(item, dtype=float) for item in second.target_equivalents]

    def covered(source: list[np.ndarray], destination: list[np.ndarray]) -> bool:
        return all(
            min(
                float(
                    np.max(
                        np.abs(torus_delta(value, candidate))[active], initial=0.0
                    )
                )
                for candidate in destination
            )
            <= tolerance
            for value in source
        )

    return covered(first_values, second_values) and covered(second_values, first_values)


def _canonical_identity_signature(target: CanonicalGeometryTarget) -> tuple[object, ...]:
    return (
        target.candidate_orbit.orbit_instance_id,
        tuple(orbit.orbit_instance_id for orbit in target.active_orbits),
        target.action_context.removed_instance_ranks,
        target.action_context.active_instance_ranks,
    )


def classify_condition_groups(
    targets: Sequence[CanonicalGeometryTarget],
    *,
    relation_mode: Literal["direct", "oracle", "predicted"],
) -> dict[str, int]:
    groups: dict[str, list[CanonicalGeometryTarget]] = defaultdict(list)
    for target in targets:
        condition_hash = _hash_payload(
            target.consumed_condition_payload(relation_mode=relation_mode)
        )
        groups[condition_hash].append(target)
    counts = {
        "REPEATED_CONDITION_GROUP": 0,
        "REPRESENTATIVE_ONLY_CONFLICT": 0,
        "CONDITION_ALIASING": 0,
        "GENUINE_MULTIMODALITY": 0,
    }
    for rows in groups.values():
        if len(rows) < 2:
            continue
        counts["REPEATED_CONDITION_GROUP"] += 1
        reference = rows[0]
        if all(_targets_equivalent(reference, item) for item in rows[1:]):
            counts["REPRESENTATIVE_ONLY_CONFLICT"] += 1
            continue
        identities = {_canonical_identity_signature(item) for item in rows}
        if len(identities) > 1:
            counts["CONDITION_ALIASING"] += 1
        else:
            counts["GENUINE_MULTIMODALITY"] += 1
    return counts


__all__ = [
    "build_canonical_targets",
    "canonical_event_key",
    "classify_condition_groups",
    "collect_action_contexts",
]
