from __future__ import annotations

import hashlib
import json
import os
import random
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Literal

import numpy as np
import torch

from crysalis_g1.geometry_mdn.losses import equivalence_marginalized_nll
from crysalis_g1.geometry_mdn.model import WrappedMixtureDensityDecoder
from crysalis_g1.geometry_mdn.serialization import PackedGeometryDataset


RelationMode = Literal["direct", "oracle", "predicted"]


@dataclass(frozen=True, slots=True)
class MDNTrainingConfig:
    seed: int = 20260823
    max_updates: int = 1500
    batch_size: int = 128
    validation_interval: int = 100
    learning_rate: float = 3.0e-4
    weight_decay: float = 1.0e-5
    gradient_clip_norm: float = 1.0

    def __post_init__(self) -> None:
        if self.seed != 20260823 or self.max_updates != 1500:
            raise ValueError("the canonical MDN budget and seed are frozen")
        if self.batch_size != 128 or self.validation_interval != 100:
            raise ValueError("the canonical MDN batch and validation interval are frozen")
        if self.learning_rate != 3.0e-4 or self.weight_decay != 1.0e-5:
            raise ValueError("the canonical MDN optimizer settings are frozen")
        if self.gradient_clip_norm != 1.0:
            raise ValueError("the canonical MDN gradient clip is frozen")


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def build_batch_schedule(
    active_indices: torch.Tensor,
    *,
    updates: int,
    batch_size: int,
    seed: int,
) -> torch.Tensor:
    indices = active_indices.to(dtype=torch.long, device="cpu")
    if indices.ndim != 1 or len(indices) == 0:
        raise ValueError("training needs at least one active free-DOF event")
    generator = torch.Generator(device="cpu").manual_seed(seed)
    chunks: list[torch.Tensor] = []
    required = updates * batch_size
    while sum(len(chunk) for chunk in chunks) < required:
        chunks.append(indices[torch.randperm(len(indices), generator=generator)])
    return torch.cat(chunks)[:required].reshape(updates, batch_size)


def state_dict_sha256(model: torch.nn.Module) -> str:
    digest = hashlib.sha256()
    for name, tensor in sorted(model.state_dict().items()):
        digest.update(name.encode("utf-8"))
        value = tensor.detach().cpu().contiguous()
        digest.update(value.numpy().tobytes())
    return digest.hexdigest()


def _json_float(value: float) -> float | None:
    return float(value) if np.isfinite(value) else None


def _atomic_torch_save(payload: object, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    torch.save(payload, temporary)
    os.replace(temporary, destination)


def _append_jsonl(path: Path, record: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(record, sort_keys=True, allow_nan=False) + "\n")


def validation_nll(
    model: WrappedMixtureDensityDecoder,
    dataset: PackedGeometryDataset,
    *,
    relation_mode: RelationMode,
    device: torch.device,
    batch_size: int = 512,
) -> float:
    model.eval()
    indices = dataset.active_dof_indices
    total = 0.0
    count = 0
    with torch.no_grad():
        for start in range(0, len(indices), batch_size):
            rows = indices[start : start + batch_size]
            batch, targets, target_mask, _ = dataset.batch(
                rows, relation_mode=relation_mode
            )
            batch = batch.to(device)
            loss = equivalence_marginalized_nll(
                model(batch),
                targets.to(device),
                target_mask.to(device),
                batch.free_dof_mask,
            )
            total += float(loss) * len(rows)
            count += len(rows)
    if count == 0:
        raise ValueError("validation has no active free-DOF events")
    value = total / count
    if not np.isfinite(value):
        raise FloatingPointError("validation NLL is non-finite")
    return value


def train_arm(
    train_dataset: PackedGeometryDataset,
    validation_dataset: PackedGeometryDataset,
    *,
    relation_mode: RelationMode,
    schedule: torch.Tensor,
    output_dir: str | Path,
    device: str | torch.device,
    config: MDNTrainingConfig = MDNTrainingConfig(),
    stop_update: int | None = None,
) -> dict[str, object]:
    if relation_mode not in {"direct", "oracle"}:
        raise ValueError("this trainer accepts only the preregistered first-stage arms")
    if schedule.shape != (config.max_updates, config.batch_size):
        raise ValueError("shared batch schedule shape differs from the frozen budget")
    final_update = config.max_updates if stop_update is None else int(stop_update)
    if not 1 <= final_update <= config.max_updates:
        raise ValueError("invalid stop update")

    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    checkpoint = destination / "latest_checkpoint.pt"
    metrics_path = destination / "training_metrics.jsonl"
    compute_device = torch.device(device)
    seed_everything(config.seed)
    model = WrappedMixtureDensityDecoder().to(compute_device)
    initialization_hash = state_dict_sha256(model)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=config.learning_rate,
        weight_decay=config.weight_decay,
    )
    start_update = 0
    best_validation = float("inf")
    elapsed_before = 0.0
    if checkpoint.exists():
        payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
        if payload["relation_mode"] != relation_mode:
            raise ValueError("checkpoint relation arm mismatch")
        if payload["config"] != asdict(config):
            raise ValueError("checkpoint training contract mismatch")
        if payload["initialization_hash"] != initialization_hash:
            raise ValueError("checkpoint initialization mismatch")
        model.load_state_dict(payload["model"])
        optimizer.load_state_dict(payload["optimizer"])
        start_update = int(payload["update"])
        best_validation = float(payload["best_validation_nll"])
        elapsed_before = float(payload["elapsed_seconds"])
    if start_update >= final_update:
        return {
            "relation_mode": relation_mode,
            "completed_update": start_update,
            "elapsed_seconds": elapsed_before,
            "seconds_per_update": elapsed_before / start_update,
            "initialization_hash": initialization_hash,
            "parameter_count": sum(item.numel() for item in model.parameters()),
            "best_validation_nll": _json_float(best_validation),
        }

    model.train()
    started = time.perf_counter()
    latest_loss = float("nan")
    latest_gradient = float("nan")
    for update_index in range(start_update, final_update):
        rows = schedule[update_index]
        batch, targets, target_mask, _ = train_dataset.batch(
            rows, relation_mode=relation_mode
        )
        batch = batch.to(compute_device)
        optimizer.zero_grad(set_to_none=True)
        loss = equivalence_marginalized_nll(
            model(batch),
            targets.to(compute_device),
            target_mask.to(compute_device),
            batch.free_dof_mask,
        )
        loss.backward()
        gradient = torch.nn.utils.clip_grad_norm_(
            model.parameters(), config.gradient_clip_norm
        )
        if not torch.isfinite(gradient):
            raise FloatingPointError("MDN gradient norm is non-finite")
        optimizer.step()
        latest_loss = float(loss.detach())
        latest_gradient = float(gradient.detach())
        completed = update_index + 1
        validation_value: float | None = None
        if completed % config.validation_interval == 0:
            validation_value = validation_nll(
                model,
                validation_dataset,
                relation_mode=relation_mode,
                device=compute_device,
            )
            model.train()
            if validation_value < best_validation:
                best_validation = validation_value
                _atomic_torch_save(
                    {
                        "schema_version": "wrapped-mdn-checkpoint.1.0.0",
                        "arm": relation_mode,
                        "update": completed,
                        "model": model.state_dict(),
                        "validation_nll": validation_value,
                        "config": asdict(config),
                        "initialization_hash": initialization_hash,
                    },
                    destination / "best_validation_checkpoint.pt",
                )
        elapsed = elapsed_before + time.perf_counter() - started
        _append_jsonl(
            metrics_path,
            {
                "arm": relation_mode,
                "development_diagnostic": True,
                "gradient_norm": latest_gradient,
                "train_nll": latest_loss,
                "update": completed,
                "validation_nll": validation_value,
                "wall_seconds": elapsed,
            },
        )
        if completed in {50, final_update} or completed % config.validation_interval == 0:
            _atomic_torch_save(
                {
                    "schema_version": "wrapped-mdn-training-state.1.0.0",
                    "relation_mode": relation_mode,
                    "update": completed,
                    "model": model.state_dict(),
                    "optimizer": optimizer.state_dict(),
                    "best_validation_nll": best_validation,
                    "config": asdict(config),
                    "initialization_hash": initialization_hash,
                    "elapsed_seconds": elapsed,
                },
                checkpoint,
            )

    elapsed = elapsed_before + time.perf_counter() - started
    if final_update == config.max_updates:
        _atomic_torch_save(
            {
                "schema_version": "wrapped-mdn-checkpoint.1.0.0",
                "arm": relation_mode,
                "update": final_update,
                "model": model.state_dict(),
                "validation_nll": validation_nll(
                    model,
                    validation_dataset,
                    relation_mode=relation_mode,
                    device=compute_device,
                ),
                "config": asdict(config),
                "initialization_hash": initialization_hash,
            },
            destination / "final_update_1500_checkpoint.pt",
        )
    return {
        "relation_mode": relation_mode,
        "completed_update": final_update,
        "elapsed_seconds": elapsed,
        "seconds_per_update": elapsed / final_update,
        "initialization_hash": initialization_hash,
        "parameter_count": sum(item.numel() for item in model.parameters()),
        "latest_train_nll": latest_loss,
        "latest_gradient_norm": latest_gradient,
        "best_validation_nll": _json_float(best_validation),
    }


__all__ = [
    "MDNTrainingConfig",
    "build_batch_schedule",
    "seed_everything",
    "state_dict_sha256",
    "train_arm",
    "validation_nll",
]
