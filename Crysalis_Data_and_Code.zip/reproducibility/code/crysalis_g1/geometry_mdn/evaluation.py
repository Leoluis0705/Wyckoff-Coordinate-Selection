from __future__ import annotations

import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from statistics import fmean
from typing import Any, Iterable, Literal, Mapping, Sequence

import numpy as np
import torch
from pymatgen.analysis.structure_matcher import StructureMatcher
from pymatgen.core import Lattice, Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
from pymatgen.util.coord import pbc_shortest_vectors
from scipy.optimize import linear_sum_assignment

from crysalis_g1.geometry_mdn.model import WrappedMixtureDensityDecoder
from crysalis_g1.geometry_mdn.sampling import registered_mdn_samples_with_components
from crysalis_g1.geometry_mdn.serialization import PackedGeometryDataset
from crysalis_g1.symmetry.assembly import C0SymmetryProjector, SymmetryAssemblyState
from crysalis_g1.symmetry.wyckoff import OrbitState, _expanded_coordinates


RelationMode = Literal["direct", "oracle", "predicted"]


def load_final_model(
    checkpoint_path: str | Path, *, device: str | torch.device
) -> WrappedMixtureDensityDecoder:
    payload = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    if payload.get("schema_version") != "wrapped-mdn-checkpoint.1.0.0":
        raise ValueError("wrapped MDN checkpoint schema mismatch")
    if int(payload.get("update", -1)) != 1500:
        raise ValueError("primary MDN comparison requires the final update-1500 model")
    model = WrappedMixtureDensityDecoder()
    model.load_state_dict(payload["model"])
    model.to(device).eval()
    return model


def infer_registered_samples(
    model: WrappedMixtureDensityDecoder,
    dataset: PackedGeometryDataset,
    *,
    event_keys: Sequence[str],
    relation_mode: RelationMode,
    device: str | torch.device,
    root_seed: int = 20260823,
    sample_count: int = 8,
    batch_size: int = 512,
) -> dict[str, dict[str, Any]]:
    index_by_event = {key: index for index, key in enumerate(dataset.event_ids)}
    if len(index_by_event) != len(dataset.event_ids):
        raise ValueError("validation event IDs are not unique")
    missing = [key for key in event_keys if key not in index_by_event]
    if missing:
        raise ValueError(f"diagnostic events are absent from validation: {len(missing)}")
    result: dict[str, dict[str, Any]] = {}
    compute_device = torch.device(device)
    for start in range(0, len(event_keys), batch_size):
        requested_keys = tuple(event_keys[start : start + batch_size])
        requested_rows = [index_by_event[key] for key in requested_keys]
        active_pairs = [
            (key, row)
            for key, row in zip(requested_keys, requested_rows, strict=True)
            if bool(dataset.tensors["free_dof_mask"][row].any())
        ]
        for key, row in zip(requested_keys, requested_rows, strict=True):
            if bool(dataset.tensors["free_dof_mask"][row].any()):
                continue
            result[key] = {
                "components": [-1] * sample_count,
                "equivalent_targets": [[0.0, 0.0, 0.0]],
                "free_dof_mask": [False, False, False],
                "samples": np.zeros((sample_count, 3), dtype=float).tolist(),
                "sample_circular_linf": [0.0] * sample_count,
            }
        if not active_pairs:
            continue
        keys = tuple(key for key, _ in active_pairs)
        rows = torch.tensor([row for _, row in active_pairs], dtype=torch.long)
        batch, targets, target_mask, returned_keys = dataset.batch(
            rows, relation_mode=relation_mode
        )
        if returned_keys != keys:
            raise ValueError("diagnostic event ordering drift")
        with torch.no_grad():
            output = model(batch.to(compute_device))
        samples, components = registered_mdn_samples_with_components(
            output,
            batch.free_dof_mask,
            root_seed=root_seed,
            event_keys=keys,
            sample_count=sample_count,
        )
        for row, key in enumerate(keys):
            equivalents = targets[row, target_mask[row]].numpy()
            mask = batch.free_dof_mask[row].numpy().astype(bool)
            errors = []
            for sample in samples[row]:
                if mask.any():
                    delta = sample[None, :] - equivalents
                    delta -= np.round(delta)
                    errors.append(float(np.min(np.max(np.abs(delta[:, mask]), axis=1))))
                else:
                    errors.append(0.0)
            result[key] = {
                "components": components[row].tolist(),
                "equivalent_targets": equivalents.tolist(),
                "free_dof_mask": mask.tolist(),
                "samples": samples[row].tolist(),
                "sample_circular_linf": errors,
            }
    return result


def _orbit_coordinates(orbit: OrbitState) -> np.ndarray:
    return np.asarray(
        _expanded_coordinates(
            orbit.target_space_group,
            orbit.wyckoff_letter,
            orbit.free_parameters,
            orbit.cell_transform_values,
        ),
        dtype=float,
    )


def orbit_rmsd_angstrom(
    target: OrbitState,
    sampled_parameters: Sequence[float],
    lattice: Sequence[Sequence[float]],
) -> float:
    candidate = OrbitState.create(
        target.target_space_group,
        target.wyckoff_letter,
        target.species,
        sampled_parameters,
        cell_transform=target.cell_transform_values,
        orbit_instance_id=f"mdn-diagnostic:{target.orbit_instance_id}",
    )
    left = _orbit_coordinates(target)
    right = _orbit_coordinates(candidate)
    vectors = np.asarray(
        pbc_shortest_vectors(Lattice(np.asarray(lattice, dtype=float)), left, right),
        dtype=float,
    )
    cost = np.linalg.norm(vectors, axis=-1)
    row, column = linear_sum_assignment(cost)
    return float(math.sqrt(np.mean(cost[row, column] ** 2)))


def coverage_class(circular_linf: float) -> str:
    if circular_linf <= 0.05:
        return "GOOD"
    if circular_linf <= 0.15:
        return "COARSE"
    return "FAILURE"


def summarize_distribution_coverage(
    sample_records: Mapping[str, Mapping[str, Any]],
    diagnostic_rows: Sequence[Mapping[str, Any]],
    orbit_by_id: Mapping[str, OrbitState],
    lattice_by_parent: Mapping[str, Sequence[Sequence[float]]],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    records = []
    for source in diagnostic_rows:
        key = str(source["event_key"])
        sampled = sample_records[key]
        orbit = orbit_by_id[str(source["candidate_orbit_id"])]
        dof = len(orbit.free_parameters)
        rmsd_values = [
            orbit_rmsd_angstrom(
                orbit,
                sample[:dof],
                lattice_by_parent[str(source["parent_id"])],
            )
            for sample in sampled["samples"]
        ]
        errors = [float(value) for value in sampled["sample_circular_linf"]]
        best_error = min(errors)
        records.append(
            {
                "event_key": key,
                "parent_id": str(source["parent_id"]),
                "candidate_orbit_id": str(source["candidate_orbit_id"]),
                "wyckoff_letter": orbit.wyckoff_letter,
                "free_dof": dof,
                "coverage_class": coverage_class(best_error),
                "nearest_circular_linf": best_error,
                "nearest_orbit_rmsd_angstrom": min(rmsd_values),
                "all_sample_circular_linf": errors,
                "all_sample_orbit_rmsd_angstrom": rmsd_values,
                "components": sampled["components"],
                "finite_sample_count": int(
                    np.isfinite(np.asarray(sampled["samples"], dtype=float)).all(axis=1).sum()
                ),
            }
        )

    def summary(rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
        circular = np.asarray([row["nearest_circular_linf"] for row in rows], dtype=float)
        orbit = np.asarray(
            [row["nearest_orbit_rmsd_angstrom"] for row in rows], dtype=float
        )
        classes = Counter(str(row["coverage_class"]) for row in rows)
        components = Counter(
            int(value)
            for row in rows
            for value in row["components"]
            if int(value) >= 0
        )
        return {
            "event_count": len(rows),
            "coverage": {name: int(classes.get(name, 0)) for name in ("GOOD", "COARSE", "FAILURE")},
            "circular_linf": {
                "p50": float(np.median(circular)),
                "p90": float(np.quantile(circular, 0.9)),
            },
            "orbit_rmsd_angstrom": {
                "median": float(np.median(orbit)),
                "p90": float(np.quantile(orbit, 0.9)),
            },
            "component_occupancy": {str(key): int(components.get(key, 0)) for key in range(8)},
            "finite_sample_rate": float(
                sum(int(row["finite_sample_count"]) for row in rows) / (8 * len(rows))
            ),
        }

    per_dof = {
        str(dof): summary([row for row in records if int(row["free_dof"]) == dof])
        for dof in range(4)
        if any(int(row["free_dof"]) == dof for row in records)
    }
    letters = sorted({str(row["wyckoff_letter"]) for row in records})
    per_wyckoff = {
        letter: summary([row for row in records if row["wyckoff_letter"] == letter])
        for letter in letters
    }
    return {"overall": summary(records), "per_dof": per_dof, "per_wyckoff": per_wyckoff}, records


def _parent_structure(parent: Any) -> Structure:
    return Structure(
        Lattice(np.asarray(parent.lattice.primitive_matrix, dtype=float)),
        list(parent.reconstructed_atomic_numbers),
        np.asarray(parent.reconstructed_fractional_coordinates, dtype=float),
        to_unit_cell=True,
    )


def _receipt_structure(receipt: Any) -> Structure | None:
    if not receipt.atomic_numbers or not receipt.fractional_coordinates:
        return None
    return Structure(
        Lattice(np.asarray(receipt.lattice, dtype=float)),
        list(receipt.atomic_numbers),
        np.asarray(receipt.fractional_coordinates, dtype=float),
        to_unit_cell=True,
    )


def _structure_metrics(parent: Structure, candidate: Structure | None) -> dict[str, Any]:
    if candidate is None:
        return {
            "cartesian_rmsd_angstrom": None,
            "nearest_neighbor_error_angstrom": None,
            "parent_match": False,
            "detected_space_group": 0,
        }
    parent_numbers = np.asarray([int(site.specie.Z) for site in parent], dtype=int)
    candidate_numbers = np.asarray([int(site.specie.Z) for site in candidate], dtype=int)
    cartesian_squared: list[float] = []
    if Counter(parent_numbers.tolist()) == Counter(candidate_numbers.tolist()):
        for atomic_number in sorted(set(parent_numbers.tolist())):
            left = np.flatnonzero(parent_numbers == atomic_number)
            right = np.flatnonzero(candidate_numbers == atomic_number)
            vectors = np.asarray(
                pbc_shortest_vectors(
                    parent.lattice,
                    np.asarray(parent.frac_coords)[left],
                    np.asarray(candidate.frac_coords)[right],
                ),
                dtype=float,
            )
            cost = np.linalg.norm(vectors, axis=-1)
            row, column = linear_sum_assignment(cost)
            cartesian_squared.extend((cost[row, column] ** 2).tolist())
    rmsd = float(math.sqrt(np.mean(cartesian_squared))) if cartesian_squared else None

    def nearest_neighbors(structure: Structure) -> np.ndarray:
        if len(structure) < 2:
            return np.zeros(len(structure), dtype=float)
        distances = np.asarray(structure.distance_matrix, dtype=float).copy()
        np.fill_diagonal(distances, np.inf)
        return np.sort(np.min(distances, axis=1))

    left_nn = nearest_neighbors(parent)
    right_nn = nearest_neighbors(candidate)
    nn_error = (
        float(np.mean(np.abs(left_nn - right_nn)))
        if left_nn.shape == right_nn.shape
        else None
    )
    minimum_distance = None
    if len(candidate) > 1:
        distances = np.asarray(candidate.distance_matrix, dtype=float).copy()
        np.fill_diagonal(distances, np.inf)
        minimum_distance = float(distances.min())
    matcher_fit = False
    if minimum_distance is None or minimum_distance >= 0.5:
        matcher = StructureMatcher(ltol=0.3, stol=0.5, angle_tol=10.0)
        try:
            matcher_fit = bool(matcher.fit(parent, candidate))
        except Exception:
            matcher_fit = False
    try:
        detected = int(
            SpacegroupAnalyzer(candidate, symprec=0.03).get_space_group_number()
        )
    except Exception:
        detected = 0
    return {
        "cartesian_rmsd_angstrom": rmsd,
        "nearest_neighbor_error_angstrom": nn_error,
        "parent_match": matcher_fit,
        "detected_space_group": detected,
        "minimum_distance_angstrom": minimum_distance,
    }


def build_k1_parent_records(
    sample_records: Mapping[str, Mapping[str, Any]],
    diagnostic_rows: Sequence[Mapping[str, Any]],
    bundles: Sequence[Any],
) -> tuple[list[dict[str, Any]], dict[str, Structure]]:
    rows_by_parent: dict[str, list[Mapping[str, Any]]] = defaultdict(list)
    for row in diagnostic_rows:
        rows_by_parent[str(row["parent_id"])].append(row)
    bundle_by_parent = {str(bundle.parent.material_id): bundle for bundle in bundles}
    projector = C0SymmetryProjector(minimum_distance=0.5)
    records: list[dict[str, Any]] = []
    structures: dict[str, Structure] = {}
    for parent_id in sorted(rows_by_parent):
        bundle = bundle_by_parent[parent_id]
        event_rows = sorted(rows_by_parent[parent_id], key=lambda row: int(row["step_index"]))
        sampled_by_orbit = {
            str(row["candidate_orbit_id"]): sample_records[str(row["event_key"])]["samples"][0]
            for row in event_rows
        }
        parent_orbits = bundle.recovered_parent.orbits
        if set(sampled_by_orbit) != {orbit.orbit_instance_id for orbit in parent_orbits}:
            raise ValueError(f"diagnostic path does not cover every parent orbit: {parent_id}")
        sampled_orbits = tuple(
            OrbitState.create(
                orbit.target_space_group,
                orbit.wyckoff_letter,
                orbit.species,
                sampled_by_orbit[orbit.orbit_instance_id][: len(orbit.free_parameters)],
                cell_transform=orbit.cell_transform_values,
                orbit_instance_id=orbit.orbit_instance_id,
            )
            for orbit in parent_orbits
        )
        composition = tuple(
            sorted(Counter(bundle.recovered_parent.reconstructed_atomic_numbers).items())
        )
        state = SymmetryAssemblyState(
            target_space_group=bundle.recovered_parent.target_space_group,
            composition=composition,
            remaining_composition=(),
            lattice=bundle.recovered_parent.lattice,
            orbits=sampled_orbits,
        )
        receipt = projector.project(state)
        candidate = _receipt_structure(receipt)
        parent = _parent_structure(bundle.recovered_parent)
        metrics = _structure_metrics(parent, candidate)
        if candidate is not None:
            structures[parent_id] = candidate
        records.append(
            {
                "parent_id": parent_id,
                "target_space_group": bundle.recovered_parent.target_space_group,
                "legal": bool(receipt.accepted),
                "projector_reason_codes": list(receipt.reason_codes),
                "target_space_group_valid": metrics["detected_space_group"]
                == bundle.recovered_parent.target_space_group,
                **metrics,
                "initial_max_force_ev_per_angstrom": None,
                "chgnet_status": "PENDING" if candidate is not None else "NO_STRUCTURE",
            }
        )
    return records, structures


def add_chgnet_initial_forces(
    records: list[dict[str, Any]],
    structures: Mapping[str, Structure],
    *,
    device: str,
    batch_size: int = 16,
) -> None:
    from chgnet.model import CHGNet

    model = CHGNet.load(model_name="0.3.0", use_device=device, verbose=False)
    record_by_parent = {str(row["parent_id"]): row for row in records}
    parent_ids = sorted(structures)
    for start in range(0, len(parent_ids), batch_size):
        keys = parent_ids[start : start + batch_size]
        batch = [structures[key] for key in keys]
        try:
            output = model.predict_structure(batch, task="ef", batch_size=batch_size)
            values = output if isinstance(output, list) else [output]
            if len(values) != len(keys):
                raise ValueError("CHGNet batch output count mismatch")
            for key, value in zip(keys, values, strict=True):
                force = value["f"]
                if hasattr(force, "detach"):
                    force = force.detach().cpu()
                array = np.asarray(force, dtype=float)
                maximum = float(np.linalg.norm(array, axis=-1).max())
                record_by_parent[key]["initial_max_force_ev_per_angstrom"] = maximum
                record_by_parent[key]["chgnet_status"] = "EVALUATED"
        except Exception as error:
            for key in keys:
                record_by_parent[key]["chgnet_status"] = "EVALUATION_FAILED"
                record_by_parent[key]["chgnet_error"] = f"{type(error).__name__}: {error}"
            if torch.cuda.is_available():
                torch.cuda.empty_cache()


def summarize_k1(records: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    forces = np.asarray(
        [
            float(row["initial_max_force_ev_per_angstrom"])
            for row in records
            if row.get("initial_max_force_ev_per_angstrom") is not None
        ],
        dtype=float,
    )
    rmsd = np.asarray(
        [float(row["cartesian_rmsd_angstrom"]) for row in records if row.get("cartesian_rmsd_angstrom") is not None],
        dtype=float,
    )
    nn = np.asarray(
        [float(row["nearest_neighbor_error_angstrom"]) for row in records if row.get("nearest_neighbor_error_angstrom") is not None],
        dtype=float,
    )
    reasons = Counter(
        str(reason) for row in records for reason in row.get("projector_reason_codes", [])
    )
    return {
        "parent_count": len(records),
        "legal_count": sum(bool(row["legal"]) for row in records),
        "initial_force_evaluated_count": len(forces),
        "initial_max_force_ev_per_angstrom": {
            "median": float(np.median(forces)) if len(forces) else None,
            "p90": float(np.quantile(forces, 0.9)) if len(forces) else None,
        },
        "cartesian_rmsd_angstrom": {
            "median": float(np.median(rmsd)) if len(rmsd) else None,
            "p90": float(np.quantile(rmsd, 0.9)) if len(rmsd) else None,
        },
        "nearest_neighbor_error_angstrom": {
            "median": float(np.median(nn)) if len(nn) else None,
            "p90": float(np.quantile(nn, 0.9)) if len(nn) else None,
        },
        "parent_match_count": sum(bool(row["parent_match"]) for row in records),
        "target_space_group_valid_count": sum(bool(row["target_space_group_valid"]) for row in records),
        "short_contact_count": sum(
            "SHORT_CONTACT" in row.get("projector_reason_codes", []) for row in records
        ),
        "failure_taxonomy": dict(sorted(reasons.items())),
    }


def paired_bootstrap_oracle_value(
    direct: Sequence[Mapping[str, Any]],
    oracle: Sequence[Mapping[str, Any]],
    *,
    seed: int = 20260823,
    resamples: int = 10_000,
) -> dict[str, Any]:
    direct_by_id = {str(row["parent_id"]): row for row in direct}
    oracle_by_id = {str(row["parent_id"]): row for row in oracle}
    parent_ids = sorted(set(direct_by_id) & set(oracle_by_id))
    if len(parent_ids) != len(direct) or len(parent_ids) != len(oracle):
        raise ValueError("Direct/Oracle parent pairing is incomplete")
    force_delta = np.asarray(
        [
            math.log1p(float(oracle_by_id[key]["initial_max_force_ev_per_angstrom"]))
            - math.log1p(float(direct_by_id[key]["initial_max_force_ev_per_angstrom"]))
            for key in parent_ids
        ]
    )
    rmsd_delta = np.asarray(
        [
            float(oracle_by_id[key]["cartesian_rmsd_angstrom"])
            - float(direct_by_id[key]["cartesian_rmsd_angstrom"])
            for key in parent_ids
        ]
    )
    legal_delta = np.asarray(
        [
            float(bool(oracle_by_id[key]["legal"]))
            - float(bool(direct_by_id[key]["legal"]))
            for key in parent_ids
        ]
    )
    generator = np.random.default_rng(seed)
    indices = generator.integers(0, len(parent_ids), size=(resamples, len(parent_ids)))

    def bootstrap(values: np.ndarray) -> np.ndarray:
        return values[indices].mean(axis=1)

    force_bootstrap = bootstrap(force_delta)
    rmsd_bootstrap = bootstrap(rmsd_delta)
    legal_bootstrap = bootstrap(legal_delta)
    force_ci = [float(value) for value in np.quantile(force_bootstrap, [0.025, 0.975])]
    rmsd_ci = [float(value) for value in np.quantile(rmsd_bootstrap, [0.025, 0.975])]
    legal_lower = float(np.quantile(legal_bootstrap, 0.05))
    force_positive = force_ci[1] < 0.0
    rmsd_positive = rmsd_ci[1] < 0.0
    legal_safe = legal_lower > -0.02
    force_nonworse = float(force_delta.mean()) <= 0.0
    rmsd_nonworse = float(rmsd_delta.mean()) <= 0.0
    if force_positive and rmsd_positive and legal_safe:
        verdict = "STRONG_SUPPORTED"
    elif legal_safe and (
        (force_positive and rmsd_nonworse) or (rmsd_positive and force_nonworse)
    ):
        verdict = "PARTIAL_SUPPORTED"
    else:
        verdict = "NOT_SUPPORTED"
    return {
        "paired_parent_count": len(parent_ids),
        "bootstrap_resamples": resamples,
        "oracle_minus_direct": {
            "mean_log1p_force": {
                "point_estimate": float(force_delta.mean()),
                "ci95": force_ci,
            },
            "mean_cartesian_rmsd_angstrom": {
                "point_estimate": float(rmsd_delta.mean()),
                "ci95": rmsd_ci,
            },
            "legal_rate": {
                "point_estimate": float(legal_delta.mean()),
                "one_sided_95_lower_bound": legal_lower,
            },
        },
        "oracle_relation_value": verdict,
    }


__all__ = [
    "add_chgnet_initial_forces",
    "build_k1_parent_records",
    "coverage_class",
    "infer_registered_samples",
    "load_final_model",
    "orbit_rmsd_angstrom",
    "paired_bootstrap_oracle_value",
    "summarize_distribution_coverage",
    "summarize_k1",
]
