from __future__ import annotations

import hashlib
import math
from collections.abc import Sequence

import numpy as np
import torch

from crysalis_g1.geometry_mdn.model import WrappedMDNOutput


def _seed(root_seed: int, event_key: str, sample_index: int) -> int:
    payload = f"wrapped-mdn:{root_seed}:{event_key}:{sample_index}".encode("utf-8")
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "big", signed=False)


def registered_mdn_samples(
    output: WrappedMDNOutput,
    free_dof_mask: torch.Tensor,
    *,
    root_seed: int,
    event_keys: Sequence[str],
    sample_count: int,
) -> np.ndarray:
    samples, _ = registered_mdn_samples_with_components(
        output,
        free_dof_mask,
        root_seed=root_seed,
        event_keys=event_keys,
        sample_count=sample_count,
    )
    return samples


def registered_mdn_samples_with_components(
    output: WrappedMDNOutput,
    free_dof_mask: torch.Tensor,
    *,
    root_seed: int,
    event_keys: Sequence[str],
    sample_count: int,
) -> tuple[np.ndarray, np.ndarray]:
    if sample_count <= 0:
        raise ValueError("sample count must be positive")
    logits = output.logits.detach().cpu().double().numpy()
    means = output.mean_angles.detach().cpu().double().numpy()
    concentration = output.concentration.detach().cpu().double().numpy()
    masks = free_dof_mask.detach().cpu().numpy().astype(bool)
    if len(event_keys) != len(logits) or masks.shape != (len(logits), 3):
        raise ValueError("registered sampling batch identity mismatch")
    samples = np.zeros((len(logits), sample_count, 3), dtype=np.float64)
    components = np.zeros((len(logits), sample_count), dtype=np.int64)
    for row, event_key in enumerate(event_keys):
        stabilized = logits[row] - np.max(logits[row])
        probabilities = np.exp(stabilized)
        probabilities /= probabilities.sum()
        for sample_index in range(sample_count):
            generator = np.random.default_rng(_seed(root_seed, event_key, sample_index))
            component = int(generator.choice(len(probabilities), p=probabilities))
            components[row, sample_index] = component
            for dof_index in np.flatnonzero(masks[row]):
                angle = generator.vonmises(
                    means[row, component, dof_index],
                    concentration[row, component, dof_index],
                )
                samples[row, sample_index, dof_index] = (
                    float(angle) / (2.0 * math.pi)
                ) % 1.0
    return samples, components


__all__ = ["registered_mdn_samples", "registered_mdn_samples_with_components"]
