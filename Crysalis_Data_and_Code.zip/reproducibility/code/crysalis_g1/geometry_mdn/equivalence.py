from __future__ import annotations

import math
from collections.abc import Sequence
from functools import lru_cache

import numpy as np
from pyxtal.symmetry import Group


def wrap_unit(values: np.ndarray) -> np.ndarray:
    array = np.asarray(values, dtype=float)
    if not np.isfinite(array).all():
        raise ValueError("torus values must be finite")
    return np.mod(array, 1.0)


def torus_delta(values: np.ndarray, reference: np.ndarray) -> np.ndarray:
    delta = np.asarray(values, dtype=float) - np.asarray(reference, dtype=float)
    if not np.isfinite(delta).all():
        raise ValueError("torus displacement inputs must be finite")
    return delta - np.floor(delta + 0.5)


def _same_periodic_coordinate_set(
    first: np.ndarray, second: np.ndarray, *, tolerance: float
) -> bool:
    if first.shape != second.shape or first.ndim != 2 or first.shape[1] != 3:
        return False
    unused = set(range(len(second)))
    for row in first:
        matches = []
        for index in unused:
            residual = torus_delta(second[index], row)
            matches.append((float(np.max(np.abs(residual), initial=0.0)), index))
        if not matches:
            return False
        distance, index = min(matches)
        if distance > tolerance:
            return False
        unused.remove(index)
    return not unused


@lru_cache(maxsize=None)
def _equivalent_free_parameters_cached(
    target_space_group: int,
    wyckoff_letter: str,
    free_parameters: tuple[float, ...],
    tolerance: float = 5e-8,
) -> tuple[tuple[float, ...], ...]:
    """Enumerate parameter representatives that expand to one physical orbit.

    Each symmetry-expanded member is treated as a possible representative. A
    candidate is retained only when the official PyXtal position expands back
    to the same periodic coordinate set.
    """

    position = Group(int(target_space_group)).get_wyckoff_position(
        str(wyckoff_letter).strip().lower()
    )
    if position is None:
        raise ValueError(
            f"unknown Wyckoff position {wyckoff_letter!r} for SG {target_space_group}"
        )
    normalized = tuple(float(value) % 1.0 for value in free_parameters)
    if not all(math.isfinite(value) for value in normalized):
        raise ValueError("free parameters must be finite")
    expected_dof = int(position.get_dof())
    if len(normalized) != expected_dof:
        raise ValueError(
            f"free-DOF mismatch for SG {target_space_group} {wyckoff_letter}: "
            f"expected {expected_dof}, got {len(normalized)}"
        )
    if expected_dof == 0:
        return ((),)

    generator = position.get_position_from_free_xyzs(list(normalized))
    reference = wrap_unit(np.asarray(position.apply_ops(generator), dtype=float))
    candidates: list[tuple[float, ...]] = []
    for coordinate in reference:
        candidate = tuple(
            float(value) % 1.0 for value in position.get_free_xyzs(coordinate)
        )
        rebuilt_generator = position.get_position_from_free_xyzs(list(candidate))
        rebuilt = wrap_unit(
            np.asarray(position.apply_ops(rebuilt_generator), dtype=float)
        )
        if not _same_periodic_coordinate_set(
            reference, rebuilt, tolerance=tolerance
        ):
            continue
        if any(
            float(
                np.max(
                    np.abs(torus_delta(np.asarray(candidate), np.asarray(existing))),
                    initial=0.0,
                )
            )
            <= tolerance
            for existing in candidates
        ):
            continue
        candidates.append(candidate)
    if not candidates:
        raise ValueError("no official equivalent free-parameter representative found")
    candidates.sort(key=lambda item: tuple(round(value, 14) for value in item))
    return tuple(candidates)


def equivalent_free_parameters(
    target_space_group: int,
    wyckoff_letter: str,
    free_parameters: Sequence[float],
    *,
    tolerance: float = 5e-8,
) -> tuple[tuple[float, ...], ...]:
    """Enumerate all verified representatives under the official parameterization."""

    return _equivalent_free_parameters_cached(
        int(target_space_group),
        str(wyckoff_letter).strip().lower(),
        tuple(float(value) for value in free_parameters),
        float(tolerance),
    )


def equivalence_min_linf(
    values: np.ndarray,
    equivalents: Sequence[Sequence[float]],
    mask: Sequence[bool],
) -> float:
    active = np.asarray(tuple(mask), dtype=bool)
    if active.shape != (3,):
        raise ValueError("free-DOF mask must be a boolean 3-vector")
    sample = np.asarray(values, dtype=float)
    if sample.shape != (3,):
        raise ValueError("sample must be a 3-vector")
    if not equivalents:
        raise ValueError("equivalence set must be non-empty")
    distances = []
    for item in equivalents:
        target = np.asarray(tuple(item), dtype=float)
        if target.shape != (3,):
            raise ValueError("equivalent target must be a 3-vector")
        residual = np.abs(torus_delta(sample, target))[active]
        distances.append(float(np.max(residual, initial=0.0)))
    return min(distances)


__all__ = [
    "equivalence_min_linf",
    "equivalent_free_parameters",
    "torus_delta",
    "wrap_unit",
]
