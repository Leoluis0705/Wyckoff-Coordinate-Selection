from __future__ import annotations

import math

import torch
from torch.nn import functional

from crysalis_g1.geometry_mdn.model import WrappedMDNOutput


def equivalence_marginalized_nll(
    output: WrappedMDNOutput,
    equivalent_targets: torch.Tensor,
    equivalent_mask: torch.Tensor,
    free_dof_mask: torch.Tensor,
) -> torch.Tensor:
    if equivalent_targets.ndim != 3 or equivalent_targets.shape[-1] != 3:
        raise ValueError("equivalent targets must have shape [B,E,3]")
    if equivalent_mask.shape != equivalent_targets.shape[:2]:
        raise ValueError("equivalent target mask shape mismatch")
    if free_dof_mask.shape != (equivalent_targets.shape[0], 3):
        raise ValueError("free-DOF mask shape mismatch")
    if not free_dof_mask.any(dim=1).all():
        raise ValueError("zero-DOF rows must bypass the MDN loss")
    theta = equivalent_targets.unsqueeze(2) * (2.0 * torch.pi)
    mean = output.mean_angles.unsqueeze(1)
    concentration = output.concentration.unsqueeze(1)
    log_i0 = torch.log(torch.special.i0e(concentration)) + concentration.abs()
    coordinate_log_prob = (
        concentration * torch.cos(theta - mean)
        - math.log(2.0 * math.pi)
        - log_i0
    )
    dof = free_dof_mask[:, None, None, :].to(coordinate_log_prob.dtype)
    component_log_prob = (coordinate_log_prob * dof).sum(dim=-1)
    mixture_log_prob = torch.logsumexp(
        component_log_prob + functional.log_softmax(output.logits, dim=-1).unsqueeze(1),
        dim=-1,
    )
    valid = equivalent_mask.to(torch.bool)
    masked = mixture_log_prob.masked_fill(~valid, -torch.inf)
    counts = valid.sum(dim=1)
    if not (counts > 0).all():
        raise ValueError("each row needs an equivalence representative")
    marginalized = torch.logsumexp(masked, dim=1) - counts.to(
        mixture_log_prob.dtype
    ).log()
    loss = -marginalized.mean()
    if not torch.isfinite(loss):
        raise FloatingPointError("wrapped MDN NLL is non-finite")
    return loss


__all__ = ["equivalence_marginalized_nll"]

