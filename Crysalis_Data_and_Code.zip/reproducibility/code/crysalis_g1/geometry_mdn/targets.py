from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Literal, Mapping

from crysalis_g1.geometry_mdn.equivalence import equivalent_free_parameters


def _wyckoff_index(letter: str) -> int:
    normalized = str(letter).strip().lower()
    if len(normalized) != 1 or not "a" <= normalized <= "z":
        raise ValueError(f"invalid Wyckoff letter: {letter!r}")
    return ord(normalized) - ord("a")


@dataclass(frozen=True, slots=True)
class CanonicalOrbitToken:
    instance_rank: int
    orbit_instance_id: str
    species: int
    wyckoff_letter: str
    multiplicity: int
    free_parameters: tuple[float, ...]

    def __post_init__(self) -> None:
        if self.instance_rank < 0 or not self.orbit_instance_id:
            raise ValueError("canonical orbit identity is required")
        if not 1 <= self.species <= 118 or self.multiplicity <= 0:
            raise ValueError("invalid orbit species or multiplicity")
        _wyckoff_index(self.wyckoff_letter)
        if not 0 <= len(self.free_parameters) <= 3:
            raise ValueError("free-DOF count must be between zero and three")
        if not all(math.isfinite(float(value)) for value in self.free_parameters):
            raise ValueError("free parameters must be finite")

    @property
    def free_dof(self) -> int:
        return len(self.free_parameters)

    def identity_features(self) -> tuple[int, int, int, int, int]:
        return (
            self.instance_rank,
            self.species,
            _wyckoff_index(self.wyckoff_letter),
            self.multiplicity,
            self.free_dof,
        )

    def realized_features(self) -> tuple[object, ...]:
        padded = (*self.free_parameters, *(0.0 for _ in range(3 - self.free_dof)))
        circular = tuple(
            component
            for value in padded
            for component in (
                math.sin(2.0 * math.pi * float(value)),
                math.cos(2.0 * math.pi * float(value)),
            )
        )
        return (*self.identity_features(), *circular)


@dataclass(frozen=True, slots=True)
class CanonicalActionContext:
    path_index: int
    step_index: int
    removed_instance_ranks: tuple[int, ...]
    active_instance_ranks: tuple[int, ...]

    def __post_init__(self) -> None:
        if self.path_index < 0 or self.step_index < 0:
            raise ValueError("action indices must be non-negative")
        if len(set(self.removed_instance_ranks)) != len(self.removed_instance_ranks):
            raise ValueError("removed orbit ranks must be unique")
        if len(set(self.active_instance_ranks)) != len(self.active_instance_ranks):
            raise ValueError("active orbit ranks must be unique")

    def consumed_features(self) -> tuple[object, ...]:
        return (
            self.path_index,
            self.step_index,
            self.removed_instance_ranks,
            self.active_instance_ranks,
        )


@dataclass(frozen=True, slots=True)
class CanonicalGeometryTarget:
    event_id: str
    parent_id: str
    split: str
    composition: tuple[tuple[int, int], ...]
    target_space_group: int
    lattice: tuple[tuple[float, float, float], ...]
    active_orbits: tuple[CanonicalOrbitToken, ...]
    candidate_orbit: CanonicalOrbitToken
    action_context: CanonicalActionContext
    relation_features: tuple[tuple[float, ...], ...]
    target_equivalents: tuple[tuple[float, float, float], ...]
    free_dof_mask: tuple[bool, bool, bool]

    def __post_init__(self) -> None:
        if not self.event_id or not self.parent_id:
            raise ValueError("event and parent identity are required")
        if self.split not in {"train_fit", "validation"}:
            raise ValueError("unsupported split")
        if not 1 <= self.target_space_group <= 230:
            raise ValueError("target space group must be from 1 through 230")
        if len(self.lattice) != 3 or any(len(row) != 3 for row in self.lattice):
            raise ValueError("lattice must be 3x3")
        if not all(math.isfinite(value) for row in self.lattice for value in row):
            raise ValueError("lattice must be finite")
        if len(self.free_dof_mask) != 3 or any(
            type(value) is not bool for value in self.free_dof_mask
        ):
            raise ValueError("free-DOF mask must be a boolean 3-vector")
        if sum(self.free_dof_mask) != self.candidate_orbit.free_dof:
            raise ValueError("candidate free-DOF and mask disagree")
        if not self.target_equivalents:
            raise ValueError("target equivalence set must be non-empty")
        for target in self.target_equivalents:
            if len(target) != 3 or not all(math.isfinite(value) for value in target):
                raise ValueError("target equivalents must be finite 3-vectors")
            if any(
                value != 0.0
                for value, active in zip(target, self.free_dof_mask, strict=True)
                if not active
            ):
                raise ValueError("masked target dimensions must be zero")
        active_ranks = tuple(orbit.instance_rank for orbit in self.active_orbits)
        if active_ranks != self.action_context.active_instance_ranks:
            raise ValueError("active orbit identity disagrees with action context")
        if self.candidate_orbit.instance_rank not in self.action_context.removed_instance_ranks:
            raise ValueError("candidate is absent from removal action history")
        if len(self.relation_features) not in {0, len(self.active_orbits)}:
            raise ValueError("relation rows must align with active orbits")

    def consumed_condition_payload(
        self, *, relation_mode: Literal["direct", "oracle", "predicted"]
    ) -> tuple[object, ...]:
        if relation_mode not in {"direct", "oracle", "predicted"}:
            raise ValueError("unknown relation mode")
        if relation_mode == "direct":
            relation = tuple(
                tuple(0.0 for _ in row) for row in self.relation_features
            )
            relation_mask = tuple(False for _ in self.relation_features)
        else:
            relation = self.relation_features
            relation_mask = tuple(True for _ in self.relation_features)
        return (
            self.composition,
            self.target_space_group,
            self.lattice,
            tuple(orbit.realized_features() for orbit in self.active_orbits),
            self.candidate_orbit.identity_features(),
            self.action_context.consumed_features(),
            relation,
            relation_mask,
            self.free_dof_mask,
        )


def _orbit_token(orbit: Any, rank_by_id: Mapping[str, int]) -> CanonicalOrbitToken:
    orbit_id = str(orbit.orbit_instance_id)
    if orbit_id not in rank_by_id:
        raise ValueError(f"orbit missing from canonical rank map: {orbit_id}")
    return CanonicalOrbitToken(
        instance_rank=int(rank_by_id[orbit_id]),
        orbit_instance_id=orbit_id,
        species=int(orbit.species),
        wyckoff_letter=str(orbit.wyckoff_letter),
        multiplicity=int(orbit.multiplicity),
        free_parameters=tuple(float(value) % 1.0 for value in orbit.free_parameters),
    )


def _relation_features(target: Any) -> tuple[float, ...]:
    descriptor = target.descriptor
    values = (
        float(descriptor.presence),
        float(descriptor.relation_count),
        float(descriptor.pair_count),
        *(float(value) for value in descriptor.continuous_values),
        float(descriptor.continuous_availability),
    )
    if len(values) != 11 or not all(math.isfinite(value) for value in values):
        raise ValueError("oracle relation descriptor must contain 11 finite values")
    return values


def target_from_integrated_event(
    event: Any,
    *,
    orbit_rank_by_id: Mapping[str, int],
    action_context: CanonicalActionContext,
) -> CanonicalGeometryTarget:
    if event.candidate_orbit is None:
        raise ValueError("terminal events have no continuous geometry target")
    candidate = _orbit_token(event.candidate_orbit, orbit_rank_by_id)
    active = tuple(_orbit_token(orbit, orbit_rank_by_id) for orbit in event.active_orbits)
    equivalents = equivalent_free_parameters(
        int(event.target_space_group),
        candidate.wyckoff_letter,
        candidate.free_parameters,
    )
    padded_equivalents = tuple(
        tuple((*values, *(0.0 for _ in range(3 - len(values)))))
        for values in equivalents
    )
    mask = tuple(index < candidate.free_dof for index in range(3))
    return CanonicalGeometryTarget(
        event_id=str(event.event_key),
        parent_id=str(event.parent_id),
        split=str(event.split),
        composition=tuple(
            (int(species), int(count)) for species, count in event.composition
        ),
        target_space_group=int(event.target_space_group),
        lattice=tuple(
            tuple(float(value) for value in row)
            for row in event.lattice.primitive_matrix
        ),
        active_orbits=active,
        candidate_orbit=candidate,
        action_context=action_context,
        relation_features=tuple(
            _relation_features(target) for target in event.relation_targets
        ),
        target_equivalents=padded_equivalents,  # type: ignore[arg-type]
        free_dof_mask=mask,  # type: ignore[arg-type]
    )


__all__ = [
    "CanonicalActionContext",
    "CanonicalGeometryTarget",
    "CanonicalOrbitToken",
    "target_from_integrated_event",
]
