from __future__ import annotations

import io
import hashlib
import json
import math
import os
import tempfile
import zipfile
from pathlib import Path
from statistics import fmean, stdev
from typing import Any, Mapping, Sequence

from crysalis_g1.external_benchmark.capabilities import capability_matrix_payload
from crysalis_g1.external_benchmark.cell_relax_gpu_adjudication import (
    render_gpu_adjudication,
    validate_gpu_adjudication,
)
from crysalis_g1.external_benchmark.failure_attribution import (
    render_cell_relax_failure_attribution,
    validate_cell_relax_failure_attribution,
)
from crysalis_g1.external_benchmark.provenance import sha256_file
from crysalis_g1.external_benchmark.records import StructurePayload


REQUIRED_OUTPUTS = (
    "BENCHMARK_MANIFEST.json",
    "BASELINE_CONDITION_CAPABILITY.json",
    "CRYSTALFORMER_RESULTS.json",
    "MATTERGEN_RESULTS.json",
    "CRYSTALFLOW_RESULTS.json",
    "DIFFCSP_RESULTS.json",
    "COMMON_CHGNET_BENCHMARK.json",
    "CELL_RELAX_FAILURE_ATTRIBUTION.json",
    "CELL_RELAX_FAILURE_ATTRIBUTION.md",
    "CELL_RELAX_GPU_ADJUDICATION.json",
    "CELL_RELAX_GPU_ADJUDICATION.md",
    "MATTERSIM_REFERENCE_BENCHMARK.json",
    "CSP_MATCH_RATE_RESULTS.json",
    "BENCHMARK_BY_SPACE_GROUP.json",
    "BENCHMARK_RUNTIME.json",
    "BENCHMARK_FAILURES.jsonl",
    "PUBLISHED_REFERENCE_METRICS.json",
    "FULL_CRYSALIS_BENCHMARK_CANDIDATES.zip",
    "EXTERNAL_BENCHMARK_REPORT.md",
)
MANIFEST_NAME = "BENCHMARK_MANIFEST.json"
_PROHIBITED_METADATA = {
    "retry_count": 0,
    "refill_count": 0,
    "sealed_or_blind_data_accessed": False,
    "server_used": False,
    "dft_used": False,
    "tuning_performed": False,
    "ablation_performed": False,
}
_NAMED_CONDITION_LEVELS = {
    "CrystalFormer": "EXACT_FORMULA_PLUS_SG",
    "MatterGen": "SG_ONLY",
    "CrystalFlow": "EXACT_FORMULA_ONLY",
    "DiffCSP": "EXACT_FORMULA_ONLY",
}
_MATTERSIM_WEIGHT_SHA256 = "28b0b0b0f13efefee06b47ea4c9105a26bd3e2c8396da193430da96b3b49a8be"
_MATTERSIM_TRI2024_SHA256 = "ab1b4426901ff7b0f8af6ee9c3cc0dd2fbe4b65c758ef2a95683071492d1c51d"
MATTERSIM_STABILITY_THRESHOLD_EV_PER_ATOM = 0.1
_SPACE_GROUPS = (225, 139, 12, 63, 189, 194, 123, 164)
_CSP_MATCHER = {"ltol": 0.3, "stol": 0.5, "angle_tol": 10.0}
_FINAL_SCIENTIFIC_CONTRACT_SCHEMA = "g1-external-benchmark-final-scientific-contract.1.0.0"
_FINAL_SCIENTIFIC_CONTRACT_KEYS = {
    "schema_version",
    "common_chgnet_results",
    "csp_results",
    "mattersim_results",
    "failure_records",
    "candidate_selection",
}
_UPSTREAM_STAGES = (
    "audit",
    "crystalformer",
    "crystalformer_k5_secondary",
    "other_baselines",
    "common_chgnet",
    "mattersim_secondary",
)
_SEED_METRIC_PATHS = {
    "generated_rate": ("generated", "rate"),
    "parse_valid_rate": ("parse_valid", "rate"),
    "common_legal_rate": ("common_legal", "rate"),
    "short_contact_free_rate": ("short_contact_free", "rate"),
    "reduced_formula_match_rate": ("composition", "reduced_formula_match", "rate"),
    "exact_cell_count_match_rate": ("composition", "exact_cell_count_match", "rate"),
    "strict_0_03_space_group_match_rate": (
        "target_space_group",
        "strict_0_03_match",
        "rate",
    ),
    "initial_force_mean": ("initial_max_force_ev_per_angstrom", "mean"),
    "initial_force_median": ("initial_max_force_ev_per_angstrom", "median"),
    "initial_force_p90": ("initial_max_force_ev_per_angstrom", "p90"),
    "initial_force_p95": ("initial_max_force_ev_per_angstrom", "p95"),
    "initial_force_max": ("initial_max_force_ev_per_angstrom", "max"),
    "fixed_cell_convergence_rate": ("fixed_cell_fire300", "convergence", "rate"),
    "fixed_cell_physical_survival_rate": (
        "fixed_cell_fire300",
        "physical_survival",
        "rate",
    ),
    "fixed_cell_strict_symmetry_survival_rate": (
        "fixed_cell_fire300",
        "strict_symmetry_survival",
        "rate",
    ),
    "cell_relax_convergence_rate": ("cell_relax_fire300", "convergence", "rate"),
    "cell_relax_physical_survival_rate": (
        "cell_relax_fire300",
        "physical_survival",
        "rate",
    ),
    "cell_relax_strict_symmetry_survival_rate": (
        "cell_relax_fire300",
        "strict_symmetry_survival",
        "rate",
    ),
}


def _canonical_json(payload: object, *, indent: int | None = None) -> str:
    return json.dumps(
        payload,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":") if indent is None else None,
        indent=indent,
    )


def _render_payload(name: str, payload: object) -> bytes:
    if name.endswith(".zip"):
        if not isinstance(payload, bytes):
            raise TypeError(f"ZIP payload must be bytes: {name}")
        if not zipfile.is_zipfile(io.BytesIO(payload)):
            raise ValueError(f"ZIP payload is malformed: {name}")
        return payload
    if name.endswith(".md"):
        if not isinstance(payload, str):
            raise TypeError(f"Markdown payload must be text: {name}")
        text = payload if payload.endswith("\n") else payload + "\n"
        return text.encode("utf-8")
    if name.endswith(".jsonl"):
        if isinstance(payload, (str, bytes)) or not isinstance(payload, Sequence):
            raise TypeError(f"JSONL payload must be a sequence: {name}")
        text = "".join(_canonical_json(row) + "\n" for row in payload)
        return text.encode("utf-8")
    return (_canonical_json(payload, indent=2) + "\n").encode("utf-8")


def _atomic_write_new(path: Path, content: bytes) -> None:
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb",
            dir=path.parent,
            prefix=f".{path.name}.",
            delete=False,
        ) as handle:
            temporary = Path(handle.name)
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.link(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _validate_policy_metadata(metadata: Mapping[str, Any]) -> None:
    for field, expected in _PROHIBITED_METADATA.items():
        observed = metadata.get(field)
        exact = (
            type(observed) is bool and observed is expected
            if type(expected) is bool
            else type(observed) is int and observed == expected
        )
        if not exact:
            raise ValueError(f"final manifest {field} must remain {expected!r}")


def _finite_number(value: object, *, label: str, minimum: float | None = None) -> float:
    if type(value) not in {int, float} or not math.isfinite(float(value)):
        raise ValueError(f"{label} must be finite")
    number = float(value)
    if minimum is not None and number < minimum:
        raise ValueError(f"{label} must be at least {minimum}")
    return number


def _validate_rate(value: object, *, label: str, denominator: int | None = None) -> None:
    if not isinstance(value, Mapping) or set(value) != {
        "numerator",
        "denominator",
        "rate",
        "unavailable_reason",
    }:
        raise ValueError(f"{label} rate schema drifted")
    observed_denominator = value.get("denominator")
    if type(observed_denominator) is not int or observed_denominator <= 0:
        raise ValueError(f"{label} rate denominator must be a positive integer")
    if denominator is not None and observed_denominator != denominator:
        raise ValueError(f"{label} rate denominator drifted")
    numerator = value.get("numerator")
    rate = value.get("rate")
    reason = value.get("unavailable_reason")
    if numerator is None or rate is None:
        if numerator is not None or rate is not None or not str(reason or "").strip():
            raise ValueError(f"{label} unavailable rate is malformed")
        return
    if (
        type(numerator) is not int
        or numerator < 0
        or numerator > observed_denominator
        or reason is not None
    ):
        raise ValueError(f"{label} rate numerator is outside its denominator")
    observed_rate = _finite_number(rate, label=f"{label} rate")
    expected_rate = numerator / observed_denominator
    if not math.isclose(observed_rate, expected_rate, rel_tol=1e-12, abs_tol=1e-15):
        raise ValueError(f"{label} rate does not equal numerator/denominator")


def _validate_all_rates(value: object, *, label: str) -> None:
    if isinstance(value, Mapping):
        rate_keys = {"numerator", "denominator", "rate", "unavailable_reason"}
        if rate_keys & set(value):
            _validate_rate(value, label=label)
            return
        for key, item in value.items():
            _validate_all_rates(item, label=f"{label}/{key}")
    elif isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        for index, item in enumerate(value):
            _validate_all_rates(item, label=f"{label}/{index}")


def _validate_numeric_summary(
    value: object,
    *,
    label: str,
    total: int | None = None,
) -> None:
    expected = {"sample_count", "mean", "median", "p90", "p95", "max"}
    if total is not None:
        expected.add("missing_count")
    if not isinstance(value, Mapping) or set(value) != expected:
        raise ValueError(f"{label} numeric summary schema drifted")
    count = value.get("sample_count")
    if type(count) is not int or count < 0:
        raise ValueError(f"{label} sample count drifted")
    if total is not None:
        missing = value.get("missing_count")
        if type(missing) is not int or missing < 0 or count + missing != total:
            raise ValueError(f"{label} resource denominator drifted")
    statistics = tuple(value.get(name) for name in ("mean", "median", "p90", "p95", "max"))
    if count == 0:
        if any(item is not None for item in statistics):
            raise ValueError(f"{label} empty numeric summary contains values")
    elif any(item is None for item in statistics):
        raise ValueError(f"{label} numeric summary is incomplete")
    else:
        for name, item in zip(("mean", "median", "p90", "p95", "max"), statistics, strict=True):
            _finite_number(item, label=f"{label} {name}")


def _nested_number(summary: Mapping[str, Any], path: Sequence[str], *, label: str) -> float:
    value: Any = summary
    for key in path:
        if not isinstance(value, Mapping) or key not in value:
            raise ValueError(f"{label} is missing")
        value = value[key]
    return _finite_number(value, label=label)


def validate_mattersim_result_rows(
    results: object,
    expected_attempt_ids: Sequence[str],
) -> None:
    """Validate one finite MatterSim/MatterGen-compatible result per eligible ID."""

    if not isinstance(results, list) or len(results) != len(expected_attempt_ids):
        raise ValueError("MatterSim COMPLETE requires a typed finite scientific result per ID")
    required = {
        "attempt_id",
        "status",
        "energy",
        "energy_per_atom",
        "rmsd_from_relaxation",
        "energy_above_hull_ev_per_atom",
        "stable",
        "unique",
        "novel",
        "novel_unique_stable",
        "failure_code",
        "failure_message",
    }
    for expected_id, row in zip(expected_attempt_ids, results, strict=True):
        if not isinstance(row, Mapping) or set(row) != required:
            raise ValueError("MatterSim COMPLETE requires a typed finite scientific result per ID")
        if row.get("attempt_id") != expected_id or row.get("status") not in {
            "EVALUATED",
            "FAILED_PRESERVED",
        }:
            raise ValueError("MatterSim scientific result identity/status drifted")
        scientific_fields = (
            "energy",
            "energy_per_atom",
            "rmsd_from_relaxation",
            "energy_above_hull_ev_per_atom",
            "stable",
            "unique",
            "novel",
            "novel_unique_stable",
        )
        if row["status"] == "FAILED_PRESERVED":
            if (
                any(row.get(name) is not None for name in scientific_fields)
                or type(row.get("failure_code")) is not str
                or not row["failure_code"].strip()
                or type(row.get("failure_message")) is not str
                or not row["failure_message"].strip()
            ):
                raise ValueError("MatterSim retained per-ID failure is incomplete")
            continue
        if row.get("failure_code") is not None or row.get("failure_message") is not None:
            raise ValueError("MatterSim evaluated result cannot carry a failure")
        _finite_number(row.get("energy"), label="MatterSim energy")
        _finite_number(row.get("energy_per_atom"), label="MatterSim energy_per_atom")
        _finite_number(
            row.get("rmsd_from_relaxation"),
            label="MatterSim rmsd_from_relaxation",
            minimum=0.0,
        )
        energy_above_hull = _finite_number(
            row.get("energy_above_hull_ev_per_atom"),
            label="MatterSim energy_above_hull_ev_per_atom",
        )
        for name in ("stable", "unique", "novel", "novel_unique_stable"):
            if type(row.get(name)) is not bool:
                raise ValueError(f"MatterSim {name} must be boolean")
        if row["stable"] is not (energy_above_hull <= MATTERSIM_STABILITY_THRESHOLD_EV_PER_ATOM):
            raise ValueError(
                "MatterSim stable flag differs from the registered 0.1 eV/atom threshold"
            )
        expected_sun = bool(row["stable"] and row["unique"] and row["novel"])
        if row["novel_unique_stable"] is not expected_sun:
            raise ValueError("MatterSim SUN must equal stable AND unique AND novel")


def collect_upstream_bindings(output_root: str | Path) -> dict[str, Any]:
    """Hash the exact pre-final receipts and every artifact bound by those receipts."""

    output = Path(output_root).resolve()
    receipt_hashes: dict[str, str] = {}
    artifact_hashes: dict[str, dict[str, str]] = {}
    for stage in _UPSTREAM_STAGES:
        receipt_path = output / "engineering" / "receipts" / f"{stage}.json"
        if not receipt_path.is_file():
            raise ValueError(f"upstream stage receipt is missing: {stage}")
        try:
            receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            raise ValueError(f"upstream stage receipt is malformed: {stage}") from None
        outputs = receipt.get("output_sha256") if isinstance(receipt, Mapping) else None
        if not isinstance(outputs, Mapping) or not outputs:
            raise ValueError(f"upstream typed artifact hashes are missing: {stage}")
        verified: dict[str, str] = {}
        for relative, digest in outputs.items():
            path = (output / str(relative)).resolve()
            if not path.is_relative_to(output) or not path.is_file() or sha256_file(path) != digest:
                raise ValueError(f"upstream typed artifact hash drifted: {stage}/{relative}")
            verified[str(relative)] = str(digest)
        receipt_hashes[stage] = sha256_file(receipt_path)
        artifact_hashes[stage] = dict(sorted(verified.items()))
    return {
        "upstream_stage_receipt_sha256": receipt_hashes,
        "upstream_typed_artifact_sha256": artifact_hashes,
    }


def _validate_upstream_bindings(output: Path, metadata: Mapping[str, Any]) -> None:
    observed = {
        "upstream_stage_receipt_sha256": metadata.get("upstream_stage_receipt_sha256"),
        "upstream_typed_artifact_sha256": metadata.get("upstream_typed_artifact_sha256"),
    }
    if observed != collect_upstream_bindings(output):
        raise ValueError("final manifest upstream receipt/artifact bindings drifted")


def _rate_text(row: Mapping[str, Any], *path: str) -> str:
    value: Any = row
    for key in path:
        if not isinstance(value, Mapping):
            return "NA"
        value = value.get(key)
    if not isinstance(value, Mapping):
        return "NA"
    numerator = value.get("numerator")
    denominator = value.get("denominator")
    rate = value.get("rate")
    if numerator is None or rate is None:
        reason = value.get("unavailable_reason") or "UNAVAILABLE"
        return f"NA ({reason})"
    return f"{numerator}/{denominator} ({float(rate):.3f})"


def _escape(value: Any) -> str:
    return str(value).replace("|", "\\|").replace("\n", " ")


def _summary_table(rows: Sequence[Mapping[str, Any]], *, strict: bool) -> str:
    heading = (
        "| Model | Attempts | Condition level | Training data | Generated | "
        "Common legal | Fixed-cell strict SG survival |"
        if strict
        else "| Model | Attempts | Condition level | Training data | Generated | "
        "Common legal | Fixed-cell physical survival |"
    )
    separator = "|---|---:|---|---|---:|---:|---:|"
    rendered = [heading, separator]
    endpoint = "strict_symmetry_survival" if strict else "physical_survival"
    for row in rows:
        rendered.append(
            "| "
            + " | ".join(
                (
                    _escape(row["model"]),
                    _escape(row["attempt_count"]),
                    _escape(row["condition_level"]),
                    _escape(row["training_data"]),
                    _rate_text(row, "generated"),
                    _rate_text(row, "common_legal"),
                    _rate_text(row, "fixed_cell_fire300", endpoint),
                )
            )
            + " |"
        )
    return "\n".join(rendered)


def _validate_summary_rows(
    rows: Sequence[Mapping[str, Any]],
    *,
    table: str,
    enforce_named_conditions: bool = True,
) -> tuple[Mapping[str, Any], ...]:
    frozen = tuple(rows)
    if not frozen:
        raise ValueError(f"{table} must contain rows")
    models: set[str] = set()
    for row in frozen:
        model = str(row.get("model", ""))
        condition_level = str(row.get("condition_level", ""))
        training_data = str(row.get("training_data", ""))
        if not model or not condition_level or not training_data:
            raise ValueError(
                f"{table} rows must disclose model, condition level, and training data"
            )
        if model in models:
            raise ValueError(f"{table} contains duplicate model: {model}")
        models.add(model)
        expected = _NAMED_CONDITION_LEVELS.get(model) if enforce_named_conditions else None
        if expected is not None and condition_level != expected:
            raise ValueError(f"{model} must be disclosed as {expected}")
    return frozen


def _validate_capabilities(rows: Sequence[Mapping[str, Any]]) -> None:
    by_model = {str(row.get("model")): row for row in rows}
    for model, expected in _NAMED_CONDITION_LEVELS.items():
        row = by_model.get(model)
        if row is None or row.get("condition_level") != expected:
            raise ValueError(f"{model} capability must disclose {expected}")
    dyna = by_model.get("DynaCrys")
    if dyna is None or dyna.get("execution_status") != (
        "NOT_RUN_NO_OFFICIAL_REPRODUCIBLE_ARTIFACT"
    ):
        raise ValueError("DynaCrys must remain NOT_RUN_NO_OFFICIAL_REPRODUCIBLE_ARTIFACT")


def render_external_benchmark_report(
    *,
    table_a_rows: Sequence[Mapping[str, Any]],
    table_b_rows: Sequence[Mapping[str, Any]],
    table_c_rows: Sequence[Mapping[str, Any]],
    capability_rows: Sequence[Mapping[str, Any]],
    full_crysalis_summary: Mapping[str, Any],
    cell_relax_failure_attribution: Mapping[str, Any] | None = None,
    cell_relax_gpu_adjudication: Mapping[str, Any] | None = None,
    mattersim_results: Mapping[str, Any] | None = None,
) -> str:
    """Render the three protocol-separated benchmark tables."""

    table_a = _validate_summary_rows(
        table_a_rows,
        table="Table A",
        enforce_named_conditions=False,
    )
    table_b = _validate_summary_rows(table_b_rows, table="Table B")
    models_a = {str(row["model"]) for row in table_a}
    if not {"FULL_CRYSALIS", "CrystalFormer"}.issubset(models_a):
        raise ValueError("Table A requires FULL_CRYSALIS and CrystalFormer")
    if any(row["condition_level"] != "EXACT_FORMULA_PLUS_SG" for row in table_a):
        raise ValueError("Table A accepts EXACT_FORMULA_PLUS_SG rows only")
    foreign_external = models_a - {"FULL_CRYSALIS", "CrystalFormer"}
    if foreign_external:
        raise ValueError(
            f"CrystalFormer is the only external Table A baseline: {sorted(foreign_external)}"
        )
    if any(row.get("common_evaluation_available") is not True for row in table_b):
        raise ValueError("Table B requires common CHGNet evaluation")
    rows_a = {str(row["model"]): row for row in table_a}
    rows_b = {str(row["model"]): row for row in table_b}
    if not {"FULL_CRYSALIS", "CrystalFormer"}.issubset(rows_b):
        raise ValueError("Table B requires FULL_CRYSALIS and CrystalFormer")
    for table_name, rows_by_model in (("Table A", rows_a), ("Table B", rows_b)):
        if rows_by_model["FULL_CRYSALIS"].get("attempt_count") != 900:
            raise ValueError(f"{table_name} FULL_CRYSALIS requires pooled 900 attempts")
        if rows_by_model["FULL_CRYSALIS"].get("condition_level") != ("EXACT_FORMULA_PLUS_SG"):
            raise ValueError(f"{table_name} FULL_CRYSALIS condition label drifted")
        if rows_by_model["CrystalFormer"].get("attempt_count") != 300:
            raise ValueError(f"{table_name} CrystalFormer K=1 requires 300 attempts")

    contextual = tuple(table_c_rows)
    if not contextual:
        raise ValueError("Table C must contain contextual reference rows")
    for row in contextual:
        if row.get("contextual_only") is not True:
            raise ValueError("Table C rows must be contextual only")
        if not str(row.get("protocol_mismatch_label", "")).strip():
            raise ValueError("Table C rows require a protocol mismatch label")
        if row.get("cross_protocol_rank") is not None:
            raise ValueError("Table C forbids a cross-protocol rank")
    _validate_capabilities(capability_rows)
    attribution_lines: tuple[str, ...] = ()
    if cell_relax_failure_attribution is not None:
        validate_cell_relax_failure_attribution(cell_relax_failure_attribution)
        counts = cell_relax_failure_attribution["summary"]["by_failure_class"]
        attribution_lines = (
            "## Cell-relax failure attribution",
            "",
            "The 31 preserved cell-relax failures were audited read-only: no sample "
            "was rerun, retried, refilled, or rewritten.",
            "",
            f"PHYSICAL_COLLAPSE_CONFIRMED={counts['PHYSICAL_COLLAPSE_CONFIRMED']}; "
            f"RESOURCE_LIMITED_EVALUATION={counts['RESOURCE_LIMITED_EVALUATION']}; "
            f"OOM_CAUSE_UNRESOLVED={counts['OOM_CAUSE_UNRESOLVED']}.",
            "A confirmed cell collapse followed by neighbor-graph explosion is counted "
            "as physical/geometric collapse, with CUDA OOM only as the terminal "
            "technical symptom. Resource-limited and unresolved cases are not "
            "automatically labeled model physical failures.",
            "",
        )
    mattersim_lines: tuple[str, ...] = ()
    gpu_adjudication_lines: tuple[str, ...] = ()
    if cell_relax_gpu_adjudication is not None:
        validate_gpu_adjudication(cell_relax_gpu_adjudication)
        gpu_summary = cell_relax_gpu_adjudication["summary"]
        gpu_counts = gpu_summary["by_final_failure_class"]
        gpu_adjudication_lines = (
            "## Same-device GPU adjudication of GPU-OOM cases",
            "",
            f"The same frozen structures and FIRE300 protocol were run on the same GPU "
            f"for failure attribution only: total={gpu_summary['total_unresolved_before']}; "
            f"GPU fully completed={gpu_summary['gpu_fully_completed']}; "
            f"PHYSICAL_COLLAPSE_CONFIRMED={gpu_counts['PHYSICAL_COLLAPSE_CONFIRMED']}; "
            f"RESOURCE_LIMITED_EVALUATION={gpu_counts['RESOURCE_LIMITED_EVALUATION']}; "
            f"OOM_CAUSE_UNRESOLVED={gpu_counts['OOM_CAUSE_UNRESOLVED']}.",
            "The execution device and all scientific evaluator settings remained frozen; "
            "only observation-only trajectory diagnostics were added.",
            "",
        )
    if mattersim_results is not None:
        status = str(mattersim_results.get("stage_status", ""))
        mattersim_lines = (
            "## MatterSim secondary evaluation",
            "",
            f"Stage status: {status}. Primary matched evaluation remains CHGNet/FIRE300.",
            "",
        )
        runtime = mattersim_results.get("runtime_provenance")
        if status == "COMPLETE" and isinstance(runtime, Mapping):
            mattersim_lines = (
                "## MatterSim secondary evaluation",
                "",
                "Stage status: COMPLETE. MATTERSIM_MODEL_SOURCE=OFFICIAL; "
                "MATTERSIM_MODEL_WEIGHTS=OFFICIAL; "
                "MATTERSIM_RUNTIME_STATUS=COMPATIBILITY_PATCHED_RUNNER.",
                "Environment/runner compatibility issues were resolved without "
                "altering the MatterSim model, weights, neighbor algorithm, relaxation "
                "algorithm, inputs, thresholds, or scientific evaluation protocol. "
                "Primary matched evaluation remains CHGNet/FIRE300.",
                "",
            )

    if full_crysalis_summary.get("attempt_count") != 900:
        raise ValueError("FULL_CRYSALIS report requires pooled 900 attempts")
    seeds = tuple(full_crysalis_summary.get("training_seeds", ()))
    if seeds != (20260823, 20260824, 20260825):
        raise ValueError("FULL_CRYSALIS report seed identities drifted")
    definition = str(full_crysalis_summary.get("seed_statistics_definition", ""))
    if "sample standard deviation" not in definition:
        raise ValueError("FULL_CRYSALIS report requires seed mean and sample SD")
    if full_crysalis_summary.get("best_seed_selection_performed") is not False:
        raise ValueError("FULL_CRYSALIS best-seed selection is forbidden")
    pooled_900 = full_crysalis_summary.get("pooled_900")
    if (
        not isinstance(pooled_900, Mapping)
        or pooled_900 != rows_a["FULL_CRYSALIS"]
        or pooled_900 != rows_b["FULL_CRYSALIS"]
    ):
        raise ValueError("FULL_CRYSALIS pooled 900 summary is not cross-bound to Tables A/B")
    per_seed = full_crysalis_summary.get("per_seed")
    seed_statistics = full_crysalis_summary.get("seed_statistics")
    expected_seed_keys = {str(seed) for seed in seeds}
    if (
        not isinstance(per_seed, Mapping)
        or set(per_seed) != expected_seed_keys
        or any(
            not isinstance(per_seed[key], Mapping) or per_seed[key].get("attempt_count") != 300
            for key in expected_seed_keys
        )
        or not isinstance(seed_statistics, Mapping)
        or set(seed_statistics) != set(_SEED_METRIC_PATHS)
    ):
        raise ValueError("FULL_CRYSALIS requires per-seed summaries and seed statistics")
    seed_summaries: list[Mapping[str, Any]] = []
    for seed in seeds:
        summary = _validate_model_summary(
            per_seed[str(seed)],
            model="FULL_CRYSALIS",
            condition_level="EXACT_FORMULA_PLUS_SG",
            attempt_count=300,
            label=f"FULL_CRYSALIS seed {seed}",
        )
        if summary.get("training_seed") != seed:
            raise ValueError("FULL_CRYSALIS per-seed training identity drifted")
        seed_summaries.append(summary)
    rendered_seed_statistics: list[str] = []
    for metric, path in sorted(_SEED_METRIC_PATHS.items()):
        values = seed_statistics[metric]
        if not isinstance(values, Mapping):
            raise ValueError("FULL_CRYSALIS seed statistics are malformed")
        mean = values.get("mean")
        sample_std = values.get("sample_std")
        if (
            type(mean) not in {int, float}
            or type(sample_std) not in {int, float}
            or not math.isfinite(float(mean))
            or not math.isfinite(float(sample_std))
            or float(sample_std) < 0.0
            or values.get("seed_count") != 3
        ):
            raise ValueError("FULL_CRYSALIS seed statistics are malformed")
        observed = [
            _nested_number(summary, path, label=f"FULL_CRYSALIS {metric}")
            for summary in seed_summaries
        ]
        if not math.isclose(float(mean), fmean(observed), rel_tol=1e-12, abs_tol=1e-15) or (
            not math.isclose(
                float(sample_std),
                stdev(observed),
                rel_tol=1e-12,
                abs_tol=1e-15,
            )
        ):
            raise ValueError(f"FULL_CRYSALIS seed statistic was not recomputed: {metric}")
        rendered_seed_statistics.append(
            f"{metric}: mean={float(mean):.3f}, sample SD={float(sample_std):.3f}"
        )
        if path[-1] == "rate":
            pooled_metric: Any = pooled_900
            seed_metrics: list[Mapping[str, Any]] = []
            for key in path[:-1]:
                pooled_metric = pooled_metric[key]
            for summary in seed_summaries:
                seed_metric: Any = summary
                for key in path[:-1]:
                    seed_metric = seed_metric[key]
                seed_metrics.append(seed_metric)
            if (
                not isinstance(pooled_metric, Mapping)
                or pooled_metric.get("numerator")
                != sum(metric_row["numerator"] for metric_row in seed_metrics)
                or pooled_metric.get("denominator")
                != sum(metric_row["denominator"] for metric_row in seed_metrics)
            ):
                raise ValueError(f"FULL_CRYSALIS pooled/per-seed count drifted: {metric}")

    published_rows = [
        "| Model | Metric | Value | Source protocol | Protocol mismatch | Cross-protocol rank |",
        "|---|---|---:|---|---|---|",
    ]
    for row in contextual:
        published_rows.append(
            "| "
            + " | ".join(
                (
                    _escape(row.get("model")),
                    _escape(row.get("metric")),
                    _escape(row.get("value")),
                    _escape(row.get("source_protocol")),
                    _escape(row.get("protocol_mismatch_label")),
                    "No cross-protocol rank",
                )
            )
            + " |"
        )

    return "\n".join(
        (
            "# Full Crysalis External Benchmark V1",
            "",
            "Full Crysalis is reported as the actual pooled 900-attempt cohort for "
            "training seeds 20260823, 20260824, 20260825. Across-seed summaries use "
            f"{definition}; best-seed selection: no.",
            "Across-seed numeric summaries: " + "; ".join(rendered_seed_statistics) + ".",
            "",
            "## Table A — strict exact-formula-plus-SG comparison",
            "",
            "Only the frozen subject and the condition-matched CrystalFormer K=1 "
            "baseline enter this table.",
            "",
            _summary_table(table_a, strict=True),
            "",
            "## Table B — common CHGNet/FIRE300 re-evaluation",
            "",
            "Rows retain their audited condition level and training data; all rates "
            "use registered all-attempt denominators.",
            "",
            _summary_table(table_b, strict=False),
            "",
            "## Table C — published contextual references",
            "",
            "Published values, including MatterGen SUN, are contextual only. They are "
            "not numerically ranked against the common CHGNet benchmark.",
            "",
            "\n".join(published_rows),
            "",
            *attribution_lines,
            *gpu_adjudication_lines,
            *mattersim_lines,
        )
    )


def _required_mapping(payloads: Mapping[str, object], name: str, label: str) -> Mapping[str, Any]:
    payload = payloads.get(name)
    if not isinstance(payload, Mapping):
        raise ValueError(f"{label} must be a JSON object")
    return payload


def _validate_runtime_summary(value: object, *, attempt_count: int, label: str) -> None:
    if not isinstance(value, Mapping) or set(value) != {
        "generation_latency_seconds",
        "wall_time_seconds",
        "wall_time_unavailable_reason",
        "peak_ram_bytes",
        "peak_vram_bytes",
    }:
        raise ValueError(f"{label} runtime summary is incomplete")
    for name in ("generation_latency_seconds", "peak_ram_bytes", "peak_vram_bytes"):
        _validate_numeric_summary(
            value.get(name),
            label=f"{label} runtime/{name}",
            total=attempt_count,
        )
    wall_time = value.get("wall_time_seconds")
    reason = value.get("wall_time_unavailable_reason")
    if wall_time is None:
        if not str(reason or "").strip():
            raise ValueError(f"{label} runtime wall-time reason is missing")
    elif reason is not None:
        raise ValueError(f"{label} runtime wall-time reason drifted")
    else:
        _finite_number(wall_time, label=f"{label} runtime wall time", minimum=0.0)


def _validate_protocol_summary(value: object, *, attempt_count: int, label: str) -> None:
    if (
        not isinstance(value, Mapping)
        or value.get("attempt_count") != attempt_count
        or (value.get("all_attempt_denominator") is not True)
    ):
        raise ValueError(f"{label} protocol denominator drifted")
    for name in ("evaluated", "convergence", "physical_survival", "strict_symmetry_survival"):
        _validate_rate(value.get(name), label=f"{label}/{name}", denominator=attempt_count)
    taxonomy = value.get("failure_taxonomy")
    if (
        not isinstance(taxonomy, Mapping)
        or not taxonomy
        or any(type(count) is not int or count < 0 for count in taxonomy.values())
        or sum(taxonomy.values()) != attempt_count
    ):
        raise ValueError(f"{label} failure taxonomy is incomplete")


def _validate_per_space_group(
    value: object,
    *,
    attempt_count: int,
    condition_level: str,
    training_data: str,
    label: str,
) -> None:
    if not isinstance(value, Mapping):
        raise ValueError(f"{label} per-space-group summary is missing")
    expected_interpretation = (
        "TARGET_SG_CONDITIONED_PERFORMANCE"
        if condition_level in {"EXACT_FORMULA_PLUS_SG", "SG_ONLY"}
        else "MANIFEST_STRATIFIED_POST_HOC_NOT_SG_CONDITIONED"
    )
    rows = value.get("rows")
    if (
        value.get("grouping_interpretation") != expected_interpretation
        or value.get("manifest_target_space_group_used_for_stratification") is not True
        or not isinstance(rows, Mapping)
        or set(rows) != {str(space_group) for space_group in _SPACE_GROUPS}
    ):
        raise ValueError(f"{label} must cover the exact eight registered space groups")
    denominators = 0
    for space_group in _SPACE_GROUPS:
        row = rows[str(space_group)]
        if (
            not isinstance(row, Mapping)
            or row.get("space_group") != space_group
            or row.get("condition_level") != condition_level
            or row.get("training_data") != training_data
            or row.get("conditioned_performance")
            is not (condition_level in {"EXACT_FORMULA_PLUS_SG", "SG_ONLY"})
        ):
            raise ValueError(f"{label} space-group row identity drifted")
        attempts = row.get("attempts")
        _validate_rate(attempts, label=f"{label}/SG{space_group}/attempts")
        denominator = attempts["denominator"]
        if attempts["numerator"] != denominator:
            raise ValueError(f"{label} SG attempt rate must retain every registered attempt")
        denominators += denominator
        for name in (
            "common_legal",
            "short_contact_free",
            "fixed_cell_strict_symmetry_survival",
            "cell_relax_strict_symmetry_survival",
        ):
            _validate_rate(
                row.get(name),
                label=f"{label}/SG{space_group}/{name}",
                denominator=denominator,
            )
        _validate_numeric_summary(
            row.get("initial_max_force_ev_per_angstrom"),
            label=f"{label}/SG{space_group}/initial force",
        )
    if denominators != attempt_count:
        raise ValueError(f"{label} space-group denominators do not cover all attempts")


def _validate_model_summary(
    summary: object,
    *,
    model: str,
    condition_level: str,
    attempt_count: int,
    label: str,
) -> Mapping[str, Any]:
    if not isinstance(summary, Mapping) or (
        summary.get("schema_version") != "g1-external-benchmark-model-summary.1.0.0"
        or summary.get("model") != model
        or summary.get("condition_level") != condition_level
        or summary.get("attempt_count") != attempt_count
        or summary.get("common_evaluation_available") is not True
        or summary.get("all_attempt_denominators") is not True
        or summary.get("published_metrics_in_common_ranking") is not False
    ):
        raise ValueError(f"{label} summary identity drifted")
    training_data = str(summary.get("training_data", ""))
    if not training_data:
        raise ValueError(f"{label} training-data label is missing")
    for name in ("attempts", "generated", "parse_valid", "common_legal", "short_contact_free"):
        _validate_rate(summary.get(name), label=f"{label}/{name}", denominator=attempt_count)
    attempts_rate = summary["attempts"]
    if attempts_rate.get("numerator") != attempt_count:
        raise ValueError(f"{label} attempts rate does not retain the full denominator")
    composition = summary.get("composition")
    target_space_group = summary.get("target_space_group")
    if not isinstance(composition, Mapping) or not isinstance(target_space_group, Mapping):
        raise ValueError(f"{label} composition/space-group metrics are missing")
    for name in ("reduced_formula_match", "exact_cell_count_match"):
        _validate_rate(
            composition.get(name),
            label=f"{label}/composition/{name}",
            denominator=attempt_count,
        )
    _validate_rate(
        target_space_group.get("strict_0_03_match"),
        label=f"{label}/strict_0_03_match",
        denominator=attempt_count,
    )
    if target_space_group.get("strict_symprec_angstrom") != 0.03:
        raise ValueError(f"{label} strict symmetry threshold drifted")
    _validate_numeric_summary(
        summary.get("initial_max_force_ev_per_angstrom"),
        label=f"{label}/initial force",
    )
    for protocol in ("fixed_cell_fire300", "cell_relax_fire300"):
        _validate_protocol_summary(
            summary.get(protocol),
            attempt_count=attempt_count,
            label=f"{label}/{protocol}",
        )
    _validate_per_space_group(
        summary.get("per_space_group"),
        attempt_count=attempt_count,
        condition_level=condition_level,
        training_data=training_data,
        label=label,
    )
    sg_rows = summary["per_space_group"]["rows"]
    for top_level, sg_metric in (
        (summary["common_legal"], "common_legal"),
        (summary["short_contact_free"], "short_contact_free"),
    ):
        if (
            sum(sg_rows[str(sg)][sg_metric]["numerator"] for sg in _SPACE_GROUPS)
            != (top_level["numerator"])
        ):
            raise ValueError(f"{label} per-space-group {sg_metric} counts drifted")
    if condition_level in {"EXACT_FORMULA_PLUS_SG", "SG_ONLY"}:
        for protocol, sg_metric in (
            ("fixed_cell_fire300", "fixed_cell_strict_symmetry_survival"),
            ("cell_relax_fire300", "cell_relax_strict_symmetry_survival"),
        ):
            observed = sum(sg_rows[str(sg)][sg_metric]["numerator"] for sg in _SPACE_GROUPS)
            if observed != summary[protocol]["strict_symmetry_survival"]["numerator"]:
                raise ValueError(f"{label} per-space-group {protocol} counts drifted")
    _validate_runtime_summary(summary.get("runtime"), attempt_count=attempt_count, label=label)
    _validate_all_rates(summary, label=label)
    return summary


def _candidate_member_bytes(payload: object) -> bytes:
    return (_canonical_json(payload) + "\n").encode("utf-8")


def build_candidate_zip_payload(selection: Mapping[str, Any]) -> bytes:
    """Build a deterministic provenance-bound candidate archive from Task 5 selection."""

    selection_keys = {
        "schema_version",
        "model",
        "candidate_count",
        "chgnet_criterion",
        "requires_strict_0_03_space_group_match",
        "requires_unique_representative",
        "final_zip_written",
        "candidates",
    }
    raw_candidates = selection.get("candidates") if isinstance(selection, Mapping) else None
    if (
        not isinstance(selection, Mapping)
        or set(selection) != selection_keys
        or selection.get("schema_version") != "g1-external-benchmark-candidate-selection.1.0.0"
        or selection.get("model") != "FULL_CRYSALIS"
        or type(selection.get("candidate_count")) is not int
        or selection["candidate_count"] < 0
        or selection.get("chgnet_criterion") != "FIXED_CELL_FIRE300_PHYSICAL_SURVIVAL"
        or selection.get("requires_strict_0_03_space_group_match") is not True
        or selection.get("requires_unique_representative") is not True
        or selection.get("final_zip_written") is not False
        or not isinstance(raw_candidates, list)
        or len(raw_candidates) != selection["candidate_count"]
    ):
        raise ValueError("candidate selection payload is malformed")

    eligibility_keys = {
        "strict_0_03_space_group_match",
        "unique_representative",
        "fixed_cell_fire300_physical_survival",
    }
    candidate_keys = {
        "evaluation_id",
        "structure",
        "condition",
        "sample_index",
        "registered_seed",
        "training_seed",
        "provenance",
        "eligibility",
    }
    members: dict[str, bytes] = {}
    declarations: list[dict[str, Any]] = []
    identities: set[str] = set()
    for candidate in raw_candidates:
        if not isinstance(candidate, Mapping) or set(candidate) != candidate_keys:
            raise ValueError("candidate selection row is malformed")
        identity = candidate.get("evaluation_id")
        eligibility = candidate.get("eligibility")
        if (
            not isinstance(identity, str)
            or not identity.strip()
            or identity in identities
            or not isinstance(eligibility, Mapping)
            or set(eligibility) != eligibility_keys
            or any(value is not True for value in eligibility.values())
            or not isinstance(candidate.get("structure"), Mapping)
            or not isinstance(candidate.get("condition"), Mapping)
            or type(candidate.get("sample_index")) is not int
            or type(candidate.get("registered_seed")) is not int
            or (
                candidate.get("training_seed") is not None
                and type(candidate.get("training_seed")) is not int
            )
            or not isinstance(candidate.get("provenance"), Mapping)
        ):
            raise ValueError("candidate selection row is malformed")
        try:
            StructurePayload.from_dict(candidate["structure"])
        except (TypeError, ValueError):
            raise ValueError("candidate selection structure is malformed") from None
        identities.add(identity)
        member_key = hashlib.sha256(identity.encode("utf-8")).hexdigest()
        structure_member = f"structures/{member_key}.json"
        provenance_member = f"provenance/{member_key}.json"
        structure_bytes = _candidate_member_bytes(candidate["structure"])
        provenance_payload = {
            "evaluation_id": identity,
            "condition": candidate["condition"],
            "sample_index": candidate["sample_index"],
            "registered_seed": candidate["registered_seed"],
            "training_seed": candidate["training_seed"],
            "provenance": candidate["provenance"],
        }
        provenance_bytes = _candidate_member_bytes(provenance_payload)
        members[structure_member] = structure_bytes
        members[provenance_member] = provenance_bytes
        declarations.append(
            {
                "evaluation_id": identity,
                "structure_member": structure_member,
                "structure_sha256": hashlib.sha256(structure_bytes).hexdigest(),
                "provenance_member": provenance_member,
                "provenance_sha256": hashlib.sha256(provenance_bytes).hexdigest(),
                "eligibility": dict(eligibility),
            }
        )
    manifest = {
        **{name: selection[name] for name in selection_keys if name != "candidates"},
        "final_zip_written": True,
        "candidates": declarations,
    }
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, mode="w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("manifest.json", _candidate_member_bytes(manifest))
        for name, content in sorted(members.items()):
            archive.writestr(name, content)
    return buffer.getvalue()


def _validate_candidate_zip(
    payload: object,
    *,
    expected_selection: Mapping[str, Any] | None = None,
) -> None:
    if not isinstance(payload, bytes):
        raise ValueError("candidate ZIP payload must be bytes")
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError("candidate ZIP contains duplicate members")
        if "manifest.json" not in names:
            raise ValueError("candidate ZIP manifest is missing")
        manifest = json.loads(archive.read("manifest.json"))
        candidates = manifest.get("candidates") if isinstance(manifest, Mapping) else None
        manifest_keys = {
            "schema_version",
            "model",
            "candidate_count",
            "chgnet_criterion",
            "requires_strict_0_03_space_group_match",
            "requires_unique_representative",
            "final_zip_written",
            "candidates",
        }
        if (
            not isinstance(manifest, Mapping)
            or set(manifest) != manifest_keys
            or manifest.get("schema_version") != "g1-external-benchmark-candidate-selection.1.0.0"
            or manifest.get("model") != "FULL_CRYSALIS"
            or type(manifest.get("candidate_count")) is not int
            or manifest["candidate_count"] < 0
            or manifest.get("chgnet_criterion") != "FIXED_CELL_FIRE300_PHYSICAL_SURVIVAL"
            or manifest.get("requires_strict_0_03_space_group_match") is not True
            or manifest.get("requires_unique_representative") is not True
            or manifest.get("final_zip_written") is not True
            or not isinstance(candidates, list)
            or len(candidates) != manifest["candidate_count"]
        ):
            raise ValueError("candidate ZIP eligibility manifest drifted")

        eligibility_keys = {
            "strict_0_03_space_group_match",
            "unique_representative",
            "fixed_cell_fire300_physical_survival",
        }
        candidate_keys = {
            "evaluation_id",
            "structure_member",
            "structure_sha256",
            "provenance_member",
            "provenance_sha256",
            "eligibility",
        }
        provenance_keys = {
            "evaluation_id",
            "condition",
            "sample_index",
            "registered_seed",
            "training_seed",
            "provenance",
        }
        declared_members = {"manifest.json"}
        identities: set[str] = set()
        recovered_candidates: list[dict[str, Any]] = []
        for candidate in candidates:
            if not isinstance(candidate, Mapping) or set(candidate) != candidate_keys:
                raise ValueError("candidate ZIP candidate declaration drifted")
            identity = candidate.get("evaluation_id")
            eligibility = candidate.get("eligibility")
            if (
                not isinstance(identity, str)
                or not identity.strip()
                or identity in identities
                or not isinstance(eligibility, Mapping)
                or set(eligibility) != eligibility_keys
                or any(value is not True for value in eligibility.values())
            ):
                raise ValueError("candidate ZIP eligibility manifest drifted")
            identities.add(identity)
            loaded_members: dict[str, object] = {}
            for kind in ("structure", "provenance"):
                member = candidate.get(f"{kind}_member")
                digest = candidate.get(f"{kind}_sha256")
                if (
                    not isinstance(member, str)
                    or not member.strip()
                    or member.startswith(("/", "\\"))
                    or "\\" in member
                    or ".." in Path(member).parts
                    or member in declared_members
                    or not isinstance(digest, str)
                    or len(digest) != 64
                    or any(character not in "0123456789abcdef" for character in digest)
                    or member not in names
                ):
                    raise ValueError("candidate ZIP member declaration drifted")
                content = archive.read(member)
                if hashlib.sha256(content).hexdigest() != digest:
                    raise ValueError("candidate ZIP member hash drifted")
                try:
                    loaded_members[kind] = json.loads(content)
                except (UnicodeDecodeError, json.JSONDecodeError):
                    raise ValueError("candidate ZIP member JSON is malformed") from None
                declared_members.add(member)
            structure = loaded_members["structure"]
            provenance = loaded_members["provenance"]
            if not isinstance(structure, Mapping):
                raise ValueError("candidate ZIP structure member is malformed")
            try:
                StructurePayload.from_dict(structure)
            except (TypeError, ValueError):
                raise ValueError("candidate ZIP structure member is malformed") from None
            if (
                not isinstance(provenance, Mapping)
                or set(provenance) != provenance_keys
                or provenance.get("evaluation_id") != identity
                or not isinstance(provenance.get("condition"), Mapping)
                or type(provenance.get("sample_index")) is not int
                or type(provenance.get("registered_seed")) is not int
                or (
                    provenance.get("training_seed") is not None
                    and type(provenance.get("training_seed")) is not int
                )
                or not isinstance(provenance.get("provenance"), Mapping)
            ):
                raise ValueError("candidate ZIP provenance member is malformed")
            recovered_candidates.append(
                {
                    "evaluation_id": identity,
                    "structure": dict(structure),
                    "condition": dict(provenance["condition"]),
                    "sample_index": provenance["sample_index"],
                    "registered_seed": provenance["registered_seed"],
                    "training_seed": provenance["training_seed"],
                    "provenance": dict(provenance["provenance"]),
                    "eligibility": dict(eligibility),
                }
            )
        if set(names) != declared_members:
            raise ValueError("candidate ZIP contains undeclared or missing members")
        if expected_selection is not None:
            recovered_selection = {
                **{
                    name: manifest[name]
                    for name in (
                        "schema_version",
                        "model",
                        "candidate_count",
                        "chgnet_criterion",
                        "requires_strict_0_03_space_group_match",
                        "requires_unique_representative",
                    )
                },
                "final_zip_written": False,
                "candidates": recovered_candidates,
            }
            if recovered_selection != dict(expected_selection):
                raise ValueError("candidate ZIP differs from upstream candidate set")


def _scientific_contract_digest(contract: Mapping[str, Any]) -> str:
    content = _canonical_json(contract).encode("utf-8")
    return hashlib.sha256(content).hexdigest()


def _validate_upstream_scientific_contract(
    payloads: Mapping[str, object],
    contract: object,
) -> None:
    if (
        not isinstance(contract, Mapping)
        or set(contract) != _FINAL_SCIENTIFIC_CONTRACT_KEYS
        or contract.get("schema_version") != _FINAL_SCIENTIFIC_CONTRACT_SCHEMA
    ):
        raise ValueError("upstream scientific contract is missing or malformed")
    comparisons = {
        "COMMON_CHGNET_BENCHMARK.json": "common_chgnet_results",
        "CSP_MATCH_RATE_RESULTS.json": "csp_results",
        "MATTERSIM_REFERENCE_BENCHMARK.json": "mattersim_results",
        "BENCHMARK_FAILURES.jsonl": "failure_records",
    }
    for artifact, field in comparisons.items():
        if payloads.get(artifact) != contract.get(field):
            raise ValueError(f"{artifact} differs from upstream scientific contract")
    expected_candidates = contract.get("candidate_selection")
    if not isinstance(expected_candidates, Mapping):
        raise ValueError("upstream candidate set is missing")
    _validate_candidate_zip(
        payloads.get("FULL_CRYSALIS_BENCHMARK_CANDIDATES.zip"),
        expected_selection=expected_candidates,
    )


def validate_delivery_payloads(payloads: Mapping[str, object]) -> None:
    """Fail closed on the scientific semantics of every non-manifest payload."""

    expected = set(REQUIRED_OUTPUTS) - {MANIFEST_NAME}
    if set(payloads) != expected:
        raise ValueError("delivery payload names differ from the required artifacts")
    _validate_all_rates(payloads, label="delivery")
    capability = _required_mapping(
        payloads,
        "BASELINE_CONDITION_CAPABILITY.json",
        "baseline condition capability",
    )
    if capability != capability_matrix_payload():
        raise ValueError("baseline condition capability matrix drifted")

    common = _required_mapping(
        payloads,
        "COMMON_CHGNET_BENCHMARK.json",
        "common CHGNet benchmark",
    )
    if common.get("schema_version") != "g1-external-benchmark-common-results.1.0.0":
        raise ValueError("common CHGNet benchmark schema drifted")
    table_a = common.get("table_a_rows")
    table_b = common.get("table_b_rows")
    full_summary = common.get("full_crysalis_summary")
    if (
        not isinstance(table_a, Sequence)
        or isinstance(table_a, (str, bytes))
        or not isinstance(table_b, Sequence)
        or isinstance(table_b, (str, bytes))
        or not isinstance(full_summary, Mapping)
    ):
        raise ValueError("common CHGNet tables or pooled summary are missing")
    frozen_a = _validate_summary_rows(table_a, table="Table A", enforce_named_conditions=False)
    frozen_b = _validate_summary_rows(table_b, table="Table B")
    rows_a = {str(row.get("model")): row for row in frozen_a}
    rows_b = {str(row.get("model")): row for row in frozen_b}
    if set(rows_a) != {"FULL_CRYSALIS", "CrystalFormer"} or set(rows_b) != {
        "FULL_CRYSALIS",
        "CrystalFormer",
        "MatterGen",
        "CrystalFlow",
        "DiffCSP",
    }:
        raise ValueError("common CHGNet table model coverage drifted")
    expected_summary_identities = {
        "FULL_CRYSALIS": ("EXACT_FORMULA_PLUS_SG", 900),
        "CrystalFormer": ("EXACT_FORMULA_PLUS_SG", 300),
        "MatterGen": ("SG_ONLY", 300),
        "CrystalFlow": ("EXACT_FORMULA_ONLY", 300),
        "DiffCSP": ("EXACT_FORMULA_ONLY", 300),
    }
    for model, (condition_level, count) in expected_summary_identities.items():
        summary = _validate_model_summary(
            rows_b[model],
            model=model,
            condition_level=condition_level,
            attempt_count=count,
            label=f"Table B {model}",
        )
        if model in rows_a and rows_a[model] != summary:
            raise ValueError(f"Table A/B {model} summary binding drifted")

    attribution = _required_mapping(
        payloads,
        "CELL_RELAX_FAILURE_ATTRIBUTION.json",
        "cell-relax failure attribution",
    )
    validate_cell_relax_failure_attribution(attribution)
    attribution_markdown = payloads.get("CELL_RELAX_FAILURE_ATTRIBUTION.md")
    if (
        not isinstance(attribution_markdown, str)
        or attribution_markdown.rstrip()
        != render_cell_relax_failure_attribution(attribution).rstrip()
    ):
        raise ValueError("cell-relax failure attribution Markdown drifted")
    gpu_adjudication = _required_mapping(
        payloads,
        "CELL_RELAX_GPU_ADJUDICATION.json",
        "cell-relax GPU adjudication",
    )
    validate_gpu_adjudication(gpu_adjudication)
    gpu_adjudication_markdown = payloads.get("CELL_RELAX_GPU_ADJUDICATION.md")
    if (
        not isinstance(gpu_adjudication_markdown, str)
        or gpu_adjudication_markdown.rstrip() != render_gpu_adjudication(gpu_adjudication).rstrip()
    ):
        raise ValueError("cell-relax GPU adjudication Markdown drifted")

    crystalformer = _required_mapping(
        payloads,
        "CRYSTALFORMER_RESULTS.json",
        "CrystalFormer results",
    )
    if (
        crystalformer.get("schema_version") != "g1-external-benchmark-crystalformer-results.1.0.0"
        or crystalformer.get("model") != "CrystalFormer"
        or crystalformer.get("condition_level") != "EXACT_FORMULA_PLUS_SG"
    ):
        raise ValueError("CrystalFormer results schema or condition identity drifted")
    secondary = crystalformer.get("secondary_k5")
    primary = _validate_model_summary(
        crystalformer.get("primary_k1"),
        model="CrystalFormer",
        condition_level="EXACT_FORMULA_PLUS_SG",
        attempt_count=300,
        label="CrystalFormer K=1",
    )
    if (
        primary != rows_b.get("CrystalFormer")
        or not isinstance(secondary, Mapping)
        or secondary.get("analysis_role") != "SECONDARY_CSP_ONLY"
        or secondary.get("condition_count") != 300
        or secondary.get("attempt_count") != 1500
        or secondary.get("new_attempt_count") != 1200
        or secondary.get("pooled_with_primary_quality") is not False
        or secondary.get("may_replace_k1") is not False
    ):
        raise ValueError("CrystalFormer results do not preserve K=1/K=5 separation")

    model_files = {
        "MATTERGEN_RESULTS.json": ("MatterGen", "SG_ONLY"),
        "CRYSTALFLOW_RESULTS.json": ("CrystalFlow", "EXACT_FORMULA_ONLY"),
        "DIFFCSP_RESULTS.json": ("DiffCSP", "EXACT_FORMULA_ONLY"),
    }
    for name, (model, condition_level) in model_files.items():
        result = _required_mapping(payloads, name, f"{model} results")
        summary = _validate_model_summary(
            result.get("common_summary"),
            model=model,
            condition_level=condition_level,
            attempt_count=300,
            label=model,
        )
        if (
            result.get("schema_version") != "g1-external-benchmark-model-results.1.0.0"
            or result.get("model") != model
            or result.get("condition_level") != condition_level
            or summary != rows_b.get(model)
        ):
            raise ValueError(f"{model} result/capability binding drifted")

    csp = _required_mapping(payloads, "CSP_MATCH_RATE_RESULTS.json", "CSP results")
    k1 = csp.get("crystalformer_k1")
    k5 = csp.get("crystalformer_k5_secondary")
    if (
        csp.get("schema_version") != "g1-external-benchmark-csp-results.1.0.0"
        or not isinstance(k1, Mapping)
        or not isinstance(k5, Mapping)
        or (k1.get("condition_count"), k1.get("samples_per_condition"), k1.get("attempt_count"))
        != (300, 1, 300)
        or k5.get("analysis_role") != "SECONDARY_CSP_ONLY"
        or (k5.get("condition_count"), k5.get("samples_per_condition"), k5.get("attempt_count"))
        != (300, 5, 1500)
        or k5.get("pooled_with_k1_quality") is not False
    ):
        raise ValueError("CrystalFormer K=1 and K=5 CSP results are mixed or incomplete")
    for label, cohort, samples_per_condition in (
        ("CrystalFormer K=1", k1, 1),
        ("CrystalFormer K=5", k5, 5),
    ):
        if (
            cohort.get("schema_version") != "g1-external-benchmark-csp-metrics.1.0.0"
            or cohort.get("matcher") != _CSP_MATCHER
            or cohort.get("target_space_group_used_by_matcher") is not False
            or type(cohort.get("matched_condition_count")) is not int
            or not 0 <= cohort["matched_condition_count"] <= 300
            or cohort.get("normalized_rms_condition_count") != cohort["matched_condition_count"]
            or type(cohort.get("normalized_rms_sample_count")) is not int
            or not 0 <= cohort["normalized_rms_sample_count"] <= 300 * samples_per_condition
            or type(cohort.get("parse_failure_count")) is not int
            or not 0 <= cohort["parse_failure_count"] <= 300 * samples_per_condition
            or type(cohort.get("matcher_failure_count")) is not int
            or not 0 <= cohort["matcher_failure_count"] <= 300 * samples_per_condition
            or cohort.get("all_conditions_in_denominator") is not True
        ):
            raise ValueError(f"{label} CSP scientific fields are incomplete")
        match_rate = _finite_number(cohort.get("match_rate"), label=f"{label} match rate")
        if not math.isclose(
            match_rate,
            cohort["matched_condition_count"] / 300,
            rel_tol=1e-12,
            abs_tol=1e-15,
        ):
            raise ValueError(f"{label} CSP match rate drifted")
        rms_mean = cohort.get("normalized_rms_mean")
        if cohort["matched_condition_count"] == 0:
            if rms_mean is not None:
                raise ValueError(f"{label} CSP RMS must be unavailable without matches")
        else:
            _finite_number(rms_mean, label=f"{label} normalized RMS", minimum=0.0)
        per_condition = cohort.get("per_condition")
        if (
            not isinstance(per_condition, list)
            or len(per_condition) != 300
            or len({row.get("condition_id") for row in per_condition if isinstance(row, Mapping)})
            != 300
        ):
            raise ValueError(f"{label} CSP per-condition denominator drifted")
        matched_rows = 0
        matched_samples = 0
        parse_failures = 0
        matcher_failures = 0
        matched_rms: list[float] = []
        for expected_index, row in enumerate(per_condition):
            if (
                not isinstance(row, Mapping)
                or not str(row.get("condition_id", "")).strip()
                or row.get("attempt_index") != expected_index
                or row.get("target_space_group") not in _SPACE_GROUPS
                or row.get("sample_count") != samples_per_condition
                or type(row.get("matched")) is not bool
                or not isinstance(row.get("sample_results"), list)
                or len(row["sample_results"]) != samples_per_condition
            ):
                raise ValueError(f"{label} CSP per-condition row drifted")
            row_rms = row.get("normalized_rms_distance")
            if row["matched"]:
                matched_rows += 1
                matched_rms.append(
                    _finite_number(
                        row_rms,
                        label=f"{label} condition normalized RMS",
                        minimum=0.0,
                    )
                )
            elif row_rms is not None:
                raise ValueError(f"{label} unmatched condition cannot carry normalized RMS")
            sample_rms: list[float] = []
            for sample_index, sample in enumerate(row["sample_results"]):
                if (
                    not isinstance(sample, Mapping)
                    or sample.get("sample_index") != sample_index
                    or type(sample.get("registered_seed")) is not int
                    or sample["registered_seed"] < 0
                    or type(sample.get("matched")) is not bool
                ):
                    raise ValueError(f"{label} CSP sample row drifted")
                value = sample.get("normalized_rms_distance")
                if sample["matched"]:
                    matched_samples += 1
                    sample_rms.append(
                        _finite_number(
                            value,
                            label=f"{label} sample normalized RMS",
                            minimum=0.0,
                        )
                    )
                    if (
                        sample.get("failure_code") is not None
                        or sample.get("failure_message") is not None
                    ):
                        raise ValueError(f"{label} matched CSP sample carries a failure")
                elif value is not None:
                    raise ValueError(f"{label} unmatched CSP sample carries normalized RMS")
                parse_failures += sample.get("failure_code") == "STRUCTURE_PARSE_FAILED"
                matcher_failures += sample.get("failure_code") == "MATCHER_FAILURE"
            if row["matched"] is not bool(sample_rms) or (
                sample_rms
                and not math.isclose(
                    float(row_rms),
                    min(sample_rms),
                    rel_tol=1e-12,
                    abs_tol=1e-15,
                )
            ):
                raise ValueError(f"{label} CSP condition/sample relation drifted")
        if (
            matched_rows != cohort["matched_condition_count"]
            or matched_samples != cohort["normalized_rms_sample_count"]
            or parse_failures != cohort["parse_failure_count"]
            or matcher_failures != cohort["matcher_failure_count"]
            or (
                matched_rms
                and not math.isclose(
                    float(cohort["normalized_rms_mean"]),
                    fmean(matched_rms),
                    rel_tol=1e-12,
                    abs_tol=1e-15,
                )
            )
        ):
            raise ValueError(f"{label} CSP aggregate fields were not recomputed")

    mattersim = _required_mapping(
        payloads,
        "MATTERSIM_REFERENCE_BENCHMARK.json",
        "MatterSim reference benchmark",
    )
    if (
        mattersim.get("schema_version") != "g1-external-benchmark-mattersim-results.1.0.0"
        or mattersim.get("stage_status")
        not in {"COMPLETE", "NOT_RUN_RESOURCE_LIMIT", "FAILED_PRESERVED"}
        or mattersim.get("primary_chgnet_affected") is not False
    ):
        raise ValueError("MatterSim secondary result drifted")
    if mattersim.get("stage_status") == "NOT_RUN_RESOURCE_LIMIT" and (
        not str(mattersim.get("resource_limit_reason", "")).strip()
        or not isinstance(mattersim.get("resource_evidence"), Mapping)
        or not mattersim["resource_evidence"]
        or mattersim.get("results") not in (None, [])
    ):
        raise ValueError("MatterSim resource-limit evidence is missing")
    if mattersim.get("stage_status") == "COMPLETE":
        eligible = mattersim.get("eligible_attempt_ids")
        results = mattersim.get("results")
        runtime = mattersim.get("runtime_provenance")
        if (
            mattersim.get("smoke_test_status") != "PASS"
            or mattersim.get("weight_sha256") != _MATTERSIM_WEIGHT_SHA256
            or mattersim.get("tri2024_reference_sha256") != _MATTERSIM_TRI2024_SHA256
            or mattersim.get("stability_threshold_ev_per_atom")
            != MATTERSIM_STABILITY_THRESHOLD_EV_PER_ATOM
            or not isinstance(eligible, list)
            or len(eligible) != len(set(eligible))
            or mattersim.get("eligible_attempt_count") != len(eligible)
            or not isinstance(runtime, Mapping)
            or runtime.get("mattersim_model_source") != "OFFICIAL"
            or runtime.get("mattersim_model_weights") != "OFFICIAL"
            or runtime.get("mattersim_runtime_status") != "COMPATIBILITY_PATCHED_RUNNER"
            or runtime.get("model_scientific_algorithm_modified") is not False
            or not isinstance(runtime.get("dependency_versions"), Mapping)
            or not isinstance(runtime.get("exact_command"), list)
            or not runtime["exact_command"]
            or not isinstance(runtime.get("raw_output_sha256"), Mapping)
            or not runtime["raw_output_sha256"]
            or not str(runtime.get("runner_patch_diff", "")).strip()
            or runtime.get("runner_patch_diff_sha256")
            != hashlib.sha256(str(runtime.get("runner_patch_diff")).encode()).hexdigest()
        ):
            raise ValueError("completed MatterSim evidence is incomplete or drifted")
        validate_mattersim_result_rows(results, eligible)
    if mattersim.get("stage_status") == "FAILED_PRESERVED" and (
        not str(mattersim.get("failure_reason", "")).strip()
        or mattersim.get("results") not in (None, [])
    ):
        raise ValueError("MatterSim preserved failure reason is missing")

    by_sg = _required_mapping(payloads, "BENCHMARK_BY_SPACE_GROUP.json", "SG benchmark")
    expected_sg_models = {model: rows_b[model]["per_space_group"] for model in rows_b}
    if (
        by_sg.get("schema_version") != "g1-external-benchmark-by-space-group.1.0.0"
        or by_sg.get("space_groups") != list(_SPACE_GROUPS)
        or by_sg.get("models") != expected_sg_models
    ):
        raise ValueError("space-group benchmark semantics drifted")
    runtime = _required_mapping(payloads, "BENCHMARK_RUNTIME.json", "runtime benchmark")
    expected_runtime_models = {model: rows_b[model]["runtime"] for model in rows_b}
    if (
        runtime.get("schema_version") != "g1-external-benchmark-runtime.1.0.0"
        or runtime.get("models") != expected_runtime_models
        or runtime.get("retry_count") != 0
        or runtime.get("refill_count") != 0
    ):
        raise ValueError("runtime benchmark semantics drifted")

    failures = payloads.get("BENCHMARK_FAILURES.jsonl")
    if (
        isinstance(failures, (str, bytes))
        or not isinstance(failures, Sequence)
        or any(
            not isinstance(row, Mapping)
            or row.get("schema_version") != "g1-external-benchmark-failure.1.0.0"
            or not str(row.get("model", "")).strip()
            or not str(row.get("failure_code", "")).strip()
            or not str(row.get("failure_message", "")).strip()
            for row in failures
        )
    ):
        raise ValueError("benchmark failure records are malformed")
    capability_rows = capability.get("models")
    expected_nonruns = {
        str(row["model"]): str(row["execution_status"])
        for row in capability_rows
        if isinstance(row, Mapping) and str(row.get("execution_status", "")).startswith("NOT_RUN_")
    }
    retained_nonruns = {
        str(row.get("model")): str(row.get("failure_code"))
        for row in failures
        if isinstance(row, Mapping) and str(row.get("failure_code", "")).startswith("NOT_RUN_")
    }
    if retained_nonruns != expected_nonruns:
        raise ValueError("benchmark failure records do not cover every capability non-run")
    published = _required_mapping(
        payloads,
        "PUBLISHED_REFERENCE_METRICS.json",
        "published reference metrics",
    )
    table_c = published.get("table_c_rows")
    if (
        published.get("schema_version") != "g1-external-benchmark-published-reference.1.0.0"
        or not isinstance(table_c, Sequence)
        or isinstance(table_c, (str, bytes))
        or not table_c
        or published.get("cross_protocol_ranking_performed") is not False
    ):
        raise ValueError("published reference metrics drifted")
    _validate_candidate_zip(payloads.get("FULL_CRYSALIS_BENCHMARK_CANDIDATES.zip"))

    expected_report = render_external_benchmark_report(
        table_a_rows=table_a,
        table_b_rows=table_b,
        table_c_rows=table_c,
        capability_rows=capability["models"],
        full_crysalis_summary=full_summary,
        cell_relax_failure_attribution=attribution,
        cell_relax_gpu_adjudication=gpu_adjudication,
        mattersim_results=mattersim,
    )
    report = payloads.get("EXTERNAL_BENCHMARK_REPORT.md")
    if not isinstance(report, str) or report.rstrip() != expected_report.rstrip():
        raise ValueError("external benchmark report must come from the audited renderer")


def validate_final_artifacts(
    output_root: str | Path,
    *,
    expected_upstream_stage_receipt_sha256: Mapping[str, str],
    expected_upstream_typed_artifact_sha256: Mapping[str, Mapping[str, str]],
    expected_upstream_scientific_contract: Mapping[str, Any],
) -> dict[str, Any]:
    """Re-read and rehash the published delivery before a final receipt is accepted."""

    output = Path(output_root).resolve()
    if {path.name for path in output.iterdir() if path.is_file()} != set(REQUIRED_OUTPUTS):
        raise ValueError("final delivery file set drifted")
    manifest = json.loads((output / MANIFEST_NAME).read_text(encoding="utf-8"))
    if (
        not isinstance(manifest, Mapping)
        or manifest.get("schema_version") != "g1-full-crysalis-external-benchmark-manifest.1.0.0"
        or manifest.get("required_artifact_count") != len(REQUIRED_OUTPUTS)
        or manifest.get("required_artifacts") != list(REQUIRED_OUTPUTS)
        or manifest.get("manifest_self_hash_included") is not False
        or manifest.get("manifest_written_after_other_artifacts") is not True
        or manifest.get("top_level_written_only_by_final_stage") is not True
        or manifest.get("stopped_after") != "final"
        or manifest.get("automatic_post_final_stage") is not False
    ):
        raise ValueError("final benchmark manifest semantics drifted")
    _validate_policy_metadata(manifest)
    _validate_upstream_bindings(output, manifest)
    if manifest.get("upstream_stage_receipt_sha256") != dict(
        expected_upstream_stage_receipt_sha256
    ) or manifest.get("upstream_typed_artifact_sha256") != {
        stage: dict(hashes) for stage, hashes in expected_upstream_typed_artifact_sha256.items()
    }:
        raise ValueError("final manifest differs from verified upstream stage bindings")
    if manifest.get("upstream_scientific_contract_sha256") != _scientific_contract_digest(
        expected_upstream_scientific_contract
    ):
        raise ValueError("final manifest upstream scientific contract hash drifted")
    hashes = manifest.get("artifact_sha256")
    expected_hash_names = set(REQUIRED_OUTPUTS) - {MANIFEST_NAME}
    if not isinstance(hashes, Mapping) or set(hashes) != expected_hash_names:
        raise ValueError("final benchmark manifest hash map drifted")
    for name, digest in hashes.items():
        if sha256_file(output / name) != digest:
            raise ValueError(f"final artifact hash drifted: {name}")
    payloads: dict[str, object] = {}
    for name in expected_hash_names:
        path = output / name
        if name.endswith(".zip"):
            payloads[name] = path.read_bytes()
        elif name.endswith(".md"):
            payloads[name] = path.read_text(encoding="utf-8")
        elif name.endswith(".jsonl"):
            payloads[name] = [
                json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()
            ]
        else:
            payloads[name] = json.loads(path.read_text(encoding="utf-8"))
    validate_delivery_payloads(payloads)
    _validate_upstream_scientific_contract(
        payloads,
        expected_upstream_scientific_contract,
    )
    return dict(manifest)


def write_final_artifacts(
    output_root: str | Path,
    payloads: Mapping[str, object],
    *,
    manifest_metadata: Mapping[str, Any],
    upstream_scientific_contract: Mapping[str, Any],
) -> dict[str, Any]:
    """Write the exact top-level delivery once, with the manifest last."""

    output = Path(output_root).resolve()
    expected = set(REQUIRED_OUTPUTS) - {MANIFEST_NAME}
    if set(payloads) != expected:
        raise ValueError(
            "benchmark payload names differ from required outputs: "
            f"missing={sorted(expected - set(payloads))}, "
            f"extra={sorted(set(payloads) - expected)}"
        )
    _validate_policy_metadata(manifest_metadata)
    if not output.is_dir() or not (output / "engineering").is_dir():
        raise FileNotFoundError("finalization requires the existing engineering output root")
    unexpected = sorted(
        path.name
        for path in output.iterdir()
        if path.name != "engineering" and path.name not in REQUIRED_OUTPUTS
    )
    if unexpected:
        raise ValueError(f"unexpected top-level delivery entries: {unexpected}")
    existing = [name for name in REQUIRED_OUTPUTS if (output / name).exists()]
    if existing:
        raise FileExistsError(f"final artifact writer refuses overwrite: {existing}")

    rendered = {
        name: _render_payload(name, payloads[name])
        for name in REQUIRED_OUTPUTS
        if name != MANIFEST_NAME
    }
    validate_delivery_payloads(payloads)
    _validate_upstream_scientific_contract(payloads, upstream_scientific_contract)
    _validate_upstream_bindings(output, manifest_metadata)
    created: list[Path] = []
    try:
        for name in REQUIRED_OUTPUTS:
            if name == MANIFEST_NAME:
                continue
            target = output / name
            _atomic_write_new(target, rendered[name])
            created.append(target)
        hashes = {
            name: sha256_file(output / name) for name in REQUIRED_OUTPUTS if name != MANIFEST_NAME
        }
        manifest = {
            **dict(manifest_metadata),
            "upstream_scientific_contract_sha256": _scientific_contract_digest(
                upstream_scientific_contract
            ),
            "schema_version": "g1-full-crysalis-external-benchmark-manifest.1.0.0",
            "required_artifact_count": len(REQUIRED_OUTPUTS),
            "required_artifacts": list(REQUIRED_OUTPUTS),
            "artifact_sha256": hashes,
            "manifest_self_hash_included": False,
            "manifest_written_after_other_artifacts": True,
            "top_level_written_only_by_final_stage": True,
            "stopped_after": "final",
            "automatic_post_final_stage": False,
        }
        target = output / MANIFEST_NAME
        _atomic_write_new(target, _render_payload(MANIFEST_NAME, manifest))
        created.append(target)
        validate_final_artifacts(
            output,
            expected_upstream_stage_receipt_sha256=manifest_metadata[
                "upstream_stage_receipt_sha256"
            ],
            expected_upstream_typed_artifact_sha256=manifest_metadata[
                "upstream_typed_artifact_sha256"
            ],
            expected_upstream_scientific_contract=upstream_scientific_contract,
        )
    except BaseException:
        for path in reversed(created):
            path.unlink(missing_ok=True)
        raise
    return manifest
