from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Mapping, Sequence

from crysalis_g1.external_benchmark.adapters import (
    AdapterPreflight,
    CommandReceipt,
    CommandSpec,
    build_crystalformer_command,
    combine_crystalformer_k5_attempts,
    execute_official_command,
    import_crystalformer_driver_output,
    verify_adapter_preflight,
)
from crysalis_g1.external_benchmark.capabilities import (
    PrimaryTrack,
    official_capabilities,
)
from crysalis_g1.external_benchmark.config import ExternalBenchmarkConfig
from crysalis_g1.external_benchmark.provenance import sha256_file
from crysalis_g1.external_benchmark.records import (
    AttemptRecord,
    load_registered_conditions_from_config,
    registered_sample_seed,
)
from crysalis_g1.external_benchmark.runner import (
    EXTERNAL_ARTIFACT_REGISTRY,
    StageAction,
    StageContext,
    StageResult,
    verify_stage_receipt,
)


CRYSTALFORMER_COMMIT = "31bb734a3fd006af49a021921839061e6184cbf1"
CRYSTALFORMER_CHECKPOINT_SHA256 = "df1e7051df836d26f45a93fd7f21069a183777317f318001b55f8df20805d177"
CRYSTALFORMER_RUNTIME_VERSIONS = {
    "python": "3.11.9",
    "jax": "0.9.0",
    "jaxlib": "0.9.0",
    "dm-haiku": "0.0.15",
    "optax": "0.2.6",
    "pyxtal": "1.1.1",
}
K5_COMBINED_SCHEMA = "g1-crystalformer-k5-combined.1.0.0"
_COMMIT = re.compile(r"[0-9a-f]{40}")
_SOURCE_BUNDLE_PATHS = (
    "crysalis_g1/external_benchmark/adapters.py",
    "crysalis_g1/external_benchmark/capabilities.py",
    "crysalis_g1/external_benchmark/config.py",
    "crysalis_g1/external_benchmark/official_crystalformer_driver.py",
    "crysalis_g1/external_benchmark/provenance.py",
    "crysalis_g1/external_benchmark/records.py",
    "crysalis_g1/external_benchmark/runner.py",
)


# Tests replace only this private process boundary. Formal callers cannot inject it.
_execute_official_command = execute_official_command


def _json_bytes(payload: object) -> bytes:
    return (
        json.dumps(
            payload,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        + "\n"
    ).encode("utf-8")


def _atomic_write_bytes_new(path: Path, content: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(f"immutable formal artifact already exists: {path}")
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb",
            dir=path.parent,
            prefix=f".{path.name}.",
            delete=False,
        ) as handle:
            temporary = Path(handle.name)
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.link(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _atomic_write_json_new(path: Path, payload: object) -> None:
    _atomic_write_bytes_new(path, _json_bytes(payload))


def _atomic_write_attempts_new(path: Path, attempts: Sequence[AttemptRecord]) -> None:
    _atomic_write_bytes_new(
        path,
        b"".join(_json_bytes(attempt.to_dict()) for attempt in attempts),
    )


def _relative(config: ExternalBenchmarkConfig, path: Path) -> str:
    root = config.output_root.resolve()
    resolved = path.resolve()
    if not resolved.is_relative_to((root / "engineering").resolve()):
        raise ValueError(f"formal artifact is outside engineering: {resolved}")
    return resolved.relative_to(root).as_posix()


def _declaration(
    config: ExternalBenchmarkConfig,
    path: Path,
    *,
    record_count: int | None = None,
) -> dict[str, Any]:
    declaration: dict[str, Any] = {
        "path": _relative(config, path),
        "sha256": sha256_file(path),
    }
    if record_count is not None:
        declaration["record_count"] = record_count
    return declaration


def _git_head(repo_root: Path) -> str:
    completed = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=repo_root,
        check=True,
        shell=False,
        capture_output=True,
        text=True,
    )
    head = completed.stdout.strip().lower()
    if _COMMIT.fullmatch(head) is None:
        raise ValueError("formal action Git HEAD is malformed")
    return head


def _source_paths(repo_root: Path) -> dict[str, Path]:
    return {
        "crysalis_g1/external_benchmark/formal_actions.py": Path(__file__).resolve(),
        **{name: (repo_root / name).resolve() for name in _SOURCE_BUNDLE_PATHS},
    }


def _source_status(repo_root: Path) -> str:
    completed = subprocess.run(
        [
            "git",
            "status",
            "--porcelain=v1",
            "--untracked-files=all",
            "--",
            *sorted(_source_paths(repo_root)),
        ],
        cwd=repo_root,
        check=True,
        shell=False,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def _source_index_tags(repo_root: Path) -> dict[str, str]:
    expected_paths = sorted(_source_paths(repo_root))
    completed = subprocess.run(
        ["git", "ls-files", "-v", "-z", "--", *expected_paths],
        cwd=repo_root,
        check=True,
        shell=False,
        capture_output=True,
        text=True,
    )
    tags: dict[str, str] = {}
    for entry in completed.stdout.split("\0"):
        if not entry:
            continue
        if len(entry) < 3 or entry[1] != " ":
            raise ValueError("execution-critical source index output is malformed")
        path = entry[2:].replace("\\", "/")
        if path in tags:
            raise ValueError("execution-critical source index contains duplicate paths")
        tags[path] = entry[0]
    if set(tags) != set(expected_paths):
        raise ValueError("execution-critical source paths must all be tracked by Git")
    return tags


def _source_head_blobs(repo_root: Path) -> dict[str, str]:
    paths = sorted(_source_paths(repo_root))
    head = subprocess.run(
        ["git", "rev-parse", *(f"HEAD:{path}" for path in paths)],
        cwd=repo_root,
        check=True,
        shell=False,
        capture_output=True,
        text=True,
    ).stdout.splitlines()
    worktree = subprocess.run(
        ["git", "hash-object", "--", *paths],
        cwd=repo_root,
        check=True,
        shell=False,
        capture_output=True,
        text=True,
    ).stdout.splitlines()
    if len(head) != len(paths) or len(worktree) != len(paths):
        raise ValueError("execution-critical source hash output is malformed")
    head_blobs = dict(zip(paths, head, strict=True))
    worktree_blobs = dict(zip(paths, worktree, strict=True))
    drifted = [path for path in paths if worktree_blobs[path] != head_blobs[path]]
    if drifted:
        raise ValueError(f"execution-critical source bytes differ from HEAD: {drifted}")
    return head_blobs


def _require_clean_source_paths(repo_root: Path) -> dict[str, str]:
    unsafe_flags = {path: tag for path, tag in _source_index_tags(repo_root).items() if tag != "H"}
    if unsafe_flags:
        raise ValueError(f"execution-critical source index flags are unsafe: {unsafe_flags}")
    status = _source_status(repo_root)
    if status:
        raise ValueError(f"execution-critical source paths are dirty: {status.splitlines()}")
    return _source_head_blobs(repo_root)


def _source_bundle(repo_root: Path) -> dict[str, str]:
    paths = _source_paths(repo_root)
    for name, path in paths.items():
        if not path.is_file():
            raise FileNotFoundError(f"formal source dependency is missing: {name}: {path}")
    return {name: sha256_file(path) for name, path in sorted(paths.items())}


def _source_bundle_sha256(bundle: Mapping[str, str]) -> str:
    content = json.dumps(bundle, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(content).hexdigest()


def _verify_action_source(
    repo_root: Path,
    *,
    expected_head: str,
    expected_bundle: Mapping[str, str],
    phase: str,
) -> None:
    _require_clean_source_paths(repo_root)
    if _git_head(repo_root) != expected_head or _source_bundle(repo_root) != dict(expected_bundle):
        raise ValueError(f"formal action source bundle changed {phase}")


def _crystalformer_capability() -> Any:
    matches = [
        capability for capability in official_capabilities() if capability.model == "CrystalFormer"
    ]
    if len(matches) != 1:
        raise ValueError("exactly one CrystalFormer capability is required")
    capability = matches[0]
    if (
        capability.official_commit != CRYSTALFORMER_COMMIT
        or capability.checkpoint_sha256 != CRYSTALFORMER_CHECKPOINT_SHA256
    ):
        raise ValueError("CrystalFormer capability differs from the frozen registry")
    if EXTERNAL_ARTIFACT_REGISTRY.get("CrystalFormer") != {
        "official_commit": CRYSTALFORMER_COMMIT,
        "checkpoint_sha256": CRYSTALFORMER_CHECKPOINT_SHA256,
    }:
        raise ValueError("CrystalFormer runner registry drifted")
    return capability


def _read_frozen_preflight(config: ExternalBenchmarkConfig) -> tuple[Path, Mapping[str, Any]]:
    path = config.output_root.resolve() / "engineering" / "audit" / "frozen_preflight.json"
    if not path.is_file():
        raise FileNotFoundError(f"audit frozen_preflight.json is missing: {path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        raise ValueError("audit frozen_preflight.json is malformed") from None
    if not isinstance(payload, Mapping):
        raise ValueError("audit frozen_preflight.json must be an object")
    return path, payload


def _crystalformer_paths(
    config: ExternalBenchmarkConfig,
    repo_root: Path,
) -> tuple[Path, Path, Path, Path]:
    cache = config.official_artifact_cache.resolve()
    checkout = cache / "repos" / "CrystalFormer"
    checkpoint = cache / "checkpoints" / "crystalformer_alex20s_csp" / "epoch_046000.pkl"
    python_executable = cache / "envs" / "crystalformer" / "Scripts" / "python.exe"
    driver = repo_root / "crysalis_g1" / "external_benchmark" / "official_crystalformer_driver.py"
    for label, path in (("Python executable", python_executable), ("driver", driver)):
        if not path.is_file():
            raise FileNotFoundError(f"CrystalFormer {label} is missing: {path}")
    return checkout, checkpoint, python_executable, driver


def _verified_preflight(
    config: ExternalBenchmarkConfig,
    repo_root: Path,
) -> tuple[AdapterPreflight, Path]:
    receipt_path, receipt = _read_frozen_preflight(config)
    checkout, checkpoint, _, _ = _crystalformer_paths(config, repo_root)
    preflight = verify_adapter_preflight(
        config=config,
        frozen_preflight_receipt=receipt,
        capability=_crystalformer_capability(),
        official_checkout=checkout,
        checkpoint_path=checkpoint,
        expected_checkpoint_sha256=CRYSTALFORMER_CHECKPOINT_SHA256,
        requested_track=PrimaryTrack.TRACK_A,
    )
    if preflight.condition_manifest_sha256 != config.condition_manifest_sha256:
        raise ValueError("CrystalFormer condition manifest provenance drifted")
    return preflight, receipt_path


def _stage_paths(context: StageContext, *, secondary: bool) -> dict[str, Path]:
    stage_root = context.engineering_root / (
        "crystalformer_k5_secondary_clean_rerun_1" if secondary else context.stage
    )
    prefix = "samples_1_4" if secondary else "k1"
    paths = {
        "raw": stage_root / f"{prefix}_driver_rows.jsonl",
        "driver_receipt": stage_root / f"{prefix}_driver_receipt.json",
        "stdout": stage_root / "stdout.log",
        "stderr": stage_root / "stderr.log",
        "command_receipt": stage_root / "command_receipt.json",
        "attempt_records": stage_root / "attempt_records.jsonl",
    }
    if secondary:
        paths.update(
            {
                "combined_attempt_records": stage_root / "k5_combined_attempt_records.jsonl",
                "combined_receipt": stage_root / "k5_combined_receipt.json",
            }
        )
    return {name: path.resolve() for name, path in paths.items()}


def _refuse_existing_targets(paths: Mapping[str, Path]) -> None:
    for path in paths.values():
        if path.exists():
            raise FileExistsError(f"immutable formal artifact already exists: {path}")


def _validate_context(
    context: StageContext,
    *,
    config: ExternalBenchmarkConfig,
    repo_root: Path,
    stage: str,
) -> None:
    if not isinstance(context, StageContext) or context.stage != stage:
        raise ValueError(f"formal action requires {stage} StageContext")
    if context.config != config or context.repo_root.resolve() != repo_root:
        raise ValueError("formal action context differs from its frozen build inputs")
    if context.output_root.resolve() != config.output_root.resolve():
        raise ValueError("formal action output root drifted")
    if context.engineering_root.resolve() != (config.output_root / "engineering").resolve():
        raise ValueError("formal action engineering root drifted")


def _validate_driver_receipt_semantics(
    config: ExternalBenchmarkConfig,
    driver_receipt_path: Path,
    raw_output_path: Path,
) -> None:
    payload = json.loads(driver_receipt_path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError("CrystalFormer driver receipt must be an object")
    if Path(str(payload.get("condition_manifest_path"))).resolve() != (
        config.condition_manifest_path.resolve()
    ):
        raise ValueError("CrystalFormer driver condition manifest path drifted")
    rows: list[Mapping[str, Any]] = []
    for line_number, line in enumerate(
        raw_output_path.read_text(encoding="utf-8").splitlines(), start=1
    ):
        if not line.strip():
            raise ValueError(f"CrystalFormer driver output has a blank row at line {line_number}")
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            raise ValueError(
                f"CrystalFormer driver output has invalid JSON at line {line_number}"
            ) from None
        if not isinstance(row, Mapping):
            raise ValueError(f"CrystalFormer driver output row {line_number} is not an object")
        rows.append(row)
    observed_generated = sum(row.get("status") == "GENERATED" for row in rows)
    observed_failed = sum(row.get("status") == "FAILED" for row in rows)
    if (
        observed_generated + observed_failed != len(rows)
        or payload.get("generated_count") != observed_generated
        or payload.get("failed_count") != observed_failed
    ):
        raise ValueError("CrystalFormer driver generated/failed counts drifted")
    environment = payload.get("environment") if isinstance(payload, Mapping) else None
    if not isinstance(environment, Mapping):
        raise ValueError("CrystalFormer driver environment receipt is missing")
    if environment.get("backend") != "cpu" or any(
        environment.get(name) != version for name, version in CRYSTALFORMER_RUNTIME_VERSIONS.items()
    ):
        raise ValueError("CrystalFormer driver environment differs from the frozen runtime")
    compatibility = environment.get("compatibility")
    if (
        not isinstance(compatibility, Mapping)
        or compatibility.get("jax_jaxlib") != "0.9.0"
        or compatibility.get("source_or_weight_modification") is not False
    ):
        raise ValueError("CrystalFormer compatibility provenance drifted")


def _validate_returned_command_receipt(
    command: CommandSpec,
    receipt: CommandReceipt,
    *,
    preflight: AdapterPreflight,
    paths: Mapping[str, Path],
) -> dict[str, Any]:
    if type(receipt) is not CommandReceipt:
        raise TypeError("official command boundary must return exact CommandReceipt")
    expected = {
        "argv": command.argv,
        "cwd": str(command.cwd),
        "executable": command.executable,
        "arguments": command.arguments,
        "shell": False,
        "environment_overrides": dict(command.environment_overrides),
        "runtime_versions": dict(CRYSTALFORMER_RUNTIME_VERSIONS),
        "official_commit": preflight.official_commit,
        "checkpoint_sha256": preflight.checkpoint_sha256,
        "device": "cpu",
        "launch_count": 1,
        "retry_count": 0,
        "refill_count": 0,
    }
    observed = {
        "argv": receipt.argv,
        "cwd": receipt.cwd,
        "executable": receipt.executable,
        "arguments": receipt.arguments,
        "shell": receipt.shell,
        "environment_overrides": dict(receipt.environment_overrides),
        "runtime_versions": dict(receipt.runtime_versions),
        "official_commit": receipt.official_commit,
        "checkpoint_sha256": receipt.checkpoint_sha256,
        "device": receipt.device,
        "launch_count": receipt.launch_count,
        "retry_count": receipt.retry_count,
        "refill_count": receipt.refill_count,
    }
    if observed != expected:
        raise ValueError("CrystalFormer command receipt differs from launched CommandSpec")
    if (
        type(receipt.exit_code) is not int
        or type(receipt.peak_ram_bytes) is not int
        or receipt.peak_ram_bytes < 0
        or receipt.peak_vram_bytes is not None
    ):
        raise ValueError("CrystalFormer command resource receipt drifted")
    timestamps: list[datetime] = []
    for value in (receipt.started_at, receipt.ended_at):
        if not isinstance(value, str):
            raise ValueError("CrystalFormer command receipt timestamp is malformed")
        try:
            timestamp = datetime.fromisoformat(value)
        except ValueError:
            raise ValueError("CrystalFormer command receipt timestamp is malformed") from None
        if timestamp.tzinfo is None or timestamp.utcoffset() != timedelta(0):
            raise ValueError("CrystalFormer command receipt timestamp must be UTC")
        timestamps.append(timestamp)
    if timestamps[1] < timestamps[0]:
        raise ValueError("CrystalFormer command receipt timestamp order drifted")
    for name in ("stdout", "stderr"):
        expected_path = paths[name].resolve()
        observed_path = Path(getattr(receipt, f"{name}_path")).resolve()
        observed_hash = getattr(receipt, f"{name}_sha256")
        if (
            observed_path != expected_path
            or not expected_path.is_file()
            or sha256_file(expected_path) != observed_hash
        ):
            raise ValueError(f"CrystalFormer command receipt {name} artifact drifted")
    return CommandReceipt.to_dict(receipt)


def _run_crystalformer_shard(
    context: StageContext,
    *,
    config: ExternalBenchmarkConfig,
    repo_root: Path,
    sample_index_start: int,
    sample_count: int,
    expected_head: str,
    expected_source_bundle: Mapping[str, str],
) -> tuple[
    tuple[AttemptRecord, ...],
    dict[str, Any],
    AdapterPreflight,
    Path,
    dict[str, Path],
]:
    conditions = load_registered_conditions_from_config(config)
    preflight, frozen_preflight_path = _verified_preflight(config, repo_root)
    paths = _stage_paths(context, secondary=sample_index_start == 1)
    _refuse_existing_targets(paths)
    checkout, checkpoint, python_executable, driver = _crystalformer_paths(config, repo_root)
    command = build_crystalformer_command(
        python_executable=python_executable,
        driver_path=driver,
        condition_manifest_path=config.condition_manifest_path,
        condition_manifest_sha256=config.condition_manifest_sha256,
        sample_index_start=sample_index_start,
        sample_count=sample_count,
        official_checkout=checkout,
        checkpoint_path=checkpoint,
        output_jsonl_path=paths["raw"],
        driver_receipt_path=paths["driver_receipt"],
        cwd=checkout,
    )
    _verify_action_source(
        repo_root,
        expected_head=expected_head,
        expected_bundle=expected_source_bundle,
        phase="before launch",
    )
    command_receipt = _execute_official_command(
        command,
        preflight=preflight,
        stdout_path=paths["stdout"],
        stderr_path=paths["stderr"],
        receipt_path=paths["command_receipt"],
        runtime_versions=CRYSTALFORMER_RUNTIME_VERSIONS,
    )
    _verify_action_source(
        repo_root,
        expected_head=expected_head,
        expected_bundle=expected_source_bundle,
        phase="during subprocess",
    )
    command_receipt_payload = _validate_returned_command_receipt(
        command,
        command_receipt,
        preflight=preflight,
        paths=paths,
    )
    if command_receipt.exit_code != 0:
        raise RuntimeError(
            f"CrystalFormer official command failed with exit code {command_receipt.exit_code}"
        )
    if paths["command_receipt"].read_bytes() != _json_bytes(command_receipt_payload):
        raise ValueError("CrystalFormer command receipt artifact drifted")
    _validate_driver_receipt_semantics(
        config,
        paths["driver_receipt"],
        paths["raw"],
    )
    attempts = import_crystalformer_driver_output(
        preflight=preflight,
        conditions=conditions,
        output_jsonl_path=paths["raw"],
        driver_receipt_path=paths["driver_receipt"],
        sample_index_start=sample_index_start,
        sample_count=sample_count,
    )
    expected_count = len(conditions) * sample_count
    if len(attempts) != expected_count:
        raise ValueError("CrystalFormer imported attempt denominator drifted")
    _atomic_write_attempts_new(paths["attempt_records"], attempts)
    return attempts, command_receipt_payload, preflight, frozen_preflight_path, paths


def _source_declaration(
    config: ExternalBenchmarkConfig,
    declaration: object,
    stage_receipt: Mapping[str, Any],
) -> tuple[Path, dict[str, Any]]:
    if not isinstance(declaration, Mapping) or set(declaration) != {"path", "sha256"}:
        raise ValueError("CrystalFormer K=1 driver receipt declaration drifted")
    path = (config.output_root / str(declaration["path"])).resolve()
    expected_sha = str(declaration["sha256"])
    outputs = stage_receipt.get("output_sha256")
    if (
        not path.is_relative_to((config.output_root / "engineering" / "crystalformer").resolve())
        or not path.is_file()
        or sha256_file(path) != expected_sha
        or not isinstance(outputs, Mapping)
        or outputs.get(str(declaration["path"])) != expected_sha
    ):
        raise ValueError("CrystalFormer K=1 driver receipt hash drifted")
    return path, {"path": str(declaration["path"]), "sha256": expected_sha}


def _common_evidence(
    *,
    config: ExternalBenchmarkConfig,
    frozen_preflight_path: Path,
    paths: Mapping[str, Path],
    attempt_count: int,
    action_source: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        "model": "CrystalFormer",
        "condition_level": "EXACT_FORMULA_PLUS_SG",
        "attempt_count": attempt_count,
        "denominator_complete": True,
        "retry_count": 0,
        "refill_count": 0,
        "attempt_records": _declaration(
            config, paths["attempt_records"], record_count=attempt_count
        ),
        "raw_driver_output": _declaration(config, paths["raw"], record_count=attempt_count),
        "driver_receipt": _declaration(config, paths["driver_receipt"]),
        "command_receipt_artifact": _declaration(config, paths["command_receipt"]),
        "frozen_preflight": _declaration(config, frozen_preflight_path),
        "official_artifacts": {"CrystalFormer": dict(EXTERNAL_ARTIFACT_REGISTRY["CrystalFormer"])},
        "action_source": {
            **{name: value for name, value in action_source.items() if name != "source_bundle"},
            "source_bundle": dict(action_source["source_bundle"]),
        },
    }


def _primary_action(
    *,
    config: ExternalBenchmarkConfig,
    repo_root: Path,
    expected_head: str,
    expected_source_bundle: Mapping[str, str],
    action_source: Mapping[str, Any],
) -> Any:
    def execute(context: StageContext) -> StageResult:
        _validate_context(
            context,
            config=config,
            repo_root=repo_root,
            stage="crystalformer",
        )
        _verify_action_source(
            repo_root,
            expected_head=expected_head,
            expected_bundle=expected_source_bundle,
            phase="after registration",
        )
        attempts, command_receipt, _, frozen_preflight_path, paths = _run_crystalformer_shard(
            context,
            config=config,
            repo_root=repo_root,
            sample_index_start=0,
            sample_count=1,
            expected_head=expected_head,
            expected_source_bundle=expected_source_bundle,
        )
        evidence = _common_evidence(
            config=config,
            frozen_preflight_path=frozen_preflight_path,
            paths=paths,
            attempt_count=len(attempts),
            action_source=action_source,
        )
        evidence["samples_per_condition"] = 1
        _verify_action_source(
            repo_root,
            expected_head=expected_head,
            expected_bundle=expected_source_bundle,
            phase="before completion",
        )
        return StageResult(
            outputs=tuple(paths.values()),
            evidence=evidence,
            command_receipts=(command_receipt,),
        )

    return execute


def _secondary_action(
    *,
    config: ExternalBenchmarkConfig,
    repo_root: Path,
    expected_head: str,
    expected_source_bundle: Mapping[str, str],
    action_source: Mapping[str, Any],
) -> Any:
    def execute(context: StageContext) -> StageResult:
        _validate_context(
            context,
            config=config,
            repo_root=repo_root,
            stage="crystalformer_k5_secondary",
        )
        _verify_action_source(
            repo_root,
            expected_head=expected_head,
            expected_bundle=expected_source_bundle,
            phase="after registration",
        )
        primary_stage_receipt = verify_stage_receipt(
            config,
            "crystalformer",
            repo_root=repo_root,
        )
        primary_driver_path, primary_driver_declaration = _source_declaration(
            config,
            primary_stage_receipt.get("evidence", {}).get("driver_receipt"),
            primary_stage_receipt,
        )
        attempts, command_receipt, preflight, frozen_preflight_path, paths = (
            _run_crystalformer_shard(
                context,
                config=config,
                repo_root=repo_root,
                sample_index_start=1,
                sample_count=4,
                expected_head=expected_head,
                expected_source_bundle=expected_source_bundle,
            )
        )
        secondary_driver_declaration = _declaration(config, paths["driver_receipt"])
        conditions = load_registered_conditions_from_config(config)
        combined = combine_crystalformer_k5_attempts(
            preflight=preflight,
            conditions=conditions,
            primary_driver_receipt_path=primary_driver_path,
            primary_driver_receipt_sha256=primary_driver_declaration["sha256"],
            secondary_driver_receipt_path=paths["driver_receipt"],
            secondary_driver_receipt_sha256=secondary_driver_declaration["sha256"],
        )
        if len(combined) != 1500:
            raise ValueError("CrystalFormer combined K=5 denominator drifted")
        _atomic_write_attempts_new(paths["combined_attempt_records"], combined)
        combined_attempt_declaration = _declaration(
            config,
            paths["combined_attempt_records"],
            record_count=len(combined),
        )
        primary_stage_path = (
            config.output_root / "engineering" / "receipts" / "crystalformer.json"
        ).resolve()
        combined_receipt = {
            "schema_version": K5_COMBINED_SCHEMA,
            "model": "CrystalFormer",
            "condition_level": "EXACT_FORMULA_PLUS_SG",
            "analysis_role": "SECONDARY_CSP_ONLY",
            "primary_attempt_count": 300,
            "secondary_attempt_count": len(attempts),
            "combined_attempt_count": len(combined),
            "samples_per_condition": 5,
            "sample_indices": [0, 1, 2, 3, 4],
            "pooled_with_k1": False,
            "may_replace_k1": False,
            "retry_count": 0,
            "refill_count": 0,
            "primary_stage_receipt": _declaration(config, primary_stage_path),
            "primary_driver_receipt": primary_driver_declaration,
            "secondary_driver_receipt": secondary_driver_declaration,
            "combined_attempt_records": combined_attempt_declaration,
        }
        _atomic_write_json_new(paths["combined_receipt"], combined_receipt)
        evidence = _common_evidence(
            config=config,
            frozen_preflight_path=frozen_preflight_path,
            paths=paths,
            attempt_count=len(attempts),
            action_source=action_source,
        )
        evidence.update(
            {
                "analysis_role": "SECONDARY_CSP_ONLY",
                "samples_per_condition": 4,
                "sample_indices": [1, 2, 3, 4],
                "pooled_with_k1": False,
                "may_replace_k1": False,
                "k1_stage_receipt": _declaration(config, primary_stage_path),
                "k5_combined_attempt_records": combined_attempt_declaration,
                "k5_combined_receipt": _declaration(config, paths["combined_receipt"]),
            }
        )
        _verify_action_source(
            repo_root,
            expected_head=expected_head,
            expected_bundle=expected_source_bundle,
            phase="before completion",
        )
        return StageResult(
            outputs=tuple(paths.values()),
            evidence=evidence,
            command_receipts=(command_receipt,),
        )

    return execute


def _registered_attempt_ids(
    config: ExternalBenchmarkConfig,
    sample_indices: Sequence[int],
) -> tuple[str, ...]:
    return tuple(
        f"{condition.condition_id}/sample-{sample_index}/seed-"
        f"{registered_sample_seed(condition, sample_index)}"
        for condition in load_registered_conditions_from_config(config)
        for sample_index in sample_indices
    )


def build_stage_actions(
    config: ExternalBenchmarkConfig,
    repo_root: str | Path,
) -> dict[str, StageAction]:
    if not isinstance(config, ExternalBenchmarkConfig):
        raise TypeError("formal actions require ExternalBenchmarkConfig")
    repo = Path(repo_root).resolve()
    if not repo.is_dir():
        raise FileNotFoundError(f"repository root is missing: {repo}")
    load_registered_conditions_from_config(config)
    head = _git_head(repo)
    source_head_blobs = _require_clean_source_paths(repo)
    source_bundle = _source_bundle(repo)
    source_bundle_sha256 = _source_bundle_sha256(source_bundle)
    module_sha = source_bundle["crysalis_g1/external_benchmark/formal_actions.py"]
    action_source = {
        "git_head": head,
        "module_path": str(Path(__file__).resolve()),
        "module_sha256": module_sha,
        "source_head_blobs": dict(source_head_blobs),
        "source_bundle": dict(source_bundle),
        "source_bundle_sha256": source_bundle_sha256,
    }
    source_id = f"git-{head}:source-bundle-{source_bundle_sha256}:formal-actions-{module_sha}"
    return {
        "crystalformer": StageAction(
            action_id=f"crystalformer-k1:{source_id}",
            execute=_primary_action(
                config=config,
                repo_root=repo,
                expected_head=head,
                expected_source_bundle=source_bundle,
                action_source=action_source,
            ),
            registered_attempt_ids=_registered_attempt_ids(config, (0,)),
        ),
        "crystalformer_k5_secondary": StageAction(
            action_id=f"crystalformer-k4-secondary:{source_id}",
            execute=_secondary_action(
                config=config,
                repo_root=repo,
                expected_head=head,
                expected_source_bundle=source_bundle,
                action_source=action_source,
            ),
            registered_attempt_ids=_registered_attempt_ids(config, (1, 2, 3, 4)),
        ),
    }
