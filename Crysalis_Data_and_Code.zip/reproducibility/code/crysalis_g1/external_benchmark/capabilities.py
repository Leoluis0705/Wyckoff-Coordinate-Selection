from __future__ import annotations

import re
from dataclasses import dataclass
from enum import StrEnum
from typing import Any, Iterable


SCHEMA_VERSION = "g1-external-baseline-capability.1.0.0"
UNKNOWN_DIGEST = "UNKNOWN"
_COMMIT = re.compile(r"[0-9a-f]{40}")
_SHA256 = re.compile(r"[0-9a-f]{64}")


class ConditionLevel(StrEnum):
    EXACT_FORMULA_PLUS_SG = "EXACT_FORMULA_PLUS_SG"
    EXACT_FORMULA_ONLY = "EXACT_FORMULA_ONLY"
    SG_ONLY = "SG_ONLY"
    CHEMICAL_SYSTEM_ONLY = "CHEMICAL_SYSTEM_ONLY"
    UNCONDITIONAL = "UNCONDITIONAL"
    PROPERTY_CONDITIONED = "PROPERTY_CONDITIONED"


class PrimaryTrack(StrEnum):
    TRACK_A = "TRACK_A"
    TRACK_B = "TRACK_B"
    RELATED_WORK_ONLY = "RELATED_WORK_ONLY"


class ExecutionStatus(StrEnum):
    READY_OFFICIAL_ARTIFACT = "READY_OFFICIAL_ARTIFACT"
    CONDITION_PROTOCOL_MISMATCH = "CONDITION_PROTOCOL_MISMATCH"
    CHECKPOINT_DIGEST_UNVERIFIED = "CHECKPOINT_DIGEST_UNVERIFIED"
    EXTRA_TEMPLATE_CONDITION_REQUIRED = "EXTRA_TEMPLATE_CONDITION_REQUIRED"
    NOT_RUN_NO_OFFICIAL_REPRODUCIBLE_ARTIFACT = (
        "NOT_RUN_NO_OFFICIAL_REPRODUCIBLE_ARTIFACT"
    )
    NOT_RUN_NO_RELEASED_CHECKPOINT = "NOT_RUN_NO_RELEASED_CHECKPOINT"


def _enum(value: Any, enum_type: type[StrEnum], *, field: str) -> StrEnum:
    try:
        return enum_type(value)
    except (TypeError, ValueError):
        raise ValueError(f"invalid {field}: {value!r}") from None


@dataclass(frozen=True, slots=True)
class BaselineCapability:
    model: str
    official_repository: str | None
    official_commit: str | None
    checkpoint: str | None
    checkpoint_sha256: str | None
    training_dataset: str
    supports_exact_formula: bool
    supports_target_space_group: bool
    supports_formula_plus_sg: bool
    requires_retraining: bool
    condition_level: ConditionLevel
    primary_track: PrimaryTrack
    execution_status: ExecutionStatus
    reason: str
    evidence_urls: tuple[str, ...]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "condition_level",
            _enum(self.condition_level, ConditionLevel, field="condition_level"),
        )
        object.__setattr__(
            self,
            "primary_track",
            _enum(self.primary_track, PrimaryTrack, field="primary_track"),
        )
        object.__setattr__(
            self,
            "execution_status",
            _enum(self.execution_status, ExecutionStatus, field="execution_status"),
        )
        object.__setattr__(self, "evidence_urls", tuple(self.evidence_urls))
        validate_capability(self)

    def to_dict(self) -> dict[str, Any]:
        return {
            "model": self.model,
            "official_repository": self.official_repository,
            "official_commit": self.official_commit,
            "checkpoint": self.checkpoint,
            "checkpoint_sha256": self.checkpoint_sha256,
            "training_dataset": self.training_dataset,
            "supports_exact_formula": self.supports_exact_formula,
            "supports_target_space_group": self.supports_target_space_group,
            "supports_formula_plus_sg": self.supports_formula_plus_sg,
            "requires_retraining": self.requires_retraining,
            "condition_level": self.condition_level.value,
            "primary_track": self.primary_track.value,
            "execution_status": self.execution_status.value,
            "reason": self.reason,
            "evidence_urls": list(self.evidence_urls),
        }


def validate_capability(record: BaselineCapability) -> None:
    if not record.model.strip():
        raise ValueError("model must be non-empty")
    if not record.training_dataset.strip():
        raise ValueError(f"training_dataset must be non-empty: {record.model}")
    if not record.reason.strip():
        raise ValueError(f"reason must be non-empty: {record.model}")
    boolean_fields = (
        "supports_exact_formula",
        "supports_target_space_group",
        "supports_formula_plus_sg",
        "requires_retraining",
    )
    if any(type(getattr(record, field)) is not bool for field in boolean_fields):
        raise ValueError(f"capability flags must be booleans: {record.model}")

    if record.primary_track is PrimaryTrack.TRACK_A:
        if not (
            record.supports_exact_formula
            and record.supports_target_space_group
            and record.supports_formula_plus_sg
        ):
            raise ValueError("TRACK_A requires exact formula plus explicit target SG")
        if record.requires_retraining:
            raise ValueError("TRACK_A cannot require retraining")
        if record.condition_level is not ConditionLevel.EXACT_FORMULA_PLUS_SG:
            raise ValueError("TRACK_A requires condition_level EXACT_FORMULA_PLUS_SG")
        if record.execution_status is not ExecutionStatus.READY_OFFICIAL_ARTIFACT:
            raise ValueError("TRACK_A requires a runnable released official artifact")
        if not (
            record.official_repository
            and record.official_commit
            and record.checkpoint
            and record.checkpoint_sha256
            and _SHA256.fullmatch(record.checkpoint_sha256)
        ):
            raise ValueError("TRACK_A requires a checkpoint with a verified SHA-256")

    if record.supports_formula_plus_sg and not (
        record.supports_exact_formula and record.supports_target_space_group
    ):
        raise ValueError("formula_plus_sg requires exact-formula and target-SG support")
    if record.condition_level is ConditionLevel.EXACT_FORMULA_PLUS_SG and not (
        record.supports_exact_formula
        and record.supports_target_space_group
        and record.supports_formula_plus_sg
    ):
        raise ValueError("EXACT_FORMULA_PLUS_SG condition flags are inconsistent")
    if record.condition_level is ConditionLevel.EXACT_FORMULA_ONLY and not (
        record.supports_exact_formula and not record.supports_formula_plus_sg
    ):
        raise ValueError("EXACT_FORMULA_ONLY condition flags are inconsistent")
    if record.condition_level is ConditionLevel.SG_ONLY and not (
        record.supports_target_space_group
        and not record.supports_exact_formula
        and not record.supports_formula_plus_sg
    ):
        raise ValueError("SG_ONLY condition flags are inconsistent")
    if record.condition_level in {
        ConditionLevel.UNCONDITIONAL,
        ConditionLevel.CHEMICAL_SYSTEM_ONLY,
    } and any(
        (
            record.supports_exact_formula,
            record.supports_target_space_group,
            record.supports_formula_plus_sg,
        )
    ):
        raise ValueError(
            f"{record.condition_level.value} cannot claim exact-formula or "
            "exact-target-SG support"
        )
    if record.condition_level is ConditionLevel.PROPERTY_CONDITIONED:
        property_flags = (
            record.supports_exact_formula,
            record.supports_target_space_group,
            record.supports_formula_plus_sg,
        )
        if property_flags not in {
            (False, False, False),
            (True, True, False),
        }:
            raise ValueError(
                "PROPERTY_CONDITIONED flags must either make no exact-condition "
                "claim or disclose separate formula and SG inputs without claiming "
                "formula-plus-SG-only support"
            )

    if record.official_repository is not None and not record.official_repository.startswith(
        "https://"
    ):
        raise ValueError(f"official_repository must be HTTPS: {record.model}")
    if record.official_commit is not None and _COMMIT.fullmatch(record.official_commit) is None:
        raise ValueError(f"official_commit must be a full Git commit: {record.model}")
    if record.official_repository is None and record.official_commit is not None:
        raise ValueError(f"official_commit has no official repository: {record.model}")

    if record.checkpoint is None:
        if record.checkpoint_sha256 is not None:
            raise ValueError(f"checkpoint digest has no checkpoint: {record.model}")
    elif record.checkpoint_sha256 is None:
        raise ValueError(
            f"released checkpoint digest must be SHA-256 or UNKNOWN: {record.model}"
        )
    elif record.checkpoint_sha256 == UNKNOWN_DIGEST:
        if "CHECKPOINT_DIGEST_UNVERIFIED" not in record.reason:
            raise ValueError(f"unknown checkpoint digest is not disclosed: {record.model}")
    elif _SHA256.fullmatch(record.checkpoint_sha256) is None:
        raise ValueError(f"invalid checkpoint SHA-256: {record.model}")

    if record.execution_status is ExecutionStatus.CHECKPOINT_DIGEST_UNVERIFIED:
        if not (
            record.checkpoint is not None
            and record.checkpoint_sha256 == UNKNOWN_DIGEST
        ):
            raise ValueError(
                "CHECKPOINT_DIGEST_UNVERIFIED requires an identified checkpoint "
                "with UNKNOWN digest"
            )
    if record.execution_status is ExecutionStatus.NOT_RUN_NO_RELEASED_CHECKPOINT:
        if record.checkpoint is not None or record.checkpoint_sha256 is not None:
            raise ValueError(
                "NOT_RUN_NO_RELEASED_CHECKPOINT cannot carry a checkpoint or digest"
            )
    if (
        record.execution_status
        is ExecutionStatus.NOT_RUN_NO_OFFICIAL_REPRODUCIBLE_ARTIFACT
    ):
        if record.checkpoint is not None or record.checkpoint_sha256 is not None:
            raise ValueError(
                "NOT_RUN_NO_OFFICIAL_REPRODUCIBLE_ARTIFACT cannot carry a "
                "checkpoint or digest"
            )
    if record.execution_status is ExecutionStatus.CONDITION_PROTOCOL_MISMATCH:
        if (
            record.primary_track is not PrimaryTrack.TRACK_B
            or record.supports_formula_plus_sg
            or record.checkpoint is None
            or "CONDITION_PROTOCOL_MISMATCH" not in record.reason
        ):
            raise ValueError(
                "CONDITION_PROTOCOL_MISMATCH requires a Track B released path "
                "that does not support formula plus SG"
            )
    if record.execution_status is ExecutionStatus.EXTRA_TEMPLATE_CONDITION_REQUIRED:
        if not (
            record.primary_track is PrimaryTrack.TRACK_B
            and record.condition_level is ConditionLevel.PROPERTY_CONDITIONED
            and record.supports_target_space_group
            and not record.supports_formula_plus_sg
            and record.checkpoint is not None
            and "EXTRA_WYCKOFF_TEMPLATE_REQUIRED" in record.reason
        ):
            raise ValueError(
                "EXTRA_TEMPLATE_CONDITION_REQUIRED requires a Track B SG-aware "
                "path with a disclosed extra template"
            )

    if record.execution_status is ExecutionStatus.READY_OFFICIAL_ARTIFACT:
        if record.requires_retraining:
            raise ValueError(f"runnable path cannot require retraining: {record.model}")
        if not (
            record.official_repository
            and record.official_commit
            and record.checkpoint
            and record.checkpoint_sha256
            and _SHA256.fullmatch(record.checkpoint_sha256)
        ):
            raise ValueError(
                f"runnable path requires a verified official artifact: {record.model}"
            )

    if len(record.evidence_urls) != len(set(record.evidence_urls)):
        raise ValueError(f"duplicate evidence URL: {record.model}")
    if any(not url.startswith("https://") for url in record.evidence_urls):
        raise ValueError(f"evidence URLs must be HTTPS: {record.model}")
    if any(
        (
            record.supports_exact_formula,
            record.supports_target_space_group,
            record.supports_formula_plus_sg,
        )
    ):
        if not record.evidence_urls:
            raise ValueError(f"positive interface claim lacks primary evidence: {record.model}")
        if (
            record.official_repository is not None
            and record.official_repository not in record.evidence_urls
        ):
            raise ValueError(
                f"positive interface claim lacks official repository evidence: {record.model}"
            )


_CAPABILITIES = (
    BaselineCapability(
        model="CrystalFormer",
        official_repository="https://github.com/deepmodeling/CrystalFormer",
        official_commit="31bb734a3fd006af49a021921839061e6184cbf1",
        checkpoint="alex20s/csp/epoch_046000.pkl",
        checkpoint_sha256="df1e7051df836d26f45a93fd7f21069a183777317f318001b55f8df20805d177",
        training_dataset="Alex-20s",
        supports_exact_formula=True,
        supports_target_space_group=True,
        supports_formula_plus_sg=True,
        requires_retraining=False,
        condition_level=ConditionLevel.EXACT_FORMULA_PLUS_SG,
        primary_track=PrimaryTrack.TRACK_A,
        execution_status=ExecutionStatus.READY_OFFICIAL_ARTIFACT,
        reason="OFFICIAL_FORMULA_PLUS_EXPLICIT_SPACEGROUP",
        evidence_urls=(
            "https://github.com/deepmodeling/CrystalFormer",
            "https://huggingface.co/zdcao/CrystalFormer/blob/main/MODEL_CARD.md",
            "https://huggingface.co/zdcao/CrystalFormer/resolve/main/alex20s/csp/epoch_046000.pkl",
        ),
    ),
    BaselineCapability(
        model="MatterGen",
        official_repository="https://github.com/microsoft/mattergen",
        official_commit="67afb22ea0dd0073aedfc85b30b94bea0ee21863",
        checkpoint="space_group",
        checkpoint_sha256="1b6ab06739f4319d75f4a19960840ec3c8d3d32ee842c996876ef9d8b188e4bb",
        training_dataset="Alex-MP-20",
        supports_exact_formula=False,
        supports_target_space_group=True,
        supports_formula_plus_sg=False,
        requires_retraining=False,
        condition_level=ConditionLevel.SG_ONLY,
        primary_track=PrimaryTrack.TRACK_B,
        execution_status=ExecutionStatus.CONDITION_PROTOCOL_MISMATCH,
        reason=(
            "CONDITION_PROTOCOL_MISMATCH: released space_group path is SG-only; "
            "exact-formula CSP requires a separately trained model and no released "
            "formula-plus-SG checkpoint was found"
        ),
        evidence_urls=(
            "https://github.com/microsoft/mattergen",
            "https://huggingface.co/microsoft/mattergen",
        ),
    ),
    BaselineCapability(
        model="CrystalFlow",
        official_repository="https://github.com/ixsluo/CrystalFlow",
        official_commit="9c25ff0245d787efd87c9d1d797a8968443608cc",
        checkpoint="v1.0.0-alpha.1/CSP-mp-20/epoch=2462-step=261078.ckpt",
        checkpoint_sha256="b08366eb04d47698da7ea09dbccb1c4a1304a4c3f506fdc1d8c294910ade6dc2",
        training_dataset="MP-20",
        supports_exact_formula=True,
        supports_target_space_group=False,
        supports_formula_plus_sg=False,
        requires_retraining=False,
        condition_level=ConditionLevel.EXACT_FORMULA_ONLY,
        primary_track=PrimaryTrack.TRACK_B,
        execution_status=ExecutionStatus.READY_OFFICIAL_ARTIFACT,
        reason="FORMULA_MATCHED_BUT_SG_UNCONDITIONED",
        evidence_urls=(
            "https://github.com/ixsluo/CrystalFlow",
            "https://github.com/ixsluo/CrystalFlow/releases/tag/v1.0.0-alpha.1",
        ),
    ),
    BaselineCapability(
        model="DiffCSP",
        official_repository="https://github.com/jiaor17/DiffCSP",
        official_commit="7121d159826efa2ba9500bf299250d96da37f146",
        checkpoint="official Google Drive MP-20 CSP checkpoint:last.ckpt",
        checkpoint_sha256="c06719217c940718823f7c67b58c74a0fcfba4c3e4312b23cdd22b7a15ea6b5f",
        training_dataset="MP-20",
        supports_exact_formula=True,
        supports_target_space_group=False,
        supports_formula_plus_sg=False,
        requires_retraining=False,
        condition_level=ConditionLevel.EXACT_FORMULA_ONLY,
        primary_track=PrimaryTrack.TRACK_B,
        execution_status=ExecutionStatus.READY_OFFICIAL_ARTIFACT,
        reason="FORMULA_MATCHED_BUT_SG_UNCONDITIONED",
        evidence_urls=(
            "https://github.com/jiaor17/DiffCSP",
            "https://drive.google.com/drive/folders/11WOc9lTZN4hkIY7SKLCIrbsTMGy9TsoW?usp=sharing",
        ),
    ),
    BaselineCapability(
        model="DiffCSP++",
        official_repository="https://github.com/jiaor17/DiffCSP-PP",
        official_commit="e82e7ffa7cb2a383bde69b067a343ca137d73e47",
        checkpoint="official Google Drive pretrained checkpoint collection",
        checkpoint_sha256=UNKNOWN_DIGEST,
        training_dataset="MP-20",
        supports_exact_formula=True,
        supports_target_space_group=True,
        supports_formula_plus_sg=False,
        requires_retraining=False,
        condition_level=ConditionLevel.PROPERTY_CONDITIONED,
        primary_track=PrimaryTrack.TRACK_B,
        execution_status=ExecutionStatus.EXTRA_TEMPLATE_CONDITION_REQUIRED,
        reason=(
            "EXTRA_WYCKOFF_TEMPLATE_REQUIRED: the symmetry-aware sampler requires "
            "SG plus Wyckoff letters and atom types, not formula-plus-SG alone; "
            "CHECKPOINT_DIGEST_UNVERIFIED"
        ),
        evidence_urls=(
            "https://github.com/jiaor17/DiffCSP-PP",
            "https://drive.google.com/drive/folders/1FQ_b6CE09KtyGaU_r6uO8_I5JhrQmUFB?usp=sharing",
            "https://openreview.net/forum?id=jkvZ7v4OmP",
        ),
    ),
    BaselineCapability(
        model="WyFormer",
        official_repository="https://github.com/SymmetryAdvantage/WyckoffTransformer",
        official_commit="ea6ab30d44496567939e80104694b2c6506a5752",
        checkpoint="kazeevn/WyFormer-MP20",
        checkpoint_sha256=UNKNOWN_DIGEST,
        training_dataset="MP-20",
        supports_exact_formula=False,
        supports_target_space_group=False,
        supports_formula_plus_sg=False,
        requires_retraining=False,
        condition_level=ConditionLevel.CHEMICAL_SYSTEM_ONLY,
        primary_track=PrimaryTrack.TRACK_B,
        execution_status=ExecutionStatus.CONDITION_PROTOCOL_MISMATCH,
        reason=(
            "CONDITION_PROTOCOL_MISMATCH: released controls expose element sets and "
            "an SG distribution, not exact formula plus one explicit target SG; "
            "MP-20 checkpoint digest unverified (CHECKPOINT_DIGEST_UNVERIFIED)"
        ),
        evidence_urls=(
            "https://github.com/SymmetryAdvantage/WyckoffTransformer",
            "https://huggingface.co/kazeevn/WyFormer-MP20",
            "https://proceedings.mlr.press/v267/kazeev25a.html",
        ),
    ),
    BaselineCapability(
        model="WyckoffAUGen",
        official_repository=None,
        official_commit=None,
        checkpoint=None,
        checkpoint_sha256=None,
        training_dataset="MP-20",
        supports_exact_formula=False,
        supports_target_space_group=False,
        supports_formula_plus_sg=False,
        requires_retraining=True,
        condition_level=ConditionLevel.PROPERTY_CONDITIONED,
        primary_track=PrimaryTrack.RELATED_WORK_ONLY,
        execution_status=ExecutionStatus.NOT_RUN_NO_OFFICIAL_REPRODUCIBLE_ARTIFACT,
        reason=(
            "NOT_RUN_NO_OFFICIAL_REPRODUCIBLE_ARTIFACT: published composition-space "
            "constraints are not a verified formula-plus-SG runnable interface"
        ),
        evidence_urls=("https://openreview.net/forum?id=1ne8lalwRN",),
    ),
    BaselineCapability(
        model="DynaCrys",
        official_repository=None,
        official_commit=None,
        checkpoint=None,
        checkpoint_sha256=None,
        training_dataset="MP-20",
        supports_exact_formula=False,
        supports_target_space_group=False,
        supports_formula_plus_sg=False,
        requires_retraining=True,
        condition_level=ConditionLevel.UNCONDITIONAL,
        primary_track=PrimaryTrack.RELATED_WORK_ONLY,
        execution_status=ExecutionStatus.NOT_RUN_NO_OFFICIAL_REPRODUCIBLE_ARTIFACT,
        reason=(
            "NOT_RUN_NO_OFFICIAL_REPRODUCIBLE_ARTIFACT: unconditional MP-20 method "
            "with internally evolving SG and no released code or checkpoint found"
        ),
        evidence_urls=("https://arxiv.org/abs/2608.07401",),
    ),
    BaselineCapability(
        model="FlowMM",
        official_repository="https://github.com/facebookresearch/flowmm",
        official_commit=None,
        checkpoint=None,
        checkpoint_sha256=None,
        training_dataset="UNKNOWN",
        supports_exact_formula=False,
        supports_target_space_group=False,
        supports_formula_plus_sg=False,
        requires_retraining=True,
        condition_level=ConditionLevel.UNCONDITIONAL,
        primary_track=PrimaryTrack.TRACK_B,
        execution_status=ExecutionStatus.NOT_RUN_NO_RELEASED_CHECKPOINT,
        reason=(
            "NOT_RUN_NO_RELEASED_CHECKPOINT: official archived instructions require "
            "a user-supplied checkpoint path"
        ),
        evidence_urls=("https://github.com/facebookresearch/flowmm",),
    ),
)


def validate_capability_matrix(
    records: Iterable[BaselineCapability],
) -> tuple[BaselineCapability, ...]:
    frozen = tuple(records)
    seen_models: set[str] = set()
    seen_artifacts: set[tuple[str, str]] = set()
    for record in frozen:
        validate_capability(record)
        model_identity = record.model.casefold()
        if model_identity in seen_models:
            raise ValueError(f"duplicate model: {record.model}")
        seen_models.add(model_identity)
        if record.official_repository is not None and record.checkpoint is not None:
            artifact_identity = (record.official_repository, record.checkpoint)
            if artifact_identity in seen_artifacts:
                raise ValueError(
                    f"duplicate official artifact path: {record.official_repository} / "
                    f"{record.checkpoint}"
                )
            seen_artifacts.add(artifact_identity)
    return frozen


def official_capabilities() -> tuple[BaselineCapability, ...]:
    return validate_capability_matrix(_CAPABILITIES)


def capability_matrix_payload() -> dict[str, Any]:
    records = official_capabilities()
    return {
        "schema_version": SCHEMA_VERSION,
        "track_a_models": [
            record.model
            for record in records
            if record.primary_track is PrimaryTrack.TRACK_A
        ],
        "models": [record.to_dict() for record in records],
    }
