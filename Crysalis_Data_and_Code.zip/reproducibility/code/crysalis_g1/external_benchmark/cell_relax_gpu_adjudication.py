"""Same-device GPU adjudication of frozen GPU-OOM cell-relax failures."""

from __future__ import annotations

import argparse
import json
import math
import os
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import psutil
from pymatgen.core import Lattice, Structure

from crysalis_g1.external_benchmark.config import load_config
from crysalis_g1.external_benchmark.evaluation import (
    attempt_evaluation_id,
    attempt_to_eval_mlip_record,
)
from crysalis_g1.external_benchmark.failure_attribution import ATTRIBUTION_CLASSES
from crysalis_g1.external_benchmark.provenance import sha256_file


SCHEMA_VERSION = "g1-cell-relax-gpu-adjudication.1.0.0"
WORKER_INPUT_SCHEMA = "g1-cell-relax-gpu-adjudication-worker-input.1.0.0"
WORKER_OUTPUT_SCHEMA = "g1-cell-relax-gpu-adjudication-worker-output.1.0.0"
GPU_WATCHDOG_SECONDS = 1800.0
WORKER_RSS_LIMIT_BYTES = 48 * 1024**3
SYSTEM_FREE_MEMORY_FLOOR_BYTES = 8 * 1024**3
WATCHDOG_POLL_SECONDS = 1.0
ATOM_GRAPH_CUTOFF_ANGSTROM = 6.0
VOLUME_COLLAPSE_RATIO = 0.1
MINIMUM_DISTANCE_COLLAPSE_ANGSTROM = 0.1
NEIGHBOR_EDGE_GROWTH_RATIO = 10.0
LATTICE_CONDITION_COLLAPSE = 1.0e10


def _canonical_json(payload: object) -> str:
    return json.dumps(
        payload,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def _atomic_write_new(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(f"GPU adjudication refuses overwrite: {path}")
    temporary = path.with_suffix(path.suffix + ".tmp")
    if temporary.exists():
        raise FileExistsError(f"GPU adjudication temporary output exists: {temporary}")
    try:
        with temporary.open("x", encoding="utf-8", newline="\n") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise


def _atomic_json_new(path: Path, payload: object) -> None:
    _atomic_write_new(path, _canonical_json(payload) + "\n")


def _json_object(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def _finite_number(value: object) -> float | None:
    if type(value) not in {int, float}:
        return None
    result = float(value)
    return result if math.isfinite(result) else None


def _ratio(numerator: float | int | None, denominator: float | int | None) -> float | None:
    if numerator is None or denominator is None or denominator <= 0:
        return None
    result = float(numerator) / float(denominator)
    return result if math.isfinite(result) else None


def classify_gpu_result(
    *,
    gpu_status: str,
    trajectory: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Classify the original GPU OOM from a same-device diagnostic trajectory."""

    rows = tuple(trajectory)
    evidence: list[dict[str, Any]] = []
    if rows:
        initial = rows[0]
        initial_volume = _finite_number(initial.get("cell_volume_angstrom3"))
        initial_neighbors = _finite_number(initial.get("neighbor_edges"))
        for row in rows:
            step = row.get("step")
            volume = _finite_number(row.get("cell_volume_angstrom3"))
            minimum_distance = _finite_number(row.get("minimum_distance_angstrom"))
            neighbors = _finite_number(row.get("neighbor_edges"))
            condition = _finite_number(row.get("lattice_condition_number"))
            volume_ratio = _ratio(volume, initial_volume)
            neighbor_ratio = _ratio(neighbors, initial_neighbors)
            if row.get("finite_geometry") is False:
                evidence.append({"criterion": "NONFINITE_GEOMETRY", "step": step})
            if volume_ratio is not None and volume_ratio <= VOLUME_COLLAPSE_RATIO:
                evidence.append(
                    {
                        "criterion": "CELL_VOLUME_RATIO_LE_0_1",
                        "step": step,
                        "value": volume_ratio,
                    }
                )
            if (
                minimum_distance is not None
                and minimum_distance <= MINIMUM_DISTANCE_COLLAPSE_ANGSTROM
            ):
                evidence.append(
                    {
                        "criterion": "MINIMUM_DISTANCE_LE_0_1_ANGSTROM",
                        "step": step,
                        "value": minimum_distance,
                    }
                )
            if neighbor_ratio is not None and neighbor_ratio >= NEIGHBOR_EDGE_GROWTH_RATIO:
                evidence.append(
                    {
                        "criterion": "NEIGHBOR_EDGE_GROWTH_GE_10",
                        "step": step,
                        "value": neighbor_ratio,
                    }
                )
            if condition is not None and condition >= LATTICE_CONDITION_COLLAPSE:
                evidence.append(
                    {
                        "criterion": "LATTICE_CONDITION_GE_1E10",
                        "step": step,
                        "value": condition,
                    }
                )
    unique_evidence: list[dict[str, Any]] = []
    seen_criteria: set[str] = set()
    for row in evidence:
        criterion = str(row["criterion"])
        if criterion not in seen_criteria:
            seen_criteria.add(criterion)
            unique_evidence.append(row)
    if unique_evidence:
        failure_class = "PHYSICAL_COLLAPSE_CONFIRMED"
        counting_rule = (
            "physical_survival=false; original GPU CUDA OOM was the terminal technical symptom"
        )
    elif gpu_status == "GPU_FULLY_COMPLETED":
        failure_class = "RESOURCE_LIMITED_EVALUATION"
        counting_rule = (
            "original CUDA OOM is evaluator-resource censoring rather than deterministic "
            "structural collapse; use the completed same-device GPU result for derived "
            "physical-survival interpretation"
        )
    else:
        failure_class = "OOM_CAUSE_UNRESOLVED"
        counting_rule = "do not attribute to model or hardware; report separately"
    return {
        "final_failure_class": failure_class,
        "catastrophic_collapse_evidence": unique_evidence,
        "scientific_counting_rule": counting_rule,
    }


def build_gpu_adjudication_payload(
    rows: Sequence[Mapping[str, Any]],
    *,
    expected_sample_ids: Sequence[str],
) -> dict[str, Any]:
    frozen = [dict(row) for row in rows]
    expected = tuple(str(value) for value in expected_sample_ids)
    observed = tuple(str(row.get("sample_id")) for row in frozen)
    if observed != expected or len(expected) != len(set(expected)):
        raise ValueError("GPU adjudication sample identities drifted")
    class_counts = Counter(str(row.get("final_failure_class")) for row in frozen)
    if any(name not in ATTRIBUTION_CLASSES for name in class_counts):
        raise ValueError("GPU adjudication contains an invalid failure class")
    by_model: dict[str, dict[str, int]] = {}
    for model in sorted({str(row.get("model")) for row in frozen}):
        model_rows = [row for row in frozen if row.get("model") == model]
        model_counts = Counter(str(row.get("final_failure_class")) for row in model_rows)
        by_model[model] = {
            "total": len(model_rows),
            "gpu_fully_completed": sum(
                row.get("gpu_adjudication_status") == "GPU_FULLY_COMPLETED" for row in model_rows
            ),
            **{name: model_counts[name] for name in ATTRIBUTION_CLASSES},
        }
    return {
        "schema_version": SCHEMA_VERSION,
        "adjudication_role": "SAME_DEVICE_GPU_FAILURE_ATTRIBUTION_ONLY",
        "original_gpu_records_modified": False,
        "input_structure_changed": False,
        "scientific_protocol_changed": False,
        "device_consistency": {"original": "cuda", "adjudication": "cuda"},
        "frozen_protocol": {
            "model": "CHGNet",
            "model_version": "0.3.0",
            "package_version": "0.4.2",
            "optimizer": "FIRE",
            "maximum_steps": 300,
            "force_threshold_ev_per_angstrom": 0.2,
            "relax_cell": True,
            "short_contact_distance_angstrom": 0.5,
            "atom_graph_cutoff_angstrom": ATOM_GRAPH_CUTOFF_ANGSTROM,
        },
        "watchdog": {
            "per_sample_seconds": GPU_WATCHDOG_SECONDS,
            "worker_rss_limit_bytes": WORKER_RSS_LIMIT_BYTES,
            "system_free_memory_floor_bytes": SYSTEM_FREE_MEMORY_FLOOR_BYTES,
            "watchdog_changes_fire300_parameters": False,
        },
        "catastrophic_evidence_rules": {
            "cell_volume_ratio_lte": VOLUME_COLLAPSE_RATIO,
            "minimum_distance_angstrom_lte": MINIMUM_DISTANCE_COLLAPSE_ANGSTROM,
            "neighbor_edge_growth_ratio_gte": NEIGHBOR_EDGE_GROWTH_RATIO,
            "lattice_condition_number_gte": LATTICE_CONDITION_COLLAPSE,
            "nonfinite_geometry": True,
        },
        "summary": {
            "total_unresolved_before": len(frozen),
            "gpu_fully_completed": sum(
                row.get("gpu_adjudication_status") == "GPU_FULLY_COMPLETED" for row in frozen
            ),
            "by_final_failure_class": {name: class_counts[name] for name in ATTRIBUTION_CLASSES},
            "by_model": by_model,
        },
        "results": frozen,
        "retry_count": 0,
        "refill_count": 0,
    }


def validate_gpu_adjudication(payload: object, *, expected_count: int | None = None) -> None:
    if not isinstance(payload, Mapping):
        raise ValueError("GPU adjudication must be a JSON object")
    results = payload.get("results")
    summary = payload.get("summary")
    if (
        payload.get("schema_version") != SCHEMA_VERSION
        or payload.get("adjudication_role") != "SAME_DEVICE_GPU_FAILURE_ATTRIBUTION_ONLY"
        or payload.get("original_gpu_records_modified") is not False
        or payload.get("input_structure_changed") is not False
        or payload.get("scientific_protocol_changed") is not False
        or payload.get("device_consistency")
        != {"original": "cuda", "adjudication": "cuda"}
        or payload.get("retry_count") != 0
        or payload.get("refill_count") != 0
        or not isinstance(results, list)
        or not isinstance(summary, Mapping)
    ):
        raise ValueError("GPU adjudication contract drifted")
    if expected_count is not None and len(results) != expected_count:
        raise ValueError("GPU adjudication denominator drifted")
    identities = [str(row.get("sample_id")) for row in results if isinstance(row, Mapping)]
    if len(identities) != len(results) or len(identities) != len(set(identities)):
        raise ValueError("GPU adjudication identities drifted")
    for row in results:
        if (
            row.get("original_attribution_class") != "OOM_CAUSE_UNRESOLVED"
            or row.get("original_gpu_terminal_symptom") != "CUDA_OOM"
            or row.get("final_failure_class") not in ATTRIBUTION_CLASSES
            or not str(row.get("gpu_adjudication_status") or "")
            or not isinstance(row.get("trajectory"), list)
            or row.get("trajectory_step_count") != len(row["trajectory"])
            or not str(row.get("scientific_counting_rule") or "")
        ):
            raise ValueError("GPU adjudication result row drifted")
    recomputed = build_gpu_adjudication_payload(results, expected_sample_ids=identities)
    if summary != recomputed["summary"]:
        raise ValueError("GPU adjudication summary was not recomputed")


def apply_gpu_adjudication(
    initial_attribution: Mapping[str, Any],
    gpu_adjudication: Mapping[str, Any],
) -> dict[str, Any]:
    """Update only derived labels; retain every original GPU record verbatim."""

    updated = json.loads(json.dumps(initial_attribution, allow_nan=False))
    rows = updated.get("failures")
    gpu_rows = gpu_adjudication.get("results")
    if not isinstance(rows, list) or not isinstance(gpu_rows, list):
        raise ValueError("failure attribution or GPU adjudication rows are missing")
    unresolved = {
        str(row.get("sample_id")): row
        for row in rows
        if isinstance(row, Mapping) and row.get("failure_class") == "OOM_CAUSE_UNRESOLVED"
    }
    by_id = {str(row.get("sample_id")): row for row in gpu_rows if isinstance(row, Mapping)}
    if set(unresolved) != set(by_id):
        raise ValueError("GPU adjudication does not exactly cover unresolved failures")
    for sample_id, row in unresolved.items():
        gpu = by_id[sample_id]
        final_class = str(gpu.get("final_failure_class"))
        if final_class not in ATTRIBUTION_CLASSES:
            raise ValueError("GPU adjudication final class is invalid")
        row["pre_gpu_adjudication_failure_class"] = "OOM_CAUSE_UNRESOLVED"
        row["failure_class"] = final_class
        row["scientific_counting_rule"] = str(gpu.get("scientific_counting_rule"))
        row["gpu_adjudication_result"] = {
            "gpu_adjudication_status": gpu.get("gpu_adjudication_status"),
            "gpu_converged": gpu.get("gpu_converged"),
            "gpu_physical_survival": gpu.get("gpu_physical_survival"),
            "gpu_strict_symmetry_preserving_survival": gpu.get(
                "gpu_strict_symmetry_preserving_survival"
            ),
            "final_failure_class": final_class,
            "catastrophic_collapse_evidence": gpu.get("catastrophic_collapse_evidence"),
        }
        row["evidence"].append(
            {
                "source": "same_device_gpu_adjudication_frozen_protocol",
                **row["gpu_adjudication_result"],
            }
        )
    class_counts = Counter(str(row["failure_class"]) for row in rows)
    by_model: dict[str, dict[str, int]] = {}
    for model in sorted({str(row["model"]) for row in rows}):
        counts = Counter(str(row["failure_class"]) for row in rows if row["model"] == model)
        by_model[model] = {name: counts[name] for name in ATTRIBUTION_CLASSES}
    updated["summary"] = {
        "by_failure_class": {name: class_counts[name] for name in ATTRIBUTION_CLASSES},
        "by_model": by_model,
    }
    updated["gpu_adjudication_applied"] = True
    updated["gpu_adjudication_summary"] = gpu_adjudication.get("summary")
    return updated


def render_gpu_adjudication(payload: Mapping[str, Any]) -> str:
    summary = payload.get("summary")
    if not isinstance(summary, Mapping):
        raise ValueError("GPU adjudication summary is missing")
    counts = summary.get("by_final_failure_class")
    by_model = summary.get("by_model")
    if not isinstance(counts, Mapping) or not isinstance(by_model, Mapping):
        raise ValueError("GPU adjudication summary is malformed")
    lines = [
        "# Cell-relax Same-device GPU Adjudication",
        "",
        "The frozen 29 GPU-OOM structures were re-evaluated on the same GPU device for "
        "failure attribution only. Structures, CHGNet weights, FIRE300 settings, force "
        "threshold, neighbor settings, convergence, symmetry, and survival definitions "
        "were unchanged; only observation-only trajectory diagnostics were added.",
        "",
        f"Total unresolved before: {summary['total_unresolved_before']}",
        f"GPU fully completed: {summary['gpu_fully_completed']}",
        "",
        "| Final failure class | Count |",
        "|---|---:|",
    ]
    lines.extend(f"| {name} | {int(counts.get(name, 0))} |" for name in ATTRIBUTION_CLASSES)
    lines.extend(
        (
            "",
            "| Model | Total | GPU complete | Physical collapse | Resource limited | "
            "Still unresolved |",
            "|---|---:|---:|---:|---:|---:|",
        )
    )
    for model, row in sorted(by_model.items()):
        lines.append(
            f"| {model} | {row['total']} | {row['gpu_fully_completed']} | "
            f"{row['PHYSICAL_COLLAPSE_CONFIRMED']} | "
            f"{row['RESOURCE_LIMITED_EVALUATION']} | {row['OOM_CAUSE_UNRESOLVED']} |"
        )
    lines.append("")
    return "\n".join(lines)


def _trajectory_geometry(atoms: Any, *, step: int, forces: Any) -> dict[str, Any]:
    cell = np.asarray(atoms.get_cell(), dtype=float)
    positions = np.asarray(atoms.get_positions(), dtype=float)
    finite = bool(np.isfinite(cell).all() and np.isfinite(positions).all())
    volume = float(abs(np.linalg.det(cell))) if finite else None
    condition = float(np.linalg.cond(cell)) if finite else None
    maximum_force = None
    force_array = np.asarray(forces, dtype=float)
    if force_array.size and np.isfinite(force_array).all():
        maximum_force = float(np.linalg.norm(force_array, axis=-1).max())
    minimum_distance = None
    neighbor_edges = None
    diagnostic_error = None
    if finite and volume is not None and volume > 0:
        try:
            structure = Structure(
                Lattice(cell),
                [int(value) for value in atoms.get_atomic_numbers()],
                positions,
                coords_are_cartesian=True,
                to_unit_cell=True,
            )
            if len(structure) > 1:
                distances = np.asarray(structure.distance_matrix, dtype=float).copy()
                np.fill_diagonal(distances, np.inf)
                values = distances[np.isfinite(distances)]
                if values.size:
                    minimum_distance = float(values.min())
            neighbor_edges = int(len(structure.get_neighbor_list(ATOM_GRAPH_CUTOFF_ANGSTROM)[0]))
        except Exception as error:
            diagnostic_error = f"{type(error).__name__}: {error}"
    return {
        "step": step,
        "cell_volume_angstrom3": volume,
        "minimum_distance_angstrom": minimum_distance,
        "neighbor_edges": neighbor_edges,
        "max_force_ev_per_angstrom": maximum_force,
        "finite_geometry": finite,
        "lattice_condition_number": condition,
        "diagnostic_error": diagnostic_error,
    }


def _run_worker(input_path: Path, output_path: Path, trajectory_path: Path) -> int:
    payload = _json_object(input_path)
    if payload.get("schema_version") != WORKER_INPUT_SCHEMA:
        raise ValueError("GPU adjudication worker input schema drifted")
    evaluator_config = payload.get("evaluator_config")
    if not isinstance(evaluator_config, Mapping):
        raise ValueError("GPU adjudication evaluator config is missing")
    expected = {
        "package_version": "0.4.2",
        "model_version": "0.3.0",
        "optimizer": "FIRE",
        "force_threshold_ev_per_angstrom": 0.2,
        "maximum_steps": 300,
        "relax_cell": True,
        "short_contact_distance": 0.5,
        "device": "cuda",
    }
    if any(evaluator_config.get(name) != value for name, value in expected.items()):
        raise ValueError("GPU adjudication scientific protocol drifted")

    import chgnet.model.dynamics as dynamics

    from crysalis_g1.experiments.chgnet_terminal import (
        CHGNetEvaluationConfig,
        CHGNetTerminalEvaluator,
    )
    from crysalis_g1.full_crysalis.evaluation import _augment_symmetry

    original_observer = dynamics.TrajectoryObserver
    trajectory_path.parent.mkdir(parents=True, exist_ok=True)
    if trajectory_path.exists():
        raise FileExistsError("GPU trajectory output already exists")
    trajectory_stream = trajectory_path.open("x", encoding="utf-8", buffering=1)

    class AdjudicationObserver(original_observer):
        def __call__(self) -> None:
            super().__call__()
            try:
                diagnostic = _trajectory_geometry(
                    self.atoms,
                    step=len(self.forces) - 1,
                    forces=self.forces[-1],
                )
            except Exception as error:
                diagnostic = {
                    "step": len(self.forces) - 1,
                    "cell_volume_angstrom3": None,
                    "minimum_distance_angstrom": None,
                    "neighbor_edges": None,
                    "max_force_ev_per_angstrom": None,
                    "finite_geometry": False,
                    "lattice_condition_number": None,
                    "diagnostic_error": f"{type(error).__name__}: {error}",
                }
            trajectory_stream.write(_canonical_json(diagnostic) + "\n")
            trajectory_stream.flush()
            os.fsync(trajectory_stream.fileno())

    started = time.time()
    try:
        dynamics.TrajectoryObserver = AdjudicationObserver
        evaluator = CHGNetTerminalEvaluator(CHGNetEvaluationConfig(**dict(evaluator_config)))
        result = _augment_symmetry(evaluator._evaluate_record(dict(payload["generation_record"])))
        gpu_status = (
            "GPU_FULLY_COMPLETED" if result.get("status") == "EVALUATED" else "GPU_EVALUATOR_FAILED"
        )
        output = {
            "schema_version": WORKER_OUTPUT_SCHEMA,
            "sample_id": payload["sample_id"],
            "gpu_adjudication_status": gpu_status,
            "result": result,
            "wall_time_seconds": time.time() - started,
        }
        _atomic_json_new(output_path, output)
        return 0
    except Exception as error:
        output = {
            "schema_version": WORKER_OUTPUT_SCHEMA,
            "sample_id": payload["sample_id"],
            "gpu_adjudication_status": "GPU_PROCESS_EXCEPTION",
            "exception_type": type(error).__name__,
            "exception_message": str(error),
            "result": None,
            "wall_time_seconds": time.time() - started,
        }
        _atomic_json_new(output_path, output)
        return 1
    finally:
        dynamics.TrajectoryObserver = original_observer
        trajectory_stream.close()


def _process_tree_rss(process: psutil.Process) -> int:
    total = 0
    try:
        children = tuple(process.children(recursive=True))
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        children = ()
    for member in (process, *children):
        try:
            total += int(member.memory_info().rss)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return total


def _terminate_process_tree(process: psutil.Process) -> None:
    try:
        children = tuple(process.children(recursive=True))
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        children = ()
    members = (*children, process)
    for member in reversed(members):
        try:
            member.terminate()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    _, alive = psutil.wait_procs(members, timeout=10)
    for member in alive:
        try:
            member.kill()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass


def _read_trajectory(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]
    if any(not isinstance(row, dict) for row in rows):
        raise ValueError("GPU adjudication trajectory is malformed")
    return rows


def _run_sample(
    *,
    worker_input: Mapping[str, Any],
    sample_dir: Path,
) -> dict[str, Any]:
    sample_dir.mkdir(parents=True, exist_ok=False)
    input_path = sample_dir / "worker_input.json"
    output_path = sample_dir / "worker_output.json"
    trajectory_path = sample_dir / "trajectory.jsonl"
    stdout_path = sample_dir / "stdout.log"
    stderr_path = sample_dir / "stderr.log"
    receipt_path = sample_dir / "command_receipt.json"
    _atomic_json_new(input_path, worker_input)
    command = [
        sys.executable,
        "-m",
        "crysalis_g1.external_benchmark.cell_relax_gpu_adjudication",
        "--worker-input",
        str(input_path),
        "--worker-output",
        str(output_path),
        "--worker-trajectory",
        str(trajectory_path),
    ]
    started = time.time()
    watchdog_status = None
    peak_rss = 0
    with (
        stdout_path.open("x", encoding="utf-8") as stdout,
        stderr_path.open("x", encoding="utf-8") as stderr,
    ):
        process = subprocess.Popen(
            command,
            cwd=Path.cwd(),
            stdout=stdout,
            stderr=stderr,
            shell=False,
        )
        monitored = psutil.Process(process.pid)
        while process.poll() is None:
            elapsed = time.time() - started
            rss = _process_tree_rss(monitored)
            peak_rss = max(peak_rss, rss)
            if elapsed >= GPU_WATCHDOG_SECONDS:
                watchdog_status = "WATCHDOG_TIMEOUT"
            elif rss >= WORKER_RSS_LIMIT_BYTES:
                watchdog_status = "WATCHDOG_WORKER_MEMORY"
            elif psutil.virtual_memory().available <= SYSTEM_FREE_MEMORY_FLOOR_BYTES:
                watchdog_status = "WATCHDOG_SYSTEM_MEMORY_FLOOR"
            if watchdog_status is not None:
                _terminate_process_tree(monitored)
                process.wait()
                break
            time.sleep(WATCHDOG_POLL_SECONDS)
        exit_code = int(process.returncode)
    ended = time.time()
    worker_output = _json_object(output_path) if output_path.is_file() else None
    trajectory = _read_trajectory(trajectory_path)
    gpu_status = str(
        watchdog_status
        or (
            worker_output.get("gpu_adjudication_status")
            if isinstance(worker_output, Mapping)
            else "GPU_PROCESS_FAILED"
        )
    )
    classification = classify_gpu_result(
        gpu_status=gpu_status,
        trajectory=trajectory,
    )
    result = worker_output.get("result") if isinstance(worker_output, Mapping) else None
    result_record = dict(result) if isinstance(result, Mapping) else {}
    first_step = trajectory[0] if trajectory else {}
    last_step = trajectory[-1] if trajectory else {}
    initial_volume = _finite_number(first_step.get("cell_volume_angstrom3"))
    final_volume = _finite_number(last_step.get("cell_volume_angstrom3"))
    initial_neighbors = _finite_number(first_step.get("neighbor_edges"))
    final_neighbors = _finite_number(last_step.get("neighbor_edges"))
    hashes = {
        path.name: sha256_file(path)
        for path in (input_path, output_path, trajectory_path, stdout_path, stderr_path)
        if path.is_file()
    }
    receipt = {
        "schema_version": "g1-cell-relax-gpu-adjudication-command.1.0.0",
        "argv": command,
        "started_at_unix": started,
        "ended_at_unix": ended,
        "wall_time_seconds": ended - started,
        "exit_code": exit_code,
        "watchdog_status": watchdog_status,
        "peak_worker_tree_rss_bytes": peak_rss,
        "artifact_sha256": hashes,
        "retry_count": 0,
        "refill_count": 0,
    }
    _atomic_json_new(receipt_path, receipt)
    return {
        "gpu_adjudication_status": gpu_status,
        "gpu_exit_code": exit_code,
        "gpu_watchdog_status": watchdog_status,
        "gpu_wall_time_seconds": ended - started,
        "gpu_peak_worker_tree_rss_bytes": peak_rss,
        "trajectory_step_count": len(trajectory),
        "trajectory": trajectory,
        "initial_cell_volume": initial_volume,
        "final_cell_volume": final_volume,
        "cell_volume_ratio": _ratio(final_volume, initial_volume),
        "initial_neighbor_count": initial_neighbors,
        "final_neighbor_count": final_neighbors,
        "neighbor_growth_ratio": _ratio(final_neighbors, initial_neighbors),
        "initial_minimum_distance": first_step.get("minimum_distance_angstrom"),
        "final_minimum_distance": last_step.get("minimum_distance_angstrom"),
        "initial_max_force_ev_per_angstrom": first_step.get("max_force_ev_per_angstrom"),
        "final_max_force_ev_per_angstrom": last_step.get("max_force_ev_per_angstrom"),
        "finite_geometry_through_last_observation": all(
            row.get("finite_geometry") is True for row in trajectory
        ),
        "gpu_result": result,
        "gpu_converged": result_record.get("converged"),
        "gpu_physical_survival": result_record.get("post_relax_survival"),
        "gpu_strict_symmetry_preserving_survival": result_record.get(
            "strict_symmetry_preserving_survival"
        ),
        "gpu_post_relax_detected_space_groups": result_record.get(
            "post_relax_detected_space_groups"
        ),
        "gpu_final_force_ev_per_angstrom": result_record.get("post_max_force_ev_per_angstrom"),
        "command_receipt": receipt,
        **classification,
    }


def _build_parent_payload(config_path: Path, repo_root: Path, output_dir: Path) -> dict[str, Any]:
    from crysalis_g1.external_benchmark.formal_completion import _all_attempts

    config = load_config(config_path)
    attribution_path = (
        config.output_root / "engineering/stages/cell_relax_failure_attribution/"
        "CELL_RELAX_FAILURE_ATTRIBUTION.json"
    )
    attribution = _json_object(attribution_path)
    unresolved = [
        row
        for row in attribution.get("failures", ())
        if isinstance(row, Mapping) and row.get("failure_class") == "OOM_CAUSE_UNRESOLVED"
    ]
    if len(unresolved) != 29:
        raise ValueError(
            f"GPU adjudication requires exactly 29 unresolved samples, got {len(unresolved)}"
        )
    unresolved_ids = tuple(str(row["sample_id"]) for row in unresolved)
    if len(set(unresolved_ids)) != 29:
        raise ValueError("GPU adjudication unresolved identities are not unique")
    attempts = _all_attempts(config, repo_root)
    by_id = {attempt_evaluation_id(attempt): attempt for attempt in attempts}
    invocation_path = (
        config.output_root / "engineering/stages/common_chgnet/evalmlip/invocation_manifest.json"
    )
    invocation = _json_object(invocation_path)
    evaluator = invocation["evaluator_provenance"]["cell_relax"]
    if not isinstance(evaluator, Mapping) or evaluator.get("device") != "cuda":
        raise ValueError("frozen GPU cell-relax provenance is missing")
    gpu_evaluator = dict(evaluator)
    output_dir.mkdir(parents=True, exist_ok=False)
    progress_path = output_dir / "progress.log"
    results: list[dict[str, Any]] = []
    for index, attribution_row in enumerate(unresolved):
        sample_id = str(attribution_row["sample_id"])
        attempt = by_id.get(sample_id)
        if attempt is None:
            raise ValueError(f"GPU adjudication attempt is missing: {sample_id}")
        worker_input = {
            "schema_version": WORKER_INPUT_SCHEMA,
            "sample_id": sample_id,
            "model": attempt.model,
            "generation_record": attempt_to_eval_mlip_record(attempt),
            "evaluator_config": gpu_evaluator,
            "original_gpu_failure_record": attribution_row["original_failure_record"],
            "protocol_consistency": {
                "device": {"original": "cuda", "adjudication": "cuda"},
                "scientific_parameters_changed": False,
            },
        }
        sample_result = _run_sample(
            worker_input=worker_input,
            sample_dir=output_dir / f"sample_{index:02d}_{sample_id[-12:]}",
        )
        results.append(
            {
                "model": attempt.model,
                "condition_id": attempt.condition.condition_id,
                "sample_id": sample_id,
                "sample_index": attempt.sample_index,
                "original_gpu_status": attribution_row["original_failure_record"].get("status"),
                "original_gpu_error": attribution_row["original_failure_record"].get(
                    "exception_message"
                ),
                "original_gpu_terminal_symptom": "CUDA_OOM",
                "original_gpu_failure_record": attribution_row["original_failure_record"],
                "original_attribution_class": "OOM_CAUSE_UNRESOLVED",
                **sample_result,
            }
        )
        with progress_path.open("a", encoding="utf-8", buffering=1) as progress:
            progress.write(
                f"{index + 1}/29 {sample_id} {sample_result['gpu_adjudication_status']} "
                f"{sample_result['final_failure_class']}\n"
            )
            progress.flush()
            os.fsync(progress.fileno())
    payload = build_gpu_adjudication_payload(results, expected_sample_ids=unresolved_ids)
    payload["source_artifacts"] = {
        "initial_failure_attribution": {
            "path": attribution_path.relative_to(config.output_root).as_posix(),
            "sha256": sha256_file(attribution_path),
        },
        "common_invocation_manifest": {
            "path": invocation_path.relative_to(config.output_root).as_posix(),
            "sha256": sha256_file(invocation_path),
        },
        "config": {"path": str(config_path.resolve()), "sha256": sha256_file(config_path)},
    }
    return payload


def run_parent(config_path: Path, repo_root: Path, output_dir: Path) -> dict[str, Any]:
    payload = _build_parent_payload(config_path, repo_root, output_dir)
    json_path = output_dir / "CELL_RELAX_GPU_ADJUDICATION.json"
    markdown_path = output_dir / "CELL_RELAX_GPU_ADJUDICATION.md"
    _atomic_json_new(json_path, payload)
    _atomic_write_new(markdown_path, render_gpu_adjudication(payload))
    return payload


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Frozen cell-relax same-device GPU failure adjudication"
    )
    parser.add_argument("--config")
    parser.add_argument("--repo-root")
    parser.add_argument("--output-dir")
    parser.add_argument("--worker-input")
    parser.add_argument("--worker-output")
    parser.add_argument("--worker-trajectory")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    arguments = build_parser().parse_args(argv)
    if arguments.worker_input:
        if not arguments.worker_output or not arguments.worker_trajectory:
            raise ValueError("worker output and trajectory paths are required")
        return _run_worker(
            Path(arguments.worker_input).resolve(),
            Path(arguments.worker_output).resolve(),
            Path(arguments.worker_trajectory).resolve(),
        )
    if not arguments.config or not arguments.repo_root or not arguments.output_dir:
        raise ValueError("parent mode requires config, repo root, and output directory")
    payload = run_parent(
        Path(arguments.config).resolve(),
        Path(arguments.repo_root).resolve(),
        Path(arguments.output_dir).resolve(),
    )
    print(_canonical_json(payload["summary"]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
