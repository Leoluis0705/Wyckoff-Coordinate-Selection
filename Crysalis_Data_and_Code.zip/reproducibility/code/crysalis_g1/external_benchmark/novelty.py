from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any, Mapping, Sequence

from pymatgen.analysis.structure_matcher import StructureMatcher

from crysalis_g1.experiments.c0_symmetry_oracle import load_recovered_parents
from crysalis_g1.external_benchmark.config import ExternalBenchmarkConfig
from crysalis_g1.external_benchmark.evaluation import attempt_evaluation_id
from crysalis_g1.external_benchmark.provenance import (
    preflight_frozen_inputs,
    sha256_file,
)
from crysalis_g1.external_benchmark.records import (
    AttemptRecord,
    AttemptStatus,
    StructurePayload,
)


NOVELTY_SCHEMA = "g1-external-benchmark-novelty.1.0.0"
NORMALIZED_REFERENCE_SCHEMA = "g1-external-benchmark-normalized-reference-cohort.1.0.0"
NOVELTY_MATCHER_SETTINGS = {
    "primitive_cell": False,
    "scale": True,
    "attempt_supercell": False,
    "ltol": 0.2,
    "stol": 0.3,
    "angle_tol": 5.0,
}
_SHA256 = re.compile(r"[0-9a-f]{64}")
_FORBIDDEN_DATABASE_TOKENS = {"COD", "OQMD", "AFLOW", "ICSD"}


class ReferenceCohortKind(StrEnum):
    COMMON_PHASE2A_TRAIN_FIT_REFERENCE = "COMMON_PHASE2A_TRAIN_FIT_REFERENCE"
    OFFICIAL_BASELINE_TRAIN_SET = "OFFICIAL_BASELINE_TRAIN_SET"


def novelty_matcher_settings() -> dict[str, bool | float]:
    return dict(NOVELTY_MATCHER_SETTINGS)


def novelty_matcher() -> StructureMatcher:
    return StructureMatcher(**NOVELTY_MATCHER_SETTINGS)


def _reject_external_database_identifier(value: str) -> None:
    normalized = re.sub(r"[^A-Z0-9]+", "_", value.upper()).strip("_")
    tokens = set(normalized.split("_"))
    compact = normalized.replace("_", "")
    if tokens & _FORBIDDEN_DATABASE_TOKENS or "MPFULL" in compact:
        raise ValueError("external novelty database identifier is forbidden")


def _normalized_structures_digest(structures: Sequence[StructurePayload]) -> str:
    return hashlib.sha256(
        json.dumps(
            [structure.to_dict() for structure in structures],
            sort_keys=True,
            separators=(",", ":"),
        ).encode()
    ).hexdigest()


@dataclass(frozen=True, slots=True, init=False)
class HashedStructureCohort:
    cohort_id: str
    kind: ReferenceCohortKind
    artifact_path: Path
    artifact_sha256: str
    structures: tuple[StructurePayload, ...]
    normalized_structures_sha256: str
    source_artifacts: tuple[tuple[str, Path, str], ...]
    binding_method: str

    @classmethod
    def _from_verified_sources(
        cls,
        *,
        cohort_id: str,
        kind: ReferenceCohortKind | str,
        artifact_path: Path,
        artifact_sha256: str,
        structures: Sequence[StructurePayload],
        source_artifacts: Sequence[tuple[str, Path, str]],
        binding_method: str,
    ) -> HashedStructureCohort:
        try:
            normalized_kind = ReferenceCohortKind(kind)
        except (TypeError, ValueError):
            raise ValueError("invalid reference cohort kind") from None
        normalized_id = str(cohort_id).strip()
        if not normalized_id:
            raise ValueError("reference cohort ID must be non-empty")
        _reject_external_database_identifier(normalized_id)
        _reject_external_database_identifier(str(artifact_path))
        if (
            normalized_kind is ReferenceCohortKind.COMMON_PHASE2A_TRAIN_FIT_REFERENCE
            and normalized_id != "PHASE2A_TRAIN_FIT_REFERENCE"
        ):
            raise ValueError("common novelty cohort must be the frozen Phase2A reference")
        normalized_sources = tuple(
            (str(name), Path(path), str(digest).lower()) for name, path, digest in source_artifacts
        )
        if not normalized_sources or len({item[0] for item in normalized_sources}) != len(
            normalized_sources
        ):
            raise ValueError("reference cohort source artifacts are missing or duplicate")
        for name, path, digest in normalized_sources:
            _reject_external_database_identifier(str(path))
            if _SHA256.fullmatch(digest) is None:
                raise ValueError(f"invalid reference cohort SHA-256: {name}")
            if not path.is_file():
                raise FileNotFoundError(f"reference cohort artifact is missing: {path}")
            observed = sha256_file(path)
            if observed != digest:
                raise ValueError(
                    f"reference cohort hash mismatch: {name}: expected {digest}, observed {observed}"
                )
        path = Path(artifact_path)
        digest = str(artifact_sha256).lower()
        if _SHA256.fullmatch(digest) is None:
            raise ValueError("invalid reference cohort SHA-256")
        if not any(
            source_path.resolve() == path.resolve() and source_digest == digest
            for _, source_path, source_digest in normalized_sources
        ):
            raise ValueError("primary reference artifact is not source-bound")
        normalized_structures = tuple(structures)
        if not normalized_structures or any(
            not isinstance(structure, StructurePayload) for structure in normalized_structures
        ):
            raise ValueError("reference cohort must contain normalized structures")
        if not str(binding_method).strip():
            raise ValueError("reference cohort binding method is missing")
        instance = object.__new__(cls)
        object.__setattr__(instance, "cohort_id", normalized_id)
        object.__setattr__(instance, "kind", normalized_kind)
        object.__setattr__(instance, "artifact_path", path)
        object.__setattr__(instance, "artifact_sha256", digest)
        object.__setattr__(instance, "structures", normalized_structures)
        object.__setattr__(
            instance,
            "normalized_structures_sha256",
            _normalized_structures_digest(normalized_structures),
        )
        object.__setattr__(instance, "source_artifacts", normalized_sources)
        object.__setattr__(instance, "binding_method", str(binding_method))
        return instance

    @classmethod
    def from_normalized_json_artifact(
        cls,
        artifact_path: str | Path,
        *,
        expected_sha256: str,
    ) -> HashedStructureCohort:
        path = Path(artifact_path)
        digest = str(expected_sha256).lower()
        if _SHA256.fullmatch(digest) is None:
            raise ValueError("invalid reference cohort SHA-256")
        if not path.is_file():
            raise FileNotFoundError(f"reference cohort artifact is missing: {path}")
        observed = sha256_file(path)
        if observed != digest:
            raise ValueError(
                f"reference cohort hash mismatch: expected {digest}, observed {observed}"
            )
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise ValueError("normalized reference artifact is invalid JSON") from error
        expected_keys = {"schema_version", "cohort_id", "kind", "structures"}
        if not isinstance(payload, Mapping) or set(payload) != expected_keys:
            raise ValueError("normalized reference artifact schema drifted")
        if payload["schema_version"] != NORMALIZED_REFERENCE_SCHEMA:
            raise ValueError("normalized reference artifact schema drifted")
        if payload["kind"] == ReferenceCohortKind.COMMON_PHASE2A_TRAIN_FIT_REFERENCE.value:
            raise ValueError("common novelty cohort must be built by the frozen Phase2A loader")
        raw_structures = payload["structures"]
        if not isinstance(raw_structures, list):
            raise ValueError("normalized reference artifact structures are missing")
        structures = tuple(StructurePayload.from_dict(item) for item in raw_structures)
        return cls._from_verified_sources(
            cohort_id=str(payload["cohort_id"]),
            kind=str(payload["kind"]),
            artifact_path=path,
            artifact_sha256=digest,
            structures=structures,
            source_artifacts=(("normalized_reference", path, digest),),
            binding_method="NORMALIZED_JSON_ARTIFACT",
        )

    @property
    def source_artifact_sha256(self) -> dict[str, str]:
        return {name: digest for name, _, digest in self.source_artifacts}

    @property
    def source_artifact_paths(self) -> dict[str, str]:
        return {name: str(path.resolve()) for name, path, _ in self.source_artifacts}

    def verify_source_hashes(self) -> None:
        for name, path, expected in self.source_artifacts:
            observed = sha256_file(path)
            if observed != expected:
                raise ValueError(
                    f"reference cohort hash mismatch: {name}: expected {expected}, observed {observed}"
                )


def load_frozen_phase2a_train_fit_cohort(
    config: ExternalBenchmarkConfig,
    *,
    repo_root: str | Path,
) -> HashedStructureCohort:
    preflight_frozen_inputs(config, repo_root)
    base_path = (
        config.base_config_path
        if config.base_config_path.is_absolute()
        else Path(repo_root).resolve() / config.base_config_path
    )
    base = json.loads(base_path.read_text(encoding="utf-8"))
    artifacts = base.get("artifacts") if isinstance(base, Mapping) else None
    required = ("phase2a_manifest", "structure_ood_manifest", "recovered_parents")
    if not isinstance(artifacts, Mapping):
        raise ValueError("frozen Phase2A artifact declarations are missing")
    sources: list[tuple[str, Path, str]] = []
    paths: dict[str, Path] = {}
    for name in required:
        declaration = artifacts.get(name)
        expected = config.frozen_artifact_sha256.get(name)
        if not isinstance(declaration, Mapping) or expected is None:
            raise ValueError(f"frozen Phase2A artifact declaration is missing: {name}")
        path = Path(str(declaration.get("path", "")))
        if str(declaration.get("sha256", "")).lower() != expected:
            raise ValueError(f"frozen Phase2A artifact declaration drifted: {name}")
        if sha256_file(path) != expected:
            raise ValueError(f"frozen Phase2A artifact hash mismatch: {name}")
        paths[name] = path
        sources.append((name, path, expected))

    train_ids: set[str] = set()
    with paths["structure_ood_manifest"].open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            try:
                row = json.loads(line)
            except json.JSONDecodeError as error:
                raise ValueError(f"invalid frozen split manifest row {line_number}") from error
            if not isinstance(row, Mapping):
                raise ValueError(f"invalid frozen split manifest row {line_number}")
            if row.get("split") == "train_fit":
                train_ids.add(str(row.get("material_id", "")))
    if not train_ids or "" in train_ids:
        raise ValueError("frozen Phase2A train_fit split is empty or malformed")
    parents = load_recovered_parents(paths["recovered_parents"])
    missing = train_ids - set(parents)
    if missing:
        raise ValueError("frozen Phase2A train_fit parent mapping is incomplete")
    structures = tuple(
        StructurePayload(
            lattice=tuple(
                tuple(float(value) for value in row)
                for row in parents[material_id].lattice.primitive_matrix
            ),
            atomic_numbers=tuple(
                int(value) for value in parents[material_id].reconstructed_atomic_numbers
            ),
            fractional_coordinates=tuple(
                tuple(float(value) for value in row)
                for row in parents[material_id].reconstructed_fractional_coordinates
            ),
        )
        for material_id in sorted(train_ids)
    )
    return HashedStructureCohort._from_verified_sources(
        cohort_id="PHASE2A_TRAIN_FIT_REFERENCE",
        kind=ReferenceCohortKind.COMMON_PHASE2A_TRAIN_FIT_REFERENCE,
        artifact_path=paths["recovered_parents"],
        artifact_sha256=config.frozen_artifact_sha256["recovered_parents"],
        structures=structures,
        source_artifacts=sources,
        binding_method="FROZEN_PHASE2A_TRAIN_FIT_ARTIFACTS",
    )


def _aligned_common(
    attempts: Sequence[AttemptRecord],
    common_records: Sequence[Mapping[str, Any]],
) -> tuple[tuple[AttemptRecord, ...], tuple[Mapping[str, Any], ...]]:
    attempts = tuple(attempts)
    common = tuple(common_records)
    if len(attempts) != len(common):
        raise ValueError("attempt and common-evaluation denominators differ")
    expected = [attempt_evaluation_id(attempt) for attempt in attempts]
    observed = [str(record.get("evaluation_id")) for record in common]
    if expected != observed:
        raise ValueError("attempt and common-evaluation identities differ")
    return attempts, common


def cluster_unique_structures(
    attempts: Sequence[AttemptRecord],
    common_records: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    attempts, common = _aligned_common(attempts, common_records)
    matcher = novelty_matcher()
    representatives: list[tuple[str, Any]] = []
    clusters: list[dict[str, Any]] = []
    eligible_count = 0
    for attempt, common_record in zip(attempts, common, strict=True):
        if not (
            attempt.status is AttemptStatus.GENERATED
            and common_record.get("parse_valid") is True
            and common_record.get("common_legal_crystal") is True
            and attempt.structure is not None
        ):
            continue
        eligible_count += 1
        evaluation_id = attempt_evaluation_id(attempt)
        candidate = attempt.structure.to_pymatgen()
        matched_cluster: int | None = None
        for index, (_, representative) in enumerate(representatives):
            try:
                matched = bool(matcher.fit(candidate, representative))
            except Exception as error:
                raise RuntimeError(
                    "StructureMatcher failed during deterministic uniqueness clustering"
                ) from error
            if matched:
                matched_cluster = index
                break
        if matched_cluster is None:
            representatives.append((evaluation_id, candidate))
            clusters.append(
                {
                    "cluster_index": len(clusters),
                    "representative_evaluation_id": evaluation_id,
                    "member_evaluation_ids": [evaluation_id],
                }
            )
        else:
            clusters[matched_cluster]["member_evaluation_ids"].append(evaluation_id)
    unique_count = len(representatives)
    return {
        "schema_version": "g1-external-benchmark-uniqueness.1.0.0",
        "matcher": novelty_matcher_settings(),
        "eligibility_definition": "GENERATED_AND_COMMON_LEGAL",
        "representative_selection": "FIRST_IN_REGISTERED_ORDER",
        "denominator": eligible_count,
        "unique_numerator": unique_count,
        "unique_rate": unique_count / eligible_count if eligible_count else None,
        "unavailable_reason": None if eligible_count else "NO_ELIGIBLE_STRUCTURES",
        "representative_evaluation_ids": [item[0] for item in representatives],
        "clusters": clusters,
    }


def evaluate_novelty(
    attempts: Sequence[AttemptRecord],
    uniqueness: Mapping[str, Any],
    reference_cohort: HashedStructureCohort | None,
) -> dict[str, Any]:
    if reference_cohort is None:
        return {
            "schema_version": NOVELTY_SCHEMA,
            "status": "NOT_RUN_REFERENCE_UNAVAILABLE",
            "reference_cohort": None,
            "reference_artifact_sha256": None,
            "denominator": None,
            "novel_numerator": None,
            "novelty_rate": None,
            "representatives": [],
            "external_database_queried": False,
        }
    if not isinstance(reference_cohort, HashedStructureCohort):
        raise TypeError("novelty reference must be a HashedStructureCohort")
    if reference_cohort.kind is ReferenceCohortKind.COMMON_PHASE2A_TRAIN_FIT_REFERENCE:
        if reference_cohort.binding_method != "FROZEN_PHASE2A_TRAIN_FIT_ARTIFACTS" or set(
            reference_cohort.source_artifact_sha256
        ) != {"phase2a_manifest", "structure_ood_manifest", "recovered_parents"}:
            raise ValueError("common novelty cohort was not built by the frozen Phase2A loader")
    reference_cohort.verify_source_hashes()
    by_identity = {attempt_evaluation_id(attempt): attempt for attempt in attempts}
    if len(by_identity) != len(attempts):
        raise ValueError("novelty attempts contain duplicate identities")
    representative_ids = list(uniqueness.get("representative_evaluation_ids", ()))
    if any(identity not in by_identity for identity in representative_ids):
        raise ValueError("uniqueness representatives are missing from attempts")
    references = [structure.to_pymatgen() for structure in reference_cohort.structures]
    matcher = novelty_matcher()
    rows: list[dict[str, Any]] = []
    novel_count = 0
    for identity in representative_ids:
        attempt = by_identity[identity]
        if attempt.structure is None:
            raise ValueError("unique representative has no structure")
        candidate = attempt.structure.to_pymatgen()
        matched_reference_index: int | None = None
        for index, reference in enumerate(references):
            try:
                matched = bool(matcher.fit(candidate, reference))
            except Exception as error:
                raise RuntimeError(
                    "StructureMatcher failed during hash-bound novelty evaluation"
                ) from error
            if matched:
                matched_reference_index = index
                break
        novel = matched_reference_index is None
        novel_count += int(novel)
        rows.append(
            {
                "evaluation_id": identity,
                "novel": novel,
                "matched_reference_index": matched_reference_index,
            }
        )
    denominator = len(rows)
    return {
        "schema_version": NOVELTY_SCHEMA,
        "status": "COMPLETED",
        "reference_cohort": reference_cohort.cohort_id,
        "reference_cohort_kind": reference_cohort.kind.value,
        "reference_artifact_path": str(reference_cohort.artifact_path.resolve()),
        "reference_artifact_sha256": reference_cohort.artifact_sha256,
        "reference_source_artifact_paths": reference_cohort.source_artifact_paths,
        "reference_source_artifact_sha256": reference_cohort.source_artifact_sha256,
        "reference_binding_method": reference_cohort.binding_method,
        "normalized_reference_structures_sha256": (reference_cohort.normalized_structures_sha256),
        "reference_structure_count": len(reference_cohort.structures),
        "matcher": novelty_matcher_settings(),
        "denominator": denominator,
        "novel_numerator": novel_count,
        "novelty_rate": novel_count / denominator if denominator else None,
        "representatives": rows,
        "external_database_queried": False,
    }


def select_crysalis_candidates(
    attempts: Sequence[AttemptRecord],
    common_records: Sequence[Mapping[str, Any]],
    uniqueness: Mapping[str, Any],
    fixed_cell_records: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    raw_attempts = tuple(attempts)
    if not raw_attempts or any(attempt.model != "FULL_CRYSALIS" for attempt in raw_attempts):
        raise ValueError("candidate export is restricted to FULL_CRYSALIS")
    attempts, common = _aligned_common(raw_attempts, common_records)
    fixed = tuple(fixed_cell_records)
    expected = [attempt_evaluation_id(attempt) for attempt in attempts]
    observed = [str(record.get("condition_id")) for record in fixed]
    if observed != expected:
        raise ValueError("candidate fixed-cell evaluation identities differ")
    representative_ids = set(
        str(value) for value in uniqueness.get("representative_evaluation_ids", ())
    )
    if not representative_ids.issubset(set(expected)):
        raise ValueError("candidate uniqueness representatives are foreign")

    candidates: list[dict[str, Any]] = []
    for attempt, common_record, fixed_record in zip(attempts, common, fixed, strict=True):
        identity = attempt_evaluation_id(attempt)
        eligibility = {
            "strict_0_03_space_group_match": (
                common_record.get("strict_0_03_space_group_match") is True
            ),
            "unique_representative": identity in representative_ids,
            "fixed_cell_fire300_physical_survival": (
                fixed_record.get("post_relax_survival") is True
            ),
        }
        if all(eligibility.values()):
            if attempt.structure is None:
                raise ValueError("eligible Crysalis candidate has no structure")
            candidates.append(
                {
                    "evaluation_id": identity,
                    "structure": attempt.structure.to_dict(),
                    "condition": attempt.condition.to_dict(),
                    "sample_index": attempt.sample_index,
                    "registered_seed": attempt.registered_seed,
                    "training_seed": attempt.training_seed,
                    "provenance": attempt.provenance.to_dict(),
                    "eligibility": eligibility,
                }
            )
    return {
        "schema_version": "g1-external-benchmark-candidate-selection.1.0.0",
        "model": "FULL_CRYSALIS",
        "candidate_count": len(candidates),
        "chgnet_criterion": "FIXED_CELL_FIRE300_PHYSICAL_SURVIVAL",
        "requires_strict_0_03_space_group_match": True,
        "requires_unique_representative": True,
        "final_zip_written": False,
        "candidates": candidates,
    }
