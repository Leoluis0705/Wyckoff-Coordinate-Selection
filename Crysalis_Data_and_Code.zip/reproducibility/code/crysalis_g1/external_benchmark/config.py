from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping


SCHEMA_VERSION = "g1-full-crysalis-external-benchmark.1.0.0"
REFERENCE_COMMIT = "9eb2da822bf7f60e931dfe2d6e5376272c1f07af"
TRAINING_SEEDS = (20260823, 20260824, 20260825)
PARENT_FREE_FLAGS = (
    "material_id_lookup_present",
    "parent_coordinates_present",
    "parent_lattice_present",
    "true_orbit_count_present",
    "true_termination_step_present",
    "true_wyckoff_sequence_present",
)
FORBIDDEN_AUTHORIZATIONS = (
    "ablation",
    "contribution_lock",
    "tuning",
    "dft",
    "server",
    "retry",
    "refill",
)
_SHA256 = re.compile(r"[0-9a-f]{64}")


def _require_keys(value: Mapping[str, Any], expected: set[str], *, label: str) -> None:
    observed = set(value)
    if observed != expected:
        raise ValueError(f"{label} keys drifted: expected {sorted(expected)}, observed {sorted(observed)}")


def _hash(value: Any, *, label: str) -> str:
    digest = str(value).lower()
    if _SHA256.fullmatch(digest) is None:
        raise ValueError(f"invalid SHA-256 for {label}")
    return digest


def _hash_map(value: Any, *, label: str) -> dict[str, str]:
    if not isinstance(value, Mapping) or not value:
        raise ValueError(f"{label} must be a non-empty map")
    return {str(name): _hash(digest, label=f"{label}/{name}") for name, digest in value.items()}


def _integer(value: Any, *, label: str) -> int:
    if type(value) is not int:
        raise ValueError(f"{label} must be an integer")
    return value


@dataclass(frozen=True, slots=True)
class ExternalBenchmarkConfig:
    config_path: Path
    reference_commit: str
    replication_root: Path
    positive_run_root: Path
    output_root: Path
    official_artifact_cache: Path
    base_config_path: Path
    base_config_sha256: str
    formal_attempt_count: int
    training_seeds: tuple[int, ...]
    condition_count: int
    condition_manifest_path: Path
    condition_manifest_sha256: str
    condition_input: Mapping[str, bool]
    frozen_artifact_sha256: Mapping[str, str]
    frozen_core_sha256: Mapping[str, str]
    authorization: Mapping[str, bool]

    def __post_init__(self) -> None:
        if self.reference_commit != REFERENCE_COMMIT:
            raise ValueError("reference commit drifted")
        if self.formal_attempt_count != 900:
            raise ValueError("formal attempt count must remain 900")
        if self.training_seeds != TRAINING_SEEDS:
            raise ValueError("training seed identities drifted")
        if self.condition_count != 300:
            raise ValueError("condition count must remain 300")
        if self.formal_attempt_count != self.condition_count * len(self.training_seeds):
            raise ValueError("formal attempts must equal condition count times seed count")
        _require_keys(self.condition_input, set(PARENT_FREE_FLAGS), label="condition input")
        if any(value is not False for value in self.condition_input.values()):
            raise ValueError("condition input must remain parent-free")
        if self.authorization.get("full_model_frozen") is not True:
            raise ValueError("full model must remain frozen")
        if self.authorization.get("external_benchmark_only") is not True:
            raise ValueError("external benchmark boundary must remain enabled")
        for name in FORBIDDEN_AUTHORIZATIONS:
            if self.authorization.get(name) is not False:
                raise ValueError(f"{name} must remain forbidden")


def load_config(path: str | Path) -> ExternalBenchmarkConfig:
    config_path = Path(path)
    payload = json.loads(config_path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError("external benchmark config must be an object")
    _require_keys(
        payload,
        {
            "schema_version", "reference_commit", "replication_root", "positive_run_root",
            "output_root", "official_artifact_cache", "base_config", "formal_attempt_count",
            "training_seeds", "condition_count", "condition_manifest", "condition_input",
            "frozen_artifact_sha256", "frozen_core_sha256", "authorization",
        },
        label="external benchmark config",
    )
    if payload["schema_version"] != SCHEMA_VERSION:
        raise ValueError("unsupported external benchmark config schema")
    base = payload["base_config"]
    condition = payload["condition_manifest"]
    if not isinstance(base, Mapping) or not isinstance(condition, Mapping):
        raise ValueError("base config and condition manifest declarations must be objects")
    _require_keys(base, {"path", "sha256"}, label="base config")
    _require_keys(condition, {"path", "sha256"}, label="condition manifest")
    authorization = payload["authorization"]
    if not isinstance(authorization, Mapping):
        raise ValueError("authorization must be an object")
    expected_authorization = {"full_model_frozen", "external_benchmark_only", *FORBIDDEN_AUTHORIZATIONS}
    _require_keys(authorization, expected_authorization, label="authorization")
    if any(type(value) is not bool for value in authorization.values()):
        raise ValueError("authorization values must be booleans")
    condition_input = payload["condition_input"]
    if not isinstance(condition_input, Mapping) or any(type(value) is not bool for value in condition_input.values()):
        raise ValueError("condition input flags must be booleans")
    return ExternalBenchmarkConfig(
        config_path=config_path,
        reference_commit=str(payload["reference_commit"]),
        replication_root=Path(payload["replication_root"]),
        positive_run_root=Path(payload["positive_run_root"]),
        output_root=Path(payload["output_root"]),
        official_artifact_cache=Path(payload["official_artifact_cache"]),
        base_config_path=Path(base["path"]),
        base_config_sha256=_hash(base["sha256"], label="base config"),
        formal_attempt_count=_integer(
            payload["formal_attempt_count"], label="formal_attempt_count"
        ),
        training_seeds=tuple(
            _integer(seed, label="training seeds")
            for seed in payload["training_seeds"]
        ),
        condition_count=_integer(payload["condition_count"], label="condition_count"),
        condition_manifest_path=Path(condition["path"]),
        condition_manifest_sha256=_hash(condition["sha256"], label="condition manifest"),
        condition_input={str(name): value for name, value in condition_input.items()},
        frozen_artifact_sha256=_hash_map(payload["frozen_artifact_sha256"], label="frozen artifact"),
        frozen_core_sha256=_hash_map(payload["frozen_core_sha256"], label="frozen core"),
        authorization={str(name): value for name, value in authorization.items()},
    )
