from __future__ import annotations

import hashlib
import json
import math
from dataclasses import replace
from pathlib import Path
from statistics import fmean
from typing import Any, Mapping, Sequence

from pymatgen.analysis.structure_matcher import StructureMatcher
from pymatgen.core import Lattice, Structure

from crysalis_g1.experiments.c0_symmetry_evaluation import (
    ConditionSource,
    build_parent_free_conditions,
    load_validation_condition_sources,
)
from crysalis_g1.experiments.c0_symmetry_oracle import load_recovered_parents
from crysalis_g1.external_benchmark.config import ExternalBenchmarkConfig
from crysalis_g1.external_benchmark.provenance import sha256_file
from crysalis_g1.external_benchmark.records import (
    AttemptRecord,
    AttemptStatus,
    REGISTERED_ROOT_SEED,
    RegisteredCondition,
    load_registered_conditions,
    validate_formal_attempts,
)


CSP_MATCHER_SETTINGS = {"ltol": 0.3, "stol": 0.5, "angle_tol": 10.0}
_REFERENCE_ARTIFACTS = (
    "phase2a_manifest",
    "structure_ood_manifest",
    "recovered_parents",
    "condition_manifest",
)


def matcher_settings() -> dict[str, float]:
    return dict(CSP_MATCHER_SETTINGS)


def csp_matcher() -> StructureMatcher:
    return StructureMatcher(**CSP_MATCHER_SETTINGS)


def match_structures(candidate: Structure, reference: Structure) -> dict[str, Any]:
    matcher = csp_matcher()
    try:
        matched = bool(matcher.fit(candidate, reference))
        if not matched:
            return {
                "matched": False,
                "normalized_rms_distance": None,
                "failure": None,
            }
        distances = matcher.get_rms_dist(candidate, reference)
        if distances is None:
            raise ValueError("StructureMatcher returned no RMS distance for a match")
        rms = float(distances[0])
        if not math.isfinite(rms):
            raise ValueError("StructureMatcher returned nonfinite RMS distance")
        if abs(rms) < 1e-15:
            rms = 0.0
        return {
            "matched": True,
            "normalized_rms_distance": rms,
            "failure": None,
        }
    except Exception as error:
        return {
            "matched": False,
            "normalized_rms_distance": None,
            "failure": f"{type(error).__name__}: {error}",
        }


def _canonical_public(condition: RegisteredCondition | Mapping[str, Any]) -> bytes:
    payload = condition.to_dict() if isinstance(condition, RegisteredCondition) else condition
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()


def _ordered_sources(
    sources: Sequence[ConditionSource], root_seed: int
) -> tuple[ConditionSource, ...]:
    return tuple(
        sorted(
            sources,
            key=lambda source: hashlib.sha256(
                f"condition-order:{root_seed}:{source.canonical_structure_hash}".encode()
            ).hexdigest(),
        )
    )


def map_evaluator_references(
    conditions: Sequence[RegisteredCondition],
    sources: Sequence[ConditionSource],
    reference_structures_by_material_id: Mapping[str, Structure],
    *,
    root_seed: int,
) -> dict[str, Structure]:
    if not conditions:
        raise ValueError("evaluator reference conditions must not be empty")
    replayed = build_parent_free_conditions(sources, count=len(conditions), root_seed=root_seed)
    if len(replayed) != len(conditions) or any(
        _canonical_public(observed) != _canonical_public(expected)
        for observed, expected in zip(replayed, conditions, strict=True)
    ):
        raise ValueError("public condition identity/order drift blocks reference mapping")
    ordered = _ordered_sources(sources, root_seed)
    mapped: dict[str, Structure] = {}
    for index, condition in enumerate(conditions):
        source = ordered[index % len(ordered)]
        reference = reference_structures_by_material_id.get(source.material_id)
        if reference is None:
            raise ValueError(
                f"reference mapping drift: recovered parent missing for {condition.condition_id}"
            )
        mapped[condition.condition_id] = reference
    return mapped


def _parent_structure(parent: Any) -> Structure:
    return Structure(
        Lattice(parent.lattice.primitive_matrix),
        parent.reconstructed_atomic_numbers,
        parent.reconstructed_fractional_coordinates,
        to_unit_cell=True,
    )


def _base_config_path(config: ExternalBenchmarkConfig) -> Path:
    path = config.base_config_path
    if path.is_absolute():
        return path
    repository_root = config.config_path.resolve().parent.parent
    return repository_root / path


def _frozen_reference_artifacts(
    config: ExternalBenchmarkConfig,
) -> dict[str, Path]:
    base_path = _base_config_path(config)
    if not base_path.is_file():
        raise FileNotFoundError(f"frozen base config is missing: {base_path}")
    if sha256_file(base_path) != config.base_config_sha256:
        raise ValueError("frozen base config hash mismatch")
    base = json.loads(base_path.read_text(encoding="utf-8"))
    if not isinstance(base, Mapping):
        raise ValueError("frozen base config must be an object")
    artifacts = base.get("artifacts")
    if not isinstance(artifacts, Mapping):
        raise ValueError("frozen base config artifacts are missing")
    base_hashes = {
        str(name): str(item.get("sha256", "")).lower()
        for name, item in artifacts.items()
        if isinstance(item, Mapping)
    }
    if base_hashes != dict(config.frozen_artifact_sha256):
        raise ValueError("base frozen artifact map drifted")

    paths: dict[str, Path] = {}
    for name in _REFERENCE_ARTIFACTS:
        item = artifacts.get(name)
        expected = config.frozen_artifact_sha256.get(name)
        if not isinstance(item, Mapping) or expected is None:
            raise ValueError(f"frozen reference artifact is missing: {name}")
        if str(item.get("sha256", "")).lower() != expected:
            raise ValueError(f"frozen reference artifact declaration drifted: {name}")
        paths[name] = Path(str(item.get("path", "")))

    condition_path = paths["condition_manifest"]
    if condition_path.resolve() != config.condition_manifest_path.resolve():
        raise ValueError("condition manifest path mismatch")
    if config.frozen_artifact_sha256["condition_manifest"] != config.condition_manifest_sha256:
        raise ValueError("condition manifest registered digest mismatch")
    expected_split = paths["phase2a_manifest"].parent / "splits" / "structure_ood_manifest.jsonl"
    if paths["structure_ood_manifest"].resolve() != expected_split.resolve():
        raise ValueError("structure OOD manifest path mismatch")

    for name, path in paths.items():
        if not path.is_file():
            raise FileNotFoundError(f"frozen reference artifact is missing: {path}")
        if sha256_file(path) != config.frozen_artifact_sha256[name]:
            label = {
                "condition_manifest": "condition manifest",
                "recovered_parents": "recovered parent cache",
                "phase2a_manifest": "Phase2A manifest",
                "structure_ood_manifest": "structure OOD manifest",
            }[name]
            raise ValueError(f"{label} hash mismatch")
    return paths


def load_evaluator_references(
    config: ExternalBenchmarkConfig,
) -> dict[str, Structure]:
    artifacts = _frozen_reference_artifacts(config)
    phase2a_root = artifacts["phase2a_manifest"].parent
    recovered_parent_cache = artifacts["recovered_parents"]
    conditions = load_registered_conditions(
        artifacts["condition_manifest"],
        expected_count=config.condition_count,
        root_seed=REGISTERED_ROOT_SEED,
        expected_sha256=config.condition_manifest_sha256,
    )
    sources = load_validation_condition_sources(phase2a_root, recovered_parent_cache)
    parents = load_recovered_parents(recovered_parent_cache)
    structures: dict[str, Structure] = {}
    for source in sources:
        parent = parents.get(source.material_id)
        if parent is None:
            raise ValueError(
                f"reference mapping drift: recovered parent missing for {source.material_id}"
            )
        structures[source.material_id] = _parent_structure(parent)
    return map_evaluator_references(conditions, sources, structures, root_seed=REGISTERED_ROOT_SEED)


def _validate_csp_attempt_provenance(
    records: tuple[AttemptRecord, ...],
    conditions: Sequence[RegisteredCondition],
    *,
    samples_per_condition: int,
) -> None:
    if samples_per_condition != 5:
        validate_formal_attempts(
            records,
            conditions,
            samples_per_condition=samples_per_condition,
        )
        return

    primary_sources = {
        (
            record.provenance.source_artifact,
            record.provenance.source_artifact_sha256,
        )
        for record in records
        if record.sample_index == 0
    }
    secondary_sources = {
        (
            record.provenance.source_artifact,
            record.provenance.source_artifact_sha256,
        )
        for record in records
        if record.sample_index in (1, 2, 3, 4)
    }
    if (
        len(primary_sources) != 1
        or len(secondary_sources) != 1
        or any(value is None for value in next(iter(primary_sources), (None, None)))
        or any(value is None for value in next(iter(secondary_sources), (None, None)))
    ):
        raise ValueError("K=5 CrystalFormer shard source provenance drifted")
    if primary_sources == secondary_sources:
        raise ValueError("K=5 requires distinct K=1 and K=4 source shards")

    provenance_normalized = tuple(
        replace(
            record,
            provenance=replace(
                record.provenance,
                source_artifact=None,
                source_artifact_sha256=None,
            ),
        )
        for record in records
    )
    validate_formal_attempts(
        provenance_normalized,
        conditions,
        samples_per_condition=samples_per_condition,
    )


def evaluate_csp_attempts(
    attempts: Sequence[AttemptRecord],
    conditions: Sequence[RegisteredCondition],
    references: Mapping[str, Structure],
    *,
    samples_per_condition: int,
) -> dict[str, Any]:
    records = tuple(attempts)
    _validate_csp_attempt_provenance(
        records,
        conditions,
        samples_per_condition=samples_per_condition,
    )
    expected_reference_ids = {condition.condition_id for condition in conditions}
    if set(references) != expected_reference_ids:
        raise ValueError("CSP reference condition mapping is missing or foreign")
    per_condition: list[dict[str, Any]] = []
    matcher_failures = 0
    parse_failures = 0
    matched_rms: list[float] = []
    matched_sample_count = 0
    for condition_index, condition in enumerate(conditions):
        start = condition_index * samples_per_condition
        condition_records = records[start : start + samples_per_condition]
        sample_results: list[dict[str, Any]] = []
        sample_rms: list[float] = []
        for record in condition_records:
            if record.status is not AttemptStatus.GENERATED:
                if record.failure_code == "STRUCTURE_PARSE_FAILED":
                    parse_failures += 1
                sample_results.append(
                    {
                        "sample_index": record.sample_index,
                        "registered_seed": record.registered_seed,
                        "matched": False,
                        "normalized_rms_distance": None,
                        "failure_code": record.failure_code,
                        "failure_message": record.failure_message,
                    }
                )
                continue
            try:
                candidate = record.structure.to_pymatgen()  # type: ignore[union-attr]
            except Exception as error:
                parse_failures += 1
                sample_results.append(
                    {
                        "sample_index": record.sample_index,
                        "registered_seed": record.registered_seed,
                        "matched": False,
                        "normalized_rms_distance": None,
                        "failure_code": "STRUCTURE_PARSE_FAILED",
                        "failure_message": f"{type(error).__name__}: {error}",
                    }
                )
                continue
            result = match_structures(candidate, references[condition.condition_id])
            if result["failure"] is not None:
                matcher_failures += 1
            if result["matched"]:
                sample_rms.append(float(result["normalized_rms_distance"]))
                matched_sample_count += 1
            sample_results.append(
                {
                    "sample_index": record.sample_index,
                    "registered_seed": record.registered_seed,
                    "matched": result["matched"],
                    "normalized_rms_distance": result["normalized_rms_distance"],
                    "failure_code": None if result["failure"] is None else "MATCHER_FAILURE",
                    "failure_message": result["failure"],
                }
            )
        normalized_rms = min(sample_rms) if sample_rms else None
        if normalized_rms is not None:
            matched_rms.append(normalized_rms)
        per_condition.append(
            {
                "condition_id": condition.condition_id,
                "attempt_index": condition.attempt_index,
                "target_space_group": condition.space_group,
                "sample_count": samples_per_condition,
                "matched": normalized_rms is not None,
                "normalized_rms_distance": normalized_rms,
                "sample_results": sample_results,
            }
        )
    matched_count = len(matched_rms)
    return {
        "schema_version": "g1-external-benchmark-csp-metrics.1.0.0",
        "matcher": matcher_settings(),
        "target_space_group_used_by_matcher": False,
        "samples_per_condition": samples_per_condition,
        "attempt_count": len(records),
        "condition_count": len(conditions),
        "matched_condition_count": matched_count,
        "match_rate": matched_count / len(conditions) if conditions else 0.0,
        "normalized_rms_condition_count": matched_count,
        "normalized_rms_sample_count": matched_sample_count,
        "normalized_rms_mean": fmean(matched_rms) if matched_rms else None,
        "parse_failure_count": parse_failures,
        "matcher_failure_count": matcher_failures,
        "all_conditions_in_denominator": True,
        "per_condition": per_condition,
    }
