from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
import platform
import re
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from importlib.metadata import version
from pathlib import Path
from types import MappingProxyType
from typing import Any, Callable, Iterable, Mapping, Sequence


CONDITION_SCHEMA = "g1-c0-symmetry-condition-manifest.1.0.0"
ROW_SCHEMA = "g1-official-track-b-driver-row.1.0.0"
RECEIPT_SCHEMA = "g1-official-track-b-driver-receipt.1.1.0"
EXPECTED_CONDITION_COUNT = 300
EXPECTED_SPACE_GROUPS = frozenset({225, 139, 12, 63, 189, 194, 123, 164})
PARENT_FREE_FLAGS = (
    "material_id_lookup_present",
    "parent_coordinates_present",
    "parent_lattice_present",
    "true_orbit_count_present",
    "true_termination_step_present",
    "true_wyckoff_sequence_present",
)
_SHA256 = re.compile(r"[0-9a-f]{64}")
_CONDITION_KEYS = {
    "condition_id",
    "attempt_index",
    "root_seed",
    "condition_seed",
    "composition",
    "space_group",
}
_MANIFEST_KEYS = {
    "attempt_count",
    "root_seed",
    "schema_version",
    "conditions",
    *PARENT_FREE_FLAGS,
}
_ROW_KEYS = {
    "schema_version",
    "model",
    "condition_level",
    "condition_id",
    "attempt_index",
    "sample_index",
    "registered_seed",
    "condition_input",
    "protocol",
    "status",
    "failure_code",
    "failure_message",
    "structure",
    "generation_latency_seconds",
    "retry_count",
    "refill_count",
    "provenance",
}
_RECEIPT_KEYS = {
    "schema_version",
    "status",
    "model",
    "condition_level",
    "official_repository",
    "official_checkout",
    "official_commit",
    "checkpoint",
    "checkpoint_path",
    "checkpoint_sha256",
    "companion_artifacts",
    "condition_manifest_path",
    "condition_manifest_sha256",
    "expected_condition_count",
    "sample_index",
    "attempt_count",
    "generated_count",
    "failed_count",
    "denominator_complete",
    "retry_count",
    "refill_count",
    "checkpoint_load_attempt_count",
    "checkpoint_load_count",
    "sample_call_count",
    "rng_reset_count",
    "batch_size",
    "protocol",
    "output_jsonl_path",
    "output_jsonl_sha256",
    "started_at",
    "ended_at",
    "abort_code",
    "device",
    "environment",
}
_ELEMENT_SYMBOLS = (
    "X",
    "H",
    "He",
    "Li",
    "Be",
    "B",
    "C",
    "N",
    "O",
    "F",
    "Ne",
    "Na",
    "Mg",
    "Al",
    "Si",
    "P",
    "S",
    "Cl",
    "Ar",
    "K",
    "Ca",
    "Sc",
    "Ti",
    "V",
    "Cr",
    "Mn",
    "Fe",
    "Co",
    "Ni",
    "Cu",
    "Zn",
    "Ga",
    "Ge",
    "As",
    "Se",
    "Br",
    "Kr",
    "Rb",
    "Sr",
    "Y",
    "Zr",
    "Nb",
    "Mo",
    "Tc",
    "Ru",
    "Rh",
    "Pd",
    "Ag",
    "Cd",
    "In",
    "Sn",
    "Sb",
    "Te",
    "I",
    "Xe",
    "Cs",
    "Ba",
    "La",
    "Ce",
    "Pr",
    "Nd",
    "Pm",
    "Sm",
    "Eu",
    "Gd",
    "Tb",
    "Dy",
    "Ho",
    "Er",
    "Tm",
    "Yb",
    "Lu",
    "Hf",
    "Ta",
    "W",
    "Re",
    "Os",
    "Ir",
    "Pt",
    "Au",
    "Hg",
    "Tl",
    "Pb",
    "Bi",
    "Po",
    "At",
    "Rn",
    "Fr",
    "Ra",
    "Ac",
    "Th",
    "Pa",
    "U",
    "Np",
    "Pu",
    "Am",
    "Cm",
    "Bk",
    "Cf",
    "Es",
    "Fm",
    "Md",
    "No",
    "Lr",
    "Rf",
    "Db",
    "Sg",
    "Bh",
    "Hs",
    "Mt",
    "Ds",
    "Rg",
    "Cn",
    "Nh",
    "Fl",
    "Mc",
    "Lv",
    "Ts",
    "Og",
)


@dataclass(frozen=True, slots=True)
class TrackBProtocol:
    model: str
    official_repository: str
    official_commit: str
    checkpoint: str
    checkpoint_sha256: str
    companion_sha256: Mapping[str, str]
    condition_level: str
    training_data: str
    environment: Mapping[str, str]
    protocol: Mapping[str, Any]

    def __post_init__(self) -> None:
        object.__setattr__(self, "companion_sha256", MappingProxyType(dict(self.companion_sha256)))
        object.__setattr__(self, "environment", MappingProxyType(dict(self.environment)))
        object.__setattr__(self, "protocol", MappingProxyType(dict(self.protocol)))


TRACK_B_PROTOCOLS: Mapping[str, TrackBProtocol] = MappingProxyType(
    {
        "MatterGen": TrackBProtocol(
            model="MatterGen",
            official_repository="https://github.com/microsoft/mattergen",
            official_commit="67afb22ea0dd0073aedfc85b30b94bea0ee21863",
            checkpoint="space_group",
            checkpoint_sha256=("1b6ab06739f4319d75f4a19960840ec3c8d3d32ee842c996876ef9d8b188e4bb"),
            companion_sha256={
                "config": ("75ebcb5bcf3fc2f1c78aeb9a99c88bd99ebd61fcdaa5fe9463344a7c29df62ac")
            },
            condition_level="SG_ONLY",
            training_data="Alex-MP-20",
            environment={
                "python": "3.10.20",
                "mattergen": "1.0.3",
                "torch": "2.7.1+cu128",
            },
            protocol={
                "space_group_only": True,
                "formula_supplied": False,
                "diffusion_guidance_factor": 2.0,
                "diffusion_steps": 1000,
                "batch_size": 1,
            },
        ),
        "CrystalFlow": TrackBProtocol(
            model="CrystalFlow",
            official_repository="https://github.com/ixsluo/CrystalFlow",
            official_commit="9c25ff0245d787efd87c9d1d797a8968443608cc",
            checkpoint="v1.0.0-alpha.1/CSP-mp-20/epoch=2462-step=261078.ckpt",
            checkpoint_sha256=("b08366eb04d47698da7ea09dbccb1c4a1304a4c3f506fdc1d8c294910ade6dc2"),
            companion_sha256={
                "hparams": ("1be9aa0c4d1bde9caf5ed8d76f4ff3760c667ba2bfa29d6c5d6bba01c3bc0a1b"),
                "lattice_scaler": (
                    "baad2a8f6e8086a47c612e7a16cd0f10ea987c5fdd6309eda52cfa51a0f9d289"
                ),
                "prop_scaler": ("7f2725921427bd0d996199756ba5ff01be6cb5aeb60f8fb143f037a31f88f7ee"),
                "prop_scalers": (
                    "a10252190bc3b47559a63fb581054049e41827a14ce83cfcd8ff83b4c2b2963b"
                ),
            },
            condition_level="EXACT_FORMULA_ONLY",
            training_data="MP-20",
            environment={
                "python": "3.10.20",
                "torch": "2.11.0+cu130",
                "lightning": "2.3.2",
                "torchdyn": "1.0.6",
            },
            protocol={
                "exact_formula_only": True,
                "space_group_supplied": False,
                "ode_int_steps": 100,
                "anneal_coords": True,
                "anneal_slope": 5.0,
                "batch_size": 1,
            },
        ),
        "DiffCSP": TrackBProtocol(
            model="DiffCSP",
            official_repository="https://github.com/jiaor17/DiffCSP",
            official_commit="7121d159826efa2ba9500bf299250d96da37f146",
            checkpoint="official Google Drive MP-20 CSP checkpoint:last.ckpt",
            checkpoint_sha256=("c06719217c940718823f7c67b58c74a0fcfba4c3e4312b23cdd22b7a15ea6b5f"),
            companion_sha256={
                "hparams": ("7e8afc601276abed9a112d93156aa6657ff78c3fe8634d412ccf684952e292a0")
            },
            condition_level="EXACT_FORMULA_ONLY",
            training_data="MP-20",
            environment={
                "python": "3.10.20",
                "torch": "2.11.0+cu130",
                "pytorch-lightning": "2.6.5",
            },
            protocol={
                "exact_formula_only": True,
                "space_group_supplied": False,
                "diffusion_steps": 1000,
                "step_lr": 1e-5,
                "batch_size": 1,
                "runtime_classmethod_checkpoint_load": True,
            },
        ),
    }
)


@dataclass(frozen=True, slots=True)
class OfficialTrackBAPI:
    environment: Mapping[str, str]
    device: str
    cuda_available: bool
    load_model: Callable[[], Any]
    sample: Callable[[Any, dict[str, object]], Mapping[str, Any]]
    seed_random: Callable[[int], None]
    seed_numpy: Callable[[int], None]
    seed_torch: Callable[[int], None]
    seed_cuda_all: Callable[[int], None]

    def __post_init__(self) -> None:
        object.__setattr__(self, "environment", MappingProxyType(dict(self.environment)))
        callbacks = (
            self.load_model,
            self.sample,
            self.seed_random,
            self.seed_numpy,
            self.seed_torch,
            self.seed_cuda_all,
        )
        if any(not callable(callback) for callback in callbacks):
            raise TypeError("official runtime API callbacks must be callable")
        if type(self.cuda_available) is not bool:
            raise TypeError("cuda_available must be a boolean")


class _DriverAbort(Exception):
    def __init__(self, code: str, error: BaseException):
        super().__init__(str(error))
        self.code = code
        self.error = error


def _sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _json_loads(value: str) -> Any:
    def reject_constant(constant: str) -> None:
        raise ValueError(f"non-finite JSON constant: {constant}")

    return json.loads(value, parse_constant=reject_constant)


def _json_bytes(payload: object) -> bytes:
    return (
        json.dumps(
            payload,
            allow_nan=False,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        + "\n"
    ).encode("utf-8")


def _strict_wsl_path_to_windows(value: str) -> str | None:
    if "\\" in value or "\x00" in value:
        return None
    parts = value.split("/")
    if len(parts) < 3 or parts[:2] != ["", "mnt"] or re.fullmatch(r"[a-z]", parts[2]) is None:
        return None
    segments = parts[3:]
    if any(
        not segment
        or segment in {".", ".."}
        or any(character in segment for character in '<>:"|?*')
        for segment in segments
    ):
        return None
    suffix = "\\".join(segments)
    return f"{parts[2].upper()}:\\{suffix}"


def _strict_windows_path_to_wsl(value: str) -> str | None:
    match = re.fullmatch(r"([A-Z]):\\(.*)", value)
    if match is None or "/" in value or "\x00" in value:
        return None
    suffix = match.group(2)
    segments = [] if not suffix else suffix.split("\\")
    if any(
        not segment
        or segment in {".", ".."}
        or any(character in segment for character in '<>:"|?*')
        for segment in segments
    ):
        return None
    tail = "" if not segments else "/" + "/".join(segments)
    return f"/mnt/{match.group(1).lower()}{tail}"


def _receipt_path_matches_local(
    receipt_path: object,
    canonical_local_path: str,
    *,
    local_os_name: str,
) -> bool:
    if not isinstance(receipt_path, str) or not receipt_path or "\x00" in receipt_path:
        return False
    if receipt_path == canonical_local_path:
        return True
    if local_os_name == "nt":
        return receipt_path == _strict_windows_path_to_wsl(canonical_local_path)
    if local_os_name == "posix":
        return receipt_path == _strict_wsl_path_to_windows(canonical_local_path)
    raise ValueError(f"unsupported local path platform: {local_os_name}")


def _canonical_receipt_path(receipt_path: object, expected_local_path: str | Path) -> Path:
    expected = Path(expected_local_path).resolve()
    if not _receipt_path_matches_local(
        receipt_path,
        str(expected),
        local_os_name=os.name,
    ):
        raise ValueError("driver receipt path differs from registered local path")
    return expected


def _atomic_write_json_new(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(f"immutable receipt already exists: {path}")
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb", dir=path.parent, prefix=f".{path.name}.", delete=False
        ) as handle:
            temporary = Path(handle.name)
            handle.write(_json_bytes(payload))
            handle.flush()
            os.fsync(handle.fileno())
        os.link(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _atomic_create_empty_new(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _append_jsonl_row(path: Path, payload: object) -> None:
    data = _json_bytes(payload)
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)
    try:
        written = os.write(descriptor, data)
        if written != len(data):
            raise OSError("short atomic JSONL write")
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _git_output(checkout: Path, arguments: tuple[str, ...]) -> str:
    completed = subprocess.run(
        ["git", *arguments],
        cwd=checkout,
        check=True,
        shell=False,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def _condition_seed(root_seed: int, attempt_index: int) -> int:
    return int.from_bytes(
        hashlib.sha256(f"condition-seed:{root_seed}:{attempt_index}".encode()).digest()[:8],
        "big",
    ) % (2**31 - 1)


def _condition_id(condition: Mapping[str, Any]) -> str:
    public = {
        key: condition[key]
        for key in (
            "attempt_index",
            "root_seed",
            "condition_seed",
            "composition",
            "space_group",
        )
    }
    return (
        "condition-"
        + hashlib.sha256(
            json.dumps(public, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()
    )


def _load_conditions(path: Path, expected_sha256: str) -> tuple[dict[str, Any], ...]:
    if _SHA256.fullmatch(expected_sha256) is None:
        raise ValueError("condition manifest SHA-256 is malformed")
    if not path.is_file() or _sha256_file(path) != expected_sha256:
        raise ValueError("condition manifest hash mismatch")
    payload = _json_loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping) or set(payload) != _MANIFEST_KEYS:
        raise ValueError("condition manifest schema or keys drifted")
    if payload["schema_version"] != CONDITION_SCHEMA or payload["root_seed"] != 20260823:
        raise ValueError("condition manifest schema or root seed drifted")
    if payload["attempt_count"] != EXPECTED_CONDITION_COUNT:
        raise ValueError("driver requires 300 unique ordered conditions")
    if any(payload[flag] is not False for flag in PARENT_FREE_FLAGS):
        raise ValueError("driver condition manifest is not parent-free")
    raw = payload["conditions"]
    if not isinstance(raw, list) or len(raw) != EXPECTED_CONDITION_COUNT:
        raise ValueError("driver requires 300 unique ordered conditions")
    conditions: list[dict[str, Any]] = []
    identities: set[str] = set()
    space_groups: set[int] = set()
    for expected_index, item in enumerate(raw):
        if not isinstance(item, Mapping) or set(item) != _CONDITION_KEYS:
            raise ValueError("condition schema drifted")
        condition = dict(item)
        if condition["attempt_index"] != expected_index:
            raise ValueError("driver requires 300 unique ordered conditions")
        if condition["root_seed"] != payload["root_seed"]:
            raise ValueError("condition root seed drifted")
        if condition["condition_seed"] != _condition_seed(condition["root_seed"], expected_index):
            raise ValueError("registered condition seed drifted")
        if condition["condition_id"] != _condition_id(condition):
            raise ValueError("registered condition identity drifted")
        if condition["condition_id"] in identities:
            raise ValueError("driver requires 300 unique ordered conditions")
        composition = condition["composition"]
        if (
            not isinstance(composition, list)
            or not composition
            or any(
                not isinstance(pair, list)
                or len(pair) != 2
                or type(pair[0]) is not int
                or type(pair[1]) is not int
                or not 1 <= pair[0] <= 118
                or pair[1] < 1
                for pair in composition
            )
            or composition != sorted(composition)
            or len({pair[0] for pair in composition}) != len(composition)
        ):
            raise ValueError("condition composition drifted")
        space_group = condition["space_group"]
        if type(space_group) is not int or not 1 <= space_group <= 230:
            raise ValueError("condition space group drifted")
        identities.add(condition["condition_id"])
        space_groups.add(space_group)
        conditions.append(condition)
    if space_groups != EXPECTED_SPACE_GROUPS:
        raise ValueError("frozen eight-space-group set drifted")
    return tuple(conditions)


def _registered_sample_seed(condition_seed: int) -> int:
    return condition_seed


def _formula(condition: Mapping[str, Any]) -> str:
    return "".join(
        _ELEMENT_SYMBOLS[atomic_number] + ("" if count == 1 else str(count))
        for atomic_number, count in condition["composition"]
    )


def _verified_artifacts(
    *,
    protocol: TrackBProtocol,
    official_checkout: Path,
    checkpoint_path: Path,
    companion_paths: Mapping[str, str | Path],
) -> dict[str, dict[str, str]]:
    if not official_checkout.is_dir():
        raise FileNotFoundError(f"official checkout is missing: {official_checkout}")
    if _git_output(official_checkout, ("rev-parse", "HEAD")) != protocol.official_commit:
        raise ValueError(f"official {protocol.model} commit mismatch")
    if _git_output(official_checkout, ("diff", "--name-only", "HEAD", "--")) or _git_output(
        official_checkout,
        ("ls-files", "--others", "--exclude-standard"),
    ):
        raise ValueError(f"official {protocol.model} checkout is dirty")
    if not checkpoint_path.is_file():
        raise FileNotFoundError(f"official checkpoint is missing: {checkpoint_path}")
    observed_checkpoint = _sha256_file(checkpoint_path)
    if observed_checkpoint != protocol.checkpoint_sha256:
        raise ValueError(
            "official checkpoint hash mismatch: "
            f"expected {protocol.checkpoint_sha256}, observed {observed_checkpoint}"
        )
    if set(companion_paths) != set(protocol.companion_sha256):
        raise ValueError(f"official {protocol.model} companion artifact set drifted")
    verified: dict[str, dict[str, str]] = {}
    for name, expected_digest in protocol.companion_sha256.items():
        path = Path(companion_paths[name]).resolve()
        if not path.is_file():
            raise FileNotFoundError(f"official companion artifact is missing: {name}: {path}")
        observed = _sha256_file(path)
        if observed != expected_digest:
            raise ValueError(f"official {protocol.model} companion hash mismatch: {name}")
        verified[name] = {"path": str(path), "sha256": observed}
    return verified


def _validate_environment(protocol: TrackBProtocol, api: OfficialTrackBAPI, device: str) -> None:
    if not isinstance(api, OfficialTrackBAPI):
        raise TypeError("private official loader returned an invalid API")
    if device != "cuda" or api.device != device or api.cuda_available is not True:
        raise ValueError(f"official {protocol.model} device mismatch: CUDA is required")
    if any(api.environment.get(name) != value for name, value in protocol.environment.items()):
        raise ValueError(f"official {protocol.model} environment mismatch")


def _condition_input(protocol: TrackBProtocol, condition: Mapping[str, Any]) -> dict[str, Any]:
    if protocol.condition_level == "SG_ONLY":
        return {
            "formula": None,
            "formula_not_supplied": True,
            "space_group": condition["space_group"],
            "space_group_not_supplied": False,
        }
    return {
        "formula": _formula(condition),
        "formula_not_supplied": False,
        "space_group": None,
        "space_group_not_supplied": True,
    }


def _sample_request(protocol: TrackBProtocol, condition: Mapping[str, Any]) -> dict[str, object]:
    if protocol.model == "MatterGen":
        return {
            "space_group": int(condition["space_group"]),
            "diffusion_guidance_factor": 2.0,
            "diffusion_steps": 1000,
            "batch_size": 1,
        }
    if protocol.model == "CrystalFlow":
        return {
            "formula": _formula(condition),
            "ode_int_steps": 100,
            "anneal_coords": True,
            "anneal_slope": 5.0,
            "batch_size": 1,
        }
    return {
        "formula": _formula(condition),
        "diffusion_steps": 1000,
        "step_lr": 1e-5,
        "batch_size": 1,
    }


def _reset_rng(api: OfficialTrackBAPI, seed: int) -> None:
    api.seed_random(seed)
    api.seed_numpy(seed % (2**32))
    api.seed_torch(seed)
    api.seed_cuda_all(seed)


def _finite_float(value: Any, *, label: str) -> float:
    if type(value) not in {int, float}:
        raise ValueError(f"{label} must be numeric")
    result = float(value)
    if not math.isfinite(result):
        raise FloatingPointError("NaN/non-finite official output corruption")
    return result


def _normalize_structure(payload: Mapping[str, Any]) -> dict[str, Any]:
    keys = {"lattice", "atomic_numbers", "fractional_coordinates"}
    if not isinstance(payload, Mapping) or set(payload) != keys:
        raise ValueError("normalized official structure keys drifted")
    lattice = payload["lattice"]
    atomic_numbers = payload["atomic_numbers"]
    coordinates = payload["fractional_coordinates"]
    if (
        not isinstance(lattice, Sequence)
        or isinstance(lattice, (str, bytes))
        or len(lattice) != 3
        or any(
            not isinstance(row, Sequence) or isinstance(row, (str, bytes)) or len(row) != 3
            for row in lattice
        )
    ):
        raise ValueError("normalized official lattice is malformed")
    if (
        not isinstance(atomic_numbers, Sequence)
        or isinstance(atomic_numbers, (str, bytes))
        or not atomic_numbers
        or not isinstance(coordinates, Sequence)
        or isinstance(coordinates, (str, bytes))
        or len(atomic_numbers) != len(coordinates)
        or any(
            not isinstance(row, Sequence) or isinstance(row, (str, bytes)) or len(row) != 3
            for row in coordinates
        )
    ):
        raise ValueError("normalized official sites are malformed")
    normalized_atomic_numbers: list[int] = []
    for value in atomic_numbers:
        if type(value) is not int or not 1 <= value <= 118:
            raise ValueError("normalized official atomic number is invalid")
        normalized_atomic_numbers.append(value)
    normalized = {
        "lattice": [
            [_finite_float(value, label="lattice value") for value in row] for row in lattice
        ],
        "atomic_numbers": normalized_atomic_numbers,
        "fractional_coordinates": [
            [_finite_float(value, label="fractional coordinate") for value in row]
            for row in coordinates
        ],
    }
    a, b, c = normalized["lattice"]
    determinant = (
        a[0] * (b[1] * c[2] - b[2] * c[1])
        - a[1] * (b[0] * c[2] - b[2] * c[0])
        + a[2] * (b[0] * c[1] - b[1] * c[0])
    )
    if abs(determinant) <= 0.0:
        raise ValueError("normalized official cell volume is not positive")
    return normalized


def _fatal_code(error: BaseException) -> str | None:
    if isinstance(error, MemoryError):
        return "UNRECOVERABLE_OOM"
    message = f"{type(error).__name__}: {error}".lower()
    if "out of memory" in message or "resource_exhausted" in message:
        return "UNRECOVERABLE_OOM"
    if isinstance(error, FloatingPointError) or "nan" in message or "non-finite" in message:
        return "UNRECOVERABLE_NAN"
    return None


def _row_provenance(
    protocol: TrackBProtocol,
    checkpoint_path: Path,
    companion_artifacts: Mapping[str, Mapping[str, str]],
) -> dict[str, Any]:
    return {
        "official_repository": protocol.official_repository,
        "official_commit": protocol.official_commit,
        "checkpoint": protocol.checkpoint,
        "checkpoint_path": str(checkpoint_path),
        "checkpoint_sha256": protocol.checkpoint_sha256,
        "companion_sha256": {
            name: artifact["sha256"] for name, artifact in companion_artifacts.items()
        },
    }


def _receipt_payload(
    *,
    status: str,
    protocol: TrackBProtocol,
    started_at: str,
    ended_at: str,
    manifest_path: Path,
    manifest_sha256: str,
    checkout: Path,
    checkpoint: Path,
    companion_artifacts: Mapping[str, Mapping[str, str]],
    output_path: Path,
    api: OfficialTrackBAPI,
    attempted_count: int,
    generated_count: int,
    failed_count: int,
    checkpoint_load_attempt_count: int,
    checkpoint_load_count: int,
    abort_code: str | None,
) -> dict[str, Any]:
    return {
        "schema_version": RECEIPT_SCHEMA,
        "status": status,
        "model": protocol.model,
        "condition_level": protocol.condition_level,
        "official_repository": protocol.official_repository,
        "official_checkout": str(checkout),
        "official_commit": protocol.official_commit,
        "checkpoint": protocol.checkpoint,
        "checkpoint_path": str(checkpoint),
        "checkpoint_sha256": protocol.checkpoint_sha256,
        "companion_artifacts": {
            name: dict(artifact) for name, artifact in companion_artifacts.items()
        },
        "condition_manifest_path": str(manifest_path),
        "condition_manifest_sha256": manifest_sha256,
        "expected_condition_count": EXPECTED_CONDITION_COUNT,
        "sample_index": 0,
        "attempt_count": attempted_count,
        "generated_count": generated_count,
        "failed_count": failed_count,
        "denominator_complete": attempted_count == EXPECTED_CONDITION_COUNT,
        "retry_count": 0,
        "refill_count": 0,
        "checkpoint_load_attempt_count": checkpoint_load_attempt_count,
        "checkpoint_load_count": checkpoint_load_count,
        "sample_call_count": attempted_count,
        "rng_reset_count": attempted_count,
        "batch_size": 1,
        "protocol": dict(protocol.protocol),
        "output_jsonl_path": str(output_path),
        "output_jsonl_sha256": (_sha256_file(output_path) if output_path.is_file() else None),
        "started_at": started_at,
        "ended_at": ended_at,
        "abort_code": abort_code,
        "device": api.device,
        "environment": dict(api.environment),
    }


def _load_official_api(
    *,
    protocol: TrackBProtocol,
    official_checkout: Path,
    checkpoint_path: Path,
    companion_paths: Mapping[str, Path],
    device: str,
) -> OfficialTrackBAPI:
    arguments = {
        "official_checkout": official_checkout,
        "checkpoint_path": checkpoint_path,
        "companion_paths": companion_paths,
        "device": device,
    }
    if protocol.model == "MatterGen":
        return _load_mattergen_api(**arguments)
    if protocol.model == "CrystalFlow":
        return _load_crystalflow_api(**arguments)
    return _load_diffcsp_api(**arguments)


def run_driver(
    *,
    model: str,
    condition_manifest_path: str | Path,
    expected_condition_sha256: str,
    official_checkout: str | Path,
    checkpoint_path: str | Path,
    companion_paths: Mapping[str, str | Path],
    output_jsonl_path: str | Path,
    receipt_path: str | Path,
    device: str,
) -> dict[str, Any]:
    try:
        protocol = TRACK_B_PROTOCOLS[model]
    except KeyError:
        raise ValueError(f"unsupported official Track B model: {model}") from None
    manifest = Path(condition_manifest_path).resolve()
    checkout = Path(official_checkout).resolve()
    checkpoint = Path(checkpoint_path).resolve()
    output = Path(output_jsonl_path).resolve()
    receipt_target = Path(receipt_path).resolve()
    companions = {name: Path(path).resolve() for name, path in companion_paths.items()}
    if output.exists():
        raise FileExistsError(f"output JSONL already exists: {output}")
    if receipt_target.exists():
        raise FileExistsError(f"immutable receipt already exists: {receipt_target}")
    conditions = _load_conditions(manifest, expected_condition_sha256)
    companion_artifacts = _verified_artifacts(
        protocol=protocol,
        official_checkout=checkout,
        checkpoint_path=checkpoint,
        companion_paths=companions,
    )
    official = _load_official_api(
        protocol=protocol,
        official_checkout=checkout,
        checkpoint_path=checkpoint,
        companion_paths=companions,
        device=device,
    )
    _validate_environment(protocol, official, device)

    started_at = datetime.now(timezone.utc).isoformat()
    output.parent.mkdir(parents=True, exist_ok=True)
    try:
        loaded_model = official.load_model()
    except Exception as error:
        abort_code = _fatal_code(error)
        if abort_code is None:
            raise
        _atomic_create_empty_new(output)
        abort_receipt = _receipt_payload(
            status="ABORTED",
            protocol=protocol,
            started_at=started_at,
            ended_at=datetime.now(timezone.utc).isoformat(),
            manifest_path=manifest,
            manifest_sha256=expected_condition_sha256,
            checkout=checkout,
            checkpoint=checkpoint,
            companion_artifacts=companion_artifacts,
            output_path=output,
            api=official,
            attempted_count=0,
            generated_count=0,
            failed_count=0,
            checkpoint_load_attempt_count=1,
            checkpoint_load_count=0,
            abort_code=abort_code,
        )
        _atomic_write_json_new(receipt_target, abort_receipt)
        raise
    generated_count = 0
    failed_count = 0
    attempted_count = 0
    provenance = _row_provenance(protocol, checkpoint, companion_artifacts)
    try:
        for condition in conditions:
            registered_seed = _registered_sample_seed(int(condition["condition_seed"]))
            started = time.perf_counter()
            status = "FAILED"
            failure_code: str | None = None
            failure_message: str | None = None
            structure: dict[str, Any] | None = None
            pending_abort: _DriverAbort | None = None
            _reset_rng(official, registered_seed)
            request = _sample_request(protocol, condition)
            try:
                structure = _normalize_structure(official.sample(loaded_model, request))
                status = "GENERATED"
            except Exception as error:
                fatal_code = _fatal_code(error)
                if fatal_code is None:
                    failure_code = "OFFICIAL_SAMPLE_FAILED"
                else:
                    failure_code = fatal_code
                    pending_abort = _DriverAbort(fatal_code, error)
                failure_message = f"{type(error).__name__}: {error}"
                structure = None
            latency = time.perf_counter() - started
            if status == "GENERATED":
                generated_count += 1
            else:
                failed_count += 1
            row = {
                "schema_version": ROW_SCHEMA,
                "model": protocol.model,
                "condition_level": protocol.condition_level,
                "condition_id": condition["condition_id"],
                "attempt_index": condition["attempt_index"],
                "sample_index": 0,
                "registered_seed": registered_seed,
                "condition_input": _condition_input(protocol, condition),
                "protocol": dict(protocol.protocol),
                "status": status,
                "failure_code": failure_code,
                "failure_message": failure_message,
                "structure": structure,
                "generation_latency_seconds": latency,
                "retry_count": 0,
                "refill_count": 0,
                "provenance": provenance,
            }
            _append_jsonl_row(output, row)
            attempted_count += 1
            if pending_abort is not None:
                raise pending_abort
    except _DriverAbort as abort:
        receipt = _receipt_payload(
            status="ABORTED",
            protocol=protocol,
            started_at=started_at,
            ended_at=datetime.now(timezone.utc).isoformat(),
            manifest_path=manifest,
            manifest_sha256=expected_condition_sha256,
            checkout=checkout,
            checkpoint=checkpoint,
            companion_artifacts=companion_artifacts,
            output_path=output,
            api=official,
            attempted_count=attempted_count,
            generated_count=generated_count,
            failed_count=failed_count,
            checkpoint_load_attempt_count=1,
            checkpoint_load_count=1,
            abort_code=abort.code,
        )
        _atomic_write_json_new(receipt_target, receipt)
        raise abort.error

    receipt = _receipt_payload(
        status="COMPLETE",
        protocol=protocol,
        started_at=started_at,
        ended_at=datetime.now(timezone.utc).isoformat(),
        manifest_path=manifest,
        manifest_sha256=expected_condition_sha256,
        checkout=checkout,
        checkpoint=checkpoint,
        companion_artifacts=companion_artifacts,
        output_path=output,
        api=official,
        attempted_count=attempted_count,
        generated_count=generated_count,
        failed_count=failed_count,
        checkpoint_load_attempt_count=1,
        checkpoint_load_count=1,
        abort_code=None,
    )
    _atomic_write_json_new(receipt_target, receipt)
    return receipt


def _load_source_module(name: str, path: Path) -> Any:
    specification = importlib.util.spec_from_file_location(name, path)
    if specification is None or specification.loader is None:
        raise ImportError(f"cannot load pinned official module: {path}")
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def _pymatgen_payload(structure: Any) -> dict[str, Any]:
    return {
        "lattice": structure.lattice.matrix.tolist(),
        "atomic_numbers": [int(site.specie.Z) for site in structure],
        "fractional_coordinates": structure.frac_coords.tolist(),
    }


def _tensor_payload(outputs: Mapping[str, Any]) -> dict[str, Any]:
    num_atoms = outputs["num_atoms"].detach().cpu().reshape(-1).tolist()
    if len(num_atoms) != 1:
        raise ValueError("official Track B sampler output batch size drifted")
    site_count = int(num_atoms[0])
    lattices = outputs["lattices"].detach().cpu().tolist()
    atomic_numbers = outputs["atom_types"].detach().cpu().reshape(-1).tolist()
    coordinates = outputs["frac_coords"].detach().cpu().reshape(-1, 3).tolist()
    if len(lattices) != 1 or len(atomic_numbers) != site_count or len(coordinates) != site_count:
        raise ValueError("official Track B sampler site count drifted")
    return {
        "lattice": lattices[0],
        "atomic_numbers": [int(value) for value in atomic_numbers],
        "fractional_coordinates": coordinates,
    }


def _load_mattergen_api(
    *,
    official_checkout: Path,
    checkpoint_path: Path,
    companion_paths: Mapping[str, Path],
    device: str,
) -> OfficialTrackBAPI:
    del device
    _validate_runtime_layout(
        model="MatterGen",
        checkpoint_path=checkpoint_path,
        companion_paths=companion_paths,
    )
    sys.path.insert(0, str(official_checkout))
    import numpy as np
    import random
    import torch
    from mattergen.common.utils.data_classes import MatterGenCheckpointInfo
    from mattergen.generator import CrystalGenerator

    model_root = companion_paths["config"].parent
    checkpoint_info = MatterGenCheckpointInfo(
        model_path=str(model_root), load_epoch="last", strict_checkpoint_loading=True
    )

    def load_model() -> Any:
        generator = CrystalGenerator(
            checkpoint_info=checkpoint_info,
            batch_size=1,
            num_batches=1,
            diffusion_guidance_factor=2.0,
            properties_to_condition_on={"space_group": 1},
            record_trajectories=False,
        )
        generator.prepare()
        return generator

    def sample(generator: Any, request: dict[str, object]) -> Mapping[str, Any]:
        generator.properties_to_condition_on = {"space_group": int(request["space_group"])}
        generator.diffusion_guidance_factor = float(request["diffusion_guidance_factor"])
        with tempfile.TemporaryDirectory(prefix="mattergen-track-b-") as output_dir:
            structures = generator.generate(
                batch_size=1,
                num_batches=1,
                target_compositions_dict=None,
                output_dir=output_dir,
            )
        if len(structures) != 1:
            raise ValueError("official MatterGen batch-one output count drifted")
        return _pymatgen_payload(structures[0])

    return OfficialTrackBAPI(
        environment={
            "python": platform.python_version(),
            "mattergen": version("mattergen"),
            "torch": torch.__version__,
            "cuda_runtime": str(torch.version.cuda),
        },
        device="cuda",
        cuda_available=bool(torch.cuda.is_available()),
        load_model=load_model,
        sample=sample,
        seed_random=random.seed,
        seed_numpy=np.random.seed,
        seed_torch=torch.manual_seed,
        seed_cuda_all=torch.cuda.manual_seed_all,
    )


def _load_crystalflow_api(
    *,
    official_checkout: Path,
    checkpoint_path: Path,
    companion_paths: Mapping[str, Path],
    device: str,
) -> OfficialTrackBAPI:
    del device
    _validate_runtime_layout(
        model="CrystalFlow",
        checkpoint_path=checkpoint_path,
        companion_paths=companion_paths,
    )
    sys.path.insert(0, str(official_checkout))
    sys.path.insert(0, str(official_checkout / "scripts"))
    os.environ.setdefault("PROJECT_ROOT", str(official_checkout))
    os.environ["TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD"] = "1"
    import lightning
    import numpy as np
    import random
    import torch
    import torchdyn
    from torch_geometric.data import Batch

    eval_utils = _load_source_module(
        "crystalflow_official_eval_utils", official_checkout / "scripts" / "eval_utils.py"
    )
    prior_eval_utils = sys.modules.get("eval_utils")
    sys.modules["eval_utils"] = eval_utils
    try:
        sample_module = _load_source_module(
            "crystalflow_official_sample", official_checkout / "scripts" / "sample.py"
        )
    finally:
        if prior_eval_utils is None:
            sys.modules.pop("eval_utils", None)
        else:
            sys.modules["eval_utils"] = prior_eval_utils
    model_root = companion_paths["hparams"].parent

    def load_model() -> Any:
        checkpoints = tuple(model_root.glob("*.ckpt"))
        if len(checkpoints) != 1 or checkpoints[0].resolve() != checkpoint_path:
            raise ValueError("CrystalFlow model directory checkpoint selection drifted")
        model, _loader, _cfg = eval_utils.load_model(model_root, load_data=False)
        model.to("cuda")
        model.eval()
        return model

    def sample(model: Any, request: dict[str, object]) -> Mapping[str, Any]:
        dataset = sample_module.SampleDataset(str(request["formula"]), 1, conditions={})
        batch = Batch.from_data_list([dataset[0]])
        batch.cuda()
        outputs, _trajectory = model.sample(
            batch,
            step_lr=1e-5,
            N=int(request["ode_int_steps"]),
            anneal_lattice=False,
            anneal_coords=bool(request["anneal_coords"]),
            anneal_slope=float(request["anneal_slope"]),
            anneal_offset=0.0,
            guide_factor=None,
        )
        return _tensor_payload(outputs)

    return OfficialTrackBAPI(
        environment={
            "python": platform.python_version(),
            "torch": torch.__version__,
            "lightning": lightning.__version__,
            "torchdyn": torchdyn.__version__,
            "cuda_runtime": str(torch.version.cuda),
            "torch_force_no_weights_only_load": os.environ["TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD"],
        },
        device="cuda",
        cuda_available=bool(torch.cuda.is_available()),
        load_model=load_model,
        sample=sample,
        seed_random=random.seed,
        seed_numpy=np.random.seed,
        seed_torch=torch.manual_seed,
        seed_cuda_all=torch.cuda.manual_seed_all,
    )


def _load_diffcsp_checkpoint_runtime(
    model: Any, checkpoint_path: str | Path, hparams_path: str | Path
) -> Any:
    return type(model).load_from_checkpoint(
        str(Path(checkpoint_path).resolve()),
        hparams_file=str(Path(hparams_path).resolve()),
        strict=False,
    )


def _validate_runtime_layout(
    *,
    model: str,
    checkpoint_path: str | Path,
    companion_paths: Mapping[str, str | Path],
) -> None:
    checkpoint = Path(checkpoint_path).resolve()
    companions = {name: Path(path).resolve() for name, path in companion_paths.items()}
    if model == "MatterGen":
        root = companions["config"].parent
        expected_checkpoint = root / "checkpoints" / "last.ckpt"
        expected_companions = {"config": root / "config.yaml"}
    elif model == "CrystalFlow":
        root = companions["hparams"].parent
        expected_checkpoint = root / "epoch=2462-step=261078.ckpt"
        expected_companions = {
            "hparams": root / "hparams.yaml",
            "lattice_scaler": root / "lattice_scaler.pt",
            "prop_scaler": root / "prop_scaler.pt",
            "prop_scalers": root / "prop_scalers.pt",
        }
    elif model == "DiffCSP":
        root = companions["hparams"].parent
        expected_checkpoint = root / "last.ckpt"
        expected_companions = {"hparams": root / "hparams.yaml"}
    else:
        raise ValueError(f"unsupported official Track B model: {model}")
    if checkpoint != expected_checkpoint.resolve() or companions != {
        name: path.resolve() for name, path in expected_companions.items()
    }:
        raise ValueError(f"official {model} runtime artifact layout drifted")


def _load_diffcsp_api(
    *,
    official_checkout: Path,
    checkpoint_path: Path,
    companion_paths: Mapping[str, Path],
    device: str,
) -> OfficialTrackBAPI:
    del device
    _validate_runtime_layout(
        model="DiffCSP",
        checkpoint_path=checkpoint_path,
        companion_paths=companion_paths,
    )
    sys.path.insert(0, str(official_checkout))
    os.environ.setdefault("PROJECT_ROOT", str(official_checkout))
    import hydra
    import numpy as np
    import pytorch_lightning
    import random
    import torch
    from hydra import compose, initialize_config_dir
    from pymatgen.core import Composition
    from torch_geometric.data import Batch, Data

    model_root = companion_paths["hparams"].parent

    def load_model() -> Any:
        with initialize_config_dir(config_dir=str(model_root), version_base=None):
            cfg = compose(config_name="hparams")
            instance = hydra.utils.instantiate(
                cfg.model,
                optim=cfg.optim,
                data=cfg.data,
                logging=cfg.logging,
                _recursive_=False,
            )
        model = _load_diffcsp_checkpoint_runtime(
            instance, checkpoint_path, companion_paths["hparams"]
        )
        if int(model.beta_scheduler.timesteps) != 1000:
            raise ValueError("official DiffCSP checkpoint timestep count drifted")
        model.to("cuda")
        model.eval()
        return model

    def sample(model: Any, request: dict[str, object]) -> Mapping[str, Any]:
        composition = Composition(str(request["formula"]))
        atomic_numbers: list[int] = []
        for element, amount in composition.items():
            if not float(amount).is_integer() or amount < 1:
                raise ValueError("DiffCSP formula contains a non-integer amount")
            atomic_numbers.extend([int(element.Z)] * int(amount))
        data = Data(
            atom_types=torch.LongTensor(atomic_numbers),
            num_atoms=len(atomic_numbers),
            num_nodes=len(atomic_numbers),
        )
        batch = Batch.from_data_list([data])
        batch.cuda()
        outputs, _trajectory = model.sample(batch, step_lr=float(request["step_lr"]))
        return _tensor_payload(outputs)

    return OfficialTrackBAPI(
        environment={
            "python": platform.python_version(),
            "torch": torch.__version__,
            "pytorch-lightning": pytorch_lightning.__version__,
            "cuda_runtime": str(torch.version.cuda),
        },
        device="cuda",
        cuda_available=bool(torch.cuda.is_available()),
        load_model=load_model,
        sample=sample,
        seed_random=random.seed,
        seed_numpy=np.random.seed,
        seed_torch=torch.manual_seed,
        seed_cuda_all=torch.cuda.manual_seed_all,
    )


def _capability(protocol: TrackBProtocol) -> Any:
    from crysalis_g1.external_benchmark.capabilities import official_capabilities

    capability = next(
        (record for record in official_capabilities() if record.model == protocol.model),
        None,
    )
    if capability is None:
        raise ValueError(f"Task 2 capability is missing: {protocol.model}")
    if (
        capability.official_commit != protocol.official_commit
        or capability.checkpoint_sha256 != protocol.checkpoint_sha256
        or capability.condition_level.value != protocol.condition_level
    ):
        raise ValueError(f"Task 2 capability drifted: {protocol.model}")
    return capability


def _attempt_provenance(protocol: TrackBProtocol, source: Path | None) -> Any:
    from crysalis_g1.external_benchmark.provenance import sha256_file
    from crysalis_g1.external_benchmark.records import ModelProvenance

    return ModelProvenance(
        official_repository=protocol.official_repository,
        implementation_commit=protocol.official_commit,
        checkpoint=protocol.checkpoint,
        checkpoint_sha256=protocol.checkpoint_sha256,
        source_artifact=None if source is None else str(source),
        source_artifact_sha256=None if source is None else sha256_file(source),
    )


def _failure_cohort(
    *,
    protocol: TrackBProtocol,
    capability: Any,
    conditions: Sequence[Any],
    code: str,
    message: str,
    source: Path | None,
) -> tuple[Any, ...]:
    from crysalis_g1.external_benchmark.records import (
        AttemptRecord,
        AttemptStatus,
        registered_sample_seed,
        validate_formal_attempts,
    )

    provenance = _attempt_provenance(protocol, source)
    records = tuple(
        AttemptRecord(
            model=protocol.model,
            condition_level=capability.condition_level,
            training_data=capability.training_dataset,
            condition=condition,
            sample_index=0,
            registered_seed=registered_sample_seed(condition, 0),
            status=AttemptStatus.FAILED,
            failure_code=code,
            failure_message=message,
            structure=None,
            generation_latency_seconds=None,
            peak_ram_bytes=None,
            peak_vram_bytes=None,
            retry_count=0,
            refill_count=0,
            provenance=provenance,
            training_seed=None,
        )
        for condition in conditions
    )
    return validate_formal_attempts(records, conditions, samples_per_condition=1)


def _expected_row_header(
    protocol: TrackBProtocol, condition: Any, provenance: Mapping[str, Any]
) -> dict[str, Any]:
    condition_dict = condition.to_dict()
    return {
        "schema_version": ROW_SCHEMA,
        "model": protocol.model,
        "condition_level": protocol.condition_level,
        "condition_id": condition.condition_id,
        "attempt_index": condition.attempt_index,
        "sample_index": 0,
        "registered_seed": condition.condition_seed,
        "condition_input": _condition_input(protocol, condition_dict),
        "protocol": dict(protocol.protocol),
        "retry_count": 0,
        "refill_count": 0,
        "provenance": dict(provenance),
    }


def _row_provenance_matches(
    received: object,
    expected: Mapping[str, Any],
    expected_checkpoint_path: Path,
) -> bool:
    if not isinstance(received, Mapping) or set(received) != set(expected):
        return False
    try:
        _canonical_receipt_path(received.get("checkpoint_path"), expected_checkpoint_path)
    except ValueError:
        return False
    return all(
        received.get(name) == value for name, value in expected.items() if name != "checkpoint_path"
    )


def _validate_receipt(
    *,
    receipt: Any,
    protocol: TrackBProtocol,
    output: Path,
    rows: Sequence[Any],
    expected_official_checkout: Path,
    expected_checkpoint: Path,
    expected_companions: Mapping[str, Path],
    expected_manifest: Path,
    expected_manifest_sha256: str,
) -> str:
    if not isinstance(receipt, Mapping) or set(receipt) != _RECEIPT_KEYS:
        raise ValueError("driver receipt keys drifted")
    status = receipt.get("status")
    if status not in {"COMPLETE", "ABORTED"}:
        raise ValueError("driver receipt status drifted")
    row_count = len(rows)
    if set(expected_companions) != set(protocol.companion_sha256):
        raise ValueError("registered companion path mapping drifted")
    companion_artifacts = receipt.get("companion_artifacts")
    if (
        not isinstance(companion_artifacts, Mapping)
        or set(companion_artifacts) != set(protocol.companion_sha256)
        or any(
            not isinstance(companion_artifacts[name], Mapping)
            or set(companion_artifacts[name]) != {"path", "sha256"}
            or companion_artifacts[name].get("sha256") != digest
            for name, digest in protocol.companion_sha256.items()
        )
    ):
        raise ValueError("driver receipt companion provenance drifted")
    _canonical_receipt_path(receipt.get("official_checkout"), expected_official_checkout)
    _canonical_receipt_path(receipt.get("checkpoint_path"), expected_checkpoint)
    for name, path in expected_companions.items():
        _canonical_receipt_path(companion_artifacts[name].get("path"), path)
    _verified_artifacts(
        protocol=protocol,
        official_checkout=expected_official_checkout,
        checkpoint_path=expected_checkpoint,
        companion_paths=expected_companions,
    )
    expected = {
        "schema_version": RECEIPT_SCHEMA,
        "model": protocol.model,
        "condition_level": protocol.condition_level,
        "official_repository": protocol.official_repository,
        "official_commit": protocol.official_commit,
        "checkpoint": protocol.checkpoint,
        "checkpoint_sha256": protocol.checkpoint_sha256,
        "expected_condition_count": EXPECTED_CONDITION_COUNT,
        "sample_index": 0,
        "attempt_count": row_count,
        "retry_count": 0,
        "refill_count": 0,
        "checkpoint_load_attempt_count": 1,
        "sample_call_count": row_count,
        "rng_reset_count": row_count,
        "batch_size": 1,
        "protocol": dict(protocol.protocol),
        "device": "cuda",
    }
    if any(receipt.get(name) != value for name, value in expected.items()):
        raise ValueError("driver receipt header drifted")
    _canonical_receipt_path(receipt.get("output_jsonl_path"), output)
    if receipt.get("output_jsonl_sha256") != _sha256_file(output):
        raise ValueError("driver receipt output hash drifted")
    environment = receipt.get("environment")
    if not isinstance(environment, Mapping) or any(
        environment.get(name) != value for name, value in protocol.environment.items()
    ):
        raise ValueError("driver receipt environment drifted")
    _canonical_receipt_path(receipt.get("condition_manifest_path"), expected_manifest)
    if (
        _SHA256.fullmatch(expected_manifest_sha256) is None
        or receipt.get("condition_manifest_sha256") != expected_manifest_sha256
        or not expected_manifest.is_file()
        or _sha256_file(expected_manifest) != expected_manifest_sha256
    ):
        raise ValueError("driver receipt condition manifest drifted")
    if any(not isinstance(row, Mapping) for row in rows):
        raise ValueError("driver output row is malformed")
    generated_count = sum(row.get("status") == "GENERATED" for row in rows)
    failed_count = sum(row.get("status") == "FAILED" for row in rows)
    if (
        generated_count + failed_count != row_count
        or receipt.get("generated_count") != generated_count
        or receipt.get("failed_count") != failed_count
    ):
        raise ValueError("driver receipt attempt counts drifted")
    if status == "COMPLETE":
        if (
            row_count != EXPECTED_CONDITION_COUNT
            or receipt.get("denominator_complete") is not True
            or receipt.get("checkpoint_load_count") != 1
            or receipt.get("abort_code") is not None
        ):
            raise ValueError("complete driver denominator drifted")
    elif (
        not 0 <= row_count < EXPECTED_CONDITION_COUNT
        or receipt.get("denominator_complete") is not False
        or receipt.get("checkpoint_load_count") != (0 if row_count == 0 else 1)
        or receipt.get("abort_code") not in {"UNRECOVERABLE_OOM", "UNRECOVERABLE_NAN"}
    ):
        raise ValueError("aborted driver denominator drifted")
    return str(status)


def import_official_track_b_driver_output(
    *,
    model: str,
    conditions: Sequence[Any],
    output_jsonl_path: str | Path,
    driver_receipt_path: str | Path,
    expected_official_checkout_path: str | Path,
    expected_checkpoint_path: str | Path,
    expected_companion_paths: Mapping[str, str | Path],
    expected_condition_manifest_path: str | Path,
    expected_driver_receipt_sha256: str,
    expected_condition_manifest_sha256: str,
) -> tuple[Any, ...]:
    try:
        protocol = TRACK_B_PROTOCOLS[model]
    except KeyError:
        raise ValueError(f"unsupported official Track B model: {model}") from None
    capability = _capability(protocol)
    frozen_conditions = tuple(conditions)
    if len(frozen_conditions) != EXPECTED_CONDITION_COUNT or [
        condition.attempt_index for condition in frozen_conditions
    ] != list(range(EXPECTED_CONDITION_COUNT)):
        raise ValueError("importer requires 300 unique ordered conditions")
    output = Path(output_jsonl_path).resolve()
    receipt_path = Path(driver_receipt_path).resolve()
    expected_checkout = Path(expected_official_checkout_path).resolve()
    expected_checkpoint = Path(expected_checkpoint_path).resolve()
    expected_companions = {
        name: Path(path).resolve() for name, path in expected_companion_paths.items()
    }
    expected_manifest = Path(expected_condition_manifest_path).resolve()
    source = output if output.is_file() else None
    if not output.is_file() or not receipt_path.is_file():
        return _failure_cohort(
            protocol=protocol,
            capability=capability,
            conditions=frozen_conditions,
            code="DRIVER_ARTIFACT_MISSING",
            message="official Track B output or receipt is missing",
            source=source,
        )
    try:
        if (
            _SHA256.fullmatch(expected_driver_receipt_sha256) is None
            or _sha256_file(receipt_path) != expected_driver_receipt_sha256
        ):
            raise ValueError("driver receipt differs from externally registered SHA-256")
        receipt = _json_loads(receipt_path.read_text(encoding="utf-8"))
        rows = [
            _json_loads(line)
            for line in output.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        receipt_status = _validate_receipt(
            receipt=receipt,
            protocol=protocol,
            output=output,
            rows=rows,
            expected_official_checkout=expected_checkout,
            expected_checkpoint=expected_checkpoint,
            expected_companions=expected_companions,
            expected_manifest=expected_manifest,
            expected_manifest_sha256=expected_condition_manifest_sha256,
        )
        manifest_conditions = _load_conditions(
            expected_manifest, expected_condition_manifest_sha256
        )
        if [item.to_dict() for item in frozen_conditions] != list(manifest_conditions):
            raise ValueError("registered conditions differ from audited condition manifest")
    except Exception as error:
        return _failure_cohort(
            protocol=protocol,
            capability=capability,
            conditions=frozen_conditions,
            code="DRIVER_RECEIPT_DRIFT",
            message=f"{type(error).__name__}: {error}",
            source=source,
        )
    row_provenance = _row_provenance(
        protocol,
        expected_checkpoint,
        receipt["companion_artifacts"],
    )
    for row, condition in zip(rows, frozen_conditions, strict=False):
        expected_header = _expected_row_header(protocol, condition, row_provenance)
        if (
            not isinstance(row, Mapping)
            or set(row) != _ROW_KEYS
            or any(
                row.get(name) != value
                for name, value in expected_header.items()
                if name != "provenance"
            )
            or not _row_provenance_matches(
                row.get("provenance"), row_provenance, expected_checkpoint
            )
        ):
            return _failure_cohort(
                protocol=protocol,
                capability=capability,
                conditions=frozen_conditions,
                code="CONDITION_MAPPING_DRIFT",
                message="official Track B row mapping or condition input drifted",
                source=output,
            )
    if (
        receipt_status == "ABORTED"
        and rows
        and rows[-1].get("failure_code") != receipt.get("abort_code")
    ):
        return _failure_cohort(
            protocol=protocol,
            capability=capability,
            conditions=frozen_conditions,
            code="CONDITION_MAPPING_DRIFT",
            message="aborted official Track B row does not match abort receipt",
            source=output,
        )

    from crysalis_g1.external_benchmark.records import (
        AttemptRecord,
        AttemptStatus,
        StructurePayload,
        registered_sample_seed,
        validate_formal_attempts,
    )

    provenance = _attempt_provenance(protocol, output)
    records: list[Any] = []
    for index, condition in enumerate(frozen_conditions):
        if index >= len(rows):
            records.append(
                AttemptRecord(
                    model=protocol.model,
                    condition_level=capability.condition_level,
                    training_data=capability.training_dataset,
                    condition=condition,
                    sample_index=0,
                    registered_seed=registered_sample_seed(condition, 0),
                    status=AttemptStatus.FAILED,
                    failure_code="NOT_ATTEMPTED_PROCESS_ABORTED",
                    failure_message=(
                        f"official process aborted after {len(rows)} retained attempts"
                    ),
                    structure=None,
                    generation_latency_seconds=None,
                    peak_ram_bytes=None,
                    peak_vram_bytes=None,
                    retry_count=0,
                    refill_count=0,
                    provenance=provenance,
                    training_seed=None,
                )
            )
            continue
        row = rows[index]
        status = AttemptStatus.FAILED
        structure = None
        failure_code = row.get("failure_code")
        failure_message = row.get("failure_message")
        latency = row.get("generation_latency_seconds")
        if row.get("status") == "GENERATED":
            try:
                structure = StructurePayload.from_dict(row["structure"])
            except Exception as error:
                failure_code = "STRUCTURE_PARSE_FAILED"
                failure_message = f"{type(error).__name__}: {error}"
                latency = None
            else:
                status = AttemptStatus.GENERATED
                failure_code = None
                failure_message = None
        elif row.get("status") != "FAILED":
            failure_code = "DRIVER_ROW_STATUS_DRIFT"
            failure_message = f"invalid official row status: {row.get('status')!r}"
            latency = None
        try:
            record = AttemptRecord(
                model=protocol.model,
                condition_level=capability.condition_level,
                training_data=capability.training_dataset,
                condition=condition,
                sample_index=0,
                registered_seed=registered_sample_seed(condition, 0),
                status=status,
                failure_code=failure_code,
                failure_message=failure_message,
                structure=structure,
                generation_latency_seconds=latency,
                peak_ram_bytes=None,
                peak_vram_bytes=None,
                retry_count=0,
                refill_count=0,
                provenance=provenance,
                training_seed=None,
            )
        except Exception as error:
            record = AttemptRecord(
                model=protocol.model,
                condition_level=capability.condition_level,
                training_data=capability.training_dataset,
                condition=condition,
                sample_index=0,
                registered_seed=registered_sample_seed(condition, 0),
                status=AttemptStatus.FAILED,
                failure_code="DRIVER_ROW_PARSE_FAILED",
                failure_message=f"{type(error).__name__}: {error}",
                structure=None,
                generation_latency_seconds=None,
                peak_ram_bytes=None,
                peak_vram_bytes=None,
                retry_count=0,
                refill_count=0,
                provenance=provenance,
                training_seed=None,
            )
        records.append(record)
    return validate_formal_attempts(records, frozen_conditions, samples_per_condition=1)


def _parse_companions(values: Iterable[str]) -> dict[str, Path]:
    companions: dict[str, Path] = {}
    for value in values:
        name, separator, raw_path = value.partition("=")
        if not separator or not name or not raw_path or name in companions:
            raise ValueError("--companion must be a unique NAME=PATH value")
        companions[name] = Path(raw_path)
    return companions


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Pinned official MatterGen/CrystalFlow/DiffCSP Track B driver"
    )
    parser.add_argument("--model", required=True, choices=tuple(TRACK_B_PROTOCOLS))
    parser.add_argument("--condition-manifest", required=True)
    parser.add_argument("--condition-manifest-sha256", required=True)
    parser.add_argument("--official-checkout", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--companion", action="append", default=[], metavar="NAME=PATH")
    parser.add_argument("--output-jsonl", required=True)
    parser.add_argument("--receipt", required=True)
    parser.add_argument("--device", default="cuda", choices=("cuda",))
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    run_driver(
        model=args.model,
        condition_manifest_path=args.condition_manifest,
        expected_condition_sha256=args.condition_manifest_sha256,
        official_checkout=args.official_checkout,
        checkpoint_path=args.checkpoint,
        companion_paths=_parse_companions(args.companion),
        output_jsonl_path=args.output_jsonl,
        receipt_path=args.receipt,
        device=args.device,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
