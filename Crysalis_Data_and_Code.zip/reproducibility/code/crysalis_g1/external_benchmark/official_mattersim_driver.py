from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence


SCHEMA_VERSION = "g1-official-mattersim-driver.1.0.0"
OUTPUT_SCHEMA_VERSION = "g1-official-mattersim-output.1.0.0"
OFFICIAL_MATTERGEN_COMMIT = "67afb22ea0dd0073aedfc85b30b94bea0ee21863"
OFFICIAL_MATTERSIM_COMMIT = "aedf510ec536cf24163edad4570eaceafdb7cb2b"
WEIGHT_SHA256 = "28b0b0b0f13efefee06b47ea4c9105a26bd3e2c8396da193430da96b3b49a8be"
TRI2024_SHA256 = "ab1b4426901ff7b0f8af6ee9c3cc0dd2fbe4b65c758ef2a95683071492d1c51d"
STABILITY_THRESHOLD_EV_PER_ATOM = 0.1
ASE_VERSION = "3.27.0"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _git(checkout: Path, *arguments: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ("git", *arguments),
        cwd=checkout,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
    )


def _verify_checkout(checkout: Path, expected_commit: str, *, label: str) -> None:
    if not checkout.is_dir():
        raise FileNotFoundError(f"{label} checkout is missing: {checkout}")
    head = _git(checkout, "rev-parse", "HEAD")
    if head.returncode != 0 or head.stdout.strip().lower() != expected_commit:
        raise ValueError(f"{label} checkout commit drifted")
    diff = _git(checkout, "diff", "--quiet", "--ignore-cr-at-eol", "HEAD", "--")
    untracked = _git(checkout, "ls-files", "--others", "--exclude-standard")
    if diff.returncode != 0 or untracked.returncode != 0 or untracked.stdout.strip():
        raise ValueError(f"{label} checkout is dirty")


def _atomic_json_new(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(f"immutable MatterSim artifact exists: {path}")
    data = (
        json.dumps(
            payload,
            allow_nan=False,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        + "\n"
    ).encode("utf-8")
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb",
            dir=path.parent,
            prefix=f".{path.name}.",
            delete=False,
        ) as stream:
            temporary = Path(stream.name)
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _load_input(path: Path, expected_sha256: str) -> tuple[list[str], list[Any]]:
    if not path.is_file() or _sha256(path) != expected_sha256:
        raise ValueError("MatterSim input hash drifted")
    payload = json.loads(path.read_text(encoding="utf-8"))
    rows = payload.get("structures") if isinstance(payload, Mapping) else None
    if (
        not isinstance(rows, list)
        or not rows
        or payload.get("schema_version") != "g1-mattersim-input.1.0.0"
    ):
        raise ValueError("MatterSim input is malformed")
    from pymatgen.core import Lattice, Structure

    identities: list[str] = []
    structures: list[Structure] = []
    for row in rows:
        structure = row.get("structure") if isinstance(row, Mapping) else None
        identity = row.get("attempt_id") if isinstance(row, Mapping) else None
        if not isinstance(identity, str) or not identity or not isinstance(structure, Mapping):
            raise ValueError("MatterSim input row is malformed")
        identities.append(identity)
        structures.append(
            Structure(
                Lattice(structure["lattice"]),
                structure["atomic_numbers"],
                structure["fractional_coordinates"],
                coords_are_cartesian=False,
                to_unit_cell=True,
            )
        )
    if len(identities) != len(set(identities)):
        raise ValueError("MatterSim input identities are duplicated")
    return identities, structures


def _finite(value: object, *, label: str) -> float:
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"MatterSim produced non-finite {label}")
    return normalized


def _verify_ase_version(observed: str) -> None:
    if observed != ASE_VERSION:
        raise RuntimeError(
            f"MatterSim ASE version mismatch: expected {ASE_VERSION}, observed {observed}"
        )


def _result_row(
    identity: str,
    summary: Any,
    *,
    energy_above_hull: object,
    stable: object,
    unique: object,
    novel: object,
) -> dict[str, Any]:
    try:
        energy = _finite(summary.entry.energy, label="energy")
        energy_per_atom = _finite(
            summary.entry.energy_per_atom,
            label="energy per atom",
        )
        rmsd = _finite(summary.rmsd_from_relaxation, label="relaxation RMSD")
        hull = _finite(energy_above_hull, label="energy above hull")
    except (TypeError, ValueError) as error:
        return {
            "attempt_id": identity,
            "status": "FAILED_PRESERVED",
            "energy": None,
            "energy_per_atom": None,
            "rmsd_from_relaxation": None,
            "energy_above_hull_ev_per_atom": None,
            "stable": None,
            "unique": None,
            "novel": None,
            "novel_unique_stable": None,
            "failure_code": "MATTERSIM_NONFINITE_RESULT",
            "failure_message": str(error),
        }
    is_stable = bool(stable)
    is_unique = bool(unique)
    is_novel = bool(novel)
    if is_stable != (hull <= STABILITY_THRESHOLD_EV_PER_ATOM):
        raise ValueError("MatterSim stable flag differs from registered threshold")
    return {
        "attempt_id": identity,
        "status": "EVALUATED",
        "energy": energy,
        "energy_per_atom": energy_per_atom,
        "rmsd_from_relaxation": rmsd,
        "energy_above_hull_ev_per_atom": hull,
        "stable": is_stable,
        "unique": is_unique,
        "novel": is_novel,
        "novel_unique_stable": bool(is_stable and is_unique and is_novel),
        "failure_code": None,
        "failure_message": None,
    }


def _run_cuda_smoke(
    structure,
    weight: Path,
    *,
    potential_class,
    build_dataloader,
    adaptor,
    array_module,
) -> None:
    atoms = adaptor.get_atoms(structure)
    potential = potential_class.from_checkpoint(
        load_path=str(weight),
        device="cuda",
    )
    dataloader = build_dataloader(
        [atoms],
        batch_size=1,
        only_inference=True,
    )
    prediction = potential.predict_properties(
        dataloader,
        include_forces=True,
        include_stresses=True,
    )
    if len(prediction) != 3 or any(
        not array_module.isfinite(array_module.asarray(values, dtype=float)).all()
        for values in prediction
    ):
        raise RuntimeError("MatterSim CUDA smoke test failed")


def run(arguments: argparse.Namespace) -> dict[str, Any]:
    input_path = Path(arguments.input_json).resolve()
    output_path = Path(arguments.output_json).resolve()
    receipt_path = Path(arguments.receipt).resolve()
    relaxed_path = Path(arguments.relaxed_extxyz).resolve()
    mattergen_checkout = Path(arguments.mattergen_checkout).resolve()
    mattersim_checkout = Path(arguments.mattersim_checkout).resolve()
    weight = Path(arguments.weight).resolve()
    reference_path = Path(arguments.reference_dataset).resolve()
    for target in (output_path, receipt_path, relaxed_path):
        if target.exists():
            raise FileExistsError(f"immutable MatterSim target exists: {target}")
    _verify_checkout(
        mattergen_checkout,
        OFFICIAL_MATTERGEN_COMMIT,
        label="MatterGen evaluation",
    )
    _verify_checkout(mattersim_checkout, OFFICIAL_MATTERSIM_COMMIT, label="MatterSim")
    if not weight.is_file() or _sha256(weight) != WEIGHT_SHA256:
        raise ValueError("MatterSim weight hash drifted")
    if not reference_path.is_file() or _sha256(reference_path) != TRI2024_SHA256:
        raise ValueError("TRI2024 reference hash drifted")
    identities, structures = _load_input(input_path, arguments.input_sha256)

    sys.path.insert(0, str(mattersim_checkout / "src"))
    sys.path.insert(0, str(mattergen_checkout))
    import ase
    import mattersim
    import mattergen
    import numpy as np
    import torch
    from mattersim.datasets.utils.build import build_dataloader
    from mattersim.forcefield.potential import Potential
    from mattergen.evaluation.metrics.evaluator import MetricsEvaluator
    from mattergen.evaluation.reference.correction_schemes import TRI110Compatibility2024
    from mattergen.evaluation.reference.reference_dataset_serializer import LMDBGZSerializer
    from mattergen.evaluation.utils.relaxation import relax_structures
    from mattergen.evaluation.utils.structure_matcher import (
        DefaultDisorderedStructureMatcher,
    )
    from pymatgen.io.ase import AseAtomsAdaptor

    _verify_ase_version(ase.__version__)
    if arguments.device != "cuda" or not torch.cuda.is_available():
        raise RuntimeError("registered MatterSim CUDA device is unavailable")
    started_at = _utc_now().isoformat()
    _run_cuda_smoke(
        structures[0],
        weight,
        potential_class=Potential,
        build_dataloader=build_dataloader,
        adaptor=AseAtomsAdaptor,
        array_module=np,
    )
    torch.cuda.empty_cache()

    relaxed_structures, energies = relax_structures(
        structures,
        device="cuda",
        potential_load_path=str(weight),
        output_path=str(relaxed_path),
    )
    if len(relaxed_structures) != len(identities) or len(energies) != len(identities):
        raise ValueError("MatterSim relaxed cohort denominator drifted")
    reference = LMDBGZSerializer().deserialize(str(reference_path))
    evaluator = MetricsEvaluator.from_structures_and_energies(
        structures=relaxed_structures,
        energies=energies,
        original_structures=structures,
        reference=reference,
        structure_matcher=DefaultDisorderedStructureMatcher(),
        energy_correction_scheme=TRI110Compatibility2024(),
        stability_threshold=STABILITY_THRESHOLD_EV_PER_ATOM,
    )
    energy_above_hull = evaluator.energy_capability.energy_above_hull
    stable = evaluator.is_stable
    unique = evaluator.is_unique
    novel = evaluator.is_novel
    summaries = evaluator.energy_capability._structure_summaries
    if any(len(values) != len(identities) for values in (energy_above_hull, stable, unique, novel)):
        raise ValueError("MatterSim metric denominator drifted")
    results: list[dict[str, Any]] = []
    for index, identity in enumerate(identities):
        results.append(
            _result_row(
                identity,
                summaries[index],
                energy_above_hull=energy_above_hull[index],
                stable=stable[index],
                unique=unique[index],
                novel=novel[index],
            )
        )
    ended_at = _utc_now().isoformat()
    output = {
        "schema_version": OUTPUT_SCHEMA_VERSION,
        "eligible_attempt_ids": identities,
        "eligible_attempt_count": len(identities),
        "smoke_test_status": "PASS",
        "weight_sha256": WEIGHT_SHA256,
        "tri2024_reference_sha256": TRI2024_SHA256,
        "stability_threshold_ev_per_atom": STABILITY_THRESHOLD_EV_PER_ATOM,
        "results": results,
    }
    _atomic_json_new(output_path, output)
    receipt = {
        "schema_version": SCHEMA_VERSION,
        "status": "COMPLETE",
        "official_mattergen_commit": OFFICIAL_MATTERGEN_COMMIT,
        "official_mattersim_commit": OFFICIAL_MATTERSIM_COMMIT,
        "input_json_sha256": arguments.input_sha256,
        "output_json_sha256": _sha256(output_path),
        "relaxed_extxyz_sha256": _sha256(relaxed_path),
        "weight_sha256": WEIGHT_SHA256,
        "tri2024_reference_sha256": TRI2024_SHA256,
        "eligible_attempt_count": len(identities),
        "smoke_test_status": "PASS",
        "started_at": started_at,
        "ended_at": ended_at,
        "device": "cuda",
        "environment": {
            "python": sys.version.split()[0],
            "torch": torch.__version__,
            "mattergen": getattr(mattergen, "__version__", "unknown"),
            "mattersim": getattr(mattersim, "__version__", "unknown"),
            "ase": ase.__version__,
            "cuda_runtime": str(torch.version.cuda),
        },
        "retry_count": 0,
        "refill_count": 0,
    }
    _atomic_json_new(receipt_path, receipt)
    return receipt


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Pinned official MatterSim secondary evaluator")
    parser.add_argument("--input-json", required=True)
    parser.add_argument("--input-sha256", required=True)
    parser.add_argument("--mattergen-checkout", required=True)
    parser.add_argument("--mattersim-checkout", required=True)
    parser.add_argument("--weight", required=True)
    parser.add_argument("--reference-dataset", required=True)
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--relaxed-extxyz", required=True)
    parser.add_argument("--receipt", required=True)
    parser.add_argument("--device", choices=("cuda",), default="cuda")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    receipt = run(build_parser().parse_args(argv))
    print(json.dumps(receipt, allow_nan=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
