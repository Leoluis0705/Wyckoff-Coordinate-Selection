from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import tempfile
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Mapping, Sequence

from crysalis_g1.external_benchmark.adapters import (
    AdapterPreflight,
    CommandReceipt,
    CommandSpec,
    build_command,
    emit_unsupported_attempts,
    execute_official_command,
    verify_adapter_preflight,
)
from crysalis_g1.external_benchmark.capabilities import (
    BaselineCapability,
    PrimaryTrack,
    official_capabilities,
)
from crysalis_g1.external_benchmark.config import ExternalBenchmarkConfig
from crysalis_g1.external_benchmark.official_track_b_driver import (
    RECEIPT_SCHEMA,
    TRACK_B_PROTOCOLS,
    TrackBProtocol,
    import_official_track_b_driver_output,
)
from crysalis_g1.external_benchmark.provenance import sha256_file
from crysalis_g1.external_benchmark.records import (
    AttemptRecord,
    load_registered_conditions_from_config,
    registered_sample_seed,
)
from crysalis_g1.external_benchmark.runner import (
    EXTERNAL_ARTIFACT_REGISTRY,
    StageAction,
    StageContext,
    StageResult,
)


DRIVER_SOURCE_COMMIT = "f78103b7afbddaaf943029888eb26409c5222986"
DRIVER_SOURCE_SHA256 = "8c39b7fab1b5d05a4869d6d9c18fc07794649452194aebde3b689c9048fc8c74"
RUNNABLE_MODELS = ("MatterGen", "CrystalFlow", "DiffCSP")
CLEAN_RUN_DIR = "other_baselines_clean_rerun_1"
REUSABLE_MATTERGEN_SHA256: Mapping[str, str] = {
    "raw": "d9d423b902f65a3ee5c27f74cdbf4e637fd22cdcf8eded81e6a030ba41e49822",
    "driver_receipt": "bf34871dfd13f1ef0f6d327947ce901461c47c530cd6e9b6b2ff19cb56e0a4ca",
    "stdout": "40fc8a4b9fd753fd4cf2468b71a2217aed551c137ee0cba20fc7ec967c93d27a",
    "stderr": "06c3d70fcc57871e5afa3b11df866bb991cfa318bd06aea6bddfbca05324d7f6",
    "command_receipt": "9a61cd7649e779c6e89e437d3fff0c52c43c4338af310af2df02f303813d5e76",
    "attempt_records": "fd43c006c53cb650cdedf12ff6eb61fb924ff5fa0d65601a09db3b5a5a8e7bb8",
    "model_evidence": "b7fd2309faadc621b42bd18fd435fa51dde3772229c2c0368c6faf2a6d0ed538",
}
_FATAL_ABORT_CODES = frozenset({"UNRECOVERABLE_OOM", "UNRECOVERABLE_NAN"})
_IMPORT_INTEGRITY_FAILURES = frozenset(
    {"DRIVER_ARTIFACT_MISSING", "DRIVER_RECEIPT_DRIFT", "CONDITION_MAPPING_DRIFT"}
)
_COMMIT = re.compile(r"[0-9a-f]{40}")
_SOURCE_BUNDLE_PATHS = (
    "crysalis_g1/external_benchmark/adapters.py",
    "crysalis_g1/external_benchmark/capabilities.py",
    "crysalis_g1/external_benchmark/config.py",
    "crysalis_g1/external_benchmark/official_track_b_driver.py",
    "crysalis_g1/external_benchmark/provenance.py",
    "crysalis_g1/external_benchmark/records.py",
    "crysalis_g1/external_benchmark/runner.py",
)


@dataclass(frozen=True, slots=True)
class _RuntimeLayout:
    checkout: Path
    checkpoint: Path
    companions: Mapping[str, Path]


@dataclass(frozen=True, slots=True)
class _VerifiedRuntime:
    capability: BaselineCapability
    protocol: TrackBProtocol
    layout: _RuntimeLayout
    preflight: AdapterPreflight


# Tests replace only this private process boundary. Formal callers cannot inject it.
_execute_official_command = execute_official_command


def _json_bytes(payload: object) -> bytes:
    return (
        json.dumps(
            payload,
            allow_nan=False,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        + "\n"
    ).encode("utf-8")


def _atomic_write_bytes_new(path: Path, content: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(f"immutable formal artifact already exists: {path}")
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb",
            dir=path.parent,
            prefix=f".{path.name}.",
            delete=False,
        ) as handle:
            temporary = Path(handle.name)
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.link(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _atomic_write_json_new(path: Path, payload: object) -> None:
    _atomic_write_bytes_new(path, _json_bytes(payload))


def _atomic_write_attempts_new(path: Path, attempts: Sequence[AttemptRecord]) -> None:
    _atomic_write_bytes_new(
        path,
        b"".join(_json_bytes(attempt.to_dict()) for attempt in attempts),
    )


def _load_json_object(path: Path, *, label: str) -> Mapping[str, Any]:
    try:
        payload = json.loads(
            path.read_text(encoding="utf-8"),
            parse_constant=lambda value: (_ for _ in ()).throw(
                ValueError(f"non-finite JSON constant: {value}")
            ),
        )
    except json.JSONDecodeError:
        raise ValueError(f"{label} is malformed") from None
    if not isinstance(payload, Mapping):
        raise ValueError(f"{label} must be an object")
    return payload


def _relative(config: ExternalBenchmarkConfig, path: Path) -> str:
    root = config.output_root.resolve()
    resolved = path.resolve()
    if not resolved.is_relative_to((root / "engineering").resolve()):
        raise ValueError(f"formal artifact is outside engineering: {resolved}")
    return resolved.relative_to(root).as_posix()


def _declaration(
    config: ExternalBenchmarkConfig,
    path: Path,
    *,
    record_count: int | None = None,
    expected_sha256: str | None = None,
    label: str | None = None,
) -> dict[str, Any]:
    observed_sha256 = sha256_file(path)
    if expected_sha256 is not None and observed_sha256 != expected_sha256:
        raise ValueError(f"{label or path.name} changed before evidence")
    declaration: dict[str, Any] = {
        "path": _relative(config, path),
        "sha256": observed_sha256,
    }
    if record_count is not None:
        declaration["record_count"] = record_count
    return declaration


def _git_head(repo_root: Path) -> str:
    completed = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=repo_root,
        check=True,
        shell=False,
        capture_output=True,
        text=True,
    )
    head = completed.stdout.strip().lower()
    if _COMMIT.fullmatch(head) is None:
        raise ValueError("formal action Git HEAD is malformed")
    return head


def _source_paths(repo_root: Path) -> dict[str, Path]:
    return {
        "crysalis_g1/external_benchmark/formal_other_baselines.py": Path(__file__).resolve(),
        **{name: (repo_root / name).resolve() for name in _SOURCE_BUNDLE_PATHS},
    }


def _source_status(repo_root: Path) -> str:
    completed = subprocess.run(
        [
            "git",
            "status",
            "--porcelain=v1",
            "--untracked-files=all",
            "--",
            *sorted(_source_paths(repo_root)),
        ],
        cwd=repo_root,
        check=True,
        shell=False,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def _require_clean_source_paths(repo_root: Path) -> None:
    status = _source_status(repo_root)
    if status:
        raise ValueError(f"execution-critical source paths are dirty: {status.splitlines()}")


def _source_bundle(repo_root: Path) -> dict[str, str]:
    paths = _source_paths(repo_root)
    for name, path in paths.items():
        if not path.is_file():
            raise FileNotFoundError(f"formal source dependency is missing: {name}: {path}")
    return {name: sha256_file(path) for name, path in sorted(paths.items())}


def _verify_source_state(
    repo_root: Path,
    expected_bundle: Mapping[str, str],
    *,
    phase: str,
) -> None:
    _require_clean_source_paths(repo_root)
    if _source_bundle(repo_root) != dict(expected_bundle):
        raise ValueError(f"formal other-baseline source bundle changed {phase}")


def _source_bundle_sha256(bundle: Mapping[str, str]) -> str:
    content = json.dumps(bundle, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(content).hexdigest()


def _driver_path(repo_root: Path) -> Path:
    path = (
        repo_root / "crysalis_g1" / "external_benchmark" / "official_track_b_driver.py"
    ).resolve()
    if not path.is_file() or sha256_file(path) != DRIVER_SOURCE_SHA256:
        raise ValueError("official Track B driver differs from pinned f78103b source")
    relative = path.relative_to(repo_root).as_posix()
    completed = subprocess.run(
        ["git", "diff", "--exit-code", DRIVER_SOURCE_COMMIT, "--", relative],
        cwd=repo_root,
        check=False,
        shell=False,
        capture_output=True,
        text=True,
    )
    if completed.returncode != 0:
        raise ValueError("official Track B driver differs from pinned f78103b commit")
    return path


def _read_frozen_preflight(config: ExternalBenchmarkConfig) -> tuple[Path, Mapping[str, Any]]:
    path = config.output_root.resolve() / "engineering" / "audit" / "frozen_preflight.json"
    if not path.is_file():
        raise FileNotFoundError(f"audit frozen_preflight.json is missing: {path}")
    return path, _load_json_object(path, label="audit frozen_preflight.json")


def _runtime_layouts(config: ExternalBenchmarkConfig) -> Mapping[str, _RuntimeLayout]:
    cache = config.official_artifact_cache.resolve()
    mattergen_root = cache / "checkpoints" / "mattergen_space_group_ea430eab"
    crystalflow_root = (
        cache
        / "checkpoints"
        / "crystalflow_v1.0.0-alpha.1"
        / "extracted"
        / "ckpt-v1.0.0"
        / "CSP-mp-20"
    )
    diffcsp_root = cache / "checkpoints" / "diffcsp_mp_csp"
    return {
        "MatterGen": _RuntimeLayout(
            checkout=cache / "repos" / "mattergen",
            checkpoint=mattergen_root / "checkpoints" / "last.ckpt",
            companions={"config": mattergen_root / "config.yaml"},
        ),
        "CrystalFlow": _RuntimeLayout(
            checkout=cache / "repos" / "CrystalFlow",
            checkpoint=crystalflow_root / "epoch=2462-step=261078.ckpt",
            companions={
                "hparams": crystalflow_root / "hparams.yaml",
                "lattice_scaler": crystalflow_root / "lattice_scaler.pt",
                "prop_scaler": crystalflow_root / "prop_scaler.pt",
                "prop_scalers": crystalflow_root / "prop_scalers.pt",
            },
        ),
        "DiffCSP": _RuntimeLayout(
            checkout=cache / "repos" / "DiffCSP_official",
            checkpoint=diffcsp_root / "last.ckpt",
            companions={"hparams": diffcsp_root / "hparams.yaml"},
        ),
    }


def _validate_registry_and_capability(
    model: str,
    protocol: TrackBProtocol,
) -> BaselineCapability:
    capabilities = [item for item in official_capabilities() if item.model == model]
    if len(capabilities) != 1:
        raise ValueError(f"exactly one official capability is required: {model}")
    capability = capabilities[0]
    if (
        capability.primary_track is not PrimaryTrack.TRACK_B
        or capability.official_repository != protocol.official_repository
        or capability.official_commit != protocol.official_commit
        or capability.checkpoint != protocol.checkpoint
        or capability.checkpoint_sha256 != protocol.checkpoint_sha256
        or capability.condition_level.value != protocol.condition_level
        or capability.training_dataset != protocol.training_data
    ):
        raise ValueError(f"{model} capability differs from the pinned official driver")
    registry = EXTERNAL_ARTIFACT_REGISTRY.get(model)
    if not isinstance(registry, Mapping) or (
        registry.get("official_commit") != protocol.official_commit
        or registry.get("checkpoint_sha256") != protocol.checkpoint_sha256
    ):
        raise ValueError(f"{model} runner registry differs from the pinned official driver")
    if (
        model == "MatterGen"
        and registry.get("config_sha256") != (protocol.companion_sha256["config"])
    ):
        raise ValueError("MatterGen companion registry drifted")
    if model == "CrystalFlow" and (
        registry.get("hparams_sha256") != protocol.companion_sha256["hparams"]
        or registry.get("scaler_sha256")
        != {
            name: protocol.companion_sha256[name]
            for name in ("lattice_scaler", "prop_scaler", "prop_scalers")
        }
    ):
        raise ValueError("CrystalFlow companion registry drifted")
    if (
        model == "DiffCSP"
        and registry.get("hparams_sha256") != (protocol.companion_sha256["hparams"])
    ):
        raise ValueError("DiffCSP companion registry drifted")
    return capability


def _verified_runtime(
    config: ExternalBenchmarkConfig,
    frozen_preflight: Mapping[str, Any],
    model: str,
) -> _VerifiedRuntime:
    protocol = TRACK_B_PROTOCOLS[model]
    capability = _validate_registry_and_capability(model, protocol)
    layout = _runtime_layouts(config)[model]
    preflight = verify_adapter_preflight(
        config=config,
        frozen_preflight_receipt=frozen_preflight,
        capability=capability,
        official_checkout=layout.checkout,
        checkpoint_path=layout.checkpoint,
        expected_checkpoint_sha256=protocol.checkpoint_sha256,
        requested_track=PrimaryTrack.TRACK_B,
    )
    if set(layout.companions) != set(protocol.companion_sha256):
        raise ValueError(f"{model} companion artifact set drifted")
    for name, expected in protocol.companion_sha256.items():
        path = layout.companions[name].resolve()
        if not path.is_file():
            raise FileNotFoundError(f"{model} companion artifact is missing: {name}: {path}")
        if sha256_file(path) != expected:
            raise ValueError(f"{model} companion artifact hash drifted: {name}")
    return _VerifiedRuntime(
        capability=capability,
        protocol=protocol,
        layout=layout,
        preflight=preflight,
    )


def _windows_to_wsl(path: Path) -> str:
    resolved = str(path.resolve())
    match = re.fullmatch(r"([A-Za-z]):\\(.*)", resolved)
    if match is None or "/" in resolved or "\x00" in resolved:
        raise ValueError(f"path is not a canonical absolute Windows path: {resolved}")
    segments = [] if not match.group(2) else match.group(2).split("\\")
    if any(
        not segment
        or segment in {".", ".."}
        or any(character in segment for character in '<>:"|?*')
        for segment in segments
    ):
        raise ValueError(f"path cannot be mapped canonically into WSL: {resolved}")
    suffix = "" if not segments else "/" + "/".join(segments)
    return f"/mnt/{match.group(1).lower()}{suffix}"


def _run_root(context: StageContext) -> Path:
    return (context.engineering_root / CLEAN_RUN_DIR).resolve()


def _model_paths(context: StageContext, model: str) -> dict[str, Path]:
    root = _run_root(context) / model
    return {
        "raw": root / "raw_driver_rows.jsonl",
        "driver_receipt": root / "driver_receipt.json",
        "stdout": root / "stdout.log",
        "stderr": root / "stderr.log",
        "command_receipt": root / "command_receipt.json",
        "attempt_records": root / "attempt_records.jsonl",
        "model_evidence": root / "model_evidence.json",
    }


def _all_targets(context: StageContext) -> tuple[Path, ...]:
    model_targets = tuple(
        path for model in RUNNABLE_MODELS for path in _model_paths(context, model).values()
    )
    return (*model_targets, _run_root(context) / "attempt_records.jsonl")


def _refuse_existing_targets(context: StageContext) -> None:
    mattergen_paths = _model_paths(context, "MatterGen")
    mattergen_targets = set(mattergen_paths.values())
    for path in _all_targets(context):
        if path not in mattergen_targets and path.exists():
            raise FileExistsError(f"immutable formal artifact already exists: {path}")
    existing_mattergen = {name for name, path in mattergen_paths.items() if path.exists()}
    if existing_mattergen and existing_mattergen != set(mattergen_paths):
        raise FileExistsError("reusable MatterGen artifact set is incomplete")
    if existing_mattergen:
        for name, path in mattergen_paths.items():
            if not path.is_file() or sha256_file(path) != REUSABLE_MATTERGEN_SHA256[name]:
                raise ValueError(f"reusable MatterGen {name} artifact changed")


def _command_environment(
    context: StageContext,
    runtime: _VerifiedRuntime,
) -> dict[str, str]:
    if runtime.capability.model != "CrystalFlow":
        return {}
    root = _run_root(context) / "CrystalFlow" / "runtime"
    hydra = root / "hydra"
    wandb = root / "wandb"
    hydra.mkdir(parents=True, exist_ok=True)
    wandb.mkdir(parents=True, exist_ok=True)
    return {
        "HYDRA_JOBS": _windows_to_wsl(hydra),
        "PROJECT_ROOT": _windows_to_wsl(runtime.layout.checkout),
        "TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD": "1",
        "WANDB_DIR": _windows_to_wsl(wandb),
        "WSLENV": "PROJECT_ROOT:HYDRA_JOBS:WANDB_DIR:TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD",
    }


def _build_model_command(
    context: StageContext,
    *,
    config: ExternalBenchmarkConfig,
    repo_root: Path,
    runtime: _VerifiedRuntime,
    paths: Mapping[str, Path],
) -> CommandSpec:
    wsl = Path(r"C:\Windows\System32\wsl.exe").resolve()
    python_hosts = {
        "MatterGen": Path(r"D:\CGCNN\mattergen\.venv\bin\python"),
        "CrystalFlow": (
            config.official_artifact_cache.resolve()
            / "envs"
            / "crystalflow_wsl_py310_env"
            / "bin"
            / "python"
        ),
        "DiffCSP": Path(r"D:\CGCNN\external\diffcsp_wsl_py310_env\bin\python"),
    }
    guest_python_host = python_hosts[runtime.capability.model].resolve()
    driver = _driver_path(repo_root)
    if not wsl.is_file():
        raise FileNotFoundError(f"audited WSL executable is missing: {wsl}")
    if not os.path.lexists(guest_python_host):
        raise FileNotFoundError(
            f"audited Track B Python 3.10.20 executable is missing: {guest_python_host}"
        )
    guest_python = _windows_to_wsl(guest_python_host)
    arguments: list[str] = [
        "-d",
        "Ubuntu",
        "--exec",
        guest_python,
        _windows_to_wsl(driver),
        "--model",
        runtime.capability.model,
        "--condition-manifest",
        _windows_to_wsl(config.condition_manifest_path),
        "--condition-manifest-sha256",
        config.condition_manifest_sha256,
        "--official-checkout",
        _windows_to_wsl(runtime.layout.checkout),
        "--checkpoint",
        _windows_to_wsl(runtime.layout.checkpoint),
    ]
    for name in runtime.protocol.companion_sha256:
        arguments.extend(
            ("--companion", f"{name}={_windows_to_wsl(runtime.layout.companions[name])}")
        )
    arguments.extend(
        (
            "--output-jsonl",
            _windows_to_wsl(paths["raw"]),
            "--receipt",
            _windows_to_wsl(paths["driver_receipt"]),
            "--device",
            "cuda",
        )
    )
    return build_command(
        executable=wsl,
        arguments=arguments,
        cwd=runtime.layout.checkout,
        environment_overrides=_command_environment(context, runtime),
        device="cuda",
    )


def _validate_context(
    context: StageContext,
    *,
    config: ExternalBenchmarkConfig,
    repo_root: Path,
) -> None:
    if not isinstance(context, StageContext) or context.stage != "other_baselines":
        raise ValueError("formal action requires other_baselines StageContext")
    if context.config != config or context.repo_root.resolve() != repo_root:
        raise ValueError("formal action context differs from its frozen build inputs")
    if context.output_root.resolve() != config.output_root.resolve() or (
        context.engineering_root.resolve() != (config.output_root / "engineering").resolve()
    ):
        raise ValueError("formal action output roots drifted")


def _driver_status(path: Path, *, model: str) -> tuple[str, str | None]:
    payload = _load_json_object(path, label=f"{model} driver receipt")
    status = payload.get("status")
    abort_code = payload.get("abort_code")
    if (
        payload.get("schema_version") != RECEIPT_SCHEMA
        or payload.get("model") != model
        or status not in {"COMPLETE", "ABORTED"}
    ):
        raise ValueError(f"{model} driver receipt header drifted")
    if status == "COMPLETE" and abort_code is not None:
        raise ValueError(f"{model} complete driver receipt carries an abort code")
    if status == "ABORTED" and abort_code not in _FATAL_ABORT_CODES:
        raise ValueError(f"{model} driver abort code drifted")
    return str(status), None if abort_code is None else str(abort_code)


def _validate_driver_artifact_binding(
    paths: Mapping[str, Path],
    *,
    model: str,
    expected_raw_sha256: str,
    expected_driver_receipt_sha256: str,
    phase: str,
) -> None:
    raw_bytes = paths["raw"].read_bytes()
    receipt_bytes = paths["driver_receipt"].read_bytes()
    observed_raw_sha256 = hashlib.sha256(raw_bytes).hexdigest()
    observed_receipt_sha256 = hashlib.sha256(receipt_bytes).hexdigest()
    if observed_raw_sha256 != expected_raw_sha256:
        raise ValueError(f"{model} raw driver output changed {phase}")
    if observed_receipt_sha256 != expected_driver_receipt_sha256:
        raise ValueError(f"{model} driver receipt changed {phase}")
    try:
        receipt = json.loads(
            receipt_bytes.decode("utf-8"),
            parse_constant=lambda value: (_ for _ in ()).throw(
                ValueError(f"non-finite JSON constant: {value}")
            ),
        )
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise ValueError(f"{model} driver receipt is malformed {phase}") from None
    if not isinstance(receipt, Mapping):
        raise ValueError(f"{model} driver receipt must be an object {phase}")
    if receipt.get("output_jsonl_sha256") != observed_raw_sha256:
        raise ValueError(f"{model} raw driver output is not bound to driver receipt {phase}")


def _validate_completed_driver_artifacts(
    context: StageContext,
    digests: Mapping[str, tuple[str, str]],
    *,
    phase: str,
) -> None:
    for model, (raw_sha256, receipt_sha256) in digests.items():
        _validate_driver_artifact_binding(
            _model_paths(context, model),
            model=model,
            expected_raw_sha256=raw_sha256,
            expected_driver_receipt_sha256=receipt_sha256,
            phase=phase,
        )


def _validate_returned_command_receipt(
    command: CommandSpec,
    receipt: CommandReceipt,
    *,
    runtime: _VerifiedRuntime,
    paths: Mapping[str, Path],
) -> None:
    expected = {
        "argv": command.argv,
        "cwd": str(command.cwd),
        "executable": command.executable,
        "arguments": command.arguments,
        "shell": False,
        "environment_overrides": dict(command.environment_overrides),
        "runtime_versions": dict(runtime.protocol.environment),
        "official_commit": runtime.preflight.official_commit,
        "checkpoint_sha256": runtime.preflight.checkpoint_sha256,
        "device": command.device,
        "launch_count": 1,
        "retry_count": 0,
        "refill_count": 0,
    }
    observed = {
        "argv": receipt.argv,
        "cwd": receipt.cwd,
        "executable": receipt.executable,
        "arguments": receipt.arguments,
        "shell": receipt.shell,
        "environment_overrides": dict(receipt.environment_overrides),
        "runtime_versions": dict(receipt.runtime_versions),
        "official_commit": receipt.official_commit,
        "checkpoint_sha256": receipt.checkpoint_sha256,
        "device": receipt.device,
        "launch_count": receipt.launch_count,
        "retry_count": receipt.retry_count,
        "refill_count": receipt.refill_count,
    }
    if observed != expected:
        raise ValueError(
            f"{runtime.capability.model} command receipt differs from launched CommandSpec"
        )
    if (
        type(receipt.exit_code) is not int
        or type(receipt.peak_ram_bytes) is not int
        or receipt.peak_ram_bytes < 0
        or receipt.peak_vram_bytes is not None
    ):
        raise ValueError(f"{runtime.capability.model} command resource receipt drifted")
    timestamps: list[datetime] = []
    for value in (receipt.started_at, receipt.ended_at):
        if not isinstance(value, str):
            raise ValueError(f"{runtime.capability.model} command receipt timestamp is malformed")
        try:
            timestamp = datetime.fromisoformat(value)
        except ValueError:
            raise ValueError(
                f"{runtime.capability.model} command receipt timestamp is malformed"
            ) from None
        if timestamp.tzinfo is None or timestamp.utcoffset() != timedelta(0):
            raise ValueError(f"{runtime.capability.model} command receipt timestamp must be UTC")
        timestamps.append(timestamp)
    if timestamps[1] < timestamps[0]:
        raise ValueError(f"{runtime.capability.model} command receipt timestamp order drifted")
    for name in ("stdout", "stderr"):
        expected_path = paths[name].resolve()
        observed_path = Path(getattr(receipt, f"{name}_path")).resolve()
        observed_hash = getattr(receipt, f"{name}_sha256")
        if (
            observed_path != expected_path
            or not expected_path.is_file()
            or sha256_file(expected_path) != observed_hash
        ):
            raise ValueError(f"{runtime.capability.model} command receipt {name} artifact drifted")


def _model_evidence(
    runtime: _VerifiedRuntime,
    command: CommandReceipt,
    *,
    evidence_status: str,
) -> dict[str, Any]:
    if command.peak_vram_bytes is not None:
        raise ValueError("official Track B driver unexpectedly reported unregistered VRAM")
    return {
        "model": runtime.capability.model,
        "condition_level": runtime.capability.condition_level.value,
        "capability_execution_status": runtime.capability.execution_status.value,
        "attempt_count": 300,
        "denominator_complete": True,
        "evidence_status": evidence_status,
        "command_exit_code": command.exit_code,
        "peak_command_ram_bytes": command.peak_ram_bytes,
        "peak_command_vram_bytes": None,
        "peak_command_vram_status": "NOT_REPORTED_BY_OFFICIAL_DRIVER",
        "retry_count": 0,
        "refill_count": 0,
    }


def _run_model(
    context: StageContext,
    *,
    config: ExternalBenchmarkConfig,
    repo_root: Path,
    frozen_preflight: Mapping[str, Any],
    model: str,
    expected_source_bundle: Mapping[str, str],
) -> tuple[tuple[AttemptRecord, ...], CommandReceipt, dict[str, Any], tuple[Path, ...]]:
    runtime = _verified_runtime(config, frozen_preflight, model)
    paths = _model_paths(context, model)
    command = _build_model_command(
        context,
        config=config,
        repo_root=repo_root,
        runtime=runtime,
        paths=paths,
    )
    command_receipt = _execute_official_command(
        command,
        preflight=runtime.preflight,
        stdout_path=paths["stdout"],
        stderr_path=paths["stderr"],
        receipt_path=paths["command_receipt"],
        runtime_versions=runtime.protocol.environment,
    )
    if not isinstance(command_receipt, CommandReceipt):
        raise TypeError("official command boundary must return CommandReceipt")
    _verify_source_state(
        repo_root,
        expected_source_bundle,
        phase="during subprocess",
    )
    _validate_returned_command_receipt(
        command,
        command_receipt,
        runtime=runtime,
        paths=paths,
    )
    stored_command = _load_json_object(paths["command_receipt"], label=f"{model} command receipt")
    if stored_command != command_receipt.to_dict():
        raise ValueError(f"{model} command receipt artifact drifted")
    if not paths["raw"].is_file() or not paths["driver_receipt"].is_file():
        raise RuntimeError(
            f"{model} official command exited {command_receipt.exit_code} without "
            "complete immutable driver artifacts"
        )
    status, abort_code = _driver_status(paths["driver_receipt"], model=model)
    if (status == "COMPLETE" and command_receipt.exit_code != 0) or (
        status == "ABORTED" and command_receipt.exit_code == 0
    ):
        raise ValueError(f"{model} command exit and driver receipt status disagree")
    raw_sha256 = sha256_file(paths["raw"])
    receipt_sha256 = sha256_file(paths["driver_receipt"])
    conditions = load_registered_conditions_from_config(config)
    attempts = import_official_track_b_driver_output(
        model=model,
        conditions=conditions,
        output_jsonl_path=paths["raw"],
        driver_receipt_path=paths["driver_receipt"],
        expected_official_checkout_path=runtime.layout.checkout,
        expected_checkpoint_path=runtime.layout.checkpoint,
        expected_companion_paths=runtime.layout.companions,
        expected_condition_manifest_path=config.condition_manifest_path,
        expected_driver_receipt_sha256=receipt_sha256,
        expected_condition_manifest_sha256=config.condition_manifest_sha256,
    )
    _validate_driver_artifact_binding(
        paths,
        model=model,
        expected_raw_sha256=raw_sha256,
        expected_driver_receipt_sha256=receipt_sha256,
        phase="after import",
    )
    observed_integrity_failures = {
        attempt.failure_code
        for attempt in attempts
        if attempt.failure_code in _IMPORT_INTEGRITY_FAILURES
    }
    if observed_integrity_failures:
        raise ValueError(
            f"{model} driver receipt integrity failed: {sorted(observed_integrity_failures)}"
        )
    if len(attempts) != 300:
        raise ValueError(f"{model} imported attempt denominator drifted")
    _atomic_write_attempts_new(paths["attempt_records"], attempts)
    evidence_status = "FAILED_PRESERVED" if status == "ABORTED" else "COMPLETE"
    evidence = _model_evidence(
        runtime,
        command_receipt,
        evidence_status=evidence_status,
    )
    evidence.update(
        {
            "raw_driver_output": _declaration(
                config,
                paths["raw"],
                expected_sha256=raw_sha256,
                label=f"{model} raw driver output",
            ),
            "driver_receipt": _declaration(
                config,
                paths["driver_receipt"],
                expected_sha256=receipt_sha256,
                label=f"{model} driver receipt",
            ),
            "command_receipt_artifact": _declaration(config, paths["command_receipt"]),
            "attempt_records": _declaration(
                config, paths["attempt_records"], record_count=len(attempts)
            ),
        }
    )
    _atomic_write_json_new(paths["model_evidence"], evidence)
    if status == "ABORTED":
        raise RuntimeError(
            f"{model} official driver ABORTED with {abort_code}; benchmark paused "
            "after preserving the 300-attempt denominator"
        )
    return attempts, command_receipt, evidence, tuple(paths.values())


def _load_command_receipt_artifact(path: Path, *, model: str) -> CommandReceipt:
    payload = _load_json_object(path, label=f"{model} command receipt")
    try:
        receipt = CommandReceipt(
            argv=tuple(payload["argv"]),
            cwd=str(payload["cwd"]),
            executable=str(payload["executable"]),
            arguments=tuple(payload["arguments"]),
            shell=payload["shell"],
            environment_overrides=payload["environment_overrides"],
            runtime_versions=payload["runtime_versions"],
            official_commit=str(payload["official_commit"]),
            checkpoint_sha256=str(payload["checkpoint_sha256"]),
            started_at=str(payload["started_at"]),
            ended_at=str(payload["ended_at"]),
            exit_code=payload["exit_code"],
            stdout_path=str(payload["stdout_path"]),
            stdout_sha256=str(payload["stdout_sha256"]),
            stderr_path=str(payload["stderr_path"]),
            stderr_sha256=str(payload["stderr_sha256"]),
            device=str(payload["device"]),
            peak_ram_bytes=payload["peak_ram_bytes"],
            peak_vram_bytes=payload["peak_vram_bytes"],
            launch_count=payload["launch_count"],
            retry_count=payload["retry_count"],
            refill_count=payload["refill_count"],
        )
    except (KeyError, TypeError, ValueError):
        raise ValueError(f"{model} command receipt is malformed") from None
    if receipt.to_dict() != dict(payload):
        raise ValueError(f"{model} command receipt artifact drifted")
    return receipt


def _reuse_completed_mattergen(
    context: StageContext,
    *,
    config: ExternalBenchmarkConfig,
    repo_root: Path,
    frozen_preflight: Mapping[str, Any],
) -> tuple[tuple[AttemptRecord, ...], CommandReceipt, dict[str, Any], tuple[Path, ...]]:
    model = "MatterGen"
    runtime = _verified_runtime(config, frozen_preflight, model)
    paths = _model_paths(context, model)
    for name, expected_sha256 in REUSABLE_MATTERGEN_SHA256.items():
        path = paths[name]
        if not path.is_file() or sha256_file(path) != expected_sha256:
            raise ValueError(f"reusable MatterGen {name} artifact changed")
    command = _build_model_command(
        context,
        config=config,
        repo_root=repo_root,
        runtime=runtime,
        paths=paths,
    )
    command_receipt = _load_command_receipt_artifact(paths["command_receipt"], model=model)
    _validate_returned_command_receipt(
        command,
        command_receipt,
        runtime=runtime,
        paths=paths,
    )
    status, abort_code = _driver_status(paths["driver_receipt"], model=model)
    if status != "COMPLETE" or abort_code is not None or command_receipt.exit_code != 0:
        raise ValueError("reusable MatterGen completion status drifted")
    attempts = import_official_track_b_driver_output(
        model=model,
        conditions=load_registered_conditions_from_config(config),
        output_jsonl_path=paths["raw"],
        driver_receipt_path=paths["driver_receipt"],
        expected_official_checkout_path=runtime.layout.checkout,
        expected_checkpoint_path=runtime.layout.checkpoint,
        expected_companion_paths=runtime.layout.companions,
        expected_condition_manifest_path=config.condition_manifest_path,
        expected_driver_receipt_sha256=REUSABLE_MATTERGEN_SHA256["driver_receipt"],
        expected_condition_manifest_sha256=config.condition_manifest_sha256,
    )
    if len(attempts) != 300 or any(
        attempt.failure_code in _IMPORT_INTEGRITY_FAILURES for attempt in attempts
    ):
        raise ValueError("reusable MatterGen attempt denominator or integrity drifted")
    expected_attempt_bytes = b"".join(_json_bytes(attempt.to_dict()) for attempt in attempts)
    if paths["attempt_records"].read_bytes() != expected_attempt_bytes:
        raise ValueError("reusable MatterGen attempt records changed")
    _validate_driver_artifact_binding(
        paths,
        model=model,
        expected_raw_sha256=REUSABLE_MATTERGEN_SHA256["raw"],
        expected_driver_receipt_sha256=REUSABLE_MATTERGEN_SHA256["driver_receipt"],
        phase="during continuation",
    )
    expected_evidence = _model_evidence(
        runtime,
        command_receipt,
        evidence_status="COMPLETE",
    )
    expected_evidence.update(
        {
            "raw_driver_output": _declaration(
                config,
                paths["raw"],
                expected_sha256=REUSABLE_MATTERGEN_SHA256["raw"],
            ),
            "driver_receipt": _declaration(
                config,
                paths["driver_receipt"],
                expected_sha256=REUSABLE_MATTERGEN_SHA256["driver_receipt"],
            ),
            "command_receipt_artifact": _declaration(
                config,
                paths["command_receipt"],
                expected_sha256=REUSABLE_MATTERGEN_SHA256["command_receipt"],
            ),
            "attempt_records": _declaration(
                config,
                paths["attempt_records"],
                record_count=len(attempts),
                expected_sha256=REUSABLE_MATTERGEN_SHA256["attempt_records"],
            ),
        }
    )
    stored_evidence = _load_json_object(paths["model_evidence"], label="MatterGen model evidence")
    if dict(stored_evidence) != expected_evidence:
        raise ValueError("reusable MatterGen model evidence changed")
    return attempts, command_receipt, expected_evidence, tuple(paths.values())


def _unsupported_evidence(capability: BaselineCapability) -> dict[str, Any]:
    return {
        "model": capability.model,
        "condition_level": capability.condition_level.value,
        "capability_execution_status": capability.execution_status.value,
        "attempt_count": 300,
        "denominator_complete": True,
        "evidence_status": "UNSUPPORTED",
        "peak_command_ram_bytes": None,
        "peak_command_vram_bytes": None,
        "peak_command_vram_status": "NOT_APPLICABLE_NO_OFFICIAL_COMMAND",
        "retry_count": 0,
        "refill_count": 0,
    }


def _registered_attempt_ids(config: ExternalBenchmarkConfig) -> tuple[str, ...]:
    conditions = load_registered_conditions_from_config(config)
    return tuple(
        f"{capability.model}/training-none/{condition.condition_id}/sample-0/seed-"
        f"{registered_sample_seed(condition, 0)}"
        for capability in official_capabilities()
        if capability.model != "CrystalFormer"
        for condition in conditions
    )


def build_other_baselines_action(
    config: ExternalBenchmarkConfig,
    repo_root: str | Path,
) -> StageAction:
    if not isinstance(config, ExternalBenchmarkConfig):
        raise TypeError("formal other-baseline action requires ExternalBenchmarkConfig")
    repo = Path(repo_root).resolve()
    if not repo.is_dir():
        raise FileNotFoundError(f"repository root is missing: {repo}")
    load_registered_conditions_from_config(config)
    driver = _driver_path(repo)
    build_head = _git_head(repo)
    _require_clean_source_paths(repo)
    source_bundle = _source_bundle(repo)
    source_bundle_sha256 = _source_bundle_sha256(source_bundle)
    module_sha256 = source_bundle["crysalis_g1/external_benchmark/formal_other_baselines.py"]
    driver_sha256 = sha256_file(driver)

    def execute(context: StageContext) -> StageResult:
        _validate_context(context, config=config, repo_root=repo)
        if _git_head(repo) != build_head or sha256_file(driver) != driver_sha256:
            raise ValueError("formal other-baseline action source changed after registration")
        _verify_source_state(repo, source_bundle, phase="after registration")
        _refuse_existing_targets(context)
        frozen_preflight_path, frozen_preflight = _read_frozen_preflight(config)
        frozen_preflight_sha256 = sha256_file(frozen_preflight_path)
        conditions = load_registered_conditions_from_config(config)
        attempts: list[AttemptRecord] = []
        evidence_rows: list[dict[str, Any]] = []
        commands: list[Mapping[str, Any]] = []
        outputs: list[Path] = []
        verified_driver_digests: dict[str, tuple[str, str]] = {}
        for capability in official_capabilities():
            if capability.model == "CrystalFormer":
                continue
            if capability.model in RUNNABLE_MODELS:
                _validate_completed_driver_artifacts(
                    context,
                    verified_driver_digests,
                    phase="before next model launch",
                )
                if sha256_file(frozen_preflight_path) != frozen_preflight_sha256:
                    raise ValueError("audit frozen_preflight.json changed during execution")
                if capability.model == "MatterGen" and all(
                    path.is_file() for path in _model_paths(context, capability.model).values()
                ):
                    model_attempts, command, evidence, model_outputs = _reuse_completed_mattergen(
                        context,
                        config=config,
                        repo_root=repo,
                        frozen_preflight=frozen_preflight,
                    )
                else:
                    model_attempts, command, evidence, model_outputs = _run_model(
                        context,
                        config=config,
                        repo_root=repo,
                        frozen_preflight=frozen_preflight,
                        model=capability.model,
                        expected_source_bundle=source_bundle,
                    )
                attempts.extend(model_attempts)
                evidence_rows.append(evidence)
                verified_driver_digests[capability.model] = (
                    str(evidence["raw_driver_output"]["sha256"]),
                    str(evidence["driver_receipt"]["sha256"]),
                )
                commands.append(command.to_dict())
                outputs.extend(model_outputs)
            else:
                unsupported = emit_unsupported_attempts(capability, conditions)
                attempts.extend(unsupported)
                evidence_rows.append(_unsupported_evidence(capability))
        _validate_completed_driver_artifacts(
            context,
            verified_driver_digests,
            phase="before stage evidence",
        )
        if len(attempts) != 2400:
            raise ValueError("other-baseline retained attempt denominator drifted")
        combined_path = _run_root(context) / "attempt_records.jsonl"
        _atomic_write_attempts_new(combined_path, attempts)
        outputs.append(combined_path)
        evidence = {
            "stage_status": "COMPLETE",
            "baseline_records": evidence_rows,
            "attempt_records": _declaration(config, combined_path, record_count=len(attempts)),
            "frozen_preflight": _declaration(config, frozen_preflight_path),
            "official_artifacts": {
                model: dict(EXTERNAL_ARTIFACT_REGISTRY[model]) for model in sorted(RUNNABLE_MODELS)
            },
            "driver_source": {
                "commit": DRIVER_SOURCE_COMMIT,
                "path": str(driver),
                "sha256": driver_sha256,
            },
            "action_source": {
                "git_head": build_head,
                "module_path": str(Path(__file__).resolve()),
                "module_sha256": module_sha256,
                "source_bundle": dict(source_bundle),
                "source_bundle_sha256": source_bundle_sha256,
            },
            "retry_count": 0,
            "refill_count": 0,
        }
        for model in RUNNABLE_MODELS:
            _verified_runtime(config, frozen_preflight, model)
        if (
            sha256_file(frozen_preflight_path) != frozen_preflight_sha256
            or sha256_file(config.condition_manifest_path) != config.condition_manifest_sha256
        ):
            raise ValueError("formal frozen input changed before stage completion")
        _verify_source_state(repo, source_bundle, phase="before completion")
        _validate_completed_driver_artifacts(
            context,
            verified_driver_digests,
            phase="before stage completion",
        )
        return StageResult(
            outputs=tuple(outputs),
            evidence=evidence,
            command_receipts=tuple(commands),
        )

    reuse_sha256 = hashlib.sha256(
        json.dumps(
            REUSABLE_MATTERGEN_SHA256,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()
    action_id = (
        f"other-baselines:git-{build_head}:bundle-{source_bundle_sha256}:"
        f"module-{module_sha256}:"
        f"driver-{DRIVER_SOURCE_COMMIT}-{driver_sha256}:"
        f"reused-MatterGen-{reuse_sha256}"
    )
    return StageAction(
        action_id=action_id,
        execute=execute,
        registered_attempt_ids=_registered_attempt_ids(config),
    )
