from __future__ import annotations

import hashlib
import json
import subprocess
from pathlib import Path
from typing import Any, Mapping

from crysalis_g1.external_benchmark.config import ExternalBenchmarkConfig


TASK_OWNED_PATHS = (
    "configs/g1_full_crysalis_external_benchmark_20260826_v1.json",
    "crysalis_g1/external_benchmark/config.py",
    "crysalis_g1/external_benchmark/provenance.py",
    "tests/crysalis_g1/external_benchmark/test_config.py",
    "tests/crysalis_g1/external_benchmark/test_provenance.py",
)
FROZEN_CORE_ROOT = Path("crysalis_g1/full_crysalis")


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _read_json(path: Path, *, label: str) -> Mapping[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise FileNotFoundError(f"{label} is missing: {path}") from None
    if not isinstance(payload, Mapping):
        raise ValueError(f"{label} must be a JSON object")
    return payload


def _verify_hashes(expected: Mapping[str, str], *, root: Path, label: str) -> dict[str, str]:
    observed: dict[str, str] = {}
    for relative, digest in expected.items():
        path = root / relative
        if not path.is_file():
            raise FileNotFoundError(f"{label} is missing: {path}")
        actual = sha256_file(path)
        if actual != digest:
            raise ValueError(f"{label} hash mismatch: {relative}: expected {digest}, observed {actual}")
        observed[relative] = actual
    return observed


def _manifest_hash_map(
    manifest: Mapping[str, Any], *, key: str, label: str
) -> dict[str, str]:
    value = manifest.get(key)
    if not isinstance(value, Mapping) or not value:
        raise ValueError(f"{label} is missing or empty")
    result = {str(name): str(digest).lower() for name, digest in value.items()}
    if any(len(digest) != 64 for digest in result.values()):
        raise ValueError(f"{label} contains an invalid SHA-256")
    return result


def _source_boundary(repo_root: Path) -> dict[str, Any]:
    status = subprocess.check_output(
        ["git", "status", "--porcelain", "--", FROZEN_CORE_ROOT.as_posix()],
        cwd=repo_root,
        text=True,
    )
    changed_paths = [line[3:] for line in status.splitlines() if line]
    if changed_paths:
        raise ValueError(f"frozen core has working-tree changes: {changed_paths}")
    task_paths = [Path(path) for path in TASK_OWNED_PATHS]
    shadows = any(path.is_relative_to(FROZEN_CORE_ROOT) for path in task_paths)
    if shadows:
        raise ValueError("external benchmark task paths shadow frozen core")
    return {
        "task_owned_paths": list(TASK_OWNED_PATHS),
        "full_crysalis_changed_paths": changed_paths,
        "external_package_shadows_frozen_core": shadows,
    }


def preflight_frozen_inputs(config: ExternalBenchmarkConfig, repo_root: str | Path) -> dict[str, Any]:
    repo = Path(repo_root).resolve()
    replication = _read_json(config.replication_root / "FULL_REPLICATION_MANIFEST.json", label="replication manifest")
    if replication.get("FULL_CRYSALIS_REPLICATED_SIGNAL") != "SUPPORTED":
        raise ValueError("replication decision must remain SUPPORTED")
    if replication.get("reference_commit") != config.reference_commit:
        raise ValueError("replication reference commit drifted")
    if replication.get("full_generation_attempt_count") != config.formal_attempt_count:
        raise ValueError("replication formal attempt count drifted")
    if tuple(replication.get("training_seeds", ())) != config.training_seeds:
        raise ValueError("replication training seed identities drifted")
    if replication.get("condition_manifest_sha256") != config.condition_manifest_sha256:
        raise ValueError("condition manifest hash mismatch")
    if dict(replication.get("frozen_input_sha256", {})) != dict(config.frozen_artifact_sha256):
        raise ValueError("replication frozen artifact map drifted")
    replication_artifacts = _manifest_hash_map(
        replication, key="artifact_sha256", label="replication artifact map"
    )
    required_replication = replication.get("required_artifacts")
    if not isinstance(required_replication, list) or set(replication_artifacts) != (
        set(required_replication) - {"FULL_REPLICATION_MANIFEST.json"}
    ):
        raise ValueError("replication artifact map/root contract drifted")
    observed_replication_artifacts = _verify_hashes(
        replication_artifacts,
        root=config.replication_root,
        label="replication artifact",
    )

    positive_reference_artifacts = _manifest_hash_map(
        replication,
        key="positive_reference_artifact_sha256",
        label="positive reference artifact map",
    )
    positive_manifest = _read_json(
        config.positive_run_root / "FULL_CRYSALIS_MANIFEST.json",
        label="positive reference manifest",
    )
    positive_manifest_artifacts = _manifest_hash_map(
        positive_manifest,
        key="artifact_sha256",
        label="positive reference manifest artifact map",
    )
    expected_positive_manifest_artifacts = {
        name: digest
        for name, digest in positive_reference_artifacts.items()
        if name != "FULL_CRYSALIS_MANIFEST.json"
    }
    if positive_manifest_artifacts != expected_positive_manifest_artifacts:
        raise ValueError("positive reference artifact map/root contract drifted")
    observed_positive_reference_artifacts = _verify_hashes(
        positive_reference_artifacts,
        root=config.positive_run_root,
        label="positive reference artifact",
    )
    if Path(str(replication.get("reference_output_root", ""))).resolve() != (
        config.positive_run_root.resolve()
    ):
        raise ValueError("positive reference root drifted")

    base_path = repo / config.base_config_path
    if sha256_file(base_path) != config.base_config_sha256:
        raise ValueError("frozen base config hash mismatch")
    base = _read_json(base_path, label="frozen base config")
    artifacts = base.get("artifacts")
    if not isinstance(artifacts, Mapping):
        raise ValueError("frozen base config artifacts are missing")
    base_hashes = {str(name): str(item.get("sha256", "")).lower() for name, item in artifacts.items() if isinstance(item, Mapping)}
    if base_hashes != dict(config.frozen_artifact_sha256):
        raise ValueError("base frozen artifact map drifted")
    artifact_paths = {str(name): Path(str(item["path"])) for name, item in artifacts.items()}
    observed_artifacts = {}
    for name, expected in config.frozen_artifact_sha256.items():
        actual = sha256_file(artifact_paths[name])
        if actual != expected:
            raise ValueError(f"frozen artifact hash mismatch: {name}: expected {expected}, observed {actual}")
        observed_artifacts[name] = actual

    if sha256_file(config.condition_manifest_path) != config.condition_manifest_sha256:
        raise ValueError("condition manifest hash mismatch")
    condition_manifest = _read_json(config.condition_manifest_path, label="condition manifest")
    if condition_manifest.get("attempt_count") != config.condition_count or len(condition_manifest.get("conditions", ())) != config.condition_count:
        raise ValueError("condition manifest count drifted")
    for name, expected in config.condition_input.items():
        if condition_manifest.get(name) is not expected:
            raise ValueError(f"condition input flag drifted: {name}")

    expected_core = {name: digest for name, digest in replication.get("core_implementation_sha256", {}).items() if name.startswith(f"{FROZEN_CORE_ROOT.as_posix()}/")}
    if expected_core != dict(config.frozen_core_sha256):
        raise ValueError("replication frozen core map drifted")
    observed_core = _verify_hashes(config.frozen_core_sha256, root=repo, label="frozen core")
    boundary = _source_boundary(repo)
    return {
        "schema_version": "g1-full-crysalis-external-benchmark-preflight.1.0.0",
        "status": "PASS",
        "replication_decision": replication["FULL_CRYSALIS_REPLICATED_SIGNAL"],
        "reference_commit": config.reference_commit,
        "formal_attempt_count": config.formal_attempt_count,
        "training_seeds": list(config.training_seeds),
        "condition_manifest_sha256": config.condition_manifest_sha256,
        "replication_artifact_sha256": observed_replication_artifacts,
        "positive_reference_artifact_sha256": observed_positive_reference_artifacts,
        "frozen_artifact_sha256": observed_artifacts,
        "frozen_core_sha256": observed_core,
        "source_boundary": boundary,
    }
