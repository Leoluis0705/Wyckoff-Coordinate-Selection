from __future__ import annotations

import hashlib
import json
import math
import re
from collections import Counter
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from pymatgen.core import Element, Lattice, Structure

from crysalis_g1.external_benchmark.capabilities import ConditionLevel
from crysalis_g1.external_benchmark.config import (
    ExternalBenchmarkConfig,
    PARENT_FREE_FLAGS,
)
from crysalis_g1.external_benchmark.provenance import sha256_file


CONDITION_MANIFEST_SCHEMA = "g1-c0-symmetry-condition-manifest.1.0.0"
ATTEMPT_SCHEMA_VERSION = "g1-external-benchmark-attempt.1.0.0"
REGISTERED_ROOT_SEED = 20260823
CRYSALIS_TRAINING_SEEDS = (20260823, 20260824, 20260825)

_CONDITION_ID = re.compile(r"condition-[0-9a-f]{64}")
_COMMIT = re.compile(r"[0-9a-f]{40}")
_SHA256 = re.compile(r"[0-9a-f]{64}")
_CONDITION_KEYS = {
    "condition_id",
    "attempt_index",
    "root_seed",
    "condition_seed",
    "composition",
    "space_group",
}
_MANIFEST_KEYS = {
    "attempt_count",
    "material_id_lookup_present",
    "parent_coordinates_present",
    "parent_lattice_present",
    "root_seed",
    "schema_version",
    "true_orbit_count_present",
    "true_termination_step_present",
    "true_wyckoff_sequence_present",
    "conditions",
}


def _require_exact_keys(value: Mapping[str, Any], expected: set[str], *, label: str) -> None:
    observed = set(value)
    if observed != expected:
        raise ValueError(
            f"{label} keys drifted: expected {sorted(expected)}, observed {sorted(observed)}"
        )


def _integer(value: Any, *, label: str, minimum: int | None = None) -> int:
    if type(value) is not int:
        raise ValueError(f"{label} must be an integer")
    if minimum is not None and value < minimum:
        raise ValueError(f"{label} must be at least {minimum}")
    return value


def _finite(value: Any, *, label: str, minimum: float | None = None) -> float:
    if type(value) not in {int, float}:
        raise ValueError(f"{label} must be numeric")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{label} must be finite")
    if minimum is not None and result < minimum:
        raise ValueError(f"{label} must be at least {minimum}")
    return result


def _sha256(value: Any, *, label: str) -> str:
    digest = str(value).lower()
    if _SHA256.fullmatch(digest) is None:
        raise ValueError(f"invalid SHA-256 for {label}")
    return digest


def _condition_seed(root_seed: int, attempt_index: int) -> int:
    return int.from_bytes(
        hashlib.sha256(
            f"condition-seed:{root_seed}:{attempt_index}".encode()
        ).digest()[:8],
        "big",
    ) % (2**31 - 1)


def _condition_identifier(public: Mapping[str, Any]) -> str:
    return "condition-" + hashlib.sha256(
        json.dumps(public, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


@dataclass(frozen=True, slots=True)
class RegisteredCondition:
    condition_id: str
    attempt_index: int
    root_seed: int
    condition_seed: int
    composition: tuple[tuple[int, int], ...]
    space_group: int

    def __post_init__(self) -> None:
        attempt_index = _integer(
            self.attempt_index, label="attempt_index", minimum=0
        )
        root_seed = _integer(self.root_seed, label="root_seed", minimum=0)
        condition_seed = _integer(
            self.condition_seed, label="condition_seed", minimum=0
        )
        space_group = _integer(
            self.space_group, label="space_group", minimum=1
        )
        if space_group > 230:
            raise ValueError("space_group must be in 1..230")
        try:
            composition = tuple(
                (
                    _integer(pair[0], label="composition atomic number", minimum=1),
                    _integer(pair[1], label="composition count", minimum=1),
                )
                for pair in self.composition
                if len(pair) == 2
            )
        except (TypeError, IndexError):
            raise ValueError("composition must contain integer pairs") from None
        if len(composition) != len(self.composition) or not composition:
            raise ValueError("composition must contain integer pairs")
        if any(atomic_number > 118 for atomic_number, _ in composition):
            raise ValueError("composition atomic number must be in 1..118")
        if composition != tuple(sorted(composition)):
            raise ValueError("composition pairs must be in atomic-number order")
        if len({atomic_number for atomic_number, _ in composition}) != len(composition):
            raise ValueError("composition contains duplicate atomic numbers")
        if _CONDITION_ID.fullmatch(self.condition_id) is None:
            raise ValueError("condition_id is malformed")
        if condition_seed != _condition_seed(root_seed, attempt_index):
            raise ValueError("condition_seed drifted from the registered algorithm")
        public = {
            "attempt_index": attempt_index,
            "root_seed": root_seed,
            "condition_seed": condition_seed,
            "composition": [list(pair) for pair in composition],
            "space_group": space_group,
        }
        if self.condition_id != _condition_identifier(public):
            raise ValueError("condition_id drifted from the public condition")
        object.__setattr__(self, "composition", composition)

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> RegisteredCondition:
        if not isinstance(payload, Mapping):
            raise ValueError("condition must be an object")
        _require_exact_keys(payload, _CONDITION_KEYS, label="condition")
        composition = payload["composition"]
        if not isinstance(composition, Sequence) or isinstance(composition, (str, bytes)):
            raise ValueError("composition must contain integer pairs")
        try:
            normalized = tuple(tuple(pair) for pair in composition)
        except TypeError:
            raise ValueError("composition must contain integer pairs") from None
        return cls(
            condition_id=str(payload["condition_id"]),
            attempt_index=payload["attempt_index"],
            root_seed=payload["root_seed"],
            condition_seed=payload["condition_seed"],
            composition=normalized,
            space_group=payload["space_group"],
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "condition_id": self.condition_id,
            "attempt_index": self.attempt_index,
            "root_seed": self.root_seed,
            "condition_seed": self.condition_seed,
            "composition": [list(pair) for pair in self.composition],
            "space_group": self.space_group,
        }


def formula_from_composition(composition: Sequence[tuple[int, int]]) -> str:
    parts: list[str] = []
    for atomic_number, count in sorted(composition):
        symbol = Element.from_Z(int(atomic_number)).symbol
        parts.append(symbol if int(count) == 1 else f"{symbol}{int(count)}")
    return "".join(parts)


def registered_sample_seed(
    condition: RegisteredCondition, sample_index: int
) -> int:
    sample_index = _integer(sample_index, label="sample_index", minimum=0)
    if sample_index == 0:
        return condition.condition_seed
    return int.from_bytes(
        hashlib.sha256(
            (
                "external-benchmark-sample-seed:"
                f"{condition.condition_seed}:{sample_index}"
            ).encode()
        ).digest()[:8],
        "big",
    ) % (2**31 - 1)


def load_registered_conditions(
    path: str | Path,
    *,
    expected_count: int = 300,
    root_seed: int = REGISTERED_ROOT_SEED,
    expected_sha256: str | None = None,
) -> tuple[RegisteredCondition, ...]:
    manifest_path = Path(path)
    if expected_sha256 is not None and sha256_file(manifest_path) != _sha256(
        expected_sha256, label="condition manifest"
    ):
        raise ValueError("condition manifest hash mismatch")
    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError("condition manifest must be an object")
    _require_exact_keys(payload, _MANIFEST_KEYS, label="condition manifest")
    if payload["schema_version"] != CONDITION_MANIFEST_SCHEMA:
        raise ValueError("condition manifest schema drifted")
    if payload["root_seed"] != root_seed:
        raise ValueError("condition manifest root seed drifted")
    if type(payload["attempt_count"]) is not int or payload["attempt_count"] != expected_count:
        raise ValueError("condition manifest count drifted")
    for flag in PARENT_FREE_FLAGS:
        if payload[flag] is not False:
            raise ValueError(f"condition manifest is not parent-free: {flag}")
    raw_conditions = payload["conditions"]
    if not isinstance(raw_conditions, list) or len(raw_conditions) != expected_count:
        raise ValueError("condition manifest count drifted")
    conditions = tuple(RegisteredCondition.from_dict(item) for item in raw_conditions)
    ids = [condition.condition_id for condition in conditions]
    indices = [condition.attempt_index for condition in conditions]
    if len(set(ids)) != len(ids) or len(set(indices)) != len(indices):
        raise ValueError("condition manifest contains duplicate identities")
    if indices != list(range(expected_count)):
        raise ValueError("condition manifest order drifted")
    return conditions


def load_registered_conditions_from_config(
    config: ExternalBenchmarkConfig,
) -> tuple[RegisteredCondition, ...]:
    return load_registered_conditions(
        config.condition_manifest_path,
        expected_count=config.condition_count,
        root_seed=REGISTERED_ROOT_SEED,
        expected_sha256=config.condition_manifest_sha256,
    )


@dataclass(frozen=True, slots=True)
class StructurePayload:
    lattice: tuple[tuple[float, float, float], ...]
    atomic_numbers: tuple[int, ...]
    fractional_coordinates: tuple[tuple[float, float, float], ...]

    def __post_init__(self) -> None:
        if len(self.lattice) != 3 or any(len(row) != 3 for row in self.lattice):
            raise ValueError("lattice must be 3x3")
        lattice = tuple(
            tuple(_finite(value, label="lattice value") for value in row)
            for row in self.lattice
        )
        if not self.atomic_numbers:
            raise ValueError("structure must contain at least one site")
        atomic_numbers = tuple(
            _integer(value, label="atomic number", minimum=1)
            for value in self.atomic_numbers
        )
        if any(value > 118 for value in atomic_numbers):
            raise ValueError("atomic number must be in 1..118")
        if any(len(row) != 3 for row in self.fractional_coordinates):
            raise ValueError("fractional coordinates must be Nx3")
        coordinates = tuple(
            tuple(_finite(value, label="fractional coordinate") for value in row)
            for row in self.fractional_coordinates
        )
        if len(atomic_numbers) != len(coordinates):
            raise ValueError("atomic-number and coordinate site counts differ")
        a, b, c = lattice
        determinant = (
            a[0] * (b[1] * c[2] - b[2] * c[1])
            - a[1] * (b[0] * c[2] - b[2] * c[0])
            + a[2] * (b[0] * c[1] - b[1] * c[0])
        )
        volume = abs(determinant)
        if not math.isfinite(volume) or volume <= 0.0:
            raise ValueError("structure cell volume must be finite and positive")
        object.__setattr__(self, "lattice", lattice)
        object.__setattr__(self, "atomic_numbers", atomic_numbers)
        object.__setattr__(self, "fractional_coordinates", coordinates)

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> StructurePayload:
        if not isinstance(payload, Mapping):
            raise ValueError("structure payload must be an object")
        _require_exact_keys(
            payload,
            {"lattice", "atomic_numbers", "fractional_coordinates"},
            label="structure payload",
        )
        try:
            lattice = tuple(tuple(row) for row in payload["lattice"])
            coordinates = tuple(
                tuple(row) for row in payload["fractional_coordinates"]
            )
            atomic_numbers = tuple(payload["atomic_numbers"])
        except TypeError:
            raise ValueError("structure payload arrays are malformed") from None
        return cls(
            lattice=lattice,
            atomic_numbers=atomic_numbers,
            fractional_coordinates=coordinates,
        )

    @classmethod
    def from_pymatgen(cls, structure: Structure) -> StructurePayload:
        return cls(
            lattice=tuple(tuple(float(value) for value in row) for row in structure.lattice.matrix),
            atomic_numbers=tuple(int(site.specie.Z) for site in structure),
            fractional_coordinates=tuple(
                tuple(float(value) for value in row) for row in structure.frac_coords
            ),
        )

    def to_pymatgen(self) -> Structure:
        return Structure(
            Lattice(self.lattice),
            self.atomic_numbers,
            self.fractional_coordinates,
            to_unit_cell=True,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "lattice": [list(row) for row in self.lattice],
            "atomic_numbers": list(self.atomic_numbers),
            "fractional_coordinates": [
                list(row) for row in self.fractional_coordinates
            ],
        }


@dataclass(frozen=True, slots=True)
class ModelProvenance:
    official_repository: str | None
    implementation_commit: str
    checkpoint: str
    checkpoint_sha256: str
    source_artifact: str | None
    source_artifact_sha256: str | None

    def __post_init__(self) -> None:
        if self.official_repository is not None and not self.official_repository.startswith("https://"):
            raise ValueError("official_repository must be HTTPS")
        if _COMMIT.fullmatch(self.implementation_commit) is None:
            raise ValueError("implementation_commit must be a full Git commit")
        if not self.checkpoint.strip():
            raise ValueError("checkpoint must be non-empty")
        object.__setattr__(
            self,
            "checkpoint_sha256",
            _sha256(self.checkpoint_sha256, label="checkpoint"),
        )
        if (self.source_artifact is None) != (self.source_artifact_sha256 is None):
            raise ValueError("source artifact and hash must be declared together")
        if self.source_artifact is not None:
            if not self.source_artifact.strip():
                raise ValueError("source_artifact must be non-empty")
            object.__setattr__(
                self,
                "source_artifact_sha256",
                _sha256(self.source_artifact_sha256, label="source artifact"),
            )

    def to_dict(self) -> dict[str, Any]:
        return {
            "official_repository": self.official_repository,
            "implementation_commit": self.implementation_commit,
            "checkpoint": self.checkpoint,
            "checkpoint_sha256": self.checkpoint_sha256,
            "source_artifact": self.source_artifact,
            "source_artifact_sha256": self.source_artifact_sha256,
        }


class AttemptStatus(StrEnum):
    GENERATED = "GENERATED"
    FAILED = "FAILED"
    UNSUPPORTED = "UNSUPPORTED"


@dataclass(frozen=True, slots=True)
class AttemptRecord:
    model: str
    condition_level: ConditionLevel
    training_data: str
    condition: RegisteredCondition
    sample_index: int
    registered_seed: int
    status: AttemptStatus
    failure_code: str | None
    failure_message: str | None
    structure: StructurePayload | None
    generation_latency_seconds: float | None
    peak_ram_bytes: int | None
    peak_vram_bytes: int | None
    retry_count: int
    refill_count: int
    provenance: ModelProvenance
    training_seed: int | None

    def __post_init__(self) -> None:
        try:
            object.__setattr__(self, "condition_level", ConditionLevel(self.condition_level))
        except (TypeError, ValueError):
            raise ValueError("invalid condition_level") from None
        try:
            object.__setattr__(self, "status", AttemptStatus(self.status))
        except (TypeError, ValueError):
            raise ValueError("invalid generation status") from None
        if not self.model.strip() or not self.training_data.strip():
            raise ValueError("model and training_data must be non-empty")
        if not isinstance(self.condition, RegisteredCondition):
            raise ValueError("condition must be registered")
        sample_index = _integer(self.sample_index, label="sample_index", minimum=0)
        _integer(self.registered_seed, label="registered_seed", minimum=0)
        if self.registered_seed != registered_sample_seed(self.condition, sample_index):
            raise ValueError("registered seed drifted")
        if self.status is AttemptStatus.GENERATED:
            if not isinstance(self.structure, StructurePayload):
                raise ValueError("GENERATED status requires a StructurePayload")
            if self.failure_code is not None or self.failure_message is not None:
                raise ValueError("GENERATED status cannot carry a failure")
        else:
            if self.structure is not None:
                raise ValueError("failed or unsupported attempts cannot carry a structure")
            if not (
                isinstance(self.failure_code, str)
                and self.failure_code.strip()
                and isinstance(self.failure_message, str)
                and self.failure_message.strip()
            ):
                raise ValueError("failed or unsupported attempts must retain failure detail")
        if self.generation_latency_seconds is not None:
            object.__setattr__(
                self,
                "generation_latency_seconds",
                _finite(
                    self.generation_latency_seconds,
                    label="generation latency",
                    minimum=0.0,
                ),
            )
        for name in ("peak_ram_bytes", "peak_vram_bytes"):
            value = getattr(self, name)
            if value is not None:
                _integer(value, label=name, minimum=0)
        if _integer(self.retry_count, label="retry_count", minimum=0) != 0:
            raise ValueError("retry_count must remain zero")
        if _integer(self.refill_count, label="refill_count", minimum=0) != 0:
            raise ValueError("refill_count must remain zero")
        if not isinstance(self.provenance, ModelProvenance):
            raise ValueError("attempt provenance is missing")
        if self.training_seed is not None:
            _integer(self.training_seed, label="training_seed", minimum=0)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": ATTEMPT_SCHEMA_VERSION,
            "model": self.model,
            "condition_level": self.condition_level.value,
            "training_data": self.training_data,
            "training_seed": self.training_seed,
            "condition": self.condition.to_dict(),
            "sample_index": self.sample_index,
            "registered_seed": self.registered_seed,
            "status": self.status.value,
            "failure_code": self.failure_code,
            "failure_message": self.failure_message,
            "structure": None if self.structure is None else self.structure.to_dict(),
            "generation_latency_seconds": self.generation_latency_seconds,
            "peak_ram_bytes": self.peak_ram_bytes,
            "peak_vram_bytes": self.peak_vram_bytes,
            "retry_count": self.retry_count,
            "refill_count": self.refill_count,
            "provenance": self.provenance.to_dict(),
        }


def validate_formal_attempts(
    records: Iterable[AttemptRecord],
    conditions: Sequence[RegisteredCondition],
    *,
    samples_per_condition: int,
) -> tuple[AttemptRecord, ...]:
    samples_per_condition = _integer(
        samples_per_condition, label="samples_per_condition", minimum=1
    )
    frozen = tuple(records)
    expected_count = len(conditions) * samples_per_condition
    if len(frozen) != expected_count:
        raise ValueError(
            f"formal attempt denominator incomplete: expected {expected_count}, observed {len(frozen)}"
        )
    identities = [
        (
            record.model,
            record.training_seed,
            record.condition.condition_id,
            record.sample_index,
        )
        for record in frozen
    ]
    if len(set(identities)) != len(identities):
        raise ValueError("duplicate condition/sample attempt identity")
    expected_order = [
        (condition, sample_index)
        for condition in conditions
        for sample_index in range(samples_per_condition)
    ]
    for record, (condition, sample_index) in zip(frozen, expected_order, strict=True):
        if record.condition.to_dict() != condition.to_dict():
            raise ValueError("attempt contains reordered or foreign condition")
        if record.sample_index != sample_index:
            raise ValueError("attempt sample order drifted")
        if record.registered_seed != registered_sample_seed(condition, sample_index):
            raise ValueError("attempt registered seed drifted")
    if frozen:
        cohort = {
            (
                record.model,
                record.training_seed,
                record.condition_level,
                record.training_data,
                record.provenance,
            )
            for record in frozen
        }
        if len(cohort) != 1:
            raise ValueError("formal attempt cohort provenance drifted")
    return frozen


def _reduced_composition(counts: Mapping[int, int]) -> tuple[tuple[int, int], ...]:
    if not counts:
        return ()
    divisor = math.gcd(*counts.values())
    return tuple(
        sorted((atomic_number, count // divisor) for atomic_number, count in counts.items())
    )


def compare_structure_composition(
    condition: RegisteredCondition, structure: StructurePayload
) -> dict[str, Any]:
    requested = Counter(dict(condition.composition))
    observed = Counter(structure.atomic_numbers)
    multipliers = {
        observed.get(atomic_number, 0) / count
        for atomic_number, count in requested.items()
    }
    multiplier: int | None = None
    if set(observed) == set(requested) and len(multipliers) == 1:
        candidate = next(iter(multipliers))
        if candidate >= 1 and float(candidate).is_integer():
            multiplier = int(candidate)
    return {
        "requested_cell_composition": [list(item) for item in sorted(requested.items())],
        "observed_cell_composition": [list(item) for item in sorted(observed.items())],
        "requested_reduced_composition": [
            list(item) for item in _reduced_composition(requested)
        ],
        "observed_reduced_composition": [
            list(item) for item in _reduced_composition(observed)
        ],
        "reduced_formula_match": _reduced_composition(requested)
        == _reduced_composition(observed),
        "exact_cell_count_match": requested == observed,
        "cell_formula_multiplier": multiplier,
    }


def _failure_message(record: Mapping[str, Any], failure_code: str) -> str:
    message = record.get("failure_message")
    if isinstance(message, str) and message.strip():
        return message
    reasons = record.get("projector_rejection_reasons")
    if isinstance(reasons, Sequence) and not isinstance(reasons, (str, bytes)) and reasons:
        return json.dumps(list(reasons), sort_keys=True, separators=(",", ":"))
    return failure_code


def convert_frozen_crysalis_generation_file(
    path: str | Path,
    conditions: Sequence[RegisteredCondition],
    *,
    training_seed: int,
    implementation_commit: str,
    checkpoint: str,
    checkpoint_sha256: str,
) -> tuple[AttemptRecord, ...]:
    source_path = Path(path)
    payload = json.loads(source_path.read_text(encoding="utf-8"))
    if not isinstance(payload, list) or len(payload) != len(conditions):
        raise ValueError("frozen Crysalis generation denominator drifted")
    provenance = ModelProvenance(
        official_repository=None,
        implementation_commit=implementation_commit,
        checkpoint=checkpoint,
        checkpoint_sha256=checkpoint_sha256,
        source_artifact=str(source_path.resolve()),
        source_artifact_sha256=sha256_file(source_path),
    )
    converted: list[AttemptRecord] = []
    for raw, condition in zip(payload, conditions, strict=True):
        if not isinstance(raw, Mapping):
            raise ValueError("frozen Crysalis generation record must be an object")
        observed_condition = RegisteredCondition.from_dict(raw.get("condition", {}))
        if observed_condition.to_dict() != condition.to_dict():
            raise ValueError("frozen Crysalis record contains reordered or foreign condition")
        if raw.get("retry_count") != 0 or raw.get("refill_count") != 0:
            raise ValueError("frozen Crysalis retry/refill drifted")
        structure: StructurePayload | None = None
        failure_code: str | None = None
        failure_message: str | None = None
        status = AttemptStatus.FAILED
        if raw.get("legal_terminal_crystal") is True:
            try:
                candidate = raw["candidate"]
                structure = StructurePayload.from_dict(
                    {
                        key: candidate[key]
                        for key in (
                            "lattice",
                            "atomic_numbers",
                            "fractional_coordinates",
                        )
                    }
                )
            except Exception as error:
                failure_code = "STRUCTURE_PARSE_FAILED"
                failure_message = f"{type(error).__name__}: {error}"
            else:
                status = AttemptStatus.GENERATED
        else:
            failure_code = str(raw.get("failure_code") or "GENERATION_FAILED")
            failure_message = _failure_message(raw, failure_code)
        converted.append(
            AttemptRecord(
                model="FULL_CRYSALIS",
                condition_level=ConditionLevel.EXACT_FORMULA_PLUS_SG,
                training_data="Phase2A public cohort",
                condition=condition,
                sample_index=0,
                registered_seed=registered_sample_seed(condition, 0),
                status=status,
                failure_code=failure_code,
                failure_message=failure_message,
                structure=structure,
                generation_latency_seconds=raw.get("latency_seconds"),
                peak_ram_bytes=None,
                peak_vram_bytes=None,
                retry_count=0,
                refill_count=0,
                provenance=provenance,
                training_seed=training_seed,
            )
        )
    return validate_formal_attempts(
        converted, conditions, samples_per_condition=1
    )


def convert_frozen_crysalis_generation_files(
    generation_files: Mapping[int, str | Path],
    conditions: Sequence[RegisteredCondition],
    *,
    implementation_commit: str,
    checkpoints: Mapping[int, tuple[str, str]],
) -> dict[int, tuple[AttemptRecord, ...]]:
    if set(generation_files) != set(CRYSALIS_TRAINING_SEEDS):
        raise ValueError("frozen Crysalis generation files must cover all three training seeds")
    if set(checkpoints) != set(CRYSALIS_TRAINING_SEEDS):
        raise ValueError("frozen Crysalis checkpoint provenance is incomplete")
    return {
        seed: convert_frozen_crysalis_generation_file(
            generation_files[seed],
            conditions,
            training_seed=seed,
            implementation_commit=implementation_commit,
            checkpoint=checkpoints[seed][0],
            checkpoint_sha256=checkpoints[seed][1],
        )
        for seed in CRYSALIS_TRAINING_SEEDS
    }
