from __future__ import annotations

import json
import sys
from typing import Any, Mapping

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


SYMPREC_VALUES = (0.01, 0.03, 0.05, 0.10)


def _structure_from_payload(payload: Mapping[str, Any]) -> Structure:
    return Structure(
        Lattice(np.asarray(payload["lattice"], dtype=float)),
        [int(value) for value in payload["atomic_numbers"]],
        np.asarray(payload["fractional_coordinates"], dtype=float),
        to_unit_cell=True,
    )


def main() -> int:
    structure = _structure_from_payload(json.loads(sys.stdin.read()))
    for symprec in SYMPREC_VALUES:
        try:
            number = int(
                SpacegroupAnalyzer(
                    structure,
                    symprec=symprec,
                    angle_tolerance=5.0,
                ).get_space_group_number()
            )
        except Exception:
            number = 0
        print(
            json.dumps(
                {"label": f"{symprec:.2f}", "number": number},
                separators=(",", ":"),
            ),
            flush=True,
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
