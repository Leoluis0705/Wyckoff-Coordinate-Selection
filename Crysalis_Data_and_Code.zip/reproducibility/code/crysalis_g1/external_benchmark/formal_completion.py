"""Formal MatterSim and final-delivery actions for the frozen benchmark."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Mapping, Sequence

from crysalis_g1.external_benchmark.adapters import (
    build_command,
    execute_official_command,
)
from crysalis_g1.external_benchmark.capabilities import capability_matrix_payload
from crysalis_g1.external_benchmark.cell_relax_gpu_adjudication import (
    apply_gpu_adjudication,
    render_gpu_adjudication,
    validate_gpu_adjudication,
)
from crysalis_g1.external_benchmark.config import ExternalBenchmarkConfig
from crysalis_g1.external_benchmark.evaluation import attempt_evaluation_id
from crysalis_g1.external_benchmark.failure_attribution import (
    build_attribution_from_frozen_common,
    render_cell_relax_failure_attribution,
)
from crysalis_g1.external_benchmark.formal_other_baselines import _windows_to_wsl
from crysalis_g1.external_benchmark.provenance import sha256_file
from crysalis_g1.external_benchmark.records import AttemptRecord, AttemptStatus
from crysalis_g1.external_benchmark.reporting import (
    REQUIRED_OUTPUTS,
    build_candidate_zip_payload,
    collect_upstream_bindings,
    render_external_benchmark_report,
    validate_mattersim_result_rows,
    write_final_artifacts,
)
from crysalis_g1.external_benchmark.runner import (
    EXTERNAL_ARTIFACT_REGISTRY,
    StageAction,
    StageContext,
    StageResult,
    _atomic_write_json_new,
    _load_frozen_crysalis_contract,
    _load_prior_attempt_records,
    _mattersim_eligible_attempt_ids,
    build_final_scientific_contract,
)


_POLICY_FIELDS = {
    "retry_count": 0,
    "refill_count": 0,
    "sealed_or_blind_data_accessed": False,
    "server_used": False,
    "dft_used": False,
    "tuning_performed": False,
    "ablation_performed": False,
}
_MATTERGEN_COMMIT = "67afb22ea0dd0073aedfc85b30b94bea0ee21863"
_MATTERSIM_COMMIT = "aedf510ec536cf24163edad4570eaceafdb7cb2b"
_MATTERSIM_WEIGHT_SHA256 = "28b0b0b0f13efefee06b47ea4c9105a26bd3e2c8396da193430da96b3b49a8be"
_TRI2024_SHA256 = "ab1b4426901ff7b0f8af6ee9c3cc0dd2fbe4b65c758ef2a95683071492d1c51d"
_MATTERSIM_RUNNER_BASE_COMMIT = "2ac2b6d9832dd038d1544b51bb0a73875aeedc66"
_MATTERSIM_RUNNER_PATCH_COMMIT = "b4c20f603ac2fe192535b3c4e5ea4832e04f09ed"


def build_mattersim_input_payload(
    attempts: Sequence[AttemptRecord],
    eligible_attempt_ids: Sequence[str],
) -> dict[str, Any]:
    by_id = {attempt_evaluation_id(attempt): attempt for attempt in attempts}
    eligible = tuple(str(identity) for identity in eligible_attempt_ids)
    observed_generated = {
        identity
        for identity, attempt in by_id.items()
        if attempt.status is AttemptStatus.GENERATED and attempt.structure is not None
    }
    if (
        len(by_id) != len(attempts)
        or len(eligible) != len(set(eligible))
        or set(eligible) != observed_generated
    ):
        raise ValueError("MatterSim eligible cohort differs from generated structures")
    return {
        "schema_version": "g1-mattersim-input.1.0.0",
        "structures": [
            {
                "attempt_id": identity,
                "structure": by_id[identity].structure.to_dict(),
            }
            for identity in eligible
        ],
    }


def _git_output(checkout: Path, *arguments: str) -> str:
    completed = subprocess.run(
        ("git", *arguments),
        cwd=checkout,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    if completed.returncode != 0:
        detail = completed.stderr.strip() or completed.stdout.strip()
        raise RuntimeError(f"official checkout verification failed: {detail}")
    return completed.stdout.strip()


def _verify_checkout(checkout: Path, expected_commit: str) -> None:
    if not checkout.is_dir() or _git_output(checkout, "rev-parse", "HEAD") != expected_commit:
        raise ValueError(f"official checkout commit mismatch: {checkout}")
    if _git_output(checkout, "diff", "--name-only", "--ignore-cr-at-eol", "HEAD", "--"):
        raise ValueError(f"official checkout tracked files are dirty: {checkout}")
    if _git_output(checkout, "ls-files", "--others", "--exclude-standard"):
        raise ValueError(f"official checkout contains untracked files: {checkout}")


def _all_attempts(
    config: ExternalBenchmarkConfig,
    repo_root: Path,
) -> tuple[AttemptRecord, ...]:
    frozen = _load_frozen_crysalis_contract(config, repo_root)
    full = tuple(
        attempt for seed in config.training_seeds for attempt in frozen["attempts_by_seed"][seed]
    )
    return (
        full
        + _load_prior_attempt_records(config, "crystalformer")
        + _load_prior_attempt_records(config, "other_baselines")
    )


def _mattersim_paths(context: StageContext) -> dict[str, Path]:
    root = context.engineering_root / "stages" / "mattersim_secondary"
    run = root / "official_run"
    return {
        "stage": root / "mattersim_secondary.json",
        "input": run / "input_structures.json",
        "official_output": run / "official_output.json",
        "relaxed": run / "relaxed_structures.extxyz",
        "driver_receipt": run / "driver_receipt.json",
        "stdout": run / "stdout.log",
        "stderr": run / "stderr.log",
        "command_receipt": run / "command_receipt.json",
    }


def _mattersim_runtime_paths(
    config: ExternalBenchmarkConfig,
    repo_root: Path,
) -> dict[str, Path]:
    cache = config.official_artifact_cache.resolve()
    return {
        "wsl": Path(r"C:\Windows\System32\wsl.exe").resolve(),
        "python": Path(r"D:\CGCNN\mattergen\.venv\bin\python").resolve(),
        "driver": (
            repo_root / "crysalis_g1/external_benchmark/official_mattersim_driver.py"
        ).resolve(),
        "mattergen": (cache / "repos/mattergen").resolve(),
        "mattersim": (cache / "repos/mattersim").resolve(),
        "weight": (cache / "repos/mattersim/pretrained_models/mattersim-v1.0.0-1M.pth").resolve(),
        "reference": (
            cache / "references/mattergen_67afb22e/reference_TRI2024correction.gz"
        ).resolve(),
    }


def _verify_mattersim_runtime(paths: Mapping[str, Path]) -> None:
    for name in ("wsl", "driver", "weight", "reference"):
        if not paths[name].is_file():
            raise FileNotFoundError(f"MatterSim runtime artifact is missing: {name}")
    if not os.path.lexists(paths["python"]):
        raise FileNotFoundError("MatterSim registered WSL Python is missing")
    _verify_checkout(paths["mattergen"], _MATTERGEN_COMMIT)
    _verify_checkout(paths["mattersim"], _MATTERSIM_COMMIT)
    if sha256_file(paths["weight"]) != _MATTERSIM_WEIGHT_SHA256:
        raise ValueError("MatterSim weight hash mismatch")
    if sha256_file(paths["reference"]) != _TRI2024_SHA256:
        raise ValueError("MatterSim TRI2024 reference hash mismatch")


def _mattersim_command(
    runtime: Mapping[str, Path],
    paths: Mapping[str, Path],
    input_sha256: str,
):
    arguments = (
        "-d",
        "Ubuntu",
        "--exec",
        _windows_to_wsl(runtime["python"]),
        _windows_to_wsl(runtime["driver"]),
        "--input-json",
        _windows_to_wsl(paths["input"]),
        "--input-sha256",
        input_sha256,
        "--mattergen-checkout",
        _windows_to_wsl(runtime["mattergen"]),
        "--mattersim-checkout",
        _windows_to_wsl(runtime["mattersim"]),
        "--weight",
        _windows_to_wsl(runtime["weight"]),
        "--reference-dataset",
        _windows_to_wsl(runtime["reference"]),
        "--output-json",
        _windows_to_wsl(paths["official_output"]),
        "--relaxed-extxyz",
        _windows_to_wsl(paths["relaxed"]),
        "--receipt",
        _windows_to_wsl(paths["driver_receipt"]),
        "--device",
        "cuda",
    )
    return build_command(
        executable=runtime["wsl"],
        arguments=arguments,
        cwd=runtime["mattergen"],
        environment_overrides={},
        device="cuda",
    )


def _declaration(context: StageContext, path: Path) -> dict[str, str]:
    return {
        "path": path.resolve().relative_to(context.output_root.resolve()).as_posix(),
        "sha256": sha256_file(path),
    }


def _json_object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"JSON artifact must be an object: {path}")
    return payload


def _write_mattersim_stage(
    context: StageContext,
    paths: Mapping[str, Path],
    eligible: Sequence[str],
    *,
    status: str,
    results: Sequence[Mapping[str, Any]] | None,
    failure_reason: str | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "schema_version": "g1-external-benchmark-mattersim-stage.1.0.0",
        "stage_status": status,
        "primary_chgnet_affected": False,
        "eligible_attempt_count": len(eligible),
        "eligible_attempt_ids": list(eligible),
        "results": None if results is None else [dict(row) for row in results],
        **_POLICY_FIELDS,
    }
    if status == "COMPLETE":
        payload.update(
            {
                "smoke_test_status": "PASS",
                "weight_sha256": _MATTERSIM_WEIGHT_SHA256,
                "tri2024_reference_sha256": _TRI2024_SHA256,
                "stability_threshold_ev_per_atom": 0.1,
            }
        )
    else:
        payload["failure_reason"] = str(failure_reason or "official MatterSim run failed")
    _atomic_write_json_new(paths["stage"], payload)
    return payload


def build_mattersim_action(
    *,
    config: ExternalBenchmarkConfig,
    repo_root: str | Path,
) -> StageAction:
    repo = Path(repo_root).resolve()
    eligible = _mattersim_eligible_attempt_ids(config)

    def execute(context: StageContext) -> StageResult:
        if context.stage != "mattersim_secondary":
            raise ValueError("MatterSim action received the wrong stage")
        paths = _mattersim_paths(context)
        if any(path.exists() for path in paths.values()):
            raise FileExistsError("immutable MatterSim formal artifact already exists")
        runtime = _mattersim_runtime_paths(context.config, repo)
        _verify_mattersim_runtime(runtime)
        attempts = _all_attempts(context.config, repo)
        input_payload = build_mattersim_input_payload(attempts, eligible)
        _atomic_write_json_new(paths["input"], input_payload)
        input_sha256 = sha256_file(paths["input"])
        command = _mattersim_command(runtime, paths, input_sha256)
        receipt = execute_official_command(
            command,
            preflight=SimpleNamespace(
                official_commit=_MATTERSIM_COMMIT,
                checkpoint_sha256=_MATTERSIM_WEIGHT_SHA256,
            ),
            stdout_path=paths["stdout"],
            stderr_path=paths["stderr"],
            receipt_path=paths["command_receipt"],
            runtime_versions={
                "python": "3.10.20",
                "torch": "2.7.1+cu128",
                "mattergen": "1.0.3",
                "ase": "3.27.0",
                "mattersim_commit": _MATTERSIM_COMMIT,
            },
        )
        if receipt.exit_code != 0:
            stage_payload = _write_mattersim_stage(
                context,
                paths,
                eligible,
                status="FAILED_PRESERVED",
                results=None,
                failure_reason=f"official MatterSim command exited {receipt.exit_code}",
            )
        else:
            official = _json_object(paths["official_output"])
            driver_receipt = _json_object(paths["driver_receipt"])
            results = official.get("results")
            if (
                official.get("schema_version") != "g1-official-mattersim-output.1.0.0"
                or official.get("eligible_attempt_ids") != list(eligible)
                or official.get("eligible_attempt_count") != len(eligible)
                or official.get("smoke_test_status") != "PASS"
                or official.get("weight_sha256") != _MATTERSIM_WEIGHT_SHA256
                or official.get("tri2024_reference_sha256") != _TRI2024_SHA256
                or official.get("stability_threshold_ev_per_atom") != 0.1
            ):
                raise ValueError("official MatterSim output contract drifted")
            validate_mattersim_result_rows(results, eligible)
            if (
                driver_receipt.get("status") != "COMPLETE"
                or driver_receipt.get("official_mattergen_commit") != _MATTERGEN_COMMIT
                or driver_receipt.get("official_mattersim_commit") != _MATTERSIM_COMMIT
                or driver_receipt.get("input_json_sha256") != input_sha256
                or driver_receipt.get("output_json_sha256") != sha256_file(paths["official_output"])
                or driver_receipt.get("relaxed_extxyz_sha256") != sha256_file(paths["relaxed"])
            ):
                raise ValueError("official MatterSim driver receipt drifted")
            stage_payload = _write_mattersim_stage(
                context,
                paths,
                eligible,
                status="COMPLETE",
                results=results,
            )
        evidence = {
            "stage_status": stage_payload["stage_status"],
            "primary_chgnet_affected": False,
            "mattersim_artifact": _declaration(context, paths["stage"]),
            "official_artifacts": {"MatterSim": dict(EXTERNAL_ARTIFACT_REGISTRY["MatterSim"])},
            **_POLICY_FIELDS,
        }
        if stage_payload["stage_status"] == "FAILED_PRESERVED":
            evidence["failure_reason"] = stage_payload["failure_reason"]
        outputs = tuple(path for path in paths.values() if path.is_file())
        return StageResult(
            outputs=outputs,
            evidence=evidence,
            command_receipts=(receipt.to_dict(),),
        )

    return StageAction(
        action_id=f"mattersim-secondary:{_MATTERSIM_COMMIT}:eligible-{len(eligible)}",
        execute=execute,
        registered_attempt_ids=eligible,
    )


def _published_reference_payload() -> dict[str, Any]:
    def row(
        model: str,
        metric: str,
        value: object,
        source_protocol: str,
        mismatch: str,
        source_url: str,
    ) -> dict[str, Any]:
        return {
            "model": model,
            "metric": metric,
            "value": value,
            "source_protocol": source_protocol,
            "protocol_mismatch_label": mismatch,
            "contextual_only": True,
            "cross_protocol_rank": None,
            "source_url": source_url,
        }

    mattergen_url = "https://www.nature.com/articles/s41586-025-08628-5"
    crystalflow_url = "https://github.com/ixsluo/CrystalFlow"
    diffcsp_url = "https://github.com/jiaor17/DiffCSP"
    rows = [
        row(
            "MatterGen",
            "Alex-MP-20 SUN",
            0.3857,
            "published MatterSim evaluation",
            "NOT_DIRECTLY_CONDITION_MATCHED",
            mattergen_url,
        ),
        row(
            "MatterGen",
            "Alex-MP-20 stable",
            0.7441,
            "published MatterSim evaluation",
            "NOT_DIRECTLY_CONDITION_MATCHED",
            mattergen_url,
        ),
        row(
            "MatterGen",
            "Alex-MP-20 unique",
            1.0,
            "published MatterSim evaluation",
            "NOT_DIRECTLY_CONDITION_MATCHED",
            mattergen_url,
        ),
        row(
            "MatterGen",
            "Alex-MP-20 novel",
            0.6196,
            "published MatterSim evaluation",
            "NOT_DIRECTLY_CONDITION_MATCHED",
            mattergen_url,
        ),
        row(
            "MatterGen MP-20",
            "SUN",
            0.2227,
            "published MatterSim evaluation",
            "NOT_DIRECTLY_CONDITION_MATCHED",
            mattergen_url,
        ),
        row(
            "MatterGen MP-20",
            "stable",
            0.4219,
            "published MatterSim evaluation",
            "NOT_DIRECTLY_CONDITION_MATCHED",
            mattergen_url,
        ),
        row(
            "MatterGen MP-20",
            "unique",
            1.0,
            "published MatterSim evaluation",
            "NOT_DIRECTLY_CONDITION_MATCHED",
            mattergen_url,
        ),
        row(
            "MatterGen MP-20",
            "novel",
            0.7544,
            "published MatterSim evaluation",
            "NOT_DIRECTLY_CONDITION_MATCHED",
            mattergen_url,
        ),
        row(
            "CrystalFlow",
            "MP-20 CSP K=1 match rate",
            0.6202,
            "published composition-only CSP",
            "PUBLISHED_MP20_CSP_NOT_COMMON_300",
            crystalflow_url,
        ),
        row(
            "CrystalFlow",
            "MP-20 CSP K=1 normalized RMSE",
            0.0710,
            "published composition-only CSP",
            "PUBLISHED_MP20_CSP_NOT_COMMON_300",
            crystalflow_url,
        ),
        row(
            "CrystalFlow",
            "MP-20 CSP K=20 match rate",
            0.7834,
            "published composition-only CSP",
            "PUBLISHED_MP20_CSP_NOT_COMMON_300",
            crystalflow_url,
        ),
        row(
            "CrystalFlow",
            "MP-20 CSP K=100 match rate",
            0.8249,
            "published composition-only CSP",
            "PUBLISHED_MP20_CSP_NOT_COMMON_300",
            crystalflow_url,
        ),
        row(
            "DiffCSP",
            "MP-20 CSP K=1 match rate",
            0.5149,
            "published composition-only CSP",
            "PUBLISHED_MP20_CSP_NOT_COMMON_300",
            diffcsp_url,
        ),
        row(
            "DiffCSP",
            "MP-20 CSP K=1 normalized RMSE",
            0.0631,
            "published composition-only CSP",
            "PUBLISHED_MP20_CSP_NOT_COMMON_300",
            diffcsp_url,
        ),
        row(
            "DiffCSP",
            "MP-20 CSP K=20 match rate",
            0.7793,
            "published composition-only CSP",
            "PUBLISHED_MP20_CSP_NOT_COMMON_300",
            diffcsp_url,
        ),
        row(
            "DiffCSP",
            "MP-20 CSP K=20 normalized RMSE",
            0.0492,
            "published composition-only CSP",
            "PUBLISHED_MP20_CSP_NOT_COMMON_300",
            diffcsp_url,
        ),
        row(
            "DynaCrys",
            "CHGNet SUN@0",
            0.0939,
            "published unconditional MP-20",
            "NOT_RUN_NO_OFFICIAL_REPRODUCIBLE_ARTIFACT",
            "https://arxiv.org/abs/2608.07401",
        ),
        row(
            "DynaCrys",
            "CHGNet SUN@0.1",
            0.4149,
            "published unconditional MP-20",
            "NOT_RUN_NO_OFFICIAL_REPRODUCIBLE_ARTIFACT",
            "https://arxiv.org/abs/2608.07401",
        ),
        row(
            "CrystalFormer",
            "method reference",
            "CONTEXT_ONLY",
            "official formula-plus-SG CSP",
            "CURRENT_RUN_REPORTED_IN_TABLE_A",
            "https://github.com/deepmodeling/CrystalFormer",
        ),
        row(
            "WyFormer",
            "method reference",
            "CONTEXT_ONLY",
            "published chemical-system generation",
            "CONDITION_PROTOCOL_MISMATCH",
            "https://proceedings.mlr.press/v267/kazeev25a.html",
        ),
        row(
            "WyckoffAUGen",
            "method reference",
            "CONTEXT_ONLY",
            "published property-conditioned generation",
            "NOT_RUN_NO_OFFICIAL_REPRODUCIBLE_ARTIFACT",
            "https://openreview.net/forum?id=1ne8lalwRN",
        ),
        row(
            "DiffCSP++",
            "method reference",
            "CONTEXT_ONLY",
            "published template-conditioned generation",
            "EXTRA_TEMPLATE_CONDITION_REQUIRED",
            "https://openreview.net/forum?id=jkvZ7v4OmP",
        ),
        row(
            "FlowMM",
            "method reference",
            "CONTEXT_ONLY",
            "published unconditional generation",
            "NOT_RUN_NO_RELEASED_CHECKPOINT",
            "https://github.com/facebookresearch/flowmm",
        ),
    ]
    return {
        "schema_version": "g1-external-benchmark-published-reference.1.0.0",
        "table_c_rows": rows,
        "cross_protocol_ranking_performed": False,
    }


def _delivery_payloads(
    contract: Mapping[str, Any],
    cell_relax_failure_attribution: Mapping[str, Any],
    cell_relax_gpu_adjudication: Mapping[str, Any],
) -> dict[str, object]:
    common = contract["common_chgnet_results"]
    summaries = {row["model"]: row for row in common["table_b_rows"]}
    capability = capability_matrix_payload()
    published = _published_reference_payload()
    payloads: dict[str, object] = {
        "BASELINE_CONDITION_CAPABILITY.json": capability,
        "CRYSTALFORMER_RESULTS.json": {
            "schema_version": "g1-external-benchmark-crystalformer-results.1.0.0",
            "model": "CrystalFormer",
            "condition_level": "EXACT_FORMULA_PLUS_SG",
            "primary_k1": summaries["CrystalFormer"],
            "secondary_k5": {
                "analysis_role": "SECONDARY_CSP_ONLY",
                "condition_count": 300,
                "attempt_count": 1500,
                "new_attempt_count": 1200,
                "pooled_with_primary_quality": False,
                "may_replace_k1": False,
            },
        },
        "MATTERGEN_RESULTS.json": {
            "schema_version": "g1-external-benchmark-model-results.1.0.0",
            "model": "MatterGen",
            "condition_level": "SG_ONLY",
            "common_summary": summaries["MatterGen"],
        },
        "CRYSTALFLOW_RESULTS.json": {
            "schema_version": "g1-external-benchmark-model-results.1.0.0",
            "model": "CrystalFlow",
            "condition_level": "EXACT_FORMULA_ONLY",
            "common_summary": summaries["CrystalFlow"],
        },
        "DIFFCSP_RESULTS.json": {
            "schema_version": "g1-external-benchmark-model-results.1.0.0",
            "model": "DiffCSP",
            "condition_level": "EXACT_FORMULA_ONLY",
            "common_summary": summaries["DiffCSP"],
        },
        "COMMON_CHGNET_BENCHMARK.json": common,
        "CELL_RELAX_FAILURE_ATTRIBUTION.json": cell_relax_failure_attribution,
        "CELL_RELAX_FAILURE_ATTRIBUTION.md": render_cell_relax_failure_attribution(
            cell_relax_failure_attribution
        ),
        "CELL_RELAX_GPU_ADJUDICATION.json": cell_relax_gpu_adjudication,
        "CELL_RELAX_GPU_ADJUDICATION.md": render_gpu_adjudication(cell_relax_gpu_adjudication),
        "MATTERSIM_REFERENCE_BENCHMARK.json": contract["mattersim_results"],
        "CSP_MATCH_RATE_RESULTS.json": contract["csp_results"],
        "BENCHMARK_BY_SPACE_GROUP.json": {
            "schema_version": "g1-external-benchmark-by-space-group.1.0.0",
            "space_groups": [225, 139, 12, 63, 189, 194, 123, 164],
            "models": {model: summary["per_space_group"] for model, summary in summaries.items()},
        },
        "BENCHMARK_RUNTIME.json": {
            "schema_version": "g1-external-benchmark-runtime.1.0.0",
            "models": {model: summary["runtime"] for model, summary in summaries.items()},
            "retry_count": 0,
            "refill_count": 0,
        },
        "BENCHMARK_FAILURES.jsonl": contract["failure_records"],
        "PUBLISHED_REFERENCE_METRICS.json": published,
        "FULL_CRYSALIS_BENCHMARK_CANDIDATES.zip": build_candidate_zip_payload(
            contract["candidate_selection"]
        ),
    }
    payloads["EXTERNAL_BENCHMARK_REPORT.md"] = render_external_benchmark_report(
        table_a_rows=common["table_a_rows"],
        table_b_rows=common["table_b_rows"],
        table_c_rows=published["table_c_rows"],
        capability_rows=capability["models"],
        full_crysalis_summary=common["full_crysalis_summary"],
        cell_relax_failure_attribution=cell_relax_failure_attribution,
        cell_relax_gpu_adjudication=cell_relax_gpu_adjudication,
        mattersim_results=contract["mattersim_results"],
    )
    return payloads


def _mattersim_runtime_provenance(
    config: ExternalBenchmarkConfig,
    repo_root: Path,
) -> dict[str, Any]:
    receipt_path = config.output_root / "engineering/receipts/mattersim_secondary.json"
    driver_receipt_path = (
        config.output_root
        / "engineering/stages/mattersim_secondary/official_run/driver_receipt.json"
    )
    invalidation_path = (
        config.output_root / "engineering/invalidated_runs/"
        "mattersim_secondary_20260827T154019_python310_datetime_compat/INVALIDATION.json"
    )
    receipt = _json_object(receipt_path)
    driver = _json_object(driver_receipt_path)
    invalidation = _json_object(invalidation_path)
    commands = receipt.get("command_receipts")
    if (
        receipt.get("status") != "COMPLETE"
        or not isinstance(commands, list)
        or len(commands) != 1
        or not isinstance(commands[0], Mapping)
        or driver.get("status") != "COMPLETE"
        or invalidation.get("run_status") != "INFRASTRUCTURE_INVALIDATED"
        or invalidation.get("scientific_use") is not False
    ):
        raise ValueError("MatterSim runtime provenance inputs are incomplete")
    command = commands[0]
    patch_diff = _git_output(
        repo_root,
        "diff",
        "--no-ext-diff",
        "--unified=3",
        f"{_MATTERSIM_RUNNER_BASE_COMMIT}..{_MATTERSIM_RUNNER_PATCH_COMMIT}",
        "--",
        "crysalis_g1/external_benchmark/formal_completion.py",
        "crysalis_g1/external_benchmark/official_mattersim_driver.py",
    )
    if not patch_diff:
        raise ValueError("MatterSim compatibility patch diff is empty")
    exact_command = command.get("argv")
    output_hashes = receipt.get("output_sha256")
    if not isinstance(exact_command, list) or not isinstance(output_hashes, Mapping):
        raise ValueError("MatterSim exact command or output hashes are missing")
    return {
        "mattersim_model_source": "OFFICIAL",
        "mattersim_model_weights": "OFFICIAL",
        "mattersim_runtime_status": "COMPATIBILITY_PATCHED_RUNNER",
        "model_scientific_algorithm_modified": False,
        "official_repository": "https://github.com/microsoft/mattersim",
        "official_repo_commit": _MATTERSIM_COMMIT,
        "checkpoint_sha256": _MATTERSIM_WEIGHT_SHA256,
        "dependency_versions": dict(driver["environment"]),
        "exact_command": list(exact_command),
        "raw_output_sha256": dict(output_hashes),
        "runner_patch_base_commit": _MATTERSIM_RUNNER_BASE_COMMIT,
        "runner_patch_commit": _MATTERSIM_RUNNER_PATCH_COMMIT,
        "runner_patch_diff": patch_diff,
        "runner_patch_diff_sha256": hashlib.sha256(patch_diff.encode()).hexdigest(),
        "runner_patch_scope": (
            "Python 3.10 UTC semantics, official MatterSim/ASE runtime compatibility, "
            "and CUDA smoke invocation only"
        ),
        "infrastructure_invalidated_runs": [invalidation],
    }


def build_final_action(
    *,
    config: ExternalBenchmarkConfig,
    repo_root: str | Path,
) -> StageAction:
    repo = Path(repo_root).resolve()

    def execute(context: StageContext) -> StageResult:
        if context.stage != "final":
            raise ValueError("final action received the wrong stage")
        contract = dict(build_final_scientific_contract(context.config, repo_root=repo))
        mattersim = dict(contract["mattersim_results"])
        if mattersim.get("stage_status") == "COMPLETE":
            mattersim["runtime_provenance"] = _mattersim_runtime_provenance(
                context.config,
                repo,
            )
        contract["mattersim_results"] = mattersim
        initial_attribution = build_attribution_from_frozen_common(context.config, repo)
        saved_attribution = _json_object(
            context.engineering_root
            / "stages/cell_relax_failure_attribution/CELL_RELAX_FAILURE_ATTRIBUTION.json"
        )
        if saved_attribution != initial_attribution:
            raise ValueError("saved cell-relax failure attribution drifted")
        gpu_adjudication = _json_object(
            context.engineering_root
            / "stages/cell_relax_gpu_adjudication/CELL_RELAX_GPU_ADJUDICATION.json"
        )
        validate_gpu_adjudication(gpu_adjudication, expected_count=29)
        attribution = apply_gpu_adjudication(
            initial_attribution,
            gpu_adjudication,
        )
        payloads = _delivery_payloads(contract, attribution, gpu_adjudication)
        write_final_artifacts(
            context.output_root,
            payloads,
            manifest_metadata={
                **_POLICY_FIELDS,
                **collect_upstream_bindings(context.output_root),
            },
            upstream_scientific_contract=contract,
        )
        return StageResult(
            outputs=tuple(context.output_root / name for name in REQUIRED_OUTPUTS),
            evidence={
                "stage_status": "COMPLETE",
                "required_outputs": list(REQUIRED_OUTPUTS),
                "retry_count": 0,
                "refill_count": 0,
            },
        )

    return StageAction(
        action_id="full-crysalis-external-benchmark-final-v1",
        execute=execute,
    )
