from __future__ import annotations

import hashlib
import json
import math
import numbers
import warnings
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

import numpy as np
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer

from crysalis_g1.external_benchmark.capabilities import ConditionLevel
from crysalis_g1.external_benchmark.config import ExternalBenchmarkConfig
from crysalis_g1.external_benchmark.provenance import (
    preflight_frozen_inputs,
    sha256_file,
)
from crysalis_g1.external_benchmark.records import (
    CRYSALIS_TRAINING_SEEDS,
    AttemptRecord,
    AttemptStatus,
    compare_structure_composition,
    load_registered_conditions_from_config,
)
from crysalis_g1.full_crysalis.config import FullCrysalisConfig
from crysalis_g1.full_crysalis.evaluation import EvalMLIP, SYMPREC_VALUES


COMMON_EVALUATION_SCHEMA = "g1-external-benchmark-common-evaluation.1.0.0"
SHORT_CONTACT_DISTANCE_ANGSTROM = 0.5
CHGNET_MAXIMUM_ATOMIC_NUMBER = 94
FORMULA_CONDITION_LEVELS = {
    ConditionLevel.EXACT_FORMULA_PLUS_SG,
    ConditionLevel.EXACT_FORMULA_ONLY,
}
SPACE_GROUP_CONDITION_LEVELS = {
    ConditionLevel.EXACT_FORMULA_PLUS_SG,
    ConditionLevel.SG_ONLY,
}


def attempt_evaluation_id(attempt: AttemptRecord) -> str:
    """Return the unique deterministic identity used by EvalMLIP journals."""

    if not isinstance(attempt, AttemptRecord):
        raise TypeError("EvalMLIP conversion requires an AttemptRecord")
    identity = {
        "model": attempt.model,
        "training_seed": attempt.training_seed,
        "condition_id": attempt.condition.condition_id,
        "sample_index": attempt.sample_index,
        "registered_seed": attempt.registered_seed,
    }
    digest = hashlib.sha256(
        json.dumps(identity, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    return f"external-eval-{digest}"


def _minimum_periodic_distance(structure: Structure) -> float | None:
    if len(structure) <= 1:
        return None
    distances = np.asarray(structure.distance_matrix, dtype=float).copy()
    np.fill_diagonal(distances, np.inf)
    finite = distances[np.isfinite(distances)]
    if finite.size == 0:
        raise FloatingPointError("periodic distance matrix has no finite separation")
    minimum = float(finite.min())
    if not math.isfinite(minimum) or minimum < 0.0:
        raise FloatingPointError("minimum periodic distance is nonfinite")
    return minimum


def _detect_space_groups(
    structure: Structure,
) -> tuple[dict[str, int | None], dict[str, str], list[str]]:
    detected: dict[str, int | None] = {}
    failures: dict[str, str] = {}
    retained_warnings: list[str] = []
    for symprec in SYMPREC_VALUES:
        label = f"{symprec:.2f}"
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            try:
                number = int(
                    SpacegroupAnalyzer(
                        structure,
                        symprec=symprec,
                        angle_tolerance=5.0,
                    ).get_space_group_number()
                )
                if not 1 <= number <= 230:
                    raise ValueError(f"invalid detected space group: {number}")
            except Exception as error:
                detected[label] = None
                failures[label] = f"{type(error).__name__}: {error}"
            else:
                detected[label] = number
            retained_warnings.extend(
                f"symprec={label}: {item.category.__name__}: {item.message}" for item in caught
            )
    return detected, failures, retained_warnings


def _common_record(attempt: AttemptRecord) -> dict[str, Any]:
    generated = attempt.status is AttemptStatus.GENERATED
    structure: Structure | None = None
    parse_valid = False
    parse_failure_reason: str | None = None
    finite_geometry: bool | None = None
    positive_volume: bool | None = None
    site_count = len(attempt.structure.atomic_numbers) if attempt.structure is not None else None
    supported_element_domain: bool | None = None
    supported_site_geometry: bool | None = None
    minimum_distance: float | None = None
    short_contact_free = False
    detected = {f"{value:.2f}": None for value in SYMPREC_VALUES}
    detection_failures: dict[str, str] = {}
    retained_warnings: list[str] = []

    if generated:
        try:
            structure = attempt.structure.to_pymatgen()  # type: ignore[union-attr]
            lattice = np.asarray(structure.lattice.matrix, dtype=float)
            coordinates = np.asarray(structure.frac_coords, dtype=float)
            finite_geometry = bool(np.isfinite(lattice).all() and np.isfinite(coordinates).all())
            volume = float(structure.lattice.volume)
            positive_volume = bool(math.isfinite(volume) and volume > 0.0)
            supported_element_domain = bool(
                len(structure) > 0
                and all(
                    1 <= int(site.specie.Z) <= CHGNET_MAXIMUM_ATOMIC_NUMBER for site in structure
                )
            )
            minimum_distance = _minimum_periodic_distance(structure)
            supported_site_geometry = bool(
                len(structure) > 0 and finite_geometry and positive_volume
            )
            short_contact_free = bool(
                supported_site_geometry
                and (
                    minimum_distance is None or minimum_distance >= SHORT_CONTACT_DISTANCE_ANGSTROM
                )
            )
            detected, detection_failures, retained_warnings = _detect_space_groups(structure)
            parse_valid = True
        except Exception as error:
            parse_failure_reason = f"{type(error).__name__}: {error}"
    else:
        parse_failure_reason = attempt.failure_code

    formula_conditioned = attempt.condition_level in FORMULA_CONDITION_LEVELS
    if formula_conditioned and parse_valid:
        composition = compare_structure_composition(
            attempt.condition,
            attempt.structure,  # type: ignore[arg-type]
        )
        reduced_formula_match: bool | None = bool(composition["reduced_formula_match"])
        exact_cell_count_match: bool | None = bool(composition["exact_cell_count_match"])
        cell_formula_multiplier = composition["cell_formula_multiplier"]
        composition_reason = None
    elif formula_conditioned:
        reduced_formula_match = False
        exact_cell_count_match = False
        cell_formula_multiplier = None
        composition_reason = "STRUCTURE_PARSE_FAILED" if generated else "GENERATION_NOT_AVAILABLE"
    else:
        reduced_formula_match = None
        exact_cell_count_match = None
        cell_formula_multiplier = None
        composition_reason = "NOT_EXACT_FORMULA_CONDITIONED"

    sg_conditioned = attempt.condition_level in SPACE_GROUP_CONDITION_LEVELS
    if sg_conditioned and parse_valid:
        strict_detected = detected["0.03"]
        strict_match: bool | None = strict_detected == attempt.condition.space_group
        sg_reason = None if strict_detected is not None else "SPACE_GROUP_DETECTION_FAILED"
    elif sg_conditioned:
        strict_match = False
        sg_reason = "STRUCTURE_PARSE_FAILED" if generated else "GENERATION_NOT_AVAILABLE"
    else:
        strict_match = None
        sg_reason = "NOT_TARGET_SPACE_GROUP_CONDITIONED"

    legality_reasons: list[str] = []
    if not generated:
        legality_reasons.append(f"GENERATION_{attempt.status.value}")
    elif not parse_valid:
        legality_reasons.append("STRUCTURE_PARSE_FAILED")
    else:
        if finite_geometry is not True:
            legality_reasons.append("NONFINITE_GEOMETRY")
        if positive_volume is not True:
            legality_reasons.append("NONPOSITIVE_VOLUME")
        if supported_element_domain is not True:
            legality_reasons.append("UNSUPPORTED_ELEMENT_DOMAIN")
        if supported_site_geometry is not True:
            legality_reasons.append("UNSUPPORTED_SITE_GEOMETRY")
        if not short_contact_free:
            legality_reasons.append("SHORT_CONTACT_BELOW_0.5_ANGSTROM")
    common_legal = bool(generated and parse_valid and not legality_reasons)

    return {
        "schema_version": COMMON_EVALUATION_SCHEMA,
        "evaluation_id": attempt_evaluation_id(attempt),
        "model": attempt.model,
        "condition_level": attempt.condition_level.value,
        "training_data": attempt.training_data,
        "training_seed": attempt.training_seed,
        "condition_id": attempt.condition.condition_id,
        "attempt_index": attempt.condition.attempt_index,
        "target_space_group": attempt.condition.space_group,
        "sample_index": attempt.sample_index,
        "registered_seed": attempt.registered_seed,
        "generation_status": attempt.status.value,
        "generation_failure_code": attempt.failure_code,
        "generation_failure_message": attempt.failure_message,
        "generated": generated,
        "parse_valid": parse_valid,
        "parse_failure_reason": parse_failure_reason,
        "finite_geometry": finite_geometry,
        "positive_volume": positive_volume,
        "generated_site_count": site_count,
        "supported_element_domain": supported_element_domain,
        "supported_site_geometry": supported_site_geometry,
        "minimum_periodic_distance_angstrom": minimum_distance,
        "short_contact_threshold_angstrom": SHORT_CONTACT_DISTANCE_ANGSTROM,
        "short_contact_free": short_contact_free,
        "common_legal_crystal": common_legal,
        "common_legality_reason_codes": legality_reasons,
        "composition_conditioned": formula_conditioned,
        "reduced_formula_match": reduced_formula_match,
        "exact_cell_count_match": exact_cell_count_match,
        "cell_formula_multiplier": cell_formula_multiplier,
        "composition_metric_unavailable_reason": composition_reason,
        "detected_space_groups": detected,
        "symmetry_detection_failures": detection_failures,
        "symmetry_warnings": retained_warnings,
        "target_space_group_conditioned": sg_conditioned,
        "strict_0_03_space_group_match": strict_match,
        "target_space_group_metric_unavailable_reason": sg_reason,
        "condition_matches_required_for_common_legality": False,
        "retry_count": attempt.retry_count,
        "refill_count": attempt.refill_count,
    }


def common_evaluate_attempts(
    attempts: Sequence[AttemptRecord],
) -> tuple[dict[str, Any], ...]:
    records = tuple(_common_record(attempt) for attempt in attempts)
    identities = [record["evaluation_id"] for record in records]
    if len(set(identities)) != len(identities):
        raise ValueError("common evaluation contains duplicate attempt identities")
    return records


def attempt_to_eval_mlip_record(attempt: AttemptRecord) -> dict[str, Any]:
    evaluation_id = attempt_evaluation_id(attempt)
    condition = attempt.condition.to_dict()
    condition["registered_condition_id"] = condition["condition_id"]
    condition["condition_id"] = evaluation_id
    generated = attempt.status is AttemptStatus.GENERATED
    return {
        "condition": condition,
        "legal_terminal_crystal": generated,
        "failure_code": attempt.failure_code,
        "failure_message": attempt.failure_message,
        "candidate": (attempt.structure.to_dict() if attempt.structure is not None else None),
        "external_benchmark_identity": {
            "model": attempt.model,
            "training_seed": attempt.training_seed,
            "registered_condition_id": attempt.condition.condition_id,
            "sample_index": attempt.sample_index,
            "registered_seed": attempt.registered_seed,
        },
        "retry_count": 0,
        "refill_count": 0,
    }


def _ensure_finite(value: Any, *, label: str = "evaluator output") -> None:
    if isinstance(value, Mapping):
        for key, item in value.items():
            _ensure_finite(item, label=f"{label}/{key}")
        return
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        for index, item in enumerate(value):
            _ensure_finite(item, label=f"{label}/{index}")
        return
    if isinstance(value, numbers.Real) and not isinstance(value, (bool, int)):
        if not math.isfinite(float(value)):
            raise FloatingPointError(f"nonfinite {label}")


def _validate_terminal_provenance(
    provenance: Mapping[str, Any],
    *,
    expected_weight_sha256: str | None = None,
) -> None:
    if provenance.get("role") != "TERMINAL_EVALUATION_ONLY":
        raise ValueError("EvalMLIP terminal-only role drifted")
    for field in (
        "writes_generation_state",
        "enters_training_loss",
        "checkpoint_selection",
    ):
        if provenance.get(field) is not False:
            raise ValueError(f"EvalMLIP terminal boundary drifted: {field}")
    if provenance.get("separate_from_guide_instance") is not True:
        raise ValueError("EvalMLIP must remain separate from GuideMLIP")
    for protocol, relax_cell in (("fixed_cell", False), ("cell_relax", True)):
        config = provenance.get(protocol)
        if not isinstance(config, Mapping):
            raise ValueError(f"EvalMLIP {protocol} protocol provenance is missing")
        expected = {
            "package_version": "0.4.2",
            "model_version": "0.3.0",
            "optimizer": "FIRE",
            "force_threshold_ev_per_angstrom": 0.2,
            "maximum_steps": 300,
            "relax_cell": relax_cell,
            "short_contact_distance": 0.5,
        }
        if any(config.get(name) != value for name, value in expected.items()):
            raise ValueError(f"EvalMLIP {protocol} frozen protocol drifted")
        if (
            expected_weight_sha256 is not None
            and str(config.get("weight_sha256", "")).lower() != expected_weight_sha256
        ):
            raise ValueError("EvalMLIP CHGNet weight hash drifted")


def _validate_eval_payload(
    payload: Mapping[str, Any],
    attempts: Sequence[AttemptRecord],
    *,
    expected_weight_sha256: str | None = None,
    raw_condition_ids: bool = False,
) -> None:
    if payload.get("attempt_count") != len(attempts):
        raise ValueError("EvalMLIP attempt denominator drifted")
    if payload.get("retry_count") != 0 or payload.get("refill_count") != 0:
        raise ValueError("EvalMLIP retry/refill drifted")
    provenance = payload.get("provenance")
    if not isinstance(provenance, Mapping):
        raise ValueError("EvalMLIP provenance is missing")
    _validate_terminal_provenance(provenance, expected_weight_sha256=expected_weight_sha256)
    expected_ids = [
        (attempt.condition.condition_id if raw_condition_ids else attempt_evaluation_id(attempt))
        for attempt in attempts
    ]
    for protocol in ("fixed_cell_fire300", "cell_relax_fire300"):
        protocol_payload = payload.get(protocol)
        if not isinstance(protocol_payload, Mapping):
            raise ValueError(f"EvalMLIP {protocol} payload is missing")
        records = protocol_payload.get("records")
        if not isinstance(records, Sequence) or isinstance(records, (str, bytes)):
            raise ValueError(f"EvalMLIP {protocol} records are missing")
        observed_ids = [str(record.get("condition_id")) for record in records]
        if observed_ids != expected_ids:
            raise ValueError(f"EvalMLIP {protocol} condition mapping drifted")
        for attempt, record in zip(attempts, records, strict=True):
            status = str(record.get("status"))
            if (
                attempt.status is AttemptStatus.GENERATED and status == "SKIPPED_GENERATION_FAILURE"
            ) or (
                attempt.status is not AttemptStatus.GENERATED
                and status != "SKIPPED_GENERATION_FAILURE"
            ):
                raise ValueError(f"EvalMLIP {protocol} generation status mapping drifted")
    _ensure_finite(payload)


def run_eval_mlip_cohort(
    attempts: Sequence[AttemptRecord],
    *,
    config: ExternalBenchmarkConfig,
    repo_root: str | Path,
    evaluator: Any,
    output_dir: str | Path,
) -> dict[str, Any]:
    preflight_frozen_inputs(config, repo_root)
    frozen = tuple(attempts)
    if not frozen:
        raise ValueError("EvalMLIP cohort requires registered attempts")
    converted = tuple(attempt_to_eval_mlip_record(attempt) for attempt in frozen)
    identities = [record["condition"]["condition_id"] for record in converted]
    if len(set(identities)) != len(identities):
        raise ValueError("EvalMLIP cohort condition IDs are not unique")
    payload = evaluator.evaluate(converted, output_dir=output_dir)
    if not isinstance(payload, Mapping):
        raise ValueError("EvalMLIP returned a non-object payload")
    _validate_eval_payload(
        payload,
        frozen,
        expected_weight_sha256=config.frozen_artifact_sha256["chgnet_weights"],
    )
    return dict(payload)


def _base_config_path(config: ExternalBenchmarkConfig, repo_root: str | Path) -> Path:
    if config.base_config_path.is_absolute():
        return config.base_config_path
    return Path(repo_root).resolve() / config.base_config_path


def build_frozen_eval_mlip(
    config: ExternalBenchmarkConfig,
    *,
    repo_root: str | Path,
    evaluator_factory: Callable[[FullCrysalisConfig], Any] | None = None,
) -> Any:
    preflight_frozen_inputs(config, repo_root)
    base_path = _base_config_path(config, repo_root)
    if sha256_file(base_path) != config.base_config_sha256:
        raise ValueError("frozen Full Crysalis base config hash mismatch")
    full_config = FullCrysalisConfig.from_json(base_path)
    weights = full_config.artifacts["chgnet_weights"]
    if weights.sha256.lower() != config.frozen_artifact_sha256["chgnet_weights"]:
        raise ValueError("frozen CHGNet weight declaration drifted")
    factory = EvalMLIP.from_config if evaluator_factory is None else evaluator_factory
    return factory(full_config)


def _read_json_object(path: Path, *, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise FileNotFoundError(f"{label} is missing: {path}") from None
    if not isinstance(value, dict):
        raise ValueError(f"{label} must be a JSON object")
    return value


def _frozen_eval_path_and_digest(config: ExternalBenchmarkConfig, seed: int) -> tuple[Path, str]:
    if seed == 20260823:
        root = config.positive_run_root
        receipt_path = root / "engineering/evaluate_complete.json"
    else:
        root = config.replication_root
        receipt_path = root / f"engineering/receipts/evaluate_{seed}.json"
    receipt = _read_json_object(receipt_path, label=f"seed {seed} evaluation receipt")
    if (
        receipt.get("status") != "COMPLETE"
        or receipt.get("retry_count") != 0
        or receipt.get("refill_count") != 0
        or receipt.get("sealed_or_blind_data_accessed") is not False
    ):
        raise ValueError(f"seed {seed} frozen evaluation receipt drifted")
    hashes = receipt.get("output_sha256")
    if not isinstance(hashes, Mapping):
        raise ValueError(f"seed {seed} frozen evaluation hashes are missing")
    matches = [
        (str(relative), str(digest).lower())
        for relative, digest in hashes.items()
        if str(relative).replace("\\", "/").endswith("evaluation/physics_results.json")
    ]
    if len(matches) != 1:
        raise ValueError(f"seed {seed} frozen physics result identity drifted")
    relative, digest = matches[0]
    path = root / Path(relative)
    if sha256_file(path) != digest:
        raise ValueError(f"seed {seed} frozen physics result hash mismatch")
    return path, digest


def _frozen_generation_path_and_digest(
    config: ExternalBenchmarkConfig, seed: int
) -> tuple[Path, str]:
    if seed == 20260823:
        root = config.positive_run_root
        receipt_path = root / "engineering/generate_complete.json"
    else:
        root = config.replication_root
        receipt_path = root / f"engineering/receipts/generate_{seed}.json"
    receipt = _read_json_object(receipt_path, label=f"seed {seed} generation receipt")
    if (
        receipt.get("status") != "COMPLETE"
        or receipt.get("retry_count") != 0
        or receipt.get("refill_count") != 0
        or receipt.get("sealed_or_blind_data_accessed") is not False
    ):
        raise ValueError(f"seed {seed} frozen generation receipt drifted")
    hashes = receipt.get("output_sha256")
    if not isinstance(hashes, Mapping):
        raise ValueError(f"seed {seed} frozen generation hashes are missing")
    matches = [
        (str(relative), str(digest).lower())
        for relative, digest in hashes.items()
        if str(relative).replace("\\", "/").endswith("generation/generation_records.json")
    ]
    if len(matches) != 1:
        raise ValueError(f"seed {seed} frozen generation identity drifted")
    relative, digest = matches[0]
    path = root / Path(relative)
    if sha256_file(path) != digest:
        raise ValueError(f"seed {seed} frozen generation hash mismatch")
    return path, digest


def _frozen_checkpoint_contract(
    config: ExternalBenchmarkConfig,
    seed: int,
) -> tuple[Path, str]:
    seed_report = _read_json_object(
        config.replication_root / f"FULL_REPLICATION_SEED_{seed}.json",
        label=f"seed {seed} frozen replication report",
    )
    if seed_report.get("training_seed") != seed:
        raise ValueError(f"seed {seed} frozen training identity drifted")
    training = seed_report.get("training")
    if not isinstance(training, Mapping):
        raise ValueError(f"seed {seed} frozen training provenance is missing")
    checkpoint_name = str(training.get("checkpoint_file", ""))
    checkpoint_digest = str(training.get("checkpoint_sha256", "")).lower()
    if checkpoint_name != "best.pt" or len(checkpoint_digest) != 64:
        raise ValueError(f"seed {seed} frozen checkpoint declaration drifted")
    checkpoint_path = (
        config.positive_run_root / "training" / checkpoint_name
        if seed == 20260823
        else config.replication_root / f"engineering/seeds/{seed}/training" / checkpoint_name
    )
    if sha256_file(checkpoint_path) != checkpoint_digest:
        raise ValueError(f"seed {seed} frozen checkpoint hash mismatch")
    return checkpoint_path, checkpoint_digest


def _normalize_reused_eval_payload(
    payload: Mapping[str, Any],
    attempts: Sequence[AttemptRecord],
    *,
    expected_weight_sha256: str,
) -> dict[str, Any]:
    normalized = dict(payload)
    for protocol in ("fixed_cell_fire300", "cell_relax_fire300"):
        protocol_payload = dict(payload[protocol])
        records = []
        for attempt, record in zip(
            attempts,
            protocol_payload["records"],
            strict=True,
        ):
            normalized_record = dict(record)
            normalized_record["registered_condition_id"] = str(normalized_record["condition_id"])
            normalized_record["condition_id"] = attempt_evaluation_id(attempt)
            records.append(normalized_record)
        protocol_payload["records"] = records
        normalized[protocol] = protocol_payload
    _validate_eval_payload(
        normalized,
        attempts,
        expected_weight_sha256=expected_weight_sha256,
    )
    return normalized


def load_frozen_crysalis_evaluations(
    config: ExternalBenchmarkConfig,
    attempts_by_seed: Mapping[int, Sequence[AttemptRecord]],
    *,
    repo_root: str | Path,
) -> dict[int, dict[str, Any]]:
    preflight_frozen_inputs(config, repo_root)
    if set(attempts_by_seed) != set(CRYSALIS_TRAINING_SEEDS):
        raise ValueError("frozen Crysalis reuse requires all three training seeds")
    conditions = load_registered_conditions_from_config(config)
    if sum(len(attempts_by_seed[seed]) for seed in CRYSALIS_TRAINING_SEEDS) != 900:
        raise ValueError("frozen Crysalis reuse requires exactly 900 attempts")
    reused: dict[int, dict[str, Any]] = {}
    expected_conditions = [condition.to_dict() for condition in conditions]
    for seed in CRYSALIS_TRAINING_SEEDS:
        attempts = tuple(attempts_by_seed[seed])
        if len(attempts) != 300:
            raise ValueError(f"frozen Crysalis seed {seed} requires 300 attempts")
        if any(
            attempt.model != "FULL_CRYSALIS"
            or attempt.training_seed != seed
            or attempt.sample_index != 0
            for attempt in attempts
        ):
            raise ValueError(f"frozen Crysalis seed {seed} identity mapping drifted")
        observed_conditions = [attempt.condition.to_dict() for attempt in attempts]
        if observed_conditions != expected_conditions:
            raise ValueError(f"frozen Crysalis seed {seed} condition mapping drifted")
        checkpoint_path, checkpoint_digest = _frozen_checkpoint_contract(config, seed)
        if any(
            attempt.provenance.implementation_commit != config.reference_commit
            or Path(attempt.provenance.checkpoint).resolve() != checkpoint_path.resolve()
            or attempt.provenance.checkpoint_sha256 != checkpoint_digest
            for attempt in attempts
        ):
            raise ValueError(f"frozen Crysalis seed {seed} model provenance drifted")
        generation_path, generation_digest = _frozen_generation_path_and_digest(config, seed)
        if any(
            attempt.provenance.source_artifact is None
            or Path(attempt.provenance.source_artifact).resolve() != generation_path.resolve()
            or attempt.provenance.source_artifact_sha256 != generation_digest
            for attempt in attempts
        ):
            raise ValueError(f"frozen Crysalis seed {seed} generation artifact mapping drifted")
        physics_path, digest = _frozen_eval_path_and_digest(config, seed)
        payload = _read_json_object(physics_path, label=f"seed {seed} frozen physics result")
        _validate_eval_payload(
            payload,
            attempts,
            expected_weight_sha256=config.frozen_artifact_sha256["chgnet_weights"],
            raw_condition_ids=True,
        )
        bound = _normalize_reused_eval_payload(
            payload,
            attempts,
            expected_weight_sha256=config.frozen_artifact_sha256["chgnet_weights"],
        )
        bound.update(
            {
                "training_seed": seed,
                "reused_after_hash_verification": True,
                "source_path": str(physics_path.resolve()),
                "source_sha256": digest,
                "generation_source_path": str(generation_path.resolve()),
                "generation_source_sha256": generation_digest,
                "checkpoint_path": str(checkpoint_path.resolve()),
                "checkpoint_sha256": checkpoint_digest,
                "exact_seed_condition_mapping_verified": True,
            }
        )
        reused[seed] = bound
    return reused
