"""Read-only attribution of preserved common cell-relax evaluation failures."""

from __future__ import annotations

import hashlib
import json
import math
from collections import Counter
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np

from crysalis_g1.external_benchmark.evaluation import attempt_evaluation_id
from crysalis_g1.external_benchmark.provenance import sha256_file
from crysalis_g1.external_benchmark.records import AttemptRecord, AttemptStatus


ATTRIBUTION_CLASSES = (
    "PHYSICAL_COLLAPSE_CONFIRMED",
    "RESOURCE_LIMITED_EVALUATION",
    "OOM_CAUSE_UNRESOLVED",
)
CHGNET_ATOM_GRAPH_CUTOFF_ANGSTROM = 6.0


def _optional_number(value: object) -> float | None:
    if type(value) not in {int, float}:
        return None
    result = float(value)
    return result if math.isfinite(result) else None


def _optional_integer(value: object) -> int | None:
    if type(value) is not int or value < 0:
        return None
    return value


def _ratio(numerator: float | int | None, denominator: float | int | None) -> float | None:
    if numerator is None or denominator is None or denominator <= 0:
        return None
    result = float(numerator) / float(denominator)
    return result if math.isfinite(result) else None


def _canonical_sha256(payload: Mapping[str, Any]) -> str:
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode()
    return hashlib.sha256(encoded).hexdigest()


def classify_failure(record: Mapping[str, Any]) -> tuple[str, str, str]:
    """Classify only from evidence already retained in the immutable record."""

    diagnostics = record.get("diagnostics")
    diagnostic = diagnostics if isinstance(diagnostics, Mapping) else {}
    failure_code = str(record.get("failure_code") or "")
    message = str(record.get("exception_message") or "")
    cuda_oom = failure_code == "CHGNET_CELL_RELAX_CUDA_OOM" or (
        "cuda" in message.lower() and "out of memory" in message.lower()
    )
    terminal_symptom = "CUDA_OOM" if cuda_oom else "EVALUATOR_FAILURE"

    if diagnostic.get("root_cause") == "RUNAWAY_CELL_COLLAPSE_AND_NEIGHBOR_GRAPH_GROWTH":
        return (
            "PHYSICAL_COLLAPSE_CONFIRMED",
            terminal_symptom,
            "physical_survival=false; CUDA OOM is the terminal technical symptom",
        )
    if "isolated atom" in message.lower():
        return (
            "PHYSICAL_COLLAPSE_CONFIRMED",
            "CHGNET_ISOLATED_ATOM_GRAPH",
            "physical_survival=false; generated geometry is explicitly disconnected",
        )
    if (
        diagnostic.get("root_cause") == "LOCAL_GPU_RESOURCE_LIMIT_WITHOUT_GEOMETRIC_COLLAPSE"
        and diagnostic.get("trajectory_geometry_remained_normal") is True
        and diagnostic.get("neighbor_graph_remained_normal") is True
    ):
        return (
            "RESOURCE_LIMITED_EVALUATION",
            terminal_symptom,
            "exclude from model physical-failure count; report as evaluator-resource censoring",
        )
    return (
        "OOM_CAUSE_UNRESOLVED",
        terminal_symptom,
        "do not attribute to model or hardware; report separately",
    )


def _minimum_periodic_distance(attempt: AttemptRecord) -> float | None:
    assert attempt.structure is not None
    structure = attempt.structure.to_pymatgen()
    if len(structure) <= 1:
        return None
    distances = np.asarray(structure.distance_matrix, dtype=float).copy()
    np.fill_diagonal(distances, np.inf)
    finite = distances[np.isfinite(distances)]
    return None if finite.size == 0 else float(finite.min())


def _initial_geometry(attempt: AttemptRecord) -> tuple[float, int, float | None]:
    if attempt.status is not AttemptStatus.GENERATED or attempt.structure is None:
        raise ValueError("preserved cell-relax failure lacks its frozen generated structure")
    structure = attempt.structure.to_pymatgen()
    volume = float(structure.volume)
    neighbor_count = int(len(structure.get_neighbor_list(CHGNET_ATOM_GRAPH_CUTOFF_ANGSTROM)[0]))
    return volume, neighbor_count, _minimum_periodic_distance(attempt)


def _prefer_retained_number(
    retained: object,
    computed: float,
    *,
    label: str,
) -> float:
    observed = _optional_number(retained)
    if observed is None:
        return computed
    if not math.isclose(observed, computed, rel_tol=1e-10, abs_tol=1e-10):
        raise ValueError(f"retained {label} differs from frozen input geometry")
    return observed


def _prefer_retained_integer(retained: object, computed: int, *, label: str) -> int:
    observed = _optional_integer(retained)
    if observed is None:
        return computed
    if observed != computed:
        raise ValueError(f"retained {label} differs from frozen input geometry")
    return observed


def _evidence(
    record: Mapping[str, Any],
    *,
    failure_class: str,
    initial_minimum_distance: float | None,
) -> list[dict[str, Any]]:
    diagnostics = record.get("diagnostics")
    diagnostic = diagnostics if isinstance(diagnostics, Mapping) else {}
    evidence: list[dict[str, Any]] = [
        {
            "source": "immutable_cell_relax_failure_record",
            "failure_code": record.get("failure_code"),
            "exception_type": record.get("exception_type"),
            "exception_message": record.get("exception_message"),
        },
        {
            "source": "frozen_input_geometry_read_only",
            "initial_minimum_periodic_distance_angstrom": initial_minimum_distance,
            "atom_graph_cutoff_angstrom": CHGNET_ATOM_GRAPH_CUTOFF_ANGSTROM,
        },
    ]
    if diagnostic:
        evidence.append({"source": "preserved_diagnostics", **dict(diagnostic)})
    if failure_class == "OOM_CAUSE_UNRESOLVED":
        evidence.append(
            {
                "source": "evidence_availability",
                "finding": (
                    "no preserved last-valid trajectory geometry and neighbor statistics "
                    "sufficient to distinguish collapse from a 12GB resource limit"
                ),
            }
        )
    return evidence


def build_cell_relax_failure_attribution(
    failure_records: Sequence[Mapping[str, Any]],
    attempts: Sequence[AttemptRecord],
) -> dict[str, Any]:
    """Build an attribution payload without executing CHGNet or relaxation."""

    failures = tuple(dict(record) for record in failure_records)
    if not failures:
        raise ValueError("cell-relax failure attribution requires preserved failures")
    by_evaluation_id = {attempt_evaluation_id(attempt): attempt for attempt in attempts}
    if len(by_evaluation_id) != len(attempts):
        raise ValueError("attempt evaluation identities are not unique")

    rows: list[dict[str, Any]] = []
    for record in failures:
        evaluation_id = str(record.get("condition_id") or "")
        attempt = by_evaluation_id.get(evaluation_id)
        if attempt is None:
            raise ValueError(f"preserved failure has no frozen attempt: {evaluation_id}")
        computed_volume, computed_neighbors, initial_minimum_distance = _initial_geometry(attempt)
        diagnostics = record.get("diagnostics")
        diagnostic = diagnostics if isinstance(diagnostics, Mapping) else {}
        initial_volume = _prefer_retained_number(
            diagnostic.get("initial_volume_angstrom3"),
            computed_volume,
            label="initial volume",
        )
        initial_neighbors = _prefer_retained_integer(
            diagnostic.get("initial_neighbor_edges"),
            computed_neighbors,
            label="initial neighbor count",
        )
        last_volume = _optional_number(
            diagnostic.get(
                "last_valid_cell_volume_angstrom3",
                diagnostic.get("last_observed_volume_angstrom3"),
            )
        )
        last_neighbors = _optional_integer(
            diagnostic.get(
                "last_valid_neighbor_edges",
                diagnostic.get("last_observed_neighbor_edges"),
            )
        )
        last_minimum_distance = _optional_number(
            diagnostic.get(
                "last_valid_minimum_distance_angstrom",
                diagnostic.get("last_observed_minimum_distance_angstrom"),
            )
        )
        failure_class, terminal_symptom, counting_rule = classify_failure(record)
        cuda_oom = terminal_symptom == "CUDA_OOM"
        rows.append(
            {
                "model": attempt.model,
                "condition_id": attempt.condition.condition_id,
                "sample_id": evaluation_id,
                "sample_index": attempt.sample_index,
                "initial_cell_volume": initial_volume,
                "last_valid_cell_volume": last_volume,
                "volume_ratio": _ratio(last_volume, initial_volume),
                "initial_neighbor_count": initial_neighbors,
                "last_neighbor_count": last_neighbors,
                "neighbor_growth_ratio": _ratio(last_neighbors, initial_neighbors),
                "initial_minimum_distance": initial_minimum_distance,
                "last_valid_minimum_distance": last_minimum_distance,
                "nonfinite_geometry_seen": bool(diagnostic.get("nonfinite_geometry_seen", False)),
                "cuda_oom": cuda_oom,
                "failure_class": failure_class,
                "terminal_symptom": terminal_symptom,
                "evidence": _evidence(
                    record,
                    failure_class=failure_class,
                    initial_minimum_distance=initial_minimum_distance,
                ),
                "scientific_counting_rule": counting_rule,
                "original_failure_record_sha256": _canonical_sha256(record),
                "original_failure_record": record,
            }
        )

    class_counts = Counter(row["failure_class"] for row in rows)
    by_model: dict[str, dict[str, int]] = {}
    for model in sorted({str(row["model"]) for row in rows}):
        counts = Counter(row["failure_class"] for row in rows if row["model"] == model)
        by_model[model] = {name: counts[name] for name in ATTRIBUTION_CLASSES}
    return {
        "schema_version": "g1-cell-relax-failure-attribution.1.0.0",
        "audit_mode": "READ_ONLY_FAILURE_ATTRIBUTION",
        "raw_records_modified": False,
        "relaxations_executed": 0,
        "retry_count": 0,
        "refill_count": 0,
        "neighbor_count_definition": (
            "directed periodic atom-graph edges from pymatgen get_neighbor_list at "
            f"{CHGNET_ATOM_GRAPH_CUTOFF_ANGSTROM:.1f} angstrom; verified against retained "
            "CHGNet diagnostic edge count"
        ),
        "failure_count": len(rows),
        "summary": {
            "by_failure_class": {name: class_counts[name] for name in ATTRIBUTION_CLASSES},
            "by_model": by_model,
        },
        "failures": rows,
    }


def build_attribution_from_frozen_common(
    config: object,
    repo_root: str | Path,
) -> dict[str, Any]:
    """Read the immutable common journal and frozen attempts; never run EvalMLIP."""

    from crysalis_g1.external_benchmark.formal_completion import _all_attempts

    output_root = Path(getattr(config, "output_root")).resolve()
    record_path = (
        output_root / "engineering/stages/common_chgnet/evalmlip/cell_relax_fire300_records.jsonl"
    )
    common_path = output_root / "engineering/stages/common_chgnet/common_chgnet.json"
    if not record_path.is_file() or not common_path.is_file():
        raise FileNotFoundError("frozen common CHGNet artifacts are missing")
    all_records = [
        json.loads(line) for line in record_path.read_text(encoding="utf-8").splitlines()
    ]
    failures = tuple(
        record for record in all_records if record.get("status") == "CHGNET_RELAXATION_FAILED"
    )
    payload = build_cell_relax_failure_attribution(
        failures,
        _all_attempts(config, Path(repo_root).resolve()),
    )
    payload["source_artifacts"] = {
        "cell_relax_fire300_records": {
            "path": record_path.relative_to(output_root).as_posix(),
            "sha256": sha256_file(record_path),
            "record_count": len(all_records),
            "failure_count": len(failures),
        },
        "common_chgnet": {
            "path": common_path.relative_to(output_root).as_posix(),
            "sha256": sha256_file(common_path),
        },
    }
    payload["evidence_availability"] = {
        "preserved_per_failure_record": True,
        "preserved_last_valid_trajectory_geometry_for_all_failures": False,
        "classification_is_fail_closed": True,
    }
    return payload


def write_engineering_attribution_artifacts(
    config: object,
    repo_root: str | Path,
) -> tuple[Path, Path]:
    """Write the two immutable audit artifacts under the engineering tree."""

    from crysalis_g1.external_benchmark.reporting import _atomic_write_new
    from crysalis_g1.external_benchmark.runner import _atomic_write_json_new

    output_root = Path(getattr(config, "output_root")).resolve()
    stage = output_root / "engineering/stages/cell_relax_failure_attribution"
    json_path = stage / "CELL_RELAX_FAILURE_ATTRIBUTION.json"
    markdown_path = stage / "CELL_RELAX_FAILURE_ATTRIBUTION.md"
    if json_path.exists() or markdown_path.exists():
        raise FileExistsError("immutable cell-relax attribution artifact already exists")
    payload = build_attribution_from_frozen_common(config, repo_root)
    _atomic_write_json_new(json_path, payload)
    try:
        _atomic_write_new(
            markdown_path,
            render_cell_relax_failure_attribution(payload).encode("utf-8"),
        )
    except BaseException:
        json_path.unlink(missing_ok=True)
        raise
    return json_path, markdown_path


def render_cell_relax_failure_attribution(payload: Mapping[str, Any]) -> str:
    summary = payload.get("summary")
    if not isinstance(summary, Mapping):
        raise ValueError("failure attribution summary is missing")
    class_counts = summary.get("by_failure_class")
    by_model = summary.get("by_model")
    if not isinstance(class_counts, Mapping) or not isinstance(by_model, Mapping):
        raise ValueError("failure attribution summary is malformed")
    lines = [
        "# Cell-relax Failure Attribution",
        "",
        "This is a read-only attribution of preserved failures. No CHGNet/FIRE300 "
        "sample was rerun, retried, refilled, or rewritten.",
        "",
        "| Failure class | Count |",
        "|---|---:|",
    ]
    lines.extend(f"| {name} | {int(class_counts.get(name, 0))} |" for name in ATTRIBUTION_CLASSES)
    lines.extend(
        (
            "",
            "| Model | PHYSICAL_COLLAPSE_CONFIRMED | RESOURCE_LIMITED_EVALUATION | "
            "OOM_CAUSE_UNRESOLVED | Total |",
            "|---|---:|---:|---:|---:|",
        )
    )
    for model, counts in sorted(by_model.items()):
        if not isinstance(counts, Mapping):
            raise ValueError("per-model failure attribution is malformed")
        values = [int(counts.get(name, 0)) for name in ATTRIBUTION_CLASSES]
        lines.append(f"| {model} | {values[0]} | {values[1]} | {values[2]} | {sum(values)} |")
    lines.extend(
        (
            "",
            "Confirmed collapse means physical/geometric collapse with any CUDA OOM "
            "recorded only as the terminal technical symptom. Resource-limited and "
            "unresolved cases are not automatically assigned as model physical failures.",
            "",
        )
    )
    return "\n".join(lines)


def validate_cell_relax_failure_attribution(payload: object) -> None:
    if not isinstance(payload, Mapping):
        raise ValueError("cell-relax failure attribution must be a JSON object")
    failures = payload.get("failures")
    summary = payload.get("summary")
    if (
        payload.get("schema_version") != "g1-cell-relax-failure-attribution.1.0.0"
        or payload.get("audit_mode") != "READ_ONLY_FAILURE_ATTRIBUTION"
        or payload.get("raw_records_modified") is not False
        or payload.get("relaxations_executed") != 0
        or payload.get("retry_count") != 0
        or payload.get("refill_count") != 0
        or not isinstance(failures, list)
        or payload.get("failure_count") != len(failures)
        or not isinstance(summary, Mapping)
    ):
        raise ValueError("cell-relax failure attribution contract drifted")
    observed_ids: set[str] = set()
    observed_classes: Counter[str] = Counter()
    observed_models: dict[str, Counter[str]] = {}
    required = {
        "model",
        "condition_id",
        "sample_id",
        "initial_cell_volume",
        "last_valid_cell_volume",
        "volume_ratio",
        "initial_neighbor_count",
        "last_neighbor_count",
        "neighbor_growth_ratio",
        "last_valid_minimum_distance",
        "nonfinite_geometry_seen",
        "cuda_oom",
        "failure_class",
        "evidence",
        "scientific_counting_rule",
        "original_failure_record_sha256",
        "original_failure_record",
    }
    for row in failures:
        if not isinstance(row, Mapping) or not required.issubset(row):
            raise ValueError("cell-relax failure attribution row is incomplete")
        model = str(row.get("model") or "")
        sample_id = str(row.get("sample_id") or "")
        failure_class = str(row.get("failure_class") or "")
        if (
            not model
            or not sample_id
            or sample_id in observed_ids
            or failure_class not in ATTRIBUTION_CLASSES
            or type(row.get("cuda_oom")) is not bool
            or type(row.get("nonfinite_geometry_seen")) is not bool
            or not isinstance(row.get("evidence"), list)
            or not row["evidence"]
            or not str(row.get("scientific_counting_rule") or "")
            or not isinstance(row.get("original_failure_record"), Mapping)
            or row.get("original_failure_record_sha256")
            != _canonical_sha256(row["original_failure_record"])
        ):
            raise ValueError("cell-relax failure attribution row is malformed")
        initial_volume = _optional_number(row.get("initial_cell_volume"))
        initial_neighbors = _optional_integer(row.get("initial_neighbor_count"))
        last_volume = _optional_number(row.get("last_valid_cell_volume"))
        last_neighbors = _optional_integer(row.get("last_neighbor_count"))
        if initial_volume is None or initial_volume <= 0 or initial_neighbors is None:
            raise ValueError("cell-relax failure initial geometry is missing")
        for observed, expected, label in (
            (row.get("volume_ratio"), _ratio(last_volume, initial_volume), "volume"),
            (
                row.get("neighbor_growth_ratio"),
                _ratio(last_neighbors, initial_neighbors),
                "neighbor",
            ),
        ):
            if expected is None:
                if observed is not None:
                    raise ValueError(f"cell-relax {label} ratio must be unavailable")
            elif _optional_number(observed) is None or not math.isclose(
                float(observed), expected, rel_tol=1e-12, abs_tol=1e-15
            ):
                raise ValueError(f"cell-relax {label} ratio drifted")
        observed_ids.add(sample_id)
        observed_classes[failure_class] += 1
        observed_models.setdefault(model, Counter())[failure_class] += 1
    expected_class_counts = {name: observed_classes[name] for name in ATTRIBUTION_CLASSES}
    expected_model_counts = {
        model: {name: counts[name] for name in ATTRIBUTION_CLASSES}
        for model, counts in sorted(observed_models.items())
    }
    if (
        summary.get("by_failure_class") != expected_class_counts
        or summary.get("by_model") != expected_model_counts
    ):
        raise ValueError("cell-relax failure attribution summary was not recomputed")
