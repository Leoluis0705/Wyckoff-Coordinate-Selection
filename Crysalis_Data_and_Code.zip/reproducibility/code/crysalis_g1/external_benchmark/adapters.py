from __future__ import annotations

import csv
import hashlib
import json
import os
import re
import subprocess
import tempfile
import time
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import StrEnum
from pathlib import Path
from types import MappingProxyType
from typing import Any, Iterable, Mapping, Sequence

import psutil
from pymatgen.core import Structure

from crysalis_g1.external_benchmark.capabilities import (
    UNKNOWN_DIGEST,
    BaselineCapability,
    ConditionLevel,
    ExecutionStatus,
    PrimaryTrack,
)
from crysalis_g1.external_benchmark.config import ExternalBenchmarkConfig
from crysalis_g1.external_benchmark.provenance import sha256_file
from crysalis_g1.external_benchmark.records import (
    AttemptRecord,
    AttemptStatus,
    ModelProvenance,
    RegisteredCondition,
    StructurePayload,
    formula_from_composition,
    registered_sample_seed,
    validate_formal_attempts,
)


COMMAND_RECEIPT_SCHEMA = "g1-official-command-receipt.1.0.0"
MAPPING_RECEIPT_SCHEMA = "g1-official-output-mapping.1.0.0"
CRYSTALFORMER_ROW_SCHEMA = "g1-crystalformer-official-driver-row.1.0.0"
CRYSTALFORMER_RECEIPT_SCHEMA = "g1-crystalformer-official-driver-receipt.1.1.0"
CRYSTALFORMER_SHARDS = frozenset({(0, 1), (1, 4)})
UNAVAILABLE_COMMIT = "0" * 40
UNAVAILABLE_SHA256 = "0" * 64
_SHA256 = re.compile(r"[0-9a-f]{64}")
_FROZEN_RECEIPT_KEYS = {
    "schema_version",
    "status",
    "replication_decision",
    "reference_commit",
    "formal_attempt_count",
    "training_seeds",
    "condition_manifest_sha256",
    "replication_artifact_sha256",
    "positive_reference_artifact_sha256",
    "frozen_artifact_sha256",
    "frozen_core_sha256",
    "source_boundary",
}
_MAPPING_KEYS = {
    "schema_version",
    "model",
    "condition_level",
    "training_data",
    "official_commit",
    "checkpoint_sha256",
    "samples_per_condition",
    "retry_count",
    "refill_count",
    "entries",
}
_MAPPING_ENTRY_KEYS = {
    "condition_id",
    "sample_index",
    "registered_seed",
    "output_path",
    "output_sha256",
    "output_format",
    "output_index",
    "structure_field",
}
_CRYSTALFORMER_RECEIPT_KEYS = {
    "schema_version",
    "status",
    "model",
    "official_checkout",
    "official_commit",
    "checkpoint_path",
    "checkpoint_sha256",
    "condition_manifest_path",
    "condition_manifest_sha256",
    "expected_condition_count",
    "sample_index_start",
    "sample_count",
    "attempt_count",
    "generated_count",
    "failed_count",
    "denominator_complete",
    "retry_count",
    "refill_count",
    "checkpoint_load_count",
    "sampler_cache_count",
    "observed_space_groups",
    "temperature",
    "top_p",
    "batch_size",
    "samples_per_condition",
    "output_jsonl_path",
    "output_jsonl_sha256",
    "started_at",
    "ended_at",
    "abort_code",
    "environment",
}
_CRYSTALFORMER_ROW_KEYS = {
    "schema_version",
    "condition_id",
    "attempt_index",
    "sample_index",
    "registered_seed",
    "formula",
    "target_space_group",
    "status",
    "failure_code",
    "failure_message",
    "raw",
    "structure",
    "reduced_formula_match",
    "exact_cell_count_match",
    "generation_latency_seconds",
    "retry_count",
    "refill_count",
}


def _validate_crystalformer_shard(sample_index_start: int, sample_count: int) -> tuple[int, int]:
    if (
        type(sample_index_start) is not int
        or type(sample_count) is not int
        or (sample_index_start, sample_count) not in CRYSTALFORMER_SHARDS
    ):
        raise ValueError(
            "registered CrystalFormer shard must be primary (start=0,count=1) "
            "or secondary (start=1,count=4)"
        )
    return sample_index_start, sample_count


class OutputFormat(StrEnum):
    CIF = "CIF"
    JSON = "JSON"
    CSV_JSON = "CSV_JSON"
    CSV_CIF = "CSV_CIF"


def _canonical_digest(payload: object) -> str:
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


def _json_bytes(payload: object) -> bytes:
    return (
        json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n"
    ).encode("utf-8")


def _atomic_write_json_new(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(f"immutable receipt already exists: {path}")
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb", dir=path.parent, prefix=f".{path.name}.", delete=False
        ) as handle:
            temporary = Path(handle.name)
            handle.write(_json_bytes(payload))
            handle.flush()
            os.fsync(handle.fileno())
        os.link(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _git_output(checkout: Path, arguments: tuple[str, ...]) -> str:
    completed = subprocess.run(
        ["git", *arguments],
        cwd=checkout,
        check=True,
        shell=False,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def _verified_frozen_receipt(config: ExternalBenchmarkConfig, receipt: Mapping[str, Any]) -> str:
    if not isinstance(receipt, Mapping) or set(receipt) != _FROZEN_RECEIPT_KEYS:
        raise ValueError("frozen preflight receipt schema drifted")
    expected = {
        "schema_version": "g1-full-crysalis-external-benchmark-preflight.1.0.0",
        "status": "PASS",
        "replication_decision": "SUPPORTED",
        "reference_commit": config.reference_commit,
        "formal_attempt_count": config.formal_attempt_count,
        "training_seeds": list(config.training_seeds),
        "condition_manifest_sha256": config.condition_manifest_sha256,
        "frozen_artifact_sha256": dict(config.frozen_artifact_sha256),
        "frozen_core_sha256": dict(config.frozen_core_sha256),
    }
    if any(receipt.get(key) != value for key, value in expected.items()):
        raise ValueError("frozen preflight receipt does not match Task 1 config")
    for field in (
        "replication_artifact_sha256",
        "positive_reference_artifact_sha256",
    ):
        hashes = receipt[field]
        if (
            not isinstance(hashes, Mapping)
            or not hashes
            or any(_SHA256.fullmatch(str(value)) is None for value in hashes.values())
        ):
            raise ValueError(f"frozen preflight receipt {field} is malformed")
    boundary = receipt["source_boundary"]
    if (
        not isinstance(boundary, Mapping)
        or not isinstance(boundary.get("task_owned_paths"), list)
        or boundary.get("full_crysalis_changed_paths") != []
        or boundary.get("external_package_shadows_frozen_core") is not False
    ):
        raise ValueError("frozen preflight receipt source boundary failed")
    return _canonical_digest(receipt)


@dataclass(frozen=True, slots=True)
class AdapterPreflight:
    capability: BaselineCapability
    official_checkout: Path
    checkpoint_path: Path
    official_commit: str
    checkpoint_sha256: str
    condition_manifest_sha256: str
    frozen_preflight_receipt_sha256: str

    def __post_init__(self) -> None:
        if not isinstance(self.capability, BaselineCapability):
            raise ValueError("Task 2 capability record is required")
        if self.official_commit != self.capability.official_commit:
            raise ValueError("verified commit does not match capability")
        if _SHA256.fullmatch(self.checkpoint_sha256) is None:
            raise ValueError("verified checkpoint SHA-256 is required")
        if _SHA256.fullmatch(self.condition_manifest_sha256) is None:
            raise ValueError("condition manifest SHA-256 is required")
        if _SHA256.fullmatch(self.frozen_preflight_receipt_sha256) is None:
            raise ValueError("frozen preflight receipt SHA-256 is required")

    def provenance(self, source_artifact: Path | None = None) -> ModelProvenance:
        return ModelProvenance(
            official_repository=self.capability.official_repository,
            implementation_commit=self.official_commit,
            checkpoint=self.capability.checkpoint or str(self.checkpoint_path),
            checkpoint_sha256=self.checkpoint_sha256,
            source_artifact=(None if source_artifact is None else str(source_artifact.resolve())),
            source_artifact_sha256=(
                None if source_artifact is None else sha256_file(source_artifact)
            ),
        )


def verify_adapter_preflight(
    *,
    config: ExternalBenchmarkConfig,
    frozen_preflight_receipt: Mapping[str, Any],
    capability: BaselineCapability,
    official_checkout: str | Path,
    checkpoint_path: str | Path,
    expected_checkpoint_sha256: str,
    requested_track: PrimaryTrack,
) -> AdapterPreflight:
    try:
        track = PrimaryTrack(requested_track)
    except (TypeError, ValueError):
        raise ValueError("invalid requested benchmark track") from None
    if track is PrimaryTrack.TRACK_A and (
        capability.primary_track is not PrimaryTrack.TRACK_A
        or capability.condition_level is not ConditionLevel.EXACT_FORMULA_PLUS_SG
        or not capability.supports_formula_plus_sg
    ):
        raise ValueError("TRACK_A execution requires EXACT_FORMULA_PLUS_SG capability")
    if capability.primary_track is not track:
        raise ValueError("requested track differs from the Task 2 capability record")
    if capability.execution_status in {
        ExecutionStatus.EXTRA_TEMPLATE_CONDITION_REQUIRED,
        ExecutionStatus.NOT_RUN_NO_OFFICIAL_REPRODUCIBLE_ARTIFACT,
        ExecutionStatus.NOT_RUN_NO_RELEASED_CHECKPOINT,
    }:
        raise ValueError(f"capability is not runnable: {capability.execution_status.value}")
    if not (
        capability.official_repository and capability.official_commit and capability.checkpoint
    ):
        raise ValueError("runnable adapter requires an official commit and checkpoint")
    receipt_digest = _verified_frozen_receipt(config, frozen_preflight_receipt)
    checkout = Path(official_checkout).resolve()
    checkpoint = Path(checkpoint_path).resolve()
    if not checkout.is_dir():
        raise FileNotFoundError(f"official checkout is missing: {checkout}")
    if not checkpoint.is_file():
        raise FileNotFoundError(f"official checkpoint is missing: {checkpoint}")
    expected_digest = str(expected_checkpoint_sha256).lower()
    if _SHA256.fullmatch(expected_digest) is None:
        raise ValueError("expected checkpoint SHA-256 is malformed")
    observed_digest = sha256_file(checkpoint)
    if observed_digest != expected_digest:
        raise ValueError(
            f"checkpoint hash mismatch: expected {expected_digest}, observed {observed_digest}"
        )
    if (
        capability.checkpoint_sha256 != UNKNOWN_DIGEST
        and capability.checkpoint_sha256 != expected_digest
    ):
        raise ValueError("checkpoint hash differs from the Task 2 capability record")
    observed_commit = _git_output(checkout, ("rev-parse", "HEAD"))
    if observed_commit != capability.official_commit:
        raise ValueError(
            "official commit mismatch: "
            f"expected {capability.official_commit}, observed {observed_commit}"
        )
    if _git_output(checkout, ("diff", "--name-only", "HEAD", "--")) or _git_output(
        checkout,
        ("ls-files", "--others", "--exclude-standard"),
    ):
        raise ValueError("official checkout is dirty")
    return AdapterPreflight(
        capability=capability,
        official_checkout=checkout,
        checkpoint_path=checkpoint,
        official_commit=observed_commit,
        checkpoint_sha256=observed_digest,
        condition_manifest_sha256=config.condition_manifest_sha256,
        frozen_preflight_receipt_sha256=receipt_digest,
    )


@dataclass(frozen=True, slots=True)
class CommandSpec:
    executable: str
    arguments: tuple[str, ...]
    cwd: Path
    environment_overrides: Mapping[str, str]
    device: str

    def __post_init__(self) -> None:
        executable = str(Path(self.executable).resolve())
        arguments = tuple(str(argument) for argument in self.arguments)
        if not executable or "\x00" in executable:
            raise ValueError("command executable is invalid")
        if any("\x00" in argument for argument in arguments):
            raise ValueError("command argument contains NUL")
        environment = {str(name): str(value) for name, value in self.environment_overrides.items()}
        if any(not name or "=" in name or "\x00" in name for name in environment):
            raise ValueError("environment override name is invalid")
        if any("\x00" in value for value in environment.values()):
            raise ValueError("environment override value contains NUL")
        if not self.device.strip():
            raise ValueError("device must be non-empty")
        object.__setattr__(self, "executable", executable)
        object.__setattr__(self, "arguments", arguments)
        object.__setattr__(self, "cwd", Path(self.cwd).resolve())
        object.__setattr__(self, "environment_overrides", MappingProxyType(environment))

    @property
    def argv(self) -> tuple[str, ...]:
        return (self.executable, *self.arguments)


def build_command(
    *,
    executable: str | Path,
    arguments: Sequence[str | Path],
    cwd: str | Path,
    environment_overrides: Mapping[str, str],
    device: str,
) -> CommandSpec:
    return CommandSpec(
        executable=str(executable),
        arguments=tuple(str(argument) for argument in arguments),
        cwd=Path(cwd),
        environment_overrides=environment_overrides,
        device=device,
    )


def build_crystalformer_command(
    *,
    python_executable: str | Path,
    driver_path: str | Path,
    condition_manifest_path: str | Path,
    condition_manifest_sha256: str,
    sample_index_start: int,
    sample_count: int,
    official_checkout: str | Path,
    checkpoint_path: str | Path,
    output_jsonl_path: str | Path,
    driver_receipt_path: str | Path,
    cwd: str | Path,
) -> CommandSpec:
    if _SHA256.fullmatch(condition_manifest_sha256) is None:
        raise ValueError("condition manifest SHA-256 is malformed")
    _validate_crystalformer_shard(sample_index_start, sample_count)
    paths = [
        Path(driver_path).resolve(),
        Path(condition_manifest_path).resolve(),
        Path(official_checkout).resolve(),
        Path(checkpoint_path).resolve(),
        Path(output_jsonl_path).resolve(),
        Path(driver_receipt_path).resolve(),
    ]
    driver, conditions, checkout, checkpoint, output, receipt = paths
    return build_command(
        executable=python_executable,
        arguments=(
            driver,
            "--condition-manifest",
            conditions,
            "--condition-manifest-sha256",
            condition_manifest_sha256,
            "--official-checkout",
            checkout,
            "--checkpoint",
            checkpoint,
            "--output-jsonl",
            output,
            "--receipt",
            receipt,
            "--sample-index-start",
            str(sample_index_start),
            "--sample-count",
            str(sample_count),
        ),
        cwd=cwd,
        environment_overrides={"JAX_PLATFORMS": "cpu"},
        device="cpu",
    )


def _process_tree_ram_bytes(process_id: int) -> int:
    try:
        process = psutil.Process(process_id)
        descendants = process.children(recursive=True)
        return sum(item.memory_info().rss for item in (process, *descendants) if item.is_running())
    except (psutil.Error, OSError):
        return 0


@dataclass(frozen=True, slots=True)
class CommandReceipt:
    argv: tuple[str, ...]
    cwd: str
    executable: str
    arguments: tuple[str, ...]
    shell: bool
    environment_overrides: Mapping[str, str]
    runtime_versions: Mapping[str, str]
    official_commit: str
    checkpoint_sha256: str
    started_at: str
    ended_at: str
    exit_code: int
    stdout_path: str
    stdout_sha256: str
    stderr_path: str
    stderr_sha256: str
    device: str
    peak_ram_bytes: int
    peak_vram_bytes: int | None
    launch_count: int
    retry_count: int
    refill_count: int

    def __post_init__(self) -> None:
        object.__setattr__(self, "argv", tuple(self.argv))
        object.__setattr__(self, "arguments", tuple(self.arguments))
        object.__setattr__(
            self,
            "environment_overrides",
            MappingProxyType(dict(self.environment_overrides)),
        )
        object.__setattr__(self, "runtime_versions", MappingProxyType(dict(self.runtime_versions)))
        if self.shell is not False:
            raise ValueError("official subprocess must use shell=False")
        if self.launch_count != 1 or self.retry_count != 0 or self.refill_count != 0:
            raise ValueError("official command must run exactly once without retry/refill")
        if self.peak_ram_bytes < 0:
            raise ValueError("peak RAM cannot be negative")

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": COMMAND_RECEIPT_SCHEMA,
            "argv": list(self.argv),
            "cwd": self.cwd,
            "executable": self.executable,
            "arguments": list(self.arguments),
            "shell": self.shell,
            "environment_overrides": dict(self.environment_overrides),
            "runtime_versions": dict(self.runtime_versions),
            "official_commit": self.official_commit,
            "checkpoint_sha256": self.checkpoint_sha256,
            "started_at": self.started_at,
            "ended_at": self.ended_at,
            "exit_code": self.exit_code,
            "stdout_path": self.stdout_path,
            "stdout_sha256": self.stdout_sha256,
            "stderr_path": self.stderr_path,
            "stderr_sha256": self.stderr_sha256,
            "device": self.device,
            "peak_ram_bytes": self.peak_ram_bytes,
            "peak_vram_bytes": self.peak_vram_bytes,
            "launch_count": self.launch_count,
            "retry_count": self.retry_count,
            "refill_count": self.refill_count,
        }


def execute_official_command(
    command: CommandSpec,
    *,
    preflight: AdapterPreflight,
    stdout_path: str | Path,
    stderr_path: str | Path,
    receipt_path: str | Path,
    runtime_versions: Mapping[str, str],
    peak_vram_bytes: int | None = None,
) -> CommandReceipt:
    stdout = Path(stdout_path).resolve()
    stderr = Path(stderr_path).resolve()
    receipt_target = Path(receipt_path).resolve()
    for target in (stdout, stderr, receipt_target):
        if target.exists():
            raise FileExistsError(f"immutable command artifact already exists: {target}")
        target.parent.mkdir(parents=True, exist_ok=True)
    environment = dict(os.environ)
    environment.update(command.environment_overrides)
    started_at = datetime.now(UTC).isoformat()
    peak_ram_bytes = 0
    with stdout.open("xb") as stdout_handle, stderr.open("xb") as stderr_handle:
        process = subprocess.Popen(
            list(command.argv),
            cwd=command.cwd,
            env=environment,
            stdout=stdout_handle,
            stderr=stderr_handle,
            shell=False,
        )
        while True:
            peak_ram_bytes = max(peak_ram_bytes, _process_tree_ram_bytes(process.pid))
            exit_code = process.poll()
            if exit_code is not None:
                break
            time.sleep(0.01)
    ended_at = datetime.now(UTC).isoformat()
    receipt = CommandReceipt(
        argv=command.argv,
        cwd=str(command.cwd),
        executable=command.executable,
        arguments=command.arguments,
        shell=False,
        environment_overrides=command.environment_overrides,
        runtime_versions=runtime_versions,
        official_commit=preflight.official_commit,
        checkpoint_sha256=preflight.checkpoint_sha256,
        started_at=started_at,
        ended_at=ended_at,
        exit_code=int(exit_code),
        stdout_path=str(stdout),
        stdout_sha256=sha256_file(stdout),
        stderr_path=str(stderr),
        stderr_sha256=sha256_file(stderr),
        device=command.device,
        peak_ram_bytes=peak_ram_bytes,
        peak_vram_bytes=peak_vram_bytes,
        launch_count=1,
        retry_count=0,
        refill_count=0,
    )
    _atomic_write_json_new(receipt_target, receipt.to_dict())
    return receipt


def _unsupported_status(capability: BaselineCapability) -> bool:
    return capability.execution_status in {
        ExecutionStatus.EXTRA_TEMPLATE_CONDITION_REQUIRED,
        ExecutionStatus.NOT_RUN_NO_OFFICIAL_REPRODUCIBLE_ARTIFACT,
        ExecutionStatus.NOT_RUN_NO_RELEASED_CHECKPOINT,
    } or capability.condition_level not in {
        ConditionLevel.EXACT_FORMULA_PLUS_SG,
        ConditionLevel.EXACT_FORMULA_ONLY,
        ConditionLevel.SG_ONLY,
    }


def build_condition_requests(
    capability: BaselineCapability,
    conditions: Sequence[RegisteredCondition],
) -> dict[str, Any]:
    if _unsupported_status(capability):
        raise ValueError(capability.execution_status.value)
    requests: list[dict[str, Any]] = []
    for condition in conditions:
        common = {
            "condition_id": condition.condition_id,
            "sample_index": 0,
            "registered_seed": registered_sample_seed(condition, 0),
        }
        if capability.condition_level is ConditionLevel.EXACT_FORMULA_PLUS_SG:
            request = {
                **common,
                "formula": formula_from_composition(condition.composition),
                "space_group": condition.space_group,
            }
        elif capability.condition_level is ConditionLevel.EXACT_FORMULA_ONLY:
            request = {
                **common,
                "formula": formula_from_composition(condition.composition),
            }
        elif capability.condition_level is ConditionLevel.SG_ONLY:
            request = {**common, "space_group": condition.space_group}
        else:
            raise ValueError(
                f"unsupported official condition contract: {capability.condition_level.value}"
            )
        requests.append(request)
    return {
        "schema_version": "g1-official-condition-request.1.0.0",
        "model": capability.model,
        "condition_level": capability.condition_level.value,
        "samples_per_condition": 1,
        "retry_count": 0,
        "refill_count": 0,
        "requests": requests,
    }


def _capability_provenance(capability: BaselineCapability) -> ModelProvenance:
    checkpoint_digest = capability.checkpoint_sha256
    return ModelProvenance(
        official_repository=capability.official_repository,
        implementation_commit=capability.official_commit or UNAVAILABLE_COMMIT,
        checkpoint=capability.checkpoint or "UNAVAILABLE_OFFICIAL_CHECKPOINT",
        checkpoint_sha256=(
            checkpoint_digest
            if checkpoint_digest not in {None, UNKNOWN_DIGEST}
            else UNAVAILABLE_SHA256
        ),
        source_artifact=None,
        source_artifact_sha256=None,
    )


def emit_unsupported_attempts(
    capability: BaselineCapability,
    conditions: Sequence[RegisteredCondition],
) -> tuple[AttemptRecord, ...]:
    if not _unsupported_status(capability):
        raise ValueError("capability is runnable under its declared Track B protocol")
    provenance = _capability_provenance(capability)
    records = tuple(
        AttemptRecord(
            model=capability.model,
            condition_level=capability.condition_level,
            training_data=capability.training_dataset,
            condition=condition,
            sample_index=0,
            registered_seed=registered_sample_seed(condition, 0),
            status=AttemptStatus.UNSUPPORTED,
            failure_code=capability.execution_status.value,
            failure_message=capability.reason,
            structure=None,
            generation_latency_seconds=None,
            peak_ram_bytes=None,
            peak_vram_bytes=None,
            retry_count=0,
            refill_count=0,
            provenance=provenance,
            training_seed=None,
        )
        for condition in conditions
    )
    return validate_formal_attempts(records, conditions, samples_per_condition=1)


@dataclass(frozen=True, slots=True)
class OutputMappingEntry:
    condition_id: str
    sample_index: int
    registered_seed: int
    output_path: str
    output_sha256: str
    output_format: OutputFormat
    output_index: int
    structure_field: str | None

    def __post_init__(self) -> None:
        try:
            output_format = OutputFormat(self.output_format)
        except (TypeError, ValueError):
            raise ValueError("unsupported mapped output format") from None
        if type(self.sample_index) is not int or self.sample_index < 0:
            raise ValueError("mapped sample index is invalid")
        if type(self.registered_seed) is not int or self.registered_seed < 0:
            raise ValueError("mapped registered seed is invalid")
        if type(self.output_index) is not int or self.output_index < 0:
            raise ValueError("mapped output index is invalid")
        if _SHA256.fullmatch(self.output_sha256) is None:
            raise ValueError("mapped output SHA-256 is invalid")
        if output_format in {OutputFormat.CSV_JSON, OutputFormat.CSV_CIF}:
            if not isinstance(self.structure_field, str) or not self.structure_field:
                raise ValueError("CSV mapping requires an explicit structure field")
        elif self.structure_field is not None:
            raise ValueError("non-CSV mapping cannot declare a structure field")
        object.__setattr__(self, "output_format", output_format)
        object.__setattr__(self, "output_path", str(Path(self.output_path).resolve()))

    @classmethod
    def for_file(
        cls,
        condition: RegisteredCondition,
        output_path: str | Path,
        *,
        output_format: OutputFormat | str,
        output_index: int,
        structure_field: str | None = None,
        sample_index: int = 0,
    ) -> OutputMappingEntry:
        path = Path(output_path).resolve()
        return cls(
            condition_id=condition.condition_id,
            sample_index=sample_index,
            registered_seed=registered_sample_seed(condition, sample_index),
            output_path=str(path),
            output_sha256=sha256_file(path),
            output_format=OutputFormat(output_format),
            output_index=output_index,
            structure_field=structure_field,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "condition_id": self.condition_id,
            "sample_index": self.sample_index,
            "registered_seed": self.registered_seed,
            "output_path": self.output_path,
            "output_sha256": self.output_sha256,
            "output_format": self.output_format.value,
            "output_index": self.output_index,
            "structure_field": self.structure_field,
        }


def _expected_condition_samples(
    conditions: Sequence[RegisteredCondition], samples_per_condition: int
) -> list[tuple[RegisteredCondition, int]]:
    if type(samples_per_condition) is not int or samples_per_condition < 1:
        raise ValueError("samples_per_condition must be a positive integer")
    return [
        (condition, sample_index)
        for condition in conditions
        for sample_index in range(samples_per_condition)
    ]


def write_output_mapping_receipt(
    path: str | Path,
    *,
    preflight: AdapterPreflight,
    conditions: Sequence[RegisteredCondition],
    entries: Iterable[OutputMappingEntry],
    samples_per_condition: int,
) -> dict[str, Any]:
    frozen_entries = tuple(entries)
    expected = _expected_condition_samples(conditions, samples_per_condition)
    if len(frozen_entries) != len(expected):
        raise ValueError("output mapping denominator is incomplete")
    locators: set[tuple[str, int, str | None]] = set()
    for entry, (condition, sample_index) in zip(frozen_entries, expected, strict=True):
        if not isinstance(entry, OutputMappingEntry):
            raise ValueError("output mapping entry is malformed")
        if (
            entry.condition_id != condition.condition_id
            or entry.sample_index != sample_index
            or entry.registered_seed != registered_sample_seed(condition, sample_index)
        ):
            raise ValueError("condition-to-output mapping drifted")
        locator = (entry.output_path, entry.output_index, entry.structure_field)
        if locator in locators:
            raise ValueError("duplicate mapped output")
        locators.add(locator)
    payload = {
        "schema_version": MAPPING_RECEIPT_SCHEMA,
        "model": preflight.capability.model,
        "condition_level": preflight.capability.condition_level.value,
        "training_data": preflight.capability.training_dataset,
        "official_commit": preflight.official_commit,
        "checkpoint_sha256": preflight.checkpoint_sha256,
        "samples_per_condition": samples_per_condition,
        "retry_count": 0,
        "refill_count": 0,
        "entries": [entry.to_dict() for entry in frozen_entries],
    }
    _atomic_write_json_new(Path(path).resolve(), payload)
    return payload


def _failure_cohort(
    *,
    preflight: AdapterPreflight,
    conditions: Sequence[RegisteredCondition],
    samples_per_condition: int,
    code: str,
    message: str,
    source_artifact: Path | None = None,
    command_receipt: CommandReceipt | None = None,
) -> tuple[AttemptRecord, ...]:
    provenance = preflight.provenance(source_artifact)
    peak_ram = None if command_receipt is None else command_receipt.peak_ram_bytes
    peak_vram = None if command_receipt is None else command_receipt.peak_vram_bytes
    records = tuple(
        AttemptRecord(
            model=preflight.capability.model,
            condition_level=preflight.capability.condition_level,
            training_data=preflight.capability.training_dataset,
            condition=condition,
            sample_index=sample_index,
            registered_seed=registered_sample_seed(condition, sample_index),
            status=AttemptStatus.FAILED,
            failure_code=code,
            failure_message=message,
            structure=None,
            generation_latency_seconds=None,
            peak_ram_bytes=peak_ram,
            peak_vram_bytes=peak_vram,
            retry_count=0,
            refill_count=0,
            provenance=provenance,
            training_seed=None,
        )
        for condition, sample_index in _expected_condition_samples(
            conditions, samples_per_condition
        )
    )
    return validate_formal_attempts(
        records, conditions, samples_per_condition=samples_per_condition
    )


def _read_mapped_structure(entry: Mapping[str, Any]) -> StructurePayload:
    path = Path(str(entry["output_path"]))
    output_format = OutputFormat(entry["output_format"])
    index = entry["output_index"]
    if output_format is OutputFormat.CIF:
        if index != 0:
            raise ValueError("single CIF mapping must use output index zero")
        return StructurePayload.from_pymatgen(Structure.from_file(path))
    if output_format is OutputFormat.JSON:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(payload, list):
            raise ValueError("mapped JSON output must be a list")
        return StructurePayload.from_dict(payload[index])
    with path.open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    row = rows[index]
    field = entry["structure_field"]
    if not isinstance(field, str) or field not in row:
        raise ValueError("mapped CSV structure field is missing")
    if output_format is OutputFormat.CSV_JSON:
        return StructurePayload.from_dict(json.loads(row[field]))
    if output_format is OutputFormat.CSV_CIF:
        return StructurePayload.from_pymatgen(Structure.from_str(row[field], fmt="cif"))
    raise ValueError("unsupported mapped output format")


def import_mapped_outputs(
    *,
    preflight: AdapterPreflight,
    conditions: Sequence[RegisteredCondition],
    mapping_receipt_path: str | Path,
    command_receipt: CommandReceipt | None = None,
) -> tuple[AttemptRecord, ...]:
    mapping_path = Path(mapping_receipt_path).resolve()
    if command_receipt is not None:
        if (
            command_receipt.official_commit != preflight.official_commit
            or command_receipt.checkpoint_sha256 != preflight.checkpoint_sha256
        ):
            return _failure_cohort(
                preflight=preflight,
                conditions=conditions,
                samples_per_condition=1,
                code="COMMAND_RECEIPT_DRIFT",
                message="command receipt does not match verified preflight",
                command_receipt=command_receipt,
            )
        if command_receipt.exit_code != 0:
            return _failure_cohort(
                preflight=preflight,
                conditions=conditions,
                samples_per_condition=1,
                code="PROCESS_EXIT_NONZERO",
                message=f"official process exited with code {command_receipt.exit_code}",
                command_receipt=command_receipt,
            )
    if not mapping_path.is_file():
        return _failure_cohort(
            preflight=preflight,
            conditions=conditions,
            samples_per_condition=1,
            code="OUTPUT_MAPPING_MISSING",
            message=f"output mapping receipt is missing: {mapping_path}",
            command_receipt=command_receipt,
        )
    try:
        mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
        if not isinstance(mapping, Mapping) or set(mapping) != _MAPPING_KEYS:
            raise ValueError("mapping receipt keys drifted")
        samples_per_condition = mapping["samples_per_condition"]
        expected_header = {
            "schema_version": MAPPING_RECEIPT_SCHEMA,
            "model": preflight.capability.model,
            "condition_level": preflight.capability.condition_level.value,
            "training_data": preflight.capability.training_dataset,
            "official_commit": preflight.official_commit,
            "checkpoint_sha256": preflight.checkpoint_sha256,
            "retry_count": 0,
            "refill_count": 0,
        }
        if any(mapping.get(key) != value for key, value in expected_header.items()):
            raise ValueError("mapping receipt header drifted")
        entries = mapping["entries"]
        expected = _expected_condition_samples(conditions, samples_per_condition)
        if not isinstance(entries, list) or len(entries) != len(expected):
            raise ValueError("mapping denominator drifted")
    except Exception as error:
        return _failure_cohort(
            preflight=preflight,
            conditions=conditions,
            samples_per_condition=1,
            code="OUTPUT_MAPPING_MALFORMED",
            message=f"{type(error).__name__}: {error}",
            source_artifact=mapping_path,
            command_receipt=command_receipt,
        )
    for entry, (condition, sample_index) in zip(entries, expected, strict=True):
        if (
            not isinstance(entry, Mapping)
            or set(entry) != _MAPPING_ENTRY_KEYS
            or (
                entry.get("condition_id") != condition.condition_id
                or entry.get("sample_index") != sample_index
                or entry.get("registered_seed") != registered_sample_seed(condition, sample_index)
            )
        ):
            return _failure_cohort(
                preflight=preflight,
                conditions=conditions,
                samples_per_condition=samples_per_condition,
                code="CONDITION_MAPPING_DRIFT",
                message="condition-to-output mapping order or identity drifted",
                source_artifact=mapping_path,
                command_receipt=command_receipt,
            )
    locators = [
        (
            str(Path(str(entry.get("output_path"))).resolve()),
            entry.get("output_index"),
            entry.get("structure_field"),
        )
        for entry in entries
    ]
    if len(locators) != len(set(locators)):
        return _failure_cohort(
            preflight=preflight,
            conditions=conditions,
            samples_per_condition=samples_per_condition,
            code="DUPLICATE_OUTPUT_MAPPING",
            message="two registered attempts map to the same output sample",
            source_artifact=mapping_path,
            command_receipt=command_receipt,
        )
    provenance = preflight.provenance(mapping_path)
    peak_ram = None if command_receipt is None else command_receipt.peak_ram_bytes
    peak_vram = None if command_receipt is None else command_receipt.peak_vram_bytes
    records: list[AttemptRecord] = []
    for entry, (condition, sample_index) in zip(entries, expected, strict=True):
        output_path = Path(str(entry["output_path"]))
        status = AttemptStatus.FAILED
        failure_code: str | None = None
        failure_message: str | None = None
        structure: StructurePayload | None = None
        if not output_path.is_file():
            failure_code = "OUTPUT_MISSING"
            failure_message = f"mapped output is missing: {output_path}"
        elif sha256_file(output_path) != entry.get("output_sha256"):
            failure_code = "OUTPUT_HASH_MISMATCH"
            failure_message = f"mapped output hash drifted: {output_path}"
        else:
            try:
                structure = _read_mapped_structure(entry)
            except Exception as error:
                failure_code = "STRUCTURE_PARSE_FAILED"
                failure_message = f"{type(error).__name__}: {error}"
            else:
                status = AttemptStatus.GENERATED
        records.append(
            AttemptRecord(
                model=preflight.capability.model,
                condition_level=preflight.capability.condition_level,
                training_data=preflight.capability.training_dataset,
                condition=condition,
                sample_index=sample_index,
                registered_seed=registered_sample_seed(condition, sample_index),
                status=status,
                failure_code=failure_code,
                failure_message=failure_message,
                structure=structure,
                generation_latency_seconds=None,
                peak_ram_bytes=peak_ram,
                peak_vram_bytes=peak_vram,
                retry_count=0,
                refill_count=0,
                provenance=provenance,
                training_seed=None,
            )
        )
    return validate_formal_attempts(
        records, conditions, samples_per_condition=samples_per_condition
    )


def _crystalformer_shard_pairs(
    conditions: Sequence[RegisteredCondition],
    sample_index_start: int,
    sample_count: int,
) -> tuple[tuple[RegisteredCondition, int], ...]:
    _validate_crystalformer_shard(sample_index_start, sample_count)
    return tuple(
        (condition, sample_index)
        for condition in conditions
        for sample_index in range(sample_index_start, sample_index_start + sample_count)
    )


def _validate_crystalformer_shard_attempts(
    records: Iterable[AttemptRecord],
    conditions: Sequence[RegisteredCondition],
    *,
    sample_index_start: int,
    sample_count: int,
) -> tuple[AttemptRecord, ...]:
    frozen = tuple(records)
    expected = _crystalformer_shard_pairs(conditions, sample_index_start, sample_count)
    if len(frozen) != len(expected):
        raise ValueError(
            f"CrystalFormer shard denominator incomplete: expected {len(expected)}, "
            f"observed {len(frozen)}"
        )
    identities = [
        (record.model, record.training_seed, record.condition.condition_id, record.sample_index)
        for record in frozen
    ]
    if len(set(identities)) != len(identities):
        raise ValueError("duplicate CrystalFormer condition/sample identity")
    for record, (condition, sample_index) in zip(frozen, expected, strict=True):
        if record.condition.to_dict() != condition.to_dict():
            raise ValueError("CrystalFormer shard contains reordered or foreign condition")
        if record.sample_index != sample_index:
            raise ValueError("CrystalFormer shard sample order drifted")
        if record.registered_seed != registered_sample_seed(condition, sample_index):
            raise ValueError("CrystalFormer shard registered seed drifted")
    if frozen:
        cohort = {
            (
                record.model,
                record.training_seed,
                record.condition_level,
                record.training_data,
                record.provenance,
            )
            for record in frozen
        }
        if len(cohort) != 1:
            raise ValueError("CrystalFormer shard cohort provenance drifted")
    return frozen


def _crystalformer_failure_shard(
    *,
    preflight: AdapterPreflight,
    conditions: Sequence[RegisteredCondition],
    sample_index_start: int,
    sample_count: int,
    code: str,
    message: str,
    source_artifact: Path,
) -> tuple[AttemptRecord, ...]:
    provenance = preflight.provenance(source_artifact)
    records = tuple(
        AttemptRecord(
            model=preflight.capability.model,
            condition_level=preflight.capability.condition_level,
            training_data=preflight.capability.training_dataset,
            condition=condition,
            sample_index=sample_index,
            registered_seed=registered_sample_seed(condition, sample_index),
            status=AttemptStatus.FAILED,
            failure_code=code,
            failure_message=message,
            structure=None,
            generation_latency_seconds=None,
            peak_ram_bytes=None,
            peak_vram_bytes=None,
            retry_count=0,
            refill_count=0,
            provenance=provenance,
            training_seed=None,
        )
        for condition, sample_index in _crystalformer_shard_pairs(
            conditions, sample_index_start, sample_count
        )
    )
    return _validate_crystalformer_shard_attempts(
        records,
        conditions,
        sample_index_start=sample_index_start,
        sample_count=sample_count,
    )


def import_crystalformer_driver_output(
    *,
    preflight: AdapterPreflight,
    conditions: Sequence[RegisteredCondition],
    output_jsonl_path: str | Path,
    driver_receipt_path: str | Path,
    sample_index_start: int,
    sample_count: int,
) -> tuple[AttemptRecord, ...]:
    sample_index_start, sample_count = _validate_crystalformer_shard(
        sample_index_start, sample_count
    )
    expected = _crystalformer_shard_pairs(conditions, sample_index_start, sample_count)
    expected_attempt_count = len(expected)
    output = Path(output_jsonl_path).resolve()
    receipt_path = Path(driver_receipt_path).resolve()
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    if (
        not isinstance(receipt, Mapping)
        or set(receipt) != _CRYSTALFORMER_RECEIPT_KEYS
        or any(
            (
                receipt.get("schema_version") != CRYSTALFORMER_RECEIPT_SCHEMA,
                receipt.get("status") != "COMPLETE",
                receipt.get("model") != "CrystalFormer",
                Path(str(receipt.get("official_checkout"))).resolve()
                != preflight.official_checkout,
                receipt.get("official_commit") != preflight.official_commit,
                Path(str(receipt.get("checkpoint_path"))).resolve() != preflight.checkpoint_path,
                receipt.get("checkpoint_sha256") != preflight.checkpoint_sha256,
                receipt.get("condition_manifest_sha256") != preflight.condition_manifest_sha256,
                receipt.get("expected_condition_count") != len(conditions),
                receipt.get("sample_index_start") != sample_index_start,
                receipt.get("sample_count") != sample_count,
                receipt.get("attempt_count") != expected_attempt_count,
                receipt.get("generated_count", -1) + receipt.get("failed_count", -1)
                != expected_attempt_count,
                receipt.get("denominator_complete") is not True,
                receipt.get("retry_count") != 0,
                receipt.get("refill_count") != 0,
                receipt.get("checkpoint_load_count") != 1,
                receipt.get("samples_per_condition") != sample_count,
                Path(str(receipt.get("output_jsonl_path"))).resolve() != output,
                receipt.get("output_jsonl_sha256") != sha256_file(output),
                receipt.get("abort_code") is not None,
            )
        )
    ):
        raise ValueError("CrystalFormer driver receipt drifted")
    rows = [
        json.loads(line) for line in output.read_text(encoding="utf-8").splitlines() if line.strip()
    ]
    if len(rows) != expected_attempt_count:
        return _crystalformer_failure_shard(
            preflight=preflight,
            conditions=conditions,
            sample_index_start=sample_index_start,
            sample_count=sample_count,
            code="CONDITION_MAPPING_DRIFT",
            message="CrystalFormer JSONL denominator drifted",
            source_artifact=output,
        )
    provenance = preflight.provenance(output)
    records: list[AttemptRecord] = []
    for row, (condition, sample_index) in zip(rows, expected, strict=True):
        if (
            not isinstance(row, Mapping)
            or set(row) != _CRYSTALFORMER_ROW_KEYS
            or any(
                (
                    row.get("schema_version") != CRYSTALFORMER_ROW_SCHEMA,
                    row.get("condition_id") != condition.condition_id,
                    row.get("attempt_index") != condition.attempt_index,
                    row.get("sample_index") != sample_index,
                    row.get("registered_seed") != registered_sample_seed(condition, sample_index),
                    row.get("formula") != formula_from_composition(condition.composition),
                    row.get("target_space_group") != condition.space_group,
                    row.get("retry_count") != 0,
                    row.get("refill_count") != 0,
                )
            )
        ):
            return _crystalformer_failure_shard(
                preflight=preflight,
                conditions=conditions,
                sample_index_start=sample_index_start,
                sample_count=sample_count,
                code="CONDITION_MAPPING_DRIFT",
                message="CrystalFormer row mapping drifted",
                source_artifact=output,
            )
        structure: StructurePayload | None = None
        failure_code: str | None = None
        failure_message: str | None = None
        status = AttemptStatus.FAILED
        if row.get("status") == "GENERATED":
            try:
                raw = row["raw"]
                if not isinstance(raw, Mapping) or raw.get("G") != condition.space_group:
                    raise ValueError("raw generated SG differs from requested SG")
                structure = StructurePayload.from_dict(row["structure"])
            except Exception as error:
                failure_code = "STRUCTURE_PARSE_FAILED"
                failure_message = f"{type(error).__name__}: {error}"
            else:
                status = AttemptStatus.GENERATED
        else:
            failure_code = str(row.get("failure_code") or "GENERATION_FAILED")
            failure_message = str(row.get("failure_message") or failure_code)
        records.append(
            AttemptRecord(
                model=preflight.capability.model,
                condition_level=preflight.capability.condition_level,
                training_data=preflight.capability.training_dataset,
                condition=condition,
                sample_index=sample_index,
                registered_seed=registered_sample_seed(condition, sample_index),
                status=status,
                failure_code=failure_code,
                failure_message=failure_message,
                structure=structure,
                generation_latency_seconds=row.get("generation_latency_seconds"),
                peak_ram_bytes=None,
                peak_vram_bytes=None,
                retry_count=0,
                refill_count=0,
                provenance=provenance,
                training_seed=None,
            )
        )
    return _validate_crystalformer_shard_attempts(
        records,
        conditions,
        sample_index_start=sample_index_start,
        sample_count=sample_count,
    )


def _import_bound_crystalformer_shard(
    *,
    preflight: AdapterPreflight,
    conditions: Sequence[RegisteredCondition],
    label: str,
    driver_receipt_path: str | Path,
    driver_receipt_sha256: str,
    sample_index_start: int,
    sample_count: int,
) -> tuple[AttemptRecord, ...]:
    receipt_path = Path(driver_receipt_path).resolve()
    expected_digest = str(driver_receipt_sha256).lower()
    if _SHA256.fullmatch(expected_digest) is None:
        raise ValueError(f"{label} shard driver receipt SHA-256 is malformed")
    if not receipt_path.is_file() or sha256_file(receipt_path) != expected_digest:
        raise ValueError(f"{label} shard driver receipt hash mismatch")
    try:
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
        output_path = Path(str(receipt["output_jsonl_path"])).resolve()
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
        raise ValueError(f"{label} shard driver receipt is malformed") from error
    try:
        return import_crystalformer_driver_output(
            preflight=preflight,
            conditions=conditions,
            output_jsonl_path=output_path,
            driver_receipt_path=receipt_path,
            sample_index_start=sample_index_start,
            sample_count=sample_count,
        )
    except ValueError as error:
        raise ValueError(f"{label} shard {error}") from error


def combine_crystalformer_k5_attempts(
    *,
    preflight: AdapterPreflight,
    conditions: Sequence[RegisteredCondition],
    primary_driver_receipt_path: str | Path,
    primary_driver_receipt_sha256: str,
    secondary_driver_receipt_path: str | Path,
    secondary_driver_receipt_sha256: str,
) -> tuple[AttemptRecord, ...]:
    primary = _import_bound_crystalformer_shard(
        preflight=preflight,
        conditions=conditions,
        label="primary",
        driver_receipt_path=primary_driver_receipt_path,
        driver_receipt_sha256=primary_driver_receipt_sha256,
        sample_index_start=0,
        sample_count=1,
    )
    secondary = _import_bound_crystalformer_shard(
        preflight=preflight,
        conditions=conditions,
        label="secondary",
        driver_receipt_path=secondary_driver_receipt_path,
        driver_receipt_sha256=secondary_driver_receipt_sha256,
        sample_index_start=1,
        sample_count=4,
    )
    primary_record = primary[0]
    secondary_record = secondary[0]
    if (
        primary_record.model,
        primary_record.training_seed,
        primary_record.condition_level,
        primary_record.training_data,
    ) != (
        secondary_record.model,
        secondary_record.training_seed,
        secondary_record.condition_level,
        secondary_record.training_data,
    ):
        raise ValueError("CrystalFormer K=5 shard cohort labels drifted")
    primary_provenance = primary_record.provenance
    secondary_provenance = secondary_record.provenance
    if (
        primary_provenance.official_repository,
        primary_provenance.implementation_commit,
        primary_provenance.checkpoint,
        primary_provenance.checkpoint_sha256,
    ) != (
        secondary_provenance.official_repository,
        secondary_provenance.implementation_commit,
        secondary_provenance.checkpoint,
        secondary_provenance.checkpoint_sha256,
    ):
        raise ValueError("CrystalFormer K=5 shard model provenance drifted")

    combined: list[AttemptRecord] = []
    for condition_index in range(len(conditions)):
        combined.append(primary[condition_index])
        start = condition_index * 4
        combined.extend(secondary[start : start + 4])
    frozen = tuple(combined)
    expected = [(condition, sample_index) for condition in conditions for sample_index in range(5)]
    if len(frozen) != len(expected):
        raise ValueError("CrystalFormer K=5 combined denominator drifted")
    for record, (condition, sample_index) in zip(frozen, expected, strict=True):
        if (
            record.condition.to_dict() != condition.to_dict()
            or record.sample_index != sample_index
            or record.registered_seed != registered_sample_seed(condition, sample_index)
        ):
            raise ValueError("CrystalFormer K=5 combined condition/sample mapping drifted")
    return frozen
