from __future__ import annotations

import math
from collections import Counter
from statistics import fmean, stdev
from typing import Any, Mapping, Sequence

import numpy as np

from crysalis_g1.external_benchmark.capabilities import (
    BaselineCapability,
    ConditionLevel,
    PrimaryTrack,
)
from crysalis_g1.external_benchmark.evaluation import (
    SPACE_GROUP_CONDITION_LEVELS,
    attempt_evaluation_id,
)
from crysalis_g1.external_benchmark.records import (
    CRYSALIS_TRAINING_SEEDS,
    AttemptRecord,
    AttemptStatus,
)


MODEL_SUMMARY_SCHEMA = "g1-external-benchmark-model-summary.1.0.0"


def _rate(
    numerator: int | None,
    denominator: int,
    *,
    unavailable_reason: str | None = None,
) -> dict[str, Any]:
    if unavailable_reason is not None:
        return {
            "numerator": None,
            "denominator": denominator,
            "rate": None,
            "unavailable_reason": unavailable_reason,
        }
    if numerator is None:
        raise ValueError("available metric requires a numerator")
    return {
        "numerator": int(numerator),
        "denominator": int(denominator),
        "rate": numerator / denominator if denominator else None,
        "unavailable_reason": None if denominator else "EMPTY_DENOMINATOR",
    }


def _numeric_summary(values: Sequence[float]) -> dict[str, Any]:
    array = np.asarray(tuple(float(value) for value in values), dtype=float)
    if array.size == 0:
        return {
            "sample_count": 0,
            "mean": None,
            "median": None,
            "p90": None,
            "p95": None,
            "max": None,
        }
    if not np.isfinite(array).all():
        raise FloatingPointError("nonfinite summary value")
    return {
        "sample_count": int(array.size),
        "mean": float(array.mean()),
        "median": float(np.median(array)),
        "p90": float(np.quantile(array, 0.90)),
        "p95": float(np.quantile(array, 0.95)),
        "max": float(array.max()),
    }


def _resource_summary(values: Sequence[int | float | None], *, total: int) -> dict[str, Any]:
    present = [float(value) for value in values if value is not None]
    summary = _numeric_summary(present)
    summary["missing_count"] = total - len(present)
    return summary


def _aligned_records(
    attempts: Sequence[AttemptRecord],
    common_records: Sequence[Mapping[str, Any]],
    fixed_records: Sequence[Mapping[str, Any]],
    cell_records: Sequence[Mapping[str, Any]],
) -> tuple[
    tuple[AttemptRecord, ...],
    tuple[Mapping[str, Any], ...],
    tuple[Mapping[str, Any], ...],
    tuple[Mapping[str, Any], ...],
]:
    attempts = tuple(attempts)
    common = tuple(common_records)
    fixed = tuple(fixed_records)
    cell = tuple(cell_records)
    if not attempts:
        raise ValueError("model summary requires attempts")
    if not (len(attempts) == len(common) == len(fixed) == len(cell)):
        raise ValueError("common and CHGNet evaluation denominators differ")
    expected = [attempt_evaluation_id(attempt) for attempt in attempts]
    observed_common = [str(record.get("evaluation_id")) for record in common]
    observed_fixed = [str(record.get("condition_id")) for record in fixed]
    observed_cell = [str(record.get("condition_id")) for record in cell]
    if observed_common != expected or observed_fixed != expected or observed_cell != expected:
        raise ValueError("attempt/common/CHGNet evaluation identities differ")
    return attempts, common, fixed, cell


def _protocol_summary(
    records: Sequence[Mapping[str, Any]],
    *,
    sg_conditioned: bool,
) -> dict[str, Any]:
    count = len(records)
    evaluated = sum(record.get("status") == "EVALUATED" for record in records)
    converged = sum(record.get("converged") is True for record in records)
    physical = sum(record.get("post_relax_survival") is True for record in records)
    strict = sum(record.get("strict_symmetry_preserving_survival") is True for record in records)
    strict_metric = (
        _rate(strict, count)
        if sg_conditioned
        else _rate(
            None,
            count,
            unavailable_reason="NOT_TARGET_SPACE_GROUP_CONDITIONED",
        )
    )
    return {
        "attempt_count": count,
        "all_attempt_denominator": True,
        "evaluated": _rate(evaluated, count),
        "convergence": _rate(converged, count),
        "physical_survival": _rate(physical, count),
        "strict_symmetry_survival": strict_metric,
        "failure_taxonomy": dict(
            sorted(Counter(str(record.get("status")) for record in records).items())
        ),
    }


def _per_space_group(
    attempts: Sequence[AttemptRecord],
    common: Sequence[Mapping[str, Any]],
    fixed: Sequence[Mapping[str, Any]],
    cell: Sequence[Mapping[str, Any]],
    *,
    condition_level: ConditionLevel,
    training_data: str,
) -> dict[str, Any]:
    sg_conditioned = condition_level in SPACE_GROUP_CONDITION_LEVELS
    grouped: dict[int, list[int]] = {}
    for index, attempt in enumerate(attempts):
        grouped.setdefault(attempt.condition.space_group, []).append(index)
    rows: dict[str, Any] = {}
    for space_group in sorted(grouped):
        indices = grouped[space_group]
        denominator = len(indices)
        force_values = [
            float(fixed[index]["pre_max_force_ev_per_angstrom"])
            for index in indices
            if fixed[index].get("status") == "EVALUATED"
            and fixed[index].get("pre_max_force_ev_per_angstrom") is not None
        ]
        rows[str(space_group)] = {
            "space_group": space_group,
            "condition_level": condition_level.value,
            "training_data": training_data,
            "conditioned_performance": sg_conditioned,
            "attempts": _rate(denominator, denominator),
            "common_legal": _rate(
                sum(common[index].get("common_legal_crystal") is True for index in indices),
                denominator,
            ),
            "short_contact_free": _rate(
                sum(common[index].get("short_contact_free") is True for index in indices),
                denominator,
            ),
            "fixed_cell_strict_symmetry_survival": _rate(
                sum(
                    fixed[index].get("strict_symmetry_preserving_survival") is True
                    for index in indices
                ),
                denominator,
            ),
            "cell_relax_strict_symmetry_survival": _rate(
                sum(
                    cell[index].get("strict_symmetry_preserving_survival") is True
                    for index in indices
                ),
                denominator,
            ),
            "initial_max_force_ev_per_angstrom": _numeric_summary(force_values),
        }
    return {
        "grouping_interpretation": (
            "TARGET_SG_CONDITIONED_PERFORMANCE"
            if sg_conditioned
            else "MANIFEST_STRATIFIED_POST_HOC_NOT_SG_CONDITIONED"
        ),
        "manifest_target_space_group_used_for_stratification": True,
        "rows": rows,
    }


def summarize_model_cohort(
    attempts: Sequence[AttemptRecord],
    common_records: Sequence[Mapping[str, Any]],
    fixed_records: Sequence[Mapping[str, Any]],
    cell_records: Sequence[Mapping[str, Any]],
    *,
    capability: BaselineCapability | None = None,
    wall_time_seconds: float | None = None,
) -> dict[str, Any]:
    attempts, common, fixed, cell = _aligned_records(
        attempts, common_records, fixed_records, cell_records
    )
    cohort_identity = {
        (attempt.model, attempt.condition_level, attempt.training_data) for attempt in attempts
    }
    if len(cohort_identity) != 1:
        raise ValueError("model cohort labels drifted")
    model, condition_level, training_data = next(iter(cohort_identity))
    training_seeds = {attempt.training_seed for attempt in attempts}
    if len(training_seeds) == 1:
        training_seed = next(iter(training_seeds))
        pooled_training_seeds: list[int] | None = None
    elif model == "FULL_CRYSALIS" and training_seeds == set(CRYSALIS_TRAINING_SEEDS):
        training_seed = None
        pooled_training_seeds = list(CRYSALIS_TRAINING_SEEDS)
    else:
        raise ValueError("model cohort training seed drifted")
    if capability is not None and (
        capability.model != model
        or capability.condition_level is not condition_level
        or capability.training_dataset != training_data
    ):
        raise ValueError("attempt cohort does not match its capability record")
    if wall_time_seconds is not None and (
        not math.isfinite(float(wall_time_seconds)) or wall_time_seconds < 0
    ):
        raise ValueError("wall time must be finite and nonnegative")

    count = len(attempts)
    formula_conditioned = condition_level in {
        ConditionLevel.EXACT_FORMULA_PLUS_SG,
        ConditionLevel.EXACT_FORMULA_ONLY,
    }
    sg_conditioned = condition_level in SPACE_GROUP_CONDITION_LEVELS
    initial_forces = [
        float(record["pre_max_force_ev_per_angstrom"])
        for record in fixed
        if record.get("status") == "EVALUATED"
        and record.get("pre_max_force_ev_per_angstrom") is not None
    ]
    composition = {
        "reduced_formula_match": (
            _rate(
                sum(record.get("reduced_formula_match") is True for record in common),
                count,
            )
            if formula_conditioned
            else _rate(
                None,
                count,
                unavailable_reason="NOT_EXACT_FORMULA_CONDITIONED",
            )
        ),
        "exact_cell_count_match": (
            _rate(
                sum(record.get("exact_cell_count_match") is True for record in common),
                count,
            )
            if formula_conditioned
            else _rate(
                None,
                count,
                unavailable_reason="NOT_EXACT_FORMULA_CONDITIONED",
            )
        ),
    }
    target_space_group = {
        "strict_0_03_match": (
            _rate(
                sum(record.get("strict_0_03_space_group_match") is True for record in common),
                count,
            )
            if sg_conditioned
            else _rate(
                None,
                count,
                unavailable_reason="NOT_TARGET_SPACE_GROUP_CONDITIONED",
            )
        ),
        "strict_symprec_angstrom": 0.03,
    }
    summary = {
        "schema_version": MODEL_SUMMARY_SCHEMA,
        "model": model,
        "condition_level": condition_level.value,
        "training_data": training_data,
        "training_seed": training_seed,
        "pooled_training_seeds": pooled_training_seeds,
        "primary_track": (
            capability.primary_track.value if capability is not None else "FROZEN_SUBJECT"
        ),
        "table_a_eligible": bool(
            capability is not None
            and capability.primary_track is PrimaryTrack.TRACK_A
            and capability.condition_level is ConditionLevel.EXACT_FORMULA_PLUS_SG
        ),
        "common_evaluation_available": True,
        "attempt_count": count,
        "attempts": _rate(count, count),
        "generated": _rate(
            sum(attempt.status is AttemptStatus.GENERATED for attempt in attempts),
            count,
        ),
        "parse_valid": _rate(sum(record.get("parse_valid") is True for record in common), count),
        "common_legal": _rate(
            sum(record.get("common_legal_crystal") is True for record in common),
            count,
        ),
        "short_contact_free": _rate(
            sum(record.get("short_contact_free") is True for record in common),
            count,
        ),
        "composition": composition,
        "target_space_group": target_space_group,
        "initial_max_force_ev_per_angstrom": _numeric_summary(initial_forces),
        "fixed_cell_fire300": _protocol_summary(fixed, sg_conditioned=sg_conditioned),
        "cell_relax_fire300": _protocol_summary(cell, sg_conditioned=sg_conditioned),
        "per_space_group": _per_space_group(
            attempts,
            common,
            fixed,
            cell,
            condition_level=condition_level,
            training_data=training_data,
        ),
        "runtime": {
            "generation_latency_seconds": _resource_summary(
                [attempt.generation_latency_seconds for attempt in attempts],
                total=count,
            ),
            "wall_time_seconds": (None if wall_time_seconds is None else float(wall_time_seconds)),
            "wall_time_unavailable_reason": ("NOT_RECORDED" if wall_time_seconds is None else None),
            "peak_ram_bytes": _resource_summary(
                [attempt.peak_ram_bytes for attempt in attempts], total=count
            ),
            "peak_vram_bytes": _resource_summary(
                [attempt.peak_vram_bytes for attempt in attempts], total=count
            ),
        },
        "published_metrics_in_common_ranking": False,
        "all_attempt_denominators": True,
    }
    return summary


def build_table_a_rows(
    entries: Sequence[tuple[BaselineCapability, Mapping[str, Any]]],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for capability, summary in entries:
        if summary.get("model") != capability.model:
            raise ValueError("Table A capability/summary model mismatch")
        expected_labels = {
            "condition_level": capability.condition_level.value,
            "training_data": capability.training_dataset,
            "primary_track": capability.primary_track.value,
        }
        if any(summary.get(name) != value for name, value in expected_labels.items()):
            raise ValueError("Table A capability/summary labels mismatch")
        eligible = bool(
            capability.primary_track is PrimaryTrack.TRACK_A
            and capability.condition_level is ConditionLevel.EXACT_FORMULA_PLUS_SG
        )
        if eligible:
            rows.append(dict(summary) | {"table_a_eligible": True})
    return rows


def build_table_b_rows(
    summaries: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for summary in summaries:
        generated = summary.get("generated")
        if not isinstance(generated, Mapping):
            raise ValueError("Table B summary is missing generated metric")
        if summary.get("common_evaluation_available") is not True:
            continue
        if int(generated.get("numerator", 0)) <= 0:
            continue
        rows.append(dict(summary) | {"table_b_eligible": True})
    return rows


def _seed_statistics(values: Sequence[float]) -> dict[str, Any]:
    frozen = tuple(float(value) for value in values)
    if len(frozen) != 3 or any(not math.isfinite(value) for value in frozen):
        raise ValueError("seed statistics require exactly three finite values")
    return {
        "mean": fmean(frozen),
        "sample_std": stdev(frozen),
        "seed_count": 3,
    }


def _nested_rate(summary: Mapping[str, Any], *path: str) -> float:
    value: Any = summary
    for key in path:
        value = value[key]
    if value is None or not math.isfinite(float(value)):
        raise ValueError(f"seed metric is unavailable: {'/'.join(path)}")
    return float(value)


def summarize_full_crysalis(
    attempts_by_seed: Mapping[int, Sequence[AttemptRecord]],
    common_by_seed: Mapping[int, Sequence[Mapping[str, Any]]],
    fixed_by_seed: Mapping[int, Sequence[Mapping[str, Any]]],
    cell_by_seed: Mapping[int, Sequence[Mapping[str, Any]]],
) -> dict[str, Any]:
    required = set(CRYSALIS_TRAINING_SEEDS)
    if any(
        set(mapping) != required
        for mapping in (
            attempts_by_seed,
            common_by_seed,
            fixed_by_seed,
            cell_by_seed,
        )
    ):
        raise ValueError("FULL_CRYSALIS requires exactly three training seeds")
    first_condition_order: list[str] | None = None
    per_seed: dict[str, dict[str, Any]] = {}
    for seed in CRYSALIS_TRAINING_SEEDS:
        attempts = tuple(attempts_by_seed[seed])
        if len(attempts) != 300:
            raise ValueError(f"FULL_CRYSALIS seed {seed} requires exactly 300 attempts")
        if any(
            attempt.model != "FULL_CRYSALIS" or attempt.training_seed != seed
            for attempt in attempts
        ):
            raise ValueError(f"FULL_CRYSALIS seed {seed} cohort identity drifted")
        order = [attempt.condition.condition_id for attempt in attempts]
        if first_condition_order is None:
            first_condition_order = order
        elif order != first_condition_order:
            raise ValueError("FULL_CRYSALIS seed condition order drifted")
        per_seed[str(seed)] = summarize_model_cohort(
            attempts,
            common_by_seed[seed],
            fixed_by_seed[seed],
            cell_by_seed[seed],
        )

    pooled_attempts = tuple(
        attempt for seed in CRYSALIS_TRAINING_SEEDS for attempt in attempts_by_seed[seed]
    )
    pooled_common = tuple(
        record for seed in CRYSALIS_TRAINING_SEEDS for record in common_by_seed[seed]
    )
    pooled_fixed = tuple(
        record for seed in CRYSALIS_TRAINING_SEEDS for record in fixed_by_seed[seed]
    )
    pooled_cell = tuple(record for seed in CRYSALIS_TRAINING_SEEDS for record in cell_by_seed[seed])
    pooled = summarize_model_cohort(pooled_attempts, pooled_common, pooled_fixed, pooled_cell)
    seed_summaries = [per_seed[str(seed)] for seed in CRYSALIS_TRAINING_SEEDS]
    metric_paths = {
        "generated_rate": ("generated", "rate"),
        "parse_valid_rate": ("parse_valid", "rate"),
        "common_legal_rate": ("common_legal", "rate"),
        "short_contact_free_rate": ("short_contact_free", "rate"),
        "reduced_formula_match_rate": (
            "composition",
            "reduced_formula_match",
            "rate",
        ),
        "exact_cell_count_match_rate": (
            "composition",
            "exact_cell_count_match",
            "rate",
        ),
        "strict_0_03_space_group_match_rate": (
            "target_space_group",
            "strict_0_03_match",
            "rate",
        ),
        "initial_force_mean": (
            "initial_max_force_ev_per_angstrom",
            "mean",
        ),
        "initial_force_median": (
            "initial_max_force_ev_per_angstrom",
            "median",
        ),
        "initial_force_p90": (
            "initial_max_force_ev_per_angstrom",
            "p90",
        ),
        "initial_force_p95": (
            "initial_max_force_ev_per_angstrom",
            "p95",
        ),
        "initial_force_max": (
            "initial_max_force_ev_per_angstrom",
            "max",
        ),
        "fixed_cell_convergence_rate": (
            "fixed_cell_fire300",
            "convergence",
            "rate",
        ),
        "fixed_cell_physical_survival_rate": (
            "fixed_cell_fire300",
            "physical_survival",
            "rate",
        ),
        "fixed_cell_strict_symmetry_survival_rate": (
            "fixed_cell_fire300",
            "strict_symmetry_survival",
            "rate",
        ),
        "cell_relax_convergence_rate": (
            "cell_relax_fire300",
            "convergence",
            "rate",
        ),
        "cell_relax_physical_survival_rate": (
            "cell_relax_fire300",
            "physical_survival",
            "rate",
        ),
        "cell_relax_strict_symmetry_survival_rate": (
            "cell_relax_fire300",
            "strict_symmetry_survival",
            "rate",
        ),
    }
    seed_statistics = {
        name: _seed_statistics([_nested_rate(summary, *path) for summary in seed_summaries])
        for name, path in metric_paths.items()
    }
    return {
        "schema_version": "g1-external-benchmark-full-crysalis-summary.1.0.0",
        "model": "FULL_CRYSALIS",
        "attempt_count": 900,
        "training_seeds": list(CRYSALIS_TRAINING_SEEDS),
        "pooled_900": pooled,
        "per_seed": per_seed,
        "seed_statistics": seed_statistics,
        "seed_statistics_definition": "arithmetic mean and sample standard deviation",
        "best_seed_selection_performed": False,
    }
