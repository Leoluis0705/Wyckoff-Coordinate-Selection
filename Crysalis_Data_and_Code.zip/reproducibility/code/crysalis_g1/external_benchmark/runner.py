from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from crysalis_g1.external_benchmark.capabilities import (
    capability_matrix_payload,
    official_capabilities,
)
from crysalis_g1.external_benchmark.config import ExternalBenchmarkConfig
from crysalis_g1.external_benchmark.analysis import (
    summarize_full_crysalis,
    summarize_model_cohort,
)
from crysalis_g1.external_benchmark.csp import (
    evaluate_csp_attempts,
    load_evaluator_references,
)
from crysalis_g1.external_benchmark.evaluation import (
    _frozen_checkpoint_contract,
    _frozen_generation_path_and_digest,
    _validate_eval_payload,
    attempt_evaluation_id,
    common_evaluate_attempts,
    load_frozen_crysalis_evaluations,
)
from crysalis_g1.external_benchmark.novelty import (
    cluster_unique_structures,
    select_crysalis_candidates,
)
from crysalis_g1.external_benchmark.provenance import (
    preflight_frozen_inputs,
    sha256_file,
)
from crysalis_g1.external_benchmark.reporting import (
    MATTERSIM_STABILITY_THRESHOLD_EV_PER_ATOM,
    REQUIRED_OUTPUTS,
    collect_upstream_bindings,
    validate_final_artifacts,
    validate_mattersim_result_rows,
)
from crysalis_g1.external_benchmark.records import (
    ATTEMPT_SCHEMA_VERSION,
    AttemptRecord,
    AttemptStatus,
    ModelProvenance,
    RegisteredCondition,
    StructurePayload,
    convert_frozen_crysalis_generation_files,
    load_registered_conditions_from_config,
    registered_sample_seed,
)


FORMAL_STAGE_ORDER = (
    "audit",
    "crystalformer",
    "crystalformer_k5_secondary",
    "other_baselines",
    "common_chgnet",
    "mattersim_secondary",
    "final",
)
SCIENTIFIC_STAGES = FORMAL_STAGE_ORDER[1:-1]
EXTERNAL_ARTIFACT_REGISTRY: dict[str, dict[str, Any]] = {
    "CrystalFormer": {
        "official_commit": "31bb734a3fd006af49a021921839061e6184cbf1",
        "checkpoint_sha256": ("df1e7051df836d26f45a93fd7f21069a183777317f318001b55f8df20805d177"),
    },
    "MatterGen": {
        "official_commit": "67afb22ea0dd0073aedfc85b30b94bea0ee21863",
        "checkpoint_sha256": ("1b6ab06739f4319d75f4a19960840ec3c8d3d32ee842c996876ef9d8b188e4bb"),
        "config_sha256": ("75ebcb5bcf3fc2f1c78aeb9a99c88bd99ebd61fcdaa5fe9463344a7c29df62ac"),
        "hugging_face_revision": "ea430eab64b80855029c2941b9fda15f245a771a",
    },
    "CrystalFlow": {
        "official_commit": "9c25ff0245d787efd87c9d1d797a8968443608cc",
        "release_zip_sha256": ("e0fa32e383d46f8d051859d90e3a11313970cabca2b0688ac9d4ed6e0156d728"),
        "checkpoint_sha256": ("b08366eb04d47698da7ea09dbccb1c4a1304a4c3f506fdc1d8c294910ade6dc2"),
        "hparams_sha256": ("1be9aa0c4d1bde9caf5ed8d76f4ff3760c667ba2bfa29d6c5d6bba01c3bc0a1b"),
        "scaler_sha256": {
            "lattice_scaler": ("baad2a8f6e8086a47c612e7a16cd0f10ea987c5fdd6309eda52cfa51a0f9d289"),
            "prop_scaler": ("7f2725921427bd0d996199756ba5ff01be6cb5aeb60f8fb143f037a31f88f7ee"),
            "prop_scalers": ("a10252190bc3b47559a63fb581054049e41827a14ce83cfcd8ff83b4c2b2963b"),
        },
    },
    "DiffCSP": {
        "official_commit": "7121d159826efa2ba9500bf299250d96da37f146",
        "checkpoint_sha256": ("c06719217c940718823f7c67b58c74a0fcfba4c3e4312b23cdd22b7a15ea6b5f"),
        "hparams_sha256": ("7e8afc601276abed9a112d93156aa6657ff78c3fe8634d412ccf684952e292a0"),
    },
    "MatterSim": {
        "official_commit": "aedf510ec536cf24163edad4570eaceafdb7cb2b",
        "checkpoint_sha256": ("28b0b0b0f13efefee06b47ea4c9105a26bd3e2c8396da193430da96b3b49a8be"),
        "weight_sha256": ("28b0b0b0f13efefee06b47ea4c9105a26bd3e2c8396da193430da96b3b49a8be"),
        "tri2024_reference_sha256": (
            "ab1b4426901ff7b0f8af6ee9c3cc0dd2fbe4b65c758ef2a95683071492d1c51d"
        ),
    },
}

_SHA256 = re.compile(r"[0-9a-f]{64}")
_COMMIT = re.compile(r"[0-9a-f]{40}")
_POLICY_FIELDS = {
    "retry_count": 0,
    "refill_count": 0,
    "sealed_or_blind_data_accessed": False,
    "server_used": False,
    "dft_used": False,
    "tuning_performed": False,
    "ablation_performed": False,
}
_MATTERSIM_STATUSES = {
    "COMPLETE",
    "NOT_RUN_RESOURCE_LIMIT",
    "FAILED_PRESERVED",
}


@dataclass(frozen=True, slots=True)
class StageContext:
    config: ExternalBenchmarkConfig
    repo_root: Path
    stage: str
    output_root: Path
    engineering_root: Path


@dataclass(frozen=True, slots=True)
class StageResult:
    outputs: tuple[Path, ...]
    evidence: Mapping[str, Any]
    command_receipts: tuple[Mapping[str, Any], ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "outputs", tuple(Path(path) for path in self.outputs))
        object.__setattr__(self, "evidence", dict(self.evidence))
        object.__setattr__(
            self,
            "command_receipts",
            tuple(dict(receipt) for receipt in self.command_receipts),
        )
        if not self.outputs:
            raise ValueError("stage result must declare outputs")


@dataclass(frozen=True, slots=True)
class StageAction:
    action_id: str
    execute: Callable[[StageContext], StageResult]
    registered_attempt_ids: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.action_id.strip():
            raise ValueError("injected action ID must be non-empty")
        if not callable(self.execute):
            raise TypeError("injected stage action must be callable")
        identities = tuple(str(value) for value in self.registered_attempt_ids)
        if any(not value.strip() for value in identities):
            raise ValueError("registered attempt identities must be non-empty")
        if len(identities) != len(set(identities)):
            raise ValueError("registered attempt identities must be unique")
        object.__setattr__(self, "registered_attempt_ids", identities)


_run_frozen_preflight = preflight_frozen_inputs


def _canonical_json(payload: object) -> str:
    return json.dumps(
        payload,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def _digest(payload: object) -> str:
    return hashlib.sha256(_canonical_json(payload).encode("utf-8")).hexdigest()


def _config_sha256(config: ExternalBenchmarkConfig) -> str:
    payload = {
        "config_path": str(config.config_path.resolve()),
        "config_file_sha256": sha256_file(config.config_path),
        "reference_commit": config.reference_commit,
        "replication_root": str(config.replication_root.resolve()),
        "positive_run_root": str(config.positive_run_root.resolve()),
        "output_root": str(config.output_root.resolve()),
        "official_artifact_cache": str(config.official_artifact_cache.resolve()),
        "condition_manifest_sha256": config.condition_manifest_sha256,
        "formal_attempt_count": config.formal_attempt_count,
        "training_seeds": list(config.training_seeds),
        "authorization": dict(config.authorization),
    }
    return _digest(payload)


def _registry_sha256() -> str:
    return _digest(EXTERNAL_ARTIFACT_REGISTRY)


def _validate_external_artifact_registry() -> None:
    capabilities = {
        capability.model: capability
        for capability in official_capabilities()
        if capability.model in EXTERNAL_ARTIFACT_REGISTRY
    }
    for model in ("CrystalFormer", "MatterGen", "CrystalFlow", "DiffCSP"):
        artifact = EXTERNAL_ARTIFACT_REGISTRY[model]
        capability = capabilities[model]
        if artifact["official_commit"] != capability.official_commit:
            raise ValueError(f"{model} registry commit differs from Task 2 capability")
        if artifact["checkpoint_sha256"] != capability.checkpoint_sha256:
            raise ValueError(f"{model} registry checkpoint differs from Task 2 capability")

    def validate(value: object, *, label: str) -> None:
        if isinstance(value, Mapping):
            for name, item in value.items():
                validate(item, label=f"{label}/{name}")
        elif label.endswith(("official_commit", "hugging_face_revision")):
            if _COMMIT.fullmatch(str(value)) is None:
                raise ValueError(f"invalid registered revision: {label}")
        elif label.endswith("sha256") or "/scaler_sha256/" in label:
            if _SHA256.fullmatch(str(value)) is None:
                raise ValueError(f"invalid registered SHA-256: {label}")

    validate(EXTERNAL_ARTIFACT_REGISTRY, label="external_artifacts")


def _atomic_write_json_new(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(f"immutable artifact already exists: {path}")
    content = (_canonical_json(payload) + "\n").encode("utf-8")
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb",
            dir=path.parent,
            prefix=f".{path.name}.",
            delete=False,
        ) as handle:
            temporary = Path(handle.name)
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.link(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _receipt_path(config: ExternalBenchmarkConfig, stage: str) -> Path:
    return config.output_root / "engineering" / "receipts" / f"{stage}.json"


def _launch_claim_path(config: ExternalBenchmarkConfig, stage: str) -> Path:
    return config.output_root / "engineering" / "launch_claims" / f"{stage}.json"


def _relative_output(config: ExternalBenchmarkConfig, path: Path) -> str:
    root = config.output_root.resolve()
    resolved = path.resolve()
    if not resolved.is_relative_to(root):
        raise ValueError(f"stage output is outside the benchmark root: {resolved}")
    return resolved.relative_to(root).as_posix()


def _preflight_digest(receipt: Mapping[str, Any]) -> str:
    if not isinstance(receipt, Mapping) or receipt.get("status") != "PASS":
        raise ValueError("frozen-input preflight did not pass")
    return _digest(receipt)


def _validate_policy_payload(payload: object, *, label: str) -> None:
    if isinstance(payload, Mapping):
        for key, value in payload.items():
            if key in _POLICY_FIELDS:
                expected = _POLICY_FIELDS[key]
                exact = (
                    type(value) is bool and value is expected
                    if type(expected) is bool
                    else type(value) is int and value == expected
                )
                if not exact:
                    raise ValueError(f"{label} {key} violates the frozen benchmark policy")
            _validate_policy_payload(value, label=f"{label}/{key}")
    elif isinstance(payload, Sequence) and not isinstance(payload, (str, bytes)):
        for index, value in enumerate(payload):
            _validate_policy_payload(value, label=f"{label}/{index}")


def _validate_stage_evidence(stage: str, evidence: Mapping[str, Any]) -> None:
    if not isinstance(evidence, Mapping):
        raise TypeError(f"{stage} stage evidence must be an object")
    _validate_policy_payload(evidence, label=f"{stage} evidence")
    if stage == "audit":
        if evidence.get("status") != "PASS":
            raise ValueError("audit evidence did not pass")
        return
    if stage == "crystalformer":
        expected = {
            "model": "CrystalFormer",
            "condition_level": "EXACT_FORMULA_PLUS_SG",
            "attempt_count": 300,
            "samples_per_condition": 1,
            "denominator_complete": True,
            "retry_count": 0,
            "refill_count": 0,
        }
        if any(evidence.get(name) != value for name, value in expected.items()):
            raise ValueError("CrystalFormer requires exactly 300 K=1 Track A attempts")
        return
    if stage == "crystalformer_k5_secondary":
        expected = {
            "model": "CrystalFormer",
            "condition_level": "EXACT_FORMULA_PLUS_SG",
            "analysis_role": "SECONDARY_CSP_ONLY",
            "attempt_count": 1200,
            "samples_per_condition": 4,
            "sample_indices": [1, 2, 3, 4],
            "denominator_complete": True,
            "pooled_with_k1": False,
            "may_replace_k1": False,
            "retry_count": 0,
            "refill_count": 0,
        }
        if any(evidence.get(name) != value for name, value in expected.items()):
            raise ValueError("CrystalFormer K=5 secondary evidence drifted")
        return
    if stage == "other_baselines":
        if evidence.get("stage_status") != "COMPLETE":
            raise ValueError("other-baseline evidence must be complete")
        raw_rows = evidence.get("baseline_records")
        if not isinstance(raw_rows, Sequence) or isinstance(raw_rows, (str, bytes)):
            raise ValueError("other-baseline evidence records are missing")
        rows = {str(row.get("model")): row for row in raw_rows if isinstance(row, Mapping)}
        expected_capabilities = {
            capability.model: capability
            for capability in official_capabilities()
            if capability.model != "CrystalFormer"
        }
        if set(rows) != set(expected_capabilities) or len(rows) != len(raw_rows):
            raise ValueError("other-baseline evidence is missing or duplicated")
        for model, capability in expected_capabilities.items():
            row = rows[model]
            if (
                row.get("condition_level") != capability.condition_level.value
                or row.get("capability_execution_status") != capability.execution_status.value
                or row.get("attempt_count") != 300
                or row.get("denominator_complete") is not True
                or row.get("evidence_status")
                not in {"COMPLETE", "UNSUPPORTED", "FAILED_PRESERVED", "NOT_RUN_RESOURCE_LIMIT"}
            ):
                raise ValueError(f"other-baseline evidence drifted: {model}")
        dyna = rows["DynaCrys"]
        if (
            dyna.get("evidence_status") != "UNSUPPORTED"
            or dyna.get("capability_execution_status")
            != "NOT_RUN_NO_OFFICIAL_REPRODUCIBLE_ARTIFACT"
        ):
            raise ValueError("DynaCrys non-run evidence drifted")
        return
    if stage == "common_chgnet":
        if (
            evidence.get("stage_status") != "COMPLETE"
            or evidence.get("primary_evaluator") != "CHGNET_FIXED_AND_CELL_RELAX_FIRE300"
            or evidence.get("all_attempt_denominators") is not True
        ):
            raise ValueError("common CHGNet primary evidence drifted")
        return
    if stage == "mattersim_secondary":
        if (
            evidence.get("stage_status") not in _MATTERSIM_STATUSES
            or evidence.get("primary_chgnet_affected") is not False
        ):
            raise ValueError("MatterSim must remain secondary to common CHGNet")
        if evidence.get("stage_status") == "NOT_RUN_RESOURCE_LIMIT" and (
            not str(evidence.get("resource_limit_reason", "")).strip()
            or not isinstance(evidence.get("resource_evidence"), Mapping)
            or not evidence["resource_evidence"]
        ):
            raise ValueError("MatterSim resource non-run requires precise evidence")
        if (
            evidence.get("stage_status") == "FAILED_PRESERVED"
            and not str(evidence.get("failure_reason", "")).strip()
        ):
            raise ValueError("MatterSim preserved failure requires a reason")
        return
    if stage == "final" and (
        evidence.get("stage_status") != "COMPLETE"
        or tuple(evidence.get("required_outputs", ())) != REQUIRED_OUTPUTS
    ):
        raise ValueError("final-stage required output evidence drifted")


_ATTEMPT_KEYS = {
    "schema_version",
    "model",
    "condition_level",
    "training_data",
    "training_seed",
    "condition",
    "sample_index",
    "registered_seed",
    "status",
    "failure_code",
    "failure_message",
    "structure",
    "generation_latency_seconds",
    "peak_ram_bytes",
    "peak_vram_bytes",
    "retry_count",
    "refill_count",
    "provenance",
}


def _attempt_from_dict(payload: Mapping[str, Any]) -> AttemptRecord:
    if set(payload) != _ATTEMPT_KEYS or payload.get("schema_version") != ATTEMPT_SCHEMA_VERSION:
        raise ValueError("attempt record schema drifted")
    provenance = payload.get("provenance")
    condition = payload.get("condition")
    structure = payload.get("structure")
    if not isinstance(provenance, Mapping) or not isinstance(condition, Mapping):
        raise ValueError("attempt record provenance or condition is missing")
    if structure is not None and not isinstance(structure, Mapping):
        raise ValueError("attempt record structure is malformed")
    record = AttemptRecord(
        model=str(payload.get("model", "")),
        condition_level=payload.get("condition_level"),
        training_data=str(payload.get("training_data", "")),
        training_seed=payload.get("training_seed"),
        condition=RegisteredCondition.from_dict(condition),
        sample_index=payload.get("sample_index"),
        registered_seed=payload.get("registered_seed"),
        status=payload.get("status"),
        failure_code=payload.get("failure_code"),
        failure_message=payload.get("failure_message"),
        structure=(None if structure is None else StructurePayload.from_dict(structure)),
        generation_latency_seconds=payload.get("generation_latency_seconds"),
        peak_ram_bytes=payload.get("peak_ram_bytes"),
        peak_vram_bytes=payload.get("peak_vram_bytes"),
        retry_count=payload.get("retry_count"),
        refill_count=payload.get("refill_count"),
        provenance=ModelProvenance(**provenance),
    )
    if record.to_dict() != dict(payload):
        raise ValueError("attempt record normalization drifted")
    return record


def _load_bound_jsonl(
    config: ExternalBenchmarkConfig,
    declaration: object,
    outputs: Sequence[Path],
    *,
    label: str,
) -> tuple[Mapping[str, Any], ...]:
    if not isinstance(declaration, Mapping):
        raise ValueError(f"{label} declaration is missing")
    path = config.output_root / str(declaration.get("path", ""))
    if (
        not path.resolve().is_relative_to((config.output_root / "engineering").resolve())
        or path.resolve() not in {output.resolve() for output in outputs}
        or not path.is_file()
        or sha256_file(path) != declaration.get("sha256")
    ):
        raise ValueError(f"{label} path or hash drifted")
    rows: list[Mapping[str, Any]] = []
    with path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, start=1):
            if not line.strip():
                raise ValueError(f"{label} contains a blank row at line {line_number}")
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                raise ValueError(f"{label} contains invalid JSON at line {line_number}") from None
            if not isinstance(row, Mapping):
                raise ValueError(f"{label} row {line_number} is not an object")
            rows.append(row)
    if declaration.get("record_count") != len(rows):
        raise ValueError(f"{label} record count drifted")
    return tuple(rows)


def _load_bound_json(
    config: ExternalBenchmarkConfig,
    declaration: object,
    outputs: Sequence[Path],
    *,
    label: str,
) -> Mapping[str, Any]:
    if not isinstance(declaration, Mapping):
        raise ValueError(f"{label} declaration is missing")
    path = config.output_root / str(declaration.get("path", ""))
    if (
        not path.resolve().is_relative_to((config.output_root / "engineering").resolve())
        or path.resolve() not in {output.resolve() for output in outputs}
        or not path.is_file()
        or sha256_file(path) != declaration.get("sha256")
    ):
        raise ValueError(f"{label} path or hash drifted")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError(f"{label} must be a JSON object")
    return payload


def _validate_attempt_stage_payload(
    config: ExternalBenchmarkConfig,
    stage: str,
    evidence: Mapping[str, Any],
    outputs: Sequence[Path],
) -> None:
    rows = _load_bound_jsonl(
        config,
        evidence.get("attempt_records"),
        outputs,
        label=f"{stage} attempt records",
    )
    records = tuple(_attempt_from_dict(row) for row in rows)
    conditions = load_registered_conditions_from_config(config)
    if stage == "crystalformer":
        expected = [(condition, 0) for condition in conditions]
        expected_model = "CrystalFormer"
        capability = next(item for item in official_capabilities() if item.model == expected_model)
        expected_rows = [
            (expected_model, capability, condition, sample) for condition, sample in expected
        ]
    elif stage == "crystalformer_k5_secondary":
        expected_rows = [
            (
                "CrystalFormer",
                next(item for item in official_capabilities() if item.model == "CrystalFormer"),
                condition,
                sample,
            )
            for condition in conditions
            for sample in (1, 2, 3, 4)
        ]
    else:
        baseline_evidence = {
            str(row["model"]): row
            for row in evidence.get("baseline_records", ())
            if isinstance(row, Mapping)
        }
        expected_rows = [
            (capability.model, capability, condition, 0)
            for capability in official_capabilities()
            if capability.model != "CrystalFormer"
            for condition in conditions
        ]
    if len(records) != len(expected_rows):
        raise ValueError(f"{stage} retained attempt denominator drifted")
    for record, (model, capability, condition, sample_index) in zip(
        records, expected_rows, strict=True
    ):
        if (
            record.model != model
            or record.condition_level.value != capability.condition_level.value
            or record.training_data != capability.training_dataset
            or record.training_seed is not None
            or record.condition.to_dict() != condition.to_dict()
            or record.sample_index != sample_index
            or record.registered_seed != registered_sample_seed(condition, sample_index)
        ):
            raise ValueError(f"{stage} retained attempt identity drifted")
        if model in EXTERNAL_ARTIFACT_REGISTRY:
            artifact = EXTERNAL_ARTIFACT_REGISTRY[model]
            if (
                record.provenance.implementation_commit != artifact["official_commit"]
                or record.provenance.checkpoint_sha256 != artifact["checkpoint_sha256"]
            ):
                raise ValueError(f"{stage} attempt provenance drifted: {model}")
        if stage == "other_baselines":
            status = str(baseline_evidence[model]["evidence_status"])
            if status == "UNSUPPORTED":
                if (
                    record.status is not AttemptStatus.UNSUPPORTED
                    or record.failure_code != capability.execution_status.value
                ):
                    raise ValueError(f"unsupported attempt evidence drifted: {model}")
            elif record.status is AttemptStatus.UNSUPPORTED:
                raise ValueError(f"runnable baseline retained unsupported attempts: {model}")


def _load_prior_attempt_records(
    config: ExternalBenchmarkConfig,
    stage: str,
) -> tuple[AttemptRecord, ...]:
    receipt_path = _receipt_path(config, stage)
    if not receipt_path.is_file():
        raise FileNotFoundError(f"verified typed attempt receipt is missing: {stage}")
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    evidence = receipt.get("evidence") if isinstance(receipt, Mapping) else None
    hashes = receipt.get("output_sha256") if isinstance(receipt, Mapping) else None
    if not isinstance(evidence, Mapping) or not isinstance(hashes, Mapping):
        raise ValueError(f"verified typed attempt receipt is malformed: {stage}")
    outputs = tuple(config.output_root / str(relative) for relative in hashes)
    rows = _load_bound_jsonl(
        config,
        evidence.get("attempt_records"),
        outputs,
        label=f"{stage} upstream attempt records",
    )
    return tuple(_attempt_from_dict(row) for row in rows)


def _load_frozen_crysalis_contract(
    config: ExternalBenchmarkConfig,
    repo_root: Path,
) -> dict[str, Any]:
    """Use the Task 5 receipt-bound loaders for the exact frozen three-seed cohort."""

    conditions = load_registered_conditions_from_config(config)
    checkpoints = {
        seed: _frozen_checkpoint_contract(config, seed) for seed in config.training_seeds
    }
    generations = {
        seed: _frozen_generation_path_and_digest(config, seed) for seed in config.training_seeds
    }
    attempts_by_seed = convert_frozen_crysalis_generation_files(
        {seed: value[0] for seed, value in generations.items()},
        conditions,
        implementation_commit=config.reference_commit,
        checkpoints={
            seed: (str(value[0].resolve()), value[1]) for seed, value in checkpoints.items()
        },
    )
    evaluations_by_seed = load_frozen_crysalis_evaluations(
        config,
        attempts_by_seed,
        repo_root=repo_root,
    )
    source_artifacts = {
        str(seed): {
            "checkpoint": {
                "path": str(checkpoints[seed][0].resolve()),
                "sha256": checkpoints[seed][1],
            },
            "generation": {
                "path": str(generations[seed][0].resolve()),
                "sha256": generations[seed][1],
            },
            "evaluation": {
                "path": evaluations_by_seed[seed]["source_path"],
                "sha256": evaluations_by_seed[seed]["source_sha256"],
            },
        }
        for seed in config.training_seeds
    }
    return {
        "attempts_by_seed": attempts_by_seed,
        "evaluations_by_seed": evaluations_by_seed,
        "source_artifacts": source_artifacts,
    }


def _validate_common_chgnet_payload(
    config: ExternalBenchmarkConfig,
    payload: Mapping[str, Any],
    evidence: Mapping[str, Any],
    *,
    repo_root: Path,
) -> None:
    frozen = _load_frozen_crysalis_contract(config, repo_root)
    attempts_by_seed = frozen.get("attempts_by_seed")
    evaluations_by_seed = frozen.get("evaluations_by_seed")
    if not isinstance(attempts_by_seed, Mapping) or not isinstance(evaluations_by_seed, Mapping):
        raise ValueError("receipt-derived frozen Crysalis contract is malformed")
    full_attempts = tuple(
        attempt for seed in config.training_seeds for attempt in attempts_by_seed.get(seed, ())
    )
    crystalformer = _load_prior_attempt_records(config, "crystalformer")
    other_baselines = _load_prior_attempt_records(config, "other_baselines")
    all_attempts = full_attempts + crystalformer + other_baselines
    expected_ids = tuple(attempt_evaluation_id(attempt) for attempt in all_attempts)
    full = payload.get("full_crysalis")
    expected_boundary = {
        "role": "TERMINAL_EVALUATION_ONLY",
        "writes_generation_state": False,
        "enters_training_loss": False,
        "checkpoint_selection": False,
        "separate_from_guide_instance": True,
    }
    if (
        payload.get("schema_version") != "g1-external-benchmark-common-stage.1.0.0"
        or payload.get("attempt_count") != len(expected_ids)
        or tuple(payload.get("attempt_ids", ())) != expected_ids
        or payload.get("evalmlip_boundary") != expected_boundary
        or not isinstance(full, Mapping)
        or full.get("attempt_count") != 900
        or tuple(full.get("training_seeds", ())) != tuple(config.training_seeds)
        or full.get("per_seed_attempt_count") != {str(seed): 300 for seed in config.training_seeds}
        or full.get("reference_commit") != config.reference_commit
        or full.get("source_artifacts") != frozen.get("source_artifacts")
    ):
        raise ValueError("receipt-derived frozen Crysalis source contract drifted")
    common_records = payload.get("common_records")
    expected_common = common_evaluate_attempts(all_attempts)
    if not isinstance(common_records, list) or len(common_records) != len(expected_common):
        raise ValueError("common CHGNet typed common-evaluation records drifted")
    for index, (observed, expected) in enumerate(zip(common_records, expected_common, strict=True)):
        warnings = observed.get("symmetry_warnings") if isinstance(observed, Mapping) else None
        if not isinstance(warnings, list) or any(
            not isinstance(item, str) or not item.startswith("symprec=") for item in warnings
        ):
            raise ValueError("common CHGNet retained symmetry warnings are malformed")
        observed_stable = dict(observed)
        expected_stable = dict(expected)
        observed_stable.pop("symmetry_warnings", None)
        expected_stable.pop("symmetry_warnings", None)
        if observed_stable != expected_stable:
            differing = sorted(
                key
                for key in set(observed_stable) | set(expected_stable)
                if observed_stable.get(key) != expected_stable.get(key)
            )
            raise ValueError(
                f"common CHGNet typed common-evaluation records drifted at row {index}: {differing}"
            )
    evalmlip = payload.get("evalmlip")
    if not isinstance(evalmlip, Mapping):
        raise ValueError("common CHGNet typed fixed/cell records are missing")
    _validate_eval_payload(
        evalmlip,
        all_attempts,
        expected_weight_sha256=config.frozen_artifact_sha256["chgnet_weights"],
    )
    fixed = evalmlip["fixed_cell_fire300"]["records"]
    cell = evalmlip["cell_relax_fire300"]["records"]
    offset = 0
    for seed in config.training_seeds:
        attempts = tuple(attempts_by_seed[seed])
        count = len(attempts)
        frozen_eval = evaluations_by_seed[seed]
        if list(fixed[offset : offset + count]) != list(
            frozen_eval["fixed_cell_fire300"]["records"]
        ) or list(cell[offset : offset + count]) != list(
            frozen_eval["cell_relax_fire300"]["records"]
        ):
            raise ValueError(f"frozen Crysalis seed {seed} fixed/cell records drifted")
        summarize_model_cohort(
            attempts,
            expected_common[offset : offset + count],
            fixed[offset : offset + count],
            cell[offset : offset + count],
        )
        offset += count
    for cohort in (crystalformer,) + tuple(
        tuple(attempt for attempt in other_baselines if attempt.model == capability.model)
        for capability in official_capabilities()
        if capability.model != "CrystalFormer"
    ):
        count = len(cohort)
        if count != 300:
            raise ValueError("common CHGNet upstream cohort denominator drifted")
        summarize_model_cohort(
            cohort,
            expected_common[offset : offset + count],
            fixed[offset : offset + count],
            cell[offset : offset + count],
        )
        offset += count
    if offset != len(all_attempts):
        raise ValueError("common CHGNet typed record coverage drifted")
    eligible = [
        attempt_evaluation_id(attempt)
        for attempt in all_attempts
        if attempt.status is AttemptStatus.GENERATED
    ]
    if payload.get("mattersim_eligible_attempt_ids") != eligible or (
        evidence.get("mattersim_eligible_attempt_ids") != eligible
    ):
        raise ValueError("common CHGNet MatterSim eligibility evidence drifted")


def _load_stage_json_artifact(
    config: ExternalBenchmarkConfig,
    stage: str,
    evidence_field: str,
    *,
    label: str,
) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    receipt_path = _receipt_path(config, stage)
    if not receipt_path.is_file():
        raise FileNotFoundError(f"verified {label} receipt is missing")
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    evidence = receipt.get("evidence") if isinstance(receipt, Mapping) else None
    hashes = receipt.get("output_sha256") if isinstance(receipt, Mapping) else None
    if not isinstance(evidence, Mapping) or not isinstance(hashes, Mapping):
        raise ValueError(f"verified {label} receipt is malformed")
    outputs = tuple(config.output_root / str(relative) for relative in hashes)
    return (
        _load_bound_json(
            config,
            evidence.get(evidence_field),
            outputs,
            label=label,
        ),
        evidence,
    )


def _interleave_crystalformer_k5(
    primary: Sequence[AttemptRecord],
    secondary: Sequence[AttemptRecord],
) -> tuple[AttemptRecord, ...]:
    if len(primary) != 300 or len(secondary) != 1200:
        raise ValueError("upstream CrystalFormer K=5 denominator drifted")
    combined: list[AttemptRecord] = []
    for index, primary_record in enumerate(primary):
        combined.append(primary_record)
        combined.extend(secondary[index * 4 : (index + 1) * 4])
    return tuple(combined)


def _failure_record(
    *,
    source: str,
    model: str,
    evaluation_id: str | None,
    status: str,
    failure_code: str,
    failure_message: str,
) -> dict[str, Any]:
    if not all(
        isinstance(value, str) and value.strip()
        for value in (source, model, status, failure_code, failure_message)
    ):
        raise ValueError("upstream failure record is missing typed detail")
    if evaluation_id is not None and (
        not isinstance(evaluation_id, str) or not evaluation_id.strip()
    ):
        raise ValueError("upstream failure record identity is malformed")
    return {
        "schema_version": "g1-external-benchmark-failure.1.0.0",
        "source": source,
        "model": model,
        "evaluation_id": evaluation_id,
        "status": status,
        "failure_code": failure_code,
        "failure_message": failure_message,
    }


def _retained_failure_records(
    attempts: Sequence[AttemptRecord],
    common_records: Sequence[Mapping[str, Any]],
    fixed_records: Sequence[Mapping[str, Any]],
    cell_records: Sequence[Mapping[str, Any]],
    csp_results: Mapping[str, Any],
    mattersim_results: Mapping[str, Any],
) -> list[dict[str, Any]]:
    failures: list[dict[str, Any]] = []
    for capability in official_capabilities():
        status = capability.execution_status.value
        if status.startswith("NOT_RUN_"):
            failures.append(
                _failure_record(
                    source="CAPABILITY",
                    model=capability.model,
                    evaluation_id=None,
                    status=status,
                    failure_code=status,
                    failure_message=capability.reason,
                )
            )
    model_by_id = {attempt_evaluation_id(attempt): attempt.model for attempt in attempts}
    for attempt in attempts:
        if attempt.status is not AttemptStatus.GENERATED:
            failures.append(
                _failure_record(
                    source="GENERATION",
                    model=attempt.model,
                    evaluation_id=attempt_evaluation_id(attempt),
                    status=attempt.status.value,
                    failure_code=str(attempt.failure_code),
                    failure_message=str(attempt.failure_message),
                )
            )
    for record in common_records:
        if record.get("generated") is True and record.get("parse_valid") is not True:
            identity = str(record.get("evaluation_id", ""))
            failures.append(
                _failure_record(
                    source="COMMON_EVALUATION",
                    model=str(record.get("model", "")),
                    evaluation_id=identity,
                    status="FAILED_PRESERVED",
                    failure_code="STRUCTURE_PARSE_FAILED",
                    failure_message=str(record.get("parse_failure_reason", "")),
                )
            )
    for source, records in (
        ("FIXED_CELL_FIRE300", fixed_records),
        ("CELL_RELAX_FIRE300", cell_records),
    ):
        for record in records:
            status = str(record.get("status", ""))
            if status == "EVALUATED":
                continue
            identity = str(record.get("condition_id", ""))
            failures.append(
                _failure_record(
                    source=source,
                    model=model_by_id.get(identity, "UNKNOWN_MODEL"),
                    evaluation_id=identity,
                    status="FAILED_PRESERVED",
                    failure_code=status,
                    failure_message=str(
                        record.get("failure_message")
                        or record.get("failure_reason")
                        or f"retained upstream {source} status: {status}"
                    ),
                )
            )
    for csp_name in ("crystalformer_k1", "crystalformer_k5_secondary"):
        csp = csp_results.get(csp_name)
        if not isinstance(csp, Mapping):
            raise ValueError("upstream CSP failure contract is missing")
        for condition in csp.get("per_condition", ()):
            if not isinstance(condition, Mapping):
                raise ValueError("upstream CSP failure row is malformed")
            condition_id = str(condition.get("condition_id", ""))
            for sample in condition.get("sample_results", ()):
                if not isinstance(sample, Mapping) or sample.get("failure_code") is None:
                    continue
                failures.append(
                    _failure_record(
                        source=csp_name.upper(),
                        model="CrystalFormer",
                        evaluation_id=(
                            f"{condition_id}/sample-{sample.get('sample_index')}/"
                            f"seed-{sample.get('registered_seed')}"
                        ),
                        status="FAILED_PRESERVED",
                        failure_code=str(sample.get("failure_code")),
                        failure_message=str(sample.get("failure_message")),
                    )
                )
    results = mattersim_results.get("results")
    if isinstance(results, list):
        for row in results:
            if not isinstance(row, Mapping) or row.get("status") != "FAILED_PRESERVED":
                continue
            identity = str(row.get("attempt_id", ""))
            failures.append(
                _failure_record(
                    source="MATTERSIM",
                    model=model_by_id.get(identity, "UNKNOWN_MODEL"),
                    evaluation_id=identity,
                    status="FAILED_PRESERVED",
                    failure_code=str(row.get("failure_code")),
                    failure_message=str(row.get("failure_message")),
                )
            )
    return failures


def build_final_scientific_contract(
    config: ExternalBenchmarkConfig,
    *,
    repo_root: str | Path,
) -> dict[str, Any]:
    """Recompute final scientific payloads from receipt-bound typed upstream rows."""

    repo = Path(repo_root).resolve()
    common_payload, common_evidence = _load_stage_json_artifact(
        config,
        "common_chgnet",
        "common_evaluation",
        label="common CHGNet evaluation",
    )
    _validate_common_chgnet_payload(
        config,
        common_payload,
        common_evidence,
        repo_root=repo,
    )
    frozen = _load_frozen_crysalis_contract(config, repo)
    attempts_by_seed = frozen["attempts_by_seed"]
    full_attempts = tuple(
        attempt for seed in config.training_seeds for attempt in attempts_by_seed[seed]
    )
    crystalformer = _load_prior_attempt_records(config, "crystalformer")
    crystalformer_k4 = _load_prior_attempt_records(config, "crystalformer_k5_secondary")
    other_baselines = _load_prior_attempt_records(config, "other_baselines")
    all_attempts = full_attempts + crystalformer + other_baselines
    common_records = tuple(common_payload["common_records"])
    evalmlip = common_payload["evalmlip"]
    fixed_records = tuple(evalmlip["fixed_cell_fire300"]["records"])
    cell_records = tuple(evalmlip["cell_relax_fire300"]["records"])

    try:
        offset = 0
        common_by_seed: dict[int, Sequence[Mapping[str, Any]]] = {}
        fixed_by_seed: dict[int, Sequence[Mapping[str, Any]]] = {}
        cell_by_seed: dict[int, Sequence[Mapping[str, Any]]] = {}
        for seed in config.training_seeds:
            count = len(attempts_by_seed[seed])
            common_by_seed[seed] = common_records[offset : offset + count]
            fixed_by_seed[seed] = fixed_records[offset : offset + count]
            cell_by_seed[seed] = cell_records[offset : offset + count]
            offset += count
        full_summary = summarize_full_crysalis(
            attempts_by_seed,
            common_by_seed,
            fixed_by_seed,
            cell_by_seed,
        )
        summaries: dict[str, Mapping[str, Any]] = {"FULL_CRYSALIS": full_summary["pooled_900"]}
        cohorts = (crystalformer,) + tuple(
            tuple(attempt for attempt in other_baselines if attempt.model == capability.model)
            for capability in official_capabilities()
            if capability.model != "CrystalFormer"
        )
        capabilities = {capability.model: capability for capability in official_capabilities()}
        for cohort in cohorts:
            count = len(cohort)
            model = cohort[0].model
            summaries[model] = summarize_model_cohort(
                cohort,
                common_records[offset : offset + count],
                fixed_records[offset : offset + count],
                cell_records[offset : offset + count],
                capability=capabilities[model],
            )
            offset += count
        if offset != len(all_attempts):
            raise ValueError("final summary cohort coverage drifted")
    except (KeyError, TypeError, ValueError) as error:
        raise ValueError(f"upstream scientific contract cannot be recomputed: {error}") from error

    table_b_models = (
        "FULL_CRYSALIS",
        "CrystalFormer",
        "MatterGen",
        "CrystalFlow",
        "DiffCSP",
    )
    common_results = {
        "schema_version": "g1-external-benchmark-common-results.1.0.0",
        "table_a_rows": [summaries["FULL_CRYSALIS"], summaries["CrystalFormer"]],
        "table_b_rows": [summaries[model] for model in table_b_models],
        "full_crysalis_summary": full_summary,
    }
    conditions = load_registered_conditions_from_config(config)
    references = load_evaluator_references(config)
    k1 = evaluate_csp_attempts(
        crystalformer,
        conditions,
        references,
        samples_per_condition=1,
    )
    k5 = evaluate_csp_attempts(
        _interleave_crystalformer_k5(crystalformer, crystalformer_k4),
        conditions,
        references,
        samples_per_condition=5,
    ) | {
        "analysis_role": "SECONDARY_CSP_ONLY",
        "pooled_with_k1_quality": False,
    }
    csp_results = {
        "schema_version": "g1-external-benchmark-csp-results.1.0.0",
        "crystalformer_k1": k1,
        "crystalformer_k5_secondary": k5,
    }
    mattersim_payload, _ = _load_stage_json_artifact(
        config,
        "mattersim_secondary",
        "mattersim_artifact",
        label="MatterSim secondary result",
    )
    mattersim_results = dict(mattersim_payload)
    mattersim_results["schema_version"] = "g1-external-benchmark-mattersim-results.1.0.0"
    uniqueness = cluster_unique_structures(
        full_attempts,
        common_records[: len(full_attempts)],
    )
    candidate_selection = select_crysalis_candidates(
        full_attempts,
        common_records[: len(full_attempts)],
        uniqueness,
        fixed_records[: len(full_attempts)],
    )
    failure_records = _retained_failure_records(
        all_attempts,
        common_records,
        fixed_records,
        cell_records,
        csp_results,
        mattersim_results,
    )
    return {
        "schema_version": "g1-external-benchmark-final-scientific-contract.1.0.0",
        "common_chgnet_results": common_results,
        "csp_results": csp_results,
        "mattersim_results": mattersim_results,
        "failure_records": failure_records,
        "candidate_selection": candidate_selection,
    }


def _validate_typed_stage_outputs(
    config: ExternalBenchmarkConfig,
    stage: str,
    evidence: Mapping[str, Any],
    outputs: Sequence[Path],
    *,
    repo_root: Path,
) -> None:
    if stage in {"crystalformer", "crystalformer_k5_secondary", "other_baselines"}:
        _validate_attempt_stage_payload(config, stage, evidence, outputs)
    elif stage == "common_chgnet":
        payload = _load_bound_json(
            config,
            evidence.get("common_evaluation"),
            outputs,
            label="common CHGNet evaluation",
        )
        _validate_common_chgnet_payload(
            config,
            payload,
            evidence,
            repo_root=repo_root,
        )
    elif stage == "mattersim_secondary":
        payload = _load_bound_json(
            config,
            evidence.get("mattersim_artifact"),
            outputs,
            label="MatterSim secondary result",
        )
        expected_ids = _mattersim_eligible_attempt_ids(config)
        if (
            payload.get("schema_version") != "g1-external-benchmark-mattersim-stage.1.0.0"
            or payload.get("stage_status") != evidence.get("stage_status")
            or payload.get("primary_chgnet_affected") is not False
            or tuple(payload.get("eligible_attempt_ids", ())) != expected_ids
            or payload.get("eligible_attempt_count") != len(expected_ids)
        ):
            raise ValueError("MatterSim typed result drifted")
        if evidence.get("stage_status") == "COMPLETE":
            results = payload.get("results")
            if (
                payload.get("smoke_test_status") != "PASS"
                or payload.get("weight_sha256")
                != EXTERNAL_ARTIFACT_REGISTRY["MatterSim"]["weight_sha256"]
                or payload.get("tri2024_reference_sha256")
                != EXTERNAL_ARTIFACT_REGISTRY["MatterSim"]["tri2024_reference_sha256"]
                or payload.get("stability_threshold_ev_per_atom")
                != MATTERSIM_STABILITY_THRESHOLD_EV_PER_ATOM
                or not isinstance(results, list)
                or [row.get("attempt_id") for row in results if isinstance(row, Mapping)]
                != list(expected_ids)
                or len(results) != len(expected_ids)
            ):
                raise ValueError("completed MatterSim smoke/evaluation evidence drifted")
            validate_mattersim_result_rows(results, expected_ids)
        elif evidence.get("stage_status") == "NOT_RUN_RESOURCE_LIMIT" and (
            payload.get("resource_limit_reason") != evidence.get("resource_limit_reason")
            or payload.get("resource_evidence") != evidence.get("resource_evidence")
            or payload.get("results") not in (None, [])
        ):
            raise ValueError("MatterSim resource non-run evidence drifted")
        elif evidence.get("stage_status") == "FAILED_PRESERVED" and (
            payload.get("failure_reason") != evidence.get("failure_reason")
            or payload.get("results") not in (None, [])
        ):
            raise ValueError("MatterSim stage-level preserved failure evidence drifted")
    elif stage == "final":
        bindings = collect_upstream_bindings(config.output_root)
        scientific_contract = build_final_scientific_contract(
            config,
            repo_root=repo_root,
        )
        validate_final_artifacts(
            config.output_root,
            expected_upstream_stage_receipt_sha256=bindings["upstream_stage_receipt_sha256"],
            expected_upstream_typed_artifact_sha256=bindings["upstream_typed_artifact_sha256"],
            expected_upstream_scientific_contract=scientific_contract,
        )


def _registered_crystalformer_attempt_ids(
    config: ExternalBenchmarkConfig,
    sample_indices: Sequence[int],
) -> tuple[str, ...]:
    return tuple(
        f"{condition.condition_id}/sample-{sample_index}/seed-"
        f"{registered_sample_seed(condition, sample_index)}"
        for condition in load_registered_conditions_from_config(config)
        for sample_index in sample_indices
    )


def _evaluation_attempt_id(
    model: str,
    training_seed: int | None,
    condition: RegisteredCondition,
    sample_index: int,
) -> str:
    seed_label = "none" if training_seed is None else str(training_seed)
    return (
        f"{model}/training-{seed_label}/{condition.condition_id}/sample-{sample_index}/"
        f"seed-{registered_sample_seed(condition, sample_index)}"
    )


def _other_baseline_attempt_ids(config: ExternalBenchmarkConfig) -> tuple[str, ...]:
    conditions = load_registered_conditions_from_config(config)
    return tuple(
        _evaluation_attempt_id(capability.model, None, condition, 0)
        for capability in official_capabilities()
        if capability.model != "CrystalFormer"
        for condition in conditions
    )


def _common_evaluation_attempt_ids(config: ExternalBenchmarkConfig) -> tuple[str, ...]:
    conditions = load_registered_conditions_from_config(config)
    crysalis = tuple(
        _evaluation_attempt_id("FULL_CRYSALIS", seed, condition, 0)
        for seed in config.training_seeds
        for condition in conditions
    )
    crystalformer = tuple(
        _evaluation_attempt_id("CrystalFormer", None, condition, 0) for condition in conditions
    )
    return crysalis + crystalformer + _other_baseline_attempt_ids(config)


def _mattersim_eligible_attempt_ids(config: ExternalBenchmarkConfig) -> tuple[str, ...]:
    path = _receipt_path(config, "common_chgnet")
    if not path.is_file():
        raise FileNotFoundError("verified common CHGNet receipt is required before MatterSim")
    receipt = json.loads(path.read_text(encoding="utf-8"))
    evidence = receipt.get("evidence")
    if not isinstance(evidence, Mapping):
        raise ValueError("common CHGNet evidence is missing")
    identities = evidence.get("mattersim_eligible_attempt_ids")
    if not isinstance(identities, list) or any(
        not isinstance(identity, str) or not identity for identity in identities
    ):
        raise ValueError("common CHGNet MatterSim eligible identities are malformed")
    return tuple(identities)


def _validate_action(
    config: ExternalBenchmarkConfig,
    stage: str,
    action: StageAction,
) -> None:
    if not isinstance(action, StageAction):
        raise TypeError(f"{stage} requires an explicit StageAction")
    count = len(action.registered_attempt_ids)
    if stage == "crystalformer":
        expected = _registered_crystalformer_attempt_ids(config, (0,))
        if action.registered_attempt_ids != expected:
            raise ValueError(
                "CrystalFormer launch claim requires exact registered "
                "condition/sample/seed identities"
            )
    if stage == "crystalformer_k5_secondary":
        expected = _registered_crystalformer_attempt_ids(config, (1, 2, 3, 4))
        if action.registered_attempt_ids != expected:
            raise ValueError(
                "CrystalFormer K=5 launch claim requires exact 1200 registered "
                "condition/sample/seed identities"
            )
    if stage == "other_baselines" and action.registered_attempt_ids != (
        _other_baseline_attempt_ids(config)
    ):
        raise ValueError("other baselines require exact retained attempt identities")
    if stage == "common_chgnet" and action.registered_attempt_ids != (
        _common_evaluation_attempt_ids(config)
    ):
        raise ValueError("common CHGNet requires exact all-attempt identities")
    if stage == "mattersim_secondary":
        expected = _mattersim_eligible_attempt_ids(config)
        if action.registered_attempt_ids != expected:
            raise ValueError("MatterSim launch identities differ from the eligible cohort")
    if stage == "final" and count != 0:
        raise ValueError("final stage cannot launch registered scientific attempts")


def _validate_command_receipt(
    config: ExternalBenchmarkConfig,
    receipt: Mapping[str, Any],
) -> None:
    required = {
        "argv",
        "cwd",
        "executable",
        "arguments",
        "shell",
        "environment_overrides",
        "runtime_versions",
        "official_commit",
        "checkpoint_sha256",
        "started_at",
        "ended_at",
        "exit_code",
        "stdout_path",
        "stdout_sha256",
        "stderr_path",
        "stderr_sha256",
        "launch_count",
        "retry_count",
        "refill_count",
    }
    if not required.issubset(receipt):
        raise ValueError("external command receipt is incomplete")
    if receipt.get("schema_version") != "g1-official-command-receipt.1.0.0":
        raise ValueError("external command receipt schema drifted")
    if (
        receipt.get("shell") is not False
        or receipt.get("launch_count") != 1
        or receipt.get("retry_count") != 0
        or receipt.get("refill_count") != 0
    ):
        raise ValueError("external command must launch once without retry/refill")
    argv = receipt.get("argv")
    arguments = receipt.get("arguments")
    executable = receipt.get("executable")
    if (
        not isinstance(argv, Sequence)
        or isinstance(argv, (str, bytes))
        or not argv
        or any(not isinstance(value, str) or not value.strip() for value in argv)
    ):
        raise ValueError("external command argv must be a non-empty string list")
    if not isinstance(executable, str) or not executable.strip():
        raise ValueError("external command executable must be non-empty")
    if (
        not isinstance(arguments, Sequence)
        or isinstance(arguments, (str, bytes))
        or any(not isinstance(value, str) or not value.strip() for value in arguments)
        or list(argv) != [executable, *arguments]
    ):
        raise ValueError("external command argv must equal executable plus arguments")
    cwd = Path(str(receipt.get("cwd", "")))
    if not cwd.is_absolute() or not cwd.is_dir():
        raise ValueError("external command working directory is invalid")
    if _COMMIT.fullmatch(str(receipt.get("official_commit"))) is None:
        raise ValueError("external command official commit is malformed")
    if _SHA256.fullmatch(str(receipt.get("checkpoint_sha256"))) is None:
        raise ValueError("external command checkpoint hash is malformed")
    if (
        not isinstance(receipt.get("environment_overrides"), Mapping)
        or not isinstance(receipt.get("runtime_versions"), Mapping)
        or not receipt["runtime_versions"]
    ):
        raise ValueError("external command environment provenance is malformed")
    if type(receipt.get("exit_code")) is not int:
        raise ValueError("external command exit code is malformed")
    timestamps: list[datetime] = []
    for field in ("started_at", "ended_at"):
        value = receipt.get(field)
        try:
            timestamp = datetime.fromisoformat(str(value))
        except ValueError:
            raise ValueError("external command timestamp is malformed") from None
        if timestamp.tzinfo is None or timestamp.utcoffset() != timedelta(0):
            raise ValueError("external command timestamp must be UTC")
        timestamps.append(timestamp)
    if timestamps[1] < timestamps[0]:
        raise ValueError("external command timestamp order is invalid")
    for stream in ("stdout", "stderr"):
        path = Path(str(receipt.get(f"{stream}_path"))).resolve()
        expected = str(receipt.get(f"{stream}_sha256"))
        if (
            not path.is_relative_to((config.output_root / "engineering").resolve())
            or not path.is_file()
            or sha256_file(path) != expected
        ):
            raise ValueError(f"external command {stream} hash drifted")
    _validate_policy_payload(receipt, label="external command receipt")


def _validate_required_command_receipts(
    stage: str,
    evidence: Mapping[str, Any],
    commands: Sequence[Mapping[str, Any]],
) -> None:
    required_models: set[str] = set()
    if stage in {"crystalformer", "crystalformer_k5_secondary"}:
        required_models.add("CrystalFormer")
    elif stage == "other_baselines":
        for row in evidence.get("baseline_records", ()):
            if (
                isinstance(row, Mapping)
                and row.get("model") in EXTERNAL_ARTIFACT_REGISTRY
                and row.get("evidence_status") in {"COMPLETE", "FAILED_PRESERVED"}
            ):
                required_models.add(str(row["model"]))
    elif stage == "mattersim_secondary" and evidence.get("stage_status") in {
        "COMPLETE",
        "FAILED_PRESERVED",
    }:
        required_models.add("MatterSim")
    expected = {
        (
            str(EXTERNAL_ARTIFACT_REGISTRY[model]["official_commit"]),
            str(EXTERNAL_ARTIFACT_REGISTRY[model]["checkpoint_sha256"]),
        )
        for model in required_models
    }
    observed = {
        (str(command.get("official_commit")), str(command.get("checkpoint_sha256")))
        for command in commands
    }
    if expected != observed or len(commands) != len(expected):
        raise ValueError(
            f"{stage} command receipt identities differ from completed official models"
        )
    artifacts = evidence.get("official_artifacts")
    expected_artifacts = {
        model: EXTERNAL_ARTIFACT_REGISTRY[model] for model in sorted(required_models)
    }
    if required_models and artifacts != expected_artifacts:
        raise ValueError(f"{stage} official artifact hashes are incomplete or drifted")
    statuses: dict[str, str] = {}
    if stage in {"crystalformer", "crystalformer_k5_secondary"}:
        statuses["CrystalFormer"] = "COMPLETE"
    elif stage == "other_baselines":
        statuses = {
            str(row["model"]): str(row["evidence_status"])
            for row in evidence.get("baseline_records", ())
            if isinstance(row, Mapping) and row.get("model") in required_models
        }
    elif stage == "mattersim_secondary":
        statuses["MatterSim"] = str(evidence.get("stage_status"))
    for command in commands:
        model = next(
            name
            for name in required_models
            if command.get("official_commit") == EXTERNAL_ARTIFACT_REGISTRY[name]["official_commit"]
        )
        if statuses[model] == "COMPLETE" and command.get("exit_code") != 0:
            raise ValueError("completed external command exit code must be zero")
        if command.get("exit_code") != 0 and statuses[model] != "FAILED_PRESERVED":
            raise ValueError("nonzero exit code requires FAILED_PRESERVED evidence")


def _write_launch_claim(
    config: ExternalBenchmarkConfig,
    *,
    stage: str,
    action: StageAction,
) -> dict[str, Any]:
    path = _launch_claim_path(config, stage)
    expected = {
        "schema_version": "g1-external-benchmark-launch-claim.1.0.0",
        "stage": stage,
        "action_id": action.action_id,
        "config_sha256": _config_sha256(config),
        "registered_attempt_count": len(action.registered_attempt_ids),
        "registered_attempt_ids": list(action.registered_attempt_ids),
        **_POLICY_FIELDS,
    }
    if path.exists():
        if _receipt_path(config, stage).exists():
            raise FileExistsError(f"completed stage cannot reuse launch claim: {stage}")
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise ValueError(f"{stage} launch claim is malformed") from None
        if (
            not isinstance(payload, Mapping)
            or set(payload) != set(expected) | {"created_at_utc"}
            or any(payload.get(name) != value for name, value in expected.items())
        ):
            raise ValueError(f"{stage} launch claim content drifted")
        try:
            created_at = datetime.fromisoformat(str(payload.get("created_at_utc")))
        except ValueError:
            raise ValueError(f"{stage} launch claim timestamp is malformed") from None
        if created_at.tzinfo is None or created_at.utcoffset() != timedelta(0):
            raise ValueError(f"{stage} launch claim timestamp must be UTC")
        _validate_policy_payload(payload, label=f"{stage} launch claim")
        return {
            "path": _relative_output(config, path),
            "sha256": sha256_file(path),
            "registered_attempt_count": len(action.registered_attempt_ids),
        }
    payload = {**expected, "created_at_utc": datetime.now(UTC).isoformat()}
    _atomic_write_json_new(path, payload)
    return {
        "path": _relative_output(config, path),
        "sha256": sha256_file(path),
        "registered_attempt_count": len(action.registered_attempt_ids),
    }


def _validate_launch_claim(
    config: ExternalBenchmarkConfig,
    stage: str,
    declaration: Mapping[str, Any] | None,
) -> None:
    if stage not in SCIENTIFIC_STAGES:
        if declaration is not None:
            raise ValueError(f"{stage} must not carry a launch claim")
        return
    if not isinstance(declaration, Mapping):
        raise ValueError(f"{stage} launch claim is missing")
    path = config.output_root / str(declaration.get("path", ""))
    if (
        not path.is_file()
        or sha256_file(path) != declaration.get("sha256")
        or not path.resolve().is_relative_to(config.output_root.resolve())
    ):
        raise ValueError(f"{stage} launch claim hash drifted")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if (
        payload.get("stage") != stage
        or payload.get("config_sha256") != _config_sha256(config)
        or payload.get("registered_attempt_count") != declaration.get("registered_attempt_count")
        or len(payload.get("registered_attempt_ids", ())) != payload.get("registered_attempt_count")
        or len(set(payload.get("registered_attempt_ids", ())))
        != payload.get("registered_attempt_count")
    ):
        raise ValueError(f"{stage} launch claim content drifted")
    _validate_policy_payload(payload, label=f"{stage} launch claim")


def _prior_receipt_hashes(config: ExternalBenchmarkConfig, stage: str) -> dict[str, str]:
    index = FORMAL_STAGE_ORDER.index(stage)
    return {
        prior: sha256_file(_receipt_path(config, prior)) for prior in FORMAL_STAGE_ORDER[:index]
    }


def _verify_stage_receipt(
    config: ExternalBenchmarkConfig,
    stage: str,
    *,
    repo_root: str | Path,
    current_preflight: Mapping[str, Any],
) -> dict[str, Any]:
    if stage not in FORMAL_STAGE_ORDER:
        raise ValueError(f"unsupported external benchmark stage: {stage}")
    current_preflight_sha256 = _preflight_digest(current_preflight)
    path = _receipt_path(config, stage)
    if not path.is_file():
        raise FileNotFoundError(f"prior external benchmark {stage} receipt is missing: {path}")
    receipt = json.loads(path.read_text(encoding="utf-8"))
    expected = {
        "schema_version": "g1-external-benchmark-stage-receipt.1.0.0",
        "stage": stage,
        "status": "COMPLETE",
        "config_sha256": _config_sha256(config),
        "frozen_preflight_receipt_sha256": current_preflight_sha256,
        "external_artifact_registry_sha256": _registry_sha256(),
        **_POLICY_FIELDS,
    }
    if not isinstance(receipt, Mapping) or any(
        receipt.get(name) != value for name, value in expected.items()
    ):
        raise ValueError(f"invalid or drifted external benchmark stage receipt: {stage}")
    _validate_policy_payload(receipt, label=f"{stage} stage receipt")
    outputs = receipt.get("output_sha256")
    if not isinstance(outputs, Mapping) or not outputs:
        raise ValueError(f"{stage} stage receipt has no hashed outputs")
    for relative, expected_hash in outputs.items():
        target = config.output_root / str(relative)
        if not target.resolve().is_relative_to(config.output_root.resolve()):
            raise ValueError(f"{stage} stage output path escapes the benchmark root")
        if not target.is_file():
            raise FileNotFoundError(f"{stage} stage output is missing: {target}")
        if sha256_file(target) != expected_hash:
            raise ValueError(f"{stage} stage output hash drifted: {relative}")
    expected_prior = _prior_receipt_hashes(config, stage)
    if receipt.get("prior_receipt_sha256") != expected_prior:
        raise ValueError(f"{stage} prior-receipt chain drifted")
    _validate_launch_claim(config, stage, receipt.get("launch_claim"))
    _validate_stage_evidence(stage, receipt.get("evidence", {}))
    _validate_typed_stage_outputs(
        config,
        stage,
        receipt["evidence"],
        tuple(config.output_root / str(relative) for relative in outputs),
        repo_root=Path(repo_root).resolve(),
    )
    commands = receipt.get("command_receipts")
    if not isinstance(commands, list):
        raise ValueError(f"{stage} command receipt list is missing")
    for command in commands:
        if not isinstance(command, Mapping):
            raise ValueError(f"{stage} command receipt is malformed")
        _validate_command_receipt(config, command)
    _validate_required_command_receipts(stage, receipt["evidence"], commands)
    return dict(receipt)


def verify_stage_receipt(
    config: ExternalBenchmarkConfig,
    stage: str,
    *,
    repo_root: str | Path,
) -> dict[str, Any]:
    current_preflight = _run_frozen_preflight(config, repo_root)
    repo = Path(repo_root).resolve()
    if stage not in FORMAL_STAGE_ORDER:
        raise ValueError(f"unsupported external benchmark stage: {stage}")
    for prior in FORMAL_STAGE_ORDER[: FORMAL_STAGE_ORDER.index(stage)]:
        _verify_stage_receipt(
            config,
            prior,
            repo_root=repo,
            current_preflight=current_preflight,
        )
    return _verify_stage_receipt(
        config,
        stage,
        repo_root=repo,
        current_preflight=current_preflight,
    )


def _verify_prior_receipts(
    config: ExternalBenchmarkConfig,
    stage: str,
    *,
    repo_root: Path,
    preflight_receipt: Mapping[str, Any],
) -> None:
    index = FORMAL_STAGE_ORDER.index(stage)
    for prior in FORMAL_STAGE_ORDER[:index]:
        _verify_stage_receipt(
            config,
            prior,
            repo_root=repo_root,
            current_preflight=preflight_receipt,
        )


def _run_audit(
    config: ExternalBenchmarkConfig,
    preflight_receipt: Mapping[str, Any],
) -> tuple[tuple[Path, ...], dict[str, Any]]:
    if config.output_root.exists():
        raise FileExistsError(
            f"external benchmark audit refuses existing output root: {config.output_root}"
        )
    _validate_external_artifact_registry()
    audit_root = config.output_root / "engineering" / "audit"
    config.output_root.mkdir(parents=True, exist_ok=False)
    preflight_path = audit_root / "frozen_preflight.json"
    capabilities_path = audit_root / "baseline_capabilities.json"
    registry_path = audit_root / "external_artifact_registry.json"
    _atomic_write_json_new(preflight_path, dict(preflight_receipt))
    _atomic_write_json_new(capabilities_path, capability_matrix_payload())
    _atomic_write_json_new(
        registry_path,
        {
            "schema_version": "g1-external-artifact-registry.1.0.0",
            "models": EXTERNAL_ARTIFACT_REGISTRY,
        },
    )
    evidence = {
        "status": "PASS",
        "condition_manifest_sha256": config.condition_manifest_sha256,
        "formal_crysalis_attempt_count": config.formal_attempt_count,
        "external_artifact_registry_sha256": _registry_sha256(),
        **_POLICY_FIELDS,
    }
    return (preflight_path, capabilities_path, registry_path), evidence


def _validate_result_outputs(
    config: ExternalBenchmarkConfig,
    stage: str,
    result: StageResult,
) -> tuple[Path, ...]:
    outputs = tuple(path.resolve() for path in result.outputs)
    if len(outputs) != len(set(outputs)) or any(not path.is_file() for path in outputs):
        raise RuntimeError(f"{stage} did not produce all unique declared outputs")
    root = config.output_root.resolve()
    if any(not path.is_relative_to(root) for path in outputs):
        raise ValueError(f"{stage} declared an output outside the benchmark root")
    if stage == "final":
        expected = {root / name for name in REQUIRED_OUTPUTS}
        if set(outputs) != expected:
            raise ValueError("final stage outputs differ from the required delivery names")
    else:
        engineering = (root / "engineering").resolve()
        if any(not path.is_relative_to(engineering) for path in outputs):
            raise ValueError("scientific payloads must remain under engineering")
        unexpected = [path.name for path in root.iterdir() if path.name != "engineering"]
        if unexpected:
            raise ValueError(f"top-level delivery files may be written only by final: {unexpected}")
    return outputs


def _append_failure(
    config: ExternalBenchmarkConfig,
    *,
    stage: str,
    error: BaseException,
) -> None:
    if not config.output_root.is_dir():
        return
    path = config.output_root / "engineering" / "runner_failures.jsonl"
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": "g1-external-benchmark-runner-failure.1.0.0",
        "recorded_at_utc": datetime.now(UTC).isoformat(),
        "stage": stage,
        "exception_type": type(error).__name__,
        "exception_message": str(error),
        **_POLICY_FIELDS,
    }
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(_canonical_json(payload) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def run_stage(
    config: ExternalBenchmarkConfig,
    *,
    stage: str,
    repo_root: str | Path,
    actions: Mapping[str, StageAction],
) -> dict[str, Any]:
    if stage not in FORMAL_STAGE_ORDER:
        raise ValueError(f"unsupported external benchmark stage: {stage}")
    repo = Path(repo_root).resolve()
    try:
        current_preflight = _run_frozen_preflight(config, repo)
        preflight_sha256 = _preflight_digest(current_preflight)
        receipt_path = _receipt_path(config, stage)
        if receipt_path.exists():
            raise FileExistsError(f"external benchmark stage already completed: {stage}")
        _verify_prior_receipts(
            config,
            stage,
            repo_root=repo,
            preflight_receipt=current_preflight,
        )
        started_at = datetime.now(UTC).isoformat()
        launch_claim: dict[str, Any] | None = None
        action_id = "BUILTIN_AUDIT"
        command_receipts: tuple[Mapping[str, Any], ...] = ()
        if stage == "audit":
            outputs, evidence = _run_audit(config, current_preflight)
        else:
            action = actions.get(stage)
            if action is None:
                raise ValueError(f"stage requires an explicit injected action: {stage}")
            _validate_action(config, stage, action)
            action_id = action.action_id
            if stage in SCIENTIFIC_STAGES:
                launch_claim = _write_launch_claim(config, stage=stage, action=action)
            context = StageContext(
                config=config,
                repo_root=repo,
                stage=stage,
                output_root=config.output_root.resolve(),
                engineering_root=(config.output_root / "engineering").resolve(),
            )
            result = action.execute(context)
            if not isinstance(result, StageResult):
                raise TypeError("injected stage action must return StageResult")
            outputs = _validate_result_outputs(config, stage, result)
            evidence = dict(result.evidence)
            command_receipts = result.command_receipts
            for command in command_receipts:
                _validate_command_receipt(config, command)
        _validate_stage_evidence(stage, evidence)
        _validate_typed_stage_outputs(
            config,
            stage,
            evidence,
            outputs,
            repo_root=repo,
        )
        _validate_required_command_receipts(stage, evidence, command_receipts)
        outputs = tuple(Path(path).resolve() for path in outputs)
        if stage == "audit":
            _validate_result_outputs(
                config,
                stage,
                StageResult(outputs=outputs, evidence=evidence),
            )
        ended_at = datetime.now(UTC).isoformat()
        receipt = {
            "schema_version": "g1-external-benchmark-stage-receipt.1.0.0",
            "stage": stage,
            "status": "COMPLETE",
            "started_at_utc": started_at,
            "completed_at_utc": ended_at,
            "config_sha256": _config_sha256(config),
            "frozen_preflight_receipt_sha256": preflight_sha256,
            "external_artifact_registry_sha256": _registry_sha256(),
            "prior_receipt_sha256": _prior_receipt_hashes(config, stage),
            "output_sha256": {
                _relative_output(config, path): sha256_file(path) for path in outputs
            },
            "injected_action": {"kind": "CALLABLE", "action_id": action_id},
            "launch_claim": launch_claim,
            "command_receipts": [dict(command) for command in command_receipts],
            "evidence": evidence,
            **_POLICY_FIELDS,
        }
        _atomic_write_json_new(receipt_path, receipt)
        return receipt
    except BaseException as error:
        _append_failure(config, stage=stage, error=error)
        raise


def run_all(
    config: ExternalBenchmarkConfig,
    *,
    repo_root: str | Path,
    actions: Mapping[str, StageAction],
) -> dict[str, Any]:
    repo = Path(repo_root).resolve()
    receipts: list[dict[str, Any]] = []
    resumed: list[str] = []
    for stage in FORMAL_STAGE_ORDER:
        if _receipt_path(config, stage).is_file():
            receipt = verify_stage_receipt(
                config,
                stage,
                repo_root=repo,
            )
            resumed.append(stage)
        else:
            receipt = run_stage(
                config,
                stage=stage,
                repo_root=repo,
                actions=actions,
            )
        receipts.append(receipt)
    return {
        "schema_version": "g1-external-benchmark-run-complete.1.0.0",
        "status": "COMPLETE",
        "completed_stages": [receipt["stage"] for receipt in receipts],
        "resumed_stages": resumed,
        "stopped_after": "final",
        "ablation_started": False,
        "automatic_post_final_stage": False,
    }
