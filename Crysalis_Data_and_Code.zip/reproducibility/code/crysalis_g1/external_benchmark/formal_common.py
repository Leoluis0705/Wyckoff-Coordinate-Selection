from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Mapping, Sequence

from crysalis_g1.external_benchmark.config import ExternalBenchmarkConfig
from crysalis_g1.external_benchmark.evaluation import (
    _validate_eval_payload,
    attempt_evaluation_id,
    build_frozen_eval_mlip,
    common_evaluate_attempts,
    run_eval_mlip_cohort,
)
from crysalis_g1.external_benchmark.provenance import preflight_frozen_inputs
from crysalis_g1.external_benchmark.records import AttemptRecord
from crysalis_g1.external_benchmark.runner import (
    StageAction,
    StageContext,
    StageResult,
    _common_evaluation_attempt_ids,
    _evaluation_attempt_id,
    _load_frozen_crysalis_contract,
    _load_prior_attempt_records,
)
from crysalis_g1.full_crysalis.config import sha256_file
import crysalis_g1.full_crysalis.evaluation as full_evaluation
from crysalis_g1.full_crysalis.evaluation import SYMPREC_VALUES, summarize_protocol


SCHEMA_VERSION = "g1-external-benchmark-common-stage.1.0.0"
_SOURCE_PATHS = (
    "crysalis_g1/external_benchmark/formal_common.py",
    "crysalis_g1/external_benchmark/runner.py",
    "crysalis_g1/external_benchmark/evaluation.py",
    "crysalis_g1/external_benchmark/analysis.py",
    "crysalis_g1/external_benchmark/config.py",
    "crysalis_g1/external_benchmark/capabilities.py",
    "crysalis_g1/external_benchmark/records.py",
    "crysalis_g1/external_benchmark/provenance.py",
    "crysalis_g1/full_crysalis/config.py",
    "crysalis_g1/full_crysalis/evaluation.py",
    "crysalis_g1/external_benchmark/symmetry_worker.py",
    "crysalis_g1/experiments/chgnet_terminal.py",
)
_POLICY_FIELDS = {
    "retry_count": 0,
    "refill_count": 0,
    "sealed_or_blind_data_accessed": False,
    "server_used": False,
    "dft_used": False,
    "tuning_performed": False,
    "ablation_performed": False,
}
_EVALMLIP_BOUNDARY = {
    "role": "TERMINAL_EVALUATION_ONLY",
    "writes_generation_state": False,
    "enters_training_loss": False,
    "checkpoint_selection": False,
    "separate_from_guide_instance": True,
}


def _canonical_json(payload: object) -> str:
    return json.dumps(
        payload,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def _detect_space_groups_isolated(structure: Any) -> dict[str, int]:
    detected = {f"{symprec:.2f}": 0 for symprec in SYMPREC_VALUES}
    payload = {
        "lattice": structure.lattice.matrix.tolist(),
        "atomic_numbers": [int(site.specie.Z) for site in structure],
        "fractional_coordinates": structure.frac_coords.tolist(),
    }
    try:
        completed = subprocess.run(
            (
                sys.executable,
                str(Path(__file__).with_name("symmetry_worker.py")),
            ),
            input=json.dumps(payload, allow_nan=False, separators=(",", ":")),
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
    except OSError:
        return detected
    for line in completed.stdout.splitlines():
        try:
            row = json.loads(line)
            label = str(row["label"])
            number = int(row["number"])
        except (KeyError, TypeError, ValueError, json.JSONDecodeError):
            continue
        if label in detected and 0 <= number <= 230:
            detected[label] = number
    return detected


def _augment_symmetry_isolated(record: Mapping[str, Any]) -> dict[str, Any]:
    result = dict(record)
    if result.get("status") != "EVALUATED":
        result["post_relax_detected_space_groups"] = {}
        result["strict_symmetry_preserving_survival"] = False
        return result
    structure = full_evaluation._structure_from_payload(result["final_structure"])
    detected = _detect_space_groups_isolated(structure)
    target = int(result["target_space_group"])
    strict_match = detected["0.03"] == target
    result["post_relax_detected_space_groups"] = detected
    result["strict_0_03_space_group_match"] = strict_match
    result["strict_symmetry_preserving_survival"] = bool(
        result.get("post_relax_survival") and strict_match
    )
    return result


def _git(
    repo_root: Path,
    *arguments: str,
) -> str:
    process = subprocess.run(
        (
            "git",
            "-c",
            f"safe.directory={repo_root.as_posix()}",
            *arguments,
        ),
        cwd=repo_root,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    if process.returncode != 0:
        detail = process.stderr.strip() or process.stdout.strip()
        raise RuntimeError(f"Git source-bundle check failed: {detail}")
    return process.stdout.strip()


def capture_source_bundle(repo_root: str | Path) -> dict[str, Any]:
    repo = Path(repo_root).resolve()
    paths = tuple((repo / relative).resolve() for relative in _SOURCE_PATHS)
    if any(not path.is_file() or not path.is_relative_to(repo) for path in paths):
        raise FileNotFoundError("common-evaluation source bundle is incomplete")
    status = _git(
        repo,
        "status",
        "--porcelain=v1",
        "--untracked-files=all",
        "--",
        *_SOURCE_PATHS,
    )
    if status:
        raise RuntimeError(f"common-evaluation relevant source is dirty: {status}")
    head = _git(repo, "rev-parse", "HEAD")
    if len(head) != 40:
        raise RuntimeError("common-evaluation Git HEAD is malformed")
    return {
        "git_head": head,
        "files": {relative: sha256_file(repo / relative) for relative in _SOURCE_PATHS},
    }


def verify_source_bundle(
    repo_root: str | Path,
    expected: Mapping[str, Any],
) -> None:
    if capture_source_bundle(repo_root) != dict(expected):
        raise RuntimeError("common-evaluation source bundle drifted")


def _records(payload: Mapping[str, Any], protocol: str) -> list[dict[str, Any]]:
    protocol_payload = payload.get(protocol)
    if not isinstance(protocol_payload, Mapping):
        raise ValueError(f"EvalMLIP {protocol} payload is missing")
    rows = protocol_payload.get("records")
    if not isinstance(rows, Sequence) or isinstance(rows, (str, bytes)):
        raise ValueError(f"EvalMLIP {protocol} records are missing")
    normalized: list[dict[str, Any]] = []
    for row in rows:
        if not isinstance(row, Mapping):
            raise ValueError(f"EvalMLIP {protocol} record is malformed")
        normalized.append(dict(row))
    return normalized


def merge_evalmlip_payloads(
    frozen_payloads: Sequence[Mapping[str, Any]],
    external_payload: Mapping[str, Any],
) -> dict[str, Any]:
    payloads = (*tuple(frozen_payloads), external_payload)
    if len(payloads) < 2:
        raise ValueError("combined EvalMLIP requires frozen and external payloads")
    provenance = payloads[0].get("provenance")
    if not isinstance(provenance, Mapping):
        raise ValueError("EvalMLIP provenance is missing")
    for payload in payloads:
        if payload.get("provenance") != provenance:
            raise ValueError("EvalMLIP provenance drifted across reused and new cohorts")
        if payload.get("retry_count") != 0 or payload.get("refill_count") != 0:
            raise ValueError("EvalMLIP retry/refill drifted")

    protocols: dict[str, Any] = {}
    observed_ids: list[str] | None = None
    for protocol in ("fixed_cell_fire300", "cell_relax_fire300"):
        rows = [row for payload in payloads for row in _records(payload, protocol)]
        identities = [str(row.get("condition_id")) for row in rows]
        if len(identities) != len(set(identities)):
            raise ValueError("combined EvalMLIP contains duplicate identities")
        if observed_ids is None:
            observed_ids = identities
        elif identities != observed_ids:
            raise ValueError("combined EvalMLIP protocol identities drifted")
        protocols[protocol] = {
            "summary": summarize_protocol(rows),
            "records": rows,
        }

    assert observed_ids is not None
    return {
        "schema_version": "g1-full-crysalis-eval-mlip.1.0.0",
        "provenance": dict(provenance),
        "attempt_count": len(observed_ids),
        **protocols,
        "retry_count": 0,
        "refill_count": 0,
        "sealed_or_blind_data_accessed": False,
        "dft_used": False,
        "ablation_performed": False,
    }


def _write_json_new(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(f"common-evaluation output already exists: {path}")
    temporary = path.with_suffix(path.suffix + ".tmp")
    if temporary.exists():
        raise FileExistsError(f"common-evaluation temporary output exists: {temporary}")
    text = _canonical_json(payload) + "\n"
    try:
        with temporary.open("x", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        if path.exists():
            raise FileExistsError(f"common-evaluation output already exists: {path}")
        os.replace(temporary, path)
    except BaseException:
        if temporary.exists():
            temporary.unlink()
        raise


def _write_or_verify_json(path: Path, payload: object) -> None:
    if not path.exists():
        _write_json_new(path, payload)
        return
    observed = json.loads(path.read_text(encoding="utf-8"))
    if observed != payload:
        raise ValueError(f"immutable common-evaluation artifact drifted: {path}")


def _artifact_declaration(context: StageContext, path: Path) -> dict[str, str]:
    return {
        "path": path.resolve().relative_to(context.output_root.resolve()).as_posix(),
        "sha256": sha256_file(path),
    }


def _append_cell_relax_oom_failure(
    journal_path: str | Path,
    *,
    expected_ids: Sequence[str],
    condition_id: str,
    diagnostics: Mapping[str, Any],
) -> dict[str, Any]:
    """Preserve one deterministic cell-relax CUDA OOM without skipping work."""

    journal = Path(journal_path)
    if not journal.is_file():
        raise FileNotFoundError(f"cell-relax journal is missing: {journal}")
    registered = tuple(str(value) for value in expected_ids)
    if not registered or len(set(registered)) != len(registered):
        raise ValueError("registered EvalMLIP identities are invalid")
    rows = [json.loads(line) for line in journal.read_text(encoding="utf-8").splitlines()]
    completed_ids = tuple(str(row["condition_id"]) for row in rows)
    if completed_ids != registered[: len(completed_ids)]:
        raise ValueError("cell-relax journal is not a registered prefix")
    if len(completed_ids) >= len(registered) or registered[len(completed_ids)] != condition_id:
        raise ValueError("OOM identity is not the next registered attempt")

    failure = {
        "condition_id": condition_id,
        "status": "CHGNET_RELAXATION_FAILED",
        "failure_code": "CHGNET_CELL_RELAX_CUDA_OOM",
        "exception_type": "AcceleratorError",
        "exception_message": "CUDA error: out of memory",
        "converged": False,
        "post_relax_survival": False,
        "post_relax_detected_space_groups": {},
        "strict_symmetry_preserving_survival": False,
        "resource_failure_preserved": True,
        "retry_count": 0,
        "refill_count": 0,
        "diagnostics": dict(diagnostics),
    }
    line = json.dumps(
        failure,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    with journal.open("a", encoding="utf-8", buffering=1) as stream:
        stream.write(line + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    return failure


def _prior_stage_bindings(config: ExternalBenchmarkConfig) -> dict[str, Any]:
    bindings: dict[str, Any] = {}
    for stage in ("audit", "crystalformer", "crystalformer_k5_secondary", "other_baselines"):
        path = config.output_root / "engineering" / "receipts" / f"{stage}.json"
        if not path.is_file():
            raise FileNotFoundError(f"common-evaluation prior receipt is missing: {stage}")
        receipt = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(receipt, Mapping) or receipt.get("status") != "COMPLETE":
            raise ValueError(f"common-evaluation prior receipt is malformed: {stage}")
        outputs = receipt.get("output_sha256")
        if not isinstance(outputs, Mapping) or not outputs:
            raise ValueError(f"common-evaluation prior output hashes are missing: {stage}")
        bindings[stage] = {
            "receipt_path": str(path.resolve()),
            "receipt_sha256": sha256_file(path),
            "output_sha256": dict(outputs),
            "action_id": receipt.get("injected_action", {}).get("action_id"),
        }
    return bindings


def _invocation_manifest(
    context: StageContext,
    *,
    external_attempts: Sequence[AttemptRecord],
    evaluator_provenance: Mapping[str, Any],
    source_bundle: Mapping[str, Any],
) -> dict[str, Any]:
    serialized_attempts = [attempt.to_dict() for attempt in external_attempts]
    return {
        "schema_version": "g1-external-benchmark-common-invocation.1.0.0",
        "config_path": str(context.config.config_path.resolve()),
        "config_sha256": sha256_file(context.config.config_path),
        "external_attempt_count": len(external_attempts),
        "external_evaluation_ids": [
            attempt_evaluation_id(attempt) for attempt in external_attempts
        ],
        "external_attempt_records_sha256": hashlib.sha256(
            _canonical_json(serialized_attempts).encode("utf-8")
        ).hexdigest(),
        "prior_stage_bindings": _prior_stage_bindings(context.config),
        "evaluator_provenance": dict(evaluator_provenance),
        "source_bundle": dict(source_bundle),
        **_POLICY_FIELDS,
    }


def _validate_evalmlip_journals(
    output_dir: str | Path,
    payload: Mapping[str, Any],
) -> dict[str, Path]:
    output = Path(output_dir)
    paths = {
        "fixed_cell_fire300_journal": output / "fixed_cell_fire300_records.jsonl",
        "cell_relax_fire300_journal": output / "cell_relax_fire300_records.jsonl",
        "physics_results": output / "physics_results.json",
    }
    for protocol, key in (
        ("fixed_cell_fire300", "fixed_cell_fire300_journal"),
        ("cell_relax_fire300", "cell_relax_fire300_journal"),
    ):
        path = paths[key]
        if not path.is_file():
            raise FileNotFoundError(f"EvalMLIP journal is missing: {path}")
        rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]
        if rows != list(payload[protocol]["records"]):
            raise ValueError(f"EvalMLIP journal differs from typed summary: {protocol}")
    if not paths["physics_results"].is_file():
        raise ValueError("EvalMLIP physics summary drifted after typed validation")
    observed_summary = json.loads(paths["physics_results"].read_text(encoding="utf-8"))
    if _canonical_json(observed_summary) != _canonical_json(payload):
        raise ValueError("EvalMLIP physics summary drifted after typed validation")
    return paths


def run_or_resume_external_eval(
    attempts: Sequence[AttemptRecord],
    *,
    config: ExternalBenchmarkConfig,
    repo_root: str | Path,
    evaluator: Any,
    output_dir: str | Path,
) -> dict[str, Any]:
    """Resume only from a complete, typed EvalMLIP summary in the same journal directory."""

    frozen = tuple(attempts)
    output = Path(output_dir)
    summary_path = output / "physics_results.json"
    if not summary_path.is_file():
        return run_eval_mlip_cohort(
            frozen,
            config=config,
            repo_root=repo_root,
            evaluator=evaluator,
            output_dir=output,
        )
    payload = json.loads(summary_path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError("resumed EvalMLIP summary must be a JSON object")
    _validate_eval_payload(
        payload,
        frozen,
        expected_weight_sha256=config.frozen_artifact_sha256["chgnet_weights"],
    )
    return dict(payload)


def _common_payload(
    context: StageContext,
    *,
    expected_source_bundle: Mapping[str, Any],
) -> tuple[dict[str, Any], dict[str, Path]]:
    verify_source_bundle(context.repo_root, expected_source_bundle)
    preflight_frozen_inputs(context.config, context.repo_root)
    frozen = _load_frozen_crysalis_contract(context.config, context.repo_root)
    attempts_by_seed = frozen["attempts_by_seed"]
    evaluations_by_seed = frozen["evaluations_by_seed"]
    full_attempts = tuple(
        attempt for seed in context.config.training_seeds for attempt in attempts_by_seed[seed]
    )
    crystalformer = _load_prior_attempt_records(context.config, "crystalformer")
    other_baselines = _load_prior_attempt_records(context.config, "other_baselines")
    external_attempts = crystalformer + other_baselines
    all_attempts: tuple[AttemptRecord, ...] = full_attempts + external_attempts
    expected_registered_ids = _common_evaluation_attempt_ids(context.config)
    observed_registered_ids = tuple(
        _evaluation_attempt_id(
            attempt.model,
            attempt.training_seed,
            attempt.condition,
            attempt.sample_index,
        )
        for attempt in all_attempts
    )
    if observed_registered_ids != expected_registered_ids:
        raise ValueError("common-evaluation registered attempt order drifted")
    evaluation_ids = tuple(attempt_evaluation_id(attempt) for attempt in all_attempts)

    common_records = common_evaluate_attempts(all_attempts)
    evaluator = build_frozen_eval_mlip(context.config, repo_root=context.repo_root)
    evaluation_root = context.engineering_root / "stages" / "common_chgnet" / "evalmlip"
    invocation = _invocation_manifest(
        context,
        external_attempts=external_attempts,
        evaluator_provenance=evaluator.provenance,
        source_bundle=expected_source_bundle,
    )
    invocation_path = evaluation_root / "invocation_manifest.json"
    _write_or_verify_json(invocation_path, invocation)
    original_augment_symmetry = full_evaluation._augment_symmetry
    full_evaluation._augment_symmetry = _augment_symmetry_isolated
    try:
        external_eval = run_or_resume_external_eval(
            external_attempts,
            config=context.config,
            repo_root=context.repo_root,
            evaluator=evaluator,
            output_dir=evaluation_root,
        )
    finally:
        full_evaluation._augment_symmetry = original_augment_symmetry
    work_products = _validate_evalmlip_journals(evaluation_root, external_eval)
    combined = merge_evalmlip_payloads(
        tuple(evaluations_by_seed[seed] for seed in context.config.training_seeds),
        external_eval,
    )
    eligible = [
        attempt_evaluation_id(attempt)
        for attempt in all_attempts
        if attempt.status.value == "GENERATED"
    ]
    payload = {
        "schema_version": SCHEMA_VERSION,
        "attempt_count": len(all_attempts),
        "attempt_ids": list(evaluation_ids),
        "evalmlip_boundary": dict(_EVALMLIP_BOUNDARY),
        "full_crysalis": {
            "attempt_count": len(full_attempts),
            "training_seeds": list(context.config.training_seeds),
            "per_seed_attempt_count": {
                str(seed): len(attempts_by_seed[seed]) for seed in context.config.training_seeds
            },
            "reference_commit": context.config.reference_commit,
            "source_artifacts": frozen["source_artifacts"],
            "best_seed_selection_performed": False,
        },
        "common_records": list(common_records),
        "evalmlip": combined,
        "mattersim_eligible_attempt_ids": eligible,
        "source_bundle": dict(expected_source_bundle),
        **_POLICY_FIELDS,
    }
    verify_source_bundle(context.repo_root, expected_source_bundle)
    preflight_frozen_inputs(context.config, context.repo_root)
    return payload, {"invocation_manifest": invocation_path, **work_products}


def build_common_chgnet_action(
    *,
    config: ExternalBenchmarkConfig,
    repo_root: str | Path,
) -> StageAction:
    repo = Path(repo_root).resolve()
    preflight_frozen_inputs(config, repo)
    source_bundle = capture_source_bundle(repo)
    bundle_sha256 = hashlib.sha256(_canonical_json(source_bundle).encode("utf-8")).hexdigest()
    registered_ids = _common_evaluation_attempt_ids(config)

    def execute(context: StageContext) -> StageResult:
        if context.stage != "common_chgnet":
            raise ValueError("common CHGNet action received the wrong stage")
        payload, work_products = _common_payload(
            context,
            expected_source_bundle=source_bundle,
        )
        output = context.engineering_root / "stages" / "common_chgnet" / "common_chgnet.json"
        _write_or_verify_json(output, payload)
        work_product_declarations = {
            name: {
                "path": path.resolve().relative_to(context.output_root.resolve()).as_posix(),
                "sha256": sha256_file(path),
            }
            for name, path in work_products.items()
        }
        evidence = {
            "stage_status": "COMPLETE",
            "primary_evaluator": "CHGNET_FIXED_AND_CELL_RELAX_FIRE300",
            "all_attempt_denominators": True,
            "common_evaluation": _artifact_declaration(context, output),
            "mattersim_eligible_attempt_ids": payload["mattersim_eligible_attempt_ids"],
            "source_bundle": dict(source_bundle),
            "source_bundle_sha256": bundle_sha256,
            "evalmlip_work_products": work_product_declarations,
            **_POLICY_FIELDS,
        }
        return StageResult(
            outputs=(output, *work_products.values()),
            evidence=evidence,
        )

    action_id = (
        f"common-chgnet:git-{source_bundle['git_head']}:bundle-{bundle_sha256}:"
        f"attempts-{len(registered_ids)}"
    )
    return StageAction(
        action_id=action_id,
        execute=execute,
        registered_attempt_ids=registered_ids,
    )


def build_stage_actions(
    *,
    config: ExternalBenchmarkConfig,
    repo_root: str | Path,
) -> dict[str, StageAction]:
    return {
        "common_chgnet": build_common_chgnet_action(
            config=config,
            repo_root=repo_root,
        )
    }
