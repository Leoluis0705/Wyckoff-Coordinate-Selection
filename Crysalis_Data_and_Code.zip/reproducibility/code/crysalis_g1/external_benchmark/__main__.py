from __future__ import annotations

import argparse
import importlib
import json
from pathlib import Path
from typing import Mapping, Sequence

from crysalis_g1.external_benchmark.config import load_config
from crysalis_g1.external_benchmark.runner import (
    FORMAL_STAGE_ORDER,
    StageAction,
    run_all,
    run_stage,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run frozen Full Crysalis external-benchmark stages."
    )
    parser.add_argument("--config", required=True)
    parser.add_argument(
        "--stage",
        required=True,
        choices=(*FORMAL_STAGE_ORDER, "all"),
    )
    parser.add_argument(
        "--actions-module",
        help=(
            "Importable module exposing build_stage_actions(config=..., "
            "repo_root=...) for explicit injected scientific callables."
        ),
    )
    return parser


def _load_stage_actions(
    module_name: str,
    *,
    config,
    repo_root: Path,
) -> Mapping[str, StageAction]:
    module = importlib.import_module(module_name)
    factory = getattr(module, "build_stage_actions", None)
    if not callable(factory):
        raise TypeError(
            "actions module must expose callable build_stage_actions(config=..., repo_root=...)"
        )
    actions = factory(config=config, repo_root=repo_root)
    if not isinstance(actions, Mapping):
        raise TypeError("build_stage_actions must return a stage-to-StageAction mapping")
    return actions


def main(
    argv: Sequence[str] | None = None,
    *,
    actions: Mapping[str, StageAction] | None = None,
    repo_root: str | Path | None = None,
) -> int:
    arguments = build_parser().parse_args(argv)
    config = load_config(arguments.config)
    repo = Path(__file__).resolve().parents[2] if repo_root is None else Path(repo_root).resolve()
    if actions is not None and arguments.actions_module is not None:
        raise ValueError("actions may be supplied either directly or by module, not both")
    selected_actions: Mapping[str, StageAction]
    if actions is not None:
        selected_actions = actions
    elif arguments.actions_module is not None:
        selected_actions = _load_stage_actions(
            arguments.actions_module,
            config=config,
            repo_root=repo,
        )
    else:
        selected_actions = {}
    if arguments.stage == "all":
        result = run_all(
            config,
            repo_root=repo,
            actions=selected_actions,
        )
    else:
        result = run_stage(
            config,
            stage=arguments.stage,
            repo_root=repo,
            actions=selected_actions,
        )
    print(json.dumps(result, allow_nan=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
