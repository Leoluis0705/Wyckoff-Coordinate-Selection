from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
import platform
import subprocess
import sys
import tempfile
import time
from collections import Counter
from dataclasses import dataclass
from datetime import UTC, datetime
from importlib.metadata import version
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence


CRYSTALFORMER_COMMIT = "31bb734a3fd006af49a021921839061e6184cbf1"
CRYSTALFORMER_CHECKPOINT_SHA256 = "df1e7051df836d26f45a93fd7f21069a183777317f318001b55f8df20805d177"
CONDITION_SCHEMA = "g1-c0-symmetry-condition-manifest.1.0.0"
ROW_SCHEMA = "g1-crystalformer-official-driver-row.1.0.0"
RECEIPT_SCHEMA = "g1-crystalformer-official-driver-receipt.1.1.0"
EXPECTED_CONDITION_COUNT = 300
EXPECTED_SPACE_GROUPS = frozenset({225, 139, 12, 63, 189, 194, 123, 164})
REGISTERED_SHARDS = frozenset({(0, 1), (1, 4)})
PARENT_FREE_FLAGS = (
    "material_id_lookup_present",
    "parent_coordinates_present",
    "parent_lattice_present",
    "true_orbit_count_present",
    "true_termination_step_present",
    "true_wyckoff_sequence_present",
)
_CONDITION_KEYS = {
    "condition_id",
    "attempt_index",
    "root_seed",
    "condition_seed",
    "composition",
    "space_group",
}
_MANIFEST_KEYS = {
    "attempt_count",
    "root_seed",
    "schema_version",
    "conditions",
    *PARENT_FREE_FLAGS,
}


@dataclass(frozen=True, slots=True)
class CrystalFormerAPI:
    make_transformer: Callable[..., tuple[Any, Any]]
    load_checkpoint: Callable[[str], Mapping[str, Any]]
    make_sample_crystal: Callable[..., Callable[..., tuple[Any, ...]]]
    formula_string_to_composition_vector: Callable[[str], Any]
    get_struct_from_lawx: Callable[[Any, Any, Any, Any, Any], Mapping[str, Any]]
    normalize_structure: Callable[[Mapping[str, Any]], Mapping[str, Any]]
    prng_key: Callable[[int], Any]
    split_key: Callable[[Any], Sequence[Any]]
    to_python: Callable[[Any], Any]
    element_symbols: Mapping[int, str]
    backend: str
    versions: Mapping[str, str]


class _DriverAbort(Exception):
    def __init__(self, code: str, error: BaseException):
        super().__init__(str(error))
        self.code = code
        self.error = error


def _sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _json_bytes(payload: object) -> bytes:
    return (
        json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n"
    ).encode("utf-8")


def _atomic_write_json_new(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(f"immutable receipt already exists: {path}")
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb", dir=path.parent, prefix=f".{path.name}.", delete=False
        ) as handle:
            temporary = Path(handle.name)
            handle.write(_json_bytes(payload))
            handle.flush()
            os.fsync(handle.fileno())
        os.link(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _append_jsonl_row(path: Path, payload: object) -> None:
    data = _json_bytes(payload)
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)
    try:
        written = os.write(descriptor, data)
        if written != len(data):
            raise OSError("short atomic JSONL write")
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _git_output(checkout: Path, arguments: tuple[str, ...]) -> str:
    completed = subprocess.run(
        ["git", *arguments],
        cwd=checkout,
        check=True,
        shell=False,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def _condition_seed(root_seed: int, attempt_index: int) -> int:
    return int.from_bytes(
        hashlib.sha256(f"condition-seed:{root_seed}:{attempt_index}".encode()).digest()[:8],
        "big",
    ) % (2**31 - 1)


def _condition_id(condition: Mapping[str, Any]) -> str:
    public = {
        key: condition[key]
        for key in (
            "attempt_index",
            "root_seed",
            "condition_seed",
            "composition",
            "space_group",
        )
    }
    return (
        "condition-"
        + hashlib.sha256(
            json.dumps(public, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()
    )


def _load_conditions(path: Path, expected_sha256: str) -> tuple[dict[str, Any], ...]:
    if _sha256_file(path) != expected_sha256:
        raise ValueError("condition manifest hash mismatch")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping) or set(payload) != _MANIFEST_KEYS:
        raise ValueError("condition manifest schema or keys drifted")
    if payload["schema_version"] != CONDITION_SCHEMA:
        raise ValueError("condition manifest schema or keys drifted")
    if payload["root_seed"] != 20260823:
        raise ValueError("condition manifest root seed drifted")
    if payload["attempt_count"] != EXPECTED_CONDITION_COUNT:
        raise ValueError("driver requires 300 unique ordered conditions")
    if any(payload[flag] is not False for flag in PARENT_FREE_FLAGS):
        raise ValueError("driver condition manifest is not parent-free")
    raw = payload["conditions"]
    if not isinstance(raw, list) or len(raw) != EXPECTED_CONDITION_COUNT:
        raise ValueError("driver requires 300 unique ordered conditions")
    conditions: list[dict[str, Any]] = []
    identities: set[str] = set()
    observed_space_groups: set[int] = set()
    for expected_index, value in enumerate(raw):
        if not isinstance(value, Mapping) or set(value) != _CONDITION_KEYS:
            raise ValueError("condition schema drifted")
        condition = dict(value)
        if condition["attempt_index"] != expected_index:
            raise ValueError("driver requires 300 unique ordered conditions")
        if condition["root_seed"] != payload["root_seed"]:
            raise ValueError("condition root seed drifted")
        if condition["condition_seed"] != _condition_seed(condition["root_seed"], expected_index):
            raise ValueError("registered condition seed drifted")
        if condition["condition_id"] != _condition_id(condition):
            raise ValueError("registered condition identity drifted")
        if condition["condition_id"] in identities:
            raise ValueError("driver requires 300 unique ordered conditions")
        composition = condition["composition"]
        if (
            not isinstance(composition, list)
            or not composition
            or any(
                not isinstance(pair, list)
                or len(pair) != 2
                or type(pair[0]) is not int
                or type(pair[1]) is not int
                or pair[0] < 1
                or pair[0] > 118
                or pair[1] < 1
                for pair in composition
            )
        ):
            raise ValueError("condition composition drifted")
        if composition != sorted(composition) or len({pair[0] for pair in composition}) != len(
            composition
        ):
            raise ValueError("condition composition ordering or identity drifted")
        space_group = condition["space_group"]
        if type(space_group) is not int or not 1 <= space_group <= 230:
            raise ValueError("condition space group drifted")
        identities.add(condition["condition_id"])
        observed_space_groups.add(space_group)
        conditions.append(condition)
    if observed_space_groups != EXPECTED_SPACE_GROUPS:
        raise ValueError("frozen eight-space-group set drifted")
    return tuple(conditions)


def _formula(condition: Mapping[str, Any], symbols: Mapping[int, str]) -> str:
    parts: list[str] = []
    for atomic_number, count in condition["composition"]:
        try:
            symbol = symbols[int(atomic_number)]
        except KeyError:
            raise ValueError(f"official element table lacks Z={atomic_number}") from None
        parts.append(symbol if count == 1 else f"{symbol}{count}")
    return "".join(parts)


def _registered_sample_seed(condition_seed: int, sample_index: int) -> int:
    if sample_index == 0:
        return condition_seed
    return int.from_bytes(
        hashlib.sha256(
            f"external-benchmark-sample-seed:{condition_seed}:{sample_index}".encode()
        ).digest()[:8],
        "big",
    ) % (2**31 - 1)


def _validate_shard(sample_index_start: int, sample_count: int) -> tuple[int, int]:
    if (
        type(sample_index_start) is not int
        or type(sample_count) is not int
        or (sample_index_start, sample_count) not in REGISTERED_SHARDS
    ):
        raise ValueError(
            "registered CrystalFormer shard must be primary (start=0,count=1) "
            "or secondary (start=1,count=4)"
        )
    return sample_index_start, sample_count


def _first_batch(value: Any, *, label: str) -> Any:
    if not isinstance(value, list) or len(value) != 1:
        raise ValueError(f"CrystalFormer {label} must have batch size one")
    return value[0]


def _assert_finite(value: Any) -> None:
    if isinstance(value, Mapping):
        for item in value.values():
            _assert_finite(item)
    elif isinstance(value, (list, tuple)):
        for item in value:
            _assert_finite(item)
    elif type(value) is float and not math.isfinite(value):
        raise FloatingPointError("NaN/non-finite CrystalFormer output corruption")


def _normalize_structure(payload: Mapping[str, Any]) -> dict[str, Any]:
    expected = {"lattice", "atomic_numbers", "fractional_coordinates"}
    if not isinstance(payload, Mapping) or set(payload) != expected:
        raise ValueError("normalized CrystalFormer structure keys drifted")
    lattice = payload["lattice"]
    atomic_numbers = payload["atomic_numbers"]
    coordinates = payload["fractional_coordinates"]
    if (
        not isinstance(lattice, Sequence)
        or len(lattice) != 3
        or any(not isinstance(row, Sequence) or len(row) != 3 for row in lattice)
    ):
        raise ValueError("normalized CrystalFormer lattice is malformed")
    if (
        not isinstance(atomic_numbers, Sequence)
        or not atomic_numbers
        or not isinstance(coordinates, Sequence)
        or len(atomic_numbers) != len(coordinates)
        or any(not isinstance(row, Sequence) or len(row) != 3 for row in coordinates)
    ):
        raise ValueError("normalized CrystalFormer sites are malformed")
    normalized = {
        "lattice": [[float(item) for item in row] for row in lattice],
        "atomic_numbers": [int(item) for item in atomic_numbers],
        "fractional_coordinates": [[float(item) for item in row] for row in coordinates],
    }
    _assert_finite(normalized)
    return normalized


def _composition_flags(
    condition: Mapping[str, Any], structure: Mapping[str, Any]
) -> tuple[bool, bool]:
    requested = Counter({int(z): int(count) for z, count in condition["composition"]})
    observed = Counter(int(z) for z in structure["atomic_numbers"])
    requested_gcd = math.gcd(*requested.values())
    observed_gcd = math.gcd(*observed.values())
    requested_reduced = {
        atomic_number: count // requested_gcd for atomic_number, count in requested.items()
    }
    observed_reduced = {
        atomic_number: count // observed_gcd for atomic_number, count in observed.items()
    }
    return requested_reduced == observed_reduced, requested == observed


def _fatal_code(error: BaseException) -> str | None:
    if isinstance(error, MemoryError):
        return "UNRECOVERABLE_OOM"
    message = f"{type(error).__name__}: {error}".lower()
    if "out of memory" in message or "resource_exhausted" in message:
        return "UNRECOVERABLE_OOM"
    if isinstance(error, FloatingPointError) or "nan corruption" in message:
        return "UNRECOVERABLE_NAN"
    return None


def _receipt_payload(
    *,
    status: str,
    started_at: str,
    ended_at: str,
    manifest_path: Path,
    manifest_sha256: str,
    checkout: Path,
    checkpoint: Path,
    output_path: Path,
    api: CrystalFormerAPI,
    sample_index_start: int,
    sample_count: int,
    attempted_count: int,
    generated_count: int,
    failed_count: int,
    sampler_count: int,
    abort_code: str | None,
) -> dict[str, Any]:
    return {
        "schema_version": RECEIPT_SCHEMA,
        "status": status,
        "model": "CrystalFormer",
        "official_checkout": str(checkout),
        "official_commit": CRYSTALFORMER_COMMIT,
        "checkpoint_path": str(checkpoint),
        "checkpoint_sha256": CRYSTALFORMER_CHECKPOINT_SHA256,
        "condition_manifest_path": str(manifest_path),
        "condition_manifest_sha256": manifest_sha256,
        "expected_condition_count": EXPECTED_CONDITION_COUNT,
        "sample_index_start": sample_index_start,
        "sample_count": sample_count,
        "attempt_count": attempted_count,
        "generated_count": generated_count,
        "failed_count": failed_count,
        "denominator_complete": attempted_count == EXPECTED_CONDITION_COUNT * sample_count,
        "retry_count": 0,
        "refill_count": 0,
        "checkpoint_load_count": 1,
        "sampler_cache_count": sampler_count,
        "observed_space_groups": sorted(EXPECTED_SPACE_GROUPS),
        "temperature": 1.0,
        "top_p": 1.0,
        "batch_size": 1,
        "samples_per_condition": sample_count,
        "output_jsonl_path": str(output_path),
        "output_jsonl_sha256": (_sha256_file(output_path) if output_path.is_file() else None),
        "started_at": started_at,
        "ended_at": ended_at,
        "abort_code": abort_code,
        "environment": {
            "python": platform.python_version(),
            "backend": api.backend,
            **dict(api.versions),
            "compatibility": {
                "jax_jaxlib": "0.9.0",
                "reason": "official jnp.clip(a_min=...) compatibility",
                "source_or_weight_modification": False,
            },
        },
    }


def _load_official_api(checkout: Path) -> CrystalFormerAPI:
    sys.path.insert(0, str(checkout))
    sys.path.insert(0, str(checkout / "crystalformer" / "src"))
    import haiku
    import jax
    import jaxlib
    import numpy as np
    import optax
    from crystalformer.src import checkpoint
    from crystalformer.src.elements import element_list
    from crystalformer.src.formula import formula_string_to_composition_vector
    from crystalformer.src.sample import make_sample_crystal
    from crystalformer.src.transformer import make_transformer
    from pymatgen.core import Structure

    conversion_path = checkout / "scripts" / "awl2struct.py"
    specification = importlib.util.spec_from_file_location(
        "crystalformer_official_awl2struct", conversion_path
    )
    if specification is None or specification.loader is None:
        raise ImportError(f"cannot load official conversion module: {conversion_path}")
    conversion_module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(conversion_module)

    def normalize_structure(structure_dict: Mapping[str, Any]) -> Mapping[str, Any]:
        structure = Structure.from_dict(structure_dict)
        return {
            "lattice": np.asarray(structure.lattice.matrix).tolist(),
            "atomic_numbers": [int(site.specie.Z) for site in structure],
            "fractional_coordinates": np.asarray(structure.frac_coords).tolist(),
        }

    def expand_official_structure(G, L, A, W, X):
        return conversion_module.get_struct_from_lawx(
            int(G), np.asarray(L), np.asarray(A), np.asarray(W), np.asarray(X)
        )

    return CrystalFormerAPI(
        make_transformer=make_transformer,
        load_checkpoint=checkpoint.load_data,
        make_sample_crystal=make_sample_crystal,
        formula_string_to_composition_vector=formula_string_to_composition_vector,
        get_struct_from_lawx=expand_official_structure,
        normalize_structure=normalize_structure,
        prng_key=jax.random.PRNGKey,
        split_key=jax.random.split,
        to_python=lambda value: np.asarray(value).tolist(),
        element_symbols={index: symbol for index, symbol in enumerate(element_list)},
        backend=jax.default_backend(),
        versions={
            "jax": jax.__version__,
            "jaxlib": jaxlib.__version__,
            "dm-haiku": haiku.__version__,
            "optax": optax.__version__,
            "pyxtal": version("pyxtal"),
            "pymatgen": version("pymatgen"),
        },
    )


def run_driver(
    *,
    condition_manifest_path: str | Path,
    expected_condition_sha256: str,
    sample_index_start: int,
    sample_count: int,
    official_checkout: str | Path,
    checkpoint_path: str | Path,
    output_jsonl_path: str | Path,
    receipt_path: str | Path,
) -> dict[str, Any]:
    sample_index_start, sample_count = _validate_shard(sample_index_start, sample_count)
    manifest = Path(condition_manifest_path).resolve()
    checkout = Path(official_checkout).resolve()
    checkpoint = Path(checkpoint_path).resolve()
    output = Path(output_jsonl_path).resolve()
    receipt_target = Path(receipt_path).resolve()
    if output.exists():
        raise FileExistsError(f"output JSONL already exists: {output}")
    if receipt_target.exists():
        raise FileExistsError(f"immutable receipt already exists: {receipt_target}")
    if not checkout.is_dir():
        raise FileNotFoundError(f"official checkout is missing: {checkout}")
    if not checkpoint.is_file():
        raise FileNotFoundError(f"official checkpoint is missing: {checkpoint}")
    conditions = _load_conditions(manifest, expected_condition_sha256)
    if _git_output(checkout, ("rev-parse", "HEAD")) != CRYSTALFORMER_COMMIT:
        raise ValueError("official CrystalFormer commit mismatch")
    if _git_output(checkout, ("status", "--porcelain")):
        raise ValueError("official CrystalFormer checkout is dirty")
    if _sha256_file(checkpoint) != CRYSTALFORMER_CHECKPOINT_SHA256:
        raise ValueError("official CrystalFormer checkpoint hash mismatch")
    official = _load_official_api(checkout)
    if platform.python_version() != "3.11.9":
        raise ValueError("official CrystalFormer driver requires Python 3.11.9")
    if official.backend != "cpu":
        raise ValueError("official CrystalFormer Windows driver requires CPU backend")
    if official.versions.get("jax") != "0.9.0" or official.versions.get("jaxlib") != "0.9.0":
        raise ValueError("official CrystalFormer driver requires JAX/JAXlib 0.9.0")
    if official.versions.get("dm-haiku") != "0.0.15":
        raise ValueError("official CrystalFormer driver requires dm-haiku 0.0.15")
    if official.versions.get("optax") != "0.2.6":
        raise ValueError("official CrystalFormer driver requires optax 0.2.6")
    if official.versions.get("pyxtal") != "1.1.1":
        raise ValueError("official CrystalFormer driver requires pyxtal 1.1.1")

    started_at = datetime.now(UTC).isoformat()
    output.parent.mkdir(parents=True, exist_ok=True)
    initial_key = official.prng_key(42)
    initial_params, transformer = official.make_transformer(
        initial_key,
        5,
        16,
        4,
        21,
        256,
        16,
        8,
        32,
        256,
        256,
        119,
        28,
        0.1,
        0.1,
    )
    del initial_params
    checkpoint_payload = official.load_checkpoint(str(checkpoint))
    if not isinstance(checkpoint_payload, Mapping) or "params" not in checkpoint_payload:
        raise ValueError("official CrystalFormer checkpoint lacks params")
    params = checkpoint_payload["params"]
    sampler_cache: dict[int, Callable[..., tuple[Any, ...]]] = {}
    generated_count = 0
    failed_count = 0
    attempted_count = 0

    try:
        for condition in conditions:
            formula = _formula(condition, official.element_symbols)
            for sample_index in range(sample_index_start, sample_index_start + sample_count):
                started = time.perf_counter()
                raw: dict[str, Any] | None = None
                structure: dict[str, Any] | None = None
                reduced_formula_match: bool | None = None
                exact_cell_count_match: bool | None = None
                status = "FAILED"
                failure_code: str | None = None
                failure_message: str | None = None
                pending_abort: _DriverAbort | None = None
                registered_seed = _registered_sample_seed(
                    int(condition["condition_seed"]), sample_index
                )
                try:
                    composition = official.formula_string_to_composition_vector(formula)
                    space_group = int(condition["space_group"])
                    if space_group not in sampler_cache:
                        sampler_cache[space_group] = official.make_sample_crystal(
                            transformer,
                            21,
                            119,
                            28,
                            16,
                            4,
                            w_mask=None,
                            top_p=1.0,
                            temperature=1.0,
                            K=30,
                            g=space_group,
                            atom_mask=None,
                        )
                    key = official.prng_key(registered_seed)
                    split = tuple(official.split_key(key))
                    if len(split) != 2:
                        raise ValueError("official JAX key split did not return two keys")
                    arrays = sampler_cache[space_group](split[1], params, 1, composition)
                    if len(arrays) != 6:
                        raise ValueError("official CrystalFormer sampler output arity drifted")
                    G, X, A, W, M, L = (official.to_python(value) for value in arrays)
                    raw = {
                        "G": _first_batch(G, label="G"),
                        "L": _first_batch(L, label="L"),
                        "X": _first_batch(X, label="X"),
                        "A": _first_batch(A, label="A"),
                        "W": _first_batch(W, label="W"),
                        "M": _first_batch(M, label="M"),
                    }
                    _assert_finite(raw)
                    if int(raw["G"]) != space_group:
                        failure_code = "CRYSTALFORMER_SPACE_GROUP_MISMATCH"
                        failure_message = f"requested SG {space_group}, generated raw SG {raw['G']}"
                    else:
                        official_structure = official.get_struct_from_lawx(
                            raw["G"], raw["L"], raw["A"], raw["W"], raw["X"]
                        )
                        structure = _normalize_structure(
                            official.normalize_structure(official_structure)
                        )
                        reduced_formula_match, exact_cell_count_match = _composition_flags(
                            condition, structure
                        )
                        status = "GENERATED"
                except Exception as error:
                    fatal_code = _fatal_code(error)
                    if fatal_code is not None:
                        raw = None
                        failure_code = fatal_code
                        failure_message = f"{type(error).__name__}: {error}"
                        pending_abort = _DriverAbort(fatal_code, error)
                    else:
                        failure_code = "CRYSTALFORMER_SAMPLE_FAILED"
                        failure_message = f"{type(error).__name__}: {error}"
                    structure = None
                    reduced_formula_match = None
                    exact_cell_count_match = None
                latency = time.perf_counter() - started
                if status == "GENERATED":
                    generated_count += 1
                else:
                    failed_count += 1
                row = {
                    "schema_version": ROW_SCHEMA,
                    "condition_id": condition["condition_id"],
                    "attempt_index": condition["attempt_index"],
                    "sample_index": sample_index,
                    "registered_seed": registered_seed,
                    "formula": formula,
                    "target_space_group": condition["space_group"],
                    "status": status,
                    "failure_code": failure_code,
                    "failure_message": failure_message,
                    "raw": raw,
                    "structure": structure,
                    "reduced_formula_match": reduced_formula_match,
                    "exact_cell_count_match": exact_cell_count_match,
                    "generation_latency_seconds": latency,
                    "retry_count": 0,
                    "refill_count": 0,
                }
                _append_jsonl_row(output, row)
                attempted_count += 1
                if pending_abort is not None:
                    raise pending_abort
    except _DriverAbort as abort:
        receipt = _receipt_payload(
            status="ABORTED",
            started_at=started_at,
            ended_at=datetime.now(UTC).isoformat(),
            manifest_path=manifest,
            manifest_sha256=expected_condition_sha256,
            checkout=checkout,
            checkpoint=checkpoint,
            output_path=output,
            api=official,
            sample_index_start=sample_index_start,
            sample_count=sample_count,
            attempted_count=attempted_count,
            generated_count=generated_count,
            failed_count=failed_count,
            sampler_count=len(sampler_cache),
            abort_code=abort.code,
        )
        _atomic_write_json_new(receipt_target, receipt)
        raise abort.error

    receipt = _receipt_payload(
        status="COMPLETE",
        started_at=started_at,
        ended_at=datetime.now(UTC).isoformat(),
        manifest_path=manifest,
        manifest_sha256=expected_condition_sha256,
        checkout=checkout,
        checkpoint=checkpoint,
        output_path=output,
        api=official,
        sample_index_start=sample_index_start,
        sample_count=sample_count,
        attempted_count=attempted_count,
        generated_count=generated_count,
        failed_count=failed_count,
        sampler_count=len(sampler_cache),
        abort_code=None,
    )
    _atomic_write_json_new(receipt_target, receipt)
    return receipt


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Pinned official CrystalFormer registered-shard benchmark driver"
    )
    parser.add_argument("--condition-manifest", required=True)
    parser.add_argument("--condition-manifest-sha256", required=True)
    parser.add_argument("--sample-index-start", required=True, type=int)
    parser.add_argument("--sample-count", required=True, type=int)
    parser.add_argument("--official-checkout", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--output-jsonl", required=True)
    parser.add_argument("--receipt", required=True)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    run_driver(
        condition_manifest_path=args.condition_manifest,
        expected_condition_sha256=args.condition_manifest_sha256,
        sample_index_start=args.sample_index_start,
        sample_count=args.sample_count,
        official_checkout=args.official_checkout,
        checkpoint_path=args.checkpoint,
        output_jsonl_path=args.output_jsonl,
        receipt_path=args.receipt,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
