from __future__ import annotations

import argparse
import json
import math
import time
from collections import defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterator, Mapping, Sequence

import torch

from crysalis_g1.data.canonical import (
    CanonicalOrbitRecord,
    CanonicalParentRecord,
    SymmetrySignature,
)
from crysalis_g1.data.structural_operators import (
    CanonicalRelationRecord,
    RelationInterfaceGroup,
    RelationRegistry,
    StructuralAction,
    StructuralTrajectory,
    apply_structural_action,
    initial_deconstruction_state,
    replay_trajectory,
)
from crysalis_g1.experiments.c0_symmetry_evaluation import (
    load_c0_symmetry_checkpoint,
)
from crysalis_g1.experiments.c0_symmetry_reconstruction import RecoveredParent
from crysalis_g1.experiments.chgnet_terminal import (
    CHGNetEvaluationConfig,
    CHGNetTerminalEvaluator,
)

from crysalis_g1.experiments.contribution_analysis import (
    FROZEN_SPACE_GROUPS,
    MATCHED_BASELINES,
    choose_final_contribution_label,
    evaluate_orbit_graph_signal,
    hierarchical_training_seed_bootstrap,
    paired_condition_bootstrap,
    space_group_macro_comparison,
)
from crysalis_g1.experiments.contribution_lock_runner import (
    ContributionLockConfig,
    FrozenArtifact,
    RunnerDependencies,
    run_contribution_lock,
)
from crysalis_g1.experiments.contribution_rollout import generate_scored_attempts
from crysalis_g1.experiments.contribution_state_graph import (
    ActionDescription,
    ParentStateGraph,
    build_contribution_corpus,
    build_parent_state_graph,
)
from crysalis_g1.experiments.contribution_training import (
    ActionScorerCorpus,
    ActionScorerGroup,
    ActionScorerTrainingConfig,
    build_action_scorer_corpus,
    train_action_scorer,
    validate_formal_training_config,
)
from crysalis_g1.model.action_viability import ActionViabilityConfig


FORMAL_RESAMPLES = 10_000
FORMAL_BOOTSTRAP_SEED = 20260823
FORMAL_CONDITION_COUNT = 300


@dataclass(frozen=True, slots=True)
class FrozenBaselineRecords:
    uniform_generation: tuple[Mapping[str, object], ...]
    uniform_fixed_cell: tuple[Mapping[str, object], ...]
    single_path_generation: tuple[Mapping[str, object], ...]
    single_path_fixed_cell: tuple[Mapping[str, object], ...]
    empirical_generation: tuple[Mapping[str, object], ...]
    empirical_fixed_cell: tuple[Mapping[str, object], ...]


@dataclass(frozen=True, slots=True)
class PublicParentBundle:
    parent: CanonicalParentRecord
    registry: RelationRegistry
    recovered_parent: RecoveredParent
    trajectories: tuple[StructuralTrajectory, ...]
    split: str


def _read_json_object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected a JSON object: {path}")
    return payload


def load_runner_config(
    config_path: str | Path,
) -> tuple[ContributionLockConfig, dict[str, Any]]:
    """Resolve the checked-in formal configuration without loading model/data caches."""

    path = Path(config_path).resolve()
    raw = _read_json_object(path)
    raw_artifacts = raw.get("frozen_artifacts")
    if not isinstance(raw_artifacts, dict) or not raw_artifacts:
        raise ValueError("formal configuration requires frozen_artifacts")
    artifacts: dict[str, FrozenArtifact] = {}
    for label, value in raw_artifacts.items():
        if not isinstance(value, dict) or set(value) != {"path", "sha256"}:
            raise ValueError(f"invalid frozen artifact declaration: {label}")
        artifact_path = Path(str(value["path"])).expanduser()
        if not artifact_path.is_absolute():
            artifact_path = (path.parent / artifact_path).resolve()
        digest = str(value["sha256"]).lower()
        if len(digest) != 64 or any(
            character not in "0123456789abcdef" for character in digest
        ):
            raise ValueError(f"invalid frozen artifact SHA256: {label}")
        artifacts[str(label)] = FrozenArtifact(path=artifact_path, sha256=digest)

    attribution = _read_json_object(artifacts["attribution_manifest"].path)
    frozen_files = attribution.get("frozen_c0_implementation_file_sha256")
    if not isinstance(frozen_files, dict) or not frozen_files:
        raise ValueError("attribution manifest lacks frozen C0 implementation hashes")
    implementation_files = {
        str(relative): str(digest).lower()
        for relative, digest in frozen_files.items()
    }
    commit = str(raw.get("frozen_implementation_commit", ""))
    if commit != attribution.get("frozen_implementation_commit_sha"):
        raise ValueError("configured frozen C0 implementation commit drifted")
    contribution_commit = str(raw.get("contribution_implementation_commit", ""))
    raw_contribution_files = raw.get("contribution_implementation_files", {})
    if not isinstance(raw_contribution_files, dict):
        raise ValueError("contribution implementation files must be a mapping")
    contribution_files: dict[str, str] = {}
    for relative, raw_digest in raw_contribution_files.items():
        relative_path = str(relative)
        digest = str(raw_digest).lower()
        if (
            not relative_path
            or len(digest) != 64
            or any(character not in "0123456789abcdef" for character in digest)
        ):
            raise ValueError("invalid contribution implementation declaration")
        contribution_files[relative_path] = digest

    repository_root = Path(str(raw.get("repository_root", "..")))
    if not repository_root.is_absolute():
        repository_root = (path.parent / repository_root).resolve()
    cohort = raw.get("frozen_cohort")
    if not isinstance(cohort, dict):
        raise ValueError("formal configuration lacks frozen_cohort")
    config = ContributionLockConfig(
        repository_root=repository_root,
        output_root=Path(str(raw["output_root"])).resolve(),
        frozen_artifacts=artifacts,
        frozen_implementation_commit=commit,
        frozen_implementation_files=implementation_files,
        contribution_implementation_commit=contribution_commit,
        contribution_implementation_files=contribution_files,
        root_seed=int(raw["root_seed"]),
        conditional_extra_seeds=tuple(
            int(value) for value in raw["conditional_extra_seeds"]
        ),
        expected_parent_count=int(cohort["parent_count"]),
        expected_subset_node_count=int(cohort["subset_node_count"]),
        expected_minimum_orbit_count=int(cohort["minimum_orbit_count"]),
        expected_maximum_orbit_count=int(cohort["maximum_orbit_count"]),
    )
    return config, raw


def _canonical_parent_from_dict(payload: Mapping[str, object]) -> CanonicalParentRecord:
    return CanonicalParentRecord(
        material_id=str(payload["material_id"]),
        source_partition=str(payload["source_partition"]),
        source_prototype_family=str(payload["source_prototype_family"]),
        source_structure_hash=str(payload["source_structure_hash"]),
        canonical_structure_hash=str(payload["canonical_structure_hash"]),
        lattice=tuple(
            tuple(float(value) for value in row) for row in payload["lattice"]  # type: ignore[union-attr]
        ),
        atomic_numbers=tuple(int(value) for value in payload["atomic_numbers"]),  # type: ignore[union-attr]
        fractional_coordinates=tuple(
            tuple(float(value) for value in row)
            for row in payload["fractional_coordinates"]  # type: ignore[union-attr]
        ),
        canonical_to_source_site=tuple(
            int(value) for value in payload["canonical_to_source_site"]  # type: ignore[union-attr]
        ),
        source_space_group=int(payload["source_space_group"]),
        space_group=int(payload["space_group"]),
        symmetry_status=str(payload["symmetry_status"]),
        observations=tuple(
            SymmetrySignature(
                symprec=float(item["symprec"]),
                space_group=int(item["space_group"]),
                equivalent_atoms=tuple(int(value) for value in item["equivalent_atoms"]),
                wyckoff_letters=tuple(str(value) for value in item["wyckoff_letters"]),
            )
            for item in payload["observations"]  # type: ignore[union-attr]
        ),
        orbits=tuple(
            CanonicalOrbitRecord(
                orbit_id=str(item["orbit_id"]),
                canonical_site_indices=tuple(
                    int(value) for value in item["canonical_site_indices"]
                ),
                source_site_indices=tuple(
                    int(value) for value in item["source_site_indices"]
                ),
                atomic_number=int(item["atomic_number"]),
                multiplicity=int(item["multiplicity"]),
                wyckoff_letter=str(item["wyckoff_letter"]),
            )
            for item in payload["orbits"]  # type: ignore[union-attr]
        ),
        reduced_formula_key=tuple(
            (int(item[0]), int(item[1]))
            for item in payload["reduced_formula_key"]  # type: ignore[union-attr]
        ),
    )


def _relation_registry_from_dict(payload: Mapping[str, object]) -> RelationRegistry:
    return RelationRegistry(
        material_id=str(payload["material_id"]),
        canonical_structure_hash=str(payload["canonical_structure_hash"]),
        relations=tuple(
            CanonicalRelationRecord(
                relation_id=str(item["relation_id"]),
                source_site_index=int(item["source_site_index"]),
                target_site_index=int(item["target_site_index"]),
                source_orbit_id=str(item["source_orbit_id"]),
                target_orbit_id=str(item["target_orbit_id"]),
                image=tuple(int(value) for value in item["image"]),
                distance=float(item["distance"]),
            )
            for item in payload["relations"]  # type: ignore[union-attr]
        ),
        interface_groups=tuple(
            RelationInterfaceGroup(
                group_id=str(item["group_id"]),
                source_orbit_id=str(item["source_orbit_id"]),
                target_orbit_id=str(item["target_orbit_id"]),
                relation_ids=tuple(str(value) for value in item["relation_ids"]),
            )
            for item in payload["interface_groups"]  # type: ignore[union-attr]
        ),
    )


def _iter_jsonl_objects(path: Path) -> Iterator[dict[str, Any]]:
    with path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, start=1):
            if not line.strip():
                continue
            payload = json.loads(line)
            if not isinstance(payload, dict):
                raise ValueError(f"JSONL row {line_number} is not an object: {path}")
            yield payload


def load_public_parent_bundles(
    config: ContributionLockConfig,
) -> tuple[PublicParentBundle, ...]:
    """Load exactly the frozen public Structure-OOD cohort and no other parents."""

    split_rows = _iter_jsonl_objects(
        config.frozen_artifacts["structure_ood_manifest"].path
    )
    splits = {str(row["material_id"]): str(row["split"]) for row in split_rows}
    if len(splits) != config.expected_parent_count or set(splits.values()) - {
        "train_fit",
        "validation",
    }:
        raise ValueError("Structure-OOD public cohort is invalid")
    selected = set(splits)

    parents: dict[str, CanonicalParentRecord] = {}
    for payload in _iter_jsonl_objects(
        config.frozen_artifacts["canonical_parents"].path
    ):
        material_id = str(payload["material_id"])
        if material_id in selected:
            parents[material_id] = _canonical_parent_from_dict(payload)
    registries = {
        str(payload["material_id"]): _relation_registry_from_dict(payload)
        for payload in _iter_jsonl_objects(
            config.frozen_artifacts["canonical_relations"].path
        )
        if str(payload["material_id"]) in selected
    }
    recovered = {
        str(payload["material_id"]): RecoveredParent.from_dict(payload)
        for payload in _iter_jsonl_objects(
            config.frozen_artifacts["recovered_parents"].path
        )
        if str(payload["material_id"]) in selected
    }
    trajectories: dict[str, list[StructuralTrajectory]] = defaultdict(list)
    with config.frozen_artifacts["d_orbit_trajectories"].path.open(
        encoding="utf-8"
    ) as stream:
        for line in stream:
            if not line.strip():
                continue
            payload = json.loads(line)
            material_id = str(payload["parent_structure_id"])
            if material_id in selected:
                trajectories[material_id].append(
                    StructuralTrajectory.from_json(line)
                )

    key_sets = (set(parents), set(registries), set(recovered), set(trajectories))
    if any(keys != selected for keys in key_sets):
        raise ValueError("Phase2A/C0 parent identities are not exactly aligned")
    bundles = []
    for material_id in sorted(selected):
        parent_trajectories = tuple(
            sorted(trajectories[material_id], key=lambda item: item.path_index)
        )
        if len(parent_trajectories) != 4 or tuple(
            item.path_index for item in parent_trajectories
        ) != (0, 1, 2, 3):
            raise ValueError("each contribution parent requires four D_orbit paths")
        bundles.append(
            PublicParentBundle(
                parent=parents[material_id],
                registry=registries[material_id],
                recovered_parent=recovered[material_id],
                trajectories=parent_trajectories,
                split=splits[material_id],
            )
        )
    return tuple(bundles)


def _generation_ids(
    records: Sequence[Mapping[str, object]], *, label: str
) -> list[str]:
    if len(records) != FORMAL_CONDITION_COUNT:
        raise ValueError(f"{label} must contain exactly 300 generation records")
    result: list[str] = []
    for record in records:
        condition = record.get("condition")
        if not isinstance(condition, Mapping):
            raise ValueError(f"{label} record lacks a condition envelope")
        result.append(str(condition.get("condition_id", "")))
    if any(not value for value in result) or len(set(result)) != len(result):
        raise ValueError(f"{label} condition IDs must be non-empty and unique")
    return result


def _fixed_ids(
    records: Sequence[Mapping[str, object]], *, label: str
) -> list[str]:
    if len(records) != FORMAL_CONDITION_COUNT:
        raise ValueError(f"{label} must contain exactly 300 fixed-cell records")
    result = [str(record.get("condition_id", "")) for record in records]
    if any(not value for value in result) or len(set(result)) != len(result):
        raise ValueError(f"{label} condition IDs must be non-empty and unique")
    return result


def _legal_terminal(records: Sequence[Mapping[str, object]]) -> list[bool]:
    return [bool(record.get("legal_terminal_crystal")) for record in records]


def _short_contact_rejection(
    records: Sequence[Mapping[str, object]],
) -> list[bool]:
    return [
        "SHORT_CONTACT" in tuple(record.get("projector_rejection_reasons", ()))
        for record in records
    ]


def _physical_survival(records: Sequence[Mapping[str, object]]) -> list[bool]:
    return [
        bool(record.get("post_relax_survival"))
        and bool(record.get("space_group_match"))
        for record in records
    ]


def _space_groups(records: Sequence[Mapping[str, object]]) -> list[int]:
    result: list[int] = []
    for record in records:
        condition = record["condition"]
        if not isinstance(condition, Mapping):
            raise ValueError("generation condition envelope is malformed")
        result.append(int(condition["space_group"]))
    return result


def _comparison_map(
    *,
    graph_generation: Sequence[Mapping[str, object]],
    graph_fixed: Sequence[Mapping[str, object]],
    final_generation: Sequence[Mapping[str, object]],
    final_fixed: Sequence[Mapping[str, object]],
    baselines: FrozenBaselineRecords,
    endpoint: str,
) -> dict[str, dict[str, Any]]:
    graph_ids = _generation_ids(graph_generation, label="GRAPH_VIABILITY")
    if endpoint == "symmetry_valid_legal_terminal":
        graph_values = _legal_terminal(graph_generation)
        baseline_records = {
            "UNIFORM_LEGAL": baselines.uniform_generation,
            "FINAL_SET_MEMBERSHIP": tuple(final_generation),
        }
        value_function = _legal_terminal
        id_function = _generation_ids
    elif endpoint == "short_contact_rejection":
        graph_values = _short_contact_rejection(graph_generation)
        baseline_records = {
            "UNIFORM_LEGAL": baselines.uniform_generation,
            "FINAL_SET_MEMBERSHIP": tuple(final_generation),
        }
        value_function = _short_contact_rejection
        id_function = _generation_ids
    elif endpoint == "fixed_cell_symmetry_preserving_physical_survival":
        graph_values = _physical_survival(graph_fixed)
        graph_ids = _fixed_ids(graph_fixed, label="GRAPH_VIABILITY fixed cell")
        baseline_records = {
            "UNIFORM_LEGAL": baselines.uniform_fixed_cell,
            "FINAL_SET_MEMBERSHIP": tuple(final_fixed),
        }
        value_function = _physical_survival
        id_function = _fixed_ids
    else:
        raise ValueError(f"unregistered endpoint: {endpoint}")

    comparisons = {}
    for index, baseline in enumerate(MATCHED_BASELINES):
        records = baseline_records[baseline]
        comparisons[baseline] = paired_condition_bootstrap(
            graph_values,
            value_function(records),
            graph_condition_ids=graph_ids,
            baseline_condition_ids=id_function(records, label=baseline),
            baseline_name=baseline,
            resamples=FORMAL_RESAMPLES,
            seed=FORMAL_BOOTSTRAP_SEED + index,
            endpoint=endpoint,
        )
    return comparisons


def _macro_map(
    *,
    graph_generation: Sequence[Mapping[str, object]],
    final_generation: Sequence[Mapping[str, object]],
    baselines: FrozenBaselineRecords,
) -> dict[str, dict[str, Any]]:
    graph_ids = _generation_ids(graph_generation, label="GRAPH_VIABILITY")
    graph_values = _legal_terminal(graph_generation)
    groups = _space_groups(graph_generation)
    baseline_records = {
        "UNIFORM_LEGAL": baselines.uniform_generation,
        "FINAL_SET_MEMBERSHIP": tuple(final_generation),
    }
    return {
        baseline: space_group_macro_comparison(
            graph=graph_values,
            baseline=_legal_terminal(records),
            graph_condition_ids=graph_ids,
            baseline_condition_ids=_generation_ids(records, label=baseline),
            baseline_name=baseline,
            space_groups=groups,
            required_space_groups=FROZEN_SPACE_GROUPS,
        )
        for baseline, records in baseline_records.items()
    }


def _reference_rate(
    generation: Sequence[Mapping[str, object]],
    fixed_cell: Sequence[Mapping[str, object]],
) -> dict[str, Any]:
    generation_ids = _generation_ids(generation, label="frozen reference")
    fixed_ids = _fixed_ids(fixed_cell, label="frozen reference fixed cell")
    if set(generation_ids) != set(fixed_ids):
        raise ValueError("frozen reference generation/fixed-cell cohorts differ")
    legal = _legal_terminal(generation)
    survival = _physical_survival(fixed_cell)
    short = _short_contact_rejection(generation)
    return {
        "attempt_count": FORMAL_CONDITION_COUNT,
        "legal_terminal_count": sum(legal),
        "legal_terminal_rate": sum(legal) / FORMAL_CONDITION_COUNT,
        "fixed_cell_symmetry_preserving_survival_count": sum(survival),
        "fixed_cell_symmetry_preserving_survival_rate": (
            sum(survival) / FORMAL_CONDITION_COUNT
        ),
        "short_contact_rejection_count": sum(short),
        "short_contact_rejection_rate": sum(short) / FORMAL_CONDITION_COUNT,
    }


def _by_space_group_report(
    *,
    graph_generation: Sequence[Mapping[str, object]],
    graph_fixed: Sequence[Mapping[str, object]],
    final_generation: Sequence[Mapping[str, object]],
    final_fixed: Sequence[Mapping[str, object]],
    baselines: FrozenBaselineRecords,
    macro: Mapping[str, Mapping[str, object]],
) -> dict[str, object]:
    arm_records = {
        "SINGLE_PATH_IMITATION": (
            baselines.single_path_generation,
            baselines.single_path_fixed_cell,
        ),
        "UNIFORM_LEGAL": (
            baselines.uniform_generation,
            baselines.uniform_fixed_cell,
        ),
        "EMPIRICAL_FREQUENCY": (
            baselines.empirical_generation,
            baselines.empirical_fixed_cell,
        ),
        "FINAL_SET_MEMBERSHIP": (tuple(final_generation), tuple(final_fixed)),
        "GRAPH_VIABILITY": (tuple(graph_generation), tuple(graph_fixed)),
    }
    canonical_ids = _generation_ids(graph_generation, label="GRAPH_VIABILITY")
    space_group_by_id = dict(zip(canonical_ids, _space_groups(graph_generation), strict=True))
    indexed: dict[
        str,
        tuple[dict[str, Mapping[str, object]], dict[str, Mapping[str, object]]],
    ] = {}
    for arm, (generation, fixed) in arm_records.items():
        generation_ids = _generation_ids(generation, label=arm)
        fixed_ids = _fixed_ids(fixed, label=f"{arm} fixed cell")
        if set(generation_ids) != set(canonical_ids) or set(fixed_ids) != set(
            canonical_ids
        ):
            raise ValueError(f"{arm} does not use the frozen condition cohort")
        indexed[arm] = (
            dict(zip(generation_ids, generation, strict=True)),
            dict(zip(fixed_ids, fixed, strict=True)),
        )
    rows: dict[str, object] = {}
    for space_group in FROZEN_SPACE_GROUPS:
        condition_ids = [
            condition_id
            for condition_id in canonical_ids
            if space_group_by_id[condition_id] == space_group
        ]
        if not condition_ids:
            raise ValueError(f"frozen space group has no conditions: {space_group}")
        arms: dict[str, object] = {}
        for arm, (generation_by_id, fixed_by_id) in indexed.items():
            generated = [generation_by_id[condition_id] for condition_id in condition_ids]
            fixed_records = [fixed_by_id[condition_id] for condition_id in condition_ids]
            legal = _legal_terminal(generated)
            survival = _physical_survival(fixed_records)
            short = _short_contact_rejection(generated)
            arms[arm] = {
                "condition_count": len(condition_ids),
                "legal_terminal_count": sum(legal),
                "legal_terminal_rate": sum(legal) / len(condition_ids),
                "fixed_cell_symmetry_preserving_survival_count": sum(survival),
                "fixed_cell_symmetry_preserving_survival_rate": (
                    sum(survival) / len(condition_ids)
                ),
                "short_contact_rejection_count": sum(short),
                "short_contact_rejection_rate": sum(short) / len(condition_ids),
            }
        rows[str(space_group)] = {
            "condition_count": len(condition_ids),
            "arms": arms,
        }
    return {
        "schema_version": "g1-contribution-by-space-group.1.0.0",
        "space_group_count": len(FROZEN_SPACE_GROUPS),
        "required_space_groups": list(FROZEN_SPACE_GROUPS),
        "groups": rows,
        "endpoint1_macro_comparisons": dict(macro),
    }


def analyze_first_round(
    first_seed_run: Mapping[str, object],
    *,
    baselines: FrozenBaselineRecords,
) -> dict[str, Any]:
    generation = first_seed_run.get("generation")
    fixed = first_seed_run.get("fixed_cell_fire300")
    if not isinstance(generation, Mapping) or not isinstance(fixed, Mapping):
        raise ValueError("first-seed result lacks generation or fixed-cell records")
    graph_generation = tuple(generation["GRAPH_VIABILITY"])
    final_generation = tuple(generation["FINAL_SET_MEMBERSHIP"])
    graph_fixed = tuple(fixed["GRAPH_VIABILITY"])
    final_fixed = tuple(fixed["FINAL_SET_MEMBERSHIP"])

    endpoint1 = _comparison_map(
        graph_generation=graph_generation,
        graph_fixed=graph_fixed,
        final_generation=final_generation,
        final_fixed=final_fixed,
        baselines=baselines,
        endpoint="symmetry_valid_legal_terminal",
    )
    endpoint2 = _comparison_map(
        graph_generation=graph_generation,
        graph_fixed=graph_fixed,
        final_generation=final_generation,
        final_fixed=final_fixed,
        baselines=baselines,
        endpoint="fixed_cell_symmetry_preserving_physical_survival",
    )
    short_contact = _comparison_map(
        graph_generation=graph_generation,
        graph_fixed=graph_fixed,
        final_generation=final_generation,
        final_fixed=final_fixed,
        baselines=baselines,
        endpoint="short_contact_rejection",
    )
    macro = _macro_map(
        graph_generation=graph_generation,
        final_generation=final_generation,
        baselines=baselines,
    )
    signal = evaluate_orbit_graph_signal(
        endpoint1=endpoint1,
        endpoint2=endpoint2,
        short_contact=short_contact,
        space_group_macro=macro,
    )
    supported = signal["ORBIT_GRAPH_CONTRIBUTION_SIGNAL"] == "SUPPORTED"
    endpoint1_exceeds_both = bool(signal["endpoint1_dual_strict_ci_pass"])
    decision = choose_final_contribution_label(
        first_round_graph_exceeds_both=endpoint1_exceeds_both,
        orbit_graph_replicated=False,
        relation_gain_replicated=False,
        prior_art_distinct=True,
    )
    references = {
        "SINGLE_PATH_IMITATION": _reference_rate(
            baselines.single_path_generation, baselines.single_path_fixed_cell
        ),
        "UNIFORM_LEGAL": _reference_rate(
            baselines.uniform_generation, baselines.uniform_fixed_cell
        ),
        "EMPIRICAL_FREQUENCY": _reference_rate(
            baselines.empirical_generation, baselines.empirical_fixed_cell
        ),
        "FINAL_SET_MEMBERSHIP": _reference_rate(final_generation, final_fixed),
        "GRAPH_VIABILITY": _reference_rate(graph_generation, graph_fixed),
    }
    paired_statistics = {
        "schema_version": "g1-contribution-paired-statistics.1.0.0",
        "resamples": FORMAL_RESAMPLES,
        "endpoint1": endpoint1,
        "endpoint2": endpoint2,
        "short_contact": short_contact,
        "signal": signal,
        "frozen_reference_rates": references,
    }
    by_space_group = _by_space_group_report(
        graph_generation=graph_generation,
        graph_fixed=graph_fixed,
        final_generation=final_generation,
        final_fixed=final_fixed,
        baselines=baselines,
        macro=macro,
    )
    return {
        "single_seed_supported": supported,
        "decision": decision,
        "signal": signal,
        "paired_statistics": paired_statistics,
        "by_space_group": by_space_group,
        "frozen_reference_rates": references,
    }


def analyze_three_seed_replication(
    payload: Mapping[str, object],
    *,
    baselines: FrozenBaselineRecords,
) -> dict[str, Any]:
    raw_runs = payload.get("seed_runs")
    if not isinstance(raw_runs, Sequence):
        raise ValueError("replication payload lacks seed_runs")
    graph_by_seed: dict[int, list[bool]] = {}
    graph_ids_by_seed: dict[int, list[str]] = {}
    uniform_by_seed: dict[int, list[bool]] = {}
    uniform_ids_by_seed: dict[int, list[str]] = {}
    uniform_values = _legal_terminal(baselines.uniform_generation)
    uniform_ids = _generation_ids(
        baselines.uniform_generation, label="UNIFORM_LEGAL"
    )
    for run in raw_runs:
        if not isinstance(run, Mapping):
            raise ValueError("replication seed run must be a mapping")
        seed = int(run["seed"])
        generation = run.get("generation")
        if not isinstance(generation, Mapping):
            raise ValueError("replication seed run lacks generation records")
        records = tuple(generation["GRAPH_VIABILITY"])
        graph_by_seed[seed] = _legal_terminal(records)
        graph_ids_by_seed[seed] = _generation_ids(
            records, label=f"GRAPH_VIABILITY seed {seed}"
        )
        uniform_by_seed[seed] = list(uniform_values)
        uniform_ids_by_seed[seed] = list(uniform_ids)
    return hierarchical_training_seed_bootstrap(
        graph_by_seed,
        uniform_by_seed,
        graph_condition_ids_by_seed=graph_ids_by_seed,
        uniform_condition_ids_by_seed=uniform_ids_by_seed,
        resamples=FORMAL_RESAMPLES,
        seed=FORMAL_BOOTSTRAP_SEED,
    )


def _action_payload(action: ActionDescription) -> dict[str, object]:
    return asdict(action)


def _serialize_parent_graph(
    graph: ParentStateGraph,
    *,
    split: str,
    scorer_groups: ActionScorerCorpus,
) -> dict[str, object]:
    corpus = build_contribution_corpus(
        (graph,), structure_ood_splits={graph.record.material_id: split}
    )
    labels_by_hash = {label.state_hash: label for label in corpus.labels}
    if len(labels_by_hash) != len(graph.nodes):
        raise RuntimeError("state graph label coverage is incomplete")
    nodes = []
    labels = []
    path_count_passed = True
    orbit_count = len(graph.record.orbits)
    for node in graph.nodes:
        present = [
            {
                "canonical_orbit_identity": orbit.orbit_instance_id,
                "wyckoff_position": orbit.wyckoff_letter,
                "multiplicity": orbit.multiplicity,
                "species": orbit.atomic_number,
            }
            for orbit in node.c0_state.present_orbits
        ]
        expected_paths = math.factorial(orbit_count - node.depth)
        path_count_passed &= (
            node.number_of_future_completion_paths == expected_paths
            and node.minimum_remaining_steps == orbit_count - node.depth
        )
        nodes.append(
            {
                "valid_crystallographic_state_hash": node.state_hash,
                "c0_state_hash": node.c0_state.state_hash,
                "target_space_group": node.c0_state.target_space_group,
                "remaining_composition": node.c0_state.remaining_composition,
                "present_canonical_orbit_identities": [
                    item["canonical_orbit_identity"] for item in present
                ],
                "present_orbits": present,
                "lattice_contract": asdict(node.c0_state.frozen_lattice),
                "legal_action_set": [
                    _action_payload(action) for action in node.legal_action_set
                ],
                "number_of_future_completion_paths": (
                    node.number_of_future_completion_paths
                ),
                "minimum_remaining_steps": node.minimum_remaining_steps,
                "compiler_state_verified": node.compiler_state_verified,
                "projector_verified": node.projector_verified,
                "termination_verified": node.termination_verified,
            }
        )
        label = labels_by_hash[node.state_hash]
        action_counts = []
        for action in node.legal_action_set:
            action_counts.append(
                {
                    "action": _action_payload(action),
                    "future_path_count": label.future_path_count_by_action[action],
                    "log1p_future_path_count": (
                        label.log1p_future_path_count_by_action[action]
                    ),
                    "positive_successor_orbit_ids": (
                        label.positive_successor_orbit_ids.get(action, ())
                    ),
                    "successor_path_counts": label.successor_path_counts.get(
                        action, {}
                    ),
                }
            )
        labels.append(
            {
                "state_hash": label.state_hash,
                "split": label.split,
                "viable_action_set": [
                    _action_payload(action) for action in label.viable_action_set
                ],
                "nonviable_legal_action_set": [
                    _action_payload(action)
                    for action in label.nonviable_legal_action_set
                ],
                "action_path_targets": action_counts,
                "number_of_future_completion_paths": (
                    label.number_of_future_completion_paths
                ),
                "minimum_remaining_steps": label.minimum_remaining_steps,
                "operator_provenance": dict(label.operator_provenance),
            }
        )
    edges = [
        {
            "operator": "D_orbit",
            "direction": "RESTORE",
            "source_state_hash": edge.source_state_hash,
            "destination_state_hash": edge.destination_state_hash,
            "source_c0_state_hash": edge.source_c0_state_hash,
            "destination_c0_state_hash": edge.destination_c0_state_hash,
            "target_orbit_id": edge.target_orbit_id,
            "action": _action_payload(edge.action_description),
            "restore_state_hash": edge.restore_state_hash,
            "remove_state_hash": edge.remove_state_hash,
            "round_trip_exact": edge.offline_c0_verified,
        }
        for edge in graph.assembly_edges
    ]
    graph_groups = scorer_groups.graph_groups
    legal_count = sum(len(group.legal_actions) for group in graph_groups)
    viable_count = sum(sum(group.graph_targets) for group in graph_groups)
    return {
        "schema_version": "g1-contribution-parent-state-graph.1.0.0",
        "parent_id": graph.record.material_id,
        "split": split,
        "target_space_group": graph.recovered_parent.target_space_group,
        "orbit_count": orbit_count,
        "node_count": len(graph.nodes),
        "accepted_node_count": len(graph.nodes),
        "edge_count": len(graph.assembly_edges),
        "exact_round_trip_count": sum(
            edge.offline_c0_verified for edge in graph.assembly_edges
        ),
        "round_trip_failure_count": sum(
            not edge.offline_c0_verified for edge in graph.assembly_edges
        ),
        "trajectory_replay_failure_count": 0,
        "trajectory_sequence_hashes": graph.d_orbit_trajectory_sequence_hashes,
        "path_count_check_passed": path_count_passed,
        "legal_action_count": legal_count,
        "viable_action_count": int(viable_count),
        "nonviable_legal_action_count": legal_count - int(viable_count),
        "label_group_count": len(graph_groups),
        "final_set_parent_count": len(scorer_groups.final_set_groups),
        "nodes": nodes,
        "edges": edges,
        "labels": labels,
        "model_feature_boundary": {
            "material_id_used_as_model_input": False,
            "parent_coordinates_used_as_model_input": False,
            "future_oracle_state_used_at_inference": False,
        },
    }


def _records_from_artifact(path: Path) -> tuple[Mapping[str, object], ...]:
    payload = _read_json_object(path)
    records = payload.get("records")
    if not isinstance(records, list) or any(
        not isinstance(record, dict) for record in records
    ):
        raise ValueError(f"artifact does not contain record objects: {path}")
    return tuple(records)


def _load_frozen_baselines(config: ContributionLockConfig) -> FrozenBaselineRecords:
    baselines = FrozenBaselineRecords(
        uniform_generation=_records_from_artifact(
            config.frozen_artifacts["uniform_generation"].path
        ),
        uniform_fixed_cell=_records_from_artifact(
            config.frozen_artifacts["uniform_fixed_cell"].path
        ),
        single_path_generation=_records_from_artifact(
            config.frozen_artifacts["single_path_generation"].path
        ),
        single_path_fixed_cell=_records_from_artifact(
            config.frozen_artifacts["single_path_fixed_cell"].path
        ),
        empirical_generation=_records_from_artifact(
            config.frozen_artifacts["empirical_generation"].path
        ),
        empirical_fixed_cell=_records_from_artifact(
            config.frozen_artifacts["empirical_fixed_cell"].path
        ),
    )
    frozen_counts = {
        "SINGLE_PATH_IMITATION": sum(
            _legal_terminal(baselines.single_path_generation)
        ),
        "UNIFORM_LEGAL": sum(_legal_terminal(baselines.uniform_generation)),
        "EMPIRICAL_FREQUENCY": sum(
            _legal_terminal(baselines.empirical_generation)
        ),
    }
    if frozen_counts != {
        "SINGLE_PATH_IMITATION": 76,
        "UNIFORM_LEGAL": 124,
        "EMPIRICAL_FREQUENCY": 82,
    }:
        raise ValueError("frozen policy-attribution counts drifted")
    return baselines


class LiveContributionContext:
    def __init__(
        self,
        config: ContributionLockConfig,
        raw_config: Mapping[str, object],
    ) -> None:
        self.config = config
        self.raw_config = raw_config
        self._bundles: tuple[PublicParentBundle, ...] | None = None
        self._graph_groups: list[ActionScorerGroup] = []
        self._final_set_groups: list[ActionScorerGroup] = []
        self._built_parent_ids: set[str] = set()
        self._c0_model: Any | None = None
        self._chgnet: CHGNetTerminalEvaluator | None = None
        self.baselines = _load_frozen_baselines(config)

    @property
    def bundles(self) -> tuple[PublicParentBundle, ...]:
        if self._bundles is None:
            started = time.perf_counter()
            self._bundles = load_public_parent_bundles(self.config)
            print(
                f"loaded {len(self._bundles)} frozen public parents in "
                f"{time.perf_counter() - started:.1f}s",
                flush=True,
            )
        return self._bundles

    def iter_parents(self) -> Sequence[PublicParentBundle]:
        return self.bundles

    def build_parent_graph_record(
        self, bundle: object
    ) -> Mapping[str, object]:
        if not isinstance(bundle, PublicParentBundle):
            raise TypeError("live graph builder requires PublicParentBundle")
        material_id = bundle.parent.material_id
        if material_id in self._built_parent_ids:
            raise RuntimeError("parent graph was requested more than once")
        started = time.perf_counter()
        graph = build_parent_state_graph(
            bundle.parent,
            bundle.registry,
            recovered_parent=bundle.recovered_parent,
            d_orbit_trajectories=bundle.trajectories,
            max_sites=20,
            minimum_distance=0.5,
        )
        corpus = build_contribution_corpus(
            (graph,), structure_ood_splits={material_id: bundle.split}
        )
        scorer = build_action_scorer_corpus(corpus)
        self._graph_groups.extend(scorer.graph_groups)
        self._final_set_groups.extend(scorer.final_set_groups)
        self._built_parent_ids.add(material_id)
        completed = len(self._built_parent_ids)
        if completed == 1 or completed % 25 == 0 or completed == len(self.bundles):
            print(
                f"state graph {completed}/{len(self.bundles)}: {material_id} "
                f"({time.perf_counter() - started:.1f}s)",
                flush=True,
            )
        return _serialize_parent_graph(
            graph, split=bundle.split, scorer_groups=scorer
        )

    def _scorer_corpus(self) -> ActionScorerCorpus:
        if self._built_parent_ids != {
            bundle.parent.material_id for bundle in self.bundles
        }:
            raise RuntimeError("training requested before all parent graphs were built")
        return ActionScorerCorpus(
            graph_groups=tuple(self._graph_groups),
            final_set_groups=tuple(self._final_set_groups),
        )

    def train(
        self, mode: str, seed: int, cache: Path, output: Path
    ) -> Mapping[str, object]:
        if cache != self.config.output_root / "engineering" / "graph_cache":
            raise ValueError("runner supplied an unexpected graph cache")
        training_config = ActionScorerTrainingConfig(root_seed=seed)
        validate_formal_training_config(training_config, allowed_seed=seed)
        return train_action_scorer(
            self._scorer_corpus(),
            mode=mode,  # type: ignore[arg-type]
            output_directory=output,
            model_config=ActionViabilityConfig(),
            training_config=training_config,
        )

    def _rollout_device(self) -> str:
        devices = self.raw_config.get("devices")
        if not isinstance(devices, Mapping):
            raise ValueError("formal devices configuration is missing")
        device = str(devices.get("rollout", ""))
        if device == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("formal rollout requires CUDA but CUDA is unavailable")
        if device not in {"cpu", "cuda"}:
            raise ValueError("rollout device must be cpu or cuda")
        return device

    def generate(
        self,
        mode: str,
        seed: int,
        report: Mapping[str, object],
        conditions: Sequence[Mapping[str, object]],
    ) -> Sequence[Mapping[str, object]]:
        device = self._rollout_device()
        if self._c0_model is None:
            self._c0_model, _ = load_c0_symmetry_checkpoint(
                self.config.frozen_artifacts["c0_checkpoint"].path,
                device=device,
            )
        return generate_scored_attempts(
            self._c0_model,
            conditions,
            arm=mode,  # type: ignore[arg-type]
            scorer_checkpoint_path=str(report["final_checkpoint_path"]),
            scorer_checkpoint_sha256=str(report["final_checkpoint_sha256"]),
            scorer_initial_state_sha256=str(report["initial_state_sha256"]),
            scorer_training_seed=seed,
            condition_root_seed=20260823,
            condition_manifest_sha256=self.config.frozen_artifacts[
                "condition_manifest"
            ].sha256,
            c0_checkpoint_sha256=self.config.frozen_artifacts[
                "c0_checkpoint"
            ].sha256,
            device=device,
            temperature=0.8,
            minimum_distance=0.5,
        )

    def _chgnet_evaluator(self) -> CHGNetTerminalEvaluator:
        if self._chgnet is not None:
            return self._chgnet
        raw = self.raw_config.get("chgnet")
        devices = self.raw_config.get("devices")
        if not isinstance(raw, Mapping) or not isinstance(devices, Mapping):
            raise ValueError("formal CHGNet configuration is missing")
        config = CHGNetEvaluationConfig(
            package_version=str(raw["package_version"]),
            model_version=str(raw["model_version"]),
            weight_path=str(self.config.frozen_artifacts["chgnet_weights"].path),
            weight_sha256=self.config.frozen_artifacts["chgnet_weights"].sha256,
            optimizer=str(raw["optimizer"]),
            force_threshold_ev_per_angstrom=float(
                raw["force_threshold_ev_per_angstrom"]
            ),
            maximum_steps=int(raw["maximum_steps"]),
            relax_cell=bool(raw["relax_cell"]),
            short_contact_distance=float(raw["short_contact_distance"]),
            device=str(devices["chgnet"]),
        )
        if config.relax_cell or config.maximum_steps != 300:
            raise ValueError("contribution lock requires fixed-cell FIRE300")
        self._chgnet = CHGNetTerminalEvaluator(config)
        return self._chgnet

    def evaluate_fixed_cell(
        self,
        mode: str,
        seed: int,
        records: Sequence[Mapping[str, object]],
    ) -> Sequence[Mapping[str, object]]:
        output = (
            self.config.output_root
            / "engineering"
            / f"seed_{seed}"
            / mode.lower()
            / "fixed_cell_fire300.json"
        )
        payload = self._chgnet_evaluator().evaluate(
            [dict(record) for record in records], output_path=output
        )
        return tuple(
            {
                **record,
                "fixed_cell": True,
                "fire_steps": 300,
                "feature_mode": mode,
                "training_seed": seed,
            }
            for record in payload["records"]
        )

    def analyze_first(self, payload: Mapping[str, object]) -> Mapping[str, object]:
        return analyze_first_round(payload, baselines=self.baselines)

    def analyze_replication(
        self, payload: Mapping[str, object]
    ) -> Mapping[str, object]:
        return analyze_three_seed_replication(payload, baselines=self.baselines)

    def audit_relation_contract(self) -> Mapping[str, object]:
        by_parent = {bundle.parent.material_id: bundle for bundle in self.bundles}
        trajectories: dict[str, StructuralTrajectory] = {}
        with self.config.frozen_artifacts[
            "d_relation_interface_trajectories"
        ].path.open(encoding="utf-8") as stream:
            for line in stream:
                if not line.strip():
                    continue
                trajectory = StructuralTrajectory.from_json(line)
                if trajectory.parent_structure_id not in by_parent:
                    raise ValueError("relation trajectory is outside the frozen cohort")
                if trajectory.parent_structure_id in trajectories:
                    raise ValueError("duplicate relation trajectory for one parent")
                trajectories[trajectory.parent_structure_id] = trajectory
        missing = set(by_parent) - set(trajectories)
        if any(by_parent[parent_id].registry.interface_groups for parent_id in missing):
            raise ValueError("relation trajectory is missing despite interface groups")

        action_count = 0
        exact_local_round_trip_count = 0
        replay_count = 0
        sample_contract: dict[str, object] | None = None
        for parent_id, trajectory in sorted(trajectories.items()):
            bundle = by_parent[parent_id]
            if trajectory.operator != "D_relation_interface":
                raise ValueError("relation audit encountered another operator")
            replay = replay_trajectory(
                bundle.parent, bundle.registry, trajectory
            )
            if not replay.passed:
                raise RuntimeError("formal relation trajectory replay failed")
            replay_count += 1
            groups = {
                group.group_id: group for group in bundle.registry.interface_groups
            }
            state = initial_deconstruction_state(bundle.parent, bundle.registry)
            for action in trajectory.forward_actions:
                if action.target_id not in groups or action.mode != "REMOVE":
                    raise ValueError("relation forward action contract is invalid")
                before = state
                after = apply_structural_action(
                    before, action, bundle.parent, bundle.registry
                )
                expected_affected = set(groups[action.target_id].relation_ids) & set(
                    before.active_relation_ids
                )
                observed_affected = set(before.active_relation_ids) - set(
                    after.active_relation_ids
                )
                if observed_affected != expected_affected:
                    raise RuntimeError("affected relation membership drifted")
                inverse = StructuralAction(
                    "D_relation_interface", "RESTORE", action.target_id
                )
                restored = apply_structural_action(
                    after, inverse, bundle.parent, bundle.registry
                )
                if restored != before:
                    raise RuntimeError("relation local round trip is not exact")
                exact_local_round_trip_count += 1
                action_count += 1
                if sample_contract is None:
                    sample_contract = {
                        "state_before": before.content_hash(),
                        "action": action.to_dict(),
                        "state_after": after.content_hash(),
                        "affected_relation_membership": sorted(observed_affected),
                        "inverse_action": inverse.to_dict(),
                        "inverse_state": restored.content_hash(),
                    }
                state = after
        return {
            "operator": "D_relation_interface",
            "trajectory_count": len(trajectories),
            "parent_without_interface_count": len(missing),
            "action_count": action_count,
            "exact_local_round_trip_count": exact_local_round_trip_count,
            "formal_trajectory_replay_count": replay_count,
            "operator_contract_present": True,
            "stored_state_contract": True,
            "stored_action_contract": True,
            "inverse_contract": True,
            "replay_contract": True,
            "state_before": "stored forward/inverse state hash sequence",
            "action": "typed D_relation_interface REMOVE/RESTORE action",
            "state_after": "stored forward/inverse state hash sequence",
            "affected_relation_membership": "interface-group relation_ids",
            "inverse_action": "stored exact inverse action sequence",
            "sample_replay_contract": sample_contract,
            "orbit_action_coupling_contract_present": False,
            "executable": False,
            "reason": (
                "Phase2A stores executable relation-interface trajectories, but it "
                "does not store a zero-ambiguity mapping from each relation transition "
                "to an ADD_ORBIT candidate target for the shared orbit scorer. Creating "
                "that supervision now would invent a new relation operator contract."
            ),
        }

    @staticmethod
    def forbidden_relation_run(audit: Mapping[str, object]) -> object:
        raise RuntimeError(
            "relation contribution cannot run without an executable orbit-action "
            "coupling contract"
        )


def build_live_dependencies(
    config: ContributionLockConfig, raw_config: Mapping[str, object]
) -> RunnerDependencies:
    context = LiveContributionContext(config, raw_config)
    return RunnerDependencies(
        iter_parents=context.iter_parents,
        build_parent_graph_record=context.build_parent_graph_record,
        train_action_scorer=context.train,
        generate_scored_attempts=context.generate,
        evaluate_fixed_cell_fire300=context.evaluate_fixed_cell,
        analyze_first_round=context.analyze_first,
        analyze_replication=context.analyze_replication,
        audit_relation_contract=context.audit_relation_contract,
        run_relation_contribution=context.forbidden_relation_run,
    )


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run the Crysalis-G1 contribution lock")
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--dry-run", action="store_true")
    arguments = parser.parse_args(argv)
    config, raw = load_runner_config(arguments.config)
    dependencies = None if arguments.dry_run else build_live_dependencies(config, raw)
    run_contribution_lock(config, dependencies=dependencies, dry_run=arguments.dry_run)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
