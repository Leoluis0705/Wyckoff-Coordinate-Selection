from __future__ import annotations

import hashlib
import json
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Literal

import numpy as np
import torch

from crysalis_g1.actions import ActionType


FORMAL_DECONSTRUCTION_OPERATORS = ("D_orbit", "D_relation_interface")
_REQUIRED_PHASE2A_FILES = (
    "canonical_cache/canonical_parents.jsonl",
    "canonical_cache/canonical_relations.jsonl",
    "splits/structure_ood_manifest.jsonl",
    "splits/composition_ood_manifest.jsonl",
    "trajectories/d_orbit.jsonl",
    "trajectories/d_relation_interface.jsonl",
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            try:
                yield json.loads(line)
            except json.JSONDecodeError as error:
                raise ValueError(f"invalid JSONL at {path}:{line_number}") from error


@dataclass(frozen=True, slots=True)
class CanonicalOrbit:
    orbit_id: str
    atomic_number: int
    multiplicity: int
    wyckoff_letter: str
    canonical_site_indices: tuple[int, ...]
    representative_fractional_coordinate: tuple[float, float, float]
    expanded_fractional_coordinates: tuple[tuple[float, float, float], ...]


@dataclass(frozen=True, slots=True)
class RelationGroup:
    group_id: str
    source_orbit_id: str
    target_orbit_id: str
    relation_ids: tuple[str, ...]
    mean_parent_distance: float


@dataclass(frozen=True, slots=True)
class _Parent:
    canonical_structure_hash: str
    composition: tuple[tuple[int, int], ...]
    space_group: int
    target_lattice: tuple[tuple[float, float, float], ...]
    orbits: tuple[CanonicalOrbit, ...]
    relation_groups: tuple[RelationGroup, ...]

    @property
    def orbit_by_id(self) -> dict[str, CanonicalOrbit]:
        return {orbit.orbit_id: orbit for orbit in self.orbits}


@dataclass(frozen=True, slots=True)
class AssemblyExampleKey:
    operator: Literal["D_orbit", "D_relation_interface"]
    parent_structure_id: str
    path_index: int
    assembly_step: int
    sequence_hash: str


@dataclass(frozen=True, slots=True)
class RelationEdgeFeature:
    source_orbit_id: str
    target_orbit_id: str
    invariants: tuple[float, ...]
    availability: tuple[bool, ...]
    vector: tuple[float, float, float]


@dataclass(frozen=True, slots=True)
class AssemblyExample:
    example_id: str
    operator: Literal["D_orbit", "D_relation_interface"]
    composition: tuple[tuple[int, int], ...]
    space_group: int
    progress: float
    active_orbit_ids: tuple[str, ...]
    active_relation_group_ids: tuple[str, ...]
    active_orbits: tuple[CanonicalOrbit, ...]
    relation_edges: tuple[RelationEdgeFeature, ...]
    input_lattice: tuple[tuple[float, float, float], ...]
    target_lattice: tuple[tuple[float, float, float], ...]
    remaining_composition: tuple[tuple[int, int], ...]
    target_action: ActionType
    target_orbit: CanonicalOrbit | None
    target_relation_group_id: str | None
    target_relation_source_index: int
    target_relation_target_index: int
    target_relation_distance: float


@dataclass(frozen=True, slots=True)
class AssemblyTrainingBatch:
    composition: torch.Tensor
    remaining: torch.Tensor
    space_group: torch.Tensor
    progress: torch.Tensor
    node_atomic_numbers: torch.Tensor
    node_multiplicities: torch.Tensor
    node_wyckoff_indices: torch.Tensor
    node_fractional_coordinates: torch.Tensor
    node_mask: torch.Tensor
    input_lattice: torch.Tensor
    relation_invariants: torch.Tensor
    relation_availability: torch.Tensor
    relation_vectors: torch.Tensor
    relation_sources: torch.Tensor
    relation_targets: torch.Tensor
    relation_mask: torch.Tensor
    target_action: torch.Tensor
    target_atomic_number: torch.Tensor
    target_multiplicity: torch.Tensor
    target_wyckoff_index: torch.Tensor
    target_fractional_coordinates: torch.Tensor
    target_lattice: torch.Tensor
    target_orbit_mask: torch.Tensor
    target_relation_mask: torch.Tensor
    target_relation_sources: torch.Tensor
    target_relation_targets: torch.Tensor
    target_relation_distance: torch.Tensor
    example_ids: tuple[str, ...]

    def to(self, device: torch.device | str) -> AssemblyTrainingBatch:
        payload: dict[str, Any] = {}
        for name in self.__dataclass_fields__:
            value = getattr(self, name)
            payload[name] = value.to(device) if isinstance(value, torch.Tensor) else value
        return AssemblyTrainingBatch(**payload)


class FrozenPhase2ACorpus:
    """Read-only training views reconstructed from the corrected Phase 2A cache."""

    def __init__(
        self,
        *,
        root: Path,
        manifest_sha256: str,
        parents: dict[str, _Parent],
        splits: dict[str, str],
        trajectories: tuple[tuple[str, dict[str, Any]], ...],
    ) -> None:
        self.root = root
        self.manifest_sha256 = manifest_sha256
        self._parents = parents
        self._splits = splits
        self._trajectories = trajectories
        self._trajectory_by_key = {
            (operator, row["parent_structure_id"], int(row["path_index"])): row
            for operator, row in trajectories
        }

    @classmethod
    def load(
        cls, root: str | Path, *, expected_manifest_sha256: str
    ) -> FrozenPhase2ACorpus:
        root = Path(root)
        manifest_path = root / "phase2a_manifest.json"
        observed_manifest_sha = _sha256(manifest_path)
        if observed_manifest_sha != expected_manifest_sha256:
            raise RuntimeError(
                "Phase 2A manifest hash mismatch: "
                f"expected {expected_manifest_sha256}, observed {observed_manifest_sha}"
            )
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("schema_version") != "g1-phase2a-cache.1.1.0":
            raise RuntimeError("unsupported corrected Phase 2A schema")
        if manifest.get("no_refill") is not True:
            raise RuntimeError("corrected Phase 2A cache violates NO_REFILL")
        if manifest.get("sealed_or_blind_data_accessed") is not False:
            raise RuntimeError("corrected Phase 2A cache accessed sealed/blind data")
        declared = manifest.get("file_sha256", {})
        for relative in _REQUIRED_PHASE2A_FILES:
            path = root / relative
            expected = declared.get(relative)
            if not path.is_file() or not isinstance(expected, str):
                raise RuntimeError(f"required corrected Phase 2A artifact missing: {relative}")
            observed = _sha256(path)
            if observed != expected:
                raise RuntimeError(
                    f"corrected Phase 2A artifact hash mismatch: {relative}"
                )

        trajectories: list[tuple[str, dict[str, Any]]] = []
        selected_ids: set[str] = set()
        for operator, relative in (
            ("D_orbit", "trajectories/d_orbit.jsonl"),
            ("D_relation_interface", "trajectories/d_relation_interface.jsonl"),
        ):
            for row in _read_jsonl(root / relative):
                if row.get("operator") != operator:
                    raise RuntimeError(f"trajectory operator mismatch in {relative}")
                selected_ids.add(str(row["parent_structure_id"]))
                trajectories.append((operator, row))

        split_rows = _read_jsonl(root / "splits/structure_ood_manifest.jsonl")
        splits = {
            str(row["material_id"]): str(row["split"])
            for row in split_rows
            if str(row["material_id"]) in selected_ids
        }
        if set(splits) != selected_ids:
            raise RuntimeError("selected parents are incomplete in Structure-OOD manifest")

        parent_payloads = {
            str(row["material_id"]): row
            for row in _read_jsonl(root / "canonical_cache/canonical_parents.jsonl")
            if str(row["material_id"]) in selected_ids
        }
        relation_payloads = {
            str(row["material_id"]): row
            for row in _read_jsonl(root / "canonical_cache/canonical_relations.jsonl")
            if str(row["material_id"]) in selected_ids
        }
        if set(parent_payloads) != selected_ids:
            raise RuntimeError("selected canonical parents are incomplete")
        parents: dict[str, _Parent] = {}
        for material_id, payload in parent_payloads.items():
            coordinates = tuple(
                tuple(float(value) for value in coordinate)
                for coordinate in payload["fractional_coordinates"]
            )
            orbits = tuple(
                CanonicalOrbit(
                    orbit_id=str(orbit["orbit_id"]),
                    atomic_number=int(orbit["atomic_number"]),
                    multiplicity=int(orbit["multiplicity"]),
                    wyckoff_letter=str(orbit["wyckoff_letter"]),
                    canonical_site_indices=tuple(
                        int(index) for index in orbit["canonical_site_indices"]
                    ),
                    representative_fractional_coordinate=coordinates[
                        int(orbit["canonical_site_indices"][0])
                    ],
                    expanded_fractional_coordinates=tuple(
                        coordinates[int(index)]
                        for index in orbit["canonical_site_indices"]
                    ),
                )
                for orbit in payload["orbits"]
            )
            relation_payload = relation_payloads.get(
                material_id, {"interface_groups": [], "relations": []}
            )
            relation_distance = {
                str(relation["relation_id"]): float(relation["distance"])
                for relation in relation_payload["relations"]
            }
            groups = []
            for group in relation_payload["interface_groups"]:
                relation_ids = tuple(str(value) for value in group["relation_ids"])
                distances = [relation_distance[value] for value in relation_ids]
                groups.append(
                    RelationGroup(
                        group_id=str(group["group_id"]),
                        source_orbit_id=str(group["source_orbit_id"]),
                        target_orbit_id=str(group["target_orbit_id"]),
                        relation_ids=relation_ids,
                        mean_parent_distance=float(np.mean(distances)),
                    )
                )
            parents[material_id] = _Parent(
                canonical_structure_hash=str(payload["canonical_structure_hash"]),
                composition=tuple(
                    sorted(Counter(int(value) for value in payload["atomic_numbers"]).items())
                ),
                space_group=int(payload["space_group"]),
                target_lattice=tuple(
                    tuple(float(value) for value in row) for row in payload["lattice"]
                ),
                orbits=orbits,
                relation_groups=tuple(groups),
            )
        return cls(
            root=root,
            manifest_sha256=observed_manifest_sha,
            parents=parents,
            splits=splits,
            trajectories=tuple(trajectories),
        )

    @property
    def parent_count(self) -> int:
        return len(self._parents)

    def example_keys(
        self,
        split: str,
        *,
        operator: Literal["D_orbit", "D_relation_interface"] | None = None,
    ) -> tuple[AssemblyExampleKey, ...]:
        if operator is not None and operator not in FORMAL_DECONSTRUCTION_OPERATORS:
            raise ValueError("only formal deconstruction operators are available")
        keys: list[AssemblyExampleKey] = []
        for trajectory_operator, row in self._trajectories:
            parent_id = str(row["parent_structure_id"])
            if self._splits[parent_id] != split:
                continue
            if operator is not None and trajectory_operator != operator:
                continue
            actions = row["inverse_actions"]
            for assembly_step in range(len(actions) + 1):
                keys.append(
                    AssemblyExampleKey(
                        operator=trajectory_operator,  # type: ignore[arg-type]
                        parent_structure_id=parent_id,
                        path_index=int(row["path_index"]),
                        assembly_step=assembly_step,
                        sequence_hash=str(row["sequence_hash"]),
                    )
                )
        return tuple(keys)

    @staticmethod
    def _embryo_lattice(composition: tuple[tuple[int, int], ...]) -> np.ndarray:
        atom_count = sum(count for _, count in composition)
        length = 3.0 + atom_count ** (1.0 / 3.0)
        return np.eye(3, dtype=np.float64) * length

    @staticmethod
    def _example_id(key: AssemblyExampleKey) -> str:
        payload = (
            f"{key.operator}:{key.sequence_hash}:{key.path_index}:{key.assembly_step}"
        )
        return "example-" + hashlib.sha256(payload.encode()).hexdigest()

    def assembly_example(self, key: AssemblyExampleKey) -> AssemblyExample:
        parent = self._parents[key.parent_structure_id]
        row = self._trajectory_by_key[
            (key.operator, key.parent_structure_id, key.path_index)
        ]
        actions = row["inverse_actions"]
        if not 0 <= key.assembly_step <= len(actions):
            raise IndexError("assembly step is out of range")
        if key.operator == "D_orbit":
            active_orbit_ids = tuple(
                str(action["target_id"])
                for action in actions[: key.assembly_step]
            )
            active_set = set(active_orbit_ids)
            active_relation_group_ids = tuple(
                group.group_id
                for group in parent.relation_groups
                if group.source_orbit_id in active_set
                and group.target_orbit_id in active_set
            )
            target_action = (
                ActionType.ADD_ORBIT
                if key.assembly_step < len(actions)
                else ActionType.TERMINATE
            )
            target_orbit = (
                parent.orbit_by_id[str(actions[key.assembly_step]["target_id"])]
                if key.assembly_step < len(actions)
                else None
            )
            target_relation_group_id = None
        else:
            active_orbit_ids = tuple(orbit.orbit_id for orbit in parent.orbits)
            active_relation_group_ids = tuple(
                str(action["target_id"])
                for action in actions[: key.assembly_step]
            )
            target_action = (
                ActionType.ADD_PERIODIC_EDGE
                if key.assembly_step < len(actions)
                else ActionType.TERMINATE
            )
            target_orbit = None
            target_relation_group_id = (
                str(actions[key.assembly_step]["target_id"])
                if key.assembly_step < len(actions)
                else None
            )

        orbit_map = parent.orbit_by_id
        active_orbits = tuple(orbit_map[value] for value in active_orbit_ids)
        index_by_orbit = {
            orbit.orbit_id: index for index, orbit in enumerate(active_orbits)
        }
        lattice = self._embryo_lattice(parent.composition)
        progress = key.assembly_step / max(len(actions), 1)
        active_groups = {
            group.group_id: group
            for group in parent.relation_groups
            if group.group_id in set(active_relation_group_ids)
        }
        degrees = Counter()
        for group in active_groups.values():
            degrees[group.source_orbit_id] += 1
            degrees[group.target_orbit_id] += 1
        relation_edges = []
        for group_id in active_relation_group_ids:
            group = active_groups[group_id]
            source_coordinate = np.asarray(
                orbit_map[group.source_orbit_id].representative_fractional_coordinate
            )
            target_coordinate = np.asarray(
                orbit_map[group.target_orbit_id].representative_fractional_coordinate
            )
            delta = target_coordinate - source_coordinate
            delta -= np.round(delta)
            vector = delta @ lattice
            invariants = (
                float(np.linalg.norm(vector)),
                0.0,
                float(degrees[group.source_orbit_id]),
                float(degrees[group.target_orbit_id]),
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                float(progress),
            )
            availability = (
                True,
                False,
                True,
                True,
                False,
                False,
                False,
                False,
                False,
                False,
                True,
            )
            relation_edges.append(
                RelationEdgeFeature(
                    source_orbit_id=group.source_orbit_id,
                    target_orbit_id=group.target_orbit_id,
                    invariants=invariants,
                    availability=availability,
                    vector=tuple(float(value) for value in vector),
                )
            )

        remaining = Counter(dict(parent.composition))
        for orbit in active_orbits:
            remaining[orbit.atomic_number] -= orbit.multiplicity
        remaining_composition = tuple(
            sorted((number, count) for number, count in remaining.items() if count > 0)
        )
        relation_source = relation_target = 0
        relation_distance = 0.0
        if target_relation_group_id is not None:
            target_group = next(
                group
                for group in parent.relation_groups
                if group.group_id == target_relation_group_id
            )
            relation_source = index_by_orbit[target_group.source_orbit_id]
            relation_target = index_by_orbit[target_group.target_orbit_id]
            relation_distance = target_group.mean_parent_distance
        return AssemblyExample(
            example_id=self._example_id(key),
            operator=key.operator,
            composition=parent.composition,
            space_group=parent.space_group,
            progress=float(progress),
            active_orbit_ids=active_orbit_ids,
            active_relation_group_ids=active_relation_group_ids,
            active_orbits=active_orbits,
            relation_edges=tuple(relation_edges),
            input_lattice=tuple(tuple(float(value) for value in row) for row in lattice),
            target_lattice=parent.target_lattice,
            remaining_composition=remaining_composition,
            target_action=target_action,
            target_orbit=target_orbit,
            target_relation_group_id=target_relation_group_id,
            target_relation_source_index=relation_source,
            target_relation_target_index=relation_target,
            target_relation_distance=relation_distance,
        )

    def collate(
        self, keys: Iterable[AssemblyExampleKey]
    ) -> AssemblyTrainingBatch:
        examples = tuple(self.assembly_example(key) for key in keys)
        if not examples:
            raise ValueError("assembly batch must not be empty")
        batch_size = len(examples)
        node_count = max(1, max(len(example.active_orbits) for example in examples))
        relation_count = max(1, max(len(example.relation_edges) for example in examples))
        composition = torch.zeros((batch_size, 119), dtype=torch.float32)
        remaining = torch.zeros_like(composition)
        space_group = torch.zeros(batch_size, dtype=torch.long)
        progress = torch.zeros((batch_size, 1), dtype=torch.float32)
        node_atomic_numbers = torch.zeros((batch_size, node_count), dtype=torch.long)
        node_multiplicities = torch.zeros_like(node_atomic_numbers)
        node_wyckoff_indices = torch.zeros_like(node_atomic_numbers)
        node_fractional_coordinates = torch.zeros(
            (batch_size, node_count, 3), dtype=torch.float32
        )
        node_mask = torch.zeros((batch_size, node_count), dtype=torch.bool)
        input_lattice = torch.zeros((batch_size, 3, 3), dtype=torch.float32)
        relation_invariants = torch.zeros(
            (batch_size, relation_count, 11), dtype=torch.float32
        )
        relation_availability = torch.zeros_like(
            relation_invariants, dtype=torch.bool
        )
        relation_vectors = torch.zeros(
            (batch_size, relation_count, 3), dtype=torch.float32
        )
        relation_sources = torch.zeros(
            (batch_size, relation_count), dtype=torch.long
        )
        relation_targets = torch.zeros_like(relation_sources)
        relation_mask = torch.zeros(
            (batch_size, relation_count), dtype=torch.bool
        )
        target_action = torch.zeros(batch_size, dtype=torch.long)
        target_atomic_number = torch.zeros(batch_size, dtype=torch.long)
        target_multiplicity = torch.zeros(batch_size, dtype=torch.long)
        target_wyckoff_index = torch.zeros(batch_size, dtype=torch.long)
        target_fractional_coordinates = torch.zeros(
            (batch_size, 3), dtype=torch.float32
        )
        target_lattice = torch.zeros((batch_size, 3, 3), dtype=torch.float32)
        target_orbit_mask = torch.zeros(batch_size, dtype=torch.bool)
        target_relation_mask = torch.zeros(batch_size, dtype=torch.bool)
        target_relation_sources = torch.zeros(batch_size, dtype=torch.long)
        target_relation_targets = torch.zeros(batch_size, dtype=torch.long)
        target_relation_distance = torch.zeros(batch_size, dtype=torch.float32)

        for row, example in enumerate(examples):
            for atomic_number, count in example.composition:
                composition[row, atomic_number] = float(count)
            for atomic_number, count in example.remaining_composition:
                remaining[row, atomic_number] = float(count)
            space_group[row] = example.space_group
            progress[row, 0] = example.progress
            input_lattice[row] = torch.tensor(example.input_lattice)
            target_lattice[row] = torch.tensor(example.target_lattice)
            orbit_index = {
                orbit.orbit_id: index
                for index, orbit in enumerate(example.active_orbits)
            }
            for column, orbit in enumerate(example.active_orbits):
                node_atomic_numbers[row, column] = orbit.atomic_number
                node_multiplicities[row, column] = orbit.multiplicity
                node_wyckoff_indices[row, column] = ord(orbit.wyckoff_letter) - ord("a")
                node_fractional_coordinates[row, column] = torch.tensor(
                    orbit.representative_fractional_coordinate
                )
                node_mask[row, column] = True
            for column, edge in enumerate(example.relation_edges):
                relation_invariants[row, column] = torch.tensor(edge.invariants)
                relation_availability[row, column] = torch.tensor(edge.availability)
                relation_vectors[row, column] = torch.tensor(edge.vector)
                relation_sources[row, column] = orbit_index[edge.source_orbit_id]
                relation_targets[row, column] = orbit_index[edge.target_orbit_id]
                relation_mask[row, column] = True
            target_action[row] = list(ActionType).index(example.target_action)
            if example.target_orbit is not None:
                target_orbit_mask[row] = True
                target_atomic_number[row] = example.target_orbit.atomic_number
                target_multiplicity[row] = example.target_orbit.multiplicity
                target_wyckoff_index[row] = (
                    ord(example.target_orbit.wyckoff_letter) - ord("a")
                )
                target_fractional_coordinates[row] = torch.tensor(
                    example.target_orbit.representative_fractional_coordinate
                )
            if example.target_relation_group_id is not None:
                target_relation_mask[row] = True
                target_relation_sources[row] = example.target_relation_source_index
                target_relation_targets[row] = example.target_relation_target_index
                target_relation_distance[row] = example.target_relation_distance
        return AssemblyTrainingBatch(
            composition=composition,
            remaining=remaining,
            space_group=space_group,
            progress=progress,
            node_atomic_numbers=node_atomic_numbers,
            node_multiplicities=node_multiplicities,
            node_wyckoff_indices=node_wyckoff_indices,
            node_fractional_coordinates=node_fractional_coordinates,
            node_mask=node_mask,
            input_lattice=input_lattice,
            relation_invariants=relation_invariants,
            relation_availability=relation_availability,
            relation_vectors=relation_vectors,
            relation_sources=relation_sources,
            relation_targets=relation_targets,
            relation_mask=relation_mask,
            target_action=target_action,
            target_atomic_number=target_atomic_number,
            target_multiplicity=target_multiplicity,
            target_wyckoff_index=target_wyckoff_index,
            target_fractional_coordinates=target_fractional_coordinates,
            target_lattice=target_lattice,
            target_orbit_mask=target_orbit_mask,
            target_relation_mask=target_relation_mask,
            target_relation_sources=target_relation_sources,
            target_relation_targets=target_relation_targets,
            target_relation_distance=target_relation_distance,
            example_ids=tuple(example.example_id for example in examples),
        )

    def build_condition_manifest(
        self, *, count: int, split: str, root_seed: int
    ) -> list[dict[str, Any]]:
        if count <= 0:
            raise ValueError("condition count must be positive")
        candidates = [
            parent
            for parent_id, parent in self._parents.items()
            if self._splits[parent_id] == split
        ]
        if not candidates:
            raise ValueError(f"no conditions are available for split {split}")
        candidates.sort(
            key=lambda parent: hashlib.sha256(
                f"condition-order:{root_seed}:{parent.canonical_structure_hash}".encode()
            ).hexdigest()
        )
        conditions = []
        for attempt_index in range(count):
            parent = candidates[attempt_index % len(candidates)]
            condition_seed = int.from_bytes(
                hashlib.sha256(
                    f"condition-seed:{root_seed}:{attempt_index}".encode()
                ).digest()[:8],
                "big",
            ) % (2**31 - 1)
            public_payload = {
                "attempt_index": attempt_index,
                "root_seed": root_seed,
                "condition_seed": condition_seed,
                "composition": [list(item) for item in parent.composition],
                "space_group": parent.space_group,
            }
            condition_id = "condition-" + hashlib.sha256(
                json.dumps(public_payload, sort_keys=True).encode()
            ).hexdigest()
            conditions.append({"condition_id": condition_id, **public_payload})
        return conditions
