from __future__ import annotations

import hashlib
import json
import math
import os
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from statistics import median
from typing import Iterable

import torch
import torch.nn.functional as F
from torch import nn

from crysalis_g1.experiments.local_pilot_data import FrozenPhase2ACorpus
from crysalis_g1.experiments.local_pilot_training import derive_named_seed


@dataclass(frozen=True, slots=True)
class RelationLearningExample:
    example_id: str
    parent_split: str
    invariant_values: tuple[float, ...]
    availability: tuple[bool, ...]
    target_distance: float
    distance_available: bool
    inverse_feasible: float


@dataclass(frozen=True, slots=True)
class RelationLearningBatch:
    inputs: torch.Tensor
    target_distance: torch.Tensor
    distance_mask: torch.Tensor
    inverse_feasible: torch.Tensor
    example_ids: tuple[str, ...]

    def to(self, device: torch.device | str) -> RelationLearningBatch:
        return RelationLearningBatch(
            inputs=self.inputs.to(device),
            target_distance=self.target_distance.to(device),
            distance_mask=self.distance_mask.to(device),
            inverse_feasible=self.inverse_feasible.to(device),
            example_ids=self.example_ids,
        )


class RelationLearningCorpus:
    """Offline cross-sample relation view using rotation-invariant scalars only."""

    def __init__(
        self,
        phase2a: FrozenPhase2ACorpus,
        examples_by_split: dict[str, tuple[RelationLearningExample, ...]],
    ) -> None:
        self.phase2a = phase2a
        self._examples_by_split = examples_by_split

    @staticmethod
    def _candidate_features(
        *,
        source: object,
        target: object,
        space_group: int,
        progress: float,
        source_degree: int,
        target_degree: int,
    ) -> tuple[float, ...]:
        source_atomic_number = int(getattr(source, "atomic_number"))
        target_atomic_number = int(getattr(target, "atomic_number"))
        return (
            source_atomic_number / 118.0,
            target_atomic_number / 118.0,
            int(getattr(source, "multiplicity")) / 12.0,
            int(getattr(target, "multiplicity")) / 12.0,
            (ord(str(getattr(source, "wyckoff_letter"))) - ord("a")) / 25.0,
            (ord(str(getattr(target, "wyckoff_letter"))) - ord("a")) / 25.0,
            space_group / 230.0,
            progress,
            min(source_degree, 8) / 8.0,
            min(target_degree, 8) / 8.0,
            abs(source_atomic_number - target_atomic_number) / 118.0,
        )

    @classmethod
    def load(
        cls, root: str | Path, *, expected_manifest_sha256: str
    ) -> RelationLearningCorpus:
        phase2a = FrozenPhase2ACorpus.load(
            root, expected_manifest_sha256=expected_manifest_sha256
        )
        examples_by_split: dict[str, list[RelationLearningExample]] = {}
        for operator, trajectory in phase2a._trajectories:
            if operator != "D_relation_interface":
                continue
            parent_id = str(trajectory["parent_structure_id"])
            parent = phase2a._parents[parent_id]
            split = phase2a._splits[parent_id]
            orbit_by_id = parent.orbit_by_id
            group_by_id = {
                group.group_id: group for group in parent.relation_groups
            }
            actions = tuple(trajectory["inverse_actions"])
            active_group_ids: list[str] = []
            for step, action in enumerate(actions):
                target_group_id = str(action["target_id"])
                degrees: dict[str, int] = {}
                for active_group_id in active_group_ids:
                    active_group = group_by_id[active_group_id]
                    degrees[active_group.source_orbit_id] = (
                        degrees.get(active_group.source_orbit_id, 0) + 1
                    )
                    degrees[active_group.target_orbit_id] = (
                        degrees.get(active_group.target_orbit_id, 0) + 1
                    )
                progress = step / max(len(actions), 1)

                def build(group_id: str, feasible: float) -> RelationLearningExample:
                    group = group_by_id[group_id]
                    source = orbit_by_id[group.source_orbit_id]
                    target = orbit_by_id[group.target_orbit_id]
                    payload = (
                        f"relation-learning:{trajectory['sequence_hash']}:"
                        f"{step}:{group_id}:{int(feasible)}"
                    )
                    return RelationLearningExample(
                        example_id="relation-example-"
                        + hashlib.sha256(payload.encode()).hexdigest(),
                        parent_split=split,
                        invariant_values=cls._candidate_features(
                            source=source,
                            target=target,
                            space_group=parent.space_group,
                            progress=progress,
                            source_degree=degrees.get(group.source_orbit_id, 0),
                            target_degree=degrees.get(group.target_orbit_id, 0),
                        ),
                        availability=(True,) * 11,
                        target_distance=group.mean_parent_distance,
                        distance_available=bool(feasible),
                        inverse_feasible=feasible,
                    )

                examples_by_split.setdefault(split, []).append(
                    build(target_group_id, 1.0)
                )
                inactive_non_targets = sorted(
                    set(group_by_id) - set(active_group_ids) - {target_group_id}
                )
                if inactive_non_targets:
                    negative_index = int.from_bytes(
                        hashlib.sha256(
                            f"relation-negative:{trajectory['sequence_hash']}:{step}".encode()
                        ).digest()[:8],
                        "big",
                    ) % len(inactive_non_targets)
                    examples_by_split[split].append(
                        build(inactive_non_targets[negative_index], 0.0)
                    )
                active_group_ids.append(target_group_id)
        return cls(
            phase2a,
            {
                split: tuple(examples)
                for split, examples in examples_by_split.items()
            },
        )

    def examples(self, split: str) -> tuple[RelationLearningExample, ...]:
        return self._examples_by_split.get(split, ())

    @staticmethod
    def collate(
        examples: Iterable[RelationLearningExample],
    ) -> RelationLearningBatch:
        examples = tuple(examples)
        if not examples:
            raise ValueError("relation-learning batch must not be empty")
        values = torch.tensor(
            [example.invariant_values for example in examples], dtype=torch.float32
        )
        availability = torch.tensor(
            [example.availability for example in examples], dtype=torch.bool
        )
        inputs = torch.cat(
            (torch.where(availability, values, torch.zeros_like(values)), availability.float()),
            dim=-1,
        )
        return RelationLearningBatch(
            inputs=inputs,
            target_distance=torch.tensor(
                [example.target_distance for example in examples], dtype=torch.float32
            ),
            distance_mask=torch.tensor(
                [example.distance_available for example in examples], dtype=torch.bool
            ),
            inverse_feasible=torch.tensor(
                [example.inverse_feasible for example in examples], dtype=torch.float32
            ),
            example_ids=tuple(example.example_id for example in examples),
        )


class LinearSplineKANLayer(nn.Module):
    """Additive degree-one B-spline KAN layer on normalized scalar inputs."""

    def __init__(self, input_dim: int, output_dim: int, grid_size: int) -> None:
        super().__init__()
        if input_dim <= 0 or output_dim <= 0 or grid_size < 3:
            raise ValueError("KAN dimensions and grid size are invalid")
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.grid_size = grid_size
        self.coefficients = nn.Parameter(
            torch.empty(output_dim, input_dim, grid_size)
        )
        self.bias = nn.Parameter(torch.zeros(output_dim))
        nn.init.normal_(self.coefficients, mean=0.0, std=0.02)

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        if values.shape[-1] != self.input_dim:
            raise ValueError("KAN input width mismatch")
        values = values.float().clamp(0.0, 1.0)
        knots = torch.linspace(
            0.0, 1.0, self.grid_size, device=values.device, dtype=values.dtype
        )
        basis = (
            1.0
            - (values[..., None] - knots).abs() * float(self.grid_size - 1)
        ).clamp_min(0.0)
        return torch.einsum("big,oig->bo", basis, self.coefficients) + self.bias


class CRKANTeacher(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, grid_size: int) -> None:
        super().__init__()
        self.layer_1 = LinearSplineKANLayer(input_dim, hidden_dim, grid_size)
        self.layer_2 = LinearSplineKANLayer(hidden_dim, 2, grid_size)

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        hidden = torch.sigmoid(self.layer_1(values))
        return self.layer_2(hidden)


class MatchedMLPTeacher(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, prior_dim: int) -> None:
        super().__init__()
        self.trunk = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, prior_dim),
        )
        self.head = nn.Linear(prior_dim, 2)

    def prior(self, values: torch.Tensor) -> torch.Tensor:
        return self.trunk(values)

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        return self.head(self.prior(values))

    def relation_library_state_dict(self) -> dict[str, torch.Tensor]:
        return {
            name: value.detach().cpu().clone()
            for name, value in self.trunk.state_dict().items()
        }


class RelationStudent(MatchedMLPTeacher):
    pass


def relation_learning_loss(
    prediction: torch.Tensor,
    target_distance: torch.Tensor,
    distance_mask: torch.Tensor,
    inverse_feasible: torch.Tensor,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    if bool(distance_mask.any()):
        distance = F.smooth_l1_loss(
            F.softplus(prediction[distance_mask, 0]),
            target_distance[distance_mask],
        )
    else:
        distance = prediction.sum() * 0.0
    calibration = F.binary_cross_entropy_with_logits(
        prediction[:, 1], inverse_feasible
    )
    return distance + calibration, {
        "relation_distance_loss": distance,
        "inverse_calibration_loss": calibration,
    }


@dataclass(frozen=True, slots=True)
class RelationTrainingConfig:
    root_seed: int
    device: str
    batch_size: int
    learning_rate: float
    weight_decay: float
    maximum_updates: int
    minimum_updates: int
    validation_interval: int
    early_stopping_patience: int
    latency_repetitions: int

    def __post_init__(self) -> None:
        if self.root_seed != 20260823:
            raise ValueError("relation-training root seed must remain 20260823")
        if self.device not in {"cpu", "cuda"}:
            raise ValueError("relation-training device must be cpu or cuda")
        counts = (
            self.batch_size,
            self.maximum_updates,
            self.minimum_updates,
            self.validation_interval,
            self.early_stopping_patience,
            self.latency_repetitions,
        )
        if any(type(value) is not int or value <= 0 for value in counts):
            raise ValueError("relation-training counts must be positive integers")
        if self.minimum_updates > self.maximum_updates:
            raise ValueError("relation minimum updates cannot exceed maximum")
        if self.learning_rate <= 0 or self.weight_decay < 0:
            raise ValueError("relation optimizer configuration is invalid")

    def sha256(self) -> str:
        payload = json.dumps(
            asdict(self), sort_keys=True, separators=(",", ":")
        ).encode()
        return hashlib.sha256(payload).hexdigest()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _write_json(path: Path, payload: object) -> None:
    path.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            allow_nan=False,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


def _sync(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)


class _RelationSampler:
    def __init__(
        self,
        examples: tuple[RelationLearningExample, ...],
        *,
        seed: int,
    ) -> None:
        if not examples:
            raise ValueError("relation sampler has no examples")
        self.examples = examples
        self.generator = torch.Generator().manual_seed(seed)

    def batch(self, batch_size: int) -> RelationLearningBatch:
        indices = torch.randint(
            len(self.examples), (batch_size,), generator=self.generator
        ).tolist()
        return RelationLearningCorpus.collate(self.examples[index] for index in indices)


def _evaluate_relation_model(
    model: nn.Module,
    examples: tuple[RelationLearningExample, ...],
    *,
    batch_size: int,
    device: torch.device,
) -> dict[str, float]:
    if not examples:
        raise ValueError("relation validation split has no examples")
    objective_sum = 0.0
    example_count = 0
    positive_absolute_error = 0.0
    positive_count = 0
    brier_sum = 0.0
    model.eval()
    with torch.no_grad():
        for start in range(0, len(examples), batch_size):
            batch = RelationLearningCorpus.collate(
                examples[start : start + batch_size]
            ).to(device)
            prediction = model(batch.inputs)
            loss, _ = relation_learning_loss(
                prediction,
                batch.target_distance,
                batch.distance_mask,
                batch.inverse_feasible,
            )
            count = len(batch.example_ids)
            objective_sum += float(loss) * count
            example_count += count
            if bool(batch.distance_mask.any()):
                absolute = (
                    F.softplus(prediction[batch.distance_mask, 0])
                    - batch.target_distance[batch.distance_mask]
                ).abs()
                positive_absolute_error += float(absolute.sum())
                positive_count += int(batch.distance_mask.sum())
            probability = torch.sigmoid(prediction[:, 1])
            brier_sum += float(
                (probability - batch.inverse_feasible).square().sum()
            )
    model.train()
    return {
        "validation_objective": objective_sum / max(example_count, 1),
        "held_out_relation_mae": positive_absolute_error / max(positive_count, 1),
        "inverse_relation_brier": brier_sum / max(example_count, 1),
    }


def _inference_profile(
    model: nn.Module,
    batch: RelationLearningBatch,
    *,
    repetitions: int,
    device: torch.device,
) -> dict[str, float | int]:
    model.eval()
    batch = batch.to(device)
    baseline_allocated = (
        int(torch.cuda.memory_allocated(device)) if device.type == "cuda" else 0
    )
    baseline_reserved = (
        int(torch.cuda.memory_reserved(device)) if device.type == "cuda" else 0
    )
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    with torch.no_grad():
        for _ in range(3):
            model(batch.inputs)
        _sync(device)
        latencies = []
        for _ in range(repetitions):
            started = time.perf_counter()
            model(batch.inputs)
            _sync(device)
            latencies.append(time.perf_counter() - started)
    model.train()
    return {
        "p50_latency_seconds": median(latencies),
        "peak_allocated_vram_bytes": (
            max(
                0,
                int(torch.cuda.max_memory_allocated(device))
                - baseline_allocated,
            )
            if device.type == "cuda"
            else 0
        ),
        "peak_reserved_vram_bytes": (
            max(
                0,
                int(torch.cuda.max_memory_reserved(device))
                - baseline_reserved,
            )
            if device.type == "cuda"
            else 0
        ),
    }


def _train_relation_model(
    *,
    model: nn.Module,
    model_name: str,
    train_examples: tuple[RelationLearningExample, ...],
    validation_examples: tuple[RelationLearningExample, ...],
    config: RelationTrainingConfig,
    output_dir: Path,
    teacher: nn.Module | None = None,
) -> dict[str, object]:
    if output_dir.exists():
        raise FileExistsError(f"relation run refuses to overwrite: {output_dir}")
    output_dir.mkdir(parents=True)
    device = torch.device(config.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA relation training requested but unavailable")
    seed = derive_named_seed(config.root_seed, f"relation:{model_name}:initialization")
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    model = model.to(device).train()
    if teacher is not None:
        teacher = teacher.to(device).eval()
        for parameter in teacher.parameters():
            parameter.requires_grad_(False)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=config.learning_rate, weight_decay=config.weight_decay
    )
    sampler = _RelationSampler(
        train_examples,
        seed=derive_named_seed(config.root_seed, "relation:shared-batch-schedule"),
    )
    best_objective = math.inf
    best_update = 0
    stale_evaluations = 0
    stopped_early = False
    metrics_path = output_dir / "metrics.jsonl"
    best_path = output_dir / "best.pt"
    started = time.perf_counter()
    completed_updates = 0
    with metrics_path.open("x", encoding="utf-8") as metrics:
        for update in range(1, config.maximum_updates + 1):
            batch = sampler.batch(config.batch_size).to(device)
            optimizer.zero_grad(set_to_none=True)
            prediction = model(batch.inputs)
            loss, components = relation_learning_loss(
                prediction,
                batch.target_distance,
                batch.distance_mask,
                batch.inverse_feasible,
            )
            if teacher is not None:
                with torch.no_grad():
                    teacher_prediction = teacher(batch.inputs)
                distillation = F.smooth_l1_loss(prediction, teacher_prediction)
                loss = loss + distillation
                components["distillation_loss"] = distillation
            if not bool(torch.isfinite(loss)):
                raise FloatingPointError(
                    f"non-finite {model_name} loss at update {update}"
                )
            loss.backward()
            if not all(
                parameter.grad is None or bool(torch.isfinite(parameter.grad).all())
                for parameter in model.parameters()
            ):
                raise FloatingPointError(
                    f"non-finite {model_name} gradient at update {update}"
                )
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            completed_updates = update
            if update % config.validation_interval == 0 or update == config.maximum_updates:
                validation = _evaluate_relation_model(
                    model,
                    validation_examples,
                    batch_size=config.batch_size,
                    device=device,
                )
                record = {
                    "update": update,
                    "train_objective": float(loss.detach()),
                    **{
                        name: float(value.detach())
                        for name, value in components.items()
                    },
                    **validation,
                }
                metrics.write(
                    json.dumps(record, sort_keys=True, separators=(",", ":"))
                    + "\n"
                )
                metrics.flush()
                os.fsync(metrics.fileno())
                objective = float(validation["validation_objective"])
                if objective < best_objective - 1e-12:
                    best_objective = objective
                    best_update = update
                    stale_evaluations = 0
                    temporary = best_path.with_suffix(".pt.tmp")
                    torch.save(model.state_dict(), temporary)
                    os.replace(temporary, best_path)
                else:
                    stale_evaluations += 1
                if (
                    update >= config.minimum_updates
                    and stale_evaluations >= config.early_stopping_patience
                ):
                    stopped_early = True
                    break
    model.load_state_dict(torch.load(best_path, map_location=device, weights_only=True))
    final_validation = _evaluate_relation_model(
        model,
        validation_examples,
        batch_size=config.batch_size,
        device=device,
    )
    profile_batch = RelationLearningCorpus.collate(
        validation_examples[: min(config.batch_size, len(validation_examples))]
    )
    profile = _inference_profile(
        model,
        profile_batch,
        repetitions=config.latency_repetitions,
        device=device,
    )
    result: dict[str, object] = {
        "model_name": model_name,
        "status": "PASS",
        "all_finite": True,
        "parameter_count": sum(parameter.numel() for parameter in model.parameters()),
        "completed_updates": completed_updates,
        "best_update": best_update,
        "stopped_early": stopped_early,
        "wall_seconds": time.perf_counter() - started,
        **final_validation,
        **profile,
        "metrics_sha256": _sha256(metrics_path),
        "best_checkpoint_sha256": _sha256(best_path),
    }
    _write_json(output_dir / "summary.json", result)
    return result


def _markdown_comparison(result: dict[str, object]) -> str:
    kan = result["teachers"]["cr_kan"]  # type: ignore[index]
    mlp = result["teachers"]["matched_mlp"]  # type: ignore[index]
    return "\n".join(
        (
            "# Relation Teacher Comparison",
            "",
            "This stage learns cross-sample relation regularities from rotation-invariant "
            "scalars. It is separate from persistent sample-specific relation memory and "
            "does not act as the reverse assembly policy.",
            "",
            "| Backend | Parameters | Updates | Relation MAE | Inverse Brier | p50 latency (s) |",
            "|---|---:|---:|---:|---:|---:|",
            f"| CR-KAN T-S | {kan['parameter_count']} | {kan['completed_updates']} | "
            f"{kan['held_out_relation_mae']:.6f} | {kan['inverse_relation_brier']:.6f} | "
            f"{kan['p50_latency_seconds']:.6f} |",
            f"| Matched MLP | {mlp['parameter_count']} | {mlp['completed_updates']} | "
            f"{mlp['held_out_relation_mae']:.6f} | {mlp['inverse_relation_brier']:.6f} | "
            f"{mlp['p50_latency_seconds']:.6f} |",
            "",
            f"Selected relation-library backend: `{result['selected_backend']}`.",
            "",
            "KAN failure or underperformance only changes the relation-library backend; "
            "it does not disable C0/C1 or replace the independent assembly generator.",
            "",
        )
    )


def run_relation_stage(
    *,
    corpus: RelationLearningCorpus,
    train_split: str,
    validation_split: str,
    config: RelationTrainingConfig,
    output_dir: str | Path,
    phase2a_manifest_sha256: str,
    code_sha256: str,
    student_maximum_updates: int = 4000,
    student_minimum_updates: int = 1600,
    student_validation_interval: int = 400,
) -> dict[str, object]:
    output_dir = Path(output_dir)
    if output_dir.exists():
        raise FileExistsError(f"relation stage refuses to overwrite: {output_dir}")
    output_dir.mkdir(parents=True)
    train_examples = corpus.examples(train_split)
    validation_examples = corpus.examples(validation_split)
    if not train_examples or not validation_examples:
        raise RuntimeError("relation stage requires non-empty train and validation splits")

    initialization_seed = derive_named_seed(
        config.root_seed, "relation:teacher-common-initialization"
    )
    torch.manual_seed(initialization_seed)
    kan = CRKANTeacher(input_dim=22, hidden_dim=7, grid_size=15)
    torch.manual_seed(initialization_seed)
    mlp = MatchedMLPTeacher(input_dim=22, hidden_dim=64, prior_dim=16)
    kan_parameters = sum(parameter.numel() for parameter in kan.parameters())
    mlp_parameters = sum(parameter.numel() for parameter in mlp.parameters())
    parameter_gap = abs(kan_parameters - mlp_parameters) / mlp_parameters
    if parameter_gap > 0.01:
        raise RuntimeError("KAN and MLP teachers are not parameter matched")

    teachers_dir = output_dir / "teachers"
    teachers_dir.mkdir()
    kan_result = _train_relation_model(
        model=kan,
        model_name="cr_kan",
        train_examples=train_examples,
        validation_examples=validation_examples,
        config=config,
        output_dir=teachers_dir / "cr_kan",
    )
    mlp_result = _train_relation_model(
        model=mlp,
        model_name="matched_mlp",
        train_examples=train_examples,
        validation_examples=validation_examples,
        config=config,
        output_dir=teachers_dir / "matched_mlp",
    )
    kan_quality_win = (
        float(kan_result["held_out_relation_mae"])
        < float(mlp_result["held_out_relation_mae"])
        or float(kan_result["inverse_relation_brier"])
        < float(mlp_result["inverse_relation_brier"])
    )
    kan_latency_pass = float(kan_result["p50_latency_seconds"]) <= 5.0 * max(
        float(mlp_result["p50_latency_seconds"]), 1e-12
    )
    kan_selected = kan_quality_win and kan_latency_pass
    selected_backend = "matched_mlp"
    library_model: MatchedMLPTeacher = mlp
    student_result: dict[str, object] | None = None
    mlp.cpu()
    if kan_selected:
        student_config = RelationTrainingConfig(
            root_seed=config.root_seed,
            device=config.device,
            batch_size=config.batch_size,
            learning_rate=config.learning_rate,
            weight_decay=config.weight_decay,
            maximum_updates=student_maximum_updates,
            minimum_updates=student_minimum_updates,
            validation_interval=student_validation_interval,
            early_stopping_patience=config.early_stopping_patience,
            latency_repetitions=config.latency_repetitions,
        )
        student = RelationStudent(input_dim=22, hidden_dim=64, prior_dim=16)
        student_result = _train_relation_model(
            model=student,
            model_name="relation_student",
            train_examples=train_examples,
            validation_examples=validation_examples,
            config=student_config,
            output_dir=output_dir / "student",
            teacher=kan,
        )
        student_pass = (
            bool(student_result["all_finite"])
            and float(student_result["validation_objective"])
            <= float(kan_result["validation_objective"]) * 1.05 + 1e-6
            and float(student_result["p50_latency_seconds"])
            < float(kan_result["p50_latency_seconds"])
            and int(student_result["peak_allocated_vram_bytes"])
            <= int(kan_result["peak_allocated_vram_bytes"])
        )
        if student_pass:
            selected_backend = "student_mlp"
            library_model = student
    else:
        kan.cpu()

    library_state_path = output_dir / "relation_library_state_dict.pt"
    torch.save(library_model.relation_library_state_dict(), library_state_path)
    artifact = {
        "schema_version": "g1-relation-library-artifact.1.0.0",
        "status": "PASS",
        "selected_backend": selected_backend,
        "rotation_invariants_only": True,
        "directional_inputs_present": False,
        "cross_sample_lifecycle": True,
        "sample_specific_memory_included": False,
        "generation_backend": False,
        "assembly_policy_included": False,
        "input_dimension": 22,
        "invariant_dimension": 11,
        "availability_dimension": 11,
        "prior_dimension": 16,
        "state_dict_file": library_state_path.name,
        "state_dict_sha256": _sha256(library_state_path),
        "phase2a_manifest_sha256": phase2a_manifest_sha256,
        "code_sha256": code_sha256,
        "root_seed": config.root_seed,
        "teacher_parameter_relative_gap": parameter_gap,
        "train_example_count": len(train_examples),
        "validation_example_count": len(validation_examples),
        "no_refill": True,
    }
    _write_json(output_dir / "RELATION_LIBRARY_ARTIFACT.json", artifact)
    result: dict[str, object] = {
        "status": "PASS",
        "selected_backend": selected_backend,
        "kan_teacher_selected": kan_selected,
        "student_attempted": student_result is not None,
        "teachers": {"cr_kan": kan_result, "matched_mlp": mlp_result},
        "student": student_result,
        "artifact": artifact,
        "phase2a_manifest_sha256": phase2a_manifest_sha256,
        "code_sha256": code_sha256,
        "training_config_sha256": config.sha256(),
    }
    _write_json(output_dir / "relation_stage_summary.json", result)
    (output_dir / "RELATION_TEACHER_COMPARISON.md").write_text(
        _markdown_comparison(result), encoding="utf-8"
    )
    return result
