from __future__ import annotations

import json
from typing import Mapping, Sequence


REQUIRED_STEP_FIELDS = frozenset(
    {
        "stream_seed",
        "arm",
        "parent_id",
        "step_index",
        "active_orbit_summary",
        "remaining_composition",
        "target_space_group",
        "legal_candidate_count",
        "candidate_observable_action_signatures",
        "positive_action_class_signatures",
        "learned_candidate_probabilities",
        "chosen_action_signature",
        "chosen_action_probability",
        "positive_set_probability_mass",
        "strict_parent_orbit_id_match",
        "observable_positive_class_match",
        "mdn_sample_seed",
        "sampled_free_parameters",
        "official_expansion_status",
        "projector_accepted",
        "projector_rejection_reason",
        "minimum_interatomic_distance_angstrom",
        "terminal_composition_match",
        "terminal_target_sg_match",
        "terminal_legal_status",
    }
)


def geometry_event_key(
    stream_seed: int,
    parent_id: str,
    step_index: int,
    observable_action_signature: Sequence[object],
) -> str:
    signature = json.dumps(list(observable_action_signature), separators=(",", ":"))
    return f"geometry:{int(stream_seed)}:{parent_id}:{int(step_index)}:{signature}"


def classify_off_parent_trajectory(records: Sequence[Mapping[str, object]]) -> str:
    if not records:
        return "UNRESOLVED"
    first_off = next(
        (
            index
            for index, row in enumerate(records)
            if not bool(row.get("strict_parent_orbit_id_match", False))
        ),
        None,
    )
    if first_off is None:
        return "NO_OFF_PARENT_ACTION"
    first = records[first_off]
    last = records[-1]
    failure = last.get("trajectory_failure")
    if failure == "NO_LEGAL_ACTION":
        return "DISCRETE_DEAD_END"
    if failure in {"NONFINITE", "EXPANSION_FAILURE"}:
        return "UNRESOLVED"
    rejected = next(
        (
            index
            for index, row in enumerate(records[first_off:], start=first_off)
            if row.get("projector_accepted") is False
        ),
        None,
    )
    if rejected is not None:
        return (
            "IMMEDIATE_GEOMETRY_REJECTION"
            if rejected == first_off
            else "LATER_GEOMETRY_REJECTION"
        )
    if bool(last.get("terminal_legal_status", False)):
        if bool(first.get("observable_positive_class_match", False)):
            return "OBSERVABLE_IDENTITY_ALIAS"
        return "ALTERNATIVE_LEGAL_TERMINAL"
    if not bool(last.get("terminal_composition_match", False)) or not bool(
        last.get("terminal_target_sg_match", False)
    ):
        return "WRONG_TARGET_TERMINAL"
    return "UNRESOLVED"


def next_model_target(class_counts: Mapping[str, int]) -> str:
    grouped = {
        "ACTION_EQUIVALENCE_CLASS_OBJECTIVE": int(
            class_counts.get("OBSERVABLE_IDENTITY_ALIAS", 0)
        ),
        "TERMINAL_VALIDITY_OBJECTIVE": int(
            class_counts.get("ALTERNATIVE_LEGAL_TERMINAL", 0)
        ),
        "JOINT_ACTION_CONDITIONED_GEOMETRY": int(
            class_counts.get("IMMEDIATE_GEOMETRY_REJECTION", 0)
        )
        + int(class_counts.get("LATER_GEOMETRY_REJECTION", 0)),
        "LONG_HORIZON_ACTION_REPRESENTATION": int(
            class_counts.get("DISCRETE_DEAD_END", 0)
        ),
    }
    total = sum(grouped.values())
    if total == 0:
        return "MIXED_REQUIRES_USER_DECISION"
    target, count = max(grouped.items(), key=lambda item: (item[1], item[0]))
    return target if count / total > 0.5 else "MIXED_REQUIRES_USER_DECISION"


__all__ = [
    "REQUIRED_STEP_FIELDS",
    "classify_off_parent_trajectory",
    "geometry_event_key",
    "next_model_target",
]
