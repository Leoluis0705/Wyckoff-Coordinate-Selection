from __future__ import annotations

import math
from collections import defaultdict
from collections.abc import Mapping, Sequence, Set
from fractions import Fraction

import numpy as np

from crysalis_g1.experiments.full_orbit_operator import paired_bootstrap

DEVELOPMENT_SPLITS = frozenset({"policy_train", "policy_validation"})
STAGE_TARGETS = {
    "EARLY": Fraction(1, 4),
    "MID": Fraction(1, 2),
    "LATE": Fraction(3, 4),
}


def _action_key(orbit: Mapping[str, object]) -> tuple[str, int, int, int]:
    return (
        str(orbit["wyckoff_letter"]),
        int(orbit["species"]),
        int(orbit["multiplicity"]),
        len(orbit.get("free_parameters", [])),
    )


def assemble_depth_event_pool(
    parent_payloads: Mapping[str, Mapping[str, object]],
    graph_rows: Sequence[Mapping[str, object]],
    *,
    forbidden_parent_ids: Set[str],
) -> list[dict[str, object]]:
    """Enumerate structural-only, graph-positive depth events.

    Official compiler and expansion checks are deliberately performed by the runner
    before final cohort selection because those checks require live domain objects.
    """

    forbidden = {str(value) for value in forbidden_parent_ids}
    result: list[dict[str, object]] = []
    for graph_line_number, row in enumerate(graph_rows, start=1):
        parent_id = str(row["parent_id"])
        split = str(row["split"])
        if parent_id in forbidden or split not in DEVELOPMENT_SPLITS:
            continue
        parent = parent_payloads.get(parent_id)
        if parent is None or not bool(parent.get("passed", False)):
            continue
        orbits = [dict(value) for value in parent["orbits"]]  # type: ignore[index]
        orbit_ids = [str(orbit["orbit_instance_id"]) for orbit in orbits]
        if len(orbit_ids) != len(set(orbit_ids)):
            raise ValueError(f"duplicate canonical orbit identity: {parent_id}")
        active_ids = tuple(str(value) for value in row["active_orbit_ids"])  # type: ignore[index]
        active_set = set(active_ids)
        if not active_set or not active_set <= set(orbit_ids):
            continue
        missing_ids = set(orbit_ids) - active_set
        if len(missing_ids) <= 1:
            continue
        positive_ids = {
            str(value) for value in row.get("positive_orbit_ids", [])  # type: ignore[arg-type]
        }
        positive_keys = {
            tuple(value) for value in row.get("positive_action_keys", [])  # type: ignore[arg-type]
        }
        eligible_targets = []
        for canonical_index, orbit in enumerate(orbits):
            orbit_id = str(orbit["orbit_instance_id"])
            free_dof = len(orbit.get("free_parameters", []))
            action_key = _action_key(orbit)
            if (
                orbit_id in missing_ids
                and orbit_id in positive_ids
                and 1 <= free_dof <= 3
                and (not positive_keys or action_key in positive_keys)
            ):
                eligible_targets.append((canonical_index, orbit))
        if not eligible_targets:
            continue
        canonical_index, target = eligible_targets[0]
        active_ranks = tuple(sorted(orbit_ids.index(value) for value in active_ids))
        final_orbit_count = len(orbits)
        active_orbit_count = len(active_ids)
        crystal_system = str(parent["lattice"]["crystal_system"])  # type: ignore[index]
        target_id = str(target["orbit_instance_id"])
        result.append(
            {
                "event_base_id": (
                    f"assembly-depth:{parent_id}:graph-{graph_line_number:06d}:"
                    f"{target_id}"
                ),
                "parent_id": parent_id,
                "original_split_source": split,
                "crystal_system": crystal_system,
                "target_space_group": int(parent["target_space_group"]),
                "graph_line_number": graph_line_number,
                "active_orbit_ids": active_ids,
                "active_orbit_ranks": active_ranks,
                "active_orbit_count": active_orbit_count,
                "final_orbit_count": final_orbit_count,
                "active_orbit_fraction": active_orbit_count / final_orbit_count,
                "missing_orbit_count": len(missing_ids),
                "canonical_event_index": canonical_index,
                "target_orbit_id": target_id,
                "wyckoff_position_id": str(target["wyckoff_position_id"]),
                "wyckoff_letter": str(target["wyckoff_letter"]),
                "species": int(target["species"]),
                "multiplicity": int(target["multiplicity"]),
                "free_dof": len(target.get("free_parameters", [])),
                "parent_u_star": tuple(
                    float(value) for value in target["free_parameters"]
                ),
            }
        )
    return result


def _stage_choice(
    rows: Sequence[Mapping[str, object]], stage: str
) -> dict[str, object]:
    target = STAGE_TARGETS[stage]
    selected = min(
        rows,
        key=lambda row: (
            abs(
                Fraction(int(row["active_orbit_count"]), int(row["final_orbit_count"]))
                - target
            ),
            tuple(int(value) for value in row["active_orbit_ranks"]),
            int(row["canonical_event_index"]),
            str(row["wyckoff_position_id"]),
            int(row["species"]),
            int(row["multiplicity"]),
            int(row["graph_line_number"]),
        ),
    )
    event = dict(selected)
    event["stage"] = stage
    event["stage_target_fraction"] = float(target)
    event["stage_fraction_absolute_error"] = abs(
        float(event["active_orbit_fraction"]) - float(target)
    )
    event["event_id"] = f"{event['event_base_id']}:{stage.lower()}"
    return event


def _systematic_stratified_parent_selection(
    parent_events: Mapping[str, Sequence[Mapping[str, object]]], *, target_n: int
) -> list[str]:
    grouped: dict[tuple[str, str, int], list[str]] = defaultdict(list)
    for parent_id, events in parent_events.items():
        first = events[0]
        key = (
            str(first["original_split_source"]),
            str(first["crystal_system"]),
            int(first["final_orbit_count"]),
        )
        grouped[key].append(str(parent_id))
    if target_n <= 0 or target_n > len(parent_events):
        raise ValueError("target parent count is outside the eligible cohort")
    keys = sorted(grouped)
    if len(keys) > target_n:
        raise ValueError("target parent count cannot cover every structural stratum")
    allocation = {key: 1 for key in keys}
    remaining = target_n - len(keys)
    capacities = {key: len(grouped[key]) - 1 for key in keys}
    total_capacity = sum(capacities.values())
    quotas = {
        key: (remaining * capacities[key] / total_capacity if total_capacity else 0.0)
        for key in keys
    }
    for key in keys:
        allocation[key] += int(math.floor(quotas[key]))
    leftover = target_n - sum(allocation.values())
    for key in sorted(
        keys, key=lambda value: (-(quotas[value] - math.floor(quotas[value])), value)
    ):
        if leftover == 0:
            break
        if allocation[key] < len(grouped[key]):
            allocation[key] += 1
            leftover -= 1
    if leftover:
        raise RuntimeError("deterministic stratum allocation did not fill the cohort")
    selected_by_key: dict[tuple[str, str, int], list[str]] = {}
    for key in keys:
        values = sorted(grouped[key])
        take_n = allocation[key]
        positions = [
            int(math.floor((rank + 0.5) * len(values) / take_n))
            for rank in range(take_n)
        ]
        if len(positions) != len(set(positions)):
            raise RuntimeError(f"systematic positions collided in stratum {key}")
        selected_by_key[key] = [values[position] for position in positions]
    selected: list[str] = []
    for rank in range(max(map(len, selected_by_key.values()))):
        for key in keys:
            if rank < len(selected_by_key[key]):
                selected.append(selected_by_key[key][rank])
    if len(selected) != target_n or len(set(selected)) != target_n:
        raise RuntimeError("deterministic parent selection count mismatch")
    return selected


def select_depth_cohort(
    event_pool: Sequence[Mapping[str, object]], *, target_parent_n: int = 32
) -> list[dict[str, object]]:
    grouped: dict[str, list[Mapping[str, object]]] = defaultdict(list)
    for event in event_pool:
        grouped[str(event["parent_id"])].append(event)
    complete: dict[str, list[dict[str, object]]] = {}
    for parent_id, rows in grouped.items():
        stage_rows = [_stage_choice(rows, stage) for stage in STAGE_TARGETS]
        if len({int(row["active_orbit_count"]) for row in stage_rows}) != 3:
            continue
        complete[parent_id] = stage_rows
    selected_ids = _systematic_stratified_parent_selection(
        complete, target_n=target_parent_n
    )
    result = [
        dict(event) for parent_id in selected_ids for event in complete[parent_id]
    ]
    if len(result) != target_parent_n * 3:
        raise RuntimeError("selected event count mismatch")
    return result


def paired_force_comparison(
    mlp_force: np.ndarray,
    baseline_force: np.ndarray,
    *,
    seed: int,
    resamples: int = 10_000,
) -> dict[str, float | int]:
    result = paired_bootstrap(
        np.asarray(mlp_force, dtype=float),
        np.asarray(baseline_force, dtype=float),
        resamples=resamples,
        seed=seed,
    )
    return {**result, "pair_n": int(len(mlp_force))}


def generalization_verdict(
    *,
    random_by_stage: Mapping[str, Mapping[str, float]],
    direct_by_stage: Mapping[str, Mapping[str, float]],
) -> dict[str, object]:
    expected = set(STAGE_TARGETS)
    if set(random_by_stage) != expected or set(direct_by_stage) != expected:
        raise ValueError("verdict requires EARLY, MID, and LATE comparisons")
    stage_signal = {
        stage: (
            "SUPPORTED"
            if float(random_by_stage[stage]["ci_upper"]) < 0.0
            and float(random_by_stage[stage]["win_rate"]) >= 0.65
            else "NOT_SUPPORTED"
        )
        for stage in STAGE_TARGETS
    }
    supported_n = sum(value == "SUPPORTED" for value in stage_signal.values())
    significant_reverse = any(
        stage_signal[stage] != "SUPPORTED"
        and float(random_by_stage[stage]["ci_lower"]) > 0.0
        for stage in STAGE_TARGETS
    )
    if supported_n >= 2 and not significant_reverse:
        overall = "SUPPORTED"
        next_action = "CRYSALIS_INTEGRATED_WHAT_WHERE_POC"
    elif stage_signal == {
        "EARLY": "NOT_SUPPORTED",
        "MID": "NOT_SUPPORTED",
        "LATE": "SUPPORTED",
    }:
        overall = "LATE_ONLY"
        next_action = "BUILD_MULTI_DEPTH_COMPATIBILITY_DATASET"
    else:
        overall = "NOT_SUPPORTED"
        next_action = "RETURN_TO_TERMINAL_ONLY_COMPATIBILITY"
    direct_supported_n = sum(
        float(direct_by_stage[stage]["ci_upper"]) < 0.0 for stage in STAGE_TARGETS
    )
    return {
        "stage_signal": stage_signal,
        "assembly_depth_generalization": overall,
        "compatibility_beats_direct_mdn": (
            "SUPPORTED" if direct_supported_n >= 2 else "NOT_SUPPORTED"
        ),
        "direct_supported_stage_n": direct_supported_n,
        "next_action": next_action,
    }


__all__ = [
    "DEVELOPMENT_SPLITS",
    "STAGE_TARGETS",
    "assemble_depth_event_pool",
    "generalization_verdict",
    "paired_force_comparison",
    "select_depth_cohort",
]
