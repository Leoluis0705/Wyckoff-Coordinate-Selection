from __future__ import annotations

import hashlib
import math
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import torch

from crysalis_g1.experiments.c0_symmetry_data import decode_lattice_degrees
from crysalis_g1.experiments.c0_symmetry_evaluation import (
    _canonical_cell_transform,
    _embryo_lattice,
    _inference_example,
    _model_output,
)
from crysalis_g1.experiments.contribution_state_graph import ActionDescription
from crysalis_g1.experiments.contribution_training import (
    ActionScorerTrainingConfig,
)
from crysalis_g1.model.action_viability import (
    FEATURE_BLOCK_SLICES,
    FEATURE_DIMENSION,
    ActionViabilityConfig,
    ActionViabilityScorer,
    CurrentOrbitSummary,
    FeatureMode,
    encode_state_action_features,
)
from crysalis_g1.symmetry.assembly import (
    AddOrbitAction,
    C0SymmetryProjector,
    LegalAddOrbit,
    SpaceGroupLegalActionCompiler,
    SymmetryAssemblyState,
)

CONDITION_ROOT_SEED = 20260823
FORMAL_CONDITION_COUNT = 300
FORMAL_COMPLETED_UPDATES = 5_000
FORMAL_MAX_SITES = 20
FROZEN_TEMPERATURE = 0.8
FROZEN_MINIMUM_DISTANCE = 0.5
FROZEN_C0_CHECKPOINT_SHA256 = (
    "8cf3a9a2ee27626a1719fa0d8cbc084efd23b9e614c1a60e4f560b92554c91d4"
)
FROZEN_CONDITION_MANIFEST_SHA256 = (
    "0d8308b3d6fdd5539302ae19aca6b38952aecef7016942ec46a8ef7493200961"
)
SCORER_CHECKPOINT_SCHEMA_VERSION = (
    "g1-contribution-action-scorer-checkpoint.1.0.0"
)
ALLOWED_SCORER_TRAINING_SEEDS = frozenset({20260823, 20260824, 20260825})
_CONDITION_FIELDS = frozenset(
    {
        "condition_id",
        "attempt_index",
        "root_seed",
        "condition_seed",
        "composition",
        "space_group",
    }
)
_SCORER_FEATURE_FIELDS = (
    "target_space_group",
    "full_composition",
    "remaining_composition",
    "present_orbits",
    "lattice_degrees",
    "action",
)


@dataclass(frozen=True, slots=True)
class LoadedActionScorer:
    model: ActionViabilityScorer
    feature_mode: FeatureMode
    training_seed: int
    checkpoint_sha256: str
    trainable_parameter_count: int


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _is_sha256(value: object) -> bool:
    if not isinstance(value, str) or len(value) != 64:
        return False
    try:
        int(value, 16)
    except ValueError:
        return False
    return True


def _expected_feature_schema() -> dict[str, object]:
    return {
        "dimension": FEATURE_DIMENSION,
        "blocks": {
            name: {"start": section.start, "stop": section.stop}
            for name, section in FEATURE_BLOCK_SLICES.items()
        },
        "final_set_zeroed_blocks": (
            "remaining_composition",
            "current_wyckoff",
            "current_species",
            "current_multiplicity",
            "progress",
        ),
    }


def load_action_scorer_checkpoint(
    checkpoint_path: str | Path,
    *,
    expected_sha256: str,
    expected_mode: FeatureMode,
    expected_training_seed: int,
    expected_initial_state_sha256: str,
    device: str,
) -> LoadedActionScorer:
    """Load one completed formal scorer checkpoint after fail-closed validation."""

    if expected_mode not in ("GRAPH_VIABILITY", "FINAL_SET_MEMBERSHIP"):
        raise ValueError("unsupported scorer feature mode")
    if expected_training_seed not in ALLOWED_SCORER_TRAINING_SEEDS:
        raise ValueError("unsupported scorer training seed")
    if not _is_sha256(expected_initial_state_sha256):
        raise ValueError("expected scorer initial-state hash is invalid")
    path = Path(checkpoint_path)
    observed_sha256 = _file_sha256(path)
    if observed_sha256 != expected_sha256:
        raise ValueError("scorer checkpoint SHA-256 mismatch")
    payload = torch.load(path, map_location=device, weights_only=False)
    if not isinstance(payload, Mapping):
        raise ValueError("scorer checkpoint payload must be a mapping")
    if payload.get("schema_version") != SCORER_CHECKPOINT_SCHEMA_VERSION:
        raise ValueError("unsupported scorer checkpoint schema")
    if payload.get("feature_mode") != expected_mode:
        raise ValueError("scorer checkpoint feature mode mismatch")
    if payload.get("completed_updates") != FORMAL_COMPLETED_UPDATES:
        raise ValueError("scorer checkpoint must prove exactly 5000 completed updates")
    if payload.get("feature_schema") != _expected_feature_schema():
        raise ValueError("scorer checkpoint feature schema mismatch")
    training_config = payload.get("training_config")
    if not isinstance(training_config, Mapping):
        raise ValueError("scorer checkpoint training configuration is missing")
    if training_config.get("root_seed") != expected_training_seed:
        raise ValueError("scorer checkpoint training seed mismatch")
    expected_training_config = asdict(
        ActionScorerTrainingConfig(root_seed=expected_training_seed)
    )
    if dict(training_config) != expected_training_config:
        raise ValueError("scorer checkpoint training configuration mismatch")
    if payload.get("restart_or_checkpoint_reload") is not False:
        raise ValueError("scorer checkpoint does not prove uninterrupted training")
    if payload.get("initial_state_sha256") != expected_initial_state_sha256:
        raise ValueError("scorer checkpoint initial-state hash mismatch")
    validation_loss = payload.get("validation_loss")
    if (
        isinstance(validation_loss, bool)
        or not isinstance(validation_loss, (int, float))
        or not math.isfinite(float(validation_loss))
    ):
        raise ValueError("scorer checkpoint validation loss must be finite")

    raw_model_config = payload.get("model_config")
    if not isinstance(raw_model_config, Mapping):
        raise ValueError("scorer checkpoint model configuration is missing")
    try:
        model_config = ActionViabilityConfig(**dict(raw_model_config))
    except (TypeError, ValueError) as error:
        raise ValueError("scorer checkpoint parameter configuration mismatch") from error
    if model_config != ActionViabilityConfig():
        raise ValueError("scorer checkpoint parameter configuration mismatch")
    model = ActionViabilityScorer(model_config).to(device)
    expected_parameter_count = model.trainable_parameter_count()
    if payload.get("trainable_parameter_count") != expected_parameter_count:
        raise ValueError("scorer checkpoint parameter count mismatch")
    try:
        model.load_state_dict(payload["model_state_dict"], strict=True)
    except (KeyError, RuntimeError) as error:
        raise ValueError("scorer checkpoint model state mismatch") from error
    if not all(bool(torch.isfinite(parameter).all()) for parameter in model.parameters()):
        raise ValueError("scorer checkpoint contains non-finite parameters")
    model.eval()
    return LoadedActionScorer(
        model=model,
        feature_mode=expected_mode,
        training_seed=expected_training_seed,
        checkpoint_sha256=observed_sha256,
        trainable_parameter_count=expected_parameter_count,
    )


def _action_description(action: LegalAddOrbit) -> ActionDescription:
    return ActionDescription(
        operator="D_orbit",
        wyckoff_letter=action.wyckoff_letter,
        atomic_number=action.species,
        multiplicity=action.multiplicity,
        free_parameter_count=action.free_parameter_count,
    )


def _score_legal_actions(
    scorer: LoadedActionScorer,
    *,
    state: SymmetryAssemblyState,
    legal_actions: Sequence[LegalAddOrbit],
) -> tuple[tuple[ActionDescription, ...], torch.Tensor]:
    descriptions = tuple(_action_description(action) for action in legal_actions)
    present_orbits = tuple(
        CurrentOrbitSummary(
            wyckoff_letter=orbit.wyckoff_letter,
            atomic_number=orbit.species,
            multiplicity=orbit.multiplicity,
        )
        for orbit in state.orbits
    )
    features = torch.stack(
        tuple(
            encode_state_action_features(
                mode=scorer.feature_mode,
                target_space_group=state.target_space_group,
                full_composition=state.composition,
                remaining_composition=state.remaining_composition,
                present_orbits=present_orbits,
                lattice_degrees=state.lattice.conventional_parameters,
                action=description,
            )
            for description in descriptions
        )
    ).to(next(scorer.model.parameters()).device)
    with torch.no_grad():
        logits = scorer.model(features)
    if logits.shape != (len(legal_actions),) or not bool(torch.isfinite(logits).all()):
        raise FloatingPointError("scorer produced invalid legal-action logits")
    return descriptions, logits.detach().cpu()


def _derive_policy_seed(
    *, condition_id: str, arm: FeatureMode, training_seed: int
) -> tuple[str, int]:
    namespace = f"contribution_rollout:{arm}:training_seed:{training_seed}"
    digest = hashlib.sha256(
        f"{CONDITION_ROOT_SEED}:{namespace}:{condition_id}".encode("utf-8")
    ).digest()
    return namespace, int.from_bytes(digest[:8], "big") % (2**63)


def _validate_protocol(
    model: Any,
    conditions: Sequence[Mapping[str, Any]],
    *,
    arm: FeatureMode,
    scorer_training_seed: int,
    condition_root_seed: int,
    condition_manifest_sha256: str,
    c0_checkpoint_sha256: str,
    temperature: float,
    minimum_distance: float,
) -> None:
    if arm not in ("GRAPH_VIABILITY", "FINAL_SET_MEMBERSHIP"):
        raise ValueError("unsupported contribution rollout arm")
    if scorer_training_seed not in ALLOWED_SCORER_TRAINING_SEEDS:
        raise ValueError("unsupported scorer training seed")
    if condition_root_seed != CONDITION_ROOT_SEED:
        raise ValueError("condition root seed must remain frozen at 20260823")
    if condition_manifest_sha256 != FROZEN_CONDITION_MANIFEST_SHA256:
        raise ValueError("frozen condition manifest SHA-256 mismatch")
    if c0_checkpoint_sha256 != FROZEN_C0_CHECKPOINT_SHA256:
        raise ValueError("frozen C0 checkpoint SHA-256 mismatch")
    if temperature != FROZEN_TEMPERATURE:
        raise ValueError("scorer temperature must remain frozen at 0.8")
    if minimum_distance != FROZEN_MINIMUM_DISTANCE:
        raise ValueError("minimum distance must remain frozen at 0.5")
    if getattr(model.config, "maximum_sites", None) != FORMAL_MAX_SITES:
        raise ValueError("frozen C0 model must use maximum_sites=20")
    if len(conditions) != FORMAL_CONDITION_COUNT:
        raise ValueError("scored rollout requires exactly 300 frozen conditions")
    observed_ids: set[str] = set()
    for expected_index, condition in enumerate(conditions):
        if set(condition) != _CONDITION_FIELDS:
            raise ValueError("condition fields do not match the frozen public schema")
        if int(condition["attempt_index"]) != expected_index:
            raise ValueError("condition attempt indices are not aligned")
        if int(condition["root_seed"]) != condition_root_seed:
            raise ValueError("condition root seed drifted")
        condition_id = str(condition["condition_id"])
        if not condition_id or condition_id in observed_ids:
            raise ValueError("condition identifiers must be non-empty and unique")
        observed_ids.add(condition_id)


def generate_scored_attempts(
    model: Any,
    conditions: Sequence[Mapping[str, Any]],
    *,
    arm: FeatureMode,
    scorer_checkpoint_path: str | Path,
    scorer_checkpoint_sha256: str,
    scorer_initial_state_sha256: str,
    scorer_training_seed: int,
    condition_root_seed: int,
    condition_manifest_sha256: str,
    c0_checkpoint_sha256: str,
    device: str,
    temperature: float = FROZEN_TEMPERATURE,
    minimum_distance: float = FROZEN_MINIMUM_DISTANCE,
) -> list[dict[str, Any]]:
    """Generate exactly the frozen conditions with scorer-only legal selection."""

    _validate_protocol(
        model,
        conditions,
        arm=arm,
        scorer_training_seed=scorer_training_seed,
        condition_root_seed=condition_root_seed,
        condition_manifest_sha256=condition_manifest_sha256,
        c0_checkpoint_sha256=c0_checkpoint_sha256,
        temperature=temperature,
        minimum_distance=minimum_distance,
    )
    scorer = load_action_scorer_checkpoint(
        scorer_checkpoint_path,
        expected_sha256=scorer_checkpoint_sha256,
        expected_mode=arm,
        expected_training_seed=scorer_training_seed,
        expected_initial_state_sha256=scorer_initial_state_sha256,
        device=device,
    )
    model = model.to(device).eval()
    compiler = SpaceGroupLegalActionCompiler(max_sites=FORMAL_MAX_SITES)
    projector = C0SymmetryProjector(minimum_distance=minimum_distance)
    records: list[dict[str, Any]] = []
    for condition_mapping in conditions:
        condition = dict(condition_mapping)
        started = time.perf_counter()
        composition = tuple(
            (int(atomic_number), int(count))
            for atomic_number, count in condition["composition"]
        )
        target_space_group = int(condition["space_group"])
        namespace, policy_seed = _derive_policy_seed(
            condition_id=str(condition["condition_id"]),
            arm=arm,
            training_seed=scorer_training_seed,
        )
        rng = np.random.default_rng(policy_seed)
        site_count = sum(count for _, count in composition)
        embryo_state = SymmetryAssemblyState.empty(
            target_space_group=target_space_group,
            composition=composition,
            lattice=_embryo_lattice(target_space_group, site_count),
        )
        embryo_output = _model_output(
            model,
            _inference_example(condition, embryo_state, ()),
            device=device,
        )
        cell_logits = embryo_output.cell_index_logits[0].detach().cpu().clone()
        cell_logits[0] = -math.inf
        cell_index = int(cell_logits.argmax())
        predicted_degrees = (
            embryo_output.lattice_degree_prediction[0].detach().cpu().tolist()
        )
        lattice = decode_lattice_degrees(
            target_space_group,
            predicted_degrees,
            cell_transform=_canonical_cell_transform(cell_index),
        )
        state = SymmetryAssemblyState.empty(
            target_space_group=target_space_group,
            composition=composition,
            lattice=lattice,
        )
        actions: list[dict[str, Any]] = []
        receipts = []
        selection_trace: list[dict[str, Any]] = []
        failure_code: str | None = None
        completed = False
        terminal_receipt = None
        for step_index in range(model.config.maximum_orbits + 1):
            legal_actions = compiler.legal_add_actions(state)
            output = _model_output(
                model,
                _inference_example(condition, state, legal_actions),
                device=device,
            )
            termination_requested = bool(
                int(output.terminate_logits[0].argmax().detach().cpu()) == 1
            )
            if not state.remaining_composition:
                terminal_receipt = projector.project(state)
                receipts.append(terminal_receipt)
                if termination_requested and compiler.can_terminate(
                    state, terminal_receipt
                ):
                    completed = True
                else:
                    failure_code = (
                        "TERMINATION_NOT_SELECTED"
                        if terminal_receipt.accepted
                        else "TERMINAL_PROJECTOR_REJECTED"
                    )
                break
            if not legal_actions:
                failure_code = "NO_LEGAL_ADD_ORBIT_ACTION"
                break
            descriptions, logits = _score_legal_actions(
                scorer,
                state=state,
                legal_actions=legal_actions,
            )
            probabilities = torch.softmax(logits / temperature, dim=0).numpy()
            if not np.isfinite(probabilities).all() or not np.isclose(
                probabilities.sum(), 1.0
            ):
                raise FloatingPointError("invalid scorer legal-action probabilities")
            selected_index = int(rng.choice(len(legal_actions), p=probabilities))
            selected = legal_actions[selected_index]
            selection_trace.append(
                {
                    "step_index": step_index,
                    "policy_namespace": namespace,
                    "policy_seed": policy_seed,
                    "scorer_training_seed": scorer_training_seed,
                    "scorer_feature_mode": arm,
                    "scorer_feature_fields": list(_SCORER_FEATURE_FIELDS),
                    "legal_action_descriptions": [
                        asdict(description) for description in descriptions
                    ],
                    "logits": logits.tolist(),
                    "probabilities": probabilities.tolist(),
                    "selected_index": selected_index,
                    "selected_action": asdict(descriptions[selected_index]),
                    "c0_legal_action": asdict(selected),
                    "temperature": temperature,
                    "scored_only_compiler_legal_actions": True,
                    "future_or_provenance_features_used": False,
                    "c0_discrete_action_logits_used": False,
                }
            )
            free = tuple(
                float(value)
                for value in output.free_parameter_prediction[
                    0, : selected.free_parameter_count
                ]
                .detach()
                .cpu()
                .tolist()
            )
            orbit_id = f"{condition['condition_id']}:orbit:{step_index}"
            next_state = compiler.apply_add(
                state,
                AddOrbitAction(
                    selected.wyckoff_letter,
                    selected.species,
                    free,
                    orbit_id,
                ),
            )
            receipt = projector.project(next_state)
            receipts.append(receipt)
            actions.append(
                {
                    "step_index": step_index,
                    "wyckoff_position_id": selected.wyckoff_position_id,
                    "wyckoff_letter": selected.wyckoff_letter,
                    "species": selected.species,
                    "multiplicity": selected.multiplicity,
                    "free_parameters": list(free),
                    "orbit_instance_id": orbit_id,
                    "termination_requested_while_illegal": termination_requested,
                    "projector": receipt.to_dict(),
                }
            )
            if not receipt.accepted:
                failure_code = "PROJECTOR_REJECTED"
                break
            state = next_state
        else:
            failure_code = "MAXIMUM_ORBIT_STEPS_EXCEEDED"

        final_receipt = terminal_receipt or (receipts[-1] if receipts else None)
        detected_space_group = (
            int(final_receipt.detected_space_groups.get(0.03, 0))
            if final_receipt is not None
            else 0
        )
        target_match = detected_space_group == target_space_group
        legal_terminal = bool(
            completed
            and final_receipt is not None
            and final_receipt.accepted
            and target_match
        )
        candidate = None
        if legal_terminal and final_receipt is not None:
            candidate = {
                "atomic_numbers": list(final_receipt.atomic_numbers),
                "fractional_coordinates": [
                    list(value) for value in final_receipt.fractional_coordinates
                ],
                "lattice": [list(value) for value in final_receipt.lattice],
                "orbit_states": [asdict(orbit) for orbit in state.orbits],
            }
        rejection_reasons = [
            reason
            for receipt in receipts
            if not receipt.accepted
            for reason in receipt.reason_codes
        ]
        records.append(
            {
                "condition": condition,
                "policy_arm": arm,
                "policy_namespace": namespace,
                "policy_seed": policy_seed,
                "scorer_training_seed": scorer_training_seed,
                "scorer_checkpoint_sha256": scorer.checkpoint_sha256,
                "scorer_initial_state_sha256": scorer_initial_state_sha256,
                "runtime_assertions": {
                    "C0_DISCRETE_ACTION_LOGITS_USED": False,
                    "SCORER_LEGAL_ACTIONS_ONLY": True,
                    "FUTURE_OR_PROVENANCE_FEATURES_USED": False,
                    "RETRY_OR_REFILL_USED": False,
                },
                "frozen_component_receipts": {
                    "c0_checkpoint_sha256": c0_checkpoint_sha256,
                    "condition_manifest_sha256": condition_manifest_sha256,
                    "lattice_source": "FROZEN_C0",
                    "free_parameter_source": "FROZEN_C0",
                    "legal_action_source": "FROZEN_C0_COMPILER",
                    "projector_source": "FROZEN_C0",
                    "termination_source": "FROZEN_C0",
                    "minimum_distance": minimum_distance,
                    "temperature": temperature,
                },
                "scorer_selection_trace": selection_trace,
                "selected_cell_index": cell_index,
                "selected_lattice_degrees": predicted_degrees,
                "selected_lattice": [list(value) for value in lattice.primitive_matrix],
                "actions": actions,
                "completed": completed,
                "legal_terminal_crystal": legal_terminal,
                "failure_code": failure_code,
                "pre_projector_target_space_group_match": target_match,
                "post_projector_target_space_group_match": target_match,
                "wyckoff_orbit_valid": bool(
                    final_receipt
                    and final_receipt.orbit_membership_valid
                    and final_receipt.distinct_orbit_instances_valid
                ),
                "composition_valid": bool(
                    final_receipt and final_receipt.composition_valid
                ),
                "multiplicity_valid": bool(
                    final_receipt and final_receipt.multiplicity_valid
                ),
                "short_contact_free": bool(
                    final_receipt and final_receipt.minimum_distance_valid
                ),
                "detected_space_group": detected_space_group,
                "projector_attempt_count": len(receipts),
                "projector_rejection_count": sum(
                    not receipt.accepted for receipt in receipts
                ),
                "projector_rejection_reasons": rejection_reasons,
                "candidate": candidate,
                "latency_seconds": time.perf_counter() - started,
                "retry_count": 0,
                "refill_count": 0,
            }
        )
    return records
