from __future__ import annotations

import math
from collections.abc import Mapping


def choose_external_parent_budget(
    *,
    elapsed_minutes_at_16: float,
    event_counts: Mapping[int, int],
    max_minutes: float = 35.0,
) -> int:
    if set(event_counts) != {128, 96}:
        raise ValueError("external ETA gate requires 128 and 96 parent event counts")
    if not math.isfinite(elapsed_minutes_at_16) or elapsed_minutes_at_16 <= 0.0:
        raise ValueError("elapsed time at 16 events must be positive and finite")
    for parent_n in (128, 96):
        projected = elapsed_minutes_at_16 * int(event_counts[parent_n]) / 16.0
        if projected <= max_minutes:
            return parent_n
    raise TimeoutError("projected 96-parent external validation exceeds 35 minutes")


def unique_selection_indices(
    *,
    context_index: int,
    orbit_index: int,
    contact_index: int,
    reference_index: int = 12,
) -> tuple[int, ...]:
    result = []
    for value in (context_index, orbit_index, contact_index, reference_index):
        index = int(value)
        if index < 0:
            raise ValueError("candidate indices must be nonnegative")
        if index not in result:
            result.append(index)
    return tuple(result)


def external_replication_verdict(
    *,
    orbit_ndcg5: float,
    context_ndcg5: float,
    orbit_top1_force: float,
    context_top1_force: float,
    ci_upper: float,
    nonreverse_stage_n: int,
) -> str:
    supported = (
        float(context_ndcg5) > float(orbit_ndcg5)
        and float(context_top1_force) < float(orbit_top1_force)
        and float(ci_upper) < 0.0
        and int(nonreverse_stage_n) >= 3
    )
    return "SUPPORTED" if supported else "NOT_SUPPORTED"


def second_mlip_verdict(
    *, mean_delta: float, ci_upper: float, win_rate: float
) -> str:
    if float(ci_upper) < 0.0 and float(win_rate) >= 0.60:
        return "SUPPORTED"
    if float(mean_delta) < 0.0:
        return "INCONCLUSIVE"
    return "NOT_SUPPORTED"


def external_stage_effect(stage_rows: Mapping[str, Mapping[str, float]]) -> str:
    required = {"EARLY", "MID", "LATE", "TERMINAL"}
    if set(stage_rows) != required:
        raise ValueError("stage effect requires EARLY, MID, LATE, and TERMINAL")
    clear_gain_n = sum(
        float(stage_rows[stage]["ndcg_delta"]) > 0.0
        and float(stage_rows[stage]["top1_force_delta"]) < 0.0
        for stage in ("MID", "LATE", "TERMINAL")
    )
    return "SUPPORTED" if clear_gain_n >= 2 else "NOT_SUPPORTED"


def nc_landscape_verdict(
    external_replication: str, second_mlip_value: str
) -> dict[str, str]:
    if external_replication != "SUPPORTED":
        return {
            "nc_landscape_core": "NOT_REPLICATED",
            "next_action": "REASSESS_NC_DIRECTION",
        }
    if second_mlip_value == "SUPPORTED":
        return {
            "nc_landscape_core": "STRONGLY_SUPPORTED",
            "next_action": "BOUNDED_DFT_LANDSCAPE_VALIDATION",
        }
    return {
        "nc_landscape_core": "SUPPORTED_PENDING_INDEPENDENT_PHYSICS",
        "next_action": "EXPAND_SECOND_MLIP_CHECK",
    }


__all__ = [
    "choose_external_parent_budget",
    "external_replication_verdict",
    "external_stage_effect",
    "nc_landscape_verdict",
    "second_mlip_verdict",
    "unique_selection_indices",
]
