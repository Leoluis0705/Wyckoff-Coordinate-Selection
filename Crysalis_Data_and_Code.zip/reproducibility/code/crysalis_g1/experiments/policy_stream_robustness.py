from __future__ import annotations

from collections import Counter
from statistics import fmean
from typing import Any, Mapping, Sequence

import numpy as np


def _binary_values(values: Sequence[bool]) -> np.ndarray:
    if not values:
        raise ValueError("binary outcome sequence must not be empty")
    return np.asarray([bool(value) for value in values], dtype=float)


def _aligned_streams(
    learned: Sequence[bool],
    baseline_streams: Mapping[str, Sequence[bool]],
) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    learned_array = _binary_values(learned)
    if not baseline_streams:
        raise ValueError("at least one baseline stream is required")
    streams: dict[str, np.ndarray] = {}
    for stream_id, values in sorted(baseline_streams.items()):
        array = _binary_values(values)
        if len(array) != len(learned_array):
            raise ValueError(
                f"baseline stream {stream_id!r} condition count does not match learned"
            )
        streams[str(stream_id)] = array
    return learned_array, streams


def hierarchical_paired_bootstrap(
    learned: Sequence[bool],
    baseline_streams: Mapping[str, Sequence[bool]],
    *,
    resamples: int,
    seed: int,
) -> dict[str, Any]:
    """Bootstrap frozen-policy deltas across policy streams and paired conditions."""

    if resamples <= 0:
        raise ValueError("resamples must be positive")
    learned_array, streams = _aligned_streams(learned, baseline_streams)
    stream_arrays = list(streams.values())
    observed = float(
        fmean(float(stream.mean() - learned_array.mean()) for stream in stream_arrays)
    )
    rng = np.random.default_rng(int(seed))
    draws = np.empty(int(resamples), dtype=float)
    stream_count = len(stream_arrays)
    condition_count = len(learned_array)
    for draw_index in range(int(resamples)):
        selected_streams = rng.integers(0, stream_count, size=stream_count)
        stream_deltas = []
        for selected_stream in selected_streams:
            condition_indices = rng.integers(0, condition_count, size=condition_count)
            baseline = stream_arrays[int(selected_stream)][condition_indices]
            paired_learned = learned_array[condition_indices]
            stream_deltas.append(float(np.mean(baseline - paired_learned)))
        draws[draw_index] = fmean(stream_deltas)
    lower, upper = np.quantile(draws, [0.025, 0.975])
    return {
        "observed_delta_baseline_minus_learned": observed,
        "confidence_interval_95": [float(lower), float(upper)],
        "stream_count": stream_count,
        "condition_count": condition_count,
        "resamples": int(resamples),
        "seed": int(seed),
        "uncertainty_scope": (
            "policy-stream and paired-condition uncertainty conditional on the "
            "frozen learned checkpoint and condition manifest; not training-seed "
            "uncertainty"
        ),
    }


def hierarchical_space_group_macro_bootstrap(
    learned_by_space_group: Mapping[int, Sequence[bool]],
    baseline_streams_by_space_group: Mapping[str, Mapping[int, Sequence[bool]]],
    *,
    resamples: int,
    seed: int,
) -> dict[str, Any]:
    if resamples <= 0:
        raise ValueError("resamples must be positive")
    if not learned_by_space_group or not baseline_streams_by_space_group:
        raise ValueError("space-group macro bootstrap requires non-empty inputs")
    learned = {
        int(space_group): _binary_values(values)
        for space_group, values in learned_by_space_group.items()
    }
    space_groups = sorted(learned)
    streams: dict[str, dict[int, np.ndarray]] = {}
    for stream_id, by_space_group in sorted(baseline_streams_by_space_group.items()):
        observed_groups = {int(value) for value in by_space_group}
        if observed_groups != set(space_groups):
            raise ValueError(
                f"baseline stream {stream_id!r} space-group set does not match learned"
            )
        stream: dict[int, np.ndarray] = {}
        for space_group in space_groups:
            values = _binary_values(by_space_group[space_group])
            if len(values) != len(learned[space_group]):
                raise ValueError(
                    f"baseline stream {stream_id!r} space-group {space_group} "
                    "condition count does not match learned"
                )
            stream[space_group] = values
        streams[str(stream_id)] = stream

    stream_values = list(streams.values())
    observed = float(
        fmean(
            fmean(
                float(stream[space_group].mean() - learned[space_group].mean())
                for space_group in space_groups
            )
            for stream in stream_values
        )
    )
    rng = np.random.default_rng(int(seed))
    draws = np.empty(int(resamples), dtype=float)
    stream_count = len(stream_values)
    for draw_index in range(int(resamples)):
        selected_streams = rng.integers(0, stream_count, size=stream_count)
        stream_macro_deltas: list[float] = []
        for selected_stream in selected_streams:
            stream = stream_values[int(selected_stream)]
            group_deltas: list[float] = []
            for space_group in space_groups:
                condition_count = len(learned[space_group])
                indices = rng.integers(0, condition_count, size=condition_count)
                group_deltas.append(
                    float(
                        np.mean(
                            stream[space_group][indices] - learned[space_group][indices]
                        )
                    )
                )
            stream_macro_deltas.append(fmean(group_deltas))
        draws[draw_index] = fmean(stream_macro_deltas)
    lower, upper = np.quantile(draws, [0.025, 0.975])
    return {
        "observed_macro_delta_baseline_minus_learned": observed,
        "confidence_interval_95": [float(lower), float(upper)],
        "space_groups": space_groups,
        "stream_count": stream_count,
        "resamples": int(resamples),
        "seed": int(seed),
        "uncertainty_scope": (
            "policy-stream and within-space-group paired-condition uncertainty "
            "conditional on the frozen learned checkpoint and condition manifest; "
            "not training-seed uncertainty"
        ),
    }


def summarize_binary_streams(
    learned: Sequence[bool],
    baseline_streams: Mapping[str, Sequence[bool]],
) -> dict[str, Any]:
    learned_array, streams = _aligned_streams(learned, baseline_streams)
    learned_rate = float(learned_array.mean())
    rates = {stream_id: float(values.mean()) for stream_id, values in streams.items()}
    better_count = sum(rate > learned_rate for rate in rates.values())
    return {
        "learned_rate": learned_rate,
        "baseline_stream_rates": rates,
        "baseline_mean_rate": float(fmean(rates.values())),
        "baseline_rate_range": [min(rates.values()), max(rates.values())],
        "baseline_better_stream_count": better_count,
        "baseline_better_stream_fraction": better_count / len(rates),
    }


def _selected_action_summary(records: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    multiplicities: list[float] = []
    free_parameter_counts: list[float] = []
    legal_action_counts: list[float] = []
    for record in records:
        trace_rows = list(record.get("policy_selection_trace", []))
        if trace_rows:
            for trace in trace_rows:
                selected = trace["selected_action"]
                multiplicities.append(float(selected["multiplicity"]))
                free_parameter_counts.append(float(selected["free_parameter_count"]))
                legal_action_counts.append(float(trace["legal_action_count"]))
            continue
        for action in record.get("actions", []):
            multiplicities.append(float(action["multiplicity"]))
            if "free_parameter_count" in action:
                free_parameter_counts.append(float(action["free_parameter_count"]))
            else:
                free_parameter_counts.append(
                    float(len(action.get("free_parameters", ())))
                )
    return {
        "selected_action_count": len(multiplicities),
        "selected_multiplicity_mean": (
            float(fmean(multiplicities)) if multiplicities else None
        ),
        "selected_free_parameter_count_mean": (
            float(fmean(free_parameter_counts)) if free_parameter_counts else None
        ),
        "legal_action_count_mean": (
            float(fmean(legal_action_counts)) if legal_action_counts else None
        ),
    }


def summarize_action_failure_mechanism(
    records: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    failure_counts: Counter[str] = Counter()
    by_outcome_records: dict[str, list[Mapping[str, Any]]] = {}
    legal_terminal_count = 0
    for record in records:
        is_terminal = bool(record.get("legal_terminal_crystal", False))
        legal_terminal_count += int(is_terminal)
        failure_code = record.get("failure_code")
        failure_counts[str(failure_code) if failure_code else "NONE"] += 1
        outcome = (
            "LEGAL_TERMINAL" if is_terminal else str(failure_code or "UNKNOWN_FAILURE")
        )
        by_outcome_records.setdefault(outcome, []).append(record)

    result = {
        "attempt_count": len(records),
        "legal_terminal_count": legal_terminal_count,
        "failure_code_counts": dict(sorted(failure_counts.items())),
        **_selected_action_summary(records),
        "by_outcome": {
            outcome: {
                "attempt_count": len(outcome_records),
                **_selected_action_summary(outcome_records),
            }
            for outcome, outcome_records in sorted(by_outcome_records.items())
        },
    }
    return result


def choose_cssd_robustness_decision(
    *,
    endpoint1_ci: Sequence[float],
    endpoint2_ci: Sequence[float],
    uniform_better_stream_fraction: float,
    observed_macro_delta: float,
    execution_complete: bool,
) -> str:
    if not execution_complete:
        return "ATTRIBUTION_REPLICATION_INCONCLUSIVE"
    robust = (
        len(endpoint1_ci) == 2
        and len(endpoint2_ci) == 2
        and float(endpoint1_ci[0]) > 0.0
        and float(endpoint2_ci[0]) > 0.0
        and float(uniform_better_stream_fraction) >= 0.9
        and float(observed_macro_delta) > 0.0
    )
    return "CSSD_ROBUST" if robust else "CSSD_STREAM_SENSITIVE"
