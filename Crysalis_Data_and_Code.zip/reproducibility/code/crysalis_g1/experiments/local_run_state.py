from __future__ import annotations

import hashlib
import json
import os
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _canonical_json(payload: object) -> str:
    return json.dumps(
        payload,
        ensure_ascii=False,
        allow_nan=False,
        separators=(",", ":"),
        sort_keys=True,
    )


def _atomic_write_json(path: Path, payload: object) -> None:
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            allow_nan=False,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


@dataclass(frozen=True, slots=True)
class LocalRunConfig:
    schema_version: str
    root_seed: int
    phase2a_root: str
    expected_phase2a_manifest_sha256: str
    output_root: str
    local_autonomous_execution_authorized: bool
    local_single_seed_pilot_authorized: bool
    server_deployment_authorized: bool
    three_seed_authorized: bool
    no_refill: bool

    def __post_init__(self) -> None:
        if self.schema_version != "g1-local-single-seed.1.0.0":
            raise ValueError("unsupported local single-seed schema")
        if self.root_seed != 20260823:
            raise ValueError("root seed must remain frozen at 20260823")
        if not self.local_autonomous_execution_authorized:
            raise ValueError("local autonomous execution is not authorized")
        if not self.local_single_seed_pilot_authorized:
            raise ValueError("local single-seed pilot is not authorized")
        if self.server_deployment_authorized:
            raise ValueError("server deployment must remain disabled")
        if self.three_seed_authorized:
            raise ValueError("three-seed execution must remain disabled")
        if not self.no_refill:
            raise ValueError("NO_REFILL must remain true")
        try:
            digest = bytes.fromhex(self.expected_phase2a_manifest_sha256)
        except ValueError as error:
            raise ValueError("invalid Phase 2A manifest SHA-256") from error
        if len(digest) != 32:
            raise ValueError("invalid Phase 2A manifest SHA-256")
        if Path(self.phase2a_root).resolve() == Path(self.output_root).resolve():
            raise ValueError("frozen data and run output roots must differ")

    @classmethod
    def from_json(cls, path: str | Path) -> LocalRunConfig:
        return cls(**json.loads(Path(path).read_text(encoding="utf-8")))

    def sha256(self) -> str:
        return hashlib.sha256(_canonical_json(asdict(self)).encode()).hexdigest()


class LocalRunState:
    """Crash-resilient state ledger for the authorized local single-seed run."""

    def __init__(self, config: LocalRunConfig, state: dict[str, Any]) -> None:
        self.config = config
        self.root = Path(config.output_root)
        self.state = state

    @property
    def current_stage(self) -> str:
        return str(self.state["current_stage"])

    @staticmethod
    def _verify_phase2a(config: LocalRunConfig) -> str:
        root = Path(config.phase2a_root)
        manifest = root / "phase2a_manifest.json"
        if not manifest.is_file():
            raise RuntimeError(f"Phase 2A manifest is missing: {manifest}")
        observed = _sha256(manifest)
        if observed != config.expected_phase2a_manifest_sha256:
            raise RuntimeError(
                "Phase 2A manifest hash mismatch: "
                f"expected {config.expected_phase2a_manifest_sha256}, observed {observed}"
            )
        manifest_payload = json.loads(manifest.read_text(encoding="utf-8"))
        exit_path = root / "phase2a_exit.json"
        evidence = (
            json.loads(exit_path.read_text(encoding="utf-8"))
            if exit_path.is_file()
            else manifest_payload
        )
        if evidence.get("status") != "PASS":
            raise RuntimeError("Phase 2A evidence is not PASS")
        if evidence.get("no_refill", True) is not True:
            raise RuntimeError("Phase 2A evidence violates NO_REFILL")
        return observed

    @classmethod
    def initialize(
        cls, config: LocalRunConfig, *, code_sha256: str
    ) -> LocalRunState:
        manifest_sha256 = cls._verify_phase2a(config)
        root = Path(config.output_root)
        if root.exists():
            raise FileExistsError(f"run output already exists; resume it explicitly: {root}")
        root.mkdir(parents=True)
        state: dict[str, Any] = {
            "schema_version": config.schema_version,
            "status": "RUNNING",
            "current_stage": "C0_BACKEND_SCREENING",
            "next_stage": "C0_BACKEND_SCREENING",
            "created_at": _utc_now(),
            "updated_at": _utc_now(),
            "root_seed": config.root_seed,
            "config_sha256": config.sha256(),
            "code_sha256": code_sha256,
            "phase2a_manifest_sha256": manifest_sha256,
            "phase2a_manifest_verified": True,
            "local_single_seed_pilot_authorized": True,
            "server_deployment_authorized": False,
            "three_seed_authorized": False,
            "no_refill": True,
            "completed_stages": [],
        }
        _atomic_write_json(root / "run_state.json", state)
        _atomic_write_json(
            root / "stage_status.json",
            {
                "status": "PENDING",
                "stage": "C0_BACKEND_SCREENING",
                "updated_at": _utc_now(),
            },
        )
        (root / "heartbeat.jsonl").touch()
        return cls(config, state)

    @classmethod
    def resume(cls, config: LocalRunConfig) -> LocalRunState:
        cls._verify_phase2a(config)
        root = Path(config.output_root)
        state_path = root / "run_state.json"
        if not state_path.is_file():
            raise FileNotFoundError(f"run state is missing: {state_path}")
        state = json.loads(state_path.read_text(encoding="utf-8"))
        if state.get("config_sha256") != config.sha256():
            raise RuntimeError("run config hash mismatch on resume")
        if state.get("root_seed") != config.root_seed:
            raise RuntimeError("root seed changed on resume")
        return cls(config, state)

    def _save_state(self) -> None:
        self.state["updated_at"] = _utc_now()
        _atomic_write_json(self.root / "run_state.json", self.state)

    def _append_heartbeat(self, payload: dict[str, Any]) -> None:
        record = {
            "timestamp": _utc_now(),
            "stage": self.current_stage,
            **payload,
        }
        with (self.root / "heartbeat.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(_canonical_json(record) + "\n")
            stream.flush()
            os.fsync(stream.fileno())

    def start_stage(self, stage: str, *, checkpoint_path: str | None) -> None:
        if stage != self.current_stage:
            raise ValueError(
                f"cannot start {stage}; current stage is {self.current_stage}"
            )
        now = _utc_now()
        _atomic_write_json(
            self.root / "stage_status.json",
            {
                "status": "RUNNING",
                "stage": stage,
                "started_at": now,
                "updated_at": now,
                "current_update": 0,
                "checkpoint_path": checkpoint_path,
            },
        )
        self._append_heartbeat(
            {"event": "STAGE_STARTED", "update": 0, "checkpoint_path": checkpoint_path}
        )

    def heartbeat(self, *, update: int, checkpoint_path: str | None) -> None:
        if update < 0:
            raise ValueError("update must be non-negative")
        status_path = self.root / "stage_status.json"
        status = json.loads(status_path.read_text(encoding="utf-8"))
        status["current_update"] = update
        status["checkpoint_path"] = checkpoint_path
        status["updated_at"] = _utc_now()
        _atomic_write_json(status_path, status)
        self._append_heartbeat(
            {"event": "HEARTBEAT", "update": update, "checkpoint_path": checkpoint_path}
        )

    def complete_stage(self, stage: str, *, next_stage: str) -> None:
        if stage != self.current_stage:
            raise ValueError(
                f"cannot complete {stage}; current stage is {self.current_stage}"
            )
        completed = list(self.state["completed_stages"])
        if stage not in completed:
            completed.append(stage)
        self.state["completed_stages"] = completed
        self.state["current_stage"] = next_stage
        self.state["next_stage"] = next_stage
        self._save_state()
        now = _utc_now()
        _atomic_write_json(
            self.root / "stage_status.json",
            {
                "status": "PENDING",
                "stage": next_stage,
                "previous_stage": stage,
                "previous_stage_completed_at": now,
                "updated_at": now,
            },
        )
        self._append_heartbeat(
            {"event": "STAGE_COMPLETED", "completed_stage": stage, "next_stage": next_stage}
        )

    def fail(
        self, *, reason_code: str, message: str, traceback_text: str
    ) -> None:
        sentinel = self.root / "failure_sentinel.json"
        if sentinel.exists():
            raise FileExistsError(f"failure sentinel already exists: {sentinel}")
        payload = {
            "status": "HARD_STOP",
            "stage": self.current_stage,
            "reason_code": reason_code,
            "message": message,
            "traceback": traceback_text,
            "timestamp": _utc_now(),
            "root_seed": self.config.root_seed,
            "config_sha256": self.config.sha256(),
            "phase2a_manifest_sha256": self.config.expected_phase2a_manifest_sha256,
        }
        _atomic_write_json(sentinel, payload)
        self.state["status"] = "HARD_STOP"
        self.state["failure_sentinel"] = str(sentinel)
        self._save_state()
        _atomic_write_json(
            self.root / "stage_status.json",
            {**payload, "updated_at": _utc_now()},
        )
        self._append_heartbeat(
            {"event": "HARD_STOP", "reason_code": reason_code, "message": message}
        )

    def finish(self) -> None:
        if self.current_stage != "COMPLETE":
            raise ValueError("run can finish only after entering COMPLETE stage")
        self.state["status"] = "COMPLETE"
        self.state["next_stage"] = None
        self.state["completed_at"] = _utc_now()
        self._save_state()
        _atomic_write_json(
            self.root / "stage_status.json",
            {
                "status": "COMPLETE",
                "stage": "COMPLETE",
                "completed_at": self.state["completed_at"],
                "updated_at": _utc_now(),
            },
        )
        self._append_heartbeat({"event": "RUN_COMPLETED"})

    def engineering_error(
        self, *, reason_code: str, message: str, traceback_text: str
    ) -> None:
        payload = {
            "status": "ENGINEERING_REPAIR_REQUIRED",
            "stage": self.current_stage,
            "reason_code": reason_code,
            "message": message,
            "traceback": traceback_text,
            "timestamp": _utc_now(),
            "root_seed": self.config.root_seed,
        }
        with (self.root / "engineering_errors.jsonl").open(
            "a", encoding="utf-8"
        ) as stream:
            stream.write(_canonical_json(payload) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        _atomic_write_json(
            self.root / "stage_status.json",
            {**payload, "updated_at": _utc_now()},
        )
        self._append_heartbeat(
            {
                "event": "ENGINEERING_REPAIR_REQUIRED",
                "reason_code": reason_code,
                "message": message,
            }
        )
