from __future__ import annotations

import hashlib
import io
import math
import os
import random
import tempfile
import time
from collections import Counter
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch.nn import functional as F

from crysalis_g1.experiments.contribution_state_graph import (
    ActionDescription,
    StateGraphCorpus,
)
from crysalis_g1.model.action_viability import (
    FEATURE_BLOCK_SLICES,
    FEATURE_DIMENSION,
    ActionViabilityConfig,
    ActionViabilityScorer,
    CurrentOrbitSummary,
    FeatureMode,
    encode_state_action_features,
    state_dict_sha256,
)
from crysalis_g1.symmetry.assembly import (
    SpaceGroupLegalActionCompiler,
    SymmetryAssemblyState,
)

ROOT_SEED = 20260823
AUTHORIZED_TRAINING_SEEDS = (20260823, 20260824, 20260825)
FORMAL_PREFLIGHT_UPDATES = 500
FORMAL_TOTAL_UPDATES = 5_000


@dataclass(frozen=True, slots=True)
class ActionScorerGroup:
    split: str
    target_space_group: int
    full_composition: tuple[tuple[int, int], ...]
    remaining_composition: tuple[tuple[int, int], ...]
    present_orbits: tuple[CurrentOrbitSummary, ...]
    lattice_degrees: tuple[float, ...]
    legal_actions: tuple[ActionDescription, ...]
    graph_targets: tuple[float, ...]
    final_set_targets: tuple[float, ...]
    offline_provenance: Mapping[str, object]

    def __post_init__(self) -> None:
        if self.split not in ("train_fit", "validation"):
            raise ValueError("action scorer permits only train_fit and validation")
        if not self.legal_actions:
            raise ValueError("an action scorer group requires at least one legal action")
        if len(set(self.legal_actions)) != len(self.legal_actions):
            raise ValueError("legal action descriptions must be unique within a group")
        if not (
            len(self.legal_actions)
            == len(self.graph_targets)
            == len(self.final_set_targets)
        ):
            raise ValueError("each legal action requires both contribution targets")
        if any(
            target not in (0.0, 1.0)
            for target in (*self.graph_targets, *self.final_set_targets)
        ):
            raise ValueError("action scorer targets must be binary")


@dataclass(frozen=True, slots=True)
class ActionScorerCorpus:
    graph_groups: tuple[ActionScorerGroup, ...]
    final_set_groups: tuple[ActionScorerGroup, ...]
    excluded_split_parent_counts: Mapping[str, int] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.graph_groups or not self.final_set_groups:
            raise ValueError("both action scorer corpus modes must be non-empty")
        if any(
            split != "test" or count < 0
            for split, count in self.excluded_split_parent_counts.items()
        ):
            raise ValueError("only non-negative test parent exclusions are permitted")

    def groups_for(self, mode: FeatureMode) -> tuple[ActionScorerGroup, ...]:
        if mode == "GRAPH_VIABILITY":
            return self.graph_groups
        if mode == "FINAL_SET_MEMBERSHIP":
            return self.final_set_groups
        raise ValueError("unknown action-viability feature mode")


@dataclass(frozen=True, slots=True)
class ActionScorerTrainingConfig:
    root_seed: int = ROOT_SEED
    preflight_updates: int = FORMAL_PREFLIGHT_UPDATES
    total_updates: int = FORMAL_TOTAL_UPDATES
    batch_size: int = 32
    validation_interval: int = 100
    validation_group_chunk_size: int = 256
    learning_rate: float = 1e-3
    weight_decay: float = 1e-5
    gradient_clip_norm: float = 1.0

    def __post_init__(self) -> None:
        if self.root_seed < 0:
            raise ValueError("root_seed must be non-negative")
        if not 0 < self.preflight_updates < self.total_updates:
            raise ValueError("preflight_updates must precede total_updates")
        if (
            self.batch_size <= 0
            or self.validation_interval <= 0
            or self.validation_group_chunk_size <= 0
        ):
            raise ValueError(
                "batch_size, validation_interval, and validation chunk size "
                "must be positive"
            )
        for name, value in (
            ("learning_rate", self.learning_rate),
            ("gradient_clip_norm", self.gradient_clip_norm),
        ):
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        if not math.isfinite(self.weight_decay) or self.weight_decay < 0.0:
            raise ValueError("weight_decay must be finite and non-negative")


def validate_formal_training_config(
    config: ActionScorerTrainingConfig, *, allowed_seed: int = ROOT_SEED
) -> None:
    if allowed_seed not in AUTHORIZED_TRAINING_SEEDS:
        raise ValueError("allowed_seed is not an authorized training seed")
    if config.root_seed != allowed_seed:
        raise ValueError(
            f"formal contribution schedule expected training seed {allowed_seed}"
        )
    if (
        config.preflight_updates != FORMAL_PREFLIGHT_UPDATES
        or config.total_updates != FORMAL_TOTAL_UPDATES
    ):
        raise ValueError(
            "formal contribution schedule requires exactly 500/5000 updates"
        )


def build_action_scorer_group(
    *,
    split: str,
    target_space_group: int,
    full_composition: Sequence[tuple[int, int]],
    remaining_composition: Sequence[tuple[int, int]],
    present_orbits: Sequence[CurrentOrbitSummary],
    lattice_degrees: Sequence[float],
    legal_actions: Sequence[ActionDescription],
    graph_viable_action_set: Sequence[ActionDescription],
    final_parent_action_multiset: Sequence[ActionDescription],
    offline_provenance: Mapping[str, object],
) -> ActionScorerGroup:
    legal = tuple(legal_actions)
    graph_viable = set(graph_viable_action_set)
    final_members = set(final_parent_action_multiset)
    if not graph_viable.issubset(legal):
        raise ValueError("graph-viable actions must be compiler-legal")
    accounted_composition = Counter(dict(remaining_composition))
    for orbit in present_orbits:
        accounted_composition[orbit.atomic_number] += orbit.multiplicity
    if accounted_composition != Counter(dict(full_composition)):
        raise ValueError("full composition must equal present plus remaining")
    return ActionScorerGroup(
        split=split,
        target_space_group=target_space_group,
        full_composition=tuple(full_composition),
        remaining_composition=tuple(remaining_composition),
        present_orbits=tuple(present_orbits),
        lattice_degrees=tuple(float(value) for value in lattice_degrees),
        legal_actions=legal,
        graph_targets=tuple(float(action in graph_viable) for action in legal),
        final_set_targets=tuple(float(action in final_members) for action in legal),
        offline_provenance=dict(offline_provenance),
    )


def build_action_scorer_corpus(corpus: StateGraphCorpus) -> ActionScorerCorpus:
    """Strip Task 1 graph contracts to leakage-safe grouped model examples."""

    labels = {
        (label.parent_structure_id, label.state_hash): label for label in corpus.labels
    }
    graph_groups: list[ActionScorerGroup] = []
    final_set_groups: list[ActionScorerGroup] = []
    excluded_split_parent_counts: Counter[str] = Counter()
    for graph in corpus.graphs:
        final_action_multiset = tuple(
            ActionDescription(
                operator="D_orbit",
                wyckoff_letter=orbit.wyckoff_letter,
                atomic_number=orbit.species,
                multiplicity=orbit.multiplicity,
                free_parameter_count=len(orbit.free_parameters),
            )
            for orbit in graph.recovered_parent.orbits
        )
        parent_labels = tuple(
            label
            for label in corpus.labels
            if label.parent_structure_id == graph.record.material_id
        )
        parent_splits = {label.split for label in parent_labels}
        if len(parent_splits) != 1:
            raise ValueError("contribution parent must have exactly one data split")
        parent_split = next(iter(parent_splits))
        if parent_split == "test":
            excluded_split_parent_counts[parent_split] += 1
            continue
        if parent_split not in ("train_fit", "validation"):
            raise ValueError(f"unknown contribution split: {parent_split}")

        full_composition_counter: Counter[int] = Counter()
        for orbit in graph.recovered_parent.orbits:
            full_composition_counter[orbit.species] += orbit.multiplicity
        full_composition = tuple(sorted(full_composition_counter.items()))
        empty_state = SymmetryAssemblyState.empty(
            target_space_group=graph.recovered_parent.target_space_group,
            composition=full_composition,
            lattice=graph.recovered_parent.lattice,
        )
        final_legal_actions = tuple(
            sorted(
                {
                    ActionDescription(
                        operator="D_orbit",
                        wyckoff_letter=legal.wyckoff_letter,
                        atomic_number=legal.species,
                        multiplicity=legal.multiplicity,
                        free_parameter_count=legal.free_parameter_count,
                    )
                    for legal in SpaceGroupLegalActionCompiler(
                        max_sites=graph.max_sites
                    ).legal_add_actions(empty_state)
                }
            )
        )
        if not set(final_action_multiset).issubset(final_legal_actions):
            raise ValueError(
                "final action descriptor is not independently compiler-legal"
            )
        final_set_groups.append(
            build_action_scorer_group(
                split=parent_split,
                target_space_group=graph.recovered_parent.target_space_group,
                full_composition=full_composition,
                remaining_composition=full_composition,
                present_orbits=(),
                lattice_degrees=(
                    graph.recovered_parent.lattice.conventional_parameters
                ),
                legal_actions=final_legal_actions,
                graph_viable_action_set=(),
                final_parent_action_multiset=final_action_multiset,
                offline_provenance={
                    "material_id": graph.record.material_id,
                    "source": "parent_final_orbit_multiset",
                },
            )
        )

        for node in graph.nodes:
            if not node.legal_action_set:
                continue
            key = (graph.record.material_id, node.state_hash)
            label = labels.get(key)
            if label is None:
                raise ValueError("missing grouped Task 1 label for graph node")
            labelled_actions = set(label.viable_action_set) | set(
                label.nonviable_legal_action_set
            )
            if labelled_actions != set(node.legal_action_set):
                raise ValueError("Task 1 legal-action labels drifted")
            graph_groups.append(
                build_action_scorer_group(
                    split=label.split,
                    target_space_group=node.c0_state.target_space_group,
                    full_composition=node.c0_state.full_composition,
                    remaining_composition=node.c0_state.remaining_composition,
                    present_orbits=tuple(
                        CurrentOrbitSummary(
                            wyckoff_letter=orbit.wyckoff_letter,
                            atomic_number=orbit.atomic_number,
                            multiplicity=orbit.multiplicity,
                        )
                        for orbit in node.c0_state.present_orbits
                    ),
                    lattice_degrees=node.c0_state.frozen_lattice.conventional_parameters,
                    legal_actions=node.legal_action_set,
                    graph_viable_action_set=label.viable_action_set,
                    final_parent_action_multiset=final_action_multiset,
                    offline_provenance={
                        "material_id": graph.record.material_id,
                        "state_hash": node.state_hash,
                        "canonical_orbit_ids": tuple(
                            orbit.orbit_instance_id
                            for orbit in node.c0_state.present_orbits
                        ),
                        "operator_provenance": dict(label.operator_provenance),
                    },
                )
            )
    return ActionScorerCorpus(
        graph_groups=tuple(graph_groups),
        final_set_groups=tuple(final_set_groups),
        excluded_split_parent_counts=dict(excluded_split_parent_counts),
    )


def collate_action_groups(
    groups: Sequence[ActionScorerGroup], *, mode: FeatureMode
) -> tuple[torch.Tensor, torch.Tensor]:
    features: list[torch.Tensor] = []
    targets: list[float] = []
    for group in groups:
        group_targets = (
            group.graph_targets
            if mode == "GRAPH_VIABILITY"
            else group.final_set_targets
        )
        for action, target in zip(group.legal_actions, group_targets, strict=True):
            features.append(
                encode_state_action_features(
                    mode=mode,
                    target_space_group=group.target_space_group,
                    full_composition=group.full_composition,
                    remaining_composition=group.remaining_composition,
                    present_orbits=group.present_orbits,
                    lattice_degrees=group.lattice_degrees,
                    action=action,
                )
            )
            targets.append(target)
    if not features:
        raise ValueError("cannot collate an empty legal-action batch")
    return torch.stack(features), torch.tensor(targets, dtype=torch.float32)


def _seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed % (2**32))
    torch.manual_seed(seed)


def _generator_sha256(generator: torch.Generator) -> str:
    return hashlib.sha256(generator.get_state().numpy().tobytes()).hexdigest()


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _feature_schema() -> dict[str, object]:
    return {
        "dimension": FEATURE_DIMENSION,
        "blocks": {
            name: {"start": section.start, "stop": section.stop}
            for name, section in FEATURE_BLOCK_SLICES.items()
        },
        "final_set_zeroed_blocks": (
            "remaining_composition",
            "current_wyckoff",
            "current_species",
            "current_multiplicity",
            "progress",
        ),
    }


def _save_checkpoint_new(path: Path, payload: Mapping[str, object]) -> None:
    buffer = io.BytesIO()
    torch.save(dict(payload), buffer)
    file_descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(file_descriptor, "wb", buffering=0) as stream:
            data = buffer.getbuffer()
            offset = 0
            while offset < len(data):
                written = os.write(stream.fileno(), data[offset:])
                if written <= 0:
                    raise OSError("checkpoint write made no progress")
                offset += written
            stream.flush()
            os.fsync(stream.fileno())
        try:
            os.link(temporary, path)
        except FileExistsError as error:
            raise FileExistsError(
                f"refusing to overwrite checkpoint: {path}"
            ) from error
    finally:
        temporary.unlink(missing_ok=True)


def validation_action_loss(
    model: ActionViabilityScorer,
    groups: Sequence[ActionScorerGroup],
    *,
    mode: FeatureMode,
    group_chunk_size: int,
) -> float:
    if group_chunk_size <= 0:
        raise ValueError("validation group_chunk_size must be positive")
    model.eval()
    total_loss = 0.0
    total_rows = 0
    with torch.no_grad():
        for start in range(0, len(groups), group_chunk_size):
            chunk = groups[start : start + group_chunk_size]
            features, targets = collate_action_groups(chunk, mode=mode)
            logits = model(features)
            loss_sum = F.binary_cross_entropy_with_logits(
                logits, targets, reduction="sum"
            )
            if not bool(torch.isfinite(logits).all()) or not bool(
                torch.isfinite(loss_sum)
            ):
                raise FloatingPointError(
                    "non-finite action-scorer validation loss"
                )
            total_loss += float(loss_sum.double())
            total_rows += int(targets.numel())
    model.train()
    if total_rows == 0:
        raise ValueError("validation action groups must be non-empty")
    value = total_loss / total_rows
    if not math.isfinite(value):
        raise FloatingPointError("non-finite action-scorer validation loss")
    return value


def _checkpoint_payload(
    *,
    model: ActionViabilityScorer,
    optimizer: torch.optim.Optimizer,
    generator: torch.Generator,
    mode: FeatureMode,
    model_config: ActionViabilityConfig,
    training_config: ActionScorerTrainingConfig,
    completed_updates: int,
    initial_state_sha256: str,
    validation_loss: float,
) -> dict[str, object]:
    return {
        "schema_version": "g1-contribution-action-scorer-checkpoint.1.0.0",
        "feature_mode": mode,
        "feature_schema": _feature_schema(),
        "model_config": asdict(model_config),
        "training_config": asdict(training_config),
        "completed_updates": completed_updates,
        "initial_state_sha256": initial_state_sha256,
        "trainable_parameter_count": model.trainable_parameter_count(),
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "cpu_generator_state": generator.get_state(),
        "validation_loss": validation_loss,
        "restart_or_checkpoint_reload": False,
    }


def train_action_scorer(
    corpus: ActionScorerCorpus,
    *,
    mode: FeatureMode,
    output_directory: str | Path,
    model_config: ActionViabilityConfig,
    training_config: ActionScorerTrainingConfig,
) -> dict[str, Any]:
    """Train one arm in a single uninterrupted model/optimizer/sampler loop."""

    if not isinstance(corpus, ActionScorerCorpus):
        raise TypeError("train_action_scorer requires an ActionScorerCorpus")
    groups = corpus.groups_for(mode)
    train_groups = tuple(group for group in groups if group.split == "train_fit")
    validation_groups = tuple(
        group for group in groups if group.split == "validation"
    )
    if not train_groups or not validation_groups:
        raise ValueError("both train_fit and validation action groups are required")

    output = Path(output_directory)
    stem = mode.lower()
    preflight_path = output / (
        f"{stem}_update_{training_config.preflight_updates:06d}.pt"
    )
    final_path = output / f"{stem}_update_{training_config.total_updates:06d}.pt"
    for path in (preflight_path, final_path):
        if path.exists():
            raise FileExistsError(f"refusing to overwrite checkpoint: {path}")
    output.mkdir(parents=True, exist_ok=True)

    _seed_everything(training_config.root_seed)
    model = ActionViabilityScorer(model_config)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=training_config.learning_rate,
        weight_decay=training_config.weight_decay,
    )
    generator = torch.Generator(device="cpu").manual_seed(
        training_config.root_seed
    )
    initial_state_sha = state_dict_sha256(model)
    parameter_count = model.trainable_parameter_count()
    if not all(bool(torch.isfinite(parameter).all()) for parameter in model.parameters()):
        raise FloatingPointError("non-finite action-scorer initialization")

    initial_validation_loss = validation_action_loss(
        model,
        validation_groups,
        mode=mode,
        group_chunk_size=training_config.validation_group_chunk_size,
    )
    curve: list[dict[str, float | int]] = [
        {"update": 0, "validation_loss": initial_validation_loss}
    ]
    legal_rows_scored = 0
    preflight_gate: dict[str, object] | None = None
    model_identity = id(model)
    optimizer_identity = id(optimizer)
    generator_identity = id(generator)
    started = time.perf_counter()
    final_validation_loss = initial_validation_loss
    model.train()

    for update in range(1, training_config.total_updates + 1):
        indices = torch.randint(
            len(train_groups),
            (training_config.batch_size,),
            generator=generator,
        ).tolist()
        selected = tuple(train_groups[index] for index in indices)
        features, targets = collate_action_groups(selected, mode=mode)
        legal_rows_scored += int(targets.numel())
        optimizer.zero_grad(set_to_none=True)
        logits = model(features)
        loss = F.binary_cross_entropy_with_logits(logits, targets)
        if not bool(torch.isfinite(logits).all()) or not bool(torch.isfinite(loss)):
            raise FloatingPointError(f"non-finite action-scorer forward at update {update}")
        loss.backward()
        if not all(
            parameter.grad is None or bool(torch.isfinite(parameter.grad).all())
            for parameter in model.parameters()
        ):
            raise FloatingPointError(f"non-finite action-scorer gradient at update {update}")
        gradient_norm = torch.nn.utils.clip_grad_norm_(
            model.parameters(), training_config.gradient_clip_norm
        )
        if not bool(torch.isfinite(gradient_norm)):
            raise FloatingPointError(f"non-finite gradient norm at update {update}")
        optimizer.step()
        if not all(
            bool(torch.isfinite(parameter).all()) for parameter in model.parameters()
        ):
            raise FloatingPointError(f"non-finite action-scorer parameter at update {update}")

        should_validate = (
            update % training_config.validation_interval == 0
            or update == training_config.preflight_updates
            or update == training_config.total_updates
        )
        if should_validate:
            final_validation_loss = validation_action_loss(
                model,
                validation_groups,
                mode=mode,
                group_chunk_size=training_config.validation_group_chunk_size,
            )
            curve.append(
                {
                    "update": update,
                    "train_loss": float(loss.detach()),
                    "validation_loss": final_validation_loss,
                    "gradient_norm": float(gradient_norm.detach()),
                }
            )

        if update == training_config.preflight_updates:
            preflight_gate = {
                "update": update,
                "forward_loss_finite": True,
                "gradients_finite": True,
                "parameters_finite": True,
                "validation_loss_finite": math.isfinite(final_validation_loss),
                "generator_state_sha256": _generator_sha256(generator),
            }
            _save_checkpoint_new(
                preflight_path,
                _checkpoint_payload(
                    model=model,
                    optimizer=optimizer,
                    generator=generator,
                    mode=mode,
                    model_config=model_config,
                    training_config=training_config,
                    completed_updates=update,
                    initial_state_sha256=initial_state_sha,
                    validation_loss=final_validation_loss,
                ),
            )

    if preflight_gate is None:
        raise RuntimeError("preflight gate was not reached")
    _save_checkpoint_new(
        final_path,
        _checkpoint_payload(
            model=model,
            optimizer=optimizer,
            generator=generator,
            mode=mode,
            model_config=model_config,
            training_config=training_config,
            completed_updates=training_config.total_updates,
            initial_state_sha256=initial_state_sha,
            validation_loss=final_validation_loss,
        ),
    )
    elapsed = time.perf_counter() - started
    return {
        "schema_version": "g1-contribution-action-scorer-training.1.0.0",
        "feature_mode": mode,
        "root_seed": training_config.root_seed,
        "device": "cpu",
        "feature_schema": _feature_schema(),
        "model_config": asdict(model_config),
        "training_config": asdict(training_config),
        "trainable_parameter_count": parameter_count,
        "initial_state_sha256": initial_state_sha,
        "train_group_count": len(train_groups),
        "validation_group_count": len(validation_groups),
        "excluded_split_parent_counts": dict(
            corpus.excluded_split_parent_counts
        ),
        "train_legal_action_count": sum(
            len(group.legal_actions) for group in train_groups
        ),
        "validation_legal_action_count": sum(
            len(group.legal_actions) for group in validation_groups
        ),
        "legal_action_rows_scored": legal_rows_scored,
        "loss": "binary_cross_entropy_with_logits_over_all_sampled_group_actions",
        "initial_validation_loss": initial_validation_loss,
        "final_validation_loss": final_validation_loss,
        "validation_curve": curve,
        "preflight_gate": preflight_gate,
        "updates_completed": training_config.total_updates,
        "continuation_evidence": {
            "same_model_object": id(model) == model_identity,
            "same_optimizer_object": id(optimizer) == optimizer_identity,
            "same_generator_object": id(generator) == generator_identity,
            "restart_or_checkpoint_reload": False,
        },
        "final_generator_state_sha256": _generator_sha256(generator),
        "preflight_checkpoint_path": str(preflight_path.resolve()),
        "preflight_checkpoint_sha256": _file_sha256(preflight_path),
        "final_checkpoint_path": str(final_path.resolve()),
        "final_checkpoint_sha256": _file_sha256(final_path),
        "elapsed_seconds": elapsed,
    }
