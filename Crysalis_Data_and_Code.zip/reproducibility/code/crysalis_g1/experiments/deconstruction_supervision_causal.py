from __future__ import annotations

import hashlib
import math
from collections import defaultdict
from dataclasses import dataclass
from typing import Iterable, Mapping, Sequence

import numpy as np
import torch
import torch.nn.functional as F


@dataclass(frozen=True)
class CausalSplit:
    train_parent_ids: tuple[str, ...]
    validation_parent_ids: tuple[str, ...]
    causal_test_parent_ids: tuple[str, ...]


@dataclass(frozen=True)
class FixedPaths:
    canonical_path_index: dict[str, int]
    random_path_index: dict[str, int]


@dataclass(frozen=True)
class PairedEffect:
    treatment: str
    control: str
    paired_n: int
    delta_pp: float
    ci_lower_pp: float
    ci_upper_pp: float


@dataclass(frozen=True)
class CausalVerdict:
    deconstruction_supervision_value: str
    multipath_graph_value: str
    set_valued_objective_value: str
    nc_supervision_hypothesis: str
    next_action: str


def _hash_order(seed: int, purpose: str, value: object) -> str:
    payload = f"{seed}:{purpose}:{value}".encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _stratum(parent: Mapping[str, object]) -> tuple[str, int, int, int]:
    return (
        str(parent["crystal_system"]),
        int(parent["element_count"]),
        int(parent["orbit_count"]),
        int(parent["free_dof_event_count"]),
    )


def _capped_largest_remainder(
    total: int,
    weights: Mapping[tuple[object, ...], int],
    capacities: Mapping[tuple[object, ...], int],
) -> dict[tuple[object, ...], int]:
    if total < 0 or total > sum(capacities.values()):
        raise ValueError("requested count exceeds available capacity")
    if total == 0:
        return {key: 0 for key in capacities}

    weight_sum = sum(max(0, value) for value in weights.values())
    if weight_sum == 0:
        ideals = {key: total / len(capacities) for key in capacities}
    else:
        ideals = {
            key: total * max(0, weights.get(key, 0)) / weight_sum for key in capacities
        }
    allocation = {
        key: min(capacities[key], int(math.floor(ideals[key]))) for key in capacities
    }
    remaining = total - sum(allocation.values())
    order = sorted(
        capacities,
        key=lambda key: (-(ideals[key] - math.floor(ideals[key])), repr(key)),
    )
    while remaining:
        eligible = [key for key in order if allocation[key] < capacities[key]]
        if not eligible:
            raise ValueError("unable to satisfy exact stratified allocation")
        for key in eligible:
            if remaining == 0:
                break
            allocation[key] += 1
            remaining -= 1
    return allocation


def deterministic_causal_split(
    parents: Sequence[Mapping[str, object]],
    *,
    train_count: int,
    validation_count: int,
    causal_test_count: int,
    seed: int,
) -> CausalSplit:
    """Select and split parents using only registered, model-independent strata."""

    requested = train_count + validation_count + causal_test_count
    if requested > len(parents):
        raise ValueError("not enough parents for requested causal split")
    by_id = {str(parent["parent_id"]): parent for parent in parents}
    if len(by_id) != len(parents):
        raise ValueError("parent_id values must be unique")

    groups: dict[tuple[object, ...], list[str]] = defaultdict(list)
    for parent_id, parent in by_id.items():
        groups[_stratum(parent)].append(parent_id)
    capacities = {key: len(parent_ids) for key, parent_ids in groups.items()}
    selected_quota = _capped_largest_remainder(requested, capacities, capacities)

    selected_by_stratum: dict[tuple[object, ...], list[str]] = {}
    for key, parent_ids in groups.items():
        ordered = sorted(
            parent_ids, key=lambda value: _hash_order(seed, "select", value)
        )
        selected_by_stratum[key] = ordered[: selected_quota[key]]

    validation_quota = _capped_largest_remainder(
        validation_count,
        selected_quota,
        selected_quota,
    )
    validation: list[str] = []
    remaining_by_stratum: dict[tuple[object, ...], list[str]] = {}
    for key, parent_ids in selected_by_stratum.items():
        ordered = sorted(
            parent_ids, key=lambda value: _hash_order(seed, "validation", value)
        )
        validation.extend(ordered[: validation_quota[key]])
        remaining_by_stratum[key] = ordered[validation_quota[key] :]

    remaining_capacity = {
        key: len(parent_ids) for key, parent_ids in remaining_by_stratum.items()
    }
    test_quota = _capped_largest_remainder(
        causal_test_count,
        selected_quota,
        remaining_capacity,
    )
    causal_test: list[str] = []
    train: list[str] = []
    for key, parent_ids in remaining_by_stratum.items():
        ordered = sorted(
            parent_ids, key=lambda value: _hash_order(seed, "causal-test", value)
        )
        causal_test.extend(ordered[: test_quota[key]])
        train.extend(ordered[test_quota[key] :])

    return CausalSplit(
        train_parent_ids=tuple(sorted(train)),
        validation_parent_ids=tuple(sorted(validation)),
        causal_test_parent_ids=tuple(sorted(causal_test)),
    )


def choose_fixed_paths(
    trajectories: Iterable[Mapping[str, object]],
    parent_ids: Iterable[str],
    *,
    seed: int,
) -> FixedPaths:
    requested = set(parent_ids)
    paths: dict[str, set[int]] = defaultdict(set)
    for trajectory in trajectories:
        parent_id = str(trajectory["parent_structure_id"])
        if parent_id in requested:
            paths[parent_id].add(int(trajectory["path_index"]))
    missing = sorted(requested - paths.keys())
    if missing:
        raise ValueError(f"parents without registered trajectories: {missing[:3]}")

    canonical: dict[str, int] = {}
    random_path: dict[str, int] = {}
    for parent_id in sorted(requested):
        available = sorted(paths[parent_id])
        canonical[parent_id] = available[0]
        random_path[parent_id] = min(
            available,
            key=lambda path_index: _hash_order(
                seed,
                "train:B:registered-path",
                f"{parent_id}:{path_index}",
            ),
        )
    return FixedPaths(canonical_path_index=canonical, random_path_index=random_path)


def single_positive_nll(
    logits: torch.Tensor,
    target_action_index: torch.Tensor,
    legal_mask: torch.Tensor,
) -> torch.Tensor:
    if logits.shape != legal_mask.shape:
        raise ValueError("logits and legal_mask must have the same shape")
    targets = target_action_index.to(dtype=torch.long, device=logits.device)
    if targets.shape != (logits.shape[0],):
        raise ValueError("one target action index is required per row")
    row = torch.arange(logits.shape[0], device=logits.device)
    if not bool(legal_mask.to(logits.device)[row, targets].all()):
        raise ValueError("single-positive target must be legal")
    masked = logits.masked_fill(~legal_mask.to(logits.device), float("-inf"))
    return F.cross_entropy(masked, targets)


def common_local_metrics(
    logits: torch.Tensor,
    *,
    positive_mask: torch.Tensor,
    legal_mask: torch.Tensor,
    canonical_action_index: torch.Tensor,
) -> dict[str, float]:
    if logits.shape != positive_mask.shape or logits.shape != legal_mask.shape:
        raise ValueError("local evaluation tensors must have the same shape")
    device = logits.device
    legal = legal_mask.to(device)
    positive = positive_mask.to(device) & legal
    if not bool(positive.any(dim=1).all()):
        raise ValueError("each evaluation row must have a legal positive action")
    masked = logits.masked_fill(~legal, float("-inf"))
    probabilities = torch.softmax(masked, dim=1)
    positive_mass = (probabilities * positive).sum(dim=1)
    top1 = masked.argmax(dim=1)
    row = torch.arange(masked.shape[0], device=device)

    order = torch.argsort(masked, dim=1, descending=True)
    ordered_positive = positive.gather(1, order)
    best_positive_rank = ordered_positive.to(torch.int64).argmax(dim=1) + 1
    entropy_terms = torch.where(
        probabilities > 0,
        probabilities
        * torch.log(probabilities.clamp_min(torch.finfo(probabilities.dtype).tiny)),
        torch.zeros_like(probabilities),
    )
    canonical = canonical_action_index.to(dtype=torch.long, device=device)
    canonical_valid = (canonical >= 0) & (canonical < masked.shape[1])
    canonical_hits = torch.zeros_like(canonical_valid, dtype=torch.float32)
    canonical_hits[canonical_valid] = (
        top1[canonical_valid] == canonical[canonical_valid]
    ).to(torch.float32)

    return {
        "positive_set_mass": float(positive_mass.mean().item()),
        "top1_positive_class_rate": float(
            positive[row, top1].to(torch.float32).mean().item()
        ),
        "mean_positive_rank": float(best_positive_rank.to(torch.float32).mean().item()),
        "legal_action_entropy": float((-entropy_terms.sum(dim=1)).mean().item()),
        "strict_canonical_top1": (
            float(canonical_hits[canonical_valid].mean().item())
            if bool(canonical_valid.any())
            else float("nan")
        ),
    }


def paired_terminal_effect(
    rows: Iterable[Mapping[str, object]],
    *,
    treatment: str,
    control: str,
    n_resamples: int = 10_000,
    seed: int = 20260902,
) -> PairedEffect:
    values: dict[tuple[int, str], dict[str, int]] = defaultdict(dict)
    for row in rows:
        arm = str(row["arm"])
        if arm not in {treatment, control}:
            continue
        key = (int(row["stream_seed"]), str(row["parent_id"]))
        if arm in values[key]:
            raise ValueError(f"duplicate paired outcome for {key}, arm {arm}")
        values[key][arm] = int(row["legal_terminal"])
    incomplete = [
        key for key, pair in values.items() if set(pair) != {treatment, control}
    ]
    if incomplete:
        raise ValueError(f"incomplete treatment-control pairs: {incomplete[:3]}")
    if not values:
        raise ValueError("no paired terminal outcomes")

    by_stream: dict[int, np.ndarray] = {}
    for stream in sorted({key[0] for key in values}):
        differences = [
            pair[treatment] - pair[control]
            for (row_stream, _), pair in sorted(values.items())
            if row_stream == stream
        ]
        by_stream[stream] = np.asarray(differences, dtype=np.float64)
    point = float(np.mean([array.mean() for array in by_stream.values()]))

    rng = np.random.default_rng(seed)
    streams = np.asarray(sorted(by_stream), dtype=np.int64)
    bootstrap = np.empty(n_resamples, dtype=np.float64)
    for index in range(n_resamples):
        selected_streams = rng.choice(streams, size=len(streams), replace=True)
        stream_means = []
        for stream in selected_streams:
            differences = by_stream[int(stream)]
            resampled = rng.choice(differences, size=len(differences), replace=True)
            stream_means.append(float(resampled.mean()))
        bootstrap[index] = float(np.mean(stream_means))
    lower, upper = np.quantile(bootstrap, [0.025, 0.975])
    return PairedEffect(
        treatment=treatment,
        control=control,
        paired_n=len(values),
        delta_pp=100.0 * point,
        ci_lower_pp=100.0 * float(lower),
        ci_upper_pp=100.0 * float(upper),
    )


def causal_verdict(effects: Mapping[str, Mapping[str, float]]) -> CausalVerdict:
    required = {"D-A", "D-B", "C-A", "C-B", "D-C"}
    if set(effects) != required:
        raise ValueError(f"effects must contain exactly {sorted(required)}")

    best = "D" if effects["D-A"]["delta_pp"] >= effects["C-A"]["delta_pp"] else "C"
    level1 = (
        effects[f"{best}-A"]["delta_pp"] > 0
        and effects[f"{best}-A"]["ci_lower_pp"] > 0
        and effects[f"{best}-B"]["delta_pp"] > 0
    )

    c_a = effects["C-A"]
    c_b = effects["C-B"]
    level2 = (c_a["ci_lower_pp"] > 0 and c_b["ci_upper_pp"] >= 0) or (
        c_b["ci_lower_pp"] > 0 and c_a["ci_upper_pp"] >= 0
    )

    d_c = effects["D-C"]
    if d_c["ci_lower_pp"] > 0:
        level3 = "SUPPORTED"
    elif d_c["ci_upper_pp"] < 0:
        level3 = "NOT_SUPPORTED"
    else:
        level3 = "NEUTRAL"

    if level1 and (level2 or level3 == "SUPPORTED"):
        if level3 == "SUPPORTED":
            nc = "SUPPORTED_GRAPH_AND_SET_OBJECTIVE"
        else:
            nc = "SUPPORTED_GRAPH_ONLY"
        next_action = "MODEL_AGNOSTIC_DECONSTRUCTION_REPLICATION"
    else:
        nc = "NOT_SUPPORTED"
        next_action = (
            "DOWNGRADE_TO_ARCHITECTURE_CONTRIBUTION"
            if not level1
            else "REDEFINE_DECONSTRUCTION_SUPERVISION"
        )

    return CausalVerdict(
        deconstruction_supervision_value="SUPPORTED" if level1 else "NOT_SUPPORTED",
        multipath_graph_value="SUPPORTED" if level2 else "NOT_SUPPORTED",
        set_valued_objective_value=level3,
        nc_supervision_hypothesis=nc,
        next_action=next_action,
    )


def select_profile(
    *,
    default_eta_minutes: float,
    small_eta_minutes: float,
    maximum_minutes: float = 30.0,
) -> str | None:
    if default_eta_minutes <= maximum_minutes:
        return "DEFAULT"
    if small_eta_minutes <= maximum_minutes:
        return "SMALL"
    return None
