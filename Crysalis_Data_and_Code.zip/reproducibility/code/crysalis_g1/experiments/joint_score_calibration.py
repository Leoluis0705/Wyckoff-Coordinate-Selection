from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Mapping, Sequence

import numpy as np

from crysalis_g1.experiments.physics_aware_orbit import (
    ZScoreCalibration,
    hierarchical_paired_bootstrap,
)


REGISTERED_LAMBDAS = (0.00, 0.25, 0.50, 0.75, 1.00)
TERMINAL_NONINFERIORITY_MARGIN = -0.03
FORCE_TIE_BAND = 0.03


@dataclass(frozen=True, slots=True)
class LambdaValidationResult:
    lambda_value: float
    terminal_delta: float
    terminal_ci95_lower: float
    paired_force_delta: float


def calibrated_joint_score(
    calibration: ZScoreCalibration,
    *,
    inverse: np.ndarray,
    terminal: np.ndarray,
    force: np.ndarray,
    lambda_value: float,
) -> np.ndarray:
    if float(lambda_value) not in REGISTERED_LAMBDAS:
        raise ValueError("score calibration requires a registered lambda")
    standardized = calibration.standardize(
        inverse=inverse,
        terminal=terminal,
        force=force,
    )
    return standardized["inverse"] + float(lambda_value) * (
        standardized["terminal"] - standardized["force"]
    )


def select_pareto_lambda(
    rows: tuple[LambdaValidationResult, ...],
) -> LambdaValidationResult:
    by_lambda = {float(row.lambda_value): row for row in rows}
    if tuple(sorted(by_lambda)) != REGISTERED_LAMBDAS or len(rows) != len(by_lambda):
        raise ValueError("validation results must contain each registered lambda once")
    acceptable = [
        row
        for row in rows
        if row.terminal_ci95_lower > TERMINAL_NONINFERIORITY_MARGIN
    ]
    if not acceptable:
        raise RuntimeError("no lambda satisfies validation terminal noninferiority")
    best_force = min(row.paired_force_delta for row in acceptable)
    tied = [
        row
        for row in acceptable
        if row.paired_force_delta - best_force < FORCE_TIE_BAND
    ]
    return min(tied, key=lambda row: row.lambda_value)


def _trajectory_lookup(
    rows: Sequence[Mapping[str, object]],
) -> dict[tuple[int, str], Mapping[str, object]]:
    lookup = {
        (int(row["stream_seed"]), str(row["parent_id"])): row for row in rows
    }
    if len(lookup) != len(rows):
        raise ValueError("trajectory stream-parent keys must be unique")
    return lookup


def terminal_pair_analysis(
    candidate_rows: Sequence[Mapping[str, object]],
    baseline_rows: Sequence[Mapping[str, object]],
    *,
    stream_seeds: Sequence[int],
    seed: int,
    replicates: int = 10_000,
) -> dict[str, object]:
    candidate = _trajectory_lookup(candidate_rows)
    baseline = _trajectory_lookup(baseline_rows)
    if set(candidate) != set(baseline):
        raise ValueError("candidate and baseline terminal keys differ")
    stream_values = []
    per_stream = []
    for stream_seed in stream_seeds:
        keys = sorted(key for key in candidate if key[0] == int(stream_seed))
        if not keys:
            raise ValueError(f"stream {stream_seed} has no paired trajectories")
        deltas = np.asarray(
            [
                float(bool(candidate[key]["terminal_valid"]))
                - float(bool(baseline[key]["terminal_valid"]))
                for key in keys
            ],
            dtype=float,
        )
        stream_values.append(deltas)
        per_stream.append(
            {
                "stream_seed": int(stream_seed),
                "candidate_rate": float(
                    np.mean([bool(candidate[key]["terminal_valid"]) for key in keys])
                ),
                "baseline_rate": float(
                    np.mean([bool(baseline[key]["terminal_valid"]) for key in keys])
                ),
                "delta": float(deltas.mean()),
            }
        )
    bootstrap = hierarchical_paired_bootstrap(
        stream_values, seed=seed, replicates=replicates
    )
    return {
        "candidate_rate": float(
            np.mean([bool(row["terminal_valid"]) for row in candidate_rows])
        ),
        "baseline_rate": float(
            np.mean([bool(row["terminal_valid"]) for row in baseline_rows])
        ),
        "delta": bootstrap["point"],
        "ci95_lower": bootstrap["ci95_lower"],
        "ci95_upper": bootstrap["ci95_upper"],
        "per_stream": per_stream,
    }


def force_statistics(values: Sequence[float]) -> dict[str, float | int | None]:
    array = np.asarray(values, dtype=float)
    return {
        "n": int(len(array)),
        "median": float(np.median(array)) if len(array) else None,
        "mean": float(np.mean(array)) if len(array) else None,
        "p90": float(np.quantile(array, 0.90)) if len(array) else None,
    }


def force_pair_analysis(
    candidate_rows: Sequence[Mapping[str, object]],
    baseline_rows: Sequence[Mapping[str, object]],
    *,
    stream_seeds: Sequence[int],
    seed: int,
    replicates: int = 10_000,
) -> dict[str, object]:
    candidate = _trajectory_lookup(candidate_rows)
    baseline = _trajectory_lookup(baseline_rows)
    if set(candidate) != set(baseline):
        raise ValueError("candidate and baseline force keys differ")
    stream_values = []
    candidate_forces = []
    baseline_forces = []
    per_stream = []
    for stream_seed in stream_seeds:
        keys = sorted(key for key in candidate if key[0] == int(stream_seed))
        deltas = []
        stream_candidate = []
        stream_baseline = []
        for key in keys:
            left = candidate[key]
            right = baseline[key]
            if not (left["terminal_valid"] and right["terminal_valid"]):
                continue
            left_force = left["initial_max_force_ev_per_angstrom"]
            right_force = right["initial_max_force_ev_per_angstrom"]
            if left_force is None or right_force is None:
                raise ValueError("common-legal pair lacks a force label")
            left_force = float(left_force)
            right_force = float(right_force)
            stream_candidate.append(left_force)
            stream_baseline.append(right_force)
            deltas.append(math.log1p(left_force) - math.log1p(right_force))
        if not deltas:
            raise ValueError(f"stream {stream_seed} has no common-legal force pair")
        stream_values.append(np.asarray(deltas, dtype=float))
        candidate_forces.extend(stream_candidate)
        baseline_forces.extend(stream_baseline)
        per_stream.append(
            {
                "stream_seed": int(stream_seed),
                "common_legal_n": len(deltas),
                "mean_log1p_force_delta": float(np.mean(deltas)),
            }
        )
    bootstrap = hierarchical_paired_bootstrap(
        stream_values, seed=seed, replicates=replicates
    )
    concatenated = np.concatenate(stream_values)
    return {
        "common_legal_n": int(len(concatenated)),
        "candidate_force": force_statistics(candidate_forces),
        "baseline_force": force_statistics(baseline_forces),
        "mean_log1p_force_delta": bootstrap["point"],
        "ci95_lower": bootstrap["ci95_lower"],
        "ci95_upper": bootstrap["ci95_upper"],
        "candidate_win_rate": float(np.mean(concatenated < 0.0)),
        "per_stream": per_stream,
    }


def trajectory_outcome_rates(
    rows: Sequence[Mapping[str, object]],
) -> dict[str, float]:
    if not rows:
        raise ValueError("outcome rates require trajectories")
    return {
        "geometry_rejection_rate": sum(
            row["failure"] == "PROJECTOR_REJECTED" for row in rows
        )
        / len(rows),
        "discrete_dead_end_rate": sum(
            row["failure"] == "NO_LEGAL_ACTION" for row in rows
        )
        / len(rows),
    }


def final_diagnostic_rows(
    calibrated_rows: Sequence[Mapping[str, object]],
    inverse_rows: Sequence[Mapping[str, object]],
    uniform_rows: Sequence[Mapping[str, object]],
    *,
    selected_lambda: float,
) -> list[dict[str, object]]:
    calibrated = _trajectory_lookup(calibrated_rows)
    inverse = _trajectory_lookup(inverse_rows)
    uniform = _trajectory_lookup(uniform_rows)
    if not (set(calibrated) == set(inverse) == set(uniform)):
        raise ValueError("final diagnostic arm keys differ")
    output = []
    for key in sorted(calibrated):
        joint = calibrated[key]
        baseline = inverse[key]
        control = uniform[key]
        common = bool(joint["terminal_valid"] and baseline["terminal_valid"])
        joint_force = joint["initial_max_force_ev_per_angstrom"]
        inverse_force = baseline["initial_max_force_ev_per_angstrom"]
        if common:
            if joint_force is None or inverse_force is None:
                raise ValueError("common-legal final pair lacks force")
            log_delta = math.log1p(float(joint_force)) - math.log1p(
                float(inverse_force)
            )
        else:
            log_delta = None
        output.append(
            {
                "stream_seed": key[0],
                "parent_id": key[1],
                "selected_lambda": float(selected_lambda),
                "calibrated_terminal_valid": bool(joint["terminal_valid"]),
                "inverse_terminal_valid": bool(baseline["terminal_valid"]),
                "uniform_terminal_valid": bool(control["terminal_valid"]),
                "calibrated_force": joint_force,
                "inverse_force": inverse_force,
                "common_legal_calibrated_inverse": common,
                "log1p_force_delta": log_delta,
                "calibrated_force_win": None
                if log_delta is None
                else log_delta < 0.0,
                "calibrated_minus_inverse_terminal": int(
                    bool(joint["terminal_valid"])
                )
                - int(bool(baseline["terminal_valid"])),
                "calibrated_minus_uniform_terminal": int(
                    bool(joint["terminal_valid"])
                )
                - int(bool(control["terminal_valid"])),
            }
        )
    return output


def calibration_verdict(
    *, terminal_noninferior: bool, physical_improvement: bool
) -> tuple[str, str]:
    if terminal_noninferior and physical_improvement:
        return "PARETO_IMPROVED", "BOUNDED_FIRE_VALIDATION"
    if terminal_noninferior and not physical_improvement:
        return (
            "TERMINAL_PRESERVED_PHYSICAL_GAIN_LOST",
            "KEEP_CURRENT_JOINT_OR_USER_DECISION",
        )
    if not terminal_noninferior and physical_improvement:
        return (
            "PHYSICAL_GAIN_WITH_STATISTICAL_TERMINAL_UNCERTAINTY",
            "STOP_SCORE_TUNING",
        )
    return "NO_PARETO_IMPROVEMENT", "STOP_SCORE_TUNING"


__all__ = [
    "FORCE_TIE_BAND",
    "LambdaValidationResult",
    "REGISTERED_LAMBDAS",
    "TERMINAL_NONINFERIORITY_MARGIN",
    "calibrated_joint_score",
    "calibration_verdict",
    "force_pair_analysis",
    "force_statistics",
    "final_diagnostic_rows",
    "select_pareto_lambda",
    "terminal_pair_analysis",
    "trajectory_outcome_rates",
]
