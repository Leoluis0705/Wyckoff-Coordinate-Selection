from __future__ import annotations

import hashlib
from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Hashable, Mapping, Sequence


@dataclass(frozen=True)
class OODCohort:
    parent_ids: tuple[str, ...]
    selection_mode: str
    maximum_training_frequency: int
    strict_unseen_candidate_n: int
    eligible_candidate_n: int


@dataclass(frozen=True)
class InductiveBiasVerdict:
    nc_deconstruction_inductive_bias: str
    next_action: str


def _hash(seed: int, purpose: str, value: object) -> str:
    return hashlib.sha256(f"{seed}:{purpose}:{value}".encode("utf-8")).hexdigest()


def _proportional_stratified_order(
    parent_ids: Sequence[str],
    *,
    key_by_parent: Mapping[str, Hashable],
    seed: int,
    purpose: str,
) -> tuple[str, ...]:
    grouped: dict[Hashable, list[str]] = defaultdict(list)
    for parent_id in parent_ids:
        grouped[key_by_parent[parent_id]].append(parent_id)
    ranked = []
    for key, values in grouped.items():
        ordered = sorted(values, key=lambda value: (_hash(seed, purpose, value), value))
        size = len(ordered)
        for rank, parent_id in enumerate(ordered):
            ranked.append(
                (
                    (rank + 0.5) / size,
                    _hash(seed, f"{purpose}:tie", (repr(key), parent_id)),
                    parent_id,
                )
            )
    return tuple(value[2] for value in sorted(ranked))


def nested_stratified_subsets(
    parents: Sequence[Mapping[str, object]],
    *,
    sizes: Mapping[str, int],
    seed: int,
) -> dict[str, tuple[str, ...]]:
    by_id = {str(parent["parent_id"]): parent for parent in parents}
    if len(by_id) != len(parents):
        raise ValueError("parent IDs must be unique")
    if not sizes or min(sizes.values()) <= 0 or max(sizes.values()) > len(parents):
        raise ValueError("nested subset sizes are invalid")
    key_by_parent = {
        parent_id: (
            str(parent["crystal_system"]),
            int(parent["element_count"]),
            int(parent["orbit_count"]),
            int(parent["free_dof_count"]),
        )
        for parent_id, parent in by_id.items()
    }
    order = _proportional_stratified_order(
        tuple(by_id),
        key_by_parent=key_by_parent,
        seed=seed,
        purpose="nested-low-data",
    )
    return {name: order[:count] for name, count in sizes.items()}


def select_frequency_ood_cohort(
    *,
    training_parent_ids: Sequence[str],
    candidate_parent_ids: Sequence[str],
    key_by_parent: Mapping[str, Hashable],
    target_n: int,
    seed: int,
    allow_rare_fallback: bool,
) -> OODCohort:
    training = tuple(dict.fromkeys(training_parent_ids))
    candidates = tuple(dict.fromkeys(candidate_parent_ids))
    if len(training) != len(training_parent_ids) or len(candidates) != len(
        candidate_parent_ids
    ):
        raise ValueError("training and candidate parent IDs must be unique")
    if set(training) & set(candidates):
        raise ValueError("training and OOD candidates must be parent-disjoint")
    if target_n <= 0:
        raise ValueError("target_n must be positive")

    training_frequency = Counter(key_by_parent[parent_id] for parent_id in training)
    frequency_by_candidate = {
        parent_id: training_frequency[key_by_parent[parent_id]]
        for parent_id in candidates
    }
    strict = [
        parent_id for parent_id in candidates if frequency_by_candidate[parent_id] == 0
    ]
    if len(strict) >= target_n:
        eligible = strict
        threshold = 0
        mode = "STRICT_UNSEEN"
    else:
        if not allow_rare_fallback:
            raise ValueError(
                f"strict unseen cohort has {len(strict)} candidates, fewer than {target_n}"
            )
        threshold = -1
        eligible = []
        for value in sorted(set(frequency_by_candidate.values())):
            current = [
                parent_id
                for parent_id in candidates
                if frequency_by_candidate[parent_id] <= value
            ]
            if len(current) >= target_n:
                threshold = value
                eligible = current
                break
        if threshold < 0:
            raise ValueError(
                "rare-frequency fallback cannot reach the requested cohort size"
            )
        mode = "RARE_FREQUENCY_FALLBACK"

    order = _proportional_stratified_order(
        tuple(eligible),
        key_by_parent=key_by_parent,
        seed=seed,
        purpose="ood-cohort",
    )
    return OODCohort(
        parent_ids=order[:target_n],
        selection_mode=mode,
        maximum_training_frequency=threshold,
        strict_unseen_candidate_n=len(strict),
        eligible_candidate_n=len(eligible),
    )


def area_under_scaling_curve(
    *, fractions: Sequence[float], rates: Sequence[float]
) -> float:
    if len(fractions) != len(rates) or len(fractions) < 2:
        raise ValueError("AUC needs paired fractions and rates")
    if any(right <= left for left, right in zip(fractions, fractions[1:])):
        raise ValueError("fractions must be strictly increasing")
    return float(
        sum(
            (right_x - left_x) * (left_y + right_y) / 2.0
            for left_x, right_x, left_y, right_y in zip(
                fractions, fractions[1:], rates, rates[1:]
            )
        )
    )


def select_low_data_regimes(eta_minutes: float) -> tuple[str, ...]:
    if eta_minutes <= 25.0:
        return ("10%", "25%", "50%", "100%")
    return ("10%", "25%", "100%")


def low_data_value(effects: Mapping[str, Mapping[str, float]]) -> str:
    if not {"10%", "25%", "100%"} <= set(effects):
        raise ValueError("low-data effects require 10%, 25%, and 100%")
    early_significant = any(effects[name]["ci_lower_pp"] > 0 for name in ("10%", "25%"))
    early_mean = sum(effects[name]["delta_pp"] for name in ("10%", "25%")) / 2.0
    late_names = [name for name in ("50%", "100%") if name in effects]
    late_mean = sum(effects[name]["delta_pp"] for name in late_names) / len(late_names)
    return (
        "SUPPORTED"
        if early_significant and early_mean >= late_mean
        else "NOT_SUPPORTED"
    )


def ood_generalization_value(effects: Mapping[str, Mapping[str, float]]) -> str:
    if set(effects) != {"SG", "ORBIT", "CHEM"}:
        raise ValueError("OOD effects must contain SG, ORBIT, and CHEM")
    supported_n = sum(value["ci_lower_pp"] > 0 for value in effects.values())
    no_significant_reverse = all(
        value["ci_upper_pp"] >= 0 for value in effects.values()
    )
    return (
        "SUPPORTED" if supported_n >= 2 and no_significant_reverse else "NOT_SUPPORTED"
    )


def advantage_amplification(
    effects: Mapping[str, Mapping[str, float]], *, iid_reference_pp: float
) -> str:
    amplified = any(
        value["delta_pp"] > iid_reference_pp and value["ci_lower_pp"] > 0
        for value in effects.values()
    )
    return "SUPPORTED" if amplified else "NOT_SUPPORTED"


def inductive_bias_verdict(
    *,
    low_data_status: str,
    ood_status: str,
    amplification_status: str,
) -> InductiveBiasVerdict:
    status = (
        "SUPPORTED"
        if (low_data_status == "SUPPORTED" or ood_status == "SUPPORTED")
        and amplification_status == "SUPPORTED"
        else "NOT_SUPPORTED"
    )
    return InductiveBiasVerdict(
        nc_deconstruction_inductive_bias=status,
        next_action=(
            "MODEL_AGNOSTIC_REPLICATION"
            if status == "SUPPORTED"
            else "PIVOT_NC_CORE_CLAIM"
        ),
    )
