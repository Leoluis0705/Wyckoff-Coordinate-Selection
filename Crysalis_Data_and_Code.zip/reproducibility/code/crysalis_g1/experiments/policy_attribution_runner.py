from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from dataclasses import asdict
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import torch

from crysalis_g1.experiments.c0_symmetry_data import verify_frozen_phase2a
from crysalis_g1.experiments.c0_symmetry_evaluation import (
    load_c0_symmetry_checkpoint,
)
from crysalis_g1.experiments.chgnet_terminal import (
    CHGNetEvaluationConfig,
    CHGNetTerminalEvaluator,
)
from crysalis_g1.experiments.policy_attribution import (
    build_empirical_frequency_prior,
    generate_baseline_attempts,
)
from crysalis_g1.experiments.policy_attribution_analysis import (
    audit_full_cohort_novelty,
    choose_attribution_decision,
    mcnemar_exact,
    paired_binary_bootstrap,
    space_group_macro_bootstrap,
    summarize_arm,
    summarize_by_space_group,
)

REQUIRED_OUTPUTS = (
    "POLICY_ATTRIBUTION_MANIFEST.json",
    "POLICY_ATTRIBUTION_RESULTS.md",
    "POLICY_ATTRIBUTION_METRICS.json",
    "POLICY_ATTRIBUTION_PAIRED_STATISTICS.json",
    "POLICY_ATTRIBUTION_BY_SPACE_GROUP.json",
    "UNIFORM_LEGAL_GENERATION_RECORDS.json",
    "EMPIRICAL_FREQUENCY_GENERATION_RECORDS.json",
    "EMPIRICAL_FREQUENCY_PRIOR.json",
    "POLICY_ATTRIBUTION_FAILURES.jsonl",
    "C0_COHORT_NOVEL_CANDIDATES.zip",
    "NEXT_SCIENTIFIC_DECISION.md",
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_sha256(path: str | Path, expected: str, *, label: str) -> None:
    source = Path(path)
    actual = _sha256(source)
    if actual.lower() != expected.lower():
        raise ValueError(f"{label} SHA256 mismatch: {actual} != {expected}")


def write_json_new(path: str | Path, payload: Any) -> None:
    destination = Path(path)
    if destination.exists():
        raise FileExistsError(f"refusing to overwrite: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(payload, ensure_ascii=False, allow_nan=False, indent=2, sort_keys=True)
        + "\n",
        encoding="utf-8",
    )


def assert_condition_alignment(
    conditions: Sequence[Mapping[str, Any]],
    arm_records: Mapping[str, Sequence[Mapping[str, Any]]],
    *,
    expected_count: int,
) -> None:
    if len(conditions) != expected_count:
        raise ValueError(
            f"condition manifest count mismatch: {len(conditions)} != {expected_count}"
        )
    canonical = [
        json.dumps(condition, sort_keys=True, separators=(",", ":"))
        for condition in conditions
    ]
    for arm, records in arm_records.items():
        observed = [
            json.dumps(record["condition"], sort_keys=True, separators=(",", ":"))
            for record in records
        ]
        if observed != canonical:
            raise ValueError(f"{arm} records do not match the condition manifest")


def assert_baseline_runtime_isolation(
    records: Sequence[Mapping[str, Any]], *, arm: str
) -> None:
    for record in records:
        assertion = record.get("runtime_assertions", {}).get(
            "LEARNED_ACTION_LOGITS_USED"
        )
        trace = record.get("policy_selection_trace", ())
        if assertion is not False or any(
            step.get("learned_action_logits_used") is not False for step in trace
        ):
            raise ValueError(f"{arm}: LEARNED_ACTION_LOGITS_USED must be false")


def _read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows = []
    with path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as error:
                raise ValueError(f"invalid JSONL at {path}:{line_number}") from error
    return rows


def _write_text_new(path: Path, text: str) -> None:
    if path.exists():
        raise FileExistsError(f"refusing to overwrite: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _named_statistics_seed(root_seed: int, label: str) -> int:
    digest = hashlib.sha256(
        f"{root_seed}:policy_attribution:statistics:{label}".encode("utf-8")
    ).digest()
    return int.from_bytes(digest[:8], "big") % (2**63)


def _verify_git_freeze(
    repository_root: Path,
    commit_sha: str,
    implementation_paths: Sequence[str],
) -> None:
    resolved = subprocess.run(
        ["git", "rev-parse", f"{commit_sha}^{{commit}}"],
        cwd=repository_root,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    if resolved != commit_sha:
        raise ValueError(f"frozen implementation commit mismatch: {resolved}")
    result = subprocess.run(
        ["git", "diff", "--quiet", commit_sha, "--", *implementation_paths],
        cwd=repository_root,
        check=False,
    )
    if result.returncode != 0:
        raise ValueError("frozen C0 implementation differs from its committed state")


def _current_commit(repository_root: Path) -> str:
    return subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=repository_root,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()


def verify_execution_inputs(config: Mapping[str, Any]) -> dict[str, Any]:
    root_seed = int(config["root_seed"])
    if root_seed != 20260823:
        raise ValueError("ROOT_SEED must remain 20260823")
    authorization = dict(config["authorization"])
    if authorization.get("local_execution") is not True:
        raise ValueError("local execution is not authorized")
    forbidden = {
        key: value
        for key, value in authorization.items()
        if key != "local_execution" and value is not False
    }
    if forbidden:
        raise ValueError(f"forbidden authorization enabled: {forbidden}")
    repository_root = Path(config["repository_root"])
    phase2a_root = Path(config["phase2a_root"])
    c0_root = Path(config["c0_root"])
    output_root = Path(config["output_root"])
    if not output_root.is_dir():
        raise ValueError("policy-attribution output directory must already exist")
    for filename in REQUIRED_OUTPUTS:
        if (output_root / filename).exists():
            raise FileExistsError(f"formal output already exists: {filename}")
    gates = (
        (
            phase2a_root / "phase2a_manifest.json",
            config["phase2a_manifest_sha256"],
            "Phase2A manifest",
        ),
        (
            c0_root / "C0_SYMMETRY_MANIFEST.json",
            config["c0_manifest_sha256"],
            "C0-Symmetry manifest",
        ),
        (
            Path(config["checkpoint_path"]),
            config["checkpoint_sha256"],
            "frozen C0 checkpoint",
        ),
        (
            Path(config["condition_manifest_path"]),
            config["condition_manifest_sha256"],
            "condition manifest",
        ),
        (
            Path(config["learned_generation_records_path"]),
            config["learned_generation_records_sha256"],
            "learned generation records",
        ),
        (
            Path(config["learned_fixed_cell_chgnet_path"]),
            config["learned_fixed_cell_chgnet_sha256"],
            "learned fixed-cell CHGNet records",
        ),
        (
            Path(config["learned_cell_relax_chgnet_path"]),
            config["learned_cell_relax_chgnet_sha256"],
            "learned cell-relax CHGNet records",
        ),
        (
            Path(config["chgnet"]["weight_path"]),
            config["chgnet"]["weight_sha256"],
            "CHGNet weight",
        ),
    )
    for path, expected, label in gates:
        verify_sha256(path, str(expected), label=label)
    phase2a_manifest = verify_frozen_phase2a(phase2a_root)
    c0_manifest = _read_json(c0_root / "C0_SYMMETRY_MANIFEST.json")
    if c0_manifest.get("result") != "CORE_METHOD_VIABLE_SIGNAL":
        raise ValueError("frozen C0 result is not CORE_METHOD_VIABLE_SIGNAL")
    if c0_manifest.get("root_seed") != root_seed:
        raise ValueError("frozen C0 root seed mismatch")
    if c0_manifest.get("sealed_or_blind_data_accessed") is not False:
        raise ValueError("frozen C0 manifest does not prove public-only access")
    implementation_hashes = dict(c0_manifest["implementation_file_sha256"])
    for relative, expected in implementation_hashes.items():
        verify_sha256(
            repository_root / relative,
            expected,
            label=f"frozen implementation {relative}",
        )
    _verify_git_freeze(
        repository_root,
        str(config["frozen_implementation_commit_sha"]),
        tuple(implementation_hashes),
    )
    replay = _read_json(Path(config["learned_replay_evidence"]))
    if replay.get("passed") is not True or replay.get("match_count") != 20:
        raise ValueError("20-condition learned deterministic replay did not pass")
    condition_payload = _read_json(Path(config["condition_manifest_path"]))
    conditions = condition_payload["conditions"]
    attempt_count = int(config["attempt_count"])
    if len(conditions) != attempt_count:
        raise ValueError("condition manifest attempt count mismatch")
    forbidden_condition_fields = {
        "material_id",
        "parent_structure",
        "parent_coordinates",
        "parent_lattice",
        "true_orbit_sequence",
        "true_orbit_count",
        "future_inverse_actions",
    }
    if any(forbidden_condition_fields.intersection(condition) for condition in conditions):
        raise ValueError("condition manifest contains forbidden parent or future fields")
    observed_space_groups = {int(row["space_group"]) for row in conditions}
    if observed_space_groups != {int(value) for value in config["top_space_groups"]}:
        raise ValueError("condition manifest space-group set mismatch")
    learned_payload = _read_json(Path(config["learned_generation_records_path"]))
    learned_records = learned_payload["records"]
    assert_condition_alignment(
        conditions,
        {"LEARNED": learned_records},
        expected_count=attempt_count,
    )
    learned_success = sum(
        bool(record.get("legal_terminal_crystal")) for record in learned_records
    )
    if learned_success != int(config["expected_learned_legal_terminal_count"]):
        raise ValueError("frozen learned legal-terminal count mismatch")
    learned_fixed = _read_json(Path(config["learned_fixed_cell_chgnet_path"]))
    learned_cell = _read_json(Path(config["learned_cell_relax_chgnet_path"]))
    if len(learned_fixed["records"]) != attempt_count or len(
        learned_cell["records"]
    ) != attempt_count:
        raise ValueError("learned CHGNet attempt count mismatch")
    return {
        "phase2a_manifest": phase2a_manifest,
        "c0_manifest": c0_manifest,
        "conditions": conditions,
        "learned_records": learned_records,
        "learned_fixed": learned_fixed,
        "learned_cell": learned_cell,
        "learned_replay": replay,
        "attribution_implementation_commit_sha": _current_commit(repository_root),
    }


def _chgnet_config(config: Mapping[str, Any], *, relax_cell: bool) -> CHGNetEvaluationConfig:
    payload = config["chgnet"]
    return CHGNetEvaluationConfig(
        package_version=str(payload["package_version"]),
        model_version=str(payload["model_version"]),
        weight_path=str(payload["weight_path"]),
        weight_sha256=str(payload["weight_sha256"]),
        optimizer=str(payload["optimizer"]),
        force_threshold_ev_per_angstrom=float(
            payload["force_threshold_ev_per_angstrom"]
        ),
        maximum_steps=int(payload["maximum_steps"]),
        relax_cell=relax_cell,
        short_contact_distance=float(payload["short_contact_distance"]),
        device=str(config["device"]),
    )


def _endpoint2(
    conditions: Sequence[Mapping[str, Any]],
    fixed_records: Sequence[Mapping[str, Any]],
) -> list[bool]:
    by_id = {str(record["condition_id"]): record for record in fixed_records}
    return [
        bool(by_id[str(condition["condition_id"])].get("post_relax_survival"))
        and bool(by_id[str(condition["condition_id"])].get("space_group_match"))
        for condition in conditions
    ]


def _pair_comparison(
    learned: Sequence[bool],
    baseline: Sequence[bool],
    *,
    resamples: int,
    seed: int,
) -> dict[str, Any]:
    result = paired_binary_bootstrap(
        learned,
        baseline,
        resamples=resamples,
        seed=seed,
    )
    result["mcnemar_exact"] = mcnemar_exact(learned, baseline)
    result["bootstrap_seed"] = seed
    return result


def _markdown_results(
    *,
    metrics: Mapping[str, Any],
    paired: Mapping[str, Any],
    by_space_group: Mapping[str, Any],
    decision: str,
) -> str:
    arms = ("LEARNED", "UNIFORM_LEGAL", "EMPIRICAL_FREQUENCY")
    lines = [
        "# Crysalis-G1 C0 policy attribution results",
        "",
        f"**Preregistered conclusion: `{decision}`**",
        "",
        "This single-seed experiment isolates only ADD_ORBIT action selection. "
        "Geometry, lattice, termination, legal compilation, projection, and CHGNet "
        "remain frozen and shared.",
        "",
        "## Primary endpoints",
        "",
        "| Arm | Legal terminal / 300 | Fixed-cell symmetry-preserving survival / 300 | SG-macro legal terminal rate |",
        "|---|---:|---:|---:|",
    ]
    for arm in arms:
        arm_metrics = metrics["arms"][arm]
        fixed = arm_metrics["fixed_cell_FIRE300"]
        lines.append(
            f"| {arm} | {arm_metrics['symmetry_valid_legal_terminal_count']}/300 "
            f"({arm_metrics['symmetry_valid_legal_terminal_rate']:.4f}) | "
            f"{fixed['symmetry_preserving_physical_survival_count']}/300 "
            f"({fixed['symmetry_preserving_physical_survival_rate_all_attempts']:.4f}) | "
            f"{metrics['primary_endpoints']['space_group_macro_symmetry_valid_terminal_rate'][arm]:.4f} |"
        )
    lines.extend(
        [
            "",
            "## Paired effects",
            "",
            "| Endpoint | Comparison | Delta | 95% paired bootstrap CI |",
            "|---|---|---:|---:|",
        ]
    )
    for endpoint_name in ("PRIMARY_ENDPOINT_1", "PRIMARY_ENDPOINT_2"):
        for comparison in ("learned_minus_uniform", "learned_minus_empirical"):
            row = paired[endpoint_name][comparison]
            ci = row["confidence_interval_95"]
            lines.append(
                f"| {endpoint_name} | {comparison} | {row['observed_delta']:.4f} | "
                f"[{ci[0]:.4f}, {ci[1]:.4f}] |"
            )
    for comparison in ("learned_minus_uniform", "learned_minus_empirical"):
        row = paired["PRIMARY_ENDPOINT_3"][comparison]
        ci = row["confidence_interval_95"]
        lines.append(
            f"| PRIMARY_ENDPOINT_3 | {comparison} | {row['observed_delta']:.4f} | "
            f"[{ci[0]:.4f}, {ci[1]:.4f}] |"
        )
    lines.extend(
        [
            "",
            "The confidence intervals reflect condition-level uncertainty only; they "
            "do not estimate training-seed uncertainty.",
            "",
            "## Secondary metrics",
            "",
            "| Arm | Completion | No legal | Projector rejected | Short-contact rejected | Initial force mean | Fixed convergence | Cell convergence | Unique | Novel vs 7,838 |",
            "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for arm in arms:
        row = metrics["arms"][arm]
        initial_force = row["initial_CHGNet_max_force"]["mean"]
        initial_text = "NA" if initial_force is None else f"{initial_force:.4f}"
        lines.append(
            f"| {arm} | {row['free_rollout_completion_rate']:.4f} | "
            f"{row['NO_LEGAL_ADD_ORBIT_ACTION_count']} | "
            f"{row['PROJECTOR_REJECTED_count']} | "
            f"{row['SHORT_CONTACT_rejection_count']} | {initial_text} | "
            f"{row['fixed_cell_FIRE300']['convergence_count']} | "
            f"{row['cell_relax_FIRE300']['convergence_count']} | "
            f"{row['unique_structures']} | "
            f"{row['novel_structures_relative_to_full_7838_parent_cohort']} |"
        )
    lines.extend(
        [
            "",
            "## Results by target space group",
            "",
            "| SG | Arm | Attempts | Terminal | No legal | Projector reject | Short contact | Fixed convergence | Fixed symmetry survival |",
            "|---:|---|---:|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for space_group, arm_rows in by_space_group["space_groups"].items():
        for arm in arms:
            row = arm_rows[arm]
            lines.append(
                f"| {space_group} | {arm} | {row['attempts']} | "
                f"{row['terminal_success']} | {row['no_legal_action']} | "
                f"{row['projector_rejection']} | {row['short_contact_rejection']} | "
                f"{row['fixed_cell_CHGNet_convergence']} | "
                f"{row['fixed_cell_symmetry_preserving_survival']} |"
            )
    lines.extend(
        [
            "",
            "## Novelty scope",
            "",
            "Novelty is reported against `train_fit` and the frozen 7,838-parent "
            "cohort only. The exported learned candidates are not claimed to be "
            "database-globally novel.",
            "",
            "## Frozen boundaries",
            "",
            "No model retraining, Phase2A rebuild, refill, server, DFT, extra seed, "
            "temperature search, KAN, Relation Memory, Physics, e3nn, new dataset, "
            "or new deconstruction operator was used.",
            "",
        ]
    )
    return "\n".join(lines)


def _decision_markdown(decision: str, paired: Mapping[str, Any]) -> str:
    explanations = {
        "LEARNED_REVERSE_ASSEMBLY_STRONGLY_SUPPORTED": (
            "The learned policy beats both non-learned policies on legal terminals "
            "with both lower confidence bounds above zero; fixed-cell survival and "
            "SG-macro directions also satisfy the preregistered rule."
        ),
        "LEARNED_REVERSE_ASSEMBLY_SUPPORTED_WITH_LIMITATIONS": (
            "The learned policy has a positive observed legal-terminal effect against "
            "both baselines, but confidence, physical survival, or SG-macro evidence "
            "is incomplete or concentrated by space group."
        ),
        "CRYSTALLOGRAPHIC_SEARCH_SPACE_IS_PRIMARY_CONTRIBUTOR": (
            "The learned action policy does not show a positive legal-terminal effect "
            "against both baselines. Current forward generation is therefore attributed "
            "primarily to the symmetry-constrained orbit state space and hard "
            "crystallographic constraints, not to the learned inverse policy."
        ),
        "ATTRIBUTION_INCONCLUSIVE": (
            "Engineering or sample-comparability failure prevented the preregistered "
            "paired comparison."
        ),
    }
    return "\n".join(
        [
            "# Next scientific decision",
            "",
            f"`{decision}`",
            "",
            explanations[decision],
            "",
            "This is a frozen single-training-seed attribution result. The paired "
            "confidence intervals quantify condition-level uncertainty and do not "
            "quantify training-seed uncertainty.",
            "",
            f"Bootstrap resamples per comparison: {paired['bootstrap_resamples']}.",
            "",
            "Execution stops here. No KAN, Physics, Relation Memory, server, or "
            "three-seed experiment is authorized by this result.",
            "",
        ]
    )


def run_policy_attribution(config_path: str | Path) -> Path:
    config_path = Path(config_path)
    config = _read_json(config_path)
    verified = verify_execution_inputs(config)
    output_root = Path(config["output_root"])
    engineering = output_root / "engineering"
    engineering.mkdir(exist_ok=True)
    conditions = verified["conditions"]
    learned_records = verified["learned_records"]
    prior, prior_payload = build_empirical_frequency_prior(
        phase2a_root=config["phase2a_root"],
        recovered_parent_cache=config["recovered_parent_cache"],
        alpha=1.0,
    )
    write_json_new(output_root / "EMPIRICAL_FREQUENCY_PRIOR.json", prior_payload)
    model, checkpoint_payload = load_c0_symmetry_checkpoint(
        config["checkpoint_path"], device=str(config["device"])
    )
    uniform_records = generate_baseline_attempts(
        model,
        conditions,
        arm="UNIFORM_LEGAL",
        empirical_prior=None,
        root_seed=int(config["root_seed"]),
        device=str(config["device"]),
        minimum_distance=float(config["minimum_distance_angstrom"]),
    )
    assert_baseline_runtime_isolation(uniform_records, arm="UNIFORM_LEGAL")
    uniform_payload = {
        "schema_version": "g1-policy-attribution-generation.1.0.0",
        "policy_arm": "UNIFORM_LEGAL",
        "root_seed": int(config["root_seed"]),
        "policy_namespace": "policy_attribution:uniform",
        "condition_manifest_sha256": config["condition_manifest_sha256"],
        "checkpoint_sha256": config["checkpoint_sha256"],
        "LEARNED_ACTION_LOGITS_USED": False,
        "records": uniform_records,
    }
    write_json_new(output_root / "UNIFORM_LEGAL_GENERATION_RECORDS.json", uniform_payload)
    empirical_records = generate_baseline_attempts(
        model,
        conditions,
        arm="EMPIRICAL_FREQUENCY",
        empirical_prior=prior,
        root_seed=int(config["root_seed"]),
        device=str(config["device"]),
        minimum_distance=float(config["minimum_distance_angstrom"]),
    )
    assert_baseline_runtime_isolation(
        empirical_records, arm="EMPIRICAL_FREQUENCY"
    )
    empirical_payload = {
        "schema_version": "g1-policy-attribution-generation.1.0.0",
        "policy_arm": "EMPIRICAL_FREQUENCY",
        "root_seed": int(config["root_seed"]),
        "policy_namespace": "policy_attribution:empirical",
        "condition_manifest_sha256": config["condition_manifest_sha256"],
        "checkpoint_sha256": config["checkpoint_sha256"],
        "empirical_prior_sha256": _sha256(
            output_root / "EMPIRICAL_FREQUENCY_PRIOR.json"
        ),
        "LEARNED_ACTION_LOGITS_USED": False,
        "records": empirical_records,
    }
    write_json_new(
        output_root / "EMPIRICAL_FREQUENCY_GENERATION_RECORDS.json",
        empirical_payload,
    )
    assert_condition_alignment(
        conditions,
        {
            "LEARNED": learned_records,
            "UNIFORM_LEGAL": uniform_records,
            "EMPIRICAL_FREQUENCY": empirical_records,
        },
        expected_count=int(config["attempt_count"]),
    )
    del model, checkpoint_payload
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    fixed_evaluator = CHGNetTerminalEvaluator(_chgnet_config(config, relax_cell=False))
    cell_evaluator = CHGNetTerminalEvaluator(
        _chgnet_config(config, relax_cell=True),
        optimizer=fixed_evaluator.optimizer,
    )
    uniform_fixed = fixed_evaluator.evaluate(
        uniform_records,
        output_path=engineering / "uniform_fixed_cell_fire300.json",
    )
    uniform_cell = cell_evaluator.evaluate(
        uniform_records,
        output_path=engineering / "uniform_cell_relax_fire300.json",
    )
    empirical_fixed = fixed_evaluator.evaluate(
        empirical_records,
        output_path=engineering / "empirical_fixed_cell_fire300.json",
    )
    empirical_cell = cell_evaluator.evaluate(
        empirical_records,
        output_path=engineering / "empirical_cell_relax_fire300.json",
    )
    learned_fixed = verified["learned_fixed"]
    learned_cell = verified["learned_cell"]
    parent_rows = _read_jsonl(Path(config["recovered_parent_cache"]))
    phase2a_root = Path(config["phase2a_root"])
    split_rows = _read_jsonl(
        phase2a_root / "splits" / "structure_ood_manifest.jsonl"
    )
    train_fit_ids = {
        str(row["material_id"])
        for row in split_rows
        if str(row["split"]) == "train_fit"
    }
    learned_novelty = audit_full_cohort_novelty(
        generation_records=learned_records,
        fixed_cell_records=learned_fixed["records"],
        cell_relax_records=learned_cell["records"],
        parent_rows=parent_rows,
        train_fit_ids=train_fit_ids,
        expected_parent_count=7838,
        export_directory=output_root / "C0_COHORT_NOVEL_CANDIDATES",
        zip_path=output_root / "C0_COHORT_NOVEL_CANDIDATES.zip",
    )
    uniform_novelty = audit_full_cohort_novelty(
        generation_records=uniform_records,
        fixed_cell_records=uniform_fixed["records"],
        cell_relax_records=uniform_cell["records"],
        parent_rows=parent_rows,
        train_fit_ids=train_fit_ids,
        expected_parent_count=7838,
    )
    empirical_novelty = audit_full_cohort_novelty(
        generation_records=empirical_records,
        fixed_cell_records=empirical_fixed["records"],
        cell_relax_records=empirical_cell["records"],
        parent_rows=parent_rows,
        train_fit_ids=train_fit_ids,
        expected_parent_count=7838,
    )
    arms = {
        "LEARNED": (
            learned_records,
            learned_fixed["records"],
            learned_cell["records"],
            learned_novelty,
        ),
        "UNIFORM_LEGAL": (
            uniform_records,
            uniform_fixed["records"],
            uniform_cell["records"],
            uniform_novelty,
        ),
        "EMPIRICAL_FREQUENCY": (
            empirical_records,
            empirical_fixed["records"],
            empirical_cell["records"],
            empirical_novelty,
        ),
    }
    arm_metrics = {
        name: summarize_arm(
            records,
            fixed_cell_records=fixed_records,
            cell_relax_records=cell_records,
            uniqueness=novelty,
        )
        for name, (records, fixed_records, cell_records, novelty) in arms.items()
    }
    per_arm_space_group = {
        name: summarize_by_space_group(
            records,
            fixed_cell_records=fixed_records,
            cell_relax_records=cell_records,
            required_space_groups=config["top_space_groups"],
        )
        for name, (records, fixed_records, cell_records, _) in arms.items()
    }
    by_space_group = {
        "schema_version": "g1-policy-attribution-by-space-group.1.0.0",
        "space_groups": {
            str(space_group): {
                name: per_arm_space_group[name][str(space_group)] for name in arms
            }
            for space_group in config["top_space_groups"]
        },
    }
    macro_rates = {
        name: float(
            np.mean(
                [
                    per_arm_space_group[name][str(space_group)][
                        "terminal_success_rate"
                    ]
                    for space_group in config["top_space_groups"]
                ]
            )
        )
        for name in arms
    }
    metrics = {
        "schema_version": "g1-policy-attribution-metrics.1.0.0",
        "root_seed": int(config["root_seed"]),
        "attempt_count_per_arm": int(config["attempt_count"]),
        "failure_denominator_per_arm": int(config["attempt_count"]),
        "primary_endpoints": {
            "symmetry_valid_legal_terminal_rate": {
                name: arm_metrics[name]["symmetry_valid_legal_terminal_rate"]
                for name in arms
            },
            "fixed_cell_FIRE300_symmetry_preserving_physical_survival_rate": {
                name: arm_metrics[name]["fixed_cell_FIRE300"][
                    "symmetry_preserving_physical_survival_rate_all_attempts"
                ]
                for name in arms
            },
            "space_group_macro_symmetry_valid_terminal_rate": macro_rates,
        },
        "arms": arm_metrics,
        "novelty": {
            "LEARNED": learned_novelty,
            "UNIFORM_LEGAL": uniform_novelty,
            "EMPIRICAL_FREQUENCY": empirical_novelty,
            "database_global_novelty_claimed": False,
        },
    }
    endpoint1 = {
        name: [bool(record.get("legal_terminal_crystal")) for record in values[0]]
        for name, values in arms.items()
    }
    endpoint2 = {
        name: _endpoint2(conditions, values[1]) for name, values in arms.items()
    }
    space_groups = [int(condition["space_group"]) for condition in conditions]
    resamples = int(config["bootstrap_resamples"])
    e1_uniform = _pair_comparison(
        endpoint1["LEARNED"],
        endpoint1["UNIFORM_LEGAL"],
        resamples=resamples,
        seed=_named_statistics_seed(int(config["root_seed"]), "e1-uniform"),
    )
    e1_empirical = _pair_comparison(
        endpoint1["LEARNED"],
        endpoint1["EMPIRICAL_FREQUENCY"],
        resamples=resamples,
        seed=_named_statistics_seed(int(config["root_seed"]), "e1-empirical"),
    )
    e2_uniform = _pair_comparison(
        endpoint2["LEARNED"],
        endpoint2["UNIFORM_LEGAL"],
        resamples=resamples,
        seed=_named_statistics_seed(int(config["root_seed"]), "e2-uniform"),
    )
    e2_empirical = _pair_comparison(
        endpoint2["LEARNED"],
        endpoint2["EMPIRICAL_FREQUENCY"],
        resamples=resamples,
        seed=_named_statistics_seed(int(config["root_seed"]), "e2-empirical"),
    )
    macro_uniform = space_group_macro_bootstrap(
        learned=endpoint1["LEARNED"],
        baseline=endpoint1["UNIFORM_LEGAL"],
        space_groups=space_groups,
        required_space_groups=config["top_space_groups"],
        resamples=resamples,
        seed=_named_statistics_seed(int(config["root_seed"]), "macro-uniform"),
    )
    macro_empirical = space_group_macro_bootstrap(
        learned=endpoint1["LEARNED"],
        baseline=endpoint1["EMPIRICAL_FREQUENCY"],
        space_groups=space_groups,
        required_space_groups=config["top_space_groups"],
        resamples=resamples,
        seed=_named_statistics_seed(int(config["root_seed"]), "macro-empirical"),
    )
    paired = {
        "schema_version": "g1-policy-attribution-paired-statistics.1.0.0",
        "bootstrap_resamples": resamples,
        "uncertainty_scope": (
            "condition-level uncertainty only; not training-seed uncertainty"
        ),
        "PRIMARY_ENDPOINT_1": {
            "definition": "symmetry_valid_legal_terminal_rate; denominator all 300 attempts",
            "learned_minus_uniform": e1_uniform,
            "learned_minus_empirical": e1_empirical,
        },
        "PRIMARY_ENDPOINT_2": {
            "definition": (
                "fixed-cell FIRE300 symmetry-preserving physical survival rate; "
                "denominator all 300 attempts"
            ),
            "learned_minus_uniform": e2_uniform,
            "learned_minus_empirical": e2_empirical,
        },
        "PRIMARY_ENDPOINT_3": {
            "definition": "eight-space-group macro legal-terminal rate",
            "learned_minus_uniform": macro_uniform,
            "learned_minus_empirical": macro_empirical,
        },
        "paired_condition_outcomes": [
            {
                "condition_id": str(condition["condition_id"]),
                "target_space_group": int(condition["space_group"]),
                "learned_success": endpoint1["LEARNED"][index],
                "uniform_success": endpoint1["UNIFORM_LEGAL"][index],
                "empirical_success": endpoint1["EMPIRICAL_FREQUENCY"][index],
                "learned_fixed_symmetry_survival": endpoint2["LEARNED"][index],
                "uniform_fixed_symmetry_survival": endpoint2["UNIFORM_LEGAL"][index],
                "empirical_fixed_symmetry_survival": endpoint2[
                    "EMPIRICAL_FREQUENCY"
                ][index],
            }
            for index, condition in enumerate(conditions)
        ],
    }
    decision = choose_attribution_decision(
        comparable=True,
        endpoint1={
            "learned_minus_uniform": e1_uniform,
            "learned_minus_empirical": e1_empirical,
        },
        endpoint2={
            "learned_minus_uniform": e2_uniform,
            "learned_minus_empirical": e2_empirical,
        },
        macro={
            "learned_minus_uniform": macro_uniform,
            "learned_minus_empirical": macro_empirical,
        },
    )
    failure_rows = []
    for arm, (records, fixed_records, cell_records, novelty) in arms.items():
        for record in records:
            if record.get("failure_code"):
                failure_rows.append(
                    {
                        "arm": arm,
                        "condition_id": record["condition"]["condition_id"],
                        "stage": "GENERATION",
                        "failure_code": record["failure_code"],
                        "projector_rejection_reasons": record.get(
                            "projector_rejection_reasons", []
                        ),
                    }
                )
        for protocol, relaxation_records in (
            ("FIXED_CELL_FIRE300", fixed_records),
            ("CELL_RELAX_FIRE300", cell_records),
        ):
            for record in relaxation_records:
                if record.get("status") in {
                    "CHGNET_RELAXATION_FAILED",
                    "UNSUPPORTED_ELEMENT_DOMAIN",
                }:
                    failure_rows.append(
                        {
                            "arm": arm,
                            "condition_id": record["condition_id"],
                            "stage": protocol,
                            "failure_code": record["status"],
                            "evidence": {
                                key: value
                                for key, value in record.items()
                                if key
                                in {
                                    "exception_type",
                                    "exception_message",
                                    "maximum_atomic_number",
                                }
                            },
                        }
                    )
        if novelty["candidate_parse_failure_count"] or novelty[
            "structure_matcher_failure_count"
        ]:
            failure_rows.append(
                {
                    "arm": arm,
                    "stage": "NOVELTY_AUDIT",
                    "failure_code": "NOVELTY_AUDIT_PARTIAL_FAILURE",
                    "candidate_parse_failure_count": novelty[
                        "candidate_parse_failure_count"
                    ],
                    "structure_matcher_failure_count": novelty[
                        "structure_matcher_failure_count"
                    ],
                }
            )
    failure_text = "".join(
        json.dumps(row, sort_keys=True, allow_nan=False) + "\n"
        for row in failure_rows
    )
    _write_text_new(output_root / "POLICY_ATTRIBUTION_FAILURES.jsonl", failure_text)
    write_json_new(output_root / "POLICY_ATTRIBUTION_METRICS.json", metrics)
    write_json_new(
        output_root / "POLICY_ATTRIBUTION_PAIRED_STATISTICS.json", paired
    )
    write_json_new(
        output_root / "POLICY_ATTRIBUTION_BY_SPACE_GROUP.json", by_space_group
    )
    _write_text_new(
        output_root / "POLICY_ATTRIBUTION_RESULTS.md",
        _markdown_results(
            metrics=metrics,
            paired=paired,
            by_space_group=by_space_group,
            decision=decision,
        ),
    )
    _write_text_new(
        output_root / "NEXT_SCIENTIFIC_DECISION.md",
        _decision_markdown(decision, paired),
    )
    required_without_manifest = [
        filename
        for filename in REQUIRED_OUTPUTS
        if filename != "POLICY_ATTRIBUTION_MANIFEST.json"
    ]
    file_hashes = {
        filename: _sha256(output_root / filename)
        for filename in required_without_manifest
    }
    engineering_hashes = {
        str(path.relative_to(output_root)).replace("\\", "/"): _sha256(path)
        for path in sorted(engineering.glob("*.json"))
    }
    candidate_hashes = {
        str(path.relative_to(output_root)).replace("\\", "/"): _sha256(path)
        for path in sorted(
            (output_root / "C0_COHORT_NOVEL_CANDIDATES").glob("*")
        )
        if path.is_file()
    }
    evidence_hashes = {
        filename: _sha256(output_root / filename)
        for filename in (
            "FROZEN_IMPLEMENTATION.patch",
            "POLICY_ATTRIBUTION_IMPLEMENTATION.patch",
            "LEARNED_DETERMINISTIC_REPLAY_20.json",
            "LEARNED_DETERMINISTIC_REPLAY_20_RAW_TYPE_DIAGNOSTIC.json",
        )
    }
    source_paths = (
        "configs/g1_c0_policy_attribution_20260825.json",
        "crysalis_g1/experiments/policy_attribution.py",
        "crysalis_g1/experiments/policy_attribution_analysis.py",
        "crysalis_g1/experiments/policy_attribution_runner.py",
        "tests/crysalis_g1/test_policy_attribution.py",
        "tests/crysalis_g1/test_policy_attribution_analysis.py",
        "tests/crysalis_g1/test_policy_attribution_runner.py",
    )
    repository_root = Path(config["repository_root"])
    manifest = {
        "schema_version": "g1-policy-attribution-manifest.1.0.0",
        "result": decision,
        "root_seed": int(config["root_seed"]),
        "attempt_count_per_arm": int(config["attempt_count"]),
        "arms": ["LEARNED", "UNIFORM_LEGAL", "EMPIRICAL_FREQUENCY"],
        "only_action_selection_replaced": True,
        "baseline_runtime_assertion": {"LEARNED_ACTION_LOGITS_USED": False},
        "frozen_implementation_commit_sha": config[
            "frozen_implementation_commit_sha"
        ],
        "attribution_implementation_commit_sha": verified[
            "attribution_implementation_commit_sha"
        ],
        "phase2a_manifest_sha256": config["phase2a_manifest_sha256"],
        "condition_manifest_sha256": config["condition_manifest_sha256"],
        "checkpoint_sha256": config["checkpoint_sha256"],
        "learned_deterministic_replay_20_passed": True,
        "bootstrap_resamples": resamples,
        "uncertainty_scope": (
            "condition-level uncertainty only; not training-seed uncertainty"
        ),
        "file_sha256": {
            **file_hashes,
            **engineering_hashes,
            **candidate_hashes,
            **evidence_hashes,
        },
        "implementation_file_sha256": {
            relative: _sha256(repository_root / relative) for relative in source_paths
        },
        "frozen_c0_implementation_file_sha256": verified["c0_manifest"][
            "implementation_file_sha256"
        ],
        "freeze_patch_sha256": _sha256(output_root / "FROZEN_IMPLEMENTATION.patch"),
        "authorization": dict(config["authorization"]),
        "old_checkpoint_retraining": False,
        "formal_training_started": False,
        "phase2a_rebuilt": False,
        "refill_count": 0,
        "server_used": False,
        "three_seed_authorized": False,
        "dft_used": False,
        "sealed_or_blind_data_accessed": False,
        "database_global_novelty_claimed": False,
        "stopped_after_policy_attribution": True,
        "manifest_self_hash_omitted": True,
        "chgnet_config": asdict(_chgnet_config(config, relax_cell=False)),
    }
    write_json_new(output_root / "POLICY_ATTRIBUTION_MANIFEST.json", manifest)
    return output_root


def main() -> int:
    parser = argparse.ArgumentParser(description="Run frozen C0 policy attribution")
    parser.add_argument("--config", required=True)
    arguments = parser.parse_args()
    output = run_policy_attribution(arguments.config)
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
