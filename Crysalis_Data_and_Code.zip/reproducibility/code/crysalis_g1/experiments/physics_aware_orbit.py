from __future__ import annotations

import hashlib
import math
from collections import defaultdict
from dataclasses import dataclass, fields
from typing import Mapping, Sequence

import numpy as np
import torch
from torch import nn
from torch.nn import functional

from crysalis_g1.experiments.orbit_inverse_policy import (
    OrbitInversePolicy,
    OrbitPolicyBatch,
)
from crysalis_g1.geometry_mdn.model import GeometryMDNBatch, WrappedMDNOutput


VALUE_HEAD_INPUT_DIMENSION = 200
VALUE_HEAD_HIDDEN_WIDTH = 128


def deterministic_stratified_parent_sample(
    parents: Sequence[Mapping[str, object]], *, count: int, seed: int
) -> tuple[str, ...]:
    if not 0 < count <= len(parents):
        raise ValueError("sample count must be positive and no larger than the cohort")
    parent_ids = [str(item["parent_id"]) for item in parents]
    if len(set(parent_ids)) != len(parent_ids):
        raise ValueError("parent IDs must be unique")
    grouped: dict[tuple[object, ...], list[str]] = defaultdict(list)
    for item in parents:
        grouped[
            (
                str(item["crystal_system"]),
                int(item["orbit_count"]),
                int(item["free_dof_count"]),
                int(item["element_count"]),
            )
        ].append(str(item["parent_id"]))
    total = len(parents)
    allocation = {
        key: math.floor(len(values) * count / total) for key, values in grouped.items()
    }
    missing = count - sum(allocation.values())
    remainders = sorted(
        grouped,
        key=lambda key: (
            -(len(grouped[key]) * count / total - allocation[key]),
            repr(key),
        ),
    )
    for key in remainders[:missing]:
        allocation[key] += 1
    selected: list[str] = []
    for key, values in grouped.items():
        ordered = sorted(
            values,
            key=lambda parent_id: (
                hashlib.sha256(f"{int(seed)}:{parent_id}".encode("utf-8")).hexdigest(),
                parent_id,
            ),
        )
        selected.extend(ordered[: allocation[key]])
    if len(selected) != count:
        raise RuntimeError("stratified allocation did not produce the requested count")
    return tuple(sorted(selected))


def extract_frozen_policy_features(
    policy: OrbitInversePolicy, batch: OrbitPolicyBatch
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    with torch.no_grad():
        active_token = torch.cat(
            (
                policy.species_embedding(batch.active_species),
                policy.wyckoff_embedding(batch.active_wyckoff),
                batch.active_multiplicity.unsqueeze(-1),
                policy.dof_embedding(batch.active_dof),
                policy._circular(batch.active_free_parameters),
                policy._circular(batch.active_representative),
            ),
            dim=-1,
        )
        active_weight = batch.active_mask.to(active_token.dtype).unsqueeze(-1)
        active_encoded = policy.active_encoder(active_token)
        active = (active_encoded * active_weight).sum(dim=1) / active_weight.sum(
            dim=1
        ).clamp_min(1.0)
        state = policy.state_encoder(
            torch.cat(
                (
                    policy.composition_encoder(batch.composition),
                    policy.remaining_encoder(batch.remaining_composition),
                    policy.lattice_encoder(batch.lattice),
                    policy.space_group_embedding(batch.target_sg),
                    active,
                    batch.progress,
                ),
                dim=-1,
            )
        )
        candidates = policy.candidate_encoder(
            torch.cat(
                (
                    policy.species_embedding(batch.candidate_species),
                    policy.wyckoff_embedding(batch.candidate_wyckoff),
                    batch.candidate_multiplicity.unsqueeze(-1),
                    policy.dof_embedding(batch.candidate_dof),
                    batch.candidate_feasibility,
                ),
                dim=-1,
            )
        )
        expanded = state.unsqueeze(1).expand(-1, candidates.shape[1], -1)
        logits = policy.scorer(torch.cat((expanded, candidates), dim=-1)).squeeze(-1)
        logits = logits.masked_fill(~batch.legal_mask, -torch.inf)
    return state.detach(), candidates.detach(), logits.detach()


def mdn_distribution_features(
    output: WrappedMDNOutput, free_dof_mask: torch.Tensor
) -> torch.Tensor:
    if output.mean_angles.shape != output.concentration.shape:
        raise ValueError("MDN mean and concentration shapes differ")
    if output.logits.shape != output.mean_angles.shape[:2]:
        raise ValueError("MDN component shapes differ")
    if free_dof_mask.shape != output.mean_angles.shape[::2]:
        raise ValueError("free-DOF mask shape differs from MDN output")
    probability = torch.softmax(output.logits, dim=-1)
    log_probability = torch.log_softmax(output.logits, dim=-1)
    entropy = -(probability * log_probability).sum(dim=-1)
    maximum_probability = probability.max(dim=-1).values
    effective_count = torch.exp(entropy)
    mask = free_dof_mask.to(torch.bool)
    dof_count = mask.sum(dim=-1).to(output.logits.dtype)
    weighted_kappa_by_dof = (
        probability.unsqueeze(-1) * output.concentration
    ).sum(dim=1)
    mean_kappa = (
        weighted_kappa_by_dof * mask.to(weighted_kappa_by_dof.dtype)
    ).sum(dim=-1) / dof_count.clamp_min(1.0)
    component_mask = mask.unsqueeze(1).expand_as(output.concentration)
    maximum_kappa = output.concentration.masked_fill(~component_mask, -torch.inf).flatten(
        1
    ).max(dim=-1).values
    maximum_kappa = torch.where(dof_count > 0, maximum_kappa, torch.zeros_like(maximum_kappa))
    resultant_scale = torch.special.i1e(output.concentration) / torch.special.i0e(
        output.concentration
    ).clamp_min(torch.finfo(output.concentration.dtype).tiny)
    resultant_x = (
        probability.unsqueeze(-1)
        * resultant_scale
        * torch.cos(output.mean_angles)
    ).sum(dim=1)
    resultant_y = (
        probability.unsqueeze(-1)
        * resultant_scale
        * torch.sin(output.mean_angles)
    ).sum(dim=1)
    dispersion_by_dof = 1.0 - torch.sqrt(
        resultant_x.square() + resultant_y.square()
    ).clamp(max=1.0)
    dispersion = (
        dispersion_by_dof * mask.to(dispersion_by_dof.dtype)
    ).sum(dim=-1) / dof_count.clamp_min(1.0)
    return torch.stack(
        (
            entropy,
            maximum_probability,
            effective_count,
            mean_kappa,
            maximum_kappa,
            dof_count,
            dispersion,
        ),
        dim=-1,
    )


def stack_geometry_mdn_batches(
    batches: Sequence[GeometryMDNBatch],
) -> GeometryMDNBatch:
    if not batches:
        raise ValueError("at least one geometry MDN batch is required")
    return GeometryMDNBatch(
        **{
            field.name: torch.cat(
                [getattr(batch, field.name) for batch in batches], dim=0
            )
            for field in fields(GeometryMDNBatch)
        }
    )


def build_value_feature_matrix(
    state_features: torch.Tensor,
    candidate_features: torch.Tensor,
    mdn_features: torch.Tensor,
    inverse_logits: torch.Tensor,
) -> torch.Tensor:
    if state_features.ndim != 2 or state_features.shape[-1] != 128:
        raise ValueError("state features must have shape [batch, 128]")
    if candidate_features.ndim != 3 or candidate_features.shape[-1] != 64:
        raise ValueError("candidate features must have shape [batch, candidates, 64]")
    if inverse_logits.shape != candidate_features.shape[:2]:
        raise ValueError("inverse logits must match candidate axes")
    batch_count, candidate_count = candidate_features.shape[:2]
    if mdn_features.shape == (candidate_count, 7) and batch_count == 1:
        mdn_features = mdn_features.unsqueeze(0)
    if mdn_features.shape != (batch_count, candidate_count, 7):
        raise ValueError("MDN features must match batch and candidate axes")
    state = state_features.unsqueeze(1).expand(-1, candidate_count, -1)
    combined = torch.cat(
        (
            state,
            candidate_features,
            mdn_features,
            inverse_logits.unsqueeze(-1),
        ),
        dim=-1,
    )
    return combined.reshape(batch_count * candidate_count, VALUE_HEAD_INPUT_DIMENSION)


class ActionGeometryValueHead(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.shared = nn.Sequential(
            nn.Linear(VALUE_HEAD_INPUT_DIMENSION, VALUE_HEAD_HIDDEN_WIDTH),
            nn.SiLU(),
            nn.Linear(VALUE_HEAD_HIDDEN_WIDTH, VALUE_HEAD_HIDDEN_WIDTH),
            nn.SiLU(),
        )
        self.terminal_head = nn.Linear(VALUE_HEAD_HIDDEN_WIDTH, 1)
        self.force_head = nn.Linear(VALUE_HEAD_HIDDEN_WIDTH, 1)

    def forward(self, features: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        shared = self.shared(features)
        return self.terminal_head(shared).squeeze(-1), self.force_head(shared).squeeze(-1)


def value_head_loss(
    terminal_logits: torch.Tensor,
    force_prediction: torch.Tensor,
    terminal_labels: torch.Tensor,
    force_targets: torch.Tensor,
) -> dict[str, torch.Tensor]:
    if not (
        terminal_logits.shape
        == force_prediction.shape
        == terminal_labels.shape
        == force_targets.shape
    ):
        raise ValueError("value-head tensors must have identical shapes")
    terminal_bce = functional.binary_cross_entropy_with_logits(
        terminal_logits, terminal_labels
    )
    force_mask = (terminal_labels > 0.5) & torch.isfinite(force_targets)
    if not torch.any(force_mask):
        raise ValueError("force loss requires at least one successful trajectory")
    force_huber = functional.huber_loss(
        force_prediction[force_mask], force_targets[force_mask], delta=1.0
    )
    return {
        "loss": 0.5 * (terminal_bce + force_huber),
        "terminal_bce": terminal_bce,
        "force_huber": force_huber,
    }


def successful_trajectory_indices(terminal_labels: torch.Tensor) -> torch.Tensor:
    return torch.nonzero(terminal_labels > 0.5, as_tuple=False).flatten()


@dataclass(frozen=True, slots=True)
class ZScoreCalibration:
    inverse_mean: float
    inverse_std: float
    terminal_mean: float
    terminal_std: float
    force_mean: float
    force_std: float

    @classmethod
    def fit(
        cls,
        *,
        inverse: np.ndarray,
        terminal: np.ndarray,
        force: np.ndarray,
    ) -> "ZScoreCalibration":
        arrays = tuple(np.asarray(values, dtype=float) for values in (inverse, terminal, force))
        if not arrays[0].size or any(values.shape != arrays[0].shape for values in arrays):
            raise ValueError("calibration arrays must be non-empty with identical shapes")
        if any(not np.isfinite(values).all() for values in arrays):
            raise ValueError("calibration arrays must be finite")
        means = tuple(float(values.mean()) for values in arrays)
        standard_deviations = tuple(float(values.std(ddof=0)) for values in arrays)
        if any(not math.isfinite(value) or value <= 0.0 for value in standard_deviations):
            raise ValueError("calibration standard deviations must be finite and positive")
        return cls(
            inverse_mean=means[0],
            inverse_std=standard_deviations[0],
            terminal_mean=means[1],
            terminal_std=standard_deviations[1],
            force_mean=means[2],
            force_std=standard_deviations[2],
        )

    def standardize(
        self,
        *,
        inverse: np.ndarray,
        terminal: np.ndarray,
        force: np.ndarray,
    ) -> dict[str, np.ndarray]:
        return {
            "inverse": (np.asarray(inverse, dtype=float) - self.inverse_mean)
            / self.inverse_std,
            "terminal": (np.asarray(terminal, dtype=float) - self.terminal_mean)
            / self.terminal_std,
            "force": (np.asarray(force, dtype=float) - self.force_mean) / self.force_std,
        }

    def joint_score(
        self,
        *,
        inverse: np.ndarray,
        terminal: np.ndarray,
        force: np.ndarray,
    ) -> np.ndarray:
        standardized = self.standardize(
            inverse=inverse, terminal=terminal, force=force
        )
        return standardized["inverse"] + standardized["terminal"] - standardized["force"]


def hierarchical_paired_bootstrap(
    stream_values: Sequence[Sequence[float]] | np.ndarray,
    *,
    seed: int,
    replicates: int = 10_000,
) -> dict[str, float]:
    rows = [np.asarray(values, dtype=float) for values in stream_values]
    if not rows or any(values.ndim != 1 or not len(values) for values in rows):
        raise ValueError("each hierarchical stream must contain paired values")
    if any(not np.isfinite(values).all() for values in rows):
        raise ValueError("bootstrap values must be finite")
    point = float(np.concatenate(rows).mean())
    rng = np.random.default_rng(seed)
    estimates = np.empty(replicates, dtype=float)
    for replicate in range(replicates):
        selected_streams = rng.integers(0, len(rows), size=len(rows))
        samples = []
        for stream_index in selected_streams:
            values = rows[int(stream_index)]
            parent_indices = rng.integers(0, len(values), size=len(values))
            samples.append(values[parent_indices])
        estimates[replicate] = np.concatenate(samples).mean()
    return {
        "point": point,
        "ci95_lower": float(np.quantile(estimates, 0.025)),
        "ci95_upper": float(np.quantile(estimates, 0.975)),
    }


def physics_aware_verdict(
    *, terminal_noninferior: bool, physical_improvement: bool, terminal_delta: float
) -> tuple[str, str]:
    if terminal_noninferior and physical_improvement:
        return "SUPPORTED", "RUN_BOUNDED_FIRE_VALIDATION"
    if terminal_noninferior and not physical_improvement and terminal_delta > 0.0:
        return "VALUE_HEAD_TERMINAL_ONLY", "REDESIGN_PHYSICAL_VALUE_LABEL"
    if not terminal_noninferior and physical_improvement:
        return "PHYSICAL_GAIN_WITH_TERMINAL_COST", "REVISIT_SCORE_COMBINATION"
    return "NOT_SUPPORTED", "RETURN_TO_INVERSE_POLICY_BASELINE"


__all__ = [
    "ActionGeometryValueHead",
    "VALUE_HEAD_HIDDEN_WIDTH",
    "VALUE_HEAD_INPUT_DIMENSION",
    "ZScoreCalibration",
    "build_value_feature_matrix",
    "deterministic_stratified_parent_sample",
    "extract_frozen_policy_features",
    "hierarchical_paired_bootstrap",
    "mdn_distribution_features",
    "physics_aware_verdict",
    "stack_geometry_mdn_batches",
    "successful_trajectory_indices",
    "value_head_loss",
]
