from __future__ import annotations

from dataclasses import replace

from crysalis_g1.model.geometry_backends import (
    GeometryBackendConfig,
    GeometryParameterMatch,
    match_periodic_width,
)
from crysalis_g1.model.local_pilot_model import (
    PilotArmSwitches,
    PilotModelConfig,
)


def geometry_candidates() -> GeometryParameterMatch:
    e3nn = GeometryBackendConfig(
        backend="e3nn_lite",
        node_invariant_dim=5,
        relation_invariant_dim=11,
        num_blocks=3,
        radial_basis_count=8,
        cutoff_angstrom=6.0,
        coordinate_step_scale=0.1,
        periodic_hidden_dim=0,
        e3nn_scalar_channels=16,
        e3nn_vector_channels=4,
        e3nn_tensor_channels=2,
        e3nn_l_max=2,
    )
    return match_periodic_width(e3nn, maximum_relative_difference=0.01)


def pilot_model_config(
    *,
    arm_id: str,
    geometry: GeometryBackendConfig,
    relation_library_backend: str = "matched_mlp",
) -> PilotModelConfig:
    switches = PilotArmSwitches.for_arm(arm_id)
    if relation_library_backend not in {"matched_mlp", "student_mlp"}:
        raise ValueError("unsupported relation-library backend")
    return PilotModelConfig(
        schema_version="g1-local-pilot-model.1.0.0",
        arm_id=arm_id,
        use_relation_memory=switches.use_relation_memory,
        use_relation_library=switches.use_relation_library,
        use_stepwise_physics=switches.use_stepwise_physics,
        geometry=geometry,
        hidden_dim=64,
        orbit_attention_blocks=2,
        orbit_attention_heads=4,
        relation_prior_dim=16,
        relation_memory_dim=32,
        physics_feedback_dim=12,
        projector_min_distance=0.5,
        physics_update_mode="feedback_only",
        relation_library_backend=relation_library_backend,  # type: ignore[arg-type]
    )


def select_geometry(
    backend: str, match: GeometryParameterMatch | None = None
) -> GeometryBackendConfig:
    match = geometry_candidates() if match is None else match
    if backend == "periodic_egnn":
        return match.periodic_config
    if backend == "e3nn_lite":
        return replace(match.e3nn_config)
    raise ValueError(f"unsupported geometry backend: {backend}")
