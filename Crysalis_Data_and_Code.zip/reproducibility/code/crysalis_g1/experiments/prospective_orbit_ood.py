from __future__ import annotations

import hashlib
import json
from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Hashable, Iterable, Mapping, Sequence


@dataclass(frozen=True)
class FamilySelection:
    selected_family_keys: tuple[Hashable, ...]
    parent_ids: tuple[str, ...]
    eligible_family_keys: tuple[Hashable, ...]


@dataclass(frozen=True)
class JointHoldout:
    selected_family_keys: dict[str, tuple[Hashable, ...]]
    benchmark_parent_ids: dict[str, tuple[str, ...]]
    test_parent_ids: tuple[str, ...]


@dataclass(frozen=True)
class TrainValidationSplit:
    train_parent_ids: tuple[str, ...]
    validation_parent_ids: tuple[str, ...]


@dataclass(frozen=True)
class PurityReport:
    status: str
    signature_leakage_n: dict[str, int]
    unseen_primitive_n: dict[str, int]
    minimum_primitive_training_count: dict[str, int]


@dataclass(frozen=True)
class ProspectiveVerdict:
    status: str
    benchmark_supported: dict[str, bool]
    nc_core_claim_candidate: str
    next_action: str


def valid_observed_graph_parent(
    *,
    parent_orbit_ids: set[str],
    graph_rows: Sequence[Mapping[str, object]],
    expected_split: str,
) -> bool:
    if not graph_rows:
        return False
    initial_n = 0
    seen_states: set[tuple[str, ...]] = set()
    for row in graph_rows:
        active = {str(value) for value in row["active_orbit_ids"]}
        positive = {str(value) for value in row["positive_orbit_ids"]}
        state_key = tuple(sorted(active))
        legal = {tuple(value) for value in row["legal_action_keys"]}
        positive_actions = {tuple(value) for value in row["positive_action_keys"]}
        if state_key in seen_states:
            return False
        seen_states.add(state_key)
        initial_n += int(not active)
        if (
            str(row["split"]) != expected_split
            or not active <= parent_orbit_ids
            or not positive
            or not positive <= parent_orbit_ids - active
            or not positive_actions <= legal
        ):
            return False
    return initial_n == 1


def count_bin(value: int, *, ceiling: int = 5) -> str:
    number = int(value)
    if number < 0:
        raise ValueError("count bin requires a nonnegative value")
    return str(number) if number < ceiling else f"{ceiling}+"


def multiplicity_signature(multiplicities: Iterable[int]) -> tuple[int, ...]:
    values = tuple(sorted(int(value) for value in multiplicities))
    if not values or any(value <= 0 for value in values):
        raise ValueError("multiplicity signature requires positive multiplicities")
    return values


def wyckoff_signature(
    orbits: Iterable[Mapping[str, object]],
) -> tuple[tuple[int, int, str], ...]:
    values = tuple(
        sorted(
            (
                int(orbit["target_space_group"]),
                int(orbit["hall_number"]),
                str(orbit["wyckoff_position_id"]),
            )
            for orbit in orbits
        )
    )
    if not values:
        raise ValueError("Wyckoff signature requires at least one orbit")
    return values


def transition_profile_signature(
    canonical_orbit_sequence: Sequence[tuple[int, int]],
) -> tuple[tuple[tuple[str, int, int, str], int], ...]:
    total = len(canonical_orbit_sequence)
    if total == 0:
        raise ValueError("transition profile requires a nonempty canonical path")
    motifs: Counter[tuple[str, int, int, str]] = Counter()
    for active_count, (multiplicity, free_dof) in enumerate(canonical_orbit_sequence):
        motifs[
            (
                count_bin(total - active_count),
                int(multiplicity),
                int(free_dof),
                count_bin(active_count),
            )
        ] += 1
    return tuple(sorted(motifs.items()))


def signature_canonical_string(signature: object) -> str:
    return json.dumps(signature, separators=(",", ":"), ensure_ascii=True)


def _hash(seed: int, purpose: str, value: object) -> str:
    return hashlib.sha256(f"{seed}:{purpose}:{value}".encode("utf-8")).hexdigest()


def _stratified_order(
    parent_ids: Sequence[str],
    *,
    stratum_by_parent: Mapping[str, Hashable],
    seed: int,
    purpose: str,
) -> tuple[str, ...]:
    groups: dict[Hashable, list[str]] = defaultdict(list)
    for parent_id in parent_ids:
        groups[stratum_by_parent[parent_id]].append(parent_id)
    ranked: list[tuple[float, str, str]] = []
    for stratum, members in groups.items():
        ordered = sorted(
            members, key=lambda parent_id: (_hash(seed, purpose, parent_id), parent_id)
        )
        for rank, parent_id in enumerate(ordered):
            ranked.append(
                (
                    (rank + 0.5) / len(ordered),
                    _hash(seed, f"{purpose}:tie", (repr(stratum), parent_id)),
                    parent_id,
                )
            )
    return tuple(item[2] for item in sorted(ranked))


def _distribution_distance(
    selected: set[str],
    all_parent_ids: Sequence[str],
    stratum_by_parent: Mapping[str, tuple[object, ...]],
) -> float:
    if not selected:
        return 3.0
    total = len(all_parent_ids)
    distance = 0.0
    for axis in range(3):
        population = Counter(stratum_by_parent[parent_id][axis] for parent_id in all_parent_ids)
        sample = Counter(stratum_by_parent[parent_id][axis] for parent_id in selected)
        for value in population.keys() | sample.keys():
            distance += abs(sample[value] / len(selected) - population[value] / total)
    return distance


def select_holdout_families(
    *,
    signature_by_parent: Mapping[str, Hashable],
    primitive_components_by_parent: Mapping[str, set[Hashable]],
    stratum_by_parent: Mapping[str, tuple[object, ...]],
    target_n: int,
    minimum_test_n: int,
    maximum_test_n: int,
    minimum_family_n: int,
    maximum_family_n: int,
) -> FamilySelection:
    parent_ids = tuple(sorted(signature_by_parent))
    if set(parent_ids) != set(primitive_components_by_parent) or set(parent_ids) != set(
        stratum_by_parent
    ):
        raise ValueError("signature, primitive, and stratum parent sets must match")
    families: dict[Hashable, list[str]] = defaultdict(list)
    for parent_id, signature in signature_by_parent.items():
        families[signature].append(parent_id)

    eligible: list[Hashable] = []
    all_parents = set(parent_ids)
    for signature in sorted(families, key=signature_canonical_string):
        members = set(families[signature])
        if not minimum_family_n <= len(members) <= maximum_family_n:
            continue
        components = set().union(
            *(primitive_components_by_parent[parent_id] for parent_id in members)
        )
        outside = all_parents - members
        if all(
            any(
                component in primitive_components_by_parent[parent_id]
                for parent_id in outside
            )
            for component in components
        ):
            eligible.append(signature)

    selected_keys: list[Hashable] = []
    selected_parents: set[str] = set()
    remaining = list(eligible)
    while len(selected_parents) < target_n:
        candidates = []
        for signature in remaining:
            proposed = selected_parents | set(families[signature])
            if len(proposed) > maximum_test_n:
                continue
            score = (
                abs(len(proposed) - target_n) / max(target_n, 1)
                + _distribution_distance(proposed, parent_ids, stratum_by_parent),
                signature_canonical_string(signature),
            )
            candidates.append((score, signature, proposed))
        if not candidates:
            break
        _, chosen, proposed = min(candidates, key=lambda item: item[0])
        selected_keys.append(chosen)
        selected_parents = proposed
        remaining.remove(chosen)
    if not minimum_test_n <= len(selected_parents) <= maximum_test_n:
        raise ValueError(
            f"eligible families yield {len(selected_parents)} held-out parents, "
            f"outside [{minimum_test_n}, {maximum_test_n}]"
        )
    return FamilySelection(
        selected_family_keys=tuple(selected_keys),
        parent_ids=tuple(sorted(selected_parents)),
        eligible_family_keys=tuple(eligible),
    )


def joint_holdout_design(
    selections: Mapping[str, FamilySelection],
    *,
    family_members_by_benchmark: Mapping[
        str, Mapping[Hashable, Sequence[str]]
    ],
    maximum_union_n: int,
    minimum_benchmark_n: int,
) -> JointHoldout:
    if set(selections) != {"A", "B", "C"}:
        raise ValueError("joint holdout requires A, B, and C selections")
    initial_union = set().union(
        *(set(selection.parent_ids) for selection in selections.values())
    )
    if len(initial_union) <= maximum_union_n:
        selected_keys = {
            name: tuple(selection.selected_family_keys)
            for name, selection in selections.items()
        }
    else:
        selected_keys = {name: [] for name in ("A", "B", "C")}
        accepted_union: set[str] = set()
        for name in ("A", "B", "C"):
            for family in sorted(
                selections[name].selected_family_keys,
                key=signature_canonical_string,
            ):
                members = set(family_members_by_benchmark[name][family])
                if len(accepted_union | members) <= maximum_union_n:
                    selected_keys[name].append(family)
                    accepted_union.update(members)
        selected_keys = {
            name: tuple(values) for name, values in selected_keys.items()
        }

    benchmark_parent_ids = {
        name: tuple(
            sorted(
                set().union(
                    *(
                        set(family_members_by_benchmark[name][family])
                        for family in selected_keys[name]
                    )
                )
                if selected_keys[name]
                else set()
            )
        )
        for name in ("A", "B", "C")
    }
    if any(
        len(parent_ids) < minimum_benchmark_n
        for parent_ids in benchmark_parent_ids.values()
    ):
        raise ValueError("joint trimming leaves a benchmark below its minimum")
    test_parent_ids = tuple(
        sorted(set().union(*(set(values) for values in benchmark_parent_ids.values())))
    )
    if len(test_parent_ids) > maximum_union_n:
        raise RuntimeError("joint holdout union exceeds its maximum")
    return JointHoldout(
        selected_family_keys=dict(selected_keys),
        benchmark_parent_ids=benchmark_parent_ids,
        test_parent_ids=test_parent_ids,
    )


def select_feasible_joint_holdout(
    *,
    signature_by_benchmark: Mapping[str, Mapping[str, Hashable]],
    primitive_components_by_benchmark: Mapping[
        str, Mapping[str, set[Hashable]]
    ],
    stratum_by_parent: Mapping[str, tuple[object, ...]],
    target_candidates: Sequence[int],
    minimum_test_n: int,
    maximum_test_n: int,
    minimum_family_n: int,
    maximum_family_n: int,
    minimum_union_n: int,
    maximum_union_n: int,
) -> tuple[
    int,
    dict[str, FamilySelection],
    JointHoldout,
    dict[str, dict[Hashable, tuple[str, ...]]],
]:
    if set(signature_by_benchmark) != {"A", "B", "C"} or set(
        primitive_components_by_benchmark
    ) != {"A", "B", "C"}:
        raise ValueError("feasible joint holdout requires A, B, and C signatures")
    family_members: dict[str, dict[Hashable, tuple[str, ...]]] = {}
    for name in ("A", "B", "C"):
        grouped: dict[Hashable, list[str]] = defaultdict(list)
        for parent_id, signature in signature_by_benchmark[name].items():
            grouped[signature].append(parent_id)
        family_members[name] = {
            signature: tuple(sorted(parent_ids))
            for signature, parent_ids in grouped.items()
        }
    for target_n in target_candidates:
        try:
            selections = {
                name: select_holdout_families(
                    signature_by_parent=signature_by_benchmark[name],
                    primitive_components_by_parent=primitive_components_by_benchmark[
                        name
                    ],
                    stratum_by_parent=stratum_by_parent,
                    target_n=int(target_n),
                    minimum_test_n=minimum_test_n,
                    maximum_test_n=maximum_test_n,
                    minimum_family_n=minimum_family_n,
                    maximum_family_n=maximum_family_n,
                )
                for name in ("A", "B", "C")
            }
            joint = joint_holdout_design(
                selections,
                family_members_by_benchmark=family_members,
                maximum_union_n=maximum_union_n,
                minimum_benchmark_n=minimum_test_n,
            )
        except ValueError:
            continue
        if (
            minimum_union_n <= len(joint.test_parent_ids) <= maximum_union_n
            and all(
                minimum_test_n
                <= len(joint.benchmark_parent_ids[name])
                <= maximum_test_n
                for name in ("A", "B", "C")
            )
        ):
            return int(target_n), selections, joint, family_members
    raise ValueError("no registered target candidate yields a feasible joint holdout")


def select_train_validation(
    parent_ids: Sequence[str],
    *,
    train_n: int,
    validation_n: int,
    required_components: set[Hashable],
    coverage_by_parent: Mapping[str, set[Hashable]],
    stratum_by_parent: Mapping[str, Hashable],
    seed: int,
) -> TrainValidationSplit:
    unique = tuple(dict.fromkeys(parent_ids))
    if len(unique) != len(parent_ids):
        raise ValueError("prospective train-pool parent IDs must be unique")
    if train_n + validation_n > len(unique):
        raise ValueError("train and validation counts exceed the parent pool")
    uncovered = set(required_components)
    train: set[str] = set()
    while uncovered:
        candidates = [
            parent_id
            for parent_id in unique
            if parent_id not in train and coverage_by_parent[parent_id] & uncovered
        ]
        if not candidates:
            raise ValueError(f"required primitive coverage is unavailable: {uncovered}")
        chosen = min(
            candidates,
            key=lambda parent_id: (
                -len(coverage_by_parent[parent_id] & uncovered),
                _hash(seed, "coverage", parent_id),
                parent_id,
            ),
        )
        train.add(chosen)
        uncovered -= coverage_by_parent[chosen]
    if len(train) > train_n:
        raise ValueError("primitive coverage requires more parents than train_n")

    fill_order = _stratified_order(
        [parent_id for parent_id in unique if parent_id not in train],
        stratum_by_parent=stratum_by_parent,
        seed=seed,
        purpose="prospective-train",
    )
    train.update(fill_order[: train_n - len(train)])
    remaining = [parent_id for parent_id in unique if parent_id not in train]
    validation_order = _stratified_order(
        remaining,
        stratum_by_parent=stratum_by_parent,
        seed=seed,
        purpose="prospective-validation",
    )
    validation = tuple(validation_order[:validation_n])
    return TrainValidationSplit(
        train_parent_ids=tuple(sorted(train)),
        validation_parent_ids=tuple(sorted(validation)),
    )


def combinatorial_purity(
    *,
    train_parent_ids: Sequence[str],
    benchmark_test_parent_ids: Mapping[str, Sequence[str]],
    signature_by_benchmark: Mapping[str, Mapping[str, Hashable]],
    primitive_components_by_benchmark: Mapping[
        str, Mapping[str, set[Hashable]]
    ],
) -> PurityReport:
    train = set(train_parent_ids)
    leakage: dict[str, int] = {}
    unseen: dict[str, int] = {}
    minimum_counts: dict[str, int] = {}
    for name in ("A", "B", "C"):
        train_signatures = Counter(
            signature_by_benchmark[name][parent_id] for parent_id in train
        )
        test_signatures = {
            signature_by_benchmark[name][parent_id]
            for parent_id in benchmark_test_parent_ids[name]
        }
        leakage[name] = sum(train_signatures[signature] > 0 for signature in test_signatures)
        train_component_counts: Counter[Hashable] = Counter()
        for parent_id in train:
            train_component_counts.update(
                primitive_components_by_benchmark[name][parent_id]
            )
        required = set().union(
            *(
                primitive_components_by_benchmark[name][parent_id]
                for parent_id in benchmark_test_parent_ids[name]
            )
        )
        unseen[name] = sum(train_component_counts[component] == 0 for component in required)
        minimum_counts[name] = min(
            (train_component_counts[component] for component in required),
            default=0,
        )
    status = "PASS" if not any(leakage.values()) and not any(unseen.values()) else "FAIL"
    return PurityReport(
        status=status,
        signature_leakage_n=leakage,
        unseen_primitive_n=unseen,
        minimum_primitive_training_count=minimum_counts,
    )


def prospective_verdict(
    effects: Mapping[str, Mapping[str, float]],
) -> ProspectiveVerdict:
    if set(effects) != {"A", "B", "C"}:
        raise ValueError("prospective effects must contain A, B, and C")
    supported = {
        name: value["delta_pp"] > 0 and value["ci_lower_pp"] > 0
        for name, value in effects.items()
    }
    supported_n = sum(supported.values())
    significant_reverse = any(value["ci_upper_pp"] < 0 for value in effects.values())
    if supported_n >= 2 and not significant_reverse:
        status = "SUPPORTED"
        claim = "CRYSTALLOGRAPHIC_ASSEMBLY_GRAMMAR"
        next_action = "MODEL_AGNOSTIC_REPLICATION"
    elif supported_n == 0:
        status = "NOT_SUPPORTED"
        claim = "REJECT_DECONSTRUCTION_SUPERVISION_AS_NC_CORE"
        next_action = "PIVOT_NC_CORE_CLAIM"
    else:
        status = "WEAK_OR_SPECIFIC"
        claim = "TOO_NARROW_FOR_PRIMARY_NC_CLAIM"
        next_action = "PIVOT_NC_CORE_CLAIM"
    return ProspectiveVerdict(
        status=status,
        benchmark_supported=supported,
        nc_core_claim_candidate=claim,
        next_action=next_action,
    )


def classify_primary_mechanism(
    *,
    dead_end_reduction_count: int,
    later_onset_net_count: int,
    unseen_motif_completion_net_wins: int,
    positive_set_mass_delta: float,
    completed_steps_delta: float,
) -> str:
    if dead_end_reduction_count > 0:
        return "DEAD_END_REDUCTION"
    if later_onset_net_count > 0:
        return "LATER_DEAD_END_ONSET"
    if unseen_motif_completion_net_wins > 0:
        return "UNSEEN_MOTIF_COMPLETION"
    if positive_set_mass_delta > 0:
        return "HIGHER_POSITIVE_SET_MASS"
    if completed_steps_delta > 0:
        return "MORE_COMPLETED_STEPS"
    return "OTHER"
