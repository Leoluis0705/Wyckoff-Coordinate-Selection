from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import statistics
import time
from collections.abc import Iterable, Mapping, Sequence
from pathlib import Path
from typing import Any

import numpy as np
import torch
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer

from crysalis_g1.experiments.local_pilot_training import derive_named_seed


SYMPRECS = (0.01, 0.03, 0.05, 0.10)
ALLOWED_FINAL_DECISIONS = frozenset(
    {
        "PIPELINE_OR_EVALUATOR_FAILURE",
        "CURRENT_MODEL_ARCHITECTURE_FAILURE",
        "CURRENT_METHOD_FORMULATION_NOT_SUPPORTED",
        "VIABLE_SIGNAL_REMAINS",
    }
)


def _symprec_key(value: float) -> str:
    return f"{value:.2f}"


def structure_from_payload(payload: Mapping[str, Any]) -> Structure:
    return Structure(
        Lattice(np.asarray(payload["lattice"], dtype=float)),
        [int(value) for value in payload["atomic_numbers"]],
        np.asarray(payload["fractional_coordinates"], dtype=float),
        to_unit_cell=True,
    )


def structure_payload(structure: Structure) -> dict[str, Any]:
    return {
        "atomic_numbers": [int(site.specie.Z) for site in structure],
        "fractional_coordinates": np.asarray(structure.frac_coords, dtype=float).tolist(),
        "lattice": np.asarray(structure.lattice.matrix, dtype=float).tolist(),
    }


def select_generated_records(
    records: Iterable[Mapping[str, Any]], *, count: int
) -> list[dict[str, Any]]:
    if count <= 0:
        raise ValueError("generated diagnostic sample count must be positive")
    legal = sorted(
        (dict(record) for record in records if bool(record.get("legal_terminal_crystal"))),
        key=lambda record: int(record["condition"]["attempt_index"]),
    )
    selected = legal[:count]
    if len(selected) != count:
        raise ValueError(f"needed {count} legal terminal candidates, found {len(selected)}")
    identifiers = [str(record["condition"]["condition_id"]) for record in selected]
    if len(set(identifiers)) != count:
        raise ValueError("generated diagnostic sample IDs must be unique")
    return selected


def select_control_parents(
    parents: Iterable[Mapping[str, Any]], *, count: int
) -> list[dict[str, Any]]:
    if count <= 0:
        raise ValueError("control sample count must be positive")
    eligible: list[dict[str, Any]] = []
    for source in parents:
        parent = dict(source)
        atomic_numbers = [int(value) for value in parent.get("atomic_numbers", [])]
        if (
            str(parent.get("material_id")) == "mp-1173150"
            or parent.get("source_partition") != "train_fit"
            or parent.get("symmetry_status") != "stable"
            or not atomic_numbers
            or max(atomic_numbers) > 94
            or min(atomic_numbers) < 1
        ):
            continue
        eligible.append(parent)
    eligible.sort(key=lambda parent: str(parent["material_id"]))
    selected = eligible[:count]
    if len(selected) != count:
        raise ValueError(f"needed {count} control parents, found {len(selected)}")
    identifiers = [str(parent["material_id"]) for parent in selected]
    if len(set(identifiers)) != count:
        raise ValueError("control material IDs must be unique")
    return selected


def perturb_control_parent(parent: Mapping[str, Any], *, root_seed: int) -> dict[str, Any]:
    material_id = str(parent["material_id"])
    stream_name = f"final-diagnostic-v1:perturb:{material_id}"
    seed = derive_named_seed(root_seed, stream_name)
    rng = np.random.default_rng(seed)
    lattice = np.asarray(parent["lattice"], dtype=float)
    fractional = np.asarray(parent["fractional_coordinates"], dtype=float)
    displacement = rng.normal(0.0, 0.02, size=fractional.shape)
    norms = np.linalg.norm(displacement, axis=1)
    scale = np.minimum(1.0, 0.05 / np.maximum(norms, 1e-30))
    displacement *= scale[:, None]
    perturbed_fractional = np.remainder(fractional + displacement @ np.linalg.inv(lattice), 1.0)
    return {
        "sample_id": f"{material_id}::mild-perturbation",
        "source_material_id": material_id,
        "sample_group": "PERTURBED_MP_CONTROL",
        "atomic_numbers": [int(value) for value in parent["atomic_numbers"]],
        "fractional_coordinates": perturbed_fractional.tolist(),
        "lattice": lattice.tolist(),
        "target_space_group": int(parent["space_group"]),
        "perturbation": {
            "stream_name": stream_name,
            "stream_seed": seed,
            "cartesian_sigma_angstrom": 0.02,
            "cartesian_norm_cap_angstrom": 0.05,
            "maximum_realized_displacement_angstrom": float(
                np.linalg.norm(displacement, axis=1).max(initial=0.0)
            ),
        },
    }


def _dataset_value(dataset: Any, name: str) -> Any:
    if hasattr(dataset, name):
        return getattr(dataset, name)
    return dataset[name]


def _orbit_memberships(equivalent_atoms: Sequence[int]) -> list[list[int]]:
    grouped: dict[int, list[int]] = {}
    for site_index, orbit_label in enumerate(equivalent_atoms):
        grouped.setdefault(int(orbit_label), []).append(site_index)
    return list(grouped.values())


def _equivalent_site_residual(
    structure: Structure, analyzer: SpacegroupAnalyzer
) -> dict[str, float]:
    distances: list[float] = []
    fractional = np.asarray(structure.frac_coords, dtype=float)
    atomic_numbers = np.asarray([int(site.specie.Z) for site in structure])
    lattice = np.asarray(structure.lattice.matrix, dtype=float)
    for operation in analyzer.get_symmetry_operations(cartesian=False):
        transformed = operation.operate_multi(fractional)
        for site_index, coordinate in enumerate(transformed):
            same_species = np.flatnonzero(atomic_numbers == atomic_numbers[site_index])
            delta = fractional[same_species] - coordinate
            delta -= np.round(delta)
            cartesian = delta @ lattice
            distances.append(float(np.linalg.norm(cartesian, axis=1).min()))
    array = np.asarray(distances, dtype=float)
    return {
        "maximum_angstrom": float(array.max(initial=0.0)),
        "rms_angstrom": float(np.sqrt(np.mean(array * array))) if len(array) else 0.0,
    }


def analyse_symmetry_stage(
    stage: str,
    structure: Structure,
    *,
    target_space_group: int,
    symprecs: Sequence[float] = SYMPRECS,
) -> dict[str, Any]:
    by_symprec: dict[str, Any] = {}
    atomic_numbers = [int(site.specie.Z) for site in structure]
    for symprec in symprecs:
        key = _symprec_key(float(symprec))
        try:
            analyzer = SpacegroupAnalyzer(structure, symprec=float(symprec))
            dataset = analyzer.get_symmetry_dataset()
            equivalent = [int(value) for value in _dataset_value(dataset, "equivalent_atoms")]
            wyckoffs = [str(value) for value in _dataset_value(dataset, "wyckoffs")]
            memberships = _orbit_memberships(equivalent)
            by_symprec[key] = {
                "detected_space_group": int(_dataset_value(dataset, "number")),
                "international_symbol": str(_dataset_value(dataset, "international")),
                "orbit_memberships": memberships,
                "wyckoff_membership": [
                    {
                        "site_indices": membership,
                        "wyckoff_letters": sorted({wyckoffs[index] for index in membership}),
                        "atomic_numbers": sorted({atomic_numbers[index] for index in membership}),
                    }
                    for membership in memberships
                ],
                "multiplicities": [len(membership) for membership in memberships],
                "equivalent_site_residual": _equivalent_site_residual(structure, analyzer),
                "target_match": int(_dataset_value(dataset, "number")) == int(target_space_group),
            }
        except Exception as error:
            by_symprec[key] = {
                "detected_space_group": 0,
                "international_symbol": None,
                "orbit_memberships": [],
                "wyckoff_membership": [],
                "multiplicities": [],
                "equivalent_site_residual": None,
                "target_match": False,
                "exception_type": type(error).__name__,
                "exception_message": str(error),
            }
    composition = {
        element: float(amount)
        for element, amount in structure.composition.get_el_amt_dict().items()
    }
    return {
        "stage": stage,
        "target_space_group": int(target_space_group),
        "site_count": len(structure),
        "composition": composition,
        "by_symprec": by_symprec,
    }


def cif_export_reload(structure: Structure) -> tuple[Structure, dict[str, Any]]:
    cif_text = str(CifWriter(structure, symprec=None, significant_figures=12))
    reloaded = Structure.from_str(cif_text, fmt="cif")
    before: dict[str, int] = {}
    after: dict[str, int] = {}
    for symprec in SYMPRECS:
        key = _symprec_key(symprec)
        before[key] = int(SpacegroupAnalyzer(structure, symprec=symprec).get_space_group_number())
        after[key] = int(SpacegroupAnalyzer(reloaded, symprec=symprec).get_space_group_number())
    evidence = {
        "format": "CIF",
        "significant_figures": 12,
        "site_count_before": len(structure),
        "site_count_after": len(reloaded),
        "site_count_preserved": len(structure) == len(reloaded),
        "composition_before": structure.composition.as_dict(),
        "composition_after": reloaded.composition.as_dict(),
        "composition_preserved": structure.composition == reloaded.composition,
        "detected_space_group_before_by_symprec": before,
        "detected_space_group_after_by_symprec": after,
        "detected_space_group_preserved_by_symprec": {
            key: before[key] == after[key] for key in before
        },
        "serialized_utf8_bytes": len(cif_text.encode("utf-8")),
    }
    return reloaded, evidence


def _minimum_distance(structure: Structure) -> float | None:
    if len(structure) < 2:
        return None
    distances = np.asarray(structure.distance_matrix, dtype=float)
    np.fill_diagonal(distances, np.inf)
    return float(distances.min())


def classify_collapse(structure: Structure) -> dict[str, Any]:
    reasons: list[str] = []
    fractional = np.asarray(structure.frac_coords, dtype=float)
    lattice = np.asarray(structure.lattice.matrix, dtype=float)
    volume = float(structure.lattice.volume)
    if not np.isfinite(fractional).all() or not np.isfinite(lattice).all():
        reasons.append("NONFINITE_STATE")
    if not math.isfinite(volume) or volume <= 0:
        reasons.append("NONPOSITIVE_VOLUME")
    volume_per_atom = volume / max(len(structure), 1)
    if math.isfinite(volume_per_atom) and not 1.0 <= volume_per_atom <= 200.0:
        reasons.append("VOLUME_PER_ATOM_OUTSIDE_1_TO_200_ANGSTROM3")
    minimum_distance = _minimum_distance(structure)
    if minimum_distance is not None and minimum_distance < 0.5:
        reasons.append("MINIMUM_DISTANCE_BELOW_0.5_ANGSTROM")
    return {
        "collapsed": bool(reasons),
        "reason_codes": reasons,
        "volume_angstrom3": volume,
        "volume_per_atom_angstrom3": volume_per_atom,
        "minimum_distance_angstrom": minimum_distance,
    }


def _rmsd(initial: Structure, current: Structure) -> float:
    if len(initial) != len(current) or not len(initial):
        return math.nan
    delta = np.asarray(current.frac_coords) - np.asarray(initial.frac_coords)
    delta -= np.round(delta)
    cartesian = delta @ np.asarray(current.lattice.matrix)
    return float(np.sqrt(np.mean(np.sum(cartesian * cartesian, axis=1))))


def _same_observation(trajectory: Any, first: int, second: int) -> bool:
    return bool(
        np.allclose(trajectory.forces[first], trajectory.forces[second], atol=0, rtol=0)
        and np.allclose(
            trajectory.atom_positions[first],
            trajectory.atom_positions[second],
            atol=0,
            rtol=0,
        )
        and np.allclose(trajectory.cells[first], trajectory.cells[second], atol=0, rtol=0)
        and float(trajectory.energies[first]) == float(trajectory.energies[second])
    )


def extract_relaxation_checkpoints(
    initial: Structure,
    trajectory: Any,
    *,
    maximum_steps: int,
    relax_cell: bool,
    force_threshold: float,
    requested_steps: Sequence[int] = (0, 20, 100, 300),
) -> dict[str, dict[str, Any]]:
    observation_count = len(trajectory.forces)
    if not observation_count:
        raise ValueError("relaxation trajectory has no observations")
    effective_count = observation_count
    if observation_count >= 2 and _same_observation(
        trajectory, observation_count - 2, observation_count - 1
    ):
        effective_count -= 1
    final_step = effective_count - 1
    initial_lattice = np.asarray(initial.lattice.matrix, dtype=float)
    checkpoints: dict[str, dict[str, Any]] = {}
    for requested_step in requested_steps:
        key = str(int(requested_step))
        if requested_step > maximum_steps:
            checkpoints[key] = {
                "observation_status": f"NOT_APPLICABLE_MAX_STEPS_{maximum_steps}",
                "source_step": None,
            }
            continue
        source_step = min(int(requested_step), final_step)
        forces = np.asarray(trajectory.forces[source_step], dtype=float)
        maximum_force = float(np.linalg.norm(forces, axis=-1).max(initial=0.0))
        current = Structure(
            Lattice(np.asarray(trajectory.cells[source_step], dtype=float)),
            [site.specie for site in initial],
            np.asarray(trajectory.atom_positions[source_step], dtype=float),
            coords_are_cartesian=True,
            to_unit_cell=True,
        )
        current_lattice = np.asarray(current.lattice.matrix, dtype=float)
        collapse = classify_collapse(current)
        try:
            detected_space_group = int(
                SpacegroupAnalyzer(current, symprec=0.03).get_space_group_number()
            )
        except Exception:
            detected_space_group = 0
        if requested_step <= final_step:
            status = "EXACT_STEP"
        elif maximum_force <= force_threshold:
            status = "EARLY_CONVERGED_FINAL"
        else:
            status = "EARLY_TERMINATED_FINAL"
        checkpoints[key] = {
            "observation_status": status,
            "source_step": source_step,
            "maximum_force_ev_per_angstrom": maximum_force,
            "energy_ev": float(trajectory.energies[source_step]),
            "energy_ev_per_atom": float(trajectory.energies[source_step]) / len(current),
            "rmsd_angstrom": _rmsd(initial, current),
            "lattice_relative_change": float(
                np.linalg.norm(current_lattice - initial_lattice)
                / max(np.linalg.norm(initial_lattice), 1e-12)
            ),
            "converged": maximum_force <= force_threshold,
            "collapse": collapse,
            "detected_space_group_symprec_0.03": detected_space_group,
            "relax_cell": bool(relax_cell),
            "structure": structure_payload(current),
        }
    return checkpoints


def choose_final_decision(evidence: Mapping[str, Any]) -> str:
    clean_count = int(evidence["clean_control_count"])
    clean_failure_count = int(evidence["clean_control_all_protocol_failure_count"])
    if bool(evidence["pipeline_failure_confirmed"]) or (
        clean_count > 0 and clean_failure_count / clean_count >= 0.20
    ):
        return "PIPELINE_OR_EVALUATOR_FAILURE"
    candidate_count = int(evidence["candidate_count"])
    early_failure_count = int(evidence["candidate_s1_s2_first_failure_count"])
    if candidate_count > 0 and (
        early_failure_count / candidate_count >= 0.80
        or bool(evidence["generated_materially_worse_than_controls"])
    ):
        return "CURRENT_MODEL_ARCHITECTURE_FAILURE"
    if (
        int(evidence["s4_target_match_count"]) >= 10
        and int(evidence["generated_converged_noncollapsed_300_count"]) >= 5
    ):
        return "VIABLE_SIGNAL_REMAINS"
    if bool(evidence["architecture_contracts_satisfied"]):
        return "CURRENT_METHOD_FORMULATION_NOT_SUPPORTED"
    return "CURRENT_MODEL_ARCHITECTURE_FAILURE"


def _canonical_json(payload: object, *, indent: int | None = None) -> str:
    return json.dumps(
        payload,
        ensure_ascii=False,
        allow_nan=False,
        indent=indent,
        separators=(",", ":") if indent is None else None,
        sort_keys=True,
    )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _payload_sha256(payload: object) -> str:
    return hashlib.sha256(_canonical_json(payload).encode("utf-8")).hexdigest()


def _write_json_new(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(_canonical_json(payload, indent=2) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def _append_jsonl(path: Path, payload: object) -> None:
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(_canonical_json(payload) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as source:
        for line_number, line in enumerate(source, 1):
            if line.strip():
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError as error:
                    raise ValueError(f"invalid JSONL at {path}:{line_number}") from error
    return records


def _verify_file(specification: Mapping[str, Any], *, label: str) -> Path:
    path = Path(str(specification["path"])).resolve()
    if not path.is_file():
        raise FileNotFoundError(f"{label} is missing: {path}")
    observed = _sha256(path)
    expected = str(specification["sha256"]).lower()
    if observed != expected:
        raise RuntimeError(f"{label} SHA-256 mismatch: expected {expected}, observed {observed}")
    return path


def _validate_config(config: Mapping[str, Any]) -> None:
    expected_flags = {
        "no_model_retraining": True,
        "use_frozen_checkpoints": True,
        "server_use": False,
        "three_seed_authorized": False,
        "no_refill": True,
    }
    if config.get("diagnostic_id") != "FINAL_DIAGNOSTIC_V1":
        raise ValueError("diagnostic ID must remain FINAL_DIAGNOSTIC_V1")
    for name, expected in expected_flags.items():
        if config.get(name) is not expected:
            raise ValueError(f"{name} must remain {expected}")
    if int(config["root_seed"]) != 20260823:
        raise ValueError("root seed must remain 20260823")
    if int(config["candidate_count_per_arm"]) != 50:
        raise ValueError("candidate count must remain 50 per arm")
    if int(config["control_count"]) != 20:
        raise ValueError("control count must remain 20")
    if config["device"] not in {"cpu", "cuda"}:
        raise ValueError("diagnostic device must be cpu or cuda")
    expected_protocols = {
        ("A_FIXED_CELL_FIRE_100", 100, False),
        ("B_FIXED_CELL_FIRE_300", 300, False),
        ("C_CELL_RELAX_FIRE_300", 300, True),
    }
    observed_protocols = {
        (
            str(protocol["protocol_id"]),
            int(protocol["maximum_steps"]),
            bool(protocol["relax_cell"]),
        )
        for protocol in config["chgnet"]["protocols"]
    }
    if observed_protocols != expected_protocols:
        raise ValueError("CHGNet protocol matrix must remain A100/B300/C300")
    if float(config["chgnet"]["force_threshold_ev_per_angstrom"]) != 0.2:
        raise ValueError("CHGNet force threshold must remain 0.2 eV/angstrom")


def _load_config(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    _validate_config(payload)
    return payload


def _prepare_inputs(config: Mapping[str, Any]) -> dict[str, Any]:
    rollout_records: dict[str, list[dict[str, Any]]] = {}
    selected_candidates: dict[str, list[dict[str, Any]]] = {}
    paths: dict[str, str] = {}
    for arm_id in ("C0", "C1"):
        rollout_path = _verify_file(config["candidate_rollouts"][arm_id], label=f"{arm_id} rollout")
        paths[f"{arm_id}_rollout"] = str(rollout_path)
        rollout_records[arm_id] = _read_jsonl(rollout_path)
        selected_candidates[arm_id] = select_generated_records(
            rollout_records[arm_id], count=int(config["candidate_count_per_arm"])
        )
        checkpoint = _verify_file(config["checkpoints"][arm_id], label=f"{arm_id} checkpoint")
        paths[f"{arm_id}_checkpoint"] = str(checkpoint)
    parent_path = _verify_file(config["canonical_parents"], label="canonical parents")
    paths["canonical_parents"] = str(parent_path)
    controls = select_control_parents(_read_jsonl(parent_path), count=int(config["control_count"]))
    chgnet_weight = _verify_file(
        {
            "path": config["chgnet"]["weight_path"],
            "sha256": config["chgnet"]["weight_sha256"],
        },
        label="CHGNet weight",
    )
    paths["chgnet_weight"] = str(chgnet_weight)
    return {
        "paths": paths,
        "selected_candidates": selected_candidates,
        "controls": controls,
    }


def _sample_manifest(config: Mapping[str, Any], prepared: Mapping[str, Any]) -> dict[str, Any]:
    samples: list[dict[str, Any]] = []
    for arm_id in ("C0", "C1"):
        for record in prepared["selected_candidates"][arm_id]:
            condition = record["condition"]
            samples.append(
                {
                    "sample_id": f"{arm_id}::{condition['condition_id']}",
                    "sample_group": arm_id,
                    "condition_id": condition["condition_id"],
                    "attempt_index": int(condition["attempt_index"]),
                    "condition_seed": int(condition["condition_seed"]),
                    "target_space_group": int(condition["space_group"]),
                    "source_candidate_sha256": _payload_sha256(record["candidate"]),
                }
            )
    for parent in prepared["controls"]:
        material_id = str(parent["material_id"])
        samples.append(
            {
                "sample_id": f"MP::{material_id}",
                "sample_group": "REAL_MP_CONTROL",
                "material_id": material_id,
                "target_space_group": int(parent["space_group"]),
                "source_structure_sha256": _payload_sha256(
                    {
                        "atomic_numbers": parent["atomic_numbers"],
                        "fractional_coordinates": parent["fractional_coordinates"],
                        "lattice": parent["lattice"],
                    }
                ),
            }
        )
        perturbed = perturb_control_parent(parent, root_seed=int(config["root_seed"]))
        samples.append(
            {
                "sample_id": perturbed["sample_id"],
                "sample_group": "PERTURBED_MP_CONTROL",
                "material_id": material_id,
                "target_space_group": int(parent["space_group"]),
                "perturbation": perturbed["perturbation"],
                "source_structure_sha256": _payload_sha256(
                    {
                        "atomic_numbers": perturbed["atomic_numbers"],
                        "fractional_coordinates": perturbed["fractional_coordinates"],
                        "lattice": perturbed["lattice"],
                    }
                ),
            }
        )
    counts = {
        group: sum(sample["sample_group"] == group for sample in samples)
        for group in ("C0", "C1", "REAL_MP_CONTROL", "PERTURBED_MP_CONTROL")
    }
    if counts != {
        "C0": 50,
        "C1": 50,
        "REAL_MP_CONTROL": 20,
        "PERTURBED_MP_CONTROL": 20,
    }:
        raise RuntimeError(f"diagnostic sample mapping count mismatch: {counts}")
    identifiers = [sample["sample_id"] for sample in samples]
    if len(set(identifiers)) != 140:
        raise RuntimeError("diagnostic sample mapping contains duplicate IDs")
    return {
        "schema_version": "g1-final-diagnostic-sample-manifest.1.0.0",
        "root_seed": int(config["root_seed"]),
        "selection_policy": {
            "generated": "first 50 legal terminal records ordered by attempt_index",
            "controls": "first 20 eligible stable train_fit parents ordered by material_id",
            "excluded_parent_id": "mp-1173150",
            "refill_count": 0,
        },
        "counts": counts,
        "samples": samples,
    }


def _load_frozen_model(arm_id: str, config: Mapping[str, Any]) -> torch.nn.Module:
    from crysalis_g1.experiments.local_pilot_config import (
        pilot_model_config,
        select_geometry,
    )
    from crysalis_g1.model.local_pilot_model import UnifiedLocalPilotModel

    model = UnifiedLocalPilotModel(
        pilot_model_config(
            arm_id=arm_id,
            geometry=select_geometry(str(config["geometry_backend"])),
            relation_library_backend=str(config["relation_library_backend"]),
        )
    )
    checkpoint_path = Path(str(config["checkpoints"][arm_id]["path"]))
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=True)
    if (
        str(checkpoint["arm_id"]) != arm_id
        or int(checkpoint["root_seed"]) != int(config["root_seed"])
        or int(checkpoint["completed_updates"]) != 8500
        or bool(checkpoint["three_seed_authorized"])
        or bool(checkpoint["server_deployment_authorized"])
    ):
        raise RuntimeError(f"{arm_id} checkpoint provenance contract failed")
    model.load_state_dict(checkpoint["model_state_dict"], strict=True)
    return model


def _first_symmetry_failure(stages: Mapping[str, Any]) -> str | None:
    for stage_name in ("S1", "S2", "S3", "S4"):
        audit = stages.get(stage_name)
        if audit is None or not bool(audit["by_symprec"]["0.03"]["target_match"]):
            return stage_name
    return None


def _symmetry_summary(records: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    summary: dict[str, Any] = {}
    for arm_id in ("C0", "C1"):
        arm = [record for record in records if record["arm_id"] == arm_id]
        first_failures: dict[str, int] = {}
        for record in arm:
            key = str(record["first_symmetry_failure_stage"] or "NONE")
            first_failures[key] = first_failures.get(key, 0) + 1
        stage_matches = {
            stage: sum(
                bool(record["stages"][stage]["by_symprec"]["0.03"]["target_match"])
                for record in arm
                if record["stages"].get(stage) is not None
            )
            for stage in ("S1", "S2", "S3", "S4")
        }
        summary[arm_id] = {
            "candidate_count": len(arm),
            "replay_match_count": sum(bool(record["replay_match"]) for record in arm),
            "first_symmetry_failure_counts": first_failures,
            "target_space_group_match_count_symprec_0.03": stage_matches,
            "compiler_changed_projector_state_count": sum(
                bool(record["compiler_changed_projector_state"]) for record in arm
            ),
            "export_site_or_composition_change_count": sum(
                not bool(record["export_reload_evidence"]["site_count_preserved"])
                or not bool(record["export_reload_evidence"]["composition_preserved"])
                for record in arm
            ),
            "s3_match_s4_loss_count": sum(
                bool(record["stages"]["S3"]["by_symprec"]["0.03"]["target_match"])
                and not bool(record["stages"]["S4"]["by_symprec"]["0.03"]["target_match"])
                for record in arm
            ),
        }
    return summary


def _run_symmetry_audit(
    config: Mapping[str, Any],
    prepared: Mapping[str, Any],
    *,
    output_root: Path,
    failures_path: Path,
) -> tuple[dict[str, Any], dict[str, dict[str, Any]]]:
    from crysalis_g1.experiments.local_free_rollout import (
        FreeRolloutConfig,
        replay_free_rollout_with_stages,
    )

    rollout_config = FreeRolloutConfig(
        root_seed=int(config["root_seed"]),
        max_assembly_steps=int(config["max_assembly_steps"]),
        max_orbits=int(config["max_orbits"]),
        short_contact_distance=float(config["generation_short_contact_distance"]),
        device=str(config["device"]),
        mixed_precision=bool(config["mixed_precision"]),
        sampling_temperature=float(config["sampling_temperature"]),
        coordinate_proposal_budget=int(config["coordinate_proposal_budget"]),
    )
    intermediate = output_root / "_SYMMETRY_RECORDS.jsonl"
    candidate_structures: dict[str, dict[str, Any]] = {}
    audit_records: list[dict[str, Any]] = []
    with intermediate.open("x", encoding="utf-8", newline="\n"):
        pass
    for arm_id in ("C0", "C1"):
        model = _load_frozen_model(arm_id, config)
        for index, source in enumerate(prepared["selected_candidates"][arm_id], 1):
            condition = source["condition"]
            sample_id = f"{arm_id}::{condition['condition_id']}"
            try:
                replay = replay_free_rollout_with_stages(
                    model=model,
                    condition=condition,
                    config=rollout_config,
                )
                replay_match = _payload_sha256(replay["candidate"]) == _payload_sha256(
                    source["candidate"]
                )
                stage_payloads = replay["diagnostic_stages"]
                s3_payload = stage_payloads["S3"]["committed_structure"]
                stages = {
                    "S1": analyse_symmetry_stage(
                        "S1",
                        structure_from_payload(stage_payloads["S1"]["structure"]),
                        target_space_group=int(condition["space_group"]),
                    ),
                    "S2": analyse_symmetry_stage(
                        "S2",
                        structure_from_payload(stage_payloads["S2"]["structure"]),
                        target_space_group=int(condition["space_group"]),
                    ),
                    "S3": analyse_symmetry_stage(
                        "S3",
                        structure_from_payload(s3_payload),
                        target_space_group=int(condition["space_group"]),
                    ),
                }
                model_projector_audit = analyse_symmetry_stage(
                    "S3_MODEL_PROJECTOR_INTERNAL",
                    structure_from_payload(stage_payloads["S3"]["model_projector_structure"]),
                    target_space_group=int(condition["space_group"]),
                )
                reloaded, export_evidence = cif_export_reload(structure_from_payload(s3_payload))
                stages["S4"] = analyse_symmetry_stage(
                    "S4", reloaded, target_space_group=int(condition["space_group"])
                )
                candidate_structures[sample_id] = structure_payload(reloaded)
                first_failure = _first_symmetry_failure(stages)
                record = {
                    "sample_id": sample_id,
                    "arm_id": arm_id,
                    "condition_id": str(condition["condition_id"]),
                    "attempt_index": int(condition["attempt_index"]),
                    "condition_seed": int(condition["condition_seed"]),
                    "target_space_group": int(condition["space_group"]),
                    "replay_match": replay_match,
                    "source_candidate_sha256": _payload_sha256(source["candidate"]),
                    "replay_candidate_sha256": _payload_sha256(replay["candidate"]),
                    "stages": stages,
                    "model_projector_internal_audit": model_projector_audit,
                    "compiler_changed_projector_state": bool(
                        stage_payloads["S3"]["compiler_changed_projector_state"]
                    ),
                    "export_reload_evidence": export_evidence,
                    "first_symmetry_failure_stage": first_failure,
                    "status": "AUDITED" if replay_match else "REPLAY_MISMATCH",
                }
                if not replay_match:
                    _append_jsonl(
                        failures_path,
                        {
                            "failure_type": "FROZEN_REPLAY_MISMATCH",
                            "sample_id": sample_id,
                            "source_candidate_sha256": record["source_candidate_sha256"],
                            "replay_candidate_sha256": record["replay_candidate_sha256"],
                            "retry_count": 0,
                        },
                    )
                if first_failure is not None:
                    _append_jsonl(
                        failures_path,
                        {
                            "failure_type": "TARGET_SYMMETRY_LOSS",
                            "sample_id": sample_id,
                            "target_space_group": int(condition["space_group"]),
                            "first_failure_stage": first_failure,
                            "detected_space_groups_symprec_0.03": {
                                stage: stages[stage]["by_symprec"]["0.03"]["detected_space_group"]
                                for stage in ("S1", "S2", "S3", "S4")
                            },
                            "retry_count": 0,
                        },
                    )
            except Exception as error:
                frozen_structure = structure_from_payload(source["candidate"])
                reloaded, export_evidence = cif_export_reload(frozen_structure)
                candidate_structures[sample_id] = structure_payload(reloaded)
                record = {
                    "sample_id": sample_id,
                    "arm_id": arm_id,
                    "condition_id": str(condition["condition_id"]),
                    "attempt_index": int(condition["attempt_index"]),
                    "condition_seed": int(condition["condition_seed"]),
                    "target_space_group": int(condition["space_group"]),
                    "replay_match": False,
                    "source_candidate_sha256": _payload_sha256(source["candidate"]),
                    "replay_candidate_sha256": None,
                    "stages": {
                        "S1": None,
                        "S2": None,
                        "S3": analyse_symmetry_stage(
                            "S3_FROZEN_FALLBACK",
                            frozen_structure,
                            target_space_group=int(condition["space_group"]),
                        ),
                        "S4": analyse_symmetry_stage(
                            "S4_FROZEN_FALLBACK",
                            reloaded,
                            target_space_group=int(condition["space_group"]),
                        ),
                    },
                    "model_projector_internal_audit": None,
                    "compiler_changed_projector_state": False,
                    "export_reload_evidence": export_evidence,
                    "first_symmetry_failure_stage": "S1",
                    "status": "REPLAY_EXCEPTION",
                    "exception_type": type(error).__name__,
                    "exception_message": str(error),
                }
                _append_jsonl(
                    failures_path,
                    {
                        "failure_type": "FROZEN_REPLAY_EXCEPTION",
                        "sample_id": sample_id,
                        "exception_type": type(error).__name__,
                        "exception_message": str(error),
                        "retry_count": 0,
                    },
                )
            audit_records.append(record)
            _append_jsonl(intermediate, record)
            print(
                f"SYMMETRY {arm_id} {index}/50 {record['status']} first={record['first_symmetry_failure_stage']}",
                flush=True,
            )
        model.cpu()
        del model
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    payload = {
        "schema_version": "g1-final-symmetry-stage-audit.1.0.0",
        "diagnostic_id": "FINAL_DIAGNOSTIC_V1",
        "symprecs": list(SYMPRECS),
        "primary_symprec": 0.03,
        "stage_definitions": {
            "S1": "orbit multiplicity expansion before learned geometry displacement",
            "S2": "expanded state after learned geometry displacement",
            "S3": "actually committed state after model projector and legal compiler",
            "S4": "S3 state after CIF export and reload",
        },
        "orbit_identity_rule": "symmetry-equivalent site membership; wyckoff index alone is not an orbit ID",
        "summary": _symmetry_summary(audit_records),
        "records": audit_records,
    }
    _write_json_new(output_root / "SYMMETRY_STAGE_AUDIT.json", payload)
    return payload, candidate_structures


def _load_chgnet_optimizer(config: Mapping[str, Any]) -> Any:
    import chgnet
    from chgnet.model import CHGNet, StructOptimizer

    chgnet_config = config["chgnet"]
    if chgnet.__version__ != str(chgnet_config["package_version"]):
        raise RuntimeError(
            f"CHGNet package mismatch: {chgnet.__version__} != {chgnet_config['package_version']}"
        )
    model = CHGNet.load(
        model_name=str(chgnet_config["model_version"]),
        use_device=str(config["device"]),
        verbose=False,
    )
    if str(getattr(model, "version", "")) != str(chgnet_config["model_version"]):
        raise RuntimeError("loaded CHGNet model version mismatch")
    return StructOptimizer(
        model=model,
        optimizer_class=str(chgnet_config["optimizer"]),
        use_device=str(config["device"]),
        on_isolated_atoms="error",
    )


def _exception_checkpoints(
    initial: Structure, *, maximum_steps: int, error: Exception
) -> dict[str, dict[str, Any]]:
    try:
        detected_space_group = int(
            SpacegroupAnalyzer(initial, symprec=0.03).get_space_group_number()
        )
    except Exception:
        detected_space_group = 0
    checkpoints: dict[str, dict[str, Any]] = {}
    for step in (0, 20, 100, 300):
        if step > maximum_steps:
            checkpoints[str(step)] = {
                "observation_status": f"NOT_APPLICABLE_MAX_STEPS_{maximum_steps}",
                "source_step": None,
            }
        elif step == 0:
            checkpoints["0"] = {
                "observation_status": "INITIAL_STRUCTURE_FORCE_ENERGY_UNAVAILABLE",
                "source_step": 0,
                "maximum_force_ev_per_angstrom": None,
                "energy_ev": None,
                "energy_ev_per_atom": None,
                "rmsd_angstrom": 0.0,
                "lattice_relative_change": 0.0,
                "converged": False,
                "collapse": classify_collapse(initial),
                "detected_space_group_symprec_0.03": detected_space_group,
                "structure": structure_payload(initial),
            }
        else:
            checkpoints[str(step)] = {
                "observation_status": "UNAVAILABLE_RELAXATION_EXCEPTION",
                "source_step": None,
                "exception_type": type(error).__name__,
            }
    return checkpoints


def _evaluate_chgnet_protocol(
    optimizer: Any,
    initial: Structure,
    *,
    sample: Mapping[str, Any],
    protocol: Mapping[str, Any],
    force_threshold: float,
) -> dict[str, Any]:
    started = time.perf_counter()
    maximum_steps = int(protocol["maximum_steps"])
    relax_cell = bool(protocol["relax_cell"])
    try:
        result = optimizer.relax(
            initial.copy(),
            fmax=force_threshold,
            steps=maximum_steps,
            relax_cell=relax_cell,
            loginterval=1,
            verbose=False,
            assign_magmoms=False,
        )
        trajectory = result["trajectory"]
        checkpoints = extract_relaxation_checkpoints(
            initial,
            trajectory,
            maximum_steps=maximum_steps,
            relax_cell=relax_cell,
            force_threshold=force_threshold,
        )
        final_key = str(maximum_steps)
        final = checkpoints[final_key]
        return {
            "sample_id": str(sample["sample_id"]),
            "sample_group": str(sample["sample_group"]),
            "target_space_group": int(sample["target_space_group"]),
            "protocol_id": str(protocol["protocol_id"]),
            "maximum_steps": maximum_steps,
            "relax_cell": relax_cell,
            "force_threshold_ev_per_angstrom": force_threshold,
            "status": "EVALUATED",
            "trajectory_observation_count_raw": len(trajectory.forces),
            "final_converged": bool(final["converged"]),
            "final_collapsed": bool(final["collapse"]["collapsed"]),
            "final_target_space_group_match": int(final["detected_space_group_symprec_0.03"])
            == int(sample["target_space_group"]),
            "checkpoints": checkpoints,
            "latency_seconds": time.perf_counter() - started,
        }
    except Exception as error:
        return {
            "sample_id": str(sample["sample_id"]),
            "sample_group": str(sample["sample_group"]),
            "target_space_group": int(sample["target_space_group"]),
            "protocol_id": str(protocol["protocol_id"]),
            "maximum_steps": maximum_steps,
            "relax_cell": relax_cell,
            "force_threshold_ev_per_angstrom": force_threshold,
            "status": "CHGNET_RELAXATION_EXCEPTION",
            "exception_type": type(error).__name__,
            "exception_message": str(error),
            "final_converged": False,
            "final_collapsed": bool(classify_collapse(initial)["collapsed"]),
            "final_target_space_group_match": False,
            "checkpoints": _exception_checkpoints(
                initial, maximum_steps=maximum_steps, error=error
            ),
            "latency_seconds": time.perf_counter() - started,
        }


def _diagnostic_samples(
    config: Mapping[str, Any],
    prepared: Mapping[str, Any],
    candidate_structures: Mapping[str, Mapping[str, Any]],
) -> list[dict[str, Any]]:
    samples: list[dict[str, Any]] = []
    for arm_id in ("C0", "C1"):
        for record in prepared["selected_candidates"][arm_id]:
            condition = record["condition"]
            sample_id = f"{arm_id}::{condition['condition_id']}"
            samples.append(
                {
                    "sample_id": sample_id,
                    "sample_group": arm_id,
                    "target_space_group": int(condition["space_group"]),
                    "structure": dict(candidate_structures[sample_id]),
                }
            )
    for parent in prepared["controls"]:
        material_id = str(parent["material_id"])
        parent_payload = {
            "atomic_numbers": parent["atomic_numbers"],
            "fractional_coordinates": parent["fractional_coordinates"],
            "lattice": parent["lattice"],
        }
        samples.append(
            {
                "sample_id": f"MP::{material_id}",
                "sample_group": "REAL_MP_CONTROL",
                "target_space_group": int(parent["space_group"]),
                "structure": parent_payload,
            }
        )
        perturbed = perturb_control_parent(parent, root_seed=int(config["root_seed"]))
        samples.append(
            {
                "sample_id": perturbed["sample_id"],
                "sample_group": "PERTURBED_MP_CONTROL",
                "target_space_group": int(parent["space_group"]),
                "structure": {
                    "atomic_numbers": perturbed["atomic_numbers"],
                    "fractional_coordinates": perturbed["fractional_coordinates"],
                    "lattice": perturbed["lattice"],
                },
            }
        )
    if len(samples) != 140:
        raise RuntimeError(f"expected 140 diagnostic structures, found {len(samples)}")
    return samples


def _median(values: Iterable[float | None]) -> float | None:
    finite = [float(value) for value in values if value is not None and math.isfinite(value)]
    return statistics.median(finite) if finite else None


def _relaxation_summary(records: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    summary: dict[str, Any] = {}
    groups = ("C0", "C1", "REAL_MP_CONTROL", "PERTURBED_MP_CONTROL")
    protocols = (
        "A_FIXED_CELL_FIRE_100",
        "B_FIXED_CELL_FIRE_300",
        "C_CELL_RELAX_FIRE_300",
    )
    for group in groups:
        summary[group] = {}
        for protocol_id in protocols:
            subset = [
                record
                for record in records
                if record["sample_group"] == group and record["protocol_id"] == protocol_id
            ]
            final_key = "100" if protocol_id.endswith("100") else "300"
            evaluated = [record for record in subset if record["status"] == "EVALUATED"]
            final = [record["checkpoints"][final_key] for record in evaluated]
            summary[group][protocol_id] = {
                "attempt_count": len(subset),
                "evaluated_count": len(evaluated),
                "exception_count": len(subset) - len(evaluated),
                "final_converged_count": sum(bool(record["final_converged"]) for record in subset),
                "final_collapse_count": sum(bool(record["final_collapsed"]) for record in subset),
                "final_converged_noncollapsed_count": sum(
                    bool(record["final_converged"]) and not bool(record["final_collapsed"])
                    for record in subset
                ),
                "final_target_space_group_match_count": sum(
                    bool(record["final_target_space_group_match"]) for record in subset
                ),
                "final_maximum_force_median_ev_per_angstrom": _median(
                    checkpoint.get("maximum_force_ev_per_angstrom") for checkpoint in final
                ),
                "final_energy_median_ev_per_atom": _median(
                    checkpoint.get("energy_ev_per_atom") for checkpoint in final
                ),
                "final_rmsd_median_angstrom": _median(
                    checkpoint.get("rmsd_angstrom") for checkpoint in final
                ),
                "final_lattice_relative_change_median": _median(
                    checkpoint.get("lattice_relative_change") for checkpoint in final
                ),
                "latency_median_seconds": _median(
                    record.get("latency_seconds") for record in subset
                ),
            }
    return summary


def _run_chgnet_diagnostic(
    config: Mapping[str, Any],
    prepared: Mapping[str, Any],
    candidate_structures: Mapping[str, Mapping[str, Any]],
    *,
    output_root: Path,
    failures_path: Path,
) -> dict[str, Any]:
    samples = _diagnostic_samples(config, prepared, candidate_structures)
    optimizer = _load_chgnet_optimizer(config)
    force_threshold = float(config["chgnet"]["force_threshold_ev_per_angstrom"])
    protocols = list(config["chgnet"]["protocols"])
    intermediate = output_root / "_CHGNET_RECORDS.jsonl"
    with intermediate.open("x", encoding="utf-8", newline="\n"):
        pass
    records: list[dict[str, Any]] = []
    total = len(samples) * len(protocols)
    completed = 0
    for sample in samples:
        initial = structure_from_payload(sample["structure"])
        for protocol in protocols:
            print(
                f"CHGNET START {completed + 1}/{total} {sample['sample_id']} "
                f"{protocol['protocol_id']}",
                flush=True,
            )
            record = _evaluate_chgnet_protocol(
                optimizer,
                initial,
                sample=sample,
                protocol=protocol,
                force_threshold=force_threshold,
            )
            records.append(record)
            _append_jsonl(intermediate, record)
            completed += 1
            print(
                f"CHGNET DONE {completed}/{total} {record['status']} "
                f"converged={record['final_converged']} collapse={record['final_collapsed']} "
                f"seconds={record['latency_seconds']:.3f}",
                flush=True,
            )
            if record["status"] != "EVALUATED":
                _append_jsonl(
                    failures_path,
                    {
                        "failure_type": "CHGNET_RELAXATION_EXCEPTION",
                        "sample_id": record["sample_id"],
                        "protocol_id": record["protocol_id"],
                        "exception_type": record["exception_type"],
                        "exception_message": record["exception_message"],
                        "retry_count": 0,
                    },
                )
            elif bool(record["final_collapsed"]):
                _append_jsonl(
                    failures_path,
                    {
                        "failure_type": "CHGNET_FINAL_COLLAPSE",
                        "sample_id": record["sample_id"],
                        "protocol_id": record["protocol_id"],
                        "collapse": record["checkpoints"][str(record["maximum_steps"])]["collapse"],
                        "retry_count": 0,
                    },
                )
            elif not bool(record["final_converged"]):
                _append_jsonl(
                    failures_path,
                    {
                        "failure_type": "CHGNET_NOT_CONVERGED_WITHIN_BUDGET",
                        "sample_id": record["sample_id"],
                        "protocol_id": record["protocol_id"],
                        "final_maximum_force_ev_per_angstrom": record["checkpoints"][
                            str(record["maximum_steps"])
                        ]["maximum_force_ev_per_angstrom"],
                        "retry_count": 0,
                    },
                )
    payload = {
        "schema_version": "g1-final-chgnet-relaxation-curves.1.0.0",
        "diagnostic_id": "FINAL_DIAGNOSTIC_V1",
        "provenance": {
            "package_version": str(config["chgnet"]["package_version"]),
            "model_version": str(config["chgnet"]["model_version"]),
            "weight_sha256": str(config["chgnet"]["weight_sha256"]).lower(),
            "optimizer": "FIRE",
            "force_threshold_ev_per_angstrom": force_threshold,
            "requested_checkpoints": [0, 20, 100, 300],
            "training_role": "EVALUATION_ONLY",
            "enters_model_loss": False,
        },
        "sample_count": len(samples),
        "protocol_count": len(protocols),
        "record_count": len(records),
        "summary": _relaxation_summary(records),
        "records": records,
    }
    _write_json_new(output_root / "CHGNET_RELAXATION_CURVES.json", payload)
    return payload


def _control_group_results(chgnet: Mapping[str, Any]) -> dict[str, Any]:
    records = list(chgnet["records"])
    controls = [
        record
        for record in records
        if record["sample_group"] in {"REAL_MP_CONTROL", "PERTURBED_MP_CONTROL"}
    ]
    by_sample: list[dict[str, Any]] = []
    for sample_id in sorted({str(record["sample_id"]) for record in controls}):
        sample_records = [record for record in controls if record["sample_id"] == sample_id]
        protocols: dict[str, Any] = {}
        for record in sample_records:
            final_key = str(record["maximum_steps"])
            final = record["checkpoints"][final_key]
            protocols[str(record["protocol_id"])] = {
                "status": record["status"],
                "final_converged": bool(record["final_converged"]),
                "final_collapsed": bool(record["final_collapsed"]),
                "final_target_space_group_match": bool(record["final_target_space_group_match"]),
                "final_maximum_force_ev_per_angstrom": final.get("maximum_force_ev_per_angstrom"),
                "final_rmsd_angstrom": final.get("rmsd_angstrom"),
                "final_lattice_relative_change": final.get("lattice_relative_change"),
                "final_detected_space_group_symprec_0.03": final.get(
                    "detected_space_group_symprec_0.03"
                ),
            }
        initial = sample_records[0]["checkpoints"]["0"]
        by_sample.append(
            {
                "sample_id": sample_id,
                "sample_group": sample_records[0]["sample_group"],
                "target_space_group": int(sample_records[0]["target_space_group"]),
                "initial_detected_space_group_symprec_0.03": initial.get(
                    "detected_space_group_symprec_0.03"
                ),
                "initial_collapse": initial.get("collapse"),
                "protocols": protocols,
            }
        )
    return {
        "schema_version": "g1-final-control-group-results.1.0.0",
        "diagnostic_id": "FINAL_DIAGNOSTIC_V1",
        "real_mp_control_count": sum(
            sample["sample_group"] == "REAL_MP_CONTROL" for sample in by_sample
        ),
        "perturbed_mp_control_count": sum(
            sample["sample_group"] == "PERTURBED_MP_CONTROL" for sample in by_sample
        ),
        "summary": {
            "REAL_MP_CONTROL": chgnet["summary"]["REAL_MP_CONTROL"],
            "PERTURBED_MP_CONTROL": chgnet["summary"]["PERTURBED_MP_CONTROL"],
        },
        "records": by_sample,
    }


def _decision_evidence(symmetry: Mapping[str, Any], chgnet: Mapping[str, Any]) -> dict[str, Any]:
    symmetry_records = list(symmetry["records"])
    relaxation_records = list(chgnet["records"])
    replay_mismatch_count = sum(not bool(record["replay_match"]) for record in symmetry_records)
    export_site_or_composition_change_count = sum(
        not bool(record["export_reload_evidence"]["site_count_preserved"])
        or not bool(record["export_reload_evidence"]["composition_preserved"])
        for record in symmetry_records
    )
    s3_match_s4_loss_count = sum(
        bool(record["stages"]["S3"]["by_symprec"]["0.03"]["target_match"])
        and not bool(record["stages"]["S4"]["by_symprec"]["0.03"]["target_match"])
        for record in symmetry_records
        if record["stages"].get("S3") is not None
    )
    clean_ids = {
        str(record["sample_id"])
        for record in relaxation_records
        if record["sample_group"] == "REAL_MP_CONTROL"
    }
    clean_control_all_protocol_failure_count = 0
    for sample_id in clean_ids:
        subset = [record for record in relaxation_records if record["sample_id"] == sample_id]
        if subset and all(
            record["status"] != "EVALUATED" or bool(record["final_collapsed"]) for record in subset
        ):
            clean_control_all_protocol_failure_count += 1
    candidate_s1_s2_first_failure_count = sum(
        record["first_symmetry_failure_stage"] in {"S1", "S2"} for record in symmetry_records
    )
    s4_target_match_count = sum(
        bool(record["stages"]["S4"]["by_symprec"]["0.03"]["target_match"])
        for record in symmetry_records
    )
    candidate_ids = {
        str(record["sample_id"])
        for record in relaxation_records
        if record["sample_group"] in {"C0", "C1"}
    }
    generated_converged_noncollapsed_300_count = sum(
        any(
            record["sample_id"] == sample_id
            and int(record["maximum_steps"]) == 300
            and bool(record["final_converged"])
            and not bool(record["final_collapsed"])
            for record in relaxation_records
        )
        for sample_id in candidate_ids
    )
    generated_cell = chgnet["summary"]
    generated_cell_survival_count = sum(
        int(generated_cell[arm]["C_CELL_RELAX_FIRE_300"]["final_converged_noncollapsed_count"])
        for arm in ("C0", "C1")
    )
    clean_cell_survival_count = int(
        generated_cell["REAL_MP_CONTROL"]["C_CELL_RELAX_FIRE_300"][
            "final_converged_noncollapsed_count"
        ]
    )
    generated_cell_survival_rate = generated_cell_survival_count / 100
    clean_cell_survival_rate = clean_cell_survival_count / 20
    generated_materially_worse = clean_cell_survival_rate - generated_cell_survival_rate >= 0.20
    systematic_s3_to_s4_loss = s3_match_s4_loss_count >= 20
    pipeline_failure_confirmed = bool(
        replay_mismatch_count or export_site_or_composition_change_count or systematic_s3_to_s4_loss
    )
    s1_failure_count = sum(
        record["first_symmetry_failure_stage"] == "S1" for record in symmetry_records
    )
    expansion_bug_confirmed = s1_failure_count >= 80
    return {
        "pipeline_failure_confirmed": pipeline_failure_confirmed,
        "pipeline_failure_components": {
            "frozen_replay_mismatch_count": replay_mismatch_count,
            "export_site_or_composition_change_count": export_site_or_composition_change_count,
            "s3_match_s4_loss_count": s3_match_s4_loss_count,
            "systematic_s3_to_s4_loss_threshold": 20,
        },
        "clean_control_all_protocol_failure_count": clean_control_all_protocol_failure_count,
        "clean_control_count": 20,
        "candidate_count": 100,
        "candidate_s1_s2_first_failure_count": candidate_s1_s2_first_failure_count,
        "s1_first_failure_count": s1_failure_count,
        "generated_materially_worse_than_controls": generated_materially_worse,
        "generated_cell_relax_converged_noncollapsed_rate": generated_cell_survival_rate,
        "clean_control_cell_relax_converged_noncollapsed_rate": clean_cell_survival_rate,
        "s4_target_match_count": s4_target_match_count,
        "generated_converged_noncollapsed_300_count": generated_converged_noncollapsed_300_count,
        "architecture_contracts_satisfied": False,
        "static_contract_evidence": {
            "orbit_expansion_reads_target_space_group": False,
            "orbit_expansion_reads_wyckoff_index": False,
            "orbit_expansion_rule": "fixed golden-ratio translations keyed only by representative and multiplicity",
            "tensor_projector_reads_target_space_group": False,
            "tensor_projector_behavior": "unit-cell wrapping and minimum-distance validation only",
        },
        "allowed_repair_assessment": {
            "exporter_reloader_bug_confirmed": bool(
                export_site_or_composition_change_count or systematic_s3_to_s4_loss
            ),
            "projector_bug_isolated": False,
            "symmetry_expansion_bug_confirmed": expansion_bug_confirmed,
            "evaluation_protocol_bug_confirmed": clean_control_all_protocol_failure_count >= 4,
            "repair_applied": False,
            "repair_reason": (
                "The confirmed expansion defect is an absent target-SG/Wyckoff contract, "
                "not a local arithmetic error; repairing it would introduce a new action/compiler "
                "formulation and is outside a frozen-checkpoint diagnostic."
                if expansion_bug_confirmed
                else "No allowed local defect met the preregistered evidence threshold."
            ),
        },
    }


def _report_markdown(
    config: Mapping[str, Any],
    symmetry: Mapping[str, Any],
    chgnet: Mapping[str, Any],
    decision: Mapping[str, Any],
) -> str:
    lines = [
        "# FINAL_DIAGNOSTIC_V1 Report",
        "",
        f"**Final conclusion: `{decision['final_conclusion']}`**",
        "",
        "## Frozen execution boundary",
        "",
        "- Model retraining: **not performed**.",
        "- Checkpoints: frozen C0/C1 `update-8500.pt` artifacts, hashes verified before use.",
        "- Server use: **false**. Three-seed execution: **false**. Refill/retry: **0**.",
        f"- Root seed: `{config['root_seed']}`; CHGNet force threshold: `0.2 eV/Å`.",
        "- Samples: 50 C0 + 50 C1 legal terminal candidates + 20 real MP controls + 20 paired mildly perturbed controls.",
        "",
        "## Symmetry chain",
        "",
        "At every stage, space groups were detected at symprec 0.01/0.03/0.05/0.10 Å. Orbit identity was computed from symmetry-equivalent site membership, not from a Wyckoff index alone.",
        "",
        "| Arm | Replay match | S1 target SG | S2 target SG | S3 target SG | S4 target SG | First failure S1 | First failure S2 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for arm_id in ("C0", "C1"):
        summary = symmetry["summary"][arm_id]
        stage = summary["target_space_group_match_count_symprec_0.03"]
        first = summary["first_symmetry_failure_counts"]
        lines.append(
            f"| {arm_id} | {summary['replay_match_count']}/50 | {stage['S1']}/50 | "
            f"{stage['S2']}/50 | {stage['S3']}/50 | {stage['S4']}/50 | "
            f"{first.get('S1', 0)} | {first.get('S2', 0)} |"
        )
    evidence = decision["evidence"]
    lines.extend(
        [
            "",
            "The actual implementation evidence is decisive: the orbit expander receives only a representative coordinate and multiplicity and creates sites with fixed golden-ratio translations; it does not read target SG or Wyckoff identity. The tensor projector likewise receives positions, lattice, and a mask, and only wraps the unit cell and checks minimum distance. It cannot enforce a requested space group.",
            "",
            f"Frozen replay mismatches: `{evidence['pipeline_failure_components']['frozen_replay_mismatch_count']}`. Export/reload site or composition changes: `{evidence['pipeline_failure_components']['export_site_or_composition_change_count']}`. S3-match-to-S4-loss cases: `{evidence['pipeline_failure_components']['s3_match_s4_loss_count']}`.",
            "",
            "## CHGNet relaxation",
            "",
            "Each of the 140 structures was started independently under A fixed-cell FIRE 100, B fixed-cell FIRE 300, and C cell-relax FIRE 300. Requested observations are stored at step 0/20/100/300; protocol A marks step 300 as not applicable. Early convergence carries the final observation forward with an explicit status.",
            "",
            "| Group | Protocol | Evaluated | Converged | Collapsed | Converged and noncollapsed | Median final max force (eV/Å) |",
            "|---|---|---:|---:|---:|---:|---:|",
        ]
    )
    for group in ("C0", "C1", "REAL_MP_CONTROL", "PERTURBED_MP_CONTROL"):
        for protocol_id in (
            "A_FIXED_CELL_FIRE_100",
            "B_FIXED_CELL_FIRE_300",
            "C_CELL_RELAX_FIRE_300",
        ):
            value = chgnet["summary"][group][protocol_id]
            force = value["final_maximum_force_median_ev_per_angstrom"]
            force_text = "NA" if force is None else f"{force:.6f}"
            lines.append(
                f"| {group} | {protocol_id} | {value['evaluated_count']}/{value['attempt_count']} | "
                f"{value['final_converged_count']} | {value['final_collapse_count']} | "
                f"{value['final_converged_noncollapsed_count']} | {force_text} |"
            )
    repair = evidence["allowed_repair_assessment"]
    lines.extend(
        [
            "",
            "## Model versus pipeline decision",
            "",
            f"- Clean-control all-protocol evaluator failures: `{evidence['clean_control_all_protocol_failure_count']}/20`.",
            f"- Generated cell-relax converged/noncollapsed rate: `{evidence['generated_cell_relax_converged_noncollapsed_rate']:.3f}`; clean controls: `{evidence['clean_control_cell_relax_converged_noncollapsed_rate']:.3f}`.",
            f"- Generated candidates first failing at S1/S2: `{evidence['candidate_s1_s2_first_failure_count']}/100`.",
            f"- S4 target-SG matches at symprec 0.03: `{evidence['s4_target_match_count']}/100`; generated candidates converged/noncollapsed under at least one 300-step protocol: `{evidence['generated_converged_noncollapsed_300_count']}/100`.",
            f"- Repair applied: `{str(repair['repair_applied']).lower()}`. {repair['repair_reason']}",
            "",
            "The exporter/reloader and evaluator are separated from the model by real and perturbed MP controls. The earliest dominant failure and the missing target-symmetry interfaces reside inside the current generation architecture, so the conclusion is not upgraded to a general rejection of the research hypothesis.",
            "",
            f"## Final conclusion: `{decision['final_conclusion']}`",
            "",
            "This is the sole FINAL_DIAGNOSTIC_V1 run. No same-class diagnostic, model retraining, server run, or three-seed matrix was started.",
            "",
        ]
    )
    return "\n".join(lines)


def run_final_diagnostic(config_path: str | Path) -> Path:
    config_path = Path(config_path).resolve()
    config = _load_config(config_path)
    prepared = _prepare_inputs(config)
    manifest = _sample_manifest(config, prepared)
    output_root = Path(str(config["output_root"])).resolve()
    output_root.mkdir(parents=True, exist_ok=False)
    failures_path = output_root / "FAILURES.jsonl"
    with failures_path.open("x", encoding="utf-8", newline="\n"):
        pass
    _write_json_new(
        output_root / "FINAL_DIAGNOSTIC_CONFIG.json",
        {
            **config,
            "source_config_path": str(config_path),
            "source_config_sha256": _sha256(config_path),
        },
    )
    _write_json_new(output_root / "SAMPLE_MANIFEST.json", manifest)
    started = time.perf_counter()
    print(f"FINAL_DIAGNOSTIC_V1 START output={output_root}", flush=True)
    symmetry, candidate_structures = _run_symmetry_audit(
        config,
        prepared,
        output_root=output_root,
        failures_path=failures_path,
    )
    chgnet = _run_chgnet_diagnostic(
        config,
        prepared,
        candidate_structures,
        output_root=output_root,
        failures_path=failures_path,
    )
    control_results = _control_group_results(chgnet)
    _write_json_new(output_root / "CONTROL_GROUP_RESULTS.json", control_results)
    evidence = _decision_evidence(symmetry, chgnet)
    conclusion = choose_final_decision(evidence)
    if conclusion not in ALLOWED_FINAL_DECISIONS:
        raise RuntimeError(f"unauthorized final conclusion: {conclusion}")
    decision = {
        "schema_version": "g1-final-model-vs-pipeline-decision.1.0.0",
        "diagnostic_id": "FINAL_DIAGNOSTIC_V1",
        "final_conclusion": conclusion,
        "allowed_conclusions": sorted(ALLOWED_FINAL_DECISIONS),
        "decision_rule_order": [
            "PIPELINE_OR_EVALUATOR_FAILURE",
            "CURRENT_MODEL_ARCHITECTURE_FAILURE",
            "VIABLE_SIGNAL_REMAINS",
            "CURRENT_METHOD_FORMULATION_NOT_SUPPORTED",
        ],
        "evidence": evidence,
        "no_model_retraining": True,
        "frozen_checkpoints_used": True,
        "server_used": False,
        "three_seed_started": False,
        "same_seed": True,
    }
    _write_json_new(output_root / "MODEL_VS_PIPELINE_DECISION.json", decision)
    report_path = output_root / "FINAL_DIAGNOSTIC_REPORT.md"
    with report_path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(_report_markdown(config, symmetry, chgnet, decision))
        stream.flush()
        os.fsync(stream.fileno())
    required = (
        "FINAL_DIAGNOSTIC_REPORT.md",
        "SYMMETRY_STAGE_AUDIT.json",
        "CHGNET_RELAXATION_CURVES.json",
        "CONTROL_GROUP_RESULTS.json",
        "MODEL_VS_PIPELINE_DECISION.json",
        "FAILURES.jsonl",
    )
    required_hashes = {name: _sha256(output_root / name) for name in required}
    final_manifest = {
        "schema_version": "g1-final-diagnostic-manifest.1.0.0",
        "diagnostic_id": "FINAL_DIAGNOSTIC_V1",
        "status": "COMPLETE",
        "final_conclusion": conclusion,
        "sample_count": 140,
        "symmetry_candidate_count": len(symmetry["records"]),
        "chgnet_record_count": len(chgnet["records"]),
        "required_file_sha256": required_hashes,
        "root_seed": int(config["root_seed"]),
        "no_model_retraining": True,
        "frozen_checkpoints_used": True,
        "server_used": False,
        "three_seed_started": False,
        "refill_count": 0,
        "retry_count": 0,
        "wall_seconds": time.perf_counter() - started,
    }
    _write_json_new(output_root / "FINAL_DIAGNOSTIC_MANIFEST.json", final_manifest)
    print(
        f"FINAL_DIAGNOSTIC_V1 COMPLETE conclusion={conclusion} "
        f"wall_seconds={final_manifest['wall_seconds']:.3f}",
        flush=True,
    )
    return output_root


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run the one-time FINAL_DIAGNOSTIC_V1")
    parser.add_argument("--config", required=True)
    arguments = parser.parse_args(argv)
    run_final_diagnostic(arguments.config)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
