from __future__ import annotations

import hashlib
import math
import time
from collections import Counter
from dataclasses import dataclass
from typing import Mapping, Sequence

import numpy as np
import torch
from scipy.stats import spearmanr
from torch import nn

from crysalis_g1.experiments.compatibility_operator import (
    MAX_UPDATES,
    fit_standardization,
    predict_regressor,
    train_fixed_regressor,
)

FOLD_SEED = 20260902
BOOTSTRAP_SEED = 20260902
REGISTERED_FEATURE_NAMES = (
    "candidate_framework_min_distance_min",
    "candidate_framework_min_distance_mean",
    "candidate_framework_coordination_mean",
    "candidate_framework_coordination_min",
    "candidate_framework_same_species_coordination_mean",
    "candidate_neighbor_Z_mean",
    "candidate_neighbor_Z_std",
    "candidate_coordinated_distance_mean",
    "orbit_internal_min_distance",
    "orbit_internal_pair_distance_mean",
    "short_contact_residual_max",
    "short_contact_residual_mean",
    "static_full_orbit_contact_score",
    "multiplicity",
    "free_DOF",
    "assembly_progress",
)

_ALLOWED_INPUTS = {
    "action_identity",
    "assembly_progress",
    "candidate_free_parameters",
    "candidate_orbit_coordinates",
    "candidate_species",
    "current_lattice",
    "current_partial_coordinates",
    "current_partial_species",
    "fixed_constants",
    "fixed_element_radii",
    "pbc",
}
_ALLOWED_SOURCE_ARRAYS = {
    "candidate_fractional_coordinates",
    "candidate_free_parameters",
    "complete_site_count",
    "framework_atomic_numbers",
    "framework_fractional_coordinates",
    "partial_site_count",
    "short_contact_residual_max",
    "short_contact_residual_mean",
}


@dataclass(frozen=True)
class OperatorDataset:
    sample_n: int
    evaluable_sample_n: int
    event_n: int
    features: np.ndarray
    force: np.ndarray
    target: np.ndarray
    event_ids: np.ndarray
    parent_ids: np.ndarray
    candidate_ids: np.ndarray
    candidate_indices: np.ndarray
    contact_scores: np.ndarray
    source_event_ids: tuple[str, ...]
    parent_oracle_force_by_event: Mapping[str, float]
    schema: Mapping[str, object]
    schema_audit: Mapping[str, object]


class FullOrbitCompatibilityMLP(nn.Module):
    def __init__(self, input_n: int, hidden_n: int = 128) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(input_n, hidden_n),
            nn.SiLU(),
            nn.Linear(hidden_n, hidden_n),
            nn.SiLU(),
            nn.Linear(hidden_n, 1),
        )

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        return self.network(values).squeeze(-1)


def trainable_parameter_count(model: nn.Module) -> int:
    return sum(
        parameter.numel() for parameter in model.parameters() if parameter.requires_grad
    )


def audit_parent_free_schema(schema: Mapping[str, object]) -> dict[str, object]:
    features = list(schema.get("features", []))
    names = [str(feature["name"]) for feature in features]
    if names != list(REGISTERED_FEATURE_NAMES):
        raise ValueError("feature names or order differ from the registered schema")
    violations = []
    for feature in features:
        forbidden_inputs = sorted(
            set(map(str, feature.get("allowed_inputs", []))) - _ALLOWED_INPUTS
        )
        forbidden_arrays = sorted(
            set(map(str, feature.get("source_arrays", []))) - _ALLOWED_SOURCE_ARRAYS
        )
        if forbidden_inputs or forbidden_arrays:
            violations.append(
                {
                    "feature": str(feature["name"]),
                    "forbidden_allowed_inputs": forbidden_inputs,
                    "forbidden_source_arrays": forbidden_arrays,
                }
            )
    return {
        "input_feature_n": len(names),
        "feature_names": names,
        "parent_dependent_input_n": len(violations),
        "violations": violations,
    }


def _as_nonempty_string(value: object, *, field: str) -> str:
    text = str(value).strip()
    if not text:
        raise ValueError(f"{field} must be nonempty")
    return text


def _as_finite_float(value: object, *, field: str) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{field} must be finite") from error
    if not math.isfinite(result):
        raise ValueError(f"{field} must be finite")
    return result


def build_operator_dataset(
    candidates: Sequence[Mapping[str, object]],
    events: Sequence[Mapping[str, object]],
    schema: Mapping[str, object],
) -> OperatorDataset:
    schema_audit = audit_parent_free_schema(schema)
    if int(schema_audit["parent_dependent_input_n"]) != 0:
        raise ValueError("parent-dependent inputs are forbidden")
    if len(candidates) != 1536:
        raise ValueError("registered corpus requires exactly 1536 candidate records")
    if len(events) != 64:
        raise ValueError("registered corpus requires exactly 64 event records")

    event_map: dict[str, Mapping[str, object]] = {}
    parent_values = []
    oracle_force_by_event = {}
    for row in events:
        event_id = _as_nonempty_string(row.get("event_id"), field="event_id")
        parent_id = _as_nonempty_string(row.get("parent_id"), field="parent_id")
        if event_id in event_map:
            raise ValueError("event IDs must be unique")
        if str(row.get("parent_oracle_status")) != "EVALUATED":
            raise ValueError("every parent oracle reference must be evaluated")
        event_map[event_id] = row
        parent_values.append(parent_id)
        oracle_force_by_event[event_id] = _as_finite_float(
            row.get("parent_oracle_force"), field="parent_oracle_force"
        )
    if len(set(parent_values)) != 64:
        raise ValueError("each event must belong to a unique parent")

    candidate_ids = [
        _as_nonempty_string(row.get("candidate_id"), field="candidate_id")
        for row in candidates
    ]
    if len(set(candidate_ids)) != len(candidate_ids):
        raise ValueError("candidate IDs must be unique")
    counts = Counter(str(row.get("event_id")) for row in candidates)
    if set(counts) != set(event_map) or set(counts.values()) != {24}:
        raise ValueError("every registered event must contain exactly 24 candidates")

    feature_rows = []
    force_values = []
    target_values = []
    kept_event_ids = []
    kept_parent_ids = []
    kept_candidate_ids = []
    kept_candidate_indices = []
    contact_scores = []
    undefined_target_n = 0
    indices_by_event: dict[str, set[int]] = {event_id: set() for event_id in event_map}
    for row, candidate_id in zip(candidates, candidate_ids, strict=True):
        event_id = _as_nonempty_string(row.get("event_id"), field="event_id")
        if event_id not in event_map:
            raise ValueError("candidate refers to an unknown event")
        parent_id = _as_nonempty_string(row.get("parent_id"), field="parent_id")
        if parent_id != str(event_map[event_id]["parent_id"]):
            raise ValueError("candidate parent does not match event parent")
        candidate_index = int(row["candidate_index"])
        if candidate_index in indices_by_event[event_id]:
            raise ValueError("candidate indices must be unique within each event")
        indices_by_event[event_id].add(candidate_index)

        target_text = str(row.get("force_target_log1p", "")).strip()
        force_text = str(row.get("initial_max_force_ev_per_angstrom", "")).strip()
        if not target_text or not force_text:
            undefined_target_n += 1
            if (
                target_text
                or force_text
                or str(row.get("chgnet_status")) == "EVALUATED"
            ):
                raise ValueError("undefined force target has inconsistent status")
            continue
        if str(row.get("chgnet_status")) != "EVALUATED":
            raise ValueError("defined force target must have EVALUATED status")
        force = _as_finite_float(force_text, field="initial_max_force_ev_per_angstrom")
        target = _as_finite_float(target_text, field="force_target_log1p")
        if force < 0.0 or not math.isclose(target, math.log1p(force), abs_tol=1e-9):
            raise ValueError("saved log1p-force target is inconsistent")
        features = np.asarray(
            [
                _as_finite_float(row.get(name), field=name)
                for name in REGISTERED_FEATURE_NAMES
            ],
            dtype=float,
        )
        feature_rows.append(features)
        force_values.append(force)
        target_values.append(target)
        kept_event_ids.append(event_id)
        kept_parent_ids.append(parent_id)
        kept_candidate_ids.append(candidate_id)
        kept_candidate_indices.append(candidate_index)
        contact_scores.append(
            _as_finite_float(
                row.get("static_full_orbit_contact_score"),
                field="static_full_orbit_contact_score",
            )
        )
    if undefined_target_n != 1 or len(feature_rows) != 1535:
        raise ValueError(
            "registered corpus requires exactly one undefined force target"
        )
    if any(indices != set(range(24)) for indices in indices_by_event.values()):
        raise ValueError("candidate indices must be exactly 0 through 23 per event")

    return OperatorDataset(
        sample_n=len(candidates),
        evaluable_sample_n=len(feature_rows),
        event_n=len(event_map),
        features=np.stack(feature_rows),
        force=np.asarray(force_values, dtype=float),
        target=np.asarray(target_values, dtype=float),
        event_ids=np.asarray(kept_event_ids, dtype=object),
        parent_ids=np.asarray(kept_parent_ids, dtype=object),
        candidate_ids=np.asarray(kept_candidate_ids, dtype=object),
        candidate_indices=np.asarray(kept_candidate_indices, dtype=int),
        contact_scores=np.asarray(contact_scores, dtype=float),
        source_event_ids=tuple(sorted(event_map)),
        parent_oracle_force_by_event=oracle_force_by_event,
        schema=schema,
        schema_audit=schema_audit,
    )


def fit_fold_model(
    *,
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_test: np.ndarray,
    device: str,
    seed: int,
    deadline: float | None = None,
    updates: int = MAX_UPDATES,
) -> dict[str, object]:
    raw_train = np.asarray(x_train, dtype=float)
    raw_test = np.asarray(x_test, dtype=float)
    target = np.asarray(y_train, dtype=float)
    if raw_train.ndim != 2 or raw_test.ndim != 2:
        raise ValueError("feature matrices must be two-dimensional")
    if raw_train.shape[1] != raw_test.shape[1] or len(raw_train) != len(target):
        raise ValueError("training and test shapes are inconsistent")
    if len(raw_train) == 0 or not (
        np.isfinite(raw_train).all()
        and np.isfinite(raw_test).all()
        and np.isfinite(target).all()
    ):
        raise ValueError("training arrays must be nonempty and finite")

    x_mean, x_scale = fit_standardization(raw_train)
    y_mean = float(np.mean(target))
    y_scale = float(np.std(target))
    if y_scale <= 1e-8:
        y_scale = 1.0
    normalized_train = (raw_train - x_mean) / x_scale
    normalized_test = (raw_test - x_mean) / x_scale
    normalized_target = (target - y_mean) / y_scale
    torch.manual_seed(int(seed))
    model = FullOrbitCompatibilityMLP(raw_train.shape[1])
    trained = train_fixed_regressor(
        model,
        normalized_train,
        normalized_target,
        device=device,
        seed=int(seed),
        deadline=deadline,
        updates=updates,
    )
    standardized_prediction = predict_regressor(
        trained["model"], normalized_test, device=device
    )
    prediction = standardized_prediction * y_scale + y_mean
    normalization = {
        "x_mean": [float(value) for value in x_mean],
        "x_scale": [float(value) for value in x_scale],
        "y_mean": y_mean,
        "y_scale": y_scale,
    }
    return {
        "model": trained["model"],
        "prediction": np.asarray(prediction, dtype=float),
        "normalization": normalization,
        "final_training_loss": float(trained["final_training_loss"]),
    }


def stable_random_candidate_index(event_id: str, candidate_ids: Sequence[str]) -> str:
    ordered = sorted(map(str, candidate_ids))
    if not ordered or len(ordered) != len(set(ordered)):
        raise ValueError("random baseline requires unique candidate IDs")
    seed = int(
        hashlib.sha256(f"20260902:full-orbit-random:{event_id}".encode()).hexdigest()[
            :16
        ],
        16,
    )
    generator = np.random.default_rng(seed)
    return ordered[int(generator.integers(0, len(ordered)))]


def evaluate_oof_predictions(
    *,
    dataset: OperatorDataset,
    prediction: np.ndarray,
    folds: Sequence[Sequence[str]],
    bootstrap_resamples: int = 10_000,
) -> dict[str, object]:
    scores = np.asarray(prediction, dtype=float)
    if scores.shape != dataset.target.shape or not np.isfinite(scores).all():
        raise ValueError("OOF predictions must be complete and finite")
    if len(folds) != 4 or [len(fold) for fold in folds] != [16, 16, 16, 16]:
        raise ValueError("OOF evaluation requires four folds of sixteen events")
    fold_by_event = {
        str(event_id): fold_index
        for fold_index, fold in enumerate(folds)
        for event_id in fold
    }
    if len(fold_by_event) != 64 or set(fold_by_event) != set(dataset.source_event_ids):
        raise ValueError("OOF folds do not cover each event exactly once")

    event_rows = []
    for event_id in sorted(dataset.source_event_ids):
        indices = np.flatnonzero(dataset.event_ids == event_id)
        ordered = indices[
            np.argsort(dataset.candidate_ids[indices].astype(str), kind="stable")
        ]
        force = dataset.force[ordered]
        event_scores = scores[ordered]
        metrics = event_ranking_metrics(force=force, prediction=event_scores)
        candidate_ids = dataset.candidate_ids[ordered].astype(str)
        mlp_local = int(metrics["top1_index"])
        contact_local = int(np.argmin(dataset.contact_scores[ordered]))
        random_id = stable_random_candidate_index(event_id, candidate_ids.tolist())
        random_local = int(np.flatnonzero(candidate_ids == random_id)[0])
        mlp_force = float(force[mlp_local])
        random_force = float(force[random_local])
        contact_force = float(force[contact_local])
        parents = set(dataset.parent_ids[ordered].astype(str))
        if len(parents) != 1:
            raise ValueError("an event contains candidates from multiple parents")
        event_rows.append(
            {
                "row_type": "EVENT",
                "fold_index": fold_by_event[event_id],
                "event_id": event_id,
                "parent_id": next(iter(parents)),
                "evaluable_candidate_n": len(ordered),
                "mlp_ndcg5": float(metrics["ndcg5"]),
                "mlp_event_spearman": float(metrics["spearman"]),
                "mlp_pairwise_accuracy": float(metrics["pairwise_accuracy"]),
                "mlp_top1_candidate_id": str(candidate_ids[mlp_local]),
                "mlp_top1_prediction_log1p_force": float(event_scores[mlp_local]),
                "mlp_top1_force": mlp_force,
                "random_top1_candidate_id": str(candidate_ids[random_local]),
                "random_top1_force": random_force,
                "contact_top1_candidate_id": str(candidate_ids[contact_local]),
                "contact_top1_force": contact_force,
                "parent_oracle_force": float(
                    dataset.parent_oracle_force_by_event[event_id]
                ),
                "mlp_minus_random_log1p_force": float(
                    math.log1p(mlp_force) - math.log1p(random_force)
                ),
                "mlp_minus_contact_log1p_force": float(
                    math.log1p(mlp_force) - math.log1p(contact_force)
                ),
            }
        )

    fold_rows = []
    for fold_index in range(4):
        rows = [row for row in event_rows if row["fold_index"] == fold_index]
        if len(rows) != 16:
            raise AssertionError("held-out fold event count drifted")
        fold_rows.append(
            {
                "row_type": "FOLD_SUMMARY",
                "fold_index": fold_index,
                "held_out_event_n": len(rows),
                "held_out_event_ids": [row["event_id"] for row in rows],
                "mlp_ndcg5": float(np.mean([row["mlp_ndcg5"] for row in rows])),
                "mlp_event_spearman": float(
                    np.mean([row["mlp_event_spearman"] for row in rows])
                ),
                "mlp_pairwise_accuracy": float(
                    np.mean([row["mlp_pairwise_accuracy"] for row in rows])
                ),
                "mlp_top1_force_median": float(
                    np.median([row["mlp_top1_force"] for row in rows])
                ),
                "random_top1_force_median": float(
                    np.median([row["random_top1_force"] for row in rows])
                ),
                "contact_top1_force_median": float(
                    np.median([row["contact_top1_force"] for row in rows])
                ),
                "parent_oracle_force_median": float(
                    np.median([row["parent_oracle_force"] for row in rows])
                ),
                "mlp_vs_random_mean_delta": float(
                    np.mean([row["mlp_minus_random_log1p_force"] for row in rows])
                ),
                "mlp_vs_contact_mean_delta": float(
                    np.mean([row["mlp_minus_contact_log1p_force"] for row in rows])
                ),
                "mlp_win_rate_vs_random": float(
                    np.mean(
                        [
                            row["mlp_top1_force"] < row["random_top1_force"]
                            for row in rows
                        ]
                    )
                ),
                "mlp_win_rate_vs_contact": float(
                    np.mean(
                        [
                            row["mlp_top1_force"] < row["contact_top1_force"]
                            for row in rows
                        ]
                    )
                ),
            }
        )

    mlp_force = np.asarray([row["mlp_top1_force"] for row in event_rows], dtype=float)
    random_force = np.asarray(
        [row["random_top1_force"] for row in event_rows], dtype=float
    )
    contact_force = np.asarray(
        [row["contact_top1_force"] for row in event_rows], dtype=float
    )
    mlp_vs_random = paired_bootstrap(
        mlp_force,
        random_force,
        resamples=bootstrap_resamples,
        seed=BOOTSTRAP_SEED,
    )
    mlp_vs_contact = paired_bootstrap(
        mlp_force,
        contact_force,
        resamples=bootstrap_resamples,
        seed=BOOTSTRAP_SEED,
    )
    aggregate = {
        "mlp_ndcg5": float(np.mean([row["mlp_ndcg5"] for row in event_rows])),
        "mlp_event_spearman": float(
            np.mean([row["mlp_event_spearman"] for row in event_rows])
        ),
        "mlp_pairwise_accuracy": float(
            np.mean([row["mlp_pairwise_accuracy"] for row in event_rows])
        ),
        "mlp_top1_force_median": float(np.median(mlp_force)),
        "random_top1_force_median": float(np.median(random_force)),
        "contact_top1_force_median": float(np.median(contact_force)),
        "parent_oracle_force_median": float(
            np.median([row["parent_oracle_force"] for row in event_rows])
        ),
    }
    return {
        "event_rows": event_rows,
        "fold_rows": fold_rows,
        "aggregate": aggregate,
        "mlp_vs_random": mlp_vs_random,
        "mlp_vs_contact": mlp_vs_contact,
    }


def _registered_model_seed(label: str) -> int:
    return int(
        hashlib.sha256(f"20260902:full-orbit-mlp:{label}".encode()).hexdigest()[:8],
        16,
    )


def train_cross_validation(
    dataset: OperatorDataset,
    *,
    device: str,
    deadline: float | None = None,
    updates: int = MAX_UPDATES,
) -> dict[str, object]:
    folds = stable_event_folds(dataset.source_event_ids)
    oof = np.full(dataset.evaluable_sample_n, np.nan, dtype=float)
    fold_training_rows = []
    all_events = set(dataset.source_event_ids)
    for fold_index, held_out_tuple in enumerate(folds):
        if deadline is not None and time.monotonic() >= deadline:
            raise TimeoutError("full-orbit operator reached the total deadline")
        held_out_events = set(held_out_tuple)
        train_events = all_events - held_out_events
        test_mask = np.isin(dataset.event_ids, list(held_out_events))
        train_indices = np.flatnonzero(~test_mask)
        test_indices = np.flatnonzero(test_mask)
        train_parent_ids = sorted(set(dataset.parent_ids[train_indices].astype(str)))
        held_out_parent_ids = sorted(set(dataset.parent_ids[test_indices].astype(str)))
        if len(train_events) != 48 or len(held_out_events) != 16:
            raise AssertionError("event fold sizes drifted")
        if len(train_parent_ids) != 48 or len(held_out_parent_ids) != 16:
            raise AssertionError("parent fold sizes drifted")
        if set(train_parent_ids) & set(held_out_parent_ids):
            raise AssertionError("parent leakage detected between train and held-out")

        seed = _registered_model_seed(f"fold-{fold_index}")
        fitted = fit_fold_model(
            x_train=dataset.features[train_indices],
            y_train=dataset.target[train_indices],
            x_test=dataset.features[test_indices],
            device=device,
            seed=seed,
            deadline=deadline,
            updates=updates,
        )
        oof[test_indices] = np.asarray(fitted["prediction"], dtype=float)
        fold_training_rows.append(
            {
                "row_type": "FOLD_TRAINING",
                "fold_index": fold_index,
                "train_event_n": len(train_events),
                "held_out_event_n": len(held_out_events),
                "train_parent_n": len(train_parent_ids),
                "held_out_parent_n": len(held_out_parent_ids),
                "train_sample_n": len(train_indices),
                "held_out_sample_n": len(test_indices),
                "train_event_ids": sorted(train_events),
                "held_out_event_ids": sorted(held_out_events),
                "train_parent_ids": train_parent_ids,
                "held_out_parent_ids": held_out_parent_ids,
                "model_seed": seed,
                "model_parameter_n": trainable_parameter_count(fitted["model"]),
                "final_training_loss": float(fitted["final_training_loss"]),
            }
        )
    if not np.isfinite(oof).all():
        raise RuntimeError("OOF predictions are incomplete")
    return {
        "folds": folds,
        "oof_prediction": oof,
        "fold_training_rows": fold_training_rows,
    }


def fit_full_development(
    dataset: OperatorDataset,
    *,
    device: str,
    deadline: float | None = None,
    updates: int = MAX_UPDATES,
) -> dict[str, object]:
    if deadline is not None and time.monotonic() >= deadline:
        raise TimeoutError("full-orbit operator reached the total deadline")
    sanity_n = min(64, dataset.evaluable_sample_n)
    seed = _registered_model_seed("full-development")
    fitted = fit_fold_model(
        x_train=dataset.features,
        y_train=dataset.target,
        x_test=dataset.features[:sanity_n],
        device=device,
        seed=seed,
        deadline=deadline,
        updates=updates,
    )
    return {
        "model": fitted["model"],
        "normalization": fitted["normalization"],
        "final_training_loss": float(fitted["final_training_loss"]),
        "training_sample_n": dataset.evaluable_sample_n,
        "model_parameter_n": trainable_parameter_count(fitted["model"]),
        "model_seed": seed,
        "sanity_candidate_ids": dataset.candidate_ids[:sanity_n].tolist(),
        "sanity_prediction": np.asarray(fitted["prediction"], dtype=float),
    }


def stable_event_folds(
    event_ids: Sequence[str], *, seed: int = FOLD_SEED
) -> tuple[tuple[str, ...], ...]:
    values = [str(value) for value in event_ids]
    if len(values) != 64 or len(set(values)) != 64:
        raise ValueError("fixed four-fold CV requires 64 unique events")
    ordered = sorted(
        values,
        key=lambda event_id: (
            hashlib.sha256(f"{seed}:full-orbit-fold:{event_id}".encode()).hexdigest(),
            event_id,
        ),
    )
    folds = tuple(tuple(ordered[index::4]) for index in range(4))
    if tuple(map(len, folds)) != (16, 16, 16, 16):
        raise AssertionError("event fold construction drifted")
    return folds


def event_ranking_metrics(
    *, force: np.ndarray, prediction: np.ndarray, k: int = 5
) -> dict[str, float | int]:
    truth = np.asarray(force, dtype=float)
    score = np.asarray(prediction, dtype=float)
    if len(truth) == 0 or len(truth) != len(score):
        raise ValueError("ranking arrays must have the same positive length")
    if not np.isfinite(truth).all() or not np.isfinite(score).all():
        raise ValueError("ranking arrays must be finite")
    if np.any(truth < 0.0):
        raise ValueError("force values must be nonnegative")
    if k <= 0:
        raise ValueError("ranking cutoff must be positive")

    target = np.log1p(truth)
    relevance = float(np.max(target)) - target
    selected = np.argsort(score, kind="stable")[: min(k, len(truth))]
    ideal = np.argsort(target, kind="stable")[: min(k, len(truth))]

    def dcg(indices: np.ndarray) -> float:
        gains = np.exp2(relevance[indices]) - 1.0
        discounts = np.log2(np.arange(2, len(indices) + 2, dtype=float))
        return float(np.sum(gains / discounts))

    ideal_dcg = dcg(ideal)
    ndcg = dcg(selected) / ideal_dcg if ideal_dcg > 0.0 else 1.0
    correlation = float(spearmanr(score, target).statistic)
    if not math.isfinite(correlation):
        correlation = 0.0

    left, right = np.triu_indices(len(truth), k=1)
    true_difference = target[left] - target[right]
    predicted_difference = score[left] - score[right]
    informative = np.abs(true_difference) > 1e-12
    products = true_difference[informative] * predicted_difference[informative]
    pairwise = (
        float(
            np.mean(
                np.where(
                    products > 0.0,
                    1.0,
                    np.where(products == 0.0, 0.5, 0.0),
                )
            )
        )
        if products.size
        else 1.0
    )
    top1 = int(np.argmin(score))
    return {
        "ndcg5": float(ndcg),
        "spearman": correlation,
        "pairwise_accuracy": pairwise,
        "top1_index": top1,
        "top1_force": float(truth[top1]),
    }


def paired_bootstrap(
    mlp_force: np.ndarray,
    baseline_force: np.ndarray,
    *,
    resamples: int = 10_000,
    seed: int = BOOTSTRAP_SEED,
) -> dict[str, float | int]:
    mlp = np.asarray(mlp_force, dtype=float)
    baseline = np.asarray(baseline_force, dtype=float)
    if len(mlp) == 0 or len(mlp) != len(baseline):
        raise ValueError("paired force arrays must have the same positive length")
    if not np.isfinite(mlp).all() or not np.isfinite(baseline).all():
        raise ValueError("paired force arrays must be finite")
    if np.any(mlp < 0.0) or np.any(baseline < 0.0):
        raise ValueError("paired force arrays must be nonnegative")
    if resamples <= 0:
        raise ValueError("bootstrap resamples must be positive")

    delta = np.log1p(mlp) - np.log1p(baseline)
    generator = np.random.default_rng(int(seed))
    indices = generator.integers(0, len(delta), size=(resamples, len(delta)))
    means = np.mean(delta[indices], axis=1)
    lower, upper = np.percentile(means, [2.5, 97.5])
    return {
        "mean_delta": float(np.mean(delta)),
        "ci_lower": float(lower),
        "ci_upper": float(upper),
        "win_rate": float(np.mean(mlp < baseline)),
        "resamples": int(resamples),
    }


def operator_verdict(
    *,
    ndcg5: float,
    random_ci_upper: float,
    mlp_top1_force_median: float,
    contact_top1_force_median: float,
    fold_random_mean_deltas: Sequence[float],
    parent_dependent_input_n: int,
) -> dict[str, object]:
    fold_deltas = [float(value) for value in fold_random_mean_deltas]
    if len(fold_deltas) != 4 or not np.isfinite(fold_deltas).all():
        raise ValueError("verdict requires four finite fold deltas")
    directional_fold_n = sum(value < 0.0 for value in fold_deltas)
    conditions = {
        "ndcg5_at_least_0_75": float(ndcg5) >= 0.75,
        "random_ci_upper_below_zero": float(random_ci_upper) < 0.0,
        "mlp_median_below_contact": float(mlp_top1_force_median)
        < float(contact_top1_force_median),
        "random_direction_better_at_least_3_folds": directional_fold_n >= 3,
        "parent_dependent_input_n_zero": int(parent_dependent_input_n) == 0,
    }
    supported = all(conditions.values())
    return {
        "status": "SUPPORTED" if supported else "NOT_SUPPORTED",
        "conditions": conditions,
        "random_better_fold_n": directional_fold_n,
        "full_development_refit": supported,
        "next_action": (
            "EARLY_MID_LATE_COMPATIBILITY_GENERALIZATION"
            if supported
            else "DESIGN_BETTER_FULL_ORBIT_REPRESENTATION"
        ),
    }


__all__ = [
    "BOOTSTRAP_SEED",
    "FOLD_SEED",
    "FullOrbitCompatibilityMLP",
    "OperatorDataset",
    "REGISTERED_FEATURE_NAMES",
    "audit_parent_free_schema",
    "build_operator_dataset",
    "event_ranking_metrics",
    "evaluate_oof_predictions",
    "fit_fold_model",
    "fit_full_development",
    "operator_verdict",
    "paired_bootstrap",
    "stable_event_folds",
    "stable_random_candidate_index",
    "train_cross_validation",
    "trainable_parameter_count",
]
