from __future__ import annotations

import hashlib
import json
import math
import os
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from statistics import median
from typing import Any, Callable, Mapping

import torch

from crysalis_g1.experiments.local_pilot_data import (
    AssemblyExampleKey,
    AssemblyTrainingBatch,
    FrozenPhase2ACorpus,
)
from crysalis_g1.model.local_pilot_model import (
    PilotLossScales,
    UnifiedLocalPilotModel,
    compute_pilot_losses,
)


def derive_named_seed(root_seed: int, stream_name: str) -> int:
    if not stream_name:
        raise ValueError("RNG stream name must not be empty")
    return int.from_bytes(
        hashlib.sha256(f"g1-rng:{root_seed}:{stream_name}".encode()).digest()[:8],
        "big",
    ) % (2**31 - 1)


def state_dict_sha256(state: Mapping[str, torch.Tensor]) -> str:
    digest = hashlib.sha256()
    for name in sorted(state):
        tensor = state[name].detach().cpu().contiguous()
        digest.update(name.encode())
        digest.update(str(tensor.dtype).encode())
        digest.update(str(tuple(tensor.shape)).encode())
        digest.update(tensor.numpy().tobytes())
    return digest.hexdigest()


def common_non_geometry_state(
    model: UnifiedLocalPilotModel,
) -> dict[str, torch.Tensor]:
    prefix = "periodic_equivariant_geometry_generator."
    return {
        name: tensor.detach().clone()
        for name, tensor in model.state_dict().items()
        if not name.startswith(prefix)
    }


@dataclass(frozen=True, slots=True)
class TrainingLoopConfig:
    root_seed: int
    stream_name: str
    device: str
    batch_size: int
    gradient_accumulation_steps: int
    mixed_precision: bool
    learning_rate: float
    weight_decay: float
    gradient_clip_norm: float
    maximum_updates: int
    minimum_updates: int
    validation_interval: int
    checkpoint_interval: int
    early_stopping_patience: int
    validation_batches: int

    def __post_init__(self) -> None:
        if self.root_seed != 20260823:
            raise ValueError("training root seed must remain 20260823")
        if not self.stream_name:
            raise ValueError("training RNG stream must be named")
        if self.device not in {"cpu", "cuda"}:
            raise ValueError("training device must be cpu or cuda")
        positive_ints = (
            self.batch_size,
            self.gradient_accumulation_steps,
            self.maximum_updates,
            self.minimum_updates,
            self.validation_interval,
            self.checkpoint_interval,
            self.early_stopping_patience,
            self.validation_batches,
        )
        if any(type(value) is not int or value <= 0 for value in positive_ints):
            raise ValueError("training counts must be positive integers")
        if self.minimum_updates > self.maximum_updates:
            raise ValueError("minimum updates cannot exceed maximum updates")
        if self.mixed_precision and self.device != "cuda":
            raise ValueError("mixed precision requires CUDA")
        if self.learning_rate <= 0 or self.weight_decay < 0:
            raise ValueError("optimizer values are invalid")
        if self.gradient_clip_norm <= 0:
            raise ValueError("gradient clip norm must be positive")

    def sha256(self) -> str:
        encoded = json.dumps(
            asdict(self), separators=(",", ":"), sort_keys=True
        ).encode()
        return hashlib.sha256(encoded).hexdigest()


class _CorpusSampler:
    def __init__(
        self,
        corpus: FrozenPhase2ACorpus,
        keys: tuple[AssemblyExampleKey, ...],
        *,
        seed: int,
    ) -> None:
        if not keys:
            raise ValueError("training sampler keys must not be empty")
        self.corpus = corpus
        self.keys = keys
        self.generator = torch.Generator().manual_seed(seed)
        self.cursor = 0

    def batch(self, batch_size: int) -> AssemblyTrainingBatch:
        indices = torch.randint(
            len(self.keys), (batch_size,), generator=self.generator
        ).tolist()
        self.cursor += batch_size
        return self.corpus.collate(self.keys[index] for index in indices)

    def state_dict(self) -> dict[str, Any]:
        return {
            "generator_state": self.generator.get_state(),
            "cursor": self.cursor,
        }


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _write_json(path: Path, payload: object) -> None:
    path.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            allow_nan=False,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


def _gradient_finite(model: torch.nn.Module) -> bool:
    return all(
        parameter.grad is None or bool(torch.isfinite(parameter.grad).all())
        for parameter in model.parameters()
    )


def _synchronize(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)


def _checkpoint(
    path: Path,
    *,
    model: UnifiedLocalPilotModel,
    optimizer: torch.optim.Optimizer,
    scheduler: torch.optim.lr_scheduler.LRScheduler,
    scaler: torch.amp.GradScaler,
    sampler: _CorpusSampler,
    completed_updates: int,
    config: TrainingLoopConfig,
    code_sha256: str,
    phase2a_manifest_sha256: str,
    common_initialization_sha256: str,
    validation_objective: float | None,
) -> str:
    if path.exists():
        raise FileExistsError(f"checkpoint refuses to overwrite: {path}")
    temporary = path.with_suffix(path.suffix + ".tmp")
    payload = {
        "schema_version": "g1-local-pilot-checkpoint.1.0.0",
        "arm_id": model.config.arm_id,
        "geometry_backend": model.config.geometry.backend,
        "root_seed": config.root_seed,
        "stream_name": config.stream_name,
        "stream_seed": derive_named_seed(config.root_seed, config.stream_name),
        "completed_updates": completed_updates,
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "scheduler_state_dict": scheduler.state_dict(),
        "scaler_state_dict": scaler.state_dict(),
        "sampler_state_dict": sampler.state_dict(),
        "torch_rng_state": torch.get_rng_state(),
        "cuda_rng_state": (
            torch.cuda.get_rng_state_all() if torch.cuda.is_available() else []
        ),
        "training_config": asdict(config),
        "training_config_sha256": config.sha256(),
        "code_sha256": code_sha256,
        "phase2a_manifest_sha256": phase2a_manifest_sha256,
        "common_initialization_sha256": common_initialization_sha256,
        "validation_objective": validation_objective,
        "parent_checkpoint": None if completed_updates == 0 else "update-0.pt",
        "no_refill": True,
        "three_seed_authorized": False,
        "server_deployment_authorized": False,
    }
    torch.save(payload, temporary)
    os.replace(temporary, path)
    return _sha256(path)


def _validate(
    *,
    model: UnifiedLocalPilotModel,
    corpus: FrozenPhase2ACorpus,
    keys: tuple[AssemblyExampleKey, ...],
    config: TrainingLoopConfig,
    loss_scales: PilotLossScales,
    device: torch.device,
) -> tuple[float, dict[str, float]]:
    sampler = _CorpusSampler(
        corpus,
        keys,
        seed=derive_named_seed(
            config.root_seed, "assembly:shared-validation-batch-schedule"
        ),
    )
    totals: dict[str, float] = {}
    objective = 0.0
    model.eval()
    with torch.no_grad():
        for _ in range(config.validation_batches):
            batch = sampler.batch(config.batch_size).to(device)
            with torch.autocast(
                device_type=device.type,
                dtype=torch.float16,
                enabled=config.mixed_precision,
            ):
                losses = compute_pilot_losses(model(batch), batch, loss_scales)
            objective += float(losses.validation_objective.detach())
            for name, value in losses.components.items():
                totals[name] = totals.get(name, 0.0) + float(value.detach())
    model.train()
    divisor = config.validation_batches
    return objective / divisor, {
        name: value / divisor for name, value in totals.items()
    }


def derive_training_loss_scales(
    *,
    model: UnifiedLocalPilotModel,
    corpus: FrozenPhase2ACorpus,
    train_keys: tuple[AssemblyExampleKey, ...],
    root_seed: int,
    batch_size: int,
    batch_count: int,
    device_name: str,
    mixed_precision: bool,
) -> tuple[PilotLossScales, dict[str, Any]]:
    """Freeze objective scales from deterministic train-only initial losses."""
    if root_seed != 20260823:
        raise ValueError("loss-scale root seed must remain 20260823")
    if batch_size <= 0 or batch_count <= 0:
        raise ValueError("loss-scale batch counts must be positive")
    device = torch.device(device_name)
    if mixed_precision and device.type != "cuda":
        raise ValueError("mixed-precision loss-scale audit requires CUDA")
    sampler = _CorpusSampler(
        corpus,
        train_keys,
        seed=derive_named_seed(
            root_seed, "assembly:train-only-loss-scale-schedule"
        ),
    )
    component_values: dict[str, list[float]] = {}
    schedule_digest = hashlib.sha256()
    model = model.to(device).eval()
    with torch.no_grad():
        for _ in range(batch_count):
            batch = sampler.batch(batch_size)
            for example_id in batch.example_ids:
                schedule_digest.update(example_id.encode())
            batch = batch.to(device)
            with torch.autocast(
                device_type=device.type,
                dtype=torch.float16,
                enabled=mixed_precision,
            ):
                losses = compute_pilot_losses(
                    model(batch), batch, PilotLossScales.unit()
                )
            for name, value in losses.components.items():
                scalar = float(value.detach())
                if not math.isfinite(scalar):
                    raise FloatingPointError(
                        f"non-finite train-only loss scale for {name}"
                    )
                component_values.setdefault(name, []).append(scalar)
    model.train()
    medians = {
        name: max(median(values), 1e-6)
        for name, values in component_values.items()
    }
    scales = PilotLossScales(**medians)
    report = {
        "schema_version": "g1-train-only-loss-scales.1.0.0",
        "method": "MEDIAN_RAW_INITIAL_LOSS_ON_FROZEN_TRAIN_BATCHES",
        "root_seed": root_seed,
        "batch_size": batch_size,
        "batch_count": batch_count,
        "example_count": batch_size * batch_count,
        "schedule_stream": "assembly:train-only-loss-scale-schedule",
        "schedule_sha256": schedule_digest.hexdigest(),
        "scales": asdict(scales),
        "validation_or_test_labels_used": False,
        "chgnet_used": False,
    }
    return scales, report


def run_training(
    *,
    model: UnifiedLocalPilotModel,
    corpus: FrozenPhase2ACorpus,
    train_keys: tuple[AssemblyExampleKey, ...],
    validation_keys: tuple[AssemblyExampleKey, ...],
    loss_scales: PilotLossScales,
    config: TrainingLoopConfig,
    output_dir: str | Path,
    code_sha256: str,
    phase2a_manifest_sha256: str,
    common_initialization_sha256: str,
    progress_callback: Callable[[int, str | None], None] | None = None,
    progress_interval: int = 50,
) -> dict[str, Any]:
    output_dir = Path(output_dir)
    if progress_interval <= 0:
        raise ValueError("training progress interval must be positive")
    if output_dir.exists():
        raise FileExistsError(f"training output refuses to overwrite: {output_dir}")
    checkpoints_dir = output_dir / "checkpoints"
    checkpoints_dir.mkdir(parents=True)
    if config.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA training requested but CUDA is unavailable")
    stream_seed = derive_named_seed(config.root_seed, config.stream_name)
    torch.manual_seed(stream_seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(stream_seed)
    device = torch.device(config.device)
    model = model.to(device).train()
    parameters = tuple(parameter for parameter in model.parameters() if parameter.requires_grad)
    optimizer = torch.optim.AdamW(
        parameters,
        lr=config.learning_rate,
        weight_decay=config.weight_decay,
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=config.maximum_updates
    )
    scaler = torch.amp.GradScaler(
        "cuda",
        enabled=config.mixed_precision,
        init_scale=1024.0,
        growth_interval=1_000_000_000,
    )
    sampler = _CorpusSampler(
        corpus,
        train_keys,
        seed=derive_named_seed(
            config.root_seed, "assembly:shared-training-batch-schedule"
        ),
    )
    checkpoint_hashes: dict[str, str] = {}
    checkpoint_hashes["update-0.pt"] = _checkpoint(
        checkpoints_dir / "update-0.pt",
        model=model,
        optimizer=optimizer,
        scheduler=scheduler,
        scaler=scaler,
        sampler=sampler,
        completed_updates=0,
        config=config,
        code_sha256=code_sha256,
        phase2a_manifest_sha256=phase2a_manifest_sha256,
        common_initialization_sha256=common_initialization_sha256,
        validation_objective=None,
    )
    metrics_path = output_dir / "metrics.jsonl"
    latencies: list[float] = []
    data_wait_seconds = 0.0
    best_validation = math.inf
    best_update = 0
    evaluations_without_improvement = 0
    completed_updates = 0
    stopped_early = False
    schedule_digest = hashlib.sha256()
    started = time.perf_counter()
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    with metrics_path.open("x", encoding="utf-8") as metrics:
        for update in range(1, config.maximum_updates + 1):
            update_started = time.perf_counter()
            optimizer.zero_grad(set_to_none=True)
            component_sums: dict[str, float] = {}
            train_objective = 0.0
            for _ in range(config.gradient_accumulation_steps):
                data_started = time.perf_counter()
                batch = sampler.batch(config.batch_size)
                data_wait_seconds += time.perf_counter() - data_started
                for example_id in batch.example_ids:
                    schedule_digest.update(example_id.encode())
                batch = batch.to(device)
                with torch.autocast(
                    device_type=device.type,
                    dtype=torch.float16,
                    enabled=config.mixed_precision,
                ):
                    losses = compute_pilot_losses(model(batch), batch, loss_scales)
                    scaled_loss = (
                        losses.validation_objective
                        / config.gradient_accumulation_steps
                    )
                if not bool(torch.isfinite(scaled_loss)):
                    raise FloatingPointError(
                        f"non-finite training loss at update {update}"
                    )
                scaler.scale(scaled_loss).backward()
                train_objective += float(losses.validation_objective.detach())
                for name, value in losses.components.items():
                    component_sums[name] = component_sums.get(name, 0.0) + float(
                        value.detach()
                    )
            scaler.unscale_(optimizer)
            if not _gradient_finite(model):
                raise FloatingPointError(
                    f"non-finite training gradient at update {update}"
                )
            gradient_norm = float(
                torch.nn.utils.clip_grad_norm_(parameters, config.gradient_clip_norm)
            )
            previous_scale = scaler.get_scale()
            scaler.step(optimizer)
            scaler.update()
            if scaler.get_scale() < previous_scale:
                raise FloatingPointError(
                    f"mixed-precision optimizer step skipped at update {update}"
                )
            scheduler.step()
            _synchronize(device)
            latency = time.perf_counter() - update_started
            latencies.append(latency)
            completed_updates = update
            record: dict[str, Any] = {
                "update": update,
                "train_validation_objective": train_objective
                / config.gradient_accumulation_steps,
                "gradient_norm_before_clip": gradient_norm,
                "learning_rate": scheduler.get_last_lr()[0],
                "latency_seconds": latency,
                "sampler_cursor": sampler.cursor,
                "finite": True,
                **{
                    name: value / config.gradient_accumulation_steps
                    for name, value in component_sums.items()
                },
            }
            validation_objective: float | None = None
            if update % config.validation_interval == 0 or update == config.maximum_updates:
                validation_objective, validation_components = _validate(
                    model=model,
                    corpus=corpus,
                    keys=validation_keys,
                    config=config,
                    loss_scales=loss_scales,
                    device=device,
                )
                if not math.isfinite(validation_objective):
                    raise FloatingPointError(
                        f"non-finite validation objective at update {update}"
                    )
                record["validation_objective"] = validation_objective
                record["validation_components"] = validation_components
                if validation_objective < best_validation - 1e-12:
                    best_validation = validation_objective
                    best_update = update
                    evaluations_without_improvement = 0
                else:
                    evaluations_without_improvement += 1
            should_checkpoint = (
                update % config.checkpoint_interval == 0
                or update == config.maximum_updates
                or (validation_objective is not None and update == best_update)
            )
            if should_checkpoint:
                name = f"update-{update}.pt"
                if name not in checkpoint_hashes:
                    checkpoint_hashes[name] = _checkpoint(
                        checkpoints_dir / name,
                        model=model,
                        optimizer=optimizer,
                        scheduler=scheduler,
                        scaler=scaler,
                        sampler=sampler,
                        completed_updates=update,
                        config=config,
                        code_sha256=code_sha256,
                        phase2a_manifest_sha256=phase2a_manifest_sha256,
                        common_initialization_sha256=common_initialization_sha256,
                        validation_objective=validation_objective,
                    )
            if progress_callback is not None and (
                update % progress_interval == 0
                or update == config.maximum_updates
            ):
                checkpoint_name = (
                    f"update-{update}.pt"
                    if f"update-{update}.pt" in checkpoint_hashes
                    else None
                )
                progress_callback(update, checkpoint_name)
            metrics.write(
                json.dumps(
                    record,
                    ensure_ascii=False,
                    allow_nan=False,
                    separators=(",", ":"),
                    sort_keys=True,
                )
                + "\n"
            )
            metrics.flush()
            os.fsync(metrics.fileno())
            if (
                update >= config.minimum_updates
                and evaluations_without_improvement
                >= config.early_stopping_patience
            ):
                stopped_early = True
                break
    final_name = f"update-{completed_updates}.pt"
    if final_name not in checkpoint_hashes:
        checkpoint_hashes[final_name] = _checkpoint(
            checkpoints_dir / final_name,
            model=model,
            optimizer=optimizer,
            scheduler=scheduler,
            scaler=scaler,
            sampler=sampler,
            completed_updates=completed_updates,
            config=config,
            code_sha256=code_sha256,
            phase2a_manifest_sha256=phase2a_manifest_sha256,
            common_initialization_sha256=common_initialization_sha256,
            validation_objective=(
                best_validation if math.isfinite(best_validation) else None
            ),
        )
    wall_seconds = time.perf_counter() - started
    sorted_latencies = sorted(latencies)
    p95_index = min(
        len(sorted_latencies) - 1,
        max(0, math.ceil(0.95 * len(sorted_latencies)) - 1),
    )
    result = {
        "status": "PASS",
        "arm_id": model.config.arm_id,
        "geometry_backend": model.config.geometry.backend,
        "root_seed": config.root_seed,
        "stream_name": config.stream_name,
        "stream_seed": stream_seed,
        "training_batch_schedule_stream": "assembly:shared-training-batch-schedule",
        "validation_batch_schedule_stream": "assembly:shared-validation-batch-schedule",
        "completed_updates": completed_updates,
        "minimum_updates": config.minimum_updates,
        "maximum_updates": config.maximum_updates,
        "stopped_early": stopped_early,
        "best_validation_update": best_update,
        "best_validation_objective": (
            best_validation if math.isfinite(best_validation) else None
        ),
        "all_finite": True,
        "refill_count": 0,
        "wall_seconds": wall_seconds,
        "updates_per_second": completed_updates / max(wall_seconds, 1e-12),
        "update_latency_p50_seconds": median(sorted_latencies),
        "update_latency_p95_seconds": sorted_latencies[p95_index],
        "data_wait_seconds": data_wait_seconds,
        "peak_allocated_vram_bytes": (
            int(torch.cuda.max_memory_allocated(device))
            if device.type == "cuda"
            else 0
        ),
        "peak_reserved_vram_bytes": (
            int(torch.cuda.max_memory_reserved(device))
            if device.type == "cuda"
            else 0
        ),
        "trainable_parameter_count": model.trainable_parameter_count(),
        "schedule_sha256": schedule_digest.hexdigest(),
        "training_config_sha256": config.sha256(),
        "metrics_sha256": _sha256(metrics_path),
        "checkpoint_sha256": checkpoint_hashes,
        "phase2a_manifest_sha256": phase2a_manifest_sha256,
        "common_initialization_sha256": common_initialization_sha256,
        "server_deployment_authorized": False,
        "three_seed_authorized": False,
    }
    _write_json(output_dir / "training_summary.json", result)
    return result
