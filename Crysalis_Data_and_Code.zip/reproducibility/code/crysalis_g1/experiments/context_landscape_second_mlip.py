from __future__ import annotations

import hashlib
from collections import defaultdict
from collections.abc import Mapping, Sequence

import numpy as np
from scipy.stats import spearmanr


STAGES = ("EARLY", "MID", "LATE", "TERMINAL")
ARMS = ("CONTEXT", "ORBIT_ONLY", "CONTACT", "REFERENCE")


def _truth(value: object) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes"}


def delta_distribution(values: Sequence[float]) -> dict[str, float]:
    array = np.asarray(values, dtype=float)
    if array.ndim != 1 or not len(array) or not np.isfinite(array).all():
        raise ValueError("delta distribution requires finite one-dimensional values")
    quantiles = np.quantile(array, [0.10, 0.25, 0.50, 0.75, 0.90, 0.95])
    return {
        "n": float(len(array)),
        "mean": float(np.mean(array)),
        "median": float(np.median(array)),
        "p10": float(quantiles[0]),
        "p25": float(quantiles[1]),
        "p50": float(quantiles[2]),
        "p75": float(quantiles[3]),
        "p90": float(quantiles[4]),
        "p95": float(quantiles[5]),
        "fraction_lt_0": float(np.mean(array < 0.0)),
        "fraction_lt_neg_0_25": float(np.mean(array < -0.25)),
        "fraction_lt_neg_0_50": float(np.mean(array < -0.50)),
        "fraction_gt_pos_0_25": float(np.mean(array > 0.25)),
        "fraction_gt_pos_0_50": float(np.mean(array > 0.50)),
    }


def rank_quartile_labels(
    forces: Sequence[float], event_ids: Sequence[str]
) -> dict[str, str]:
    if len(forces) != len(event_ids) or not forces or len(forces) % 4:
        raise ValueError("rank quartiles require aligned data divisible by four")
    if len(set(map(str, event_ids))) != len(event_ids):
        raise ValueError("event identities must be unique")
    ordered = sorted(
        zip(map(float, forces), map(str, event_ids), strict=True),
        key=lambda item: (item[0], item[1]),
    )
    quartile_n = len(ordered) // 4
    return {
        event_id: f"Q{index // quartile_n + 1}"
        for index, (_, event_id) in enumerate(ordered)
    }


def context_effect_mechanism(
    quartiles: Mapping[str, Mapping[str, float]],
    stages: Mapping[str, Mapping[str, float]],
) -> str:
    required_quartiles = {"Q1", "Q2", "Q3", "Q4"}
    required_stages = set(STAGES)
    if set(quartiles) != required_quartiles or set(stages) != required_stages:
        raise ValueError("mechanism classification requires four quartiles and stages")
    q4 = float(quartiles["Q4"]["mean_delta"])
    other = [float(quartiles[name]["mean_delta"]) for name in ("Q1", "Q2", "Q3")]
    if q4 < min(other) and float(quartiles["Q4"]["ci_upper"]) < 0.0:
        return "HIGH_FORCE_TAIL_SUPPRESSION"
    q_means = other + [q4]
    if all(value < 0.0 for value in q_means) and all(
        float(quartiles[name]["ci_upper"]) < 0.0 for name in required_quartiles
    ):
        return "BROAD_SHIFT"
    stage_means = [float(stages[name]["mean_delta"]) for name in STAGES]
    significant = [name for name in STAGES if float(stages[name]["ci_upper"]) < 0.0]
    weakest = min(stage_means)
    remaining = [abs(value) for value in stage_means if value != weakest]
    if 1 <= len(significant) <= 2 and remaining and abs(weakest) >= 1.5 * float(np.median(remaining)):
        return "STAGE_SPECIFIC"
    all_means = q_means + stage_means
    if any(value < 0.0 for value in all_means) and any(value > 0.0 for value in all_means):
        return "MIXED"
    return "NO_CLEAR_STRUCTURE"


def stratified_event_selection(
    rows: Sequence[Mapping[str, object]], *, target_n: int
) -> list[dict[str, object]]:
    if target_n <= 0 or len(rows) < target_n:
        raise ValueError("invalid target event count")
    groups: dict[tuple[int, str], list[Mapping[str, object]]] = defaultdict(list)
    stage_rank = {stage: index for index, stage in enumerate(STAGES)}
    for row in rows:
        stage = str(row["stage"])
        if stage not in stage_rank:
            raise ValueError(f"unknown assembly stage: {stage}")
        groups[(stage_rank[stage], str(row["crystal_system"]))].append(row)
    for values in groups.values():
        values.sort(key=lambda row: (str(row["parent_id"]), str(row["event_id"])))
    selected: list[dict[str, object]] = []
    ordered_keys = sorted(groups)
    depth = 0
    while len(selected) < target_n:
        added = False
        for key in ordered_keys:
            values = groups[key]
            if depth < len(values):
                selected.append(dict(values[depth]))
                added = True
                if len(selected) == target_n:
                    break
        if not added:
            raise RuntimeError("stratified selection exhausted unexpectedly")
        depth += 1
    return selected


def second_mlip_candidate_plan(
    rows: Sequence[Mapping[str, object]],
) -> list[dict[str, object]]:
    by_index = {int(row["candidate_index"]): row for row in rows}
    arm_indices: dict[str, int] = {}
    selectors = {
        "CONTEXT": "context_top1",
        "ORBIT_ONLY": "orbit_only_top1",
        "CONTACT": "contact_top1",
    }
    for arm, field in selectors.items():
        matches = [int(row["candidate_index"]) for row in rows if _truth(row.get(field))]
        if len(matches) != 1:
            raise ValueError(f"{arm} must select exactly one candidate")
        arm_indices[arm] = matches[0]
    arm_indices["REFERENCE"] = 12
    if 12 not in by_index:
        raise ValueError("fixed reference candidate index 12 is absent")
    planned = []
    for index in sorted(set(arm_indices.values())):
        source = by_index[index]
        planned.append(
            {
                **dict(source),
                "arms": tuple(arm for arm in ARMS if arm_indices[arm] == index),
            }
        )
    return planned


def independent_context_verdict(
    *,
    mean_delta: float,
    ci_lower: float,
    ci_upper: float,
    win_rate: float,
    context_median: float,
    orbit_median: float,
) -> str:
    if ci_upper < 0.0 and win_rate >= 0.60 and context_median < orbit_median:
        return "SUPPORTED"
    if mean_delta < 0.0:
        return "INCONCLUSIVE"
    return "NOT_SUPPORTED"


def paired_force_summary(
    context: Sequence[float],
    comparator: Sequence[float],
    *,
    resamples: int = 10_000,
    seed_label: str = "context-orbit",
) -> dict[str, float]:
    left = np.asarray(context, dtype=float)
    right = np.asarray(comparator, dtype=float)
    if left.shape != right.shape or left.ndim != 1 or not len(left):
        raise ValueError("paired force arrays must be nonempty and aligned")
    delta = np.log1p(left) - np.log1p(right)
    seed = int(hashlib.sha256(f"20260902:{seed_label}".encode()).hexdigest()[:8], 16)
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, len(delta), size=(resamples, len(delta)))
    sampled = delta[indices].mean(axis=1)
    return {
        "n": float(len(delta)),
        "context_median": float(np.median(left)),
        "comparator_median": float(np.median(right)),
        "mean_delta": float(np.mean(delta)),
        "median_delta": float(np.median(delta)),
        "ci_lower": float(np.quantile(sampled, 0.025)),
        "ci_upper": float(np.quantile(sampled, 0.975)),
        "win_rate": float(np.mean(left < right)),
    }


def ranking_agreement(rows: Sequence[Mapping[str, object]]) -> dict[str, float]:
    chgnet = np.asarray([float(row["chgnet_force"]) for row in rows], dtype=float)
    second = np.asarray([float(row["second_mlip_force"]) for row in rows], dtype=float)
    overall = float(spearmanr(chgnet, second).statistic)
    by_event: dict[str, list[Mapping[str, object]]] = defaultdict(list)
    for row in rows:
        by_event[str(row["event_id"])].append(row)
    agreements = []
    for values in by_event.values():
        if len(values) < 2:
            continue
        concordant = total = 0
        for left_index in range(len(values)):
            for right_index in range(left_index + 1, len(values)):
                a = float(values[left_index]["chgnet_force"]) - float(values[right_index]["chgnet_force"])
                b = float(values[left_index]["second_mlip_force"]) - float(values[right_index]["second_mlip_force"])
                if a == 0.0 or b == 0.0:
                    concordant += 0.5
                elif a * b > 0.0:
                    concordant += 1.0
                total += 1
        agreements.append(concordant / total)
    return {
        "spearman": overall,
        "within_event_pairwise_agreement": float(np.mean(agreements)),
    }
