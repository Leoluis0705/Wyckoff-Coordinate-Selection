from __future__ import annotations

import hashlib
import math
import random
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import torch

from crysalis_g1.experiments.c0_symmetry_data import (
    C0SymmetryCorpus,
    C0SymmetryExample,
    collate_c0_symmetry_examples,
)
from crysalis_g1.model.c0_symmetry import (
    C0SymmetryConfig,
    C0SymmetryModel,
    compute_c0_symmetry_losses,
)
from crysalis_g1.symmetry.assembly import C0SymmetryProjector, SymmetryAssemblyState


@dataclass(frozen=True, slots=True)
class C0TrainingConfig:
    root_seed: int
    updates: int
    batch_size: int
    validation_interval: int
    validation_batch_size: int
    learning_rate: float
    device: str = "cuda"
    use_amp: bool = True
    weight_decay: float = 1e-5
    gradient_clip_norm: float = 1.0
    maximum_validation_examples: int | None = None
    checkpoint_interval: int = 1000

    def __post_init__(self) -> None:
        if self.updates <= 0 or self.batch_size <= 0:
            raise ValueError("updates and batch_size must be positive")
        if self.validation_interval <= 0 or self.validation_batch_size <= 0:
            raise ValueError("validation intervals and batch sizes must be positive")
        if self.checkpoint_interval <= 0:
            raise ValueError("checkpoint_interval must be positive")
        if not math.isfinite(self.learning_rate) or self.learning_rate <= 0:
            raise ValueError("learning_rate must be finite and positive")


def _seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed % (2**32))
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _state_dict_sha256(model: C0SymmetryModel) -> str:
    digest = hashlib.sha256()
    for name, tensor in sorted(model.state_dict().items()):
        value = tensor.detach().cpu().contiguous()
        digest.update(name.encode("utf-8"))
        digest.update(str(tuple(value.shape)).encode("ascii"))
        digest.update(value.numpy().tobytes())
    return digest.hexdigest()


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _resolve_device(requested: str) -> torch.device:
    if requested == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA training requested but no CUDA device is available")
    return torch.device(requested)


def _validation_losses(
    model: C0SymmetryModel,
    examples: Sequence[C0SymmetryExample],
    *,
    batch_size: int,
    device: torch.device,
    use_amp: bool,
) -> dict[str, float]:
    model.eval()
    weighted: dict[str, float] = {}
    count = 0
    with torch.no_grad():
        for start in range(0, len(examples), batch_size):
            selected = examples[start : start + batch_size]
            orbit_slots = max(1, max(len(example.active_orbits) for example in selected))
            batch = collate_c0_symmetry_examples(
                selected,
                maximum_orbits=min(model.config.maximum_orbits, orbit_slots),
            ).to(device)
            with torch.autocast(
                device_type=device.type,
                dtype=torch.bfloat16,
                enabled=use_amp and device.type == "cuda",
            ):
                losses = compute_c0_symmetry_losses(model(batch), batch)
            for name, loss in losses.items():
                weighted[name] = weighted.get(name, 0.0) + float(
                    loss.detach().cpu()
                ) * len(selected)
            count += len(selected)
    model.train()
    if count == 0:
        raise ValueError("validation split is empty")
    return {name: value / count for name, value in weighted.items()}


def _save_checkpoint(
    path: Path,
    *,
    model: C0SymmetryModel,
    model_config: C0SymmetryConfig,
    training_config: C0TrainingConfig,
    phase: str,
    update: int,
    validation_loss: float,
) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(
        {
            "schema_version": "g1-c0-symmetry-checkpoint.1.0.0",
            "phase": phase,
            "update": update,
            "validation_loss": validation_loss,
            "model_config": asdict(model_config),
            "training_config": asdict(training_config),
            "model_state": model.state_dict(),
            "fresh_initialization": True,
            "old_checkpoint_loaded": False,
        },
        temporary,
    )
    temporary.replace(path)


def _teacher_forced_terminal_sg_rate(
    examples: Sequence[C0SymmetryExample], *, minimum_distance: float = 0.5
) -> tuple[int, float]:
    projector = C0SymmetryProjector(minimum_distance=minimum_distance)
    seen: set[str] = set()
    passed = 0
    total = 0
    for example in examples:
        if not example.terminal or example.material_id in seen:
            continue
        seen.add(example.material_id)
        state = SymmetryAssemblyState(
            target_space_group=example.target_space_group,
            composition=example.composition,
            remaining_composition=(),
            lattice=example.lattice,
            orbits=example.active_orbits,
        )
        receipt = projector.project(state)
        total += 1
        passed += int(
            receipt.accepted
            and receipt.detected_space_groups.get(0.03)
            == example.target_space_group
        )
    return total, passed / total if total else 0.0


def run_c0_symmetry_training(
    corpus: C0SymmetryCorpus,
    *,
    output_directory: str | Path,
    phase: str,
    model_config: C0SymmetryConfig,
    training_config: C0TrainingConfig,
) -> dict[str, Any]:
    if not corpus.train_examples or not corpus.validation_examples:
        raise ValueError("both train_fit and validation examples are required")
    output = Path(output_directory)
    output.mkdir(parents=True, exist_ok=True)
    checkpoint_path = output / f"{phase}_best.pt"
    if checkpoint_path.exists():
        raise FileExistsError(f"refusing to overwrite checkpoint: {checkpoint_path}")
    _seed_everything(training_config.root_seed)
    device = _resolve_device(training_config.device)
    model = C0SymmetryModel(model_config).to(device)
    initial_sha = _state_dict_sha256(model)
    parameter_count = model.trainable_parameter_count()
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=training_config.learning_rate,
        weight_decay=training_config.weight_decay,
    )
    generator = torch.Generator(device="cpu")
    generator.manual_seed(training_config.root_seed)
    validation = corpus.validation_examples
    if training_config.maximum_validation_examples is not None:
        validation = validation[: training_config.maximum_validation_examples]
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    started = time.perf_counter()
    best_validation = math.inf
    best_update = 0
    curve: list[dict[str, float | int]] = []
    model.train()
    for update in range(1, training_config.updates + 1):
        indices = torch.randint(
            len(corpus.train_examples),
            (training_config.batch_size,),
            generator=generator,
        ).tolist()
        examples = tuple(corpus.train_examples[index] for index in indices)
        orbit_slots = max(1, max(len(example.active_orbits) for example in examples))
        batch = collate_c0_symmetry_examples(
            examples, maximum_orbits=min(model_config.maximum_orbits, orbit_slots)
        ).to(device)
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast(
            device_type=device.type,
            dtype=torch.bfloat16,
            enabled=training_config.use_amp and device.type == "cuda",
        ):
            losses = compute_c0_symmetry_losses(model(batch), batch)
        losses["total"].backward()
        gradient_norm = torch.nn.utils.clip_grad_norm_(
            model.parameters(), training_config.gradient_clip_norm
        )
        if not torch.isfinite(gradient_norm):
            raise FloatingPointError(f"non-finite gradient at update {update}")
        optimizer.step()
        should_validate = (
            update == 1
            or update % training_config.validation_interval == 0
            or update % training_config.checkpoint_interval == 0
            or update == training_config.updates
        )
        if should_validate:
            validation_losses = _validation_losses(
                model,
                validation,
                batch_size=training_config.validation_batch_size,
                device=device,
                use_amp=training_config.use_amp,
            )
            validation_loss = validation_losses["total"]
            curve.append(
                {
                    "update": update,
                    "train_loss": float(losses["total"].detach().cpu()),
                    "validation_loss": validation_loss,
                    "gradient_norm": float(gradient_norm.detach().cpu()),
                    **{
                        f"train_{name}_loss": float(value.detach().cpu())
                        for name, value in losses.items()
                        if name != "total"
                    },
                    **{
                        f"validation_{name}_loss": value
                        for name, value in validation_losses.items()
                        if name != "total"
                    },
                }
            )
            if validation_loss < best_validation:
                best_validation = validation_loss
                best_update = update
                _save_checkpoint(
                    checkpoint_path,
                    model=model,
                    model_config=model_config,
                    training_config=training_config,
                    phase=phase,
                    update=update,
                    validation_loss=validation_loss,
                )
            if update % training_config.checkpoint_interval == 0:
                periodic = output / f"{phase}_update_{update:06d}.pt"
                if periodic.exists():
                    raise FileExistsError(
                        f"refusing to overwrite periodic checkpoint: {periodic}"
                    )
                _save_checkpoint(
                    periodic,
                    model=model,
                    model_config=model_config,
                    training_config=training_config,
                    phase=phase,
                    update=update,
                    validation_loss=validation_loss,
                )
    elapsed = time.perf_counter() - started
    peak_vram = (
        int(torch.cuda.max_memory_allocated(device)) if device.type == "cuda" else 0
    )
    teacher_forced_count, teacher_forced_rate = _teacher_forced_terminal_sg_rate(
        validation
    )
    first_action_loss = sum(
        float(curve[0][f"validation_{name}_loss"])
        for name in ("wyckoff", "species", "multiplicity", "free_parameters")
    )
    final_action_loss = sum(
        float(curve[-1][f"validation_{name}_loss"])
        for name in ("wyckoff", "species", "multiplicity", "free_parameters")
    )
    return {
        "schema_version": "g1-c0-symmetry-training.1.0.0",
        "phase": phase,
        "passed": checkpoint_path.is_file() and math.isfinite(best_validation),
        "fresh_initialization": True,
        "old_checkpoint_loaded": False,
        "root_seed": training_config.root_seed,
        "updates_completed": training_config.updates,
        "train_example_count": len(corpus.train_examples),
        "validation_example_count": len(validation),
        "checkpoint_selection_source": "Structure-OOD validation loss",
        "best_validation_loss": best_validation,
        "best_update": best_update,
        "parameter_count": parameter_count,
        "initial_state_sha256": initial_sha,
        "checkpoint_path": str(checkpoint_path.resolve()),
        "checkpoint_sha256": _file_sha256(checkpoint_path),
        "elapsed_seconds": elapsed,
        "updates_per_second": training_config.updates / elapsed,
        "peak_vram_bytes": peak_vram,
        "device": str(device),
        "amp_dtype": (
            "bfloat16"
            if training_config.use_amp and device.type == "cuda"
            else "float32"
        ),
        "finite_forward_backward": True,
        "initial_action_loss": first_action_loss,
        "final_action_loss": final_action_loss,
        "action_loss_decreased": final_action_loss < first_action_loss,
        "teacher_forced_terminal_count": teacher_forced_count,
        "teacher_forced_space_group_preservation_rate": teacher_forced_rate,
        "model_config": asdict(model_config),
        "training_config": asdict(training_config),
        "validation_curve": curve,
    }
