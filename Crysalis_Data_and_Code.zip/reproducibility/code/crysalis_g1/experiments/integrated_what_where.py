from __future__ import annotations

import hashlib
import math
from collections import defaultdict
from collections.abc import Mapping, Sequence, Set

import numpy as np

from crysalis_g1.experiments.physics_aware_orbit import (
    hierarchical_paired_bootstrap,
)

ARM_A = "A_UNIFORM_MDN"
ARM_B = "B_INVERSE_MDN"
ARM_C = "C_UNIFORM_COMPAT"
ARM_D = "D_INVERSE_COMPAT"
ARMS = (ARM_A, ARM_B, ARM_C, ARM_D)


def validate_frozen_policy_metadata(payload: Mapping[str, object]) -> None:
    if (
        payload.get("schema_version") != "orbit-inverse-policy.1.0.0"
        or int(payload.get("update", -1)) != 1500
        or int(payload.get("parameter_count", -1)) != 94241
    ):
        raise RuntimeError("frozen inverse-policy checkpoint drifted")


def deterministic_integrated_parent_sample(
    parents: Sequence[Mapping[str, object]],
    *,
    forbidden_parent_ids: Set[str],
    count: int,
    seed: int,
) -> tuple[str, ...]:
    forbidden = {str(value) for value in forbidden_parent_ids}
    eligible = [row for row in parents if str(row["parent_id"]) not in forbidden]
    parent_ids = [str(row["parent_id"]) for row in eligible]
    if len(parent_ids) != len(set(parent_ids)):
        raise ValueError("eligible parent metadata contains duplicate IDs")
    if not 0 < count <= len(eligible):
        raise ValueError("parent sample count is outside the eligible pool")
    grouped: dict[tuple[object, ...], list[str]] = defaultdict(list)
    for row in eligible:
        grouped[
            (
                str(row["original_split_source"]),
                str(row["crystal_system"]),
                int(row["orbit_count"]),
                int(row["free_dof_count"]),
                int(row["element_count"]),
            )
        ].append(str(row["parent_id"]))
    allocation = {
        key: math.floor(len(values) * count / len(eligible))
        for key, values in grouped.items()
    }
    missing = count - sum(allocation.values())
    remainder_order = sorted(
        grouped,
        key=lambda key: (
            -(len(grouped[key]) * count / len(eligible) - allocation[key]),
            key,
        ),
    )
    for key in remainder_order[:missing]:
        allocation[key] += 1
    selected: list[str] = []
    for key in sorted(grouped):
        ordered = sorted(
            grouped[key],
            key=lambda parent_id: (
                hashlib.sha256(
                    f"{int(seed)}:integrated-what-where:{parent_id}".encode("utf-8")
                ).hexdigest(),
                parent_id,
            ),
        )
        selected.extend(ordered[: allocation[key]])
    if len(selected) != count or len(set(selected)) != count:
        raise RuntimeError("deterministic parent allocation count mismatch")
    return tuple(sorted(selected))


def stage_for_fraction(active_orbit_count: int, final_orbit_count: int) -> str:
    if int(active_orbit_count) < 0 or int(final_orbit_count) <= 0:
        raise ValueError(
            "active orbit count must be nonnegative and final count positive"
        )
    fraction = int(active_orbit_count) / int(final_orbit_count)
    if fraction < 0.50:
        return "EARLY"
    if fraction < 0.75:
        return "MID"
    return "LATE"


def geometry_method(
    active_orbit_count: int,
    final_orbit_count: int,
    *,
    free_dof: int,
    compatibility_arm: bool,
) -> str:
    if int(free_dof) < 0:
        raise ValueError("free-DOF count must be nonnegative")
    if int(free_dof) == 0:
        return "FIXED_GEOMETRY"
    fraction = int(active_orbit_count) / int(final_orbit_count)
    if compatibility_arm and fraction >= 0.50:
        return "COMPATIBILITY_MLP"
    return "DIRECT_MDN"


def _lookup(
    trajectories: Sequence[Mapping[str, object]],
) -> dict[tuple[int, str, str], Mapping[str, object]]:
    result: dict[tuple[int, str, str], Mapping[str, object]] = {}
    for row in trajectories:
        key = (int(row["stream_seed"]), str(row["parent_id"]), str(row["arm"]))
        if key in result:
            raise ValueError(f"duplicate trajectory key: {key}")
        result[key] = row
    return result


def terminal_factorial_analysis(
    trajectories: Sequence[Mapping[str, object]],
    *,
    stream_seeds: Sequence[int],
    parent_ids: Sequence[str],
    replicates: int = 10_000,
    seed: int = 20260823,
) -> dict[str, dict[str, object]]:
    lookup = _lookup(trajectories)
    contrasts = {
        "B_MINUS_A": (ARM_B, ARM_A),
        "C_MINUS_A": (ARM_C, ARM_A),
        "D_MINUS_B": (ARM_D, ARM_B),
        "D_MINUS_A": (ARM_D, ARM_A),
    }
    result: dict[str, dict[str, object]] = {}
    for comparison_index, (name, (left_arm, right_arm)) in enumerate(contrasts.items()):
        stream_values = []
        per_stream = []
        for stream_seed in stream_seeds:
            values = np.asarray(
                [
                    float(
                        lookup[(int(stream_seed), str(parent_id), left_arm)][
                            "terminal_valid"
                        ]
                    )
                    - float(
                        lookup[(int(stream_seed), str(parent_id), right_arm)][
                            "terminal_valid"
                        ]
                    )
                    for parent_id in parent_ids
                ],
                dtype=float,
            )
            stream_values.append(values)
            per_stream.append(
                {
                    "stream_seed": int(stream_seed),
                    "point": float(values.mean()),
                }
            )
        bootstrap = hierarchical_paired_bootstrap(
            stream_values,
            seed=int(seed) + comparison_index,
            replicates=replicates,
        )
        result[name] = {
            **bootstrap,
            "left_arm": left_arm,
            "right_arm": right_arm,
            "per_stream": per_stream,
        }
    interaction_values = []
    for stream_seed in stream_seeds:
        interaction_values.append(
            np.asarray(
                [
                    (
                        float(
                            lookup[(int(stream_seed), str(parent_id), ARM_D)][
                                "terminal_valid"
                            ]
                        )
                        - float(
                            lookup[(int(stream_seed), str(parent_id), ARM_B)][
                                "terminal_valid"
                            ]
                        )
                    )
                    - (
                        float(
                            lookup[(int(stream_seed), str(parent_id), ARM_C)][
                                "terminal_valid"
                            ]
                        )
                        - float(
                            lookup[(int(stream_seed), str(parent_id), ARM_A)][
                                "terminal_valid"
                            ]
                        )
                    )
                    for parent_id in parent_ids
                ],
                dtype=float,
            )
        )
    result["INTERACTION"] = hierarchical_paired_bootstrap(
        interaction_values,
        seed=int(seed) + len(contrasts),
        replicates=replicates,
    )
    return result


def _force(row: Mapping[str, object], *, key: tuple[int, str, str]) -> float:
    value = row.get("initial_max_force_ev_per_angstrom")
    if value is None:
        raise RuntimeError(f"common-legal trajectory lacks CHGNet force: {key}")
    force = float(value)
    if not math.isfinite(force) or force < 0.0:
        raise RuntimeError(f"common-legal trajectory has invalid CHGNet force: {key}")
    return force


def force_pair_analysis(
    trajectories: Sequence[Mapping[str, object]],
    *,
    left_arm: str,
    right_arm: str,
    stream_seeds: Sequence[int],
    parent_ids: Sequence[str],
    seed: int,
    replicates: int = 10_000,
) -> dict[str, object]:
    lookup = _lookup(trajectories)
    stream_values = []
    left_values: list[float] = []
    right_values: list[float] = []
    per_stream = []
    for stream_seed in stream_seeds:
        deltas = []
        stream_left = []
        stream_right = []
        for parent_id in parent_ids:
            left_key = (int(stream_seed), str(parent_id), left_arm)
            right_key = (int(stream_seed), str(parent_id), right_arm)
            left = lookup[left_key]
            right = lookup[right_key]
            if not bool(left["terminal_valid"]) or not bool(right["terminal_valid"]):
                continue
            left_force = _force(left, key=left_key)
            right_force = _force(right, key=right_key)
            stream_left.append(left_force)
            stream_right.append(right_force)
            deltas.append(math.log1p(left_force) - math.log1p(right_force))
        if not deltas:
            raise RuntimeError(
                f"stream {stream_seed} has no common-legal {left_arm}/{right_arm} pair"
            )
        stream_values.append(np.asarray(deltas, dtype=float))
        left_values.extend(stream_left)
        right_values.extend(stream_right)
        per_stream.append(
            {
                "stream_seed": int(stream_seed),
                "common_legal_n": len(deltas),
                "mean_log1p_force_delta": float(np.mean(deltas)),
            }
        )
    bootstrap = hierarchical_paired_bootstrap(
        stream_values, seed=int(seed), replicates=replicates
    )
    concatenated = np.concatenate(stream_values)
    return {
        "left_arm": left_arm,
        "right_arm": right_arm,
        "common_legal_n": int(len(concatenated)),
        "mean_log1p_force_delta": bootstrap["point"],
        "ci95_lower": bootstrap["ci95_lower"],
        "ci95_upper": bootstrap["ci95_upper"],
        "left_win_rate": float(np.mean(concatenated < 0.0)),
        "left_force_values": left_values,
        "right_force_values": right_values,
        "per_stream": per_stream,
    }


def force_interaction_analysis(
    trajectories: Sequence[Mapping[str, object]],
    *,
    stream_seeds: Sequence[int],
    parent_ids: Sequence[str],
    seed: int,
    replicates: int = 10_000,
) -> dict[str, object]:
    lookup = _lookup(trajectories)
    stream_values = []
    per_stream = []
    for stream_seed in stream_seeds:
        values = []
        for parent_id in parent_ids:
            rows = {
                arm: lookup[(int(stream_seed), str(parent_id), arm)] for arm in ARMS
            }
            if not all(bool(row["terminal_valid"]) for row in rows.values()):
                continue
            forces = {
                arm: _force(row, key=(int(stream_seed), str(parent_id), arm))
                for arm, row in rows.items()
            }
            values.append(
                (math.log1p(forces[ARM_D]) - math.log1p(forces[ARM_B]))
                - (math.log1p(forces[ARM_C]) - math.log1p(forces[ARM_A]))
            )
        if not values:
            raise RuntimeError(
                f"stream {stream_seed} has no all-four-legal force interaction"
            )
        array = np.asarray(values, dtype=float)
        stream_values.append(array)
        per_stream.append(
            {
                "stream_seed": int(stream_seed),
                "all_four_legal_n": len(values),
                "point": float(array.mean()),
            }
        )
    bootstrap = hierarchical_paired_bootstrap(
        stream_values, seed=int(seed), replicates=replicates
    )
    return {
        **bootstrap,
        "all_four_legal_n": int(sum(len(values) for values in stream_values)),
        "per_stream": per_stream,
    }


def component_synergy(*, terminal_interaction: float, force_interaction: float) -> str:
    if float(terminal_interaction) > 0.0 and float(force_interaction) < 0.0:
        return "POSITIVE"
    if float(terminal_interaction) < 0.0 and float(force_interaction) > 0.0:
        return "NEGATIVE"
    return "NEUTRAL"


def failure_class(*, terminal_valid: bool, failure: str | None) -> str:
    if bool(terminal_valid):
        return "LEGAL_TERMINAL"
    if failure in {
        "PROJECTOR_REJECTED",
        "EXPANSION_FAILURE",
        "COMPATIBILITY_NO_VALID_CANDIDATE",
        "NONFINITE_GEOMETRY",
    }:
        return "GEOMETRY_ENDPOINT_REJECTION"
    if failure == "NO_LEGAL_ACTION":
        return "DISCRETE_DEAD_END"
    return "WRONG_TERMINAL"


def integrated_verdict(
    *,
    b_minus_a_terminal: Mapping[str, float],
    d_minus_b_terminal: Mapping[str, float],
    d_minus_a_terminal: Mapping[str, float],
    d_minus_b_force: Mapping[str, float],
    d_minus_a_force: Mapping[str, float],
) -> dict[str, object]:
    conditions = {
        "b_minus_a_terminal_point_positive": float(b_minus_a_terminal["point"]) > 0.0,
        "d_minus_b_terminal_ci_lower_above_minus_0_05": float(
            d_minus_b_terminal["ci95_lower"]
        )
        > -0.05,
        "d_minus_b_force_ci_upper_below_zero": float(d_minus_b_force["ci95_upper"])
        < 0.0,
        "d_minus_a_terminal_point_positive": float(d_minus_a_terminal["point"]) > 0.0,
        "d_minus_a_force_not_significantly_worse": float(d_minus_a_force["ci95_lower"])
        <= 0.0,
    }
    supported = all(conditions.values())
    return {
        "conditions": conditions,
        "signal": "SUPPORTED" if supported else "NOT_SUPPORTED",
        "next_action": (
            "FREEZE_CRYSALIS_V3_CORE"
            if supported
            else "DIAGNOSE_COMPONENT_INTERFERENCE"
        ),
    }


__all__ = [
    "ARM_A",
    "ARM_B",
    "ARM_C",
    "ARM_D",
    "ARMS",
    "component_synergy",
    "deterministic_integrated_parent_sample",
    "failure_class",
    "force_interaction_analysis",
    "force_pair_analysis",
    "geometry_method",
    "integrated_verdict",
    "stage_for_fraction",
    "terminal_factorial_analysis",
]
