from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from dataclasses import asdict
from pathlib import Path
from statistics import fmean
from typing import Any, Mapping, Sequence

import torch

from crysalis_g1.experiments.c0_symmetry_evaluation import (
    load_c0_symmetry_checkpoint,
)
from crysalis_g1.experiments.chgnet_terminal import (
    CHGNetEvaluationConfig,
    CHGNetTerminalEvaluator,
)
from crysalis_g1.experiments.policy_attribution import (
    build_empirical_frequency_prior,
    generate_baseline_attempts,
)
from crysalis_g1.experiments.policy_attribution_runner import (
    assert_baseline_runtime_isolation,
    assert_condition_alignment,
    verify_execution_inputs,
    verify_sha256,
    write_json_new,
)
from crysalis_g1.experiments.policy_stream_robustness import (
    choose_cssd_robustness_decision,
    hierarchical_paired_bootstrap,
    hierarchical_space_group_macro_bootstrap,
    summarize_action_failure_mechanism,
    summarize_binary_streams,
)

ORIGINAL_CORE_HYPOTHESIS = (
    "semantic deconstruction",
    "offline relation learning",
    "persistent sample-specific relation memory",
    "reverse crystal assembly",
    "physics-guided crystal generation",
)

POLICY_ARMS = ("UNIFORM_LEGAL", "EMPIRICAL_FREQUENCY")
SOURCE_PATHS = (
    "configs/g1_c0_policy_stream_robustness_20260826.json",
    "crysalis_g1/experiments/policy_attribution.py",
    "crysalis_g1/experiments/policy_stream_robustness.py",
    "crysalis_g1/experiments/policy_stream_robustness_runner.py",
    "tests/crysalis_g1/test_policy_attribution.py",
    "tests/crysalis_g1/test_policy_stream_robustness.py",
    "tests/crysalis_g1/test_policy_stream_robustness_runner.py",
)
FINAL_OUTPUTS = (
    "POLICY_STREAM_ROBUSTNESS_PREREGISTRATION.json",
    "EMPIRICAL_FREQUENCY_PRIOR.json",
    "GENERATION_EXIT.json",
    "FIXED_CELL_EXIT.json",
    "POLICY_STREAM_ROBUSTNESS_METRICS.json",
    "POLICY_STREAM_HIERARCHICAL_STATISTICS.json",
    "POLICY_STREAM_BY_SPACE_GROUP.json",
    "ACTION_FAILURE_MECHANISM_AUDIT.json",
    "CONTRIBUTION_INDEPENDENCE_AUDIT.json",
    "RESEARCH_PROGRAM_STATUS.json",
    "POLICY_STREAM_ROBUSTNESS_RESULTS.md",
    "NEXT_SCIENTIFIC_DECISION.md",
    "POLICY_STREAM_ROBUSTNESS_FAILURES.jsonl",
    "POLICY_STREAM_ROBUSTNESS_EXIT.json",
    "POLICY_STREAM_ROBUSTNESS_MANIFEST.json",
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _write_text_new(path: str | Path, text: str) -> None:
    destination = Path(path)
    if destination.exists():
        raise FileExistsError(f"refusing to overwrite: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(text, encoding="utf-8")


def _append_failure(output_root: Path, *, stage: str, error: BaseException) -> None:
    path = output_root / "POLICY_STREAM_ROBUSTNESS_FAILURES.jsonl"
    row = {
        "stage": stage,
        "exception_type": type(error).__name__,
        "exception_message": str(error),
        "automatic_retry_performed": False,
    }
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def _statistics_seed(root_seed: int, label: str) -> int:
    digest = hashlib.sha256(
        f"{root_seed}:policy_stream_robustness:statistics:{label}".encode("utf-8")
    ).digest()
    return int.from_bytes(digest[:8], "big") % (2**63)


def stream_namespace(arm: str, stream_index: int) -> str:
    if not 0 <= int(stream_index) < 20:
        raise ValueError(f"stream index must be in [0, 19]: {stream_index}")
    names = {
        "UNIFORM_LEGAL": "uniform",
        "EMPIRICAL_FREQUENCY": "empirical",
    }
    try:
        arm_name = names[str(arm)]
    except KeyError as error:
        raise ValueError(f"unsupported policy stream arm: {arm}") from error
    return f"policy_attribution:{arm_name}:stream:{int(stream_index):02d}"


def validate_execution_contract(config: Mapping[str, Any]) -> None:
    if int(config["root_seed"]) != 20260823:
        raise ValueError("ROOT_SEED must remain 20260823")
    if int(config["policy_stream_count"]) != 20:
        raise ValueError("policy stream count must remain 20")
    if [int(value) for value in config["fixed_cell_stream_indices"]] != list(range(5)):
        raise ValueError("fixed-cell stream indices must remain 00 through 04")
    if int(config["attempt_count"]) != 300:
        raise ValueError("attempt count must remain 300")
    if int(config["bootstrap_resamples"]) != 10000:
        raise ValueError("bootstrap resamples must remain 10000")
    if (
        config.get("original_core_hypothesis_retained") is not True
        or tuple(config.get("original_core_hypothesis", ())) != ORIGINAL_CORE_HYPOTHESIS
    ):
        raise ValueError("original core hypothesis must remain explicitly retained")
    authorization = dict(config["authorization"])
    if authorization.get("local_execution") is not True:
        raise ValueError("local execution is not authorized")
    forbidden = {
        key: value
        for key, value in authorization.items()
        if key != "local_execution" and value is not False
    }
    if forbidden:
        raise ValueError(f"forbidden authorization enabled: {forbidden}")


def create_new_output_root(path: str | Path) -> Path:
    output_root = Path(path)
    try:
        output_root.mkdir(parents=True, exist_ok=False)
    except FileExistsError as error:
        raise FileExistsError(f"refusing to overwrite: {output_root}") from error
    return output_root


def verify_hashed_manifest_tree(
    manifest_path: str | Path,
    *,
    expected_result: str,
    expected_manifest_sha256: str,
) -> dict[str, Any]:
    manifest_path = Path(manifest_path)
    observed_manifest_hash = _sha256(manifest_path)
    if observed_manifest_hash.lower() != str(expected_manifest_sha256).lower():
        raise ValueError("previous attribution manifest SHA256 mismatch")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("result") != expected_result:
        raise ValueError("previous attribution result mismatch")
    declared = dict(manifest.get("file_sha256", {}))
    mismatches: list[dict[str, str]] = []
    for relative_path, expected_hash in declared.items():
        evidence_path = manifest_path.parent / relative_path
        if not evidence_path.is_file():
            mismatches.append(
                {"path": relative_path, "status": "MISSING", "observed": ""}
            )
            continue
        observed = _sha256(evidence_path)
        if observed.lower() != str(expected_hash).lower():
            mismatches.append(
                {"path": relative_path, "status": "HASH_MISMATCH", "observed": observed}
            )
    if mismatches:
        raise ValueError(f"declared evidence hash mismatch: {mismatches[0]}")
    return {
        "manifest_sha256": observed_manifest_hash,
        "result": manifest["result"],
        "declared_file_count": len(declared),
        "verified_file_count": len(declared),
        "hash_mismatch_count": 0,
    }


def _verify_source_freeze(config: Mapping[str, Any]) -> dict[str, Any]:
    repository_root = Path(config["repository_root"])
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=repository_root,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    result = subprocess.run(
        ["git", "diff", "--quiet", "HEAD", "--", *SOURCE_PATHS],
        cwd=repository_root,
        check=False,
    )
    if result.returncode != 0:
        raise ValueError("policy-stream implementation differs from committed HEAD")
    return {
        "implementation_commit_sha": head,
        "implementation_file_sha256": {
            relative: _sha256(repository_root / relative) for relative in SOURCE_PATHS
        },
    }


def _verify_critical_inputs(config: Mapping[str, Any]) -> None:
    gates = (
        (
            Path(config["phase2a_root"]) / "phase2a_manifest.json",
            config["phase2a_manifest_sha256"],
            "Phase2A manifest",
        ),
        (
            config["checkpoint_path"],
            config["checkpoint_sha256"],
            "frozen C0 checkpoint",
        ),
        (
            config["condition_manifest_path"],
            config["condition_manifest_sha256"],
            "condition manifest",
        ),
        (
            config["learned_generation_records_path"],
            config["learned_generation_records_sha256"],
            "learned generation records",
        ),
        (
            config["learned_fixed_cell_chgnet_path"],
            config["learned_fixed_cell_chgnet_sha256"],
            "learned fixed-cell CHGNet records",
        ),
        (
            config["chgnet"]["weight_path"],
            config["chgnet"]["weight_sha256"],
            "CHGNet weight",
        ),
    )
    for path, expected, label in gates:
        verify_sha256(path, str(expected), label=str(label))


def _verify_previous_attribution(config: Mapping[str, Any]) -> dict[str, Any]:
    audit = verify_hashed_manifest_tree(
        config["previous_attribution_manifest_path"],
        expected_result="CRYSTALLOGRAPHIC_SEARCH_SPACE_IS_PRIMARY_CONTRIBUTOR",
        expected_manifest_sha256=str(config["previous_attribution_manifest_sha256"]),
    )
    expected_count = int(config["previous_attribution_declared_file_count"])
    if audit["declared_file_count"] != expected_count:
        raise ValueError("previous attribution declared file count mismatch")
    return audit


def _verify_declared_files(
    output_root: Path, declared: Mapping[str, str], *, label: str
) -> None:
    for relative_path, expected in declared.items():
        path = output_root / relative_path
        if not path.is_file() or _sha256(path).lower() != str(expected).lower():
            raise ValueError(f"{label} evidence mismatch: {relative_path}")


def _generation_path(output_root: Path, arm: str, stream_index: int) -> Path:
    return output_root / "generation" / f"{arm}_STREAM_{stream_index:02d}.json"


def _fixed_path(output_root: Path, arm: str, stream_index: int) -> Path:
    return output_root / "fixed_cell" / f"{arm}_STREAM_{stream_index:02d}.json"


def _preregistration(config: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "g1-policy-stream-robustness-preregistration.1.0.0",
        "scientific_question": (
            "Is crystallographic search-space dominance robust to independent "
            "legal-policy random streams under a frozen learned C0 comparator?"
        ),
        "contribution_name": "Crystallographic Search-Space Dominance (CSSD)",
        "claim_scope": "frozen C0-Symmetry architecture and 300-condition manifest",
        "root_seed": int(config["root_seed"]),
        "policy_stream_count_per_baseline": int(config["policy_stream_count"]),
        "attempt_count_per_stream": int(config["attempt_count"]),
        "fixed_cell_stream_indices": list(config["fixed_cell_stream_indices"]),
        "policy_namespaces": {
            arm: [stream_namespace(arm, index) for index in range(20)]
            for arm in POLICY_ARMS
        },
        "primary_endpoint_1": (
            "symmetry_valid_legal_terminal_rate; denominator=all 300 attempts"
        ),
        "primary_endpoint_2": (
            "fixed_cell_FIRE300_symmetry_preserving_physical_survival_rate; "
            "denominator=all 300 attempts"
        ),
        "statistics": {
            "method": "two-level paired bootstrap: policy stream then condition",
            "resamples": int(config["bootstrap_resamples"]),
            "space_group_macro": "stream bootstrap plus within-SG paired resampling",
            "uncertainty_scope": (
                "policy-stream and condition uncertainty conditional on one frozen "
                "checkpoint; not training-seed uncertainty"
            ),
        },
        "decision_rule": {
            "CSSD_ROBUST": [
                "uniform endpoint-1 CI lower bound > 0",
                "uniform beats learned in at least 90% of 20 streams",
                "uniform fixed-cell endpoint-2 CI lower bound > 0",
                "observed eight-SG macro delta > 0",
                "execution complete",
            ],
            "CSSD_STREAM_SENSITIVE": "complete execution but robust rule not met",
            "ATTRIBUTION_REPLICATION_INCONCLUSIVE": "execution incomplete",
        },
        "frozen_components": [
            "learned checkpoint",
            "300 conditions",
            "Legal Action Compiler",
            "geometry backend",
            "lattice head",
            "projector",
            "CHGNet evaluator",
        ],
        "prohibited": [
            key
            for key, enabled in config["authorization"].items()
            if key != "local_execution" and enabled is False
        ],
        "original_core_hypothesis_retained": True,
        "original_core_hypothesis": list(ORIGINAL_CORE_HYPOTHESIS),
        "no_cell_relaxation_repeat": True,
        "no_novelty_repeat": True,
    }


def _research_program_status(config: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "g1-research-program-status.1.0.0",
        "original_core_hypothesis": list(ORIGINAL_CORE_HYPOTHESIS),
        "original_core_hypothesis_retained": True,
        "current_bounded_experiment": "CSSD policy-stream robustness",
        "relationship": (
            "CSSD is an independently testable causal-attribution result inside C0; "
            "it does not replace the original semantic-relation-memory-physics program."
        ),
        "current_modules_enabled": {
            "kan": False,
            "relation_memory": False,
            "relation_library": False,
            "physics": False,
            "e3nn": False,
        },
        "future_program_not_executed_in_this_run": True,
        "authorization": dict(config["authorization"]),
    }


def _generation_payload(
    *,
    config: Mapping[str, Any],
    arm: str,
    stream_index: int,
    records: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    namespace = stream_namespace(arm, stream_index)
    return {
        "schema_version": "g1-policy-stream-generation.1.0.0",
        "policy_arm": arm,
        "stream_index": stream_index,
        "policy_namespace": namespace,
        "root_seed": int(config["root_seed"]),
        "condition_manifest_sha256": config["condition_manifest_sha256"],
        "checkpoint_sha256": config["checkpoint_sha256"],
        "LEARNED_ACTION_LOGITS_USED": False,
        "legal_terminal_count": sum(
            bool(record.get("legal_terminal_crystal")) for record in records
        ),
        "records": list(records),
    }


def run_generate(config_path: str | Path) -> Path:
    config = _read_json(config_path)
    validate_execution_contract(config)
    output_root = create_new_output_root(config["output_root"])
    write_json_new(
        output_root / "POLICY_STREAM_ROBUSTNESS_PREREGISTRATION.json",
        _preregistration(config),
    )
    write_json_new(
        output_root / "RESEARCH_PROGRAM_STATUS.json",
        _research_program_status(config),
    )
    try:
        source_freeze = _verify_source_freeze(config)
        previous_audit = _verify_previous_attribution(config)
        verified = verify_execution_inputs(config)
        conditions = verified["conditions"]
        prior, prior_payload = build_empirical_frequency_prior(
            phase2a_root=config["phase2a_root"],
            recovered_parent_cache=config["recovered_parent_cache"],
            alpha=1.0,
        )
        prior_path = output_root / "EMPIRICAL_FREQUENCY_PRIOR.json"
        write_json_new(prior_path, prior_payload)
        if _sha256(prior_path) != str(config["empirical_prior_sha256"]):
            raise ValueError("empirical prior differs from frozen attribution prior")
        model, checkpoint_payload = load_c0_symmetry_checkpoint(
            config["checkpoint_path"], device=str(config["device"])
        )
        generation_hashes: dict[str, str] = {}
        stream_metrics: dict[str, dict[str, Any]] = {}
        for arm in POLICY_ARMS:
            stream_metrics[arm] = {}
            for stream_index in range(int(config["policy_stream_count"])):
                namespace = stream_namespace(arm, stream_index)
                print(f"GENERATE {arm} stream {stream_index:02d}", flush=True)
                records = generate_baseline_attempts(
                    model,
                    conditions,
                    arm=arm,
                    empirical_prior=(prior if arm == "EMPIRICAL_FREQUENCY" else None),
                    root_seed=int(config["root_seed"]),
                    device=str(config["device"]),
                    minimum_distance=float(config["minimum_distance_angstrom"]),
                    policy_namespace=namespace,
                )
                assert_condition_alignment(
                    conditions,
                    {arm: records},
                    expected_count=int(config["attempt_count"]),
                )
                assert_baseline_runtime_isolation(records, arm=arm)
                if any(
                    record.get("policy_namespace") != namespace for record in records
                ):
                    raise ValueError(
                        f"{arm} stream namespace drift: {stream_index:02d}"
                    )
                path = _generation_path(output_root, arm, stream_index)
                write_json_new(
                    path,
                    _generation_payload(
                        config=config,
                        arm=arm,
                        stream_index=stream_index,
                        records=records,
                    ),
                )
                relative = path.relative_to(output_root).as_posix()
                generation_hashes[relative] = _sha256(path)
                successes = sum(
                    bool(record.get("legal_terminal_crystal")) for record in records
                )
                stream_metrics[arm][f"{stream_index:02d}"] = {
                    "legal_terminal_count": successes,
                    "legal_terminal_rate": successes / len(records),
                }
                del records
        del model, checkpoint_payload
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        write_json_new(
            output_root / "GENERATION_EXIT.json",
            {
                "schema_version": "g1-policy-stream-generation-exit.1.0.0",
                "status": "PASS",
                "automatic_retry_performed": False,
                "stream_count_per_arm": int(config["policy_stream_count"]),
                "attempt_count_per_stream": int(config["attempt_count"]),
                "total_baseline_attempts": (
                    len(POLICY_ARMS)
                    * int(config["policy_stream_count"])
                    * int(config["attempt_count"])
                ),
                "stream_metrics": stream_metrics,
                "file_sha256": generation_hashes,
                "source_freeze": source_freeze,
                "previous_attribution_audit": previous_audit,
                "phase2a_manifest_sha256": config["phase2a_manifest_sha256"],
                "checkpoint_sha256": config["checkpoint_sha256"],
                "condition_manifest_sha256": config["condition_manifest_sha256"],
                "sealed_or_blind_data_accessed": False,
            },
        )
        return output_root
    except Exception as error:
        _append_failure(output_root, stage="GENERATION", error=error)
        exit_path = output_root / "GENERATION_EXIT.json"
        if not exit_path.exists():
            write_json_new(
                exit_path,
                {
                    "status": "FAIL",
                    "exception_type": type(error).__name__,
                    "exception_message": str(error),
                    "automatic_retry_performed": False,
                },
            )
        raise


def _chgnet_config(config: Mapping[str, Any]) -> CHGNetEvaluationConfig:
    payload = config["chgnet"]
    return CHGNetEvaluationConfig(
        package_version=str(payload["package_version"]),
        model_version=str(payload["model_version"]),
        weight_path=str(payload["weight_path"]),
        weight_sha256=str(payload["weight_sha256"]),
        optimizer=str(payload["optimizer"]),
        force_threshold_ev_per_angstrom=float(
            payload["force_threshold_ev_per_angstrom"]
        ),
        maximum_steps=int(payload["maximum_steps"]),
        relax_cell=False,
        short_contact_distance=float(payload["short_contact_distance"]),
        device=str(config["device"]),
    )


def run_fixed_cell(config_path: str | Path) -> Path:
    config = _read_json(config_path)
    validate_execution_contract(config)
    output_root = Path(config["output_root"])
    if not output_root.is_dir():
        raise FileNotFoundError("generation output root does not exist")
    if (output_root / "FIXED_CELL_EXIT.json").exists():
        raise FileExistsError("refusing to overwrite fixed-cell phase")
    try:
        _verify_source_freeze(config)
        _verify_critical_inputs(config)
        _verify_previous_attribution(config)
        generation_exit = _read_json(output_root / "GENERATION_EXIT.json")
        if generation_exit.get("status") != "PASS":
            raise ValueError("generation phase did not pass")
        _verify_declared_files(
            output_root,
            generation_exit["file_sha256"],
            label="generation",
        )
        evaluator = CHGNetTerminalEvaluator(_chgnet_config(config))
        fixed_hashes: dict[str, str] = {}
        stream_metrics: dict[str, dict[str, Any]] = {}
        for arm in POLICY_ARMS:
            stream_metrics[arm] = {}
            for stream_index in config["fixed_cell_stream_indices"]:
                stream_index = int(stream_index)
                print(f"FIXED_CELL {arm} stream {stream_index:02d}", flush=True)
                generation = _read_json(
                    _generation_path(output_root, arm, stream_index)
                )
                records = generation["records"]
                assert_baseline_runtime_isolation(records, arm=arm)
                output_path = _fixed_path(output_root, arm, stream_index)
                payload = evaluator.evaluate(records, output_path=output_path)
                relative = output_path.relative_to(output_root).as_posix()
                fixed_hashes[relative] = _sha256(output_path)
                symmetry_survival_count = sum(
                    bool(record.get("post_relax_survival"))
                    and bool(record.get("space_group_match"))
                    for record in payload["records"]
                )
                stream_metrics[arm][f"{stream_index:02d}"] = {
                    "convergence_count": int(payload["convergence_count"]),
                    "physical_survival_count": int(
                        payload["post_relax_survival_count"]
                    ),
                    "symmetry_preserving_survival_count": symmetry_survival_count,
                    "symmetry_preserving_survival_rate": (
                        symmetry_survival_count / int(config["attempt_count"])
                    ),
                }
        write_json_new(
            output_root / "FIXED_CELL_EXIT.json",
            {
                "schema_version": "g1-policy-stream-fixed-cell-exit.1.0.0",
                "status": "PASS",
                "automatic_retry_performed": False,
                "stream_indices": list(config["fixed_cell_stream_indices"]),
                "stream_count_per_arm": len(config["fixed_cell_stream_indices"]),
                "cell_relaxation_repeated": False,
                "file_sha256": fixed_hashes,
                "stream_metrics": stream_metrics,
                "chgnet_config": asdict(_chgnet_config(config)),
            },
        )
        return output_root
    except Exception as error:
        _append_failure(output_root, stage="FIXED_CELL", error=error)
        exit_path = output_root / "FIXED_CELL_EXIT.json"
        if not exit_path.exists():
            write_json_new(
                exit_path,
                {
                    "status": "FAIL",
                    "exception_type": type(error).__name__,
                    "exception_message": str(error),
                    "automatic_retry_performed": False,
                },
            )
        raise


def _binary_generation_outcomes(
    records: Sequence[Mapping[str, Any]],
) -> list[bool]:
    return [bool(record.get("legal_terminal_crystal")) for record in records]


def _binary_fixed_outcomes(
    conditions: Sequence[Mapping[str, Any]],
    records: Sequence[Mapping[str, Any]],
) -> list[bool]:
    by_id = {str(record["condition_id"]): record for record in records}
    expected_ids = [str(condition["condition_id"]) for condition in conditions]
    if set(by_id) != set(expected_ids) or len(by_id) != len(expected_ids):
        raise ValueError("fixed-cell condition identity mismatch")
    return [
        bool(by_id[condition_id].get("post_relax_survival"))
        and bool(by_id[condition_id].get("space_group_match"))
        for condition_id in expected_ids
    ]


def _split_by_space_group(
    conditions: Sequence[Mapping[str, Any]], outcomes: Sequence[bool]
) -> dict[int, list[bool]]:
    if len(conditions) != len(outcomes):
        raise ValueError("condition and outcome counts differ")
    result: dict[int, list[bool]] = {}
    for condition, outcome in zip(conditions, outcomes, strict=True):
        result.setdefault(int(condition["space_group"]), []).append(bool(outcome))
    return result


def _space_group_stream_summary(
    learned: Mapping[int, Sequence[bool]],
    baseline_streams: Mapping[str, Mapping[int, Sequence[bool]]],
) -> dict[str, Any]:
    summary: dict[str, Any] = {}
    for space_group in sorted(learned):
        learned_values = list(learned[space_group])
        learned_rate = sum(learned_values) / len(learned_values)
        rates = {
            stream_id: sum(by_sg[space_group]) / len(by_sg[space_group])
            for stream_id, by_sg in sorted(baseline_streams.items())
        }
        summary[str(space_group)] = {
            "attempts_per_stream": len(learned_values),
            "learned_success_count": sum(learned_values),
            "learned_success_rate": learned_rate,
            "baseline_stream_success_rates": rates,
            "baseline_mean_success_rate": float(fmean(rates.values())),
            "baseline_success_rate_range": [min(rates.values()), max(rates.values())],
            "baseline_better_stream_fraction": (
                sum(rate > learned_rate for rate in rates.values()) / len(rates)
            ),
        }
    return summary


def _load_generation_streams(
    output_root: Path, config: Mapping[str, Any]
) -> dict[str, dict[str, list[dict[str, Any]]]]:
    streams: dict[str, dict[str, list[dict[str, Any]]]] = {}
    for arm in POLICY_ARMS:
        streams[arm] = {}
        for stream_index in range(int(config["policy_stream_count"])):
            payload = _read_json(_generation_path(output_root, arm, stream_index))
            namespace = stream_namespace(arm, stream_index)
            if payload.get("policy_namespace") != namespace:
                raise ValueError(f"generation payload namespace mismatch: {namespace}")
            records = payload["records"]
            assert_baseline_runtime_isolation(records, arm=arm)
            streams[arm][f"{stream_index:02d}"] = records
    return streams


def _load_fixed_streams(
    output_root: Path, config: Mapping[str, Any]
) -> dict[str, dict[str, list[dict[str, Any]]]]:
    streams: dict[str, dict[str, list[dict[str, Any]]]] = {}
    for arm in POLICY_ARMS:
        streams[arm] = {}
        for stream_index in config["fixed_cell_stream_indices"]:
            payload = _read_json(_fixed_path(output_root, arm, int(stream_index)))
            streams[arm][f"{int(stream_index):02d}"] = payload["records"]
    return streams


def _results_markdown(
    *,
    decision: str,
    independence_status: str,
    metrics: Mapping[str, Any],
    statistics: Mapping[str, Any],
    audit: Mapping[str, Any],
) -> str:
    e1 = metrics["primary_endpoint_1"]
    uniform_e1 = statistics["primary_endpoint_1"]["UNIFORM_LEGAL_minus_LEARNED"]
    uniform_e2 = statistics["primary_endpoint_2"]["UNIFORM_LEGAL_minus_LEARNED"]
    macro = statistics["space_group_macro_primary_endpoint_1"][
        "UNIFORM_LEGAL_minus_LEARNED"
    ]
    lines = [
        "# Crysalis-G1 C0 policy-stream robustness results",
        "",
        f"**Preregistered decision:** `{decision}`",
        "",
        f"**Contribution-independence status:** `{independence_status}`",
        "",
        "## Main result",
        "",
        (
            f"The frozen learned arm remained at {e1['learned_rate']:.2%} legal "
            "symmetry-valid terminals. Across 20 independent Uniform-Legal streams, "
            f"the mean was {e1['UNIFORM_LEGAL']['baseline_mean_rate']:.2%} "
            f"(range {e1['UNIFORM_LEGAL']['baseline_rate_range'][0]:.2%}–"
            f"{e1['UNIFORM_LEGAL']['baseline_rate_range'][1]:.2%})."
        ),
        "",
        (
            "Two-level paired bootstrap, Uniform minus Learned: "
            f"delta={uniform_e1['observed_delta_baseline_minus_learned']:.4f}, "
            f"95% CI [{uniform_e1['confidence_interval_95'][0]:.4f}, "
            f"{uniform_e1['confidence_interval_95'][1]:.4f}]."
        ),
        "",
        (
            "For fixed-cell FIRE300 symmetry-preserving physical survival over "
            "pre-fixed streams 00–04, Uniform minus Learned: "
            f"delta={uniform_e2['observed_delta_baseline_minus_learned']:.4f}, "
            f"95% CI [{uniform_e2['confidence_interval_95'][0]:.4f}, "
            f"{uniform_e2['confidence_interval_95'][1]:.4f}]."
        ),
        "",
        (
            "Eight-space-group macro Uniform-minus-Learned delta: "
            f"{macro['observed_macro_delta_baseline_minus_learned']:.4f}, "
            f"95% CI [{macro['confidence_interval_95'][0]:.4f}, "
            f"{macro['confidence_interval_95'][1]:.4f}]."
        ),
        "",
        "These intervals quantify policy-stream and paired-condition uncertainty "
        "conditional on one frozen checkpoint. They do not quantify training-seed "
        "uncertainty.",
        "",
        "## Independence and truth gates",
        "",
    ]
    for gate, payload in audit["gates"].items():
        lines.append(f"- `{gate}`: **{payload['status']}** — {payload['evidence']}")
    lines.extend(
        [
            "",
            "## Research-program boundary",
            "",
            "This bounded result does not replace the original Crysalis-G1 program: "
            "semantic deconstruction → offline relation learning → persistent "
            "sample-specific relation memory → reverse crystal assembly → "
            "physics-guided crystal generation. None of KAN, Relation Memory, "
            "Relation Library, Physics, e3nn, retraining, server use, DFT, or a "
            "three-seed training matrix was activated here.",
            "",
            "The defensible contribution is scoped to the frozen C0 architecture. "
            "No universal priority or database-global claim is made.",
            "",
        ]
    )
    return "\n".join(lines)


def _decision_markdown(
    decision: str, independence_status: str, audit: Mapping[str, Any]
) -> str:
    return "\n".join(
        [
            "# Next scientific decision",
            "",
            f"Policy-stream result: `{decision}`.",
            "",
            f"Contribution status: `{independence_status}`.",
            "",
            "The original Crysalis-G1 research hypothesis remains active and "
            "unchanged. This experiment only determines whether CSSD is a real, "
            "independently supported C0 contribution.",
            "",
            "Gate summary:",
            "",
            *[
                f"- {name}: {payload['status']}"
                for name, payload in audit["gates"].items()
            ],
            "",
            "Execution stops here. No KAN, Relation Memory, Physics, server, "
            "model retraining, or three-seed experiment follows automatically.",
            "",
        ]
    )


def run_finalize(config_path: str | Path) -> Path:
    config_path = Path(config_path)
    config = _read_json(config_path)
    validate_execution_contract(config)
    output_root = Path(config["output_root"])
    if not output_root.is_dir():
        raise FileNotFoundError("policy-stream output root does not exist")
    if (output_root / "POLICY_STREAM_ROBUSTNESS_EXIT.json").exists():
        raise FileExistsError("refusing to overwrite finalized experiment")
    try:
        source_freeze = _verify_source_freeze(config)
        _verify_critical_inputs(config)
        previous_audit = _verify_previous_attribution(config)
        generation_exit = _read_json(output_root / "GENERATION_EXIT.json")
        fixed_exit = _read_json(output_root / "FIXED_CELL_EXIT.json")
        if (
            generation_exit.get("status") != "PASS"
            or fixed_exit.get("status") != "PASS"
        ):
            raise ValueError("generation and fixed-cell phases must both pass")
        _verify_declared_files(
            output_root, generation_exit["file_sha256"], label="generation"
        )
        _verify_declared_files(
            output_root, fixed_exit["file_sha256"], label="fixed-cell"
        )

        conditions = _read_json(config["condition_manifest_path"])["conditions"]
        learned_records = _read_json(config["learned_generation_records_path"])[
            "records"
        ]
        learned_fixed_records = _read_json(config["learned_fixed_cell_chgnet_path"])[
            "records"
        ]
        generation_streams = _load_generation_streams(output_root, config)
        fixed_streams = _load_fixed_streams(output_root, config)
        all_alignment: dict[str, Sequence[Mapping[str, Any]]] = {
            "LEARNED": learned_records
        }
        for arm, streams in generation_streams.items():
            for stream_id, records in streams.items():
                all_alignment[f"{arm}:{stream_id}"] = records
        assert_condition_alignment(
            conditions,
            all_alignment,
            expected_count=int(config["attempt_count"]),
        )

        learned_e1 = _binary_generation_outcomes(learned_records)
        baseline_e1 = {
            arm: {
                stream_id: _binary_generation_outcomes(records)
                for stream_id, records in streams.items()
            }
            for arm, streams in generation_streams.items()
        }
        learned_e2 = _binary_fixed_outcomes(conditions, learned_fixed_records)
        baseline_e2 = {
            arm: {
                stream_id: _binary_fixed_outcomes(conditions, records)
                for stream_id, records in streams.items()
            }
            for arm, streams in fixed_streams.items()
        }
        learned_e1_by_sg = _split_by_space_group(conditions, learned_e1)
        baseline_e1_by_sg = {
            arm: {
                stream_id: _split_by_space_group(conditions, outcomes)
                for stream_id, outcomes in streams.items()
            }
            for arm, streams in baseline_e1.items()
        }
        learned_e2_by_sg = _split_by_space_group(conditions, learned_e2)
        baseline_e2_by_sg = {
            arm: {
                stream_id: _split_by_space_group(conditions, outcomes)
                for stream_id, outcomes in streams.items()
            }
            for arm, streams in baseline_e2.items()
        }

        resamples = int(config["bootstrap_resamples"])
        statistics = {
            "schema_version": "g1-policy-stream-hierarchical-statistics.1.0.0",
            "primary_endpoint_1": {},
            "primary_endpoint_2": {},
            "space_group_macro_primary_endpoint_1": {},
        }
        for arm in POLICY_ARMS:
            label = f"{arm}_minus_LEARNED"
            statistics["primary_endpoint_1"][label] = hierarchical_paired_bootstrap(
                learned_e1,
                baseline_e1[arm],
                resamples=resamples,
                seed=_statistics_seed(int(config["root_seed"]), f"e1:{arm}"),
            )
            statistics["primary_endpoint_2"][label] = hierarchical_paired_bootstrap(
                learned_e2,
                baseline_e2[arm],
                resamples=resamples,
                seed=_statistics_seed(int(config["root_seed"]), f"e2:{arm}"),
            )
            statistics["space_group_macro_primary_endpoint_1"][label] = (
                hierarchical_space_group_macro_bootstrap(
                    learned_e1_by_sg,
                    baseline_e1_by_sg[arm],
                    resamples=resamples,
                    seed=_statistics_seed(
                        int(config["root_seed"]), f"sg_macro_e1:{arm}"
                    ),
                )
            )

        e1_summaries = {
            arm: summarize_binary_streams(learned_e1, baseline_e1[arm])
            for arm in POLICY_ARMS
        }
        e2_summaries = {
            arm: summarize_binary_streams(learned_e2, baseline_e2[arm])
            for arm in POLICY_ARMS
        }
        metrics = {
            "schema_version": "g1-policy-stream-robustness-metrics.1.0.0",
            "attempt_count_per_stream": int(config["attempt_count"]),
            "primary_endpoint_1": {
                "name": "symmetry_valid_legal_terminal_rate",
                "learned_count": sum(learned_e1),
                "learned_rate": sum(learned_e1) / len(learned_e1),
                **e1_summaries,
            },
            "primary_endpoint_2": {
                "name": (
                    "fixed_cell_FIRE300_symmetry_preserving_physical_survival_rate"
                ),
                "learned_count": sum(learned_e2),
                "learned_rate": sum(learned_e2) / len(learned_e2),
                **e2_summaries,
            },
            "generation_stream_count_per_arm": int(config["policy_stream_count"]),
            "fixed_cell_stream_count_per_arm": len(config["fixed_cell_stream_indices"]),
        }
        by_space_group = {
            "schema_version": "g1-policy-stream-by-space-group.1.0.0",
            "space_groups": sorted(learned_e1_by_sg),
            "primary_endpoint_1": {
                arm: _space_group_stream_summary(
                    learned_e1_by_sg, baseline_e1_by_sg[arm]
                )
                for arm in POLICY_ARMS
            },
            "primary_endpoint_2": {
                arm: _space_group_stream_summary(
                    learned_e2_by_sg, baseline_e2_by_sg[arm]
                )
                for arm in POLICY_ARMS
            },
        }
        mechanism = {
            "schema_version": "g1-action-failure-mechanism-audit.1.0.0",
            "LEARNED": summarize_action_failure_mechanism(learned_records),
        }
        for arm in POLICY_ARMS:
            mechanism[arm] = {
                "aggregate": summarize_action_failure_mechanism(
                    [
                        record
                        for records in generation_streams[arm].values()
                        for record in records
                    ]
                ),
                "by_stream": {
                    stream_id: summarize_action_failure_mechanism(records)
                    for stream_id, records in generation_streams[arm].items()
                },
            }

        uniform_e1 = statistics["primary_endpoint_1"]["UNIFORM_LEGAL_minus_LEARNED"]
        uniform_e2 = statistics["primary_endpoint_2"]["UNIFORM_LEGAL_minus_LEARNED"]
        uniform_macro = statistics["space_group_macro_primary_endpoint_1"][
            "UNIFORM_LEGAL_minus_LEARNED"
        ]
        decision = choose_cssd_robustness_decision(
            endpoint1_ci=uniform_e1["confidence_interval_95"],
            endpoint2_ci=uniform_e2["confidence_interval_95"],
            uniform_better_stream_fraction=e1_summaries["UNIFORM_LEGAL"][
                "baseline_better_stream_fraction"
            ],
            observed_macro_delta=uniform_macro[
                "observed_macro_delta_baseline_minus_learned"
            ],
            execution_complete=True,
        )
        prior_payload = _read_json(output_root / "EMPIRICAL_FREQUENCY_PRIOR.json")
        runtime_gate = all(
            record.get("runtime_assertions", {}).get("LEARNED_ACTION_LOGITS_USED")
            is False
            for streams in generation_streams.values()
            for records in streams.values()
            for record in records
        )
        data_gate = bool(
            prior_payload.get("training_split_used") == ["train_fit"]
            and prior_payload.get("validation_or_test_frequency_used") is False
            and prior_payload.get("audit", {}).get(
                "validation_or_test_label_count_accessed"
            )
            == 0
        )
        literature = dict(config["literature_scope_audit"])
        literature_gate = bool(
            literature.get("audit_type") == "SCOPED_PRIMARY_SOURCE_AUDIT"
            and literature.get("closest_work_pairwise_attribution_found") is False
            and literature.get("universal_priority_claim_made") is False
            and len(literature.get("primary_sources", [])) >= 4
        )
        statistical_gate = decision == "CSSD_ROBUST"
        original_program_gate = bool(
            config["original_core_hypothesis_retained"]
            and tuple(config["original_core_hypothesis"]) == ORIGINAL_CORE_HYPOTHESIS
        )
        gates = {
            "statistical_stream_replication": {
                "status": "PASS" if statistical_gate else "FAIL",
                "evidence": decision,
            },
            "runtime_policy_isolation": {
                "status": "PASS" if runtime_gate else "FAIL",
                "evidence": (
                    "12,000 baseline attempts assert "
                    "LEARNED_ACTION_LOGITS_USED=false"
                ),
            },
            "train_fit_data_boundary": {
                "status": "PASS" if data_gate else "FAIL",
                "evidence": (
                    f"{prior_payload.get('label_count')} train_fit labels; "
                    "validation/test frequency accesses=0"
                ),
            },
            "frozen_evidence_integrity": {
                "status": "PASS",
                "evidence": (
                    f"{previous_audit['verified_file_count']} prior attribution "
                    "files plus Phase2A/checkpoint/condition hashes verified"
                ),
            },
            "scoped_literature_differentiation": {
                "status": "PASS" if literature_gate else "FAIL",
                "evidence": literature.get("scoped_finding", "missing audit"),
            },
            "original_research_program_preserved": {
                "status": "PASS" if original_program_gate else "FAIL",
                "evidence": "original five-stage hypothesis retained; modules not run",
            },
        }
        all_gates_pass = all(payload["status"] == "PASS" for payload in gates.values())
        independence_status = (
            "CSSD_INDEPENDENT_CONTRIBUTION_SUPPORTED_IN_FROZEN_C0"
            if all_gates_pass
            else "CSSD_CONTRIBUTION_NOT_YET_LOCKED"
        )
        independence_audit = {
            "schema_version": "g1-contribution-independence-audit.1.0.0",
            "contribution_name": "Crystallographic Search-Space Dominance (CSSD)",
            "status": independence_status,
            "scope": "frozen C0-Symmetry architecture and 300-condition manifest",
            "gates": gates,
            "literature_scope_audit": literature,
            "universal_priority_claimed": False,
            "original_program_replaced": False,
        }

        failures_path = output_root / "POLICY_STREAM_ROBUSTNESS_FAILURES.jsonl"
        if not failures_path.exists():
            _write_text_new(failures_path, "")
        write_json_new(output_root / "POLICY_STREAM_ROBUSTNESS_METRICS.json", metrics)
        write_json_new(
            output_root / "POLICY_STREAM_HIERARCHICAL_STATISTICS.json",
            statistics,
        )
        write_json_new(
            output_root / "POLICY_STREAM_BY_SPACE_GROUP.json", by_space_group
        )
        write_json_new(output_root / "ACTION_FAILURE_MECHANISM_AUDIT.json", mechanism)
        write_json_new(
            output_root / "CONTRIBUTION_INDEPENDENCE_AUDIT.json",
            independence_audit,
        )
        _write_text_new(
            output_root / "POLICY_STREAM_ROBUSTNESS_RESULTS.md",
            _results_markdown(
                decision=decision,
                independence_status=independence_status,
                metrics=metrics,
                statistics=statistics,
                audit=independence_audit,
            ),
        )
        _write_text_new(
            output_root / "NEXT_SCIENTIFIC_DECISION.md",
            _decision_markdown(decision, independence_status, independence_audit),
        )
        missing = [
            filename
            for filename in FINAL_OUTPUTS
            if filename
            not in {
                "POLICY_STREAM_ROBUSTNESS_MANIFEST.json",
                "POLICY_STREAM_ROBUSTNESS_EXIT.json",
            }
            and not (output_root / filename).is_file()
        ]
        if missing:
            raise ValueError(f"required final outputs missing: {missing}")
        file_hashes = {
            path.relative_to(output_root).as_posix(): _sha256(path)
            for path in sorted(output_root.rglob("*"))
            if path.is_file()
            and path.name
            not in {
                "POLICY_STREAM_ROBUSTNESS_MANIFEST.json",
                "POLICY_STREAM_ROBUSTNESS_EXIT.json",
            }
        }
        manifest = {
            "schema_version": "g1-policy-stream-robustness-manifest.1.0.0",
            "result": decision,
            "contribution_independence_status": independence_status,
            "root_seed": int(config["root_seed"]),
            "condition_manifest_sha256": config["condition_manifest_sha256"],
            "checkpoint_sha256": config["checkpoint_sha256"],
            "phase2a_manifest_sha256": config["phase2a_manifest_sha256"],
            "previous_attribution_manifest_sha256": config[
                "previous_attribution_manifest_sha256"
            ],
            "policy_stream_count_per_arm": int(config["policy_stream_count"]),
            "fixed_cell_stream_indices": list(config["fixed_cell_stream_indices"]),
            "attempt_count_per_stream": int(config["attempt_count"]),
            "source_freeze": source_freeze,
            "file_sha256": file_hashes,
            "authorization": dict(config["authorization"]),
            "original_core_hypothesis_retained": True,
            "old_checkpoint_retraining": False,
            "phase2a_rebuilt": False,
            "refill_count": 0,
            "server_used": False,
            "three_seed_authorized": False,
            "dft_used": False,
            "cell_relaxation_repeated": False,
            "novelty_audit_repeated": False,
            "sealed_or_blind_data_accessed": False,
            "manifest_self_hash_omitted": True,
            "exit_file_hash_omitted": True,
            "stopped_after_policy_stream_robustness": True,
            "chgnet_config": asdict(_chgnet_config(config)),
        }
        write_json_new(output_root / "POLICY_STREAM_ROBUSTNESS_MANIFEST.json", manifest)
        manifest_hash = _sha256(output_root / "POLICY_STREAM_ROBUSTNESS_MANIFEST.json")
        write_json_new(
            output_root / "POLICY_STREAM_ROBUSTNESS_EXIT.json",
            {
                "schema_version": "g1-policy-stream-robustness-exit.1.0.0",
                "status": "PASS",
                "decision": decision,
                "contribution_independence_status": independence_status,
                "manifest_sha256": manifest_hash,
                "automatic_retry_performed": False,
                "server_used": False,
                "model_retraining": False,
                "three_seed_training_matrix": False,
                "sealed_or_blind_data_accessed": False,
                "stopped_after_completion": True,
            },
        )
        return output_root
    except Exception as error:
        _append_failure(output_root, stage="FINALIZE", error=error)
        exit_path = output_root / "POLICY_STREAM_ROBUSTNESS_EXIT.json"
        if not exit_path.exists():
            write_json_new(
                exit_path,
                {
                    "status": "FAIL",
                    "decision": "ATTRIBUTION_REPLICATION_INCONCLUSIVE",
                    "exception_type": type(error).__name__,
                    "exception_message": str(error),
                    "automatic_retry_performed": False,
                },
            )
        raise


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Run frozen C0 policy-stream robustness experiment"
    )
    parser.add_argument("--config", required=True)
    parser.add_argument(
        "--phase", required=True, choices=("generate", "fixed-cell", "finalize")
    )
    arguments = parser.parse_args()
    runners = {
        "generate": run_generate,
        "fixed-cell": run_fixed_cell,
        "finalize": run_finalize,
    }
    output = runners[arguments.phase](arguments.config)
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
