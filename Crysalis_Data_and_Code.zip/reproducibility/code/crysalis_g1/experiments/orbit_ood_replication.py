from __future__ import annotations

import hashlib
import math
from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Hashable, Mapping, Sequence


@dataclass(frozen=True)
class StrictUnseenCohort:
    parent_ids: tuple[str, ...]
    eligible_parent_n: int
    criterion_violation_n: int


@dataclass(frozen=True)
class OrbitOODVerdict:
    status: str
    replicated: dict[str, bool]
    next_action: str


def named_seed(root_seed: int, name: str) -> int:
    digest = hashlib.sha256(f"{root_seed}:{name}".encode("utf-8")).digest()
    return int.from_bytes(digest[:4], "little") & 0x7FFFFFFF


def _rank(seed: int, purpose: str, value: object) -> str:
    return hashlib.sha256(f"{seed}:{purpose}:{value}".encode("utf-8")).hexdigest()


def _stratified_order(
    parent_ids: Sequence[str],
    *,
    stratum_by_parent: Mapping[str, Hashable],
    seed: int,
    purpose: str,
) -> tuple[str, ...]:
    groups: dict[Hashable, list[str]] = defaultdict(list)
    for parent_id in parent_ids:
        groups[stratum_by_parent[parent_id]].append(parent_id)
    ranked: list[tuple[float, str, str]] = []
    for stratum, values in groups.items():
        ordered = sorted(
            values, key=lambda value: (_rank(seed, purpose, value), value)
        )
        for index, parent_id in enumerate(ordered):
            ranked.append(
                (
                    (index + 0.5) / len(ordered),
                    _rank(seed, f"{purpose}:tie", (repr(stratum), parent_id)),
                    parent_id,
                )
            )
    return tuple(item[2] for item in sorted(ranked))


def select_strict_unseen_cohort(
    *,
    training_parent_ids: Sequence[str],
    candidate_parent_ids: Sequence[str],
    key_by_parent: Mapping[str, Hashable],
    stratum_by_parent: Mapping[str, Hashable],
    target_n: int,
    seed: int,
    purpose: str,
) -> StrictUnseenCohort:
    training = tuple(dict.fromkeys(training_parent_ids))
    candidates = tuple(dict.fromkeys(candidate_parent_ids))
    if len(training) != len(training_parent_ids) or len(candidates) != len(
        candidate_parent_ids
    ):
        raise ValueError("parent IDs must be unique")
    if set(training) & set(candidates):
        raise ValueError("training and candidate parents must be disjoint")
    training_keys = Counter(key_by_parent[parent_id] for parent_id in training)
    eligible = [
        parent_id
        for parent_id in candidates
        if training_keys[key_by_parent[parent_id]] == 0
    ]
    if len(eligible) < target_n:
        raise ValueError(
            f"strict unseen cohort has {len(eligible)} candidates, fewer than {target_n}"
        )
    ordered = _stratified_order(
        eligible,
        stratum_by_parent=stratum_by_parent,
        seed=seed,
        purpose=purpose,
    )
    selected = ordered[:target_n]
    violations = sum(training_keys[key_by_parent[parent_id]] > 0 for parent_id in selected)
    return StrictUnseenCohort(
        parent_ids=selected,
        eligible_parent_n=len(eligible),
        criterion_violation_n=violations,
    )


def transition_motif(
    *,
    active_orbits: Sequence[Mapping[str, int]],
    remaining_composition: Mapping[str, int],
    next_multiplicity: int,
    next_free_dof_count: int,
) -> tuple[tuple[tuple[int, int], ...], tuple[int, ...], int, int]:
    active_summary = tuple(
        sorted(
            (
                int(orbit["multiplicity"]),
                int(orbit["free_dof_count"]),
            )
            for orbit in active_orbits
        )
    )
    remaining_class = tuple(
        sorted((int(value) for value in remaining_composition.values() if value > 0), reverse=True)
    )
    return (
        active_summary,
        remaining_class,
        int(next_multiplicity),
        int(next_free_dof_count),
    )


def rare_frequency_threshold(frequencies: Sequence[int]) -> int:
    if not frequencies:
        raise ValueError("at least one training motif frequency is required")
    distinct = sorted(set(int(value) for value in frequencies))
    rank = max(1, math.ceil(0.01 * len(distinct)))
    return distinct[rank - 1]


def select_transition_ood_cohort(
    *,
    motif_frequencies_by_parent: Mapping[str, Sequence[int]],
    maximum_frequency: int,
    stratum_by_parent: Mapping[str, Hashable],
    target_n: int,
    seed: int,
    purpose: str,
) -> StrictUnseenCohort:
    eligible = [
        parent_id
        for parent_id, frequencies in motif_frequencies_by_parent.items()
        if frequencies and min(int(value) for value in frequencies) <= maximum_frequency
    ]
    if len(eligible) < target_n:
        raise ValueError(
            f"rare/unseen transition cohort has {len(eligible)} candidates, "
            f"fewer than {target_n}"
        )
    ordered = _stratified_order(
        eligible,
        stratum_by_parent=stratum_by_parent,
        seed=seed,
        purpose=purpose,
    )
    selected = ordered[:target_n]
    violations = sum(
        min(int(value) for value in motif_frequencies_by_parent[parent_id])
        > maximum_frequency
        for parent_id in selected
    )
    return StrictUnseenCohort(
        parent_ids=selected,
        eligible_parent_n=len(eligible),
        criterion_violation_n=violations,
    )


def cohort_overlap_matrix(
    cohorts: Mapping[str, Sequence[str]],
) -> dict[str, dict[str, int]]:
    sets = {name: set(parent_ids) for name, parent_ids in cohorts.items()}
    return {
        left: {
            right: len(sets[left] & sets[right])
            for right in cohorts
        }
        for left in cohorts
    }


def orbit_ood_verdict(
    effects: Mapping[str, Mapping[str, float]],
) -> OrbitOODVerdict:
    if set(effects) != {"A", "B", "C"}:
        raise ValueError("effects must contain exactly A, B, and C")
    replicated = {
        name: value["delta_pp"] > 0 and value["ci_lower_pp"] > 0
        for name, value in effects.items()
    }
    replicated_n = sum(replicated.values())
    significant_reverse = any(value["ci_upper_pp"] < 0 for value in effects.values())
    if replicated_n >= 2 and not significant_reverse:
        status = "SUPPORTED"
    elif replicated_n == 0:
        status = "NOT_REPLICATED"
    else:
        status = "WEAK_OR_SPECIFIC"
    return OrbitOODVerdict(
        status=status,
        replicated=replicated,
        next_action=(
            "MODEL_AGNOSTIC_ORBIT_OOD_REPLICATION"
            if status == "SUPPORTED"
            else "STOP_DECONSTRUCTION_NC_CLAIM"
        ),
    )


def classify_generalization_mechanism(
    *,
    dead_end_reduction_count: int,
    later_onset_net_count: int,
    post_rare_completion_net_wins: int,
) -> str:
    ranked = (
        (int(dead_end_reduction_count), "REDUCED_NO_LEGAL_ACTION_DEAD_ENDS"),
        (int(later_onset_net_count), "LATER_DEAD_END_ONSET"),
        (
            int(post_rare_completion_net_wins),
            "BETTER_COMPLETION_AFTER_UNSEEN_TRANSITION",
        ),
    )
    best_value, best_name = max(ranked, key=lambda item: item[0])
    return best_name if best_value > 0 else "OTHER"
