from __future__ import annotations

import hashlib
import math
from collections import Counter, defaultdict
from dataclasses import dataclass, fields
from typing import Iterable, Mapping, Sequence

import torch
from torch import nn


@dataclass(frozen=True, slots=True)
class ParentStratum:
    parent_id: str
    crystal_system: str
    target_space_group: int
    orbit_count_bin: str
    free_dof_count_bin: str
    element_count_bin: str

    @property
    def full_key(self) -> tuple[object, ...]:
        return (
            self.crystal_system,
            self.target_space_group,
            self.orbit_count_bin,
            self.free_dof_count_bin,
            self.element_count_bin,
        )

    @property
    def fallback_key(self) -> tuple[object, ...]:
        return (
            self.crystal_system,
            self.orbit_count_bin,
            self.free_dof_count_bin,
        )


@dataclass(frozen=True, slots=True)
class ParentSplit:
    train_parent_ids: tuple[str, ...]
    validation_parent_ids: tuple[str, ...]
    tier_by_parent: Mapping[str, str]


def _seeded_parent_order(parent_id: str, seed: int) -> str:
    return hashlib.sha256(f"{int(seed)}:{parent_id}".encode("utf-8")).hexdigest()


def deterministic_parent_split(
    parents: Sequence[ParentStratum],
    *,
    validation_count: int,
    seed: int,
    minimum_full_stratum_size: int = 10,
) -> ParentSplit:
    if len({item.parent_id for item in parents}) != len(parents):
        raise ValueError("parent IDs must be unique")
    if not 0 < validation_count < len(parents):
        raise ValueError("validation count must leave non-empty train and validation")
    full_counts = Counter(item.full_key for item in parents)
    grouped: dict[tuple[object, ...], list[ParentStratum]] = defaultdict(list)
    tier_by_parent: dict[str, str] = {}
    for item in parents:
        if full_counts[item.full_key] >= minimum_full_stratum_size:
            key = ("FULL", *item.full_key)
            tier = "FULL"
        else:
            key = ("FALLBACK", *item.fallback_key)
            tier = "FALLBACK"
        grouped[key].append(item)
        tier_by_parent[item.parent_id] = tier

    total = len(parents)
    allocation = {
        key: math.floor(len(rows) * validation_count / total)
        for key, rows in grouped.items()
    }
    missing = validation_count - sum(allocation.values())
    remainders = sorted(
        grouped,
        key=lambda key: (
            -(len(grouped[key]) * validation_count / total - allocation[key]),
            repr(key),
        ),
    )
    for key in remainders[:missing]:
        allocation[key] += 1

    validation: set[str] = set()
    for key, rows in grouped.items():
        ordered = sorted(
            rows, key=lambda item: (_seeded_parent_order(item.parent_id, seed), item.parent_id)
        )
        validation.update(item.parent_id for item in ordered[: allocation[key]])
    all_ids = {item.parent_id for item in parents}
    if len(validation) != validation_count:
        raise RuntimeError("stratified allocation did not produce the requested size")
    train = all_ids - validation
    return ParentSplit(
        train_parent_ids=tuple(sorted(train)),
        validation_parent_ids=tuple(sorted(validation)),
        tier_by_parent=tier_by_parent,
    )


@dataclass(frozen=True, slots=True)
class ObservedStateNode:
    parent_id: str
    active_orbit_ids: tuple[str, ...]
    positive_orbit_ids: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class OrbitPolicyBatch:
    composition: torch.Tensor
    remaining_composition: torch.Tensor
    target_sg: torch.Tensor
    lattice: torch.Tensor
    progress: torch.Tensor
    active_species: torch.Tensor
    active_wyckoff: torch.Tensor
    active_multiplicity: torch.Tensor
    active_dof: torch.Tensor
    active_free_parameters: torch.Tensor
    active_representative: torch.Tensor
    active_mask: torch.Tensor
    candidate_species: torch.Tensor
    candidate_wyckoff: torch.Tensor
    candidate_multiplicity: torch.Tensor
    candidate_dof: torch.Tensor
    candidate_feasibility: torch.Tensor
    legal_mask: torch.Tensor
    positive_mask: torch.Tensor

    def to(self, device: torch.device | str) -> "OrbitPolicyBatch":
        return OrbitPolicyBatch(
            **{field.name: getattr(self, field.name).to(device) for field in fields(self)}
        )


def _masked_mean(values: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    weight = mask.to(values.dtype).unsqueeze(-1)
    return (values * weight).sum(dim=1) / weight.sum(dim=1).clamp_min(1.0)


class OrbitInversePolicy(nn.Module):
    """Small relation-free scorer over compiler-legal orbit actions."""

    def __init__(self) -> None:
        super().__init__()
        self.species_embedding = nn.Embedding(119, 16, padding_idx=0)
        self.wyckoff_embedding = nn.Embedding(26, 8)
        self.space_group_embedding = nn.Embedding(231, 16)
        self.dof_embedding = nn.Embedding(4, 4)
        self.composition_encoder = nn.Sequential(
            nn.Linear(119, 32), nn.SiLU(), nn.Linear(32, 32), nn.SiLU()
        )
        self.remaining_encoder = nn.Sequential(
            nn.Linear(119, 32), nn.SiLU(), nn.Linear(32, 32), nn.SiLU()
        )
        self.lattice_encoder = nn.Sequential(
            nn.Linear(9, 32), nn.SiLU(), nn.Linear(32, 32), nn.SiLU()
        )
        self.active_encoder = nn.Sequential(
            nn.Linear(41, 64), nn.SiLU(), nn.Linear(64, 64), nn.SiLU()
        )
        self.state_encoder = nn.Sequential(
            nn.Linear(177, 128), nn.SiLU(), nn.Linear(128, 128), nn.SiLU()
        )
        self.candidate_encoder = nn.Sequential(
            nn.Linear(32, 64), nn.SiLU(), nn.Linear(64, 64), nn.SiLU()
        )
        self.scorer = nn.Sequential(
            nn.Linear(192, 128), nn.SiLU(), nn.Linear(128, 1)
        )

    @staticmethod
    def _circular(values: torch.Tensor) -> torch.Tensor:
        return torch.cat(
            (torch.sin(2.0 * torch.pi * values), torch.cos(2.0 * torch.pi * values)),
            dim=-1,
        )

    def forward(self, batch: OrbitPolicyBatch) -> torch.Tensor:
        active_token = torch.cat(
            (
                self.species_embedding(batch.active_species),
                self.wyckoff_embedding(batch.active_wyckoff),
                batch.active_multiplicity.unsqueeze(-1),
                self.dof_embedding(batch.active_dof),
                self._circular(batch.active_free_parameters),
                self._circular(batch.active_representative),
            ),
            dim=-1,
        )
        active = _masked_mean(self.active_encoder(active_token), batch.active_mask)
        state = self.state_encoder(
            torch.cat(
                (
                    self.composition_encoder(batch.composition),
                    self.remaining_encoder(batch.remaining_composition),
                    self.lattice_encoder(batch.lattice),
                    self.space_group_embedding(batch.target_sg),
                    active,
                    batch.progress,
                ),
                dim=-1,
            )
        )
        candidate = self.candidate_encoder(
            torch.cat(
                (
                    self.species_embedding(batch.candidate_species),
                    self.wyckoff_embedding(batch.candidate_wyckoff),
                    batch.candidate_multiplicity.unsqueeze(-1),
                    self.dof_embedding(batch.candidate_dof),
                    batch.candidate_feasibility,
                ),
                dim=-1,
            )
        )
        expanded_state = state.unsqueeze(1).expand(-1, candidate.shape[1], -1)
        logits = self.scorer(torch.cat((expanded_state, candidate), dim=-1)).squeeze(-1)
        return logits.masked_fill(~batch.legal_mask, -torch.inf)


def build_observed_state_nodes(
    trajectories: Iterable[Mapping[str, object]],
) -> dict[tuple[str, tuple[str, ...]], ObservedStateNode]:
    positives: dict[tuple[str, tuple[str, ...]], set[str]] = defaultdict(set)
    for trajectory in trajectories:
        parent_id = str(trajectory["parent_structure_id"])
        active: set[str] = set()
        for action in trajectory["inverse_actions"]:  # type: ignore[index]
            target_id = str(action["target_id"])
            if target_id in active:
                raise ValueError("registered trajectory restores an active orbit")
            key = (parent_id, tuple(sorted(active)))
            positives[key].add(target_id)
            active.add(target_id)
    return {
        key: ObservedStateNode(key[0], key[1], tuple(sorted(values)))
        for key, values in sorted(positives.items())
    }


def set_marginal_nll(
    logits: torch.Tensor,
    positive_mask: torch.Tensor,
    legal_mask: torch.Tensor,
) -> torch.Tensor:
    if logits.shape != positive_mask.shape or logits.shape != legal_mask.shape:
        raise ValueError("logit and action masks must have identical shapes")
    if not torch.all(positive_mask <= legal_mask):
        raise ValueError("positive actions must be legal")
    if not torch.all(positive_mask.any(dim=-1)):
        raise ValueError("every state must have at least one positive action")
    masked_logits = logits.masked_fill(~legal_mask, -torch.inf)
    log_probability = torch.log_softmax(masked_logits, dim=-1)
    positive_log_mass = torch.logsumexp(
        log_probability.masked_fill(~positive_mask, -torch.inf), dim=-1
    )
    return -positive_log_mass.mean()


__all__ = [
    "ObservedStateNode",
    "OrbitInversePolicy",
    "OrbitPolicyBatch",
    "ParentSplit",
    "ParentStratum",
    "build_observed_state_nodes",
    "deterministic_parent_split",
    "set_marginal_nll",
]
