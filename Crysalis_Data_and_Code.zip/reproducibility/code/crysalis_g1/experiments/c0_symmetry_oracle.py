from __future__ import annotations

import argparse
import hashlib
import json
import math
import time
from collections import Counter
from pathlib import Path
from typing import Any, Iterable

import numpy as np

from crysalis_g1.experiments.c0_symmetry_reconstruction import (
    RecoveredParent,
)
from crysalis_g1.symmetry.assembly import (
    AddOrbitAction,
    C0SymmetryProjector,
    IllegalAssemblyAction,
    ProjectionReceipt,
    SpaceGroupLegalActionCompiler,
    SymmetryAssemblyState,
)


def _read_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            try:
                yield json.loads(line)
            except json.JSONDecodeError as error:
                raise ValueError(f"invalid JSONL at {path}:{line_number}") from error


def load_recovered_parents(path: str | Path) -> dict[str, RecoveredParent]:
    result = {}
    for payload in _read_jsonl(Path(path)):
        parent = RecoveredParent.from_dict(payload)
        if parent.material_id in result:
            raise ValueError(f"duplicate recovered parent: {parent.material_id}")
        result[parent.material_id] = parent
    if not result:
        raise ValueError("recovered parent cache is empty")
    return result


def _fixed_lattice_structure_match(
    parent: RecoveredParent,
    atomic_numbers: tuple[int, ...],
    coordinates: tuple[tuple[float, float, float], ...],
    lattice: tuple[tuple[float, float, float], ...],
) -> tuple[bool, float]:
    target_lattice = np.asarray(parent.lattice.primitive_matrix, dtype=float)
    if not np.allclose(
        np.asarray(lattice, dtype=float), target_lattice, rtol=1e-10, atol=1e-10
    ):
        return False, math.inf
    target_numbers = parent.reconstructed_atomic_numbers
    if Counter(atomic_numbers) != Counter(target_numbers):
        return False, math.inf
    target_coordinates = np.asarray(
        parent.reconstructed_fractional_coordinates, dtype=float
    )
    candidate_coordinates = np.asarray(coordinates, dtype=float)
    maximum = 0.0
    for species in sorted(set(target_numbers)):
        left = candidate_coordinates[np.asarray(atomic_numbers) == species]
        right = target_coordinates[np.asarray(target_numbers) == species]
        unmatched = list(range(len(right)))
        for coordinate in left:
            distances = []
            for index in unmatched:
                delta = coordinate - right[index]
                delta -= np.round(delta)
                distances.append(
                    (float(np.linalg.norm(delta @ target_lattice)), index)
                )
            distance, selected = min(distances)
            maximum = max(maximum, distance)
            unmatched.remove(selected)
    return maximum <= 1e-6, maximum


def replay_inverse_actions(
    parent: RecoveredParent,
    inverse_actions: Iterable[dict[str, Any]],
    *,
    max_sites: int,
    minimum_distance: float = 0.5,
    receipt_cache: dict[tuple[str, ...], ProjectionReceipt] | None = None,
) -> dict[str, Any]:
    target_orbits = {
        orbit.orbit_instance_id: orbit for orbit in parent.orbits
    }
    composition = Counter()
    for orbit in parent.orbits:
        composition[orbit.species] += orbit.multiplicity
    state = SymmetryAssemblyState.empty(
        target_space_group=parent.target_space_group,
        composition=tuple(sorted(composition.items())),
        lattice=parent.lattice,
    )
    compiler = SpaceGroupLegalActionCompiler(max_sites=max_sites)
    projector = C0SymmetryProjector(minimum_distance=minimum_distance)
    steps = []
    try:
        for step_index, payload in enumerate(inverse_actions):
            if payload.get("operator") != "D_orbit" or payload.get("mode") != "RESTORE":
                raise IllegalAssemblyAction(
                    "INVALID_INVERSE_ACTION", json.dumps(payload, sort_keys=True)
                )
            orbit_id = str(payload["target_id"])
            target = target_orbits.get(orbit_id)
            if target is None:
                raise IllegalAssemblyAction("UNKNOWN_ORBIT", orbit_id)
            state = compiler.apply_add(
                state,
                AddOrbitAction(
                    wyckoff_letter=target.wyckoff_letter,
                    species=target.species,
                    free_parameters=target.free_parameters,
                    orbit_instance_id=target.orbit_instance_id,
                ),
            )
            cache_key = tuple(
                sorted(orbit.orbit_instance_id for orbit in state.orbits)
            )
            receipt = None if receipt_cache is None else receipt_cache.get(cache_key)
            if receipt is None:
                receipt = projector.project(state)
                if receipt_cache is not None:
                    receipt_cache[cache_key] = receipt
            steps.append(
                {
                    "step_index": step_index,
                    "orbit_instance_id": orbit_id,
                    "remaining_composition": [
                        list(value) for value in state.remaining_composition
                    ],
                    "projector": receipt.to_dict(),
                }
            )
            if not receipt.accepted:
                raise IllegalAssemblyAction(
                    "PROJECTOR_REJECTED",
                    f"step={step_index}, reasons={receipt.reason_codes}",
                )
        final_key = tuple(sorted(orbit.orbit_instance_id for orbit in state.orbits))
        final_receipt = (
            None if receipt_cache is None else receipt_cache.get(final_key)
        )
        if final_receipt is None:
            final_receipt = projector.project(state)
            if receipt_cache is not None:
                receipt_cache[final_key] = final_receipt
    except (IllegalAssemblyAction, ValueError) as error:
        return {
            "passed": False,
            "reason_code": getattr(error, "reason_code", type(error).__name__),
            "detail": str(error),
            "step_count": len(steps),
            "steps": steps,
        }
    target_ids = set(target_orbits)
    restored_ids = {orbit.orbit_instance_id for orbit in state.orbits}
    target_multiplicities = {
        orbit.orbit_instance_id: orbit.multiplicity for orbit in parent.orbits
    }
    restored_multiplicities = {
        orbit.orbit_instance_id: orbit.multiplicity for orbit in state.orbits
    }
    structure_restored, structure_residual = _fixed_lattice_structure_match(
        parent,
        final_receipt.atomic_numbers,
        final_receipt.fractional_coordinates,
        final_receipt.lattice,
    )
    composition_restored = (
        Counter(final_receipt.atomic_numbers) == composition
        and not state.remaining_composition
    )
    orbit_identities_restored = restored_ids == target_ids
    multiplicities_restored = restored_multiplicities == target_multiplicities
    target_space_group_restored = (
        final_receipt.detected_space_groups.get(0.03)
        == parent.target_space_group
    )
    lattice_restored = bool(
        np.allclose(
            np.asarray(final_receipt.lattice),
            np.asarray(parent.lattice.primitive_matrix),
            rtol=1e-10,
            atol=1e-10,
        )
    )
    termination_legal = compiler.can_terminate(state, final_receipt)
    checks = (
        composition_restored,
        orbit_identities_restored,
        multiplicities_restored,
        target_space_group_restored,
        lattice_restored,
        structure_restored,
        termination_legal,
    )
    return {
        "passed": all(checks),
        "composition_restored": composition_restored,
        "orbit_identities_restored": orbit_identities_restored,
        "multiplicities_restored": multiplicities_restored,
        "target_space_group_restored": target_space_group_restored,
        "lattice_restored": lattice_restored,
        "structure_restored": structure_restored,
        "structure_residual_angstrom": structure_residual,
        "termination_legal": termination_legal,
        "step_count": len(steps),
        "steps": steps,
        "final_projector": final_receipt.to_dict(),
    }


def _trajectory_result(
    row: dict[str, Any],
    parents: dict[str, RecoveredParent],
    *,
    max_sites: int,
    minimum_distance: float,
    include_steps: bool,
    receipt_cache: dict[tuple[str, ...], ProjectionReceipt] | None = None,
) -> dict[str, Any]:
    parent_id = str(row["parent_structure_id"])
    parent = parents.get(parent_id)
    if parent is None:
        return {
            "passed": False,
            "parent_structure_id": parent_id,
            "path_index": int(row["path_index"]),
            "sequence_hash": str(row["sequence_hash"]),
            "reason_code": "RECOVERED_PARENT_MISSING",
        }
    result = replay_inverse_actions(
        parent,
        row["inverse_actions"],
        max_sites=max_sites,
        minimum_distance=minimum_distance,
        receipt_cache=receipt_cache,
    )
    result.update(
        {
            "parent_structure_id": parent_id,
            "path_index": int(row["path_index"]),
            "sequence_hash": str(row["sequence_hash"]),
        }
    )
    if not include_steps:
        result.pop("steps", None)
        result.pop("final_projector", None)
    return result


def run_inverse_oracle(
    phase2a_root: str | Path,
    recovered_parent_cache: str | Path,
    *,
    root_seed: int,
    max_sites: int,
    minimum_distance: float = 0.5,
    sample_only: bool = False,
) -> dict[str, Any]:
    started = time.perf_counter()
    parents = load_recovered_parents(recovered_parent_cache)
    rows = tuple(
        _read_jsonl(Path(phase2a_root) / "trajectories" / "d_orbit.jsonl")
    )
    parent_ids = sorted(
        {str(row["parent_structure_id"]) for row in rows},
        key=lambda value: hashlib.sha256(
            f"oracle-sample:{root_seed}:{value}".encode()
        ).hexdigest(),
    )
    sample_ids = set(parent_ids[: min(100, len(parent_ids))])
    sample_rows = [
        row for row in rows if str(row["parent_structure_id"]) in sample_ids
    ]
    projector_cache: dict[
        str, dict[tuple[str, ...], ProjectionReceipt]
    ] = {}

    def evaluate(selected_rows: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
        return [
            _trajectory_result(
                row,
                parents,
                max_sites=max_sites,
                minimum_distance=minimum_distance,
                include_steps=False,
                receipt_cache=projector_cache.setdefault(
                    str(row["parent_structure_id"]), {}
                ),
            )
            for row in selected_rows
        ]

    sample_results = evaluate(sample_rows)
    sample_failures = [result for result in sample_results if not result["passed"]]
    if sample_failures:
        return {
            "schema_version": "g1-c0-symmetry-oracle.1.0.0",
            "root_seed": root_seed,
            "sample_parent_count": len(sample_ids),
            "sample_trajectory_count": len(sample_rows),
            "sample_passed": False,
            "sample_failures": sample_failures,
            "all_applicable_executed": False,
            "passed": False,
            "elapsed_seconds": time.perf_counter() - started,
        }
    if sample_only:
        return {
            "schema_version": "g1-c0-symmetry-oracle.1.0.0",
            "root_seed": root_seed,
            "sample_parent_count": len(sample_ids),
            "sample_parent_ids": sorted(sample_ids),
            "sample_trajectory_count": len(sample_rows),
            "sample_pass_count": len(sample_results),
            "sample_passed": True,
            "all_applicable_executed": False,
            "passed": True,
            "elapsed_seconds": time.perf_counter() - started,
        }
    all_results = evaluate(rows)
    failures = [result for result in all_results if not result["passed"]]
    residuals = [
        float(result["structure_residual_angstrom"])
        for result in all_results
        if result["passed"]
        and math.isfinite(float(result["structure_residual_angstrom"]))
    ]
    return {
        "schema_version": "g1-c0-symmetry-oracle.1.0.0",
        "root_seed": root_seed,
        "sample_parent_count": len(sample_ids),
        "sample_parent_ids": sorted(sample_ids),
        "sample_trajectory_count": len(sample_rows),
        "sample_pass_count": len(sample_results),
        "sample_passed": True,
        "all_applicable_executed": True,
        "applicable_parent_count": len(parent_ids),
        "applicable_trajectory_count": len(rows),
        "pass_count": len(all_results) - len(failures),
        "failure_count": len(failures),
        "structure_residual_angstrom": {
            "maximum": max(residuals) if residuals else None,
            "mean": sum(residuals) / len(residuals) if residuals else None,
        },
        "failures": failures,
        "passed": not failures,
        "elapsed_seconds": time.perf_counter() - started,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Replay the C0-Symmetry D_orbit inverse assembly oracle"
    )
    parser.add_argument("--phase2a-root", type=Path, required=True)
    parser.add_argument("--recovered-parent-cache", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--root-seed", type=int, default=20260823)
    parser.add_argument("--max-sites", type=int, default=20)
    parser.add_argument("--minimum-distance", type=float, default=0.5)
    parser.add_argument("--sample-only", action="store_true")
    args = parser.parse_args()
    report = run_inverse_oracle(
        args.phase2a_root,
        args.recovered_parent_cache,
        root_seed=args.root_seed,
        max_sites=args.max_sites,
        minimum_distance=args.minimum_distance,
        sample_only=args.sample_only,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps(report, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
