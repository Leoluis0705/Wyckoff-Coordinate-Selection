from __future__ import annotations

import json
import math
import os
import time
from dataclasses import dataclass
from pathlib import Path
from statistics import median
from typing import Any

import numpy as np
import torch

from crysalis_g1.actions import ActionType
from crysalis_g1.experiments.local_pilot_data import AssemblyTrainingBatch


_FORBIDDEN_CONDITION_FIELDS = {
    "material_id",
    "parent_coordinates",
    "parent_lattice",
    "canonical_structure_hash",
    "orbit_count",
    "wyckoff_sequence",
    "trajectory_length",
}


@dataclass(frozen=True, slots=True)
class FreeRolloutConfig:
    root_seed: int
    max_assembly_steps: int
    max_orbits: int
    short_contact_distance: float
    device: str
    mixed_precision: bool
    sampling_temperature: float = 1.0
    coordinate_proposal_budget: int = 16

    def __post_init__(self) -> None:
        if self.root_seed != 20260823:
            raise ValueError("free rollout root seed must remain 20260823")
        if self.max_assembly_steps <= 0 or self.max_orbits <= 0:
            raise ValueError("free rollout budgets must be positive")
        if self.short_contact_distance <= 0:
            raise ValueError("short-contact distance must be positive")
        if self.device not in {"cpu", "cuda"}:
            raise ValueError("free rollout device must be cpu or cuda")
        if self.mixed_precision and self.device != "cuda":
            raise ValueError("mixed precision requires CUDA")
        if self.sampling_temperature <= 0:
            raise ValueError("sampling temperature must be positive")
        if self.coordinate_proposal_budget <= 0:
            raise ValueError("coordinate proposal budget must be positive")


@dataclass(frozen=True, slots=True)
class _GeneratedOrbit:
    atomic_number: int
    multiplicity: int
    wyckoff_index: int
    representative: tuple[float, float, float]
    expanded: tuple[tuple[float, float, float], ...]


def _canonical_json(payload: object) -> str:
    return json.dumps(
        payload,
        ensure_ascii=False,
        allow_nan=False,
        separators=(",", ":"),
        sort_keys=True,
    )


def _composition_vector(
    composition: list[list[int]], *, device: torch.device
) -> torch.Tensor:
    value = torch.zeros((1, 119), dtype=torch.float32, device=device)
    for atomic_number, count in composition:
        if not 1 <= int(atomic_number) <= 118 or int(count) <= 0:
            raise ValueError("rollout composition entries must be positive")
        value[0, int(atomic_number)] = int(count)
    return value


def _state_batch(
    *,
    condition: dict[str, Any],
    remaining_counts: dict[int, int],
    orbits: list[_GeneratedOrbit],
    active_edges: list[tuple[int, int]],
    lattice: np.ndarray,
    step: int,
    config: FreeRolloutConfig,
    device: torch.device,
) -> AssemblyTrainingBatch:
    composition = _composition_vector(condition["composition"], device=device)
    remaining = torch.zeros_like(composition)
    for atomic_number, count in remaining_counts.items():
        if count > 0:
            remaining[0, atomic_number] = count
    node_count = max(1, len(orbits))
    node_atomic_numbers = torch.zeros((1, node_count), dtype=torch.long, device=device)
    node_multiplicities = torch.zeros_like(node_atomic_numbers)
    node_wyckoff_indices = torch.zeros_like(node_atomic_numbers)
    node_coordinates = torch.zeros((1, node_count, 3), device=device)
    node_mask = torch.zeros((1, node_count), dtype=torch.bool, device=device)
    for index, orbit in enumerate(orbits):
        node_atomic_numbers[0, index] = orbit.atomic_number
        node_multiplicities[0, index] = orbit.multiplicity
        node_wyckoff_indices[0, index] = orbit.wyckoff_index
        node_coordinates[0, index] = torch.tensor(
            orbit.representative, device=device
        )
        node_mask[0, index] = True
    pairs = list(active_edges)
    relation_count = max(1, len(pairs))
    relation_invariants = torch.zeros((1, relation_count, 11), device=device)
    relation_availability = torch.zeros(
        (1, relation_count, 11), dtype=torch.bool, device=device
    )
    relation_vectors = torch.zeros((1, relation_count, 3), device=device)
    relation_sources = torch.zeros((1, relation_count), dtype=torch.long, device=device)
    relation_targets = torch.zeros_like(relation_sources)
    relation_mask = torch.zeros((1, relation_count), dtype=torch.bool, device=device)
    lattice_tensor = torch.tensor(lattice, dtype=torch.float32, device=device)[None]
    degrees = max(0, len(orbits) - 1)
    progress = min(step / config.max_assembly_steps, 1.0)
    for edge_index, (source, target) in enumerate(pairs):
        delta = (
            node_coordinates[0, target] - node_coordinates[0, source]
        )
        delta = delta - torch.round(delta)
        vector = delta @ lattice_tensor[0]
        relation_vectors[0, edge_index] = vector
        relation_invariants[0, edge_index, 0] = torch.linalg.vector_norm(vector)
        relation_invariants[0, edge_index, 2:4] = float(degrees)
        relation_invariants[0, edge_index, 10] = progress
        relation_availability[0, edge_index, [0, 2, 3, 10]] = True
        relation_sources[0, edge_index] = source
        relation_targets[0, edge_index] = target
        relation_mask[0, edge_index] = True
    return AssemblyTrainingBatch(
        composition=composition,
        remaining=remaining,
        space_group=torch.tensor([int(condition["space_group"])], device=device),
        progress=torch.tensor([[progress]], device=device),
        node_atomic_numbers=node_atomic_numbers,
        node_multiplicities=node_multiplicities,
        node_wyckoff_indices=node_wyckoff_indices,
        node_fractional_coordinates=node_coordinates,
        node_mask=node_mask,
        input_lattice=lattice_tensor,
        relation_invariants=relation_invariants,
        relation_availability=relation_availability,
        relation_vectors=relation_vectors,
        relation_sources=relation_sources,
        relation_targets=relation_targets,
        relation_mask=relation_mask,
        target_action=torch.tensor(
            [list(ActionType).index(ActionType.UPDATE_LATTICE)], device=device
        ),
        target_atomic_number=torch.zeros(1, dtype=torch.long, device=device),
        target_multiplicity=torch.zeros(1, dtype=torch.long, device=device),
        target_wyckoff_index=torch.zeros(1, dtype=torch.long, device=device),
        target_fractional_coordinates=torch.zeros((1, 3), device=device),
        target_lattice=lattice_tensor.clone(),
        target_orbit_mask=torch.zeros(1, dtype=torch.bool, device=device),
        target_relation_mask=torch.zeros(1, dtype=torch.bool, device=device),
        target_relation_sources=torch.zeros(1, dtype=torch.long, device=device),
        target_relation_targets=torch.zeros(1, dtype=torch.long, device=device),
        target_relation_distance=torch.zeros(1, device=device),
        example_ids=(str(condition["condition_id"]),),
    )


def _sample_index(
    logits: torch.Tensor,
    *,
    generator: torch.Generator,
    temperature: float,
    legal_mask: torch.Tensor | None = None,
) -> int:
    value = logits.detach().float()
    if legal_mask is not None:
        value = value.masked_fill(~legal_mask, -torch.inf)
    probabilities = torch.softmax(value / temperature, dim=-1)
    if not torch.isfinite(probabilities).all() or float(probabilities.sum()) <= 0:
        raise FloatingPointError("rollout categorical probabilities are non-finite")
    return int(torch.multinomial(probabilities, 1, generator=generator).item())


def _expand_orbit(
    representative: tuple[float, float, float], multiplicity: int
) -> tuple[tuple[float, float, float], ...]:
    if multiplicity == 1:
        return (representative,)
    golden = np.asarray((0.61803398875, 0.41421356237, 0.73205080757))
    base = np.asarray(representative)
    return tuple(
        tuple(float(value) for value in np.remainder(base + index * golden, 1.0))
        for index in range(multiplicity)
    )


def _minimum_distance(
    fractional: np.ndarray, lattice: np.ndarray
) -> float:
    if len(fractional) < 2:
        return math.inf
    best = math.inf
    translations = np.asarray(
        [(i, j, k) for i in (-1, 0, 1) for j in (-1, 0, 1) for k in (-1, 0, 1)],
        dtype=float,
    )
    for source in range(len(fractional)):
        for target in range(source + 1, len(fractional)):
            vectors = (fractional[target] - fractional[source] + translations) @ lattice
            best = min(best, float(np.linalg.norm(vectors, axis=1).min()))
    return best


def _candidate_payload(
    orbits: list[_GeneratedOrbit], lattice: np.ndarray
) -> dict[str, Any]:
    atomic_numbers: list[int] = []
    coordinates: list[list[float]] = []
    for orbit in orbits:
        atomic_numbers.extend([orbit.atomic_number] * orbit.multiplicity)
        coordinates.extend([list(value) for value in orbit.expanded])
    return {
        "atomic_numbers": atomic_numbers,
        "fractional_coordinates": coordinates,
        "lattice": lattice.tolist(),
        "orbit_count": len(orbits),
    }


def _compile_orbit_coordinate(
    *,
    base_representative: tuple[float, float, float],
    species: int,
    multiplicity: int,
    wyckoff: int,
    existing_orbits: list[_GeneratedOrbit],
    lattice: np.ndarray,
    generator: torch.Generator,
    device: torch.device,
    proposal_budget: int,
    minimum_distance: float,
) -> tuple[_GeneratedOrbit | None, int, float, float | None]:
    base = torch.tensor(base_representative, dtype=torch.float32, device=device)
    best_distance: float | None = None
    for proposal_index in range(proposal_budget):
        if proposal_index == 0:
            proposal = base
        elif proposal_index == proposal_budget - 1:
            proposal = torch.rand(3, generator=generator, device=device)
        else:
            scale = min(0.05 + 0.025 * proposal_index, 0.35)
            proposal = torch.remainder(
                base
                + torch.randn(3, generator=generator, device=device) * scale,
                1.0,
            )
        representative = tuple(float(value) for value in proposal.cpu().tolist())
        candidate = _GeneratedOrbit(
            species,
            multiplicity,
            wyckoff,
            representative,
            _expand_orbit(representative, multiplicity),
        )
        payload = _candidate_payload([*existing_orbits, candidate], lattice)
        distance = _minimum_distance(
            np.asarray(payload["fractional_coordinates"], dtype=float), lattice
        )
        best_distance = (
            distance
            if best_distance is None
            else max(best_distance, distance)
        )
        if math.isinf(distance) or distance >= minimum_distance:
            delta = np.asarray(representative) - np.asarray(base_representative)
            delta -= np.round(delta)
            correction = float(np.linalg.norm(delta @ lattice))
            return candidate, proposal_index + 1, correction, distance
    return None, proposal_budget, 0.0, best_distance


def _run_one(
    *,
    model: torch.nn.Module,
    condition: dict[str, Any],
    config: FreeRolloutConfig,
    device: torch.device,
) -> dict[str, Any]:
    if _FORBIDDEN_CONDITION_FIELDS.intersection(condition):
        raise ValueError("free rollout condition contains forbidden parent information")
    if int(condition["root_seed"]) != config.root_seed:
        raise ValueError("condition root seed mismatch")
    generator = torch.Generator(device=device.type).manual_seed(
        int(condition["condition_seed"])
    )
    composition = {
        int(atomic_number): int(count)
        for atomic_number, count in condition["composition"]
    }
    remaining = dict(composition)
    atom_count = sum(composition.values())
    initial_length = 3.0 + atom_count ** (1.0 / 3.0)
    lattice = np.eye(3, dtype=float) * initial_length
    orbits: list[_GeneratedOrbit] = []
    active_edges: list[tuple[int, int]] = []
    actions: list[dict[str, Any]] = []
    memory_trace: list[list[float]] = []
    memory = torch.zeros(
        (1, int(model.config.relation_memory_dim)),
        dtype=torch.float32,
        device=device,
    )
    completed = False
    failure_code: str | None = None
    pre_valid: list[bool] = []
    post_valid: list[bool] = []
    corrections: list[float] = []
    started = time.perf_counter()
    for step in range(config.max_assembly_steps):
        batch = _state_batch(
            condition=condition,
            remaining_counts=remaining,
            orbits=orbits,
            active_edges=active_edges,
            lattice=lattice,
            step=step,
            config=config,
            device=device,
        )
        with torch.no_grad(), torch.autocast(
            device_type=device.type,
            dtype=torch.float16,
            enabled=config.mixed_precision,
        ):
            output = model(batch, relation_memory=memory)
        memory = output.next_relation_memory.detach().float()
        memory_trace.append(memory[0].cpu().tolist())
        action_legal = output.legal_action_mask[0].clone()
        available_pairs = [
            (source, target)
            for source in range(len(orbits))
            for target in range(source + 1, len(orbits))
            if (source, target) not in set(active_edges)
        ]
        if not available_pairs:
            action_legal[
                list(ActionType).index(ActionType.ADD_PERIODIC_EDGE)
            ] = False
        if len(orbits) >= config.max_orbits:
            action_legal[list(ActionType).index(ActionType.ADD_ORBIT)] = False
        action_index = _sample_index(
            output.action_logits[0],
            generator=generator,
            temperature=config.sampling_temperature,
            legal_mask=action_legal,
        )
        action_type = list(ActionType)[action_index]
        receipt: dict[str, Any] = {
            "step": step,
            "action_type": action_type.value,
            "accepted": True,
            "projector_pre_valid": bool(output.first_projection.pre_valid[0]),
            "projector_post_valid": bool(output.final_projection.post_valid[0]),
            "projector_rejected": bool(output.final_projection.rejected[0]),
            "projector_correction_amount": float(
                output.final_projection.correction_amount[0].detach().cpu()
            ),
            "projector_reason_codes": list(output.final_projection.reason_codes[0]),
            "second_projector_applied": output.second_projector_applied,
        }
        if action_type is ActionType.ADD_ORBIT:
            if len(orbits) >= config.max_orbits:
                receipt["accepted"] = False
                receipt["reason_code"] = "MAX_ORBITS"
            else:
                species = _sample_index(
                    output.species_logits[0],
                    generator=generator,
                    temperature=config.sampling_temperature,
                    legal_mask=batch.remaining[0] > 0,
                )
                multiplicity_legal = torch.zeros(13, dtype=torch.bool, device=device)
                multiplicity_legal[1 : min(12, remaining[species]) + 1] = True
                multiplicity = _sample_index(
                    output.multiplicity_logits[0],
                    generator=generator,
                    temperature=config.sampling_temperature,
                    legal_mask=multiplicity_legal,
                )
                wyckoff = _sample_index(
                    output.wyckoff_logits[0],
                    generator=generator,
                    temperature=config.sampling_temperature,
                )
                representative = tuple(
                    float(value)
                    for value in output.predicted_fractional_coordinate[0]
                    .detach()
                    .float()
                    .cpu()
                    .tolist()
                )
                candidate_lattice = (
                    output.predicted_lattice[0].detach().float().cpu().numpy()
                )
                compiled, proposal_count, correction, compiled_distance = (
                    _compile_orbit_coordinate(
                        base_representative=representative,
                        species=species,
                        multiplicity=multiplicity,
                        wyckoff=wyckoff,
                        existing_orbits=orbits,
                        lattice=candidate_lattice,
                        generator=generator,
                        device=device,
                        proposal_budget=config.coordinate_proposal_budget,
                        minimum_distance=config.short_contact_distance,
                    )
                )
                receipt["coordinate_proposal_count"] = proposal_count
                receipt["compiled_minimum_distance_angstrom"] = (
                    compiled_distance
                    if compiled_distance is not None and math.isfinite(compiled_distance)
                    else None
                )
                receipt["projector_correction_amount"] = correction
                receipt["projector_post_valid"] = compiled is not None
                receipt["projector_rejected"] = compiled is None
                if compiled is None:
                    receipt["accepted"] = False
                    receipt["reason_code"] = "PROJECTOR_REJECTED"
                    receipt["projector_reason_codes"] = [
                        *receipt["projector_reason_codes"],
                        "COORDINATE_PROPOSAL_BUDGET_EXHAUSTED",
                    ]
                else:
                    if proposal_count > 1:
                        receipt["projector_reason_codes"] = [
                            *receipt["projector_reason_codes"],
                            "LEGAL_COMPILER_COORDINATE_RESAMPLE",
                        ]
                    orbits.append(compiled)
                    remaining[species] -= multiplicity
                    lattice = candidate_lattice
                    receipt.update(
                        {
                            "atomic_number": species,
                            "multiplicity": multiplicity,
                            "wyckoff_index": wyckoff,
                            "representative_fractional_coordinate": list(
                                compiled.representative
                            ),
                        }
                    )
        elif action_type is ActionType.ADD_PERIODIC_EDGE:
            pair_mask = torch.zeros_like(
                output.relation_pair_logits[0], dtype=torch.bool
            )
            for source, target in available_pairs:
                pair_mask[source, target] = True
            flat_index = _sample_index(
                output.relation_pair_logits[0].flatten(),
                generator=generator,
                temperature=config.sampling_temperature,
                legal_mask=pair_mask.flatten(),
            )
            node_count = output.relation_pair_logits.shape[1]
            source, target = divmod(flat_index, node_count)
            active_edges.append((source, target))
            receipt.update(
                {"source_orbit_index": source, "target_orbit_index": target}
            )
        elif action_type is ActionType.UPDATE_LATTICE:
            candidate_lattice = output.predicted_lattice[0].detach().float().cpu().numpy()
            if np.isfinite(candidate_lattice).all() and np.linalg.det(candidate_lattice) > 0:
                lattice = candidate_lattice
            else:
                receipt["accepted"] = False
                receipt["reason_code"] = "INVALID_LATTICE_UPDATE"
        elif action_type is ActionType.REFINE_GEOMETRY and orbits:
            projected = output.final_projection.positions[0, : len(orbits)]
            inverse = torch.linalg.inv(output.final_projection.lattice[0])
            refined = (
                torch.remainder(projected.float() @ inverse.float(), 1.0)
                .detach()
                .cpu()
                .numpy()
            )
            updated: list[_GeneratedOrbit] = []
            for orbit, representative_array in zip(orbits, refined, strict=True):
                representative = tuple(float(value) for value in representative_array)
                updated.append(
                    _GeneratedOrbit(
                        orbit.atomic_number,
                        orbit.multiplicity,
                        orbit.wyckoff_index,
                        representative,
                        _expand_orbit(representative, orbit.multiplicity),
                    )
                )
            orbits = updated
        elif action_type is ActionType.TERMINATE:
            if any(count > 0 for count in remaining.values()):
                receipt["accepted"] = False
                receipt["reason_code"] = "COMPOSITION_INCOMPLETE"
            else:
                completed = True
        pre_valid.append(bool(receipt["projector_pre_valid"]))
        post_valid.append(bool(receipt["projector_post_valid"]))
        corrections.append(float(receipt["projector_correction_amount"]))
        actions.append(receipt)
        if completed:
            break
    if not completed:
        failure_code = "MAX_ASSEMBLY_STEPS"
    candidate = _candidate_payload(orbits, lattice)
    coordinates = np.asarray(candidate["fractional_coordinates"], dtype=float)
    minimum_distance = _minimum_distance(coordinates, lattice)
    composition_complete = all(count == 0 for count in remaining.values())
    short_contact_free = bool(
        len(coordinates) > 0
        and (
            len(coordinates) == 1
            or minimum_distance >= config.short_contact_distance
        )
    )
    legal_terminal = bool(
        completed
        and composition_complete
        and candidate["atomic_numbers"]
        and np.isfinite(lattice).all()
        and np.linalg.det(lattice) > 0
        and np.isfinite(coordinates).all()
        and short_contact_free
    )
    return {
        "condition": condition,
        "completed": completed,
        "failure_code": failure_code,
        "legal_terminal_crystal": legal_terminal,
        "composition_complete": composition_complete,
        "short_contact_free": bool(short_contact_free),
        "minimum_distance_angstrom": (
            minimum_distance if math.isfinite(minimum_distance) else None
        ),
        "actions": actions,
        "relation_memory_trace": memory_trace,
        "candidate": candidate,
        "projector": {
            "pre_valid_count": sum(pre_valid),
            "post_valid_count": sum(post_valid),
            "attempted_state_count": len(pre_valid),
            "rejection_count": len(post_valid) - sum(post_valid),
            "correction_amount_mean": float(np.mean(corrections)) if corrections else 0.0,
        },
        "generation_latency_seconds": time.perf_counter() - started,
    }


def run_free_rollouts(
    *,
    model: torch.nn.Module,
    conditions: list[dict[str, Any]],
    config: FreeRolloutConfig,
    output_path: str | Path,
) -> dict[str, Any]:
    if not conditions:
        raise ValueError("free rollout conditions must not be empty")
    output_path = Path(output_path)
    if output_path.exists():
        raise FileExistsError(f"free rollout refuses to overwrite: {output_path}")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    device = torch.device(config.device)
    model = model.to(device).eval()
    records: list[dict[str, Any]] = []
    for condition in conditions:
        if _FORBIDDEN_CONDITION_FIELDS.intersection(condition):
            raise ValueError("free rollout condition contains forbidden parent information")
        if int(condition["root_seed"]) != config.root_seed:
            raise ValueError("condition root seed mismatch")
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    started = time.perf_counter()
    with output_path.open("x", encoding="utf-8") as stream:
        for condition in conditions:
            try:
                record = _run_one(
                    model=model,
                    condition=condition,
                    config=config,
                    device=device,
                )
            except Exception as error:
                record = {
                    "condition": condition,
                    "completed": False,
                    "failure_code": "GENERATION_EXCEPTION",
                    "exception_type": type(error).__name__,
                    "exception_message": str(error),
                    "legal_terminal_crystal": False,
                    "composition_complete": False,
                    "short_contact_free": False,
                    "minimum_distance_angstrom": None,
                    "actions": [],
                    "relation_memory_trace": [],
                    "candidate": {
                        "atomic_numbers": [],
                        "fractional_coordinates": [],
                        "lattice": [],
                        "orbit_count": 0,
                    },
                    "projector": {
                        "pre_valid_count": 0,
                        "post_valid_count": 0,
                        "attempted_state_count": 0,
                        "rejection_count": 0,
                        "correction_amount_mean": 0.0,
                    },
                    "generation_latency_seconds": 0.0,
                }
            records.append(record)
            stream.write(_canonical_json(record) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
    latencies = sorted(float(record["generation_latency_seconds"]) for record in records)
    p95_index = min(len(latencies) - 1, math.ceil(0.95 * len(latencies)) - 1)
    completion_count = sum(bool(record["completed"]) for record in records)
    legal_count = sum(bool(record["legal_terminal_crystal"]) for record in records)
    return {
        "root_seed": config.root_seed,
        "attempt_count": len(records),
        "completion_count": completion_count,
        "failure_count": len(records) - completion_count,
        "legal_terminal_count": legal_count,
        "refill_count": 0,
        "completion_rate": completion_count / len(records),
        "legal_terminal_rate": legal_count / len(records),
        "generation_latency_p50_seconds": median(latencies),
        "generation_latency_p95_seconds": latencies[p95_index],
        "wall_seconds": time.perf_counter() - started,
        "peak_allocated_vram_bytes": (
            int(torch.cuda.max_memory_allocated(device))
            if device.type == "cuda"
            else 0
        ),
        "peak_reserved_vram_bytes": (
            int(torch.cuda.max_memory_reserved(device))
            if device.type == "cuda"
            else 0
        ),
        "records": records,
    }
