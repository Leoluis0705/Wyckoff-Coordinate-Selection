from __future__ import annotations

import hashlib
from collections import defaultdict
from collections.abc import Mapping, Sequence

import numpy as np
from pyxtal.symmetry import Group


def fixed_cutoff_from_radii(left: float, right: float) -> tuple[float, float]:
    if left <= 0.0 or right <= 0.0:
        raise ValueError("atomic radii must be positive")
    cutoff = min(4.5, 1.25 * (float(left) + float(right)))
    safe_distance = 0.65 * cutoff / 1.25
    return round(cutoff, 12), round(safe_distance, 12)


def strict_free_parameters(
    space_group: int,
    wyckoff_letter: str,
    fractional_coordinate: Sequence[float],
    *,
    tolerance: float = 1e-8,
) -> tuple[float, ...] | None:
    position = Group(int(space_group)).get_wyckoff_position(str(wyckoff_letter))
    coordinate = np.mod(np.asarray(fractional_coordinate, dtype=float), 1.0)
    generator = position.search_generator(
        coordinate,
        tol=float(tolerance),
        symmetrize=False,
    )
    if generator is None:
        return None
    free = tuple(float(value) % 1.0 for value in position.get_free_xyzs(generator))
    rebuilt_generator = position.get_position_from_free_xyzs(list(free))
    expanded = np.mod(np.asarray(position.apply_ops(rebuilt_generator), dtype=float), 1.0)
    deltas = expanded - coordinate
    periodic_max = np.max(np.abs(deltas - np.rint(deltas)), axis=1)
    if float(np.min(periodic_max)) > float(tolerance):
        return None
    return tuple(round(value, 12) for value in free)


def _rank(seed: int, namespace: str, value: object) -> str:
    return hashlib.sha256(f"{seed}:{namespace}:{value}".encode()).hexdigest()


def deterministic_audit_selection(
    rows: Sequence[Mapping[str, object]],
    *,
    target_n: int,
    seed: int,
) -> list[Mapping[str, object]]:
    grouped: dict[str, list[Mapping[str, object]]] = defaultdict(list)
    for row in rows:
        grouped[str(row["event_id"])].append(row)
    if not grouped or target_n < len(grouped) or target_n > len(rows):
        raise ValueError("target_n cannot cover the requested event grain")
    event_ids = sorted(grouped, key=lambda value: _rank(seed, "event", value))
    base, extra = divmod(int(target_n), len(event_ids))
    selected: list[Mapping[str, object]] = []
    for event_index, event_id in enumerate(event_ids):
        take_n = base + int(event_index < extra)
        candidates = sorted(
            grouped[event_id],
            key=lambda row: _rank(seed, "candidate", row["candidate_id"]),
        )
        if len(candidates) < take_n:
            raise ValueError(f"event {event_id} has fewer than {take_n} candidates")
        selected.extend(candidates[:take_n])
    return selected


def alignment_verdict(
    *,
    overall_spearman: float,
    event_ndcg5: float,
    best_worst_ci_upper: float,
    high_multiplicity_proxy_failure: bool,
) -> str:
    supported = (
        float(overall_spearman) >= 0.80
        and float(event_ndcg5) >= 0.80
        and float(best_worst_ci_upper) < 0.0
        and not bool(high_multiplicity_proxy_failure)
    )
    return "SUPPORTED" if supported else "NOT_SUPPORTED"


__all__ = [
    "alignment_verdict",
    "deterministic_audit_selection",
    "fixed_cutoff_from_radii",
    "strict_free_parameters",
]
