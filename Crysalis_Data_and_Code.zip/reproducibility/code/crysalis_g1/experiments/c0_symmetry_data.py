from __future__ import annotations

import hashlib
import json
import math
from collections import Counter
from dataclasses import dataclass, fields
from pathlib import Path
from typing import Any, Iterable, Sequence

import torch

from crysalis_g1.experiments.c0_symmetry_oracle import load_recovered_parents
from crysalis_g1.symmetry.assembly import (
    AddOrbitAction,
    SpaceGroupLegalActionCompiler,
    SymmetryAssemblyState,
)
from crysalis_g1.symmetry.wyckoff import (
    ConstrainedLattice,
    OrbitState,
    SpaceGroupConstrainedLatticeHead,
    orbit_representative_fractional_coordinate,
)


PHASE2A_MANIFEST_SHA256 = (
    "4e9c6f5e162e61cc05b2bf2204ecfb692cc30ec060d79301e9f31b60ccd7fea1"
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            try:
                yield json.loads(line)
            except json.JSONDecodeError as error:
                raise ValueError(f"invalid JSONL at {path}:{line_number}") from error


def verify_frozen_phase2a(phase2a_root: str | Path) -> dict[str, Any]:
    root = Path(phase2a_root)
    manifest_path = root / "phase2a_manifest.json"
    observed = _sha256(manifest_path)
    if observed != PHASE2A_MANIFEST_SHA256:
        raise ValueError(
            f"frozen Phase2A manifest mismatch: {observed} != {PHASE2A_MANIFEST_SHA256}"
        )
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    mismatches = []
    for relative, expected in manifest["file_sha256"].items():
        path = root / relative
        actual = _sha256(path)
        if actual != expected:
            mismatches.append(
                {"path": relative, "expected_sha256": expected, "actual_sha256": actual}
            )
    if mismatches:
        raise ValueError(f"frozen Phase2A file hash mismatches: {mismatches}")
    if manifest.get("sealed_or_blind_data_accessed") is not False:
        raise ValueError("Phase2A manifest does not prove public-only data access")
    return manifest


def encode_lattice_degrees(
    lattice: ConstrainedLattice,
) -> tuple[float, float, float, float, float, float]:
    a, b, c, alpha, beta, gamma = lattice.conventional_parameters
    return (
        math.log(a),
        math.log(b),
        math.log(c),
        math.cos(math.radians(alpha)),
        math.cos(math.radians(beta)),
        math.cos(math.radians(gamma)),
    )


def decode_lattice_degrees(
    target_space_group: int,
    values: Sequence[float],
    *,
    cell_transform: Sequence[Sequence[int]],
) -> ConstrainedLattice:
    if len(values) != 6:
        raise ValueError("six lattice degrees are required")
    lengths = [math.exp(min(math.log(30.0), max(math.log(1.5), value))) for value in values[:3]]
    angles = [
        math.degrees(math.acos(min(0.95, max(-0.95, value))))
        for value in values[3:]
    ]
    return SpaceGroupConstrainedLatticeHead().constrain(
        target_space_group,
        (*lengths, *angles),
        cell_transform=cell_transform,
    )


def _default_embryo_lattice(
    target: ConstrainedLattice, site_count: int
) -> ConstrainedLattice:
    length = max(3.0, (18.0 * site_count) ** (1.0 / 3.0))
    return SpaceGroupConstrainedLatticeHead().constrain(
        target.target_space_group,
        (length, length * 1.03, length * 1.07, 90.0, 90.0, 100.0),
        cell_transform=target.cell_transform_values,
    )


@dataclass(frozen=True, slots=True)
class C0SymmetryExample:
    material_id: str
    split: str
    sequence_hash: str
    step_index: int
    target_space_group: int
    composition: tuple[tuple[int, int], ...]
    lattice: ConstrainedLattice
    active_orbits: tuple[OrbitState, ...]
    target_orbit: OrbitState | None
    legal_action_pairs: tuple[tuple[str, int, int], ...]
    input_lattice_override: ConstrainedLattice | None = None

    @property
    def terminal(self) -> bool:
        return self.target_orbit is None

    @property
    def remaining_composition(self) -> tuple[tuple[int, int], ...]:
        remaining = Counter(dict(self.composition))
        for orbit in self.active_orbits:
            remaining[orbit.species] -= orbit.multiplicity
            if remaining[orbit.species] == 0:
                del remaining[orbit.species]
        return tuple(sorted(remaining.items()))

    def condition_payload(self, *, root_seed: int) -> dict[str, Any]:
        return {
            "schema_version": "g1-c0-symmetry-condition.1.0.0",
            "root_seed": int(root_seed),
            "target_space_group": self.target_space_group,
            "composition": [list(value) for value in self.composition],
        }


@dataclass(frozen=True, slots=True)
class C0SymmetryCorpus:
    train_examples: tuple[C0SymmetryExample, ...]
    validation_examples: tuple[C0SymmetryExample, ...]
    parent_count: int
    trajectory_count: int
    manifest_sha256: str = PHASE2A_MANIFEST_SHA256

    @classmethod
    def build(
        cls,
        phase2a_root: str | Path,
        recovered_parent_cache: str | Path,
        *,
        maximum_sites: int = 20,
    ) -> C0SymmetryCorpus:
        root = Path(phase2a_root)
        verify_frozen_phase2a(root)
        parents = load_recovered_parents(recovered_parent_cache)
        split_by_parent = {
            str(row["material_id"]): str(row["split"])
            for row in _read_jsonl(root / "splits" / "structure_ood_manifest.jsonl")
        }
        compiler = SpaceGroupLegalActionCompiler(max_sites=maximum_sites)
        train: list[C0SymmetryExample] = []
        validation: list[C0SymmetryExample] = []
        trajectory_count = 0
        used_parents: set[str] = set()
        legal_cache: dict[
            tuple[str, tuple[str, ...]], tuple[tuple[str, int, int], ...]
        ] = {}
        for row in _read_jsonl(root / "trajectories" / "d_orbit.jsonl"):
            trajectory_count += 1
            parent_id = str(row["parent_structure_id"])
            parent = parents.get(parent_id)
            if parent is None:
                raise ValueError(f"trajectory parent missing from recovered cache: {parent_id}")
            split = split_by_parent.get(parent_id)
            if split not in {"train_fit", "validation"}:
                raise ValueError(f"trajectory parent has invalid Structure-OOD split: {parent_id}")
            used_parents.add(parent_id)
            target_by_id = {
                orbit.orbit_instance_id: orbit for orbit in parent.orbits
            }
            composition = Counter()
            for orbit in parent.orbits:
                composition[orbit.species] += orbit.multiplicity
            state = SymmetryAssemblyState.empty(
                target_space_group=parent.target_space_group,
                composition=tuple(sorted(composition.items())),
                lattice=parent.lattice,
            )
            destination = train if split == "train_fit" else validation
            for step_index, action_payload in enumerate(row["inverse_actions"]):
                target_id = str(action_payload["target_id"])
                target = target_by_id.get(target_id)
                if target is None:
                    raise ValueError(f"unknown inverse orbit {parent_id}:{target_id}")
                cache_key = (
                    parent_id,
                    tuple(sorted(orbit.orbit_instance_id for orbit in state.orbits)),
                )
                legal_pairs = legal_cache.get(cache_key)
                if legal_pairs is None:
                    legal_pairs = tuple(
                        sorted(
                            {
                                (
                                    action.wyckoff_letter,
                                    action.species,
                                    action.multiplicity,
                                )
                                for action in compiler.legal_add_actions(state)
                            }
                        )
                    )
                    legal_cache[cache_key] = legal_pairs
                if (
                    target.wyckoff_letter,
                    target.species,
                    target.multiplicity,
                ) not in legal_pairs:
                    raise ValueError(
                        f"inverse target is not compiler-legal: {parent_id}:{target_id}"
                    )
                destination.append(
                    C0SymmetryExample(
                        material_id=parent_id,
                        split=split,
                        sequence_hash=str(row["sequence_hash"]),
                        step_index=step_index,
                        target_space_group=parent.target_space_group,
                        composition=tuple(sorted(composition.items())),
                        lattice=parent.lattice,
                        active_orbits=state.orbits,
                        target_orbit=target,
                        legal_action_pairs=legal_pairs,
                    )
                )
                state = compiler.apply_add(
                    state,
                    AddOrbitAction(
                        target.wyckoff_letter,
                        target.species,
                        target.free_parameters,
                        target.orbit_instance_id,
                    ),
                )
            destination.append(
                C0SymmetryExample(
                    material_id=parent_id,
                    split=split,
                    sequence_hash=str(row["sequence_hash"]),
                    step_index=len(row["inverse_actions"]),
                    target_space_group=parent.target_space_group,
                    composition=tuple(sorted(composition.items())),
                    lattice=parent.lattice,
                    active_orbits=state.orbits,
                    target_orbit=None,
                    legal_action_pairs=(),
                )
            )
        return cls(
            train_examples=tuple(train),
            validation_examples=tuple(validation),
            parent_count=len(used_parents),
            trajectory_count=trajectory_count,
        )


@dataclass(slots=True)
class C0SymmetryBatch:
    composition: torch.Tensor
    remaining_composition: torch.Tensor
    target_space_group: torch.Tensor
    progress: torch.Tensor
    orbit_species: torch.Tensor
    orbit_wyckoff: torch.Tensor
    orbit_multiplicity: torch.Tensor
    orbit_free_parameters: torch.Tensor
    orbit_fractional_coordinates: torch.Tensor
    orbit_mask: torch.Tensor
    lattice: torch.Tensor
    lattice_degrees: torch.Tensor
    legal_wyckoff_mask: torch.Tensor
    legal_species_mask: torch.Tensor
    target_terminate: torch.Tensor
    target_wyckoff: torch.Tensor
    target_species: torch.Tensor
    target_free_parameters: torch.Tensor
    target_free_parameter_mask: torch.Tensor
    target_lattice_degrees: torch.Tensor
    target_cell_index: torch.Tensor
    target_multiplicity: torch.Tensor

    @property
    def batch_size(self) -> int:
        return int(self.composition.shape[0])

    def to(self, device: torch.device | str) -> C0SymmetryBatch:
        return C0SymmetryBatch(
            **{
                field.name: getattr(self, field.name).to(device)
                for field in fields(self)
            }
        )


def collate_c0_symmetry_examples(
    examples: Sequence[C0SymmetryExample],
    *,
    maximum_orbits: int = 20,
) -> C0SymmetryBatch:
    if not examples:
        raise ValueError("cannot collate an empty C0-Symmetry batch")
    if any(len(example.active_orbits) > maximum_orbits for example in examples):
        raise ValueError("example exceeds maximum_orbits")
    batch_size = len(examples)
    composition = torch.zeros(batch_size, 119, dtype=torch.float32)
    remaining = torch.zeros_like(composition)
    target_space_group = torch.zeros(batch_size, dtype=torch.long)
    progress = torch.zeros(batch_size, 1, dtype=torch.float32)
    orbit_species = torch.zeros(batch_size, maximum_orbits, dtype=torch.long)
    orbit_wyckoff = torch.zeros(batch_size, maximum_orbits, dtype=torch.long)
    orbit_multiplicity = torch.zeros(batch_size, maximum_orbits, dtype=torch.long)
    orbit_free = torch.zeros(batch_size, maximum_orbits, 3, dtype=torch.float32)
    orbit_coordinates = torch.zeros_like(orbit_free)
    orbit_mask = torch.zeros(batch_size, maximum_orbits, dtype=torch.bool)
    lattice = torch.zeros(batch_size, 3, 3, dtype=torch.float32)
    lattice_degrees = torch.zeros(batch_size, 6, dtype=torch.float32)
    legal_wyckoff = torch.zeros(batch_size, 26, dtype=torch.bool)
    legal_species = torch.zeros(batch_size, 119, dtype=torch.bool)
    target_terminate = torch.zeros(batch_size, dtype=torch.long)
    target_wyckoff = torch.full((batch_size,), -100, dtype=torch.long)
    target_species = torch.full((batch_size,), -100, dtype=torch.long)
    target_free = torch.zeros(batch_size, 3, dtype=torch.float32)
    target_free_mask = torch.zeros(batch_size, 3, dtype=torch.bool)
    target_lattice = torch.zeros(batch_size, 6, dtype=torch.float32)
    target_cell_index = torch.zeros(batch_size, dtype=torch.long)
    target_multiplicity = torch.full((batch_size,), -100, dtype=torch.long)
    for row_index, example in enumerate(examples):
        for atomic_number, count in example.composition:
            composition[row_index, atomic_number] = count
        for atomic_number, count in example.remaining_composition:
            remaining[row_index, atomic_number] = count
        target_space_group[row_index] = example.target_space_group
        total_sites = sum(count for _, count in example.composition)
        active_sites = sum(orbit.multiplicity for orbit in example.active_orbits)
        progress[row_index, 0] = active_sites / total_sites
        input_lattice = example.input_lattice_override
        if input_lattice is None:
            input_lattice = (
                example.lattice
                if example.active_orbits
                else _default_embryo_lattice(example.lattice, total_sites)
            )
        lattice[row_index] = torch.tensor(input_lattice.primitive_matrix)
        lattice_degrees[row_index] = torch.tensor(
            encode_lattice_degrees(input_lattice)
        )
        target_lattice[row_index] = torch.tensor(
            encode_lattice_degrees(example.lattice)
        )
        target_cell_index[row_index] = example.lattice.cell_index
        for orbit_index, orbit in enumerate(example.active_orbits):
            orbit_mask[row_index, orbit_index] = True
            orbit_species[row_index, orbit_index] = orbit.species
            orbit_wyckoff[row_index, orbit_index] = ord(orbit.wyckoff_letter) - ord("a")
            orbit_multiplicity[row_index, orbit_index] = orbit.multiplicity
            if orbit.free_parameters:
                orbit_free[row_index, orbit_index, : len(orbit.free_parameters)] = (
                    torch.tensor(orbit.free_parameters)
                )
            orbit_coordinates[row_index, orbit_index] = torch.tensor(
                orbit_representative_fractional_coordinate(orbit)
            )
        for wyckoff_letter, atomic_number, _ in example.legal_action_pairs:
            legal_wyckoff[row_index, ord(wyckoff_letter) - ord("a")] = True
            legal_species[row_index, atomic_number] = True
        if example.terminal:
            target_terminate[row_index] = 1
        else:
            target = example.target_orbit
            if target is None:
                raise AssertionError("nonterminal example has no target orbit")
            target_wyckoff[row_index] = ord(target.wyckoff_letter) - ord("a")
            target_species[row_index] = target.species
            target_multiplicity[row_index] = target.multiplicity
            if target.free_parameters:
                target_free[row_index, : len(target.free_parameters)] = torch.tensor(
                    target.free_parameters
                )
                target_free_mask[row_index, : len(target.free_parameters)] = True
    return C0SymmetryBatch(
        composition=composition,
        remaining_composition=remaining,
        target_space_group=target_space_group,
        progress=progress,
        orbit_species=orbit_species,
        orbit_wyckoff=orbit_wyckoff,
        orbit_multiplicity=orbit_multiplicity,
        orbit_free_parameters=orbit_free,
        orbit_fractional_coordinates=orbit_coordinates,
        orbit_mask=orbit_mask,
        lattice=lattice,
        lattice_degrees=lattice_degrees,
        legal_wyckoff_mask=legal_wyckoff,
        legal_species_mask=legal_species,
        target_terminate=target_terminate,
        target_wyckoff=target_wyckoff,
        target_species=target_species,
        target_free_parameters=target_free,
        target_free_parameter_mask=target_free_mask,
        target_lattice_degrees=target_lattice,
        target_cell_index=target_cell_index,
        target_multiplicity=target_multiplicity,
    )
