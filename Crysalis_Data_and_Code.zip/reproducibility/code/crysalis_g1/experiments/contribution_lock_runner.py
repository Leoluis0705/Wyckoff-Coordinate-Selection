from __future__ import annotations

import hashlib
import json
import math
import os
import statistics
import subprocess
import tempfile
from collections import Counter
from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path

from crysalis_g1.experiments.contribution_analysis import (
    FROZEN_SPACE_GROUPS,
    choose_final_contribution_label,
    evaluate_orbit_graph_signal,
)

ROOT_SEED = 20260823
CONDITIONAL_EXTRA_SEEDS = (20260824, 20260825)
PREFLIGHT_UPDATES = 500
TOTAL_UPDATES = 5_000
CONDITION_COUNT = 300
FIRE_STEPS = 300
TEMPERATURE = 0.8

MANDATORY_FIRST_ROUND_FILENAMES = (
    "CONTRIBUTION_LOCK_MANIFEST.json",
    "DECONSTRUCTION_STATE_GRAPH_AUDIT.json",
    "STATE_GRAPH_REPLAY_REPORT.json",
    "MULTIPOSITIVE_VIABILITY_DATA_REPORT.json",
    "FINAL_SET_BASELINE_REPORT.json",
    "GRAPH_VIABILITY_TRAINING_REPORT.json",
    "GRAPH_VIABILITY_GENERATION_RESULTS.json",
    "CONTRIBUTION_PAIRED_STATISTICS.json",
    "CONTRIBUTION_BY_SPACE_GROUP.json",
    "CONTRIBUTION_FAILURES.jsonl",
    "PRIOR_ART_BOUNDARY.md",
    "CONTRIBUTION_LOCK_DECISION.md",
)

REQUIRED_FROZEN_ARTIFACTS = frozenset(
    {
        "phase2a_manifest",
        "c0_manifest",
        "c0_checkpoint",
        "condition_manifest",
        "attribution_manifest",
        "robustness_manifest",
        "chgnet_weights",
        "structure_ood_manifest",
    }
)

REQUIRED_AUTHORIZATIONS = {
    "server": False,
    "dft": False,
    "kan": False,
    "physics": False,
    "e3nn": False,
    "condition_refill": False,
    "temperature_search": False,
    "seed_substitution": False,
    "extra_updates": False,
    "new_deconstruction_operators": False,
}

ALLOWED_FINAL_LABELS = frozenset(
    {
        "CONTRIBUTION_LOCKED_ORBIT_GRAPH",
        "CONTRIBUTION_LOCKED_MULTI_OPERATOR",
        "NOVEL_FORMULATION_WITHOUT_EMPIRICAL_GAIN",
        "CONTRIBUTION_NOT_SUPPORTED",
    }
)


@dataclass(frozen=True, slots=True)
class FrozenArtifact:
    path: Path
    sha256: str


@dataclass(frozen=True, slots=True)
class ContributionLockConfig:
    repository_root: Path
    output_root: Path
    frozen_artifacts: Mapping[str, FrozenArtifact]
    frozen_implementation_commit: str
    frozen_implementation_files: Mapping[str, str]
    contribution_implementation_commit: str
    contribution_implementation_files: Mapping[str, str]
    root_seed: int = ROOT_SEED
    conditional_extra_seeds: tuple[int, int] = CONDITIONAL_EXTRA_SEEDS
    preflight_updates: int = PREFLIGHT_UPDATES
    total_updates: int = TOTAL_UPDATES
    condition_count: int = CONDITION_COUNT
    fire_steps: int = FIRE_STEPS
    temperature: float = TEMPERATURE
    public_splits: tuple[str, str] = ("train_fit", "validation")
    sealed_or_blind_data_accessed: bool = False
    single_path_inverse_action_policy_not_supported: bool = True
    single_path_action_policy_failure_robust: bool = True
    authorizations: Mapping[str, bool] = field(
        default_factory=lambda: dict(REQUIRED_AUTHORIZATIONS)
    )
    expected_parent_count: int = 7_838
    expected_subset_node_count: int = 116_208
    expected_minimum_orbit_count: int = 3
    expected_maximum_orbit_count: int = 8


@dataclass(frozen=True, slots=True)
class RunnerDependencies:
    iter_parents: Callable[[], Iterable[object]]
    build_parent_graph_record: Callable[[object], Mapping[str, object]]
    train_action_scorer: Callable[[str, int, Path, Path], Mapping[str, object]]
    generate_scored_attempts: Callable[
        [str, int, Mapping[str, object], Sequence[Mapping[str, object]]],
        Sequence[Mapping[str, object]],
    ]
    evaluate_fixed_cell_fire300: Callable[
        [str, int, Sequence[Mapping[str, object]]],
        Sequence[Mapping[str, object]],
    ]
    analyze_first_round: Callable[[Mapping[str, object]], Mapping[str, object]]
    analyze_replication: Callable[[Mapping[str, object]], Mapping[str, object]]
    audit_relation_contract: Callable[[], Mapping[str, object]]
    run_relation_contribution: Callable[[Mapping[str, object]], object]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _json_bytes(payload: object) -> bytes:
    return (
        json.dumps(payload, sort_keys=True, indent=2, ensure_ascii=False) + "\n"
    ).encode("utf-8")


def _atomic_write_bytes_new(path: Path, content: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        try:
            os.link(temporary, path)
        except FileExistsError as error:
            raise FileExistsError(f"refusing to overwrite: {path}") from error
    finally:
        temporary.unlink(missing_ok=True)


def _write_json_new(path: Path, payload: object) -> None:
    _atomic_write_bytes_new(path, _json_bytes(payload))


def _write_text_new(path: Path, content: str) -> None:
    _atomic_write_bytes_new(path, content.encode("utf-8"))


def _read_json(path: Path) -> Mapping[str, object]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected JSON object: {path}")
    return payload


def _parent_split_evidence(
    path: Path, *, expected_parent_count: int
) -> dict[str, object]:
    assignments: list[tuple[str, str]] = []
    orbit_counts: list[tuple[str, int]] = []
    for line_number, line in enumerate(
        path.read_text(encoding="utf-8").splitlines(), start=1
    ):
        if not line.strip():
            continue
        row = json.loads(line)
        if not isinstance(row, dict):
            raise ValueError(f"Structure-OOD row {line_number} is not an object")
        parent_id = str(row.get("material_id", ""))
        split = str(row.get("split", ""))
        orbit_count = int(row.get("orbit_count", 0))
        if (
            not parent_id
            or split not in ("train_fit", "validation")
            or orbit_count <= 0
        ):
            raise ValueError(f"Structure-OOD row {line_number} has invalid assignment")
        assignments.append((parent_id, split))
        orbit_counts.append((parent_id, orbit_count))
    assignments.sort()
    orbit_counts.sort()
    if len(assignments) != expected_parent_count:
        raise ValueError("Structure-OOD eligible parent count mismatch")
    if len({parent_id for parent_id, _ in assignments}) != len(assignments):
        raise ValueError("Structure-OOD parent IDs must be unique")
    canonical = json.dumps(assignments, separators=(",", ":"), ensure_ascii=True)
    split_counts = Counter(split for _, split in assignments)
    orbit_count_distribution = Counter(count for _, count in orbit_counts)
    return {
        "structure_ood_manifest_sha256": _sha256(path),
        "eligible_parent_split_sha256": hashlib.sha256(
            canonical.encode("utf-8")
        ).hexdigest(),
        "eligible_parent_count": len(assignments),
        "split_counts": dict(sorted(split_counts.items())),
        "orbit_count_distribution": dict(sorted(orbit_count_distribution.items())),
        "assignments": tuple(assignments),
        "orbit_counts": tuple(orbit_counts),
    }


def _run_git(repository: Path, *arguments: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *arguments],
        cwd=repository,
        check=False,
        capture_output=True,
        text=True,
    )


def _verify_implementation(
    *,
    repository: Path,
    commit_sha: str,
    files: Mapping[str, str],
    label: str,
) -> dict[str, object]:
    repository = repository.resolve()
    resolved = _run_git(
        repository, "rev-parse", f"{commit_sha}^{{commit}}"
    )
    if resolved.returncode != 0:
        raise ValueError(f"{label} commit cannot be resolved")
    commit = resolved.stdout.strip()
    if commit != commit_sha:
        raise ValueError(f"{label} commit mismatch")
    if not files:
        raise ValueError(f"{label} file set must be non-empty")

    paths = tuple(files)
    diff = _run_git(repository, "diff", "--quiet", commit, "--", *paths)
    status = _run_git(
        repository, "status", "--porcelain", "--untracked-files=all", "--", *paths
    )
    if diff.returncode != 0 or status.returncode != 0 or status.stdout.strip():
        raise ValueError(f"{label} differs from committed state")

    observed: dict[str, str] = {}
    for relative, expected in files.items():
        path = (repository / relative).resolve()
        try:
            path.relative_to(repository)
        except ValueError as error:
            raise ValueError(f"{label} path escapes repository") from error
        if not path.is_file():
            raise ValueError(f"{label} file missing: {relative}")
        actual = _sha256(path)
        if actual.lower() != str(expected).lower():
            raise ValueError(f"{label} SHA256 mismatch: {relative}")
        observed[relative] = actual
    return {"commit": commit, "file_sha256": observed}


def _verify_frozen_implementation(config: ContributionLockConfig) -> dict[str, object]:
    return _verify_implementation(
        repository=config.repository_root,
        commit_sha=config.frozen_implementation_commit,
        files=config.frozen_implementation_files,
        label="frozen implementation",
    )


def _verify_contribution_implementation(
    config: ContributionLockConfig,
) -> dict[str, object]:
    return _verify_implementation(
        repository=config.repository_root,
        commit_sha=config.contribution_implementation_commit,
        files=config.contribution_implementation_files,
        label="contribution implementation",
    )


def _verify_preflight(config: ContributionLockConfig) -> dict[str, object]:
    if config.output_root.exists():
        raise FileExistsError(f"refusing to overwrite: {config.output_root}")
    if (
        config.root_seed != ROOT_SEED
        or tuple(config.conditional_extra_seeds) != CONDITIONAL_EXTRA_SEEDS
        or config.preflight_updates != PREFLIGHT_UPDATES
        or config.total_updates != TOTAL_UPDATES
        or config.condition_count != CONDITION_COUNT
        or config.fire_steps != FIRE_STEPS
        or config.temperature != TEMPERATURE
        or tuple(config.public_splits) != ("train_fit", "validation")
        or config.sealed_or_blind_data_accessed is not False
    ):
        raise ValueError("frozen contribution-lock settings drifted")
    if (
        config.expected_parent_count <= 0
        or config.expected_subset_node_count <= 0
        or config.expected_minimum_orbit_count <= 0
        or config.expected_maximum_orbit_count < config.expected_minimum_orbit_count
    ):
        raise ValueError("frozen cohort counts must be positive")
    if dict(config.authorizations) != REQUIRED_AUTHORIZATIONS:
        raise ValueError("authorization contract drifted")
    if not config.single_path_inverse_action_policy_not_supported:
        raise ValueError("frozen attribution boundary is not acknowledged")
    if not config.single_path_action_policy_failure_robust:
        raise ValueError("completed action-policy robustness evidence is required")

    missing = REQUIRED_FROZEN_ARTIFACTS - set(config.frozen_artifacts)
    if missing:
        raise ValueError(f"missing frozen artifacts: {sorted(missing)}")
    hashes: dict[str, str] = {}
    for label, artifact in config.frozen_artifacts.items():
        path = Path(artifact.path)
        if not path.is_file():
            raise ValueError(f"{label} is missing")
        actual = _sha256(path)
        if actual.lower() != artifact.sha256.lower():
            raise ValueError(f"{label} SHA256 mismatch")
        hashes[label] = actual

    phase2a = _read_json(config.frozen_artifacts["phase2a_manifest"].path)
    c0 = _read_json(config.frozen_artifacts["c0_manifest"].path)
    attribution = _read_json(config.frozen_artifacts["attribution_manifest"].path)
    robustness = _read_json(config.frozen_artifacts["robustness_manifest"].path)
    if phase2a.get("sealed_or_blind_data_accessed") is not False:
        raise ValueError("Phase2A manifest is not public-only")
    if phase2a.get("no_refill") is not True:
        raise ValueError("Phase2A manifest does not prove no-refill execution")
    if phase2a.get("formal_training_started") is not False:
        raise ValueError("Phase2A manifest reports formal training")
    if c0.get("sealed_or_blind_data_accessed") is not False:
        raise ValueError("C0 manifest is not public-only")
    phase2a_files = phase2a.get("file_sha256")
    if not isinstance(phase2a_files, Mapping) or (
        phase2a_files.get("splits/structure_ood_manifest.jsonl")
        != hashes["structure_ood_manifest"]
    ):
        raise ValueError("Phase2A declared Structure-OOD hash drifted")
    c0_files = c0.get("file_sha256")
    if not isinstance(c0_files, Mapping) or not {
        hashes["c0_checkpoint"],
        hashes["condition_manifest"],
    }.issubset(set(c0_files.values())):
        raise ValueError("C0 declared checkpoint or condition hash drifted")
    if c0.get("phase2a_manifest_sha256_before_after") != hashes["phase2a_manifest"]:
        raise ValueError("C0 Phase2A manifest hash drifted")
    if (
        attribution.get("sealed_or_blind_data_accessed") is not False
        or attribution.get("attempt_count_per_arm") != CONDITION_COUNT
        or attribution.get("arms")
        != ["LEARNED", "UNIFORM_LEGAL", "EMPIRICAL_FREQUENCY"]
        or attribution.get("refill_count") != 0
        or attribution.get("only_action_selection_replaced") is not True
    ):
        raise ValueError("frozen policy-attribution evidence is incomplete")
    if (
        robustness.get("sealed_or_blind_data_accessed") is not False
        or robustness.get("attempt_count_per_stream") != CONDITION_COUNT
        or robustness.get("policy_stream_count_per_arm") != 20
        or robustness.get("refill_count") != 0
    ):
        raise ValueError("frozen action-policy robustness evidence is incomplete")

    condition_manifest = _read_json(
        config.frozen_artifacts["condition_manifest"].path
    )
    raw_conditions = condition_manifest.get("conditions")
    if not isinstance(raw_conditions, list) or len(raw_conditions) != CONDITION_COUNT:
        raise ValueError("condition manifest must contain exactly 300 conditions")
    conditions = tuple(dict(condition) for condition in raw_conditions)
    condition_ids = [condition.get("condition_id") for condition in conditions]
    if any(value is None for value in condition_ids) or len(set(condition_ids)) != len(
        condition_ids
    ):
        raise ValueError("condition IDs must be present and unique")

    matched_data = _parent_split_evidence(
        config.frozen_artifacts["structure_ood_manifest"].path,
        expected_parent_count=config.expected_parent_count,
    )
    observed_orbit_counts = [count for _, count in matched_data["orbit_counts"]]
    if (
        min(observed_orbit_counts) != config.expected_minimum_orbit_count
        or max(observed_orbit_counts) != config.expected_maximum_orbit_count
        or sum(1 << count for count in observed_orbit_counts)
        != config.expected_subset_node_count
    ):
        raise ValueError("frozen orbit-count or theoretical-node contract drifted")

    return {
        "artifact_sha256": hashes,
        "implementation": _verify_frozen_implementation(config),
        "contribution_implementation": _verify_contribution_implementation(config),
        "conditions": conditions,
        "matched_data_evidence": matched_data,
    }


def _prior_art_boundary() -> str:
    return """# Prior-art boundary

## Scoped novelty statement

The candidate contribution is specifically parent-derived, typed, executable, exact `D_orbit` deconstruction/restore transitions inducing exhaustive orbit-subset DAGs and state-dependent reachability labels, tested against legal-uniform and final-set controls within the frozen public-only Crysalis-G1 protocol.

## Named boundaries

- Evidence is limited to the frozen `train_fit` and `validation` parents, the registered 300 conditions, fixed-cell FIRE300, and the named matched baselines.
- Existing policy-attribution artifacts remain read-only evidence; the prior CSSD interpretation is not adopted as this experiment's main contribution.
- Material identifiers, coordinates, orbit identities, future states, future actions, and sealed or blind data are outside the model boundary.
- Wyckoff-aware and space-group-conditioned generation boundaries include [WyckoffAUGen](https://openreview.net/pdf?id=1ne8lalwRN), [WyFormer](https://proceedings.mlr.press/v267/kazeev25a.html), and [SGEquiDiff](https://arxiv.org/abs/2505.10994).
- Sequential, dynamic, and compositional crystal-generation boundaries include [DynaCrys](https://arxiv.org/abs/2608.07401) and [Composable Crystals](https://arxiv.org/abs/2605.14769).
- State-graph, flow-network, and hierarchical-building-block boundaries include [Crystal-GFN](https://arxiv.org/abs/2310.04925) and [SHAFT](https://pubs.rsc.org/en/content/articlehtml/2026/dd/d4dd00392f).

## Forbidden first claims

- Disallowed: state graphs are new in general.
- Disallowed: sequential assembly is new in general.
- Disallowed: reversible policies are new in general.
- Disallowed: building blocks are new in general.
- No claim of originating crystal inverse design, symmetry-constrained generation, graph supervision, reversible operators, or any broad field-level priority.
"""


def _decision_markdown(
    label: str,
    *,
    dry_run: bool,
    first_round: Mapping[str, object] | None = None,
    replication: Mapping[str, object] | None = None,
    relation_audit: Mapping[str, object] | None = None,
) -> str:
    if label not in ALLOWED_FINAL_LABELS:
        raise ValueError("final contribution label is not registered")
    qualifier = (
        "Dry-run fixture only; no scientific work or inference was performed."
        if dry_run
        else "Decision produced by the preregistered phase gates."
    )
    lines = ["# Contribution-lock decision", "", label, "", qualifier]
    if first_round is not None:
        signal = first_round.get("signal")
        if isinstance(signal, Mapping):
            lines.extend(
                [
                    "",
                    "## First-round gate",
                    "",
                    f"- ORBIT_GRAPH_CONTRIBUTION_SIGNAL: "
                    f"{signal.get('ORBIT_GRAPH_CONTRIBUTION_SIGNAL')}",
                    f"- Endpoint 1 dual strict-CI pass: "
                    f"{signal.get('endpoint1_dual_strict_ci_pass')}",
                    f"- Endpoint 2 dual strict-CI pass: "
                    f"{signal.get('endpoint2_dual_strict_ci_pass')}",
                    f"- SHORT_CONTACT dual strict-CI pass: "
                    f"{signal.get('short_contact_dual_strict_ci_pass')}",
                    f"- SG-macro dual direction pass: "
                    f"{signal.get('space_group_macro_dual_direction_pass')}",
                    f"- Secondary route: {signal.get('secondary_route')}",
                ]
            )
        paired = first_round.get("paired_statistics")
        if isinstance(paired, Mapping):
            endpoint1 = paired.get("endpoint1")
            if isinstance(endpoint1, Mapping):
                lines.extend(["", "### Primary endpoint 1", ""])
                for baseline in ("UNIFORM_LEGAL", "FINAL_SET_MEMBERSHIP"):
                    comparison = endpoint1.get(baseline)
                    if isinstance(comparison, Mapping):
                        lines.append(
                            f"- GRAPH_VIABILITY vs {baseline}: delta="
                            f"{comparison.get('observed_delta')}, 95% CI="
                            f"{comparison.get('confidence_interval_95')}"
                        )
    if replication is not None:
        lines.extend(
            [
                "",
                "## Three-seed replication",
                "",
                f"- ORBIT_GRAPH_CONTRIBUTION_REPLICATED: "
                f"{replication.get('ORBIT_GRAPH_CONTRIBUTION_REPLICATED')}",
                f"- Seed-level deltas: "
                f"{replication.get('seed_level_observed_deltas')}",
                f"- Mean delta: {replication.get('observed_mean_delta')}",
                f"- Std delta: {replication.get('observed_std_delta')}",
            ]
        )
    if relation_audit is not None:
        lines.extend(
            [
                "",
                "## Relation-interface branch",
                "",
                f"- Status: {relation_audit.get('status')}",
                f"- Orbit-action coupling contract present: "
                f"{relation_audit.get('orbit_action_coupling_contract_present')}",
                f"- Reason: {relation_audit.get('reason')}",
            ]
        )
    return "\n".join(lines) + "\n"


def _write_dry_run(config: ContributionLockConfig, preflight: Mapping[str, object]) -> None:
    placeholder = {
        "schema_version": "g1-contribution-lock-dry-run.1.0.0",
        "dry_run": True,
        "scientific_work_performed": False,
    }
    for name in MANDATORY_FIRST_ROUND_FILENAMES:
        path = config.output_root / name
        if name == "CONTRIBUTION_LOCK_MANIFEST.json":
            continue
        if name == "CONTRIBUTION_FAILURES.jsonl":
            _write_text_new(path, "")
        elif name == "PRIOR_ART_BOUNDARY.md":
            _write_text_new(path, _prior_art_boundary())
        elif name == "CONTRIBUTION_LOCK_DECISION.md":
            _write_text_new(
                path, _decision_markdown("CONTRIBUTION_NOT_SUPPORTED", dry_run=True)
            )
        else:
            _write_json_new(path, {**placeholder, "artifact": name})
    _write_manifest(
        config,
        preflight,
        dry_run=True,
        scientific_work=False,
        final_decision="CONTRIBUTION_NOT_SUPPORTED",
    )


def _stream_parent_graph_cache(
    config: ContributionLockConfig,
    dependencies: RunnerDependencies,
    matched_data: Mapping[str, object],
) -> dict[str, object]:
    cache = config.output_root / "engineering" / "graph_cache"
    cache.mkdir(parents=True, exist_ok=False)
    parent_count = 0
    node_count = 0
    accepted_node_count = 0
    round_trip_failures = 0
    label_group_count = 0
    final_set_parent_count = 0
    edge_count = 0
    exact_round_trip_count = 0
    legal_action_count = 0
    viable_action_count = 0
    nonviable_legal_action_count = 0
    orbit_count_distribution: Counter[int] = Counter()
    file_hashes: dict[str, str] = {}
    observed_assignments: list[tuple[str, str]] = []
    expected_orbit_counts = dict(matched_data["orbit_counts"])  # type: ignore[arg-type]
    for index, parent in enumerate(dependencies.iter_parents()):
        record = dict(dependencies.build_parent_graph_record(parent))
        if not record.get("parent_id"):
            raise ValueError("streamed graph record requires parent_id provenance")
        split = str(record.get("split", ""))
        if split not in ("train_fit", "validation"):
            raise ValueError("streamed graph record requires a public split")
        parent_id = str(record["parent_id"])
        observed_assignments.append((parent_id, split))
        orbit_count = int(record.get("orbit_count", 0))
        if orbit_count != expected_orbit_counts.get(parent_id) or not (
            config.expected_minimum_orbit_count
            <= orbit_count
            <= config.expected_maximum_orbit_count
        ):
            raise ValueError("streamed graph orbit count differs from frozen cohort")
        expected_nodes = 1 << orbit_count
        expected_edges = orbit_count * (1 << (orbit_count - 1))
        parent_nodes = int(record.get("node_count", 0))
        parent_edges = int(record.get("edge_count", 0))
        parent_legal = int(record.get("legal_action_count", -1))
        parent_viable = int(record.get("viable_action_count", -1))
        parent_nonviable = int(record.get("nonviable_legal_action_count", -1))
        if (
            parent_nodes != expected_nodes
            or int(record.get("accepted_node_count", 0)) != expected_nodes
            or parent_edges != expected_edges
            or int(record.get("exact_round_trip_count", 0)) != expected_edges
            or int(record.get("round_trip_failure_count", -1)) != 0
            or int(record.get("trajectory_replay_failure_count", -1)) != 0
            or record.get("path_count_check_passed") is not True
            or parent_legal < 0
            or parent_viable < 0
            or parent_nonviable < 0
            or parent_viable + parent_nonviable != parent_legal
            or int(record.get("label_group_count", 0)) != expected_nodes - 1
            or int(record.get("final_set_parent_count", 0)) != 1
        ):
            raise ValueError("streamed graph replay/path/label contract failed")
        orbit_count_distribution[orbit_count] += 1
        path = cache / f"parent_{index:06d}.json"
        _write_json_new(path, record)
        relative = path.relative_to(config.output_root).as_posix()
        file_hashes[relative] = _sha256(path)
        parent_count += 1
        node_count += int(record.get("node_count", 0))
        accepted_node_count += int(record.get("accepted_node_count", 0))
        round_trip_failures += int(record.get("round_trip_failure_count", 0))
        label_group_count += int(record.get("label_group_count", 0))
        final_set_parent_count += int(record.get("final_set_parent_count", 0))
        edge_count += parent_edges
        exact_round_trip_count += int(record["exact_round_trip_count"])
        legal_action_count += parent_legal
        viable_action_count += parent_viable
        nonviable_legal_action_count += parent_nonviable
    if parent_count != config.expected_parent_count:
        raise ValueError("frozen parent count mismatch")
    if node_count != config.expected_subset_node_count:
        raise ValueError("theoretical subset-node count mismatch")
    if accepted_node_count != node_count or round_trip_failures != 0:
        raise ValueError("state graph replay failed closed")
    if final_set_parent_count != parent_count:
        raise ValueError("FINAL_SET must contain exactly one record per parent")
    observed_assignments.sort()
    if tuple(observed_assignments) != tuple(matched_data["assignments"]):
        raise ValueError("streamed graph parents differ from frozen split assignments")
    expected_distribution = {
        int(count): int(frequency)
        for count, frequency in dict(
            matched_data["orbit_count_distribution"]  # type: ignore[arg-type]
        ).items()
    }
    if dict(sorted(orbit_count_distribution.items())) != expected_distribution:
        raise ValueError("streamed graph orbit-count distribution drifted")
    cache_identity = hashlib.sha256(
        json.dumps(file_hashes, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    return {
        "cache_directory": str(cache.resolve()),
        "parent_count": parent_count,
        "theoretical_node_count": node_count,
        "accepted_node_count": accepted_node_count,
        "round_trip_failure_count": round_trip_failures,
        "label_group_count": label_group_count,
        "final_set_parent_count": final_set_parent_count,
        "minimum_orbit_count": min(orbit_count_distribution),
        "maximum_orbit_count": max(orbit_count_distribution),
        "orbit_count_distribution": dict(sorted(orbit_count_distribution.items())),
        "edge_count": edge_count,
        "exact_round_trip_count": exact_round_trip_count,
        "trajectory_replay_failure_count": 0,
        "path_count_check_passed": True,
        "legal_action_count": legal_action_count,
        "viable_action_count": viable_action_count,
        "nonviable_legal_action_count": nonviable_legal_action_count,
        "legal_action_label_coverage_passed": (
            viable_action_count + nonviable_legal_action_count == legal_action_count
        ),
        "file_sha256": file_hashes,
        "corpus_cache_identity_sha256": cache_identity,
    }


def _validate_training_report(
    report: Mapping[str, object], *, mode: str, seed: int
) -> None:
    if report.get("feature_mode") != mode or report.get("root_seed") != seed:
        raise ValueError("training report mode or seed mismatch")
    if report.get("updates_completed") != TOTAL_UPDATES:
        raise ValueError("training did not stop at exactly 5000 updates")
    gate = report.get("preflight_gate")
    if not isinstance(gate, Mapping) or gate.get("update") != PREFLIGHT_UPDATES:
        raise ValueError("training finite gate is not exactly update 500")
    finite_keys = (
        "forward_loss_finite",
        "gradients_finite",
        "parameters_finite",
        "validation_loss_finite",
    )
    if not all(gate.get(key) is True for key in finite_keys):
        raise ValueError("training finite gate failed")
    continuation = report.get("continuation_evidence")
    if not isinstance(continuation, Mapping) or not (
        continuation.get("same_model_object") is True
        and continuation.get("same_optimizer_object") is True
        and continuation.get("same_generator_object") is True
        and continuation.get("restart_or_checkpoint_reload") is False
    ):
        raise ValueError("training did not continue the same live objects")
    training = report.get("training_config")
    if not isinstance(training, Mapping) or (
        training.get("root_seed") != seed
        or training.get("preflight_updates") != PREFLIGHT_UPDATES
        or training.get("total_updates") != TOTAL_UPDATES
    ):
        raise ValueError("training configuration drifted")


def _validate_matched_training(
    graph: Mapping[str, object], final_set: Mapping[str, object]
) -> None:
    keys = (
        "initial_state_sha256",
        "trainable_parameter_count",
        "model_config",
        "optimizer",
        "matched_data_evidence",
        "corpus_cache_identity_sha256",
    )
    if any(graph.get(key) != final_set.get(key) for key in keys):
        raise ValueError("matched scorer architecture or initialization drifted")
    graph_training = dict(graph["training_config"])  # type: ignore[arg-type]
    final_training = dict(final_set["training_config"])  # type: ignore[arg-type]
    if graph_training != final_training:
        raise ValueError("matched scorer optimizer, batch, or update policy drifted")


def _validate_replica_training(
    first: Mapping[str, object], replica: Mapping[str, object]
) -> None:
    for key in (
        "feature_mode",
        "trainable_parameter_count",
        "model_config",
        "optimizer",
        "matched_data_evidence",
        "corpus_cache_identity_sha256",
    ):
        if first.get(key) != replica.get(key):
            raise ValueError("conditional GRAPH training changed a frozen contract")
    first_training = dict(first["training_config"])  # type: ignore[arg-type]
    replica_training = dict(replica["training_config"])  # type: ignore[arg-type]
    first_training.pop("root_seed", None)
    replica_training.pop("root_seed", None)
    if first_training != replica_training:
        raise ValueError("conditional GRAPH training changed optimizer or budget")


def _validate_attempts(
    records: Sequence[Mapping[str, object]],
    conditions: Sequence[Mapping[str, object]],
    *,
    label: str,
    nested_condition: bool,
    mode: str,
    seed: int,
) -> tuple[Mapping[str, object], ...]:
    observed = tuple(records)
    if len(observed) != CONDITION_COUNT:
        raise ValueError(f"{label} must retain exactly 300 attempts with no refill")
    expected_ids = tuple(condition["condition_id"] for condition in conditions)
    observed_ids: list[object] = []
    for record, expected_condition in zip(observed, conditions, strict=True):
        if nested_condition:
            condition = record.get("condition")
            if not isinstance(condition, Mapping):
                raise ValueError(f"{label} record is missing its condition envelope")
            if dict(condition) != dict(expected_condition):
                raise ValueError(f"{label} condition envelope drifted")
            observed_ids.append(condition.get("condition_id"))
            if (
                record.get("policy_arm") != mode
                or record.get("scorer_training_seed") != seed
                or record.get("retry_count") != 0
                or record.get("refill_count") != 0
            ):
                raise ValueError(f"{label} mode, seed, or no-refill contract drifted")
        else:
            observed_ids.append(record.get("condition_id"))
            if (
                record.get("feature_mode") != mode
                or record.get("training_seed") != seed
            ):
                raise ValueError(f"{label} mode or seed contract drifted")
    if tuple(observed_ids) != expected_ids:
        raise ValueError(f"{label} condition alignment drifted")
    return observed


def _condition_cohort_sha256(
    condition_ids: Sequence[str], *, sort_ids: bool
) -> str:
    observed = tuple(condition_ids)
    if len(observed) != CONDITION_COUNT or len(set(observed)) != CONDITION_COUNT:
        raise ValueError("condition cohort must contain exactly 300 unique IDs")
    if any(not isinstance(value, str) or not value for value in observed):
        raise ValueError("condition cohort IDs must be non-empty strings")
    ordered = sorted(observed) if sort_ids else list(observed)
    return hashlib.sha256("\n".join(ordered).encode("utf-8")).hexdigest()


def _validate_first_round_analysis(
    analysis: Mapping[str, object],
    *,
    expected_condition_ids: Sequence[str],
) -> tuple[dict[str, object], bool, str]:
    paired = analysis.get("paired_statistics")
    by_space_group = analysis.get("by_space_group")
    if not isinstance(paired, Mapping) or paired.get("resamples") != 10_000:
        raise ValueError("paired analysis must use exactly 10000 resamples")
    if not isinstance(by_space_group, Mapping):
        raise ValueError("space-group analysis is missing")

    endpoint1 = paired.get("endpoint1")
    endpoint2 = paired.get("endpoint2")
    short_contact = paired.get("short_contact")
    macro = by_space_group.get("endpoint1_macro_comparisons")
    if not all(
        isinstance(value, Mapping)
        for value in (endpoint1, endpoint2, short_contact, macro)
    ):
        raise ValueError("first-round comparison maps are incomplete")
    recomputed = evaluate_orbit_graph_signal(
        endpoint1=endpoint1,  # type: ignore[arg-type]
        endpoint2=endpoint2,  # type: ignore[arg-type]
        short_contact=short_contact,  # type: ignore[arg-type]
        space_group_macro=macro,  # type: ignore[arg-type]
    )
    if analysis.get("signal") != recomputed or paired.get("signal") != recomputed:
        raise ValueError("first-round signal summary drifted from raw statistics")

    expected_hash = _condition_cohort_sha256(
        expected_condition_ids, sort_ids=False
    )
    first_comparison = endpoint1.get("UNIFORM_LEGAL")  # type: ignore[union-attr]
    if (
        not isinstance(first_comparison, Mapping)
        or first_comparison.get("condition_ids_sha256") != expected_hash
    ):
        raise ValueError("first-round statistics use the wrong condition cohort")

    required_groups = tuple(by_space_group.get("required_space_groups", ()))
    groups = by_space_group.get("groups")
    if (
        by_space_group.get("space_group_count") != len(FROZEN_SPACE_GROUPS)
        or required_groups != FROZEN_SPACE_GROUPS
        or not isinstance(groups, Mapping)
        or set(groups) != {str(value) for value in FROZEN_SPACE_GROUPS}
    ):
        raise ValueError("space-group report does not cover the frozen eight groups")
    group_count = 0
    for space_group in FROZEN_SPACE_GROUPS:
        row = groups[str(space_group)]
        if not isinstance(row, Mapping):
            raise ValueError("space-group report row is not a mapping")
        count = int(row.get("condition_count", 0))
        if count <= 0:
            raise ValueError("space-group report contains an empty frozen group")
        group_count += count
    if group_count != CONDITION_COUNT:
        raise ValueError("space-group report does not preserve 300 conditions")

    supported = recomputed["ORBIT_GRAPH_CONTRIBUTION_SIGNAL"] == "SUPPORTED"
    if analysis.get("single_seed_supported") is not supported:
        raise ValueError("single-seed signal summary drifted from raw statistics")
    expected_decision = choose_final_contribution_label(
        first_round_graph_exceeds_both=bool(
            recomputed["endpoint1_dual_strict_ci_pass"]
        ),
        orbit_graph_replicated=False,
        relation_gain_replicated=False,
        prior_art_distinct=True,
    )
    if analysis.get("decision") != expected_decision:
        raise ValueError("first-round decision drifted from raw statistics")
    return recomputed, supported, expected_decision


def _validate_replication_analysis(
    replication: Mapping[str, object],
    *,
    expected_condition_ids: Sequence[str],
) -> bool:
    expected_seeds = [ROOT_SEED, *CONDITIONAL_EXTRA_SEEDS]
    if (
        replication.get("training_seeds") != expected_seeds
        or replication.get("condition_count_per_seed") != CONDITION_COUNT
        or replication.get("resamples") != 10_000
        or replication.get("seed") != ROOT_SEED
        or replication.get("resampling_order")
        != "training seed then paired condition"
    ):
        raise ValueError("three-seed replication contract drifted")
    expected_hash = _condition_cohort_sha256(
        expected_condition_ids, sort_ids=True
    )
    if replication.get("condition_ids_sha256") != expected_hash:
        raise ValueError("three-seed replication uses the wrong condition cohort")

    raw_deltas = replication.get("seed_level_observed_deltas")
    expected_keys = {str(value) for value in expected_seeds}
    if not isinstance(raw_deltas, Mapping) or set(raw_deltas) != expected_keys:
        raise ValueError("replication must report all three registered seed deltas")
    deltas = [float(raw_deltas[str(seed)]) for seed in expected_seeds]
    if any(not math.isfinite(value) or not -1.0 <= value <= 1.0 for value in deltas):
        raise ValueError("replication seed deltas must be finite rates")
    observed_mean = statistics.fmean(deltas)
    observed_std = statistics.stdev(deltas)
    try:
        reported_mean = float(replication["observed_mean_delta"])
        reported_std = float(replication["observed_std_delta"])
    except (KeyError, TypeError, ValueError) as error:
        raise ValueError("replication mean or standard deviation is missing") from error
    if not (
        math.isclose(reported_mean, observed_mean, rel_tol=0.0, abs_tol=1e-12)
        and math.isclose(reported_std, observed_std, rel_tol=0.0, abs_tol=1e-12)
    ):
        raise ValueError("replication aggregates drifted from seed-level values")

    interval = replication.get("confidence_interval_95")
    if (
        not isinstance(interval, (list, tuple))
        or len(interval) != 2
        or any(not math.isfinite(float(value)) for value in interval)
        or float(interval[0]) > float(interval[1])
        or any(not -1.0 <= float(value) <= 1.0 for value in interval)
    ):
        raise ValueError("replication hierarchical-bootstrap interval is invalid")
    all_positive = all(value > 0.0 for value in deltas)
    replicated = all_positive and observed_mean > 0.0
    if (
        replication.get("all_seed_observed_deltas_positive") is not all_positive
        or replication.get("ORBIT_GRAPH_CONTRIBUTION_REPLICATED") is not replicated
    ):
        raise ValueError("replication summary drifted from seed-level values")
    return replicated


def _run_seed(
    config: ContributionLockConfig,
    dependencies: RunnerDependencies,
    conditions: Sequence[Mapping[str, object]],
    matched_data_evidence: Mapping[str, object],
    corpus_cache_identity_sha256: str,
    *,
    seed: int,
    modes: tuple[str, ...],
) -> dict[str, object]:
    cache = config.output_root / "engineering" / "graph_cache"
    seed_root = config.output_root / "engineering" / f"seed_{seed}"
    seed_root.mkdir(parents=True, exist_ok=False)
    reports: dict[str, Mapping[str, object]] = {}
    generations: dict[str, tuple[Mapping[str, object], ...]] = {}
    fixed_cell: dict[str, tuple[Mapping[str, object], ...]] = {}
    for mode in modes:
        report = dict(
            dependencies.train_action_scorer(mode, seed, cache, seed_root / mode.lower())
        )
        report["optimizer"] = "torch.optim.AdamW"
        report["matched_data_evidence"] = dict(matched_data_evidence)
        report["corpus_cache_identity_sha256"] = corpus_cache_identity_sha256
        _validate_training_report(report, mode=mode, seed=seed)
        records = _validate_attempts(
            dependencies.generate_scored_attempts(mode, seed, report, conditions),
            conditions,
            label=f"{mode} generation",
            nested_condition=True,
            mode=mode,
            seed=seed,
        )
        evaluated = _validate_attempts(
            dependencies.evaluate_fixed_cell_fire300(mode, seed, records),
            conditions,
            label=f"{mode} fixed-cell FIRE300",
            nested_condition=False,
            mode=mode,
            seed=seed,
        )
        if any(
            record.get("fixed_cell") is not True
            or record.get("fire_steps") != FIRE_STEPS
            for record in evaluated
        ):
            raise ValueError("physical evaluation must be fixed-cell FIRE300")
        reports[mode] = report
        generations[mode] = records
        fixed_cell[mode] = evaluated
    if modes == ("GRAPH_VIABILITY", "FINAL_SET_MEMBERSHIP"):
        _validate_matched_training(
            reports["GRAPH_VIABILITY"], reports["FINAL_SET_MEMBERSHIP"]
        )
    return {
        "seed": seed,
        "training": reports,
        "generation": generations,
        "fixed_cell_fire300": fixed_cell,
    }


def _failure_ledger_text(seed_runs: Sequence[Mapping[str, object]]) -> str:
    rows: list[dict[str, object]] = []
    for seed_run in seed_runs:
        seed = int(seed_run["seed"])
        generation = seed_run["generation"]
        fixed_cell = seed_run["fixed_cell_fire300"]
        if not isinstance(generation, Mapping) or not isinstance(fixed_cell, Mapping):
            raise ValueError("seed results are not grouped by feature mode")
        for mode in sorted(fixed_cell):
            generated_records = generation.get(mode)
            fixed_records = fixed_cell[mode]
            if not isinstance(generated_records, Sequence) or not isinstance(
                fixed_records, Sequence
            ):
                raise ValueError("fixed-cell feature-mode result is not a sequence")
            generation_failed: set[str] = set()
            for record in generated_records:
                if not isinstance(record, Mapping):
                    raise ValueError("generation attempt record is not a mapping")
                condition = record.get("condition")
                if not isinstance(condition, Mapping):
                    raise ValueError("generation attempt lacks a condition envelope")
                condition_id = str(condition.get("condition_id", ""))
                projector_reasons = tuple(
                    str(value)
                    for value in record.get("projector_rejection_reasons", ())
                )
                reason = record.get("failure_reason")
                if reason is None and projector_reasons:
                    reason = (
                        "SHORT_CONTACT"
                        if "SHORT_CONTACT" in projector_reasons
                        else projector_reasons[0]
                    )
                if reason is None:
                    reason = record.get("failure_code")
                if reason is None and not bool(record.get("legal_terminal_crystal")):
                    reason = "NOT_LEGAL_TERMINAL"
                if reason is None:
                    continue
                generation_failed.add(condition_id)
                row: dict[str, object] = {
                    "condition_id": condition_id,
                    "failure_reason": str(reason),
                    "feature_mode": mode,
                    "stage": "GENERATION",
                    "training_seed": seed,
                }
                if projector_reasons:
                    row["projector_rejection_reasons"] = list(projector_reasons)
                rows.append(row)
            for record in fixed_records:
                if not isinstance(record, Mapping):
                    raise ValueError("fixed-cell attempt record is not a mapping")
                condition_id = str(record.get("condition_id", ""))
                if condition_id in generation_failed:
                    continue
                symmetry_survival = bool(record.get("post_relax_survival")) and bool(
                    record.get("space_group_match")
                )
                if symmetry_survival:
                    continue
                reason = record.get("failure_reason") or record.get("status")
                if reason in (None, "EVALUATED"):
                    reason = "FIXED_CELL_NOT_SYMMETRY_PRESERVING_SURVIVAL"
                rows.append(
                    {
                        "condition_id": condition_id,
                        "failure_reason": reason,
                        "feature_mode": mode,
                        "stage": "FIXED_CELL_FIRE300",
                        "training_seed": seed,
                    }
                )
    return "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)


def _append_failure_record(path: Path, payload: Mapping[str, object]) -> None:
    content = (json.dumps(dict(payload), sort_keys=True) + "\n").encode("utf-8")
    descriptor = os.open(path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
    try:
        os.write(descriptor, content)
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _run_live(
    config: ContributionLockConfig,
    preflight: Mapping[str, object],
    dependencies: RunnerDependencies,
) -> None:
    conditions = tuple(preflight["conditions"])  # type: ignore[arg-type]
    matched_data = dict(preflight["matched_data_evidence"])  # type: ignore[arg-type]
    assignments = matched_data.pop("assignments")
    orbit_counts = matched_data.pop("orbit_counts")
    graph = _stream_parent_graph_cache(
        config,
        dependencies,
        {
            **matched_data,
            "assignments": assignments,
            "orbit_counts": orbit_counts,
        },
    )
    _write_json_new(
        config.output_root / "DECONSTRUCTION_STATE_GRAPH_AUDIT.json",
        {
            "schema_version": "g1-deconstruction-state-graph-audit.1.0.0",
            **graph,
            "sealed_or_blind_data_accessed": False,
        },
    )
    _write_json_new(
        config.output_root / "STATE_GRAPH_REPLAY_REPORT.json",
        {
            "schema_version": "g1-state-graph-replay.1.0.0",
            "operator": "D_orbit",
            "forward_direction": "REMOVE",
            "inverse_direction": "RESTORE",
            "round_trip_definition": (
                "structural state hash exactness plus frozen C0 state-contract equality"
            ),
            "frozen_projector_minimum_distance": 0.5,
            "parent_count": graph["parent_count"],
            "theoretical_node_count": graph["theoretical_node_count"],
            "accepted_node_count": graph["accepted_node_count"],
            "edge_count": graph["edge_count"],
            "exact_round_trip_count": graph["exact_round_trip_count"],
            "round_trip_failure_count": graph["round_trip_failure_count"],
            "trajectory_replay_failure_count": graph[
                "trajectory_replay_failure_count"
            ],
            "path_count_check_passed": graph["path_count_check_passed"],
            "exact_replay_passed": True,
        },
    )
    _write_json_new(
        config.output_root / "MULTIPOSITIVE_VIABILITY_DATA_REPORT.json",
        {
            "schema_version": "g1-multipositive-viability-data.1.0.0",
            "label_group_count": graph["label_group_count"],
            "final_set_parent_count": graph["final_set_parent_count"],
            "legal_action_count": graph["legal_action_count"],
            "viable_action_count": graph["viable_action_count"],
            "nonviable_legal_action_count": graph[
                "nonviable_legal_action_count"
            ],
            "legal_action_label_coverage_passed": graph[
                "legal_action_label_coverage_passed"
            ],
            "target": "all-compiler-legal-action multi-label BCE",
            "one_hot_inverse_target_used": False,
        },
    )

    first = _run_seed(
        config,
        dependencies,
        conditions,
        matched_data,
        str(graph["corpus_cache_identity_sha256"]),
        seed=config.root_seed,
        modes=("GRAPH_VIABILITY", "FINAL_SET_MEMBERSHIP"),
    )
    seed_runs = [first]
    training = first["training"]
    generation = first["generation"]
    fixed_cell = first["fixed_cell_fire300"]
    _write_json_new(
        config.output_root / "FINAL_SET_BASELINE_REPORT.json",
        {
            "schema_version": "g1-final-set-baseline.1.0.0",
            "training": training["FINAL_SET_MEMBERSHIP"],  # type: ignore[index]
            "generation_records": generation["FINAL_SET_MEMBERSHIP"],  # type: ignore[index]
            "fixed_cell_fire300": fixed_cell["FINAL_SET_MEMBERSHIP"],  # type: ignore[index]
        },
    )
    _write_json_new(
        config.output_root / "GRAPH_VIABILITY_TRAINING_REPORT.json",
        training["GRAPH_VIABILITY"],  # type: ignore[index]
    )
    _write_json_new(
        config.output_root / "GRAPH_VIABILITY_GENERATION_RESULTS.json",
        {
            "schema_version": "g1-graph-viability-generation.1.0.0",
            "generation_records": generation["GRAPH_VIABILITY"],  # type: ignore[index]
            "fixed_cell_fire300": fixed_cell["GRAPH_VIABILITY"],  # type: ignore[index]
            "condition_count": CONDITION_COUNT,
            "condition_refill": False,
        },
    )

    analysis = dict(dependencies.analyze_first_round(first))
    paired = analysis.get("paired_statistics")
    by_space_group = analysis.get("by_space_group")
    signal, single_seed_supported, decision = _validate_first_round_analysis(
        analysis,
        expected_condition_ids=[str(condition["condition_id"]) for condition in conditions],
    )
    analysis["signal"] = signal
    assert isinstance(paired, Mapping)
    assert isinstance(by_space_group, Mapping)
    _write_json_new(config.output_root / "CONTRIBUTION_PAIRED_STATISTICS.json", paired)
    _write_json_new(config.output_root / "CONTRIBUTION_BY_SPACE_GROUP.json", by_space_group)

    replication: Mapping[str, object] | None = None
    relation_audit: Mapping[str, object] | None = None
    if single_seed_supported:
        for seed in config.conditional_extra_seeds:
            replica = _run_seed(
                    config,
                    dependencies,
                    conditions,
                    matched_data,
                    str(graph["corpus_cache_identity_sha256"]),
                    seed=seed,
                    modes=("GRAPH_VIABILITY",),
                )
            _validate_replica_training(
                first["training"]["GRAPH_VIABILITY"],  # type: ignore[index]
                replica["training"]["GRAPH_VIABILITY"],  # type: ignore[index]
            )
            seed_runs.append(replica)
        replication = dict(
            dependencies.analyze_replication({"seed_runs": seed_runs})
        )
        replicated = _validate_replication_analysis(
            replication,
            expected_condition_ids=[
                str(condition["condition_id"]) for condition in conditions
            ],
        )
        replication_payload = {
            "schema_version": "g1-contribution-three-seed-replication.1.0.0",
            "training_seeds": [ROOT_SEED, *CONDITIONAL_EXTRA_SEEDS],
            "baseline": "UNIFORM_LEGAL",
            **replication,
        }
        _write_json_new(
            config.output_root / "CONTRIBUTION_THREE_SEED_REPLICATION.json",
            replication_payload,
        )
        if replicated:
            audit = dict(dependencies.audit_relation_contract())
            relation_contract_complete = (
                audit.get("executable") is True
                and audit.get("operator") == "D_relation_interface"
                and audit.get("stored_state_contract") is True
                and audit.get("stored_action_contract") is True
                and audit.get("inverse_contract") is True
                and audit.get("replay_contract") is True
            )
            if not relation_contract_complete:
                audit["status"] = "RELATION_OPERATOR_NOT_YET_EXECUTABLE"
                relation_audit = audit
                _write_json_new(
                    config.output_root / "RELATION_OPERATOR_AUDIT.json", audit
                )
                decision = "CONTRIBUTION_LOCKED_ORBIT_GRAPH"
            else:
                audit["status"] = "RELATION_OPERATOR_EXECUTABLE"
                relation_audit = audit
                _write_json_new(
                    config.output_root / "RELATION_OPERATOR_AUDIT.json", audit
                )
                relation_result = dependencies.run_relation_contribution(audit)
                if not isinstance(relation_result, Mapping):
                    raise ValueError("relation contribution result must be a mapping")
                _write_json_new(
                    config.output_root / "RELATION_CONTRIBUTION_RESULTS.json",
                    relation_result,
                )
                decision = (
                    "CONTRIBUTION_LOCKED_MULTI_OPERATOR"
                    if relation_result.get("reproducible_gain") is True
                    else "CONTRIBUTION_LOCKED_ORBIT_GRAPH"
                )
        else:
            decision = "NOVEL_FORMULATION_WITHOUT_EMPIRICAL_GAIN"

    _write_text_new(
        config.output_root / "CONTRIBUTION_FAILURES.jsonl",
        _failure_ledger_text(seed_runs),
    )
    _write_text_new(config.output_root / "PRIOR_ART_BOUNDARY.md", _prior_art_boundary())
    _write_text_new(
        config.output_root / "CONTRIBUTION_LOCK_DECISION.md",
        _decision_markdown(
            decision,
            dry_run=False,
            first_round=analysis,
            replication=replication,
            relation_audit=relation_audit,
        ),
    )
    _write_manifest(
        config,
        preflight,
        dry_run=False,
        scientific_work=True,
        final_decision=decision,
    )


def _write_manifest(
    config: ContributionLockConfig,
    preflight: Mapping[str, object],
    *,
    dry_run: bool,
    scientific_work: bool,
    final_decision: str,
) -> None:
    if final_decision not in ALLOWED_FINAL_LABELS:
        raise ValueError("manifest final decision is not registered")
    missing = [
        name
        for name in MANDATORY_FIRST_ROUND_FILENAMES
        if name != "CONTRIBUTION_LOCK_MANIFEST.json"
        and not (config.output_root / name).is_file()
    ]
    if missing:
        raise RuntimeError(f"mandatory contribution artifacts missing: {missing}")
    files = sorted(
        path
        for path in config.output_root.rglob("*")
        if path.is_file() and path.name != "CONTRIBUTION_LOCK_MANIFEST.json"
    )
    file_hashes = {
        path.relative_to(config.output_root).as_posix(): _sha256(path) for path in files
    }
    matched_data = dict(preflight["matched_data_evidence"])  # type: ignore[arg-type]
    matched_data.pop("assignments", None)
    matched_data.pop("orbit_counts", None)
    manifest = {
        "schema_version": "g1-contribution-lock-manifest.1.0.0",
        "dry_run": dry_run,
        "scientific_work_performed": scientific_work,
        "final_decision": final_decision,
        "root_seed": ROOT_SEED,
        "conditional_extra_seeds": list(CONDITIONAL_EXTRA_SEEDS),
        "preflight_updates": PREFLIGHT_UPDATES,
        "total_updates": TOTAL_UPDATES,
        "condition_count": CONDITION_COUNT,
        "temperature": TEMPERATURE,
        "fixed_cell_fire_steps": FIRE_STEPS,
        "condition_refill": False,
        "sealed_or_blind_data_accessed": False,
        "SINGLE_PATH_INVERSE_ACTION_POLICY_NOT_SUPPORTED": True,
        "SINGLE_PATH_ACTION_POLICY_FAILURE_ROBUST": True,
        "old_cssd_claim_adopted_as_main_contribution": False,
        "frozen_input_sha256": preflight["artifact_sha256"],
        "frozen_implementation": preflight["implementation"],
        "contribution_implementation": preflight["contribution_implementation"],
        "matched_data_evidence": matched_data,
        "file_sha256": file_hashes,
    }
    _write_json_new(
        config.output_root / "CONTRIBUTION_LOCK_MANIFEST.json", manifest
    )


def run_contribution_lock(
    config: ContributionLockConfig,
    *,
    dependencies: RunnerDependencies | None = None,
    dry_run: bool = False,
) -> Path:
    """Execute the frozen contribution lock once, with no retry or overwrite."""

    if not dry_run and dependencies is None:
        raise ValueError("scientific execution requires explicit runner dependencies")
    preflight = _verify_preflight(config)
    config.output_root.mkdir(parents=True, exist_ok=False)
    if dry_run:
        _write_dry_run(config, preflight)
        return config.output_root
    assert dependencies is not None
    try:
        _run_live(config, preflight, dependencies)
    except BaseException as error:
        failure = config.output_root / "CONTRIBUTION_FAILURES.jsonl"
        _append_failure_record(
            failure,
            {
                "stage": "CONTRIBUTION_LOCK",
                "error_type": type(error).__name__,
                "error": str(error),
                "retry_performed": False,
            },
        )
        raise
    return config.output_root
