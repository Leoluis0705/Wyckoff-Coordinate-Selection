from __future__ import annotations

import hashlib
import json
import math
from collections import Counter
from pathlib import Path
from typing import Any, Mapping, Sequence
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import numpy as np
from pymatgen.analysis.structure_matcher import StructureMatcher
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter
from scipy.stats import binomtest


def _record_by_condition(
    records: Sequence[Mapping[str, Any]],
) -> dict[str, Mapping[str, Any]]:
    result: dict[str, Mapping[str, Any]] = {}
    for record in records:
        condition_id = str(record["condition_id"])
        if condition_id in result:
            raise ValueError(f"duplicate relaxation condition: {condition_id}")
        result[condition_id] = record
    return result


def _force_summary(values: Sequence[float]) -> dict[str, Any]:
    array = np.asarray(values, dtype=float)
    if array.size == 0:
        return {
            "sample_count": 0,
            "mean": None,
            "median": None,
            "p90": None,
            "p95": None,
        }
    return {
        "sample_count": int(array.size),
        "mean": float(np.mean(array)),
        "median": float(np.median(array)),
        "p90": float(np.quantile(array, 0.90)),
        "p95": float(np.quantile(array, 0.95)),
    }


def _relaxation_summary(
    records: Sequence[Mapping[str, Any]],
    *,
    attempt_count: int,
) -> dict[str, Any]:
    evaluated = [record for record in records if record.get("status") == "EVALUATED"]
    convergence = sum(bool(record.get("converged")) for record in records)
    physical = sum(bool(record.get("post_relax_survival")) for record in records)
    symmetry_preserving = sum(
        bool(record.get("post_relax_survival"))
        and bool(record.get("space_group_match"))
        for record in records
    )
    final_forces = [
        float(record["post_max_force_ev_per_angstrom"])
        for record in evaluated
        if record.get("post_max_force_ev_per_angstrom") is not None
    ]
    return {
        "attempt_count": attempt_count,
        "evaluated_count": len(evaluated),
        "convergence_count": convergence,
        "convergence_rate_all_attempts": convergence / attempt_count,
        "physical_survival_count": physical,
        "physical_survival_rate_all_attempts": physical / attempt_count,
        "symmetry_preserving_physical_survival_count": symmetry_preserving,
        "symmetry_preserving_physical_survival_rate_all_attempts": (
            symmetry_preserving / attempt_count
        ),
        "target_space_group_after_relaxation_match_count": sum(
            bool(record.get("space_group_match")) for record in records
        ),
        "target_space_group_after_relaxation_match_rate_all_attempts": sum(
            bool(record.get("space_group_match")) for record in records
        )
        / attempt_count,
        "final_max_force_ev_per_angstrom": _force_summary(final_forces),
    }


def summarize_arm(
    generation_records: Sequence[Mapping[str, Any]],
    *,
    fixed_cell_records: Sequence[Mapping[str, Any]],
    cell_relax_records: Sequence[Mapping[str, Any]],
    uniqueness: Mapping[str, int],
) -> dict[str, Any]:
    if not generation_records:
        raise ValueError("generation records must not be empty")
    attempt_count = len(generation_records)
    generation_ids = [
        str(record["condition"]["condition_id"]) for record in generation_records
    ]
    if len(set(generation_ids)) != attempt_count:
        raise ValueError("generation condition IDs must be unique")
    fixed = _record_by_condition(fixed_cell_records)
    cell = _record_by_condition(cell_relax_records)
    if set(fixed) != set(generation_ids) or set(cell) != set(generation_ids):
        raise ValueError("CHGNet records must cover every generation condition exactly")
    fixed_ordered = [fixed[condition_id] for condition_id in generation_ids]
    cell_ordered = [cell[condition_id] for condition_id in generation_ids]
    initial_forces = [
        float(record["pre_max_force_ev_per_angstrom"])
        for record in fixed_ordered
        if record.get("status") == "EVALUATED"
        and record.get("pre_max_force_ev_per_angstrom") is not None
    ]
    latencies = np.asarray(
        [float(record["latency_seconds"]) for record in generation_records],
        dtype=float,
    )
    terminal_count = sum(
        bool(record.get("legal_terminal_crystal")) for record in generation_records
    )
    projector_attempts = sum(
        int(record.get("projector_attempt_count", 0)) for record in generation_records
    )
    projector_rejections = sum(
        int(record.get("projector_rejection_count", 0))
        for record in generation_records
    )
    return {
        "attempt_count": attempt_count,
        "failure_denominator": attempt_count,
        "all_failures_counted_in_denominator": True,
        "free_rollout_completion_rate": sum(
            bool(record.get("completed")) for record in generation_records
        )
        / attempt_count,
        "symmetry_valid_legal_terminal_count": terminal_count,
        "symmetry_valid_legal_terminal_rate": terminal_count / attempt_count,
        "target_SG_match": {
            "count": sum(
                bool(record.get("post_projector_target_space_group_match"))
                for record in generation_records
            ),
            "rate": sum(
                bool(record.get("post_projector_target_space_group_match"))
                for record in generation_records
            )
            / attempt_count,
        },
        "Wyckoff_orbit_validity": {
            "count": sum(
                bool(record.get("wyckoff_orbit_valid"))
                for record in generation_records
            ),
            "rate": sum(
                bool(record.get("wyckoff_orbit_valid"))
                for record in generation_records
            )
            / attempt_count,
        },
        "composition_validity": {
            "count": sum(
                bool(record.get("composition_valid"))
                for record in generation_records
            ),
            "rate": sum(
                bool(record.get("composition_valid"))
                for record in generation_records
            )
            / attempt_count,
        },
        "multiplicity_validity": {
            "count": sum(
                bool(record.get("multiplicity_valid"))
                for record in generation_records
            ),
            "rate": sum(
                bool(record.get("multiplicity_valid"))
                for record in generation_records
            )
            / attempt_count,
        },
        "NO_LEGAL_ADD_ORBIT_ACTION_count": sum(
            record.get("failure_code") == "NO_LEGAL_ADD_ORBIT_ACTION"
            for record in generation_records
        ),
        "PROJECTOR_REJECTED_count": sum(
            record.get("failure_code") == "PROJECTOR_REJECTED"
            for record in generation_records
        ),
        "SHORT_CONTACT_rejection_count": sum(
            "SHORT_CONTACT" in record.get("projector_rejection_reasons", ())
            for record in generation_records
        ),
        "short_contact_free_rate": sum(
            bool(record.get("short_contact_free")) for record in generation_records
        )
        / attempt_count,
        "projector_attempt_count": projector_attempts,
        "projector_rejection_count": projector_rejections,
        "projector_rejection_rate_per_attempt": (
            projector_rejections / max(projector_attempts, 1)
        ),
        "failure_taxonomy": dict(
            sorted(
                Counter(
                    str(record.get("failure_code") or "NONE")
                    for record in generation_records
                ).items()
            )
        ),
        "initial_CHGNet_max_force": _force_summary(initial_forces),
        "fixed_cell_FIRE300": _relaxation_summary(
            fixed_ordered, attempt_count=attempt_count
        ),
        "cell_relax_FIRE300": _relaxation_summary(
            cell_ordered, attempt_count=attempt_count
        ),
        "unique_structures": int(uniqueness["unique_count"]),
        "novel_structures_relative_to_train_fit": int(
            uniqueness["novel_vs_train_fit_count"]
        ),
        "novel_structures_relative_to_full_7838_parent_cohort": int(
            uniqueness["novel_vs_full_cohort_count"]
        ),
        "generation_latency_seconds": {
            "mean": float(np.mean(latencies)),
            "median": float(np.median(latencies)),
            "p90": float(np.quantile(latencies, 0.90)),
            "p95": float(np.quantile(latencies, 0.95)),
            "total": float(np.sum(latencies)),
        },
    }


def summarize_by_space_group(
    generation_records: Sequence[Mapping[str, Any]],
    *,
    fixed_cell_records: Sequence[Mapping[str, Any]],
    cell_relax_records: Sequence[Mapping[str, Any]],
    required_space_groups: Sequence[int],
) -> dict[str, dict[str, Any]]:
    fixed = _record_by_condition(fixed_cell_records)
    cell = _record_by_condition(cell_relax_records)
    result: dict[str, dict[str, Any]] = {}
    for space_group in required_space_groups:
        generated = [
            record
            for record in generation_records
            if int(record["condition"]["space_group"]) == int(space_group)
        ]
        if not generated:
            raise ValueError(f"required space group has no conditions: {space_group}")
        condition_ids = [
            str(record["condition"]["condition_id"]) for record in generated
        ]
        fixed_group = [fixed[condition_id] for condition_id in condition_ids]
        cell_group = [cell[condition_id] for condition_id in condition_ids]
        attempts = len(generated)
        terminal = sum(
            bool(record.get("legal_terminal_crystal")) for record in generated
        )
        result[str(space_group)] = {
            "attempts": attempts,
            "terminal_success": terminal,
            "terminal_success_rate": terminal / attempts,
            "no_legal_action": sum(
                record.get("failure_code") == "NO_LEGAL_ADD_ORBIT_ACTION"
                for record in generated
            ),
            "projector_rejection": sum(
                record.get("failure_code") == "PROJECTOR_REJECTED"
                for record in generated
            ),
            "short_contact_rejection": sum(
                "SHORT_CONTACT" in record.get("projector_rejection_reasons", ())
                for record in generated
            ),
            "fixed_cell_CHGNet_convergence": sum(
                bool(record.get("converged")) for record in fixed_group
            ),
            "fixed_cell_symmetry_preserving_survival": sum(
                bool(record.get("post_relax_survival"))
                and bool(record.get("space_group_match"))
                for record in fixed_group
            ),
            "cell_relax_CHGNet_convergence": sum(
                bool(record.get("converged")) for record in cell_group
            ),
            "cell_relax_symmetry_preserving_survival": sum(
                bool(record.get("post_relax_survival"))
                and bool(record.get("space_group_match"))
                for record in cell_group
            ),
        }
    return result


def paired_binary_bootstrap(
    learned: Sequence[bool],
    baseline: Sequence[bool],
    *,
    resamples: int,
    seed: int,
) -> dict[str, Any]:
    left = np.asarray(learned, dtype=float)
    right = np.asarray(baseline, dtype=float)
    if left.shape != right.shape or left.ndim != 1 or left.size == 0:
        raise ValueError("paired endpoint arrays must be non-empty and aligned")
    if resamples <= 0:
        raise ValueError("bootstrap resamples must be positive")
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, left.size, size=(resamples, left.size))
    deltas = (left[indices] - right[indices]).mean(axis=1)
    return {
        "condition_count": int(left.size),
        "observed_learned_rate": float(left.mean()),
        "observed_baseline_rate": float(right.mean()),
        "observed_delta": float((left - right).mean()),
        "confidence_interval_95": [
            float(np.quantile(deltas, 0.025)),
            float(np.quantile(deltas, 0.975)),
        ],
        "resamples": int(resamples),
        "resampling_unit": "paired condition",
        "uncertainty_scope": (
            "condition-level uncertainty only; not training-seed uncertainty"
        ),
    }


def mcnemar_exact(
    learned: Sequence[bool], baseline: Sequence[bool]
) -> dict[str, Any]:
    if len(learned) != len(baseline) or not learned:
        raise ValueError("McNemar inputs must be non-empty and aligned")
    learned_only = sum(bool(left) and not bool(right) for left, right in zip(learned, baseline, strict=True))
    baseline_only = sum(not bool(left) and bool(right) for left, right in zip(learned, baseline, strict=True))
    discordant = learned_only + baseline_only
    p_value = (
        float(binomtest(min(learned_only, baseline_only), discordant, 0.5).pvalue)
        if discordant
        else 1.0
    )
    return {
        "learned_success_baseline_failure": learned_only,
        "learned_failure_baseline_success": baseline_only,
        "discordant_pair_count": discordant,
        "two_sided_exact_p_value": p_value,
    }


def space_group_macro_bootstrap(
    *,
    learned: Sequence[bool],
    baseline: Sequence[bool],
    space_groups: Sequence[int],
    required_space_groups: Sequence[int],
    resamples: int,
    seed: int,
) -> dict[str, Any]:
    left = np.asarray(learned, dtype=float)
    right = np.asarray(baseline, dtype=float)
    groups = np.asarray(space_groups, dtype=int)
    if left.shape != right.shape or left.shape != groups.shape or left.size == 0:
        raise ValueError("macro endpoint arrays must be non-empty and aligned")
    indices_by_group = []
    for space_group in required_space_groups:
        indices = np.flatnonzero(groups == int(space_group))
        if indices.size == 0:
            raise ValueError(f"required space group has no paired conditions: {space_group}")
        indices_by_group.append(indices)
    observed_left = float(
        np.mean([left[indices].mean() for indices in indices_by_group])
    )
    observed_right = float(
        np.mean([right[indices].mean() for indices in indices_by_group])
    )
    rng = np.random.default_rng(seed)
    deltas = np.empty(resamples, dtype=float)
    for sample_index in range(resamples):
        group_deltas = []
        for indices in indices_by_group:
            sampled = rng.choice(indices, size=indices.size, replace=True)
            group_deltas.append(float((left[sampled] - right[sampled]).mean()))
        deltas[sample_index] = float(np.mean(group_deltas))
    return {
        "space_groups": [int(value) for value in required_space_groups],
        "observed_learned_macro_rate": observed_left,
        "observed_baseline_macro_rate": observed_right,
        "observed_delta": observed_left - observed_right,
        "confidence_interval_95": [
            float(np.quantile(deltas, 0.025)),
            float(np.quantile(deltas, 0.975)),
        ],
        "resamples": int(resamples),
        "resampling_unit": "condition within space group",
        "uncertainty_scope": (
            "condition-level uncertainty only; not training-seed uncertainty"
        ),
    }


def choose_attribution_decision(
    *,
    comparable: bool,
    endpoint1: Mapping[str, Mapping[str, Any]],
    endpoint2: Mapping[str, Mapping[str, Any]],
    macro: Mapping[str, Mapping[str, Any]],
) -> str:
    if not comparable:
        return "ATTRIBUTION_INCONCLUSIVE"
    names = ("learned_minus_uniform", "learned_minus_empirical")
    e1_positive = all(float(endpoint1[name]["observed_delta"]) > 0 for name in names)
    e1_significant = all(
        float(endpoint1[name]["confidence_interval_95"][0]) > 0 for name in names
    )
    e2_positive = all(float(endpoint2[name]["observed_delta"]) > 0 for name in names)
    e2_one_significant = any(
        float(endpoint2[name]["confidence_interval_95"][0]) > 0 for name in names
    )
    macro_positive = all(float(macro[name]["observed_delta"]) > 0 for name in names)
    if (
        e1_positive
        and e1_significant
        and e2_positive
        and e2_one_significant
        and macro_positive
    ):
        return "LEARNED_REVERSE_ASSEMBLY_STRONGLY_SUPPORTED"
    if e1_positive:
        return "LEARNED_REVERSE_ASSEMBLY_SUPPORTED_WITH_LIMITATIONS"
    return "CRYSTALLOGRAPHIC_SEARCH_SPACE_IS_PRIMARY_CONTRIBUTOR"


def _structure_from_generation(record: Mapping[str, Any]) -> Structure:
    candidate = record["candidate"]
    return Structure(
        Lattice(np.asarray(candidate["lattice"], dtype=float)),
        [int(value) for value in candidate["atomic_numbers"]],
        np.asarray(candidate["fractional_coordinates"], dtype=float),
        to_unit_cell=True,
    )


def _structure_from_parent(parent: Mapping[str, Any]) -> Structure:
    return Structure(
        Lattice(np.asarray(parent["lattice"]["primitive_matrix"], dtype=float)),
        [int(value) for value in parent["reconstructed_atomic_numbers"]],
        np.asarray(parent["reconstructed_fractional_coordinates"], dtype=float),
        to_unit_cell=True,
    )


def _formula_key(structure: Structure) -> tuple[tuple[int, int], ...]:
    counts = Counter(int(site.specie.Z) for site in structure)
    divisor = math.gcd(*counts.values()) if counts else 1
    return tuple(sorted((species, count // divisor) for species, count in counts.items()))


def _exact_composition_key(structure: Structure) -> tuple[tuple[int, int], ...]:
    return tuple(
        sorted(Counter(int(site.specie.Z) for site in structure).items())
    )


def _descriptor(structure: Structure) -> np.ndarray:
    lengths = np.asarray(structure.lattice.abc, dtype=float)
    lengths = np.sort(lengths / max(float(np.mean(lengths)), 1e-12))
    angles = np.sort(np.asarray(structure.lattice.angles, dtype=float) / 180.0)
    volume_per_atom = math.log(max(structure.volume / max(len(structure), 1), 1e-12))
    if len(structure) > 1:
        distances = np.asarray(structure.distance_matrix, dtype=float)
        distances = distances[np.triu_indices(len(structure), k=1)]
        scale = max((structure.volume / len(structure)) ** (1.0 / 3.0), 1e-12)
        quantiles = np.quantile(distances / scale, [0.0, 0.25, 0.5, 0.75, 1.0])
    else:
        quantiles = np.zeros(5, dtype=float)
    return np.concatenate((lengths, angles, [volume_per_atom], quantiles))


def _relaxation_metadata(record: Mapping[str, Any]) -> dict[str, Any]:
    return {
        key: record.get(key)
        for key in (
            "status",
            "converged",
            "post_relax_survival",
            "space_group_match",
            "detected_space_group",
            "pre_max_force_ev_per_angstrom",
            "post_max_force_ev_per_angstrom",
        )
        if key in record
    }


def _write_deterministic_zip(directory: Path, zip_path: Path) -> None:
    with ZipFile(zip_path, "x", compression=ZIP_DEFLATED) as archive:
        for path in sorted(item for item in directory.iterdir() if item.is_file()):
            info = ZipInfo(path.name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())


def audit_full_cohort_novelty(
    *,
    generation_records: Sequence[Mapping[str, Any]],
    fixed_cell_records: Sequence[Mapping[str, Any]],
    cell_relax_records: Sequence[Mapping[str, Any]],
    parent_rows: Sequence[Mapping[str, Any]],
    train_fit_ids: set[str],
    expected_parent_count: int,
    export_directory: str | Path | None = None,
    zip_path: str | Path | None = None,
) -> dict[str, Any]:
    if len(parent_rows) != expected_parent_count:
        raise ValueError(
            f"full cohort parent count mismatch: {len(parent_rows)} != {expected_parent_count}"
        )
    if (export_directory is None) != (zip_path is None):
        raise ValueError("export directory and ZIP path must be provided together")
    matcher_settings = {
        "primitive_cell": False,
        "scale": True,
        "attempt_supercell": False,
        "ltol": 0.2,
        "stol": 0.3,
        "angle_tol": 5.0,
    }
    matcher = StructureMatcher(**matcher_settings)
    loose_matcher = StructureMatcher(
        primitive_cell=False,
        scale=True,
        attempt_supercell=False,
        ltol=1.0,
        stol=2.0,
        angle_tol=180.0,
    )
    fixed = _record_by_condition(fixed_cell_records)
    cell = _record_by_condition(cell_relax_records)
    legal: list[tuple[Mapping[str, Any], Structure]] = []
    parse_failure_count = 0
    for record in generation_records:
        if not record.get("legal_terminal_crystal"):
            continue
        try:
            legal.append((record, _structure_from_generation(record)))
        except Exception:
            parse_failure_count += 1
    unique_buckets: dict[
        tuple[tuple[int, int], ...], list[tuple[Mapping[str, Any], Structure]]
    ] = {}
    matcher_failure_count = 0
    for record, structure in legal:
        bucket = unique_buckets.setdefault(_formula_key(structure), [])
        try:
            duplicate = any(matcher.fit(structure, prior) for _, prior in bucket)
        except Exception:
            matcher_failure_count += 1
            duplicate = True
        if not duplicate:
            bucket.append((record, structure))
    unique = [item for bucket in unique_buckets.values() for item in bucket]
    cohort_buckets: dict[
        tuple[tuple[int, int], ...], list[tuple[str, Structure]]
    ] = {}
    exact_buckets: dict[
        tuple[tuple[int, int], ...], list[tuple[str, Structure]]
    ] = {}
    for parent in parent_rows:
        structure = _structure_from_parent(parent)
        item = (str(parent["material_id"]), structure)
        cohort_buckets.setdefault(_formula_key(structure), []).append(item)
        exact_buckets.setdefault(_exact_composition_key(structure), []).append(item)
    train_novel_count = 0
    cohort_novel: list[tuple[Mapping[str, Any], Structure, dict[str, Any]]] = []
    for record, structure in unique:
        cohort = cohort_buckets.get(_formula_key(structure), [])
        try:
            train_match = any(
                material_id in train_fit_ids and matcher.fit(structure, parent)
                for material_id, parent in cohort
            )
            full_match = any(matcher.fit(structure, parent) for _, parent in cohort)
        except Exception:
            matcher_failure_count += 1
            train_match = True
            full_match = True
        train_novel_count += int(not train_match)
        if full_match:
            continue
        exact_candidates = exact_buckets.get(_exact_composition_key(structure), [])
        if not exact_candidates:
            raise ValueError("cohort has no exact-composition parent for generated condition")
        target_descriptor = _descriptor(structure)
        descriptor_ranked = sorted(
            (
                float(np.linalg.norm(target_descriptor - _descriptor(parent))),
                material_id,
                parent,
            )
            for material_id, parent in exact_candidates
        )
        descriptor_distance, nearest_material_id, _ = descriptor_ranked[0]
        rms_candidates = []
        for material_id, parent in exact_candidates:
            try:
                distance = loose_matcher.get_rms_dist(structure, parent)
            except Exception:
                matcher_failure_count += 1
                distance = None
            if distance is not None:
                rms_candidates.append(
                    (float(distance[0]), float(distance[1]), material_id)
                )
        best_rms = min(rms_candidates) if rms_candidates else None
        score = {
            "nearest_material_id_by_fallback_descriptor": nearest_material_id,
            "strict_structure_match": False,
            "structure_matcher_normalized_rms_min": (
                best_rms[0] if best_rms is not None else None
            ),
            "structure_matcher_max_site_distance_at_min_rms": (
                best_rms[1] if best_rms is not None else None
            ),
            "structure_matcher_rms_nearest_material_id": (
                best_rms[2] if best_rms is not None else None
            ),
            "fallback_descriptor_distance_min": descriptor_distance,
            "fallback_descriptor_definition": (
                "Euclidean distance over normalized lattice lengths, lattice angles, "
                "log volume per atom, and five normalized pair-distance quantiles"
            ),
        }
        cohort_novel.append((record, structure, score))
    exported_count = 0
    if export_directory is not None and zip_path is not None:
        directory = Path(export_directory)
        archive_path = Path(zip_path)
        if directory.exists() or archive_path.exists():
            raise FileExistsError("cohort novelty export refuses to overwrite")
        directory.mkdir(parents=True)
        for record, structure, score in cohort_novel:
            condition_id = str(record["condition"]["condition_id"])
            candidate_id = "c0-cohort-novel-" + hashlib.sha256(
                condition_id.encode("utf-8")
            ).hexdigest()[:16]
            fixed_record = fixed[condition_id]
            cell_record = cell[condition_id]
            metadata = {
                "candidate_id": candidate_id,
                "source_condition_id": condition_id,
                "composition": structure.composition.reduced_formula,
                "target_space_group": int(record["condition"]["space_group"]),
                "detected_space_group": int(record.get("detected_space_group", 0)),
                "wyckoff_sequence": [
                    {
                        "wyckoff_position_id": action["wyckoff_position_id"],
                        "multiplicity": int(action["multiplicity"]),
                        "species": int(action["species"]),
                    }
                    for action in record.get("actions", ())
                ],
                "lattice": np.asarray(structure.lattice.matrix).tolist(),
                "fractional_coordinates": np.asarray(structure.frac_coords).tolist(),
                "atomic_numbers": [int(site.specie.Z) for site in structure],
                "CHGNet_status": {
                    "fixed_cell": fixed_record.get("status"),
                    "cell_relax": cell_record.get("status"),
                },
                "fixed_cell_survival": bool(
                    fixed_record.get("post_relax_survival")
                ),
                "cell_relax_survival": bool(cell_record.get("post_relax_survival")),
                "fixed_cell_CHGNet": _relaxation_metadata(fixed_record),
                "cell_relax_CHGNet": _relaxation_metadata(cell_record),
                "nearest_cohort_match_score": score,
                "novelty_reference": f"full frozen {expected_parent_count}-parent cohort",
                "database_global_novelty_claimed": False,
            }
            (directory / f"{candidate_id}.json").write_text(
                json.dumps(metadata, indent=2, sort_keys=True, allow_nan=False) + "\n",
                encoding="utf-8",
            )
            CifWriter(structure).write_file(directory / f"{candidate_id}.cif")
            exported_count += 1
        _write_deterministic_zip(directory, archive_path)
    return {
        "novelty_scope": "symmetry-valid legal terminal structures only",
        "full_cohort_parent_count": len(parent_rows),
        "legal_terminal_structure_count": len(legal),
        "unique_count": len(unique),
        "novel_vs_train_fit_count": train_novel_count,
        "novel_vs_full_cohort_count": len(cohort_novel),
        "exported_candidate_count": exported_count,
        "candidate_parse_failure_count": parse_failure_count,
        "structure_matcher_failure_count": matcher_failure_count,
        "structure_matcher": matcher_settings,
        "database_global_novelty_claimed": False,
    }
