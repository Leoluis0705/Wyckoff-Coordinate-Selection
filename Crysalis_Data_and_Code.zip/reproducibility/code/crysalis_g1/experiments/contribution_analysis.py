from __future__ import annotations

import hashlib
from typing import Any, Mapping, Sequence

import numpy as np


MATCHED_BASELINES = ("UNIFORM_LEGAL", "FINAL_SET_MEMBERSHIP")
REGISTERED_BOOTSTRAP_RESAMPLES = 10_000
FORMAL_CONDITION_COUNT = 300
FROZEN_SPACE_GROUPS = (225, 139, 12, 63, 189, 194, 123, 164)
REGISTERED_TRAINING_SEEDS = (20260823, 20260824, 20260825)
ALLOWED_FINAL_LABELS = frozenset(
    {
        "CONTRIBUTION_LOCKED_ORBIT_GRAPH",
        "CONTRIBUTION_LOCKED_MULTI_OPERATOR",
        "NOVEL_FORMULATION_WITHOUT_EMPIRICAL_GAIN",
        "CONTRIBUTION_NOT_SUPPORTED",
    }
)


def _binary_array(values: Sequence[bool], *, label: str) -> np.ndarray:
    if len(values) == 0:
        raise ValueError(f"{label} must not be empty")
    if any(not isinstance(value, (bool, np.bool_)) for value in values):
        raise ValueError(f"{label} must contain only binary boolean outcomes")
    return np.asarray(values, dtype=float)


def _formal_condition_ids(
    values: Sequence[str], *, label: str, expected_length: int
) -> tuple[str, ...]:
    condition_ids = tuple(values)
    if len(condition_ids) != expected_length:
        raise ValueError(f"{label} must be aligned with its endpoint outcomes")
    if len(condition_ids) != FORMAL_CONDITION_COUNT:
        raise ValueError("formal contribution analysis requires exactly 300 conditions")
    if any(not isinstance(value, str) or not value for value in condition_ids):
        raise ValueError(f"{label} must contain non-empty string condition IDs")
    if len(set(condition_ids)) != len(condition_ids):
        raise ValueError(f"{label} condition IDs must be unique")
    return condition_ids


def _aligned_binary_arrays(
    graph: Sequence[bool],
    baseline: Sequence[bool],
    *,
    graph_condition_ids: Sequence[str],
    baseline_condition_ids: Sequence[str],
) -> tuple[np.ndarray, np.ndarray, tuple[str, ...]]:
    graph_array = _binary_array(graph, label="graph outcomes")
    baseline_array = _binary_array(baseline, label="baseline outcomes")
    graph_ids = _formal_condition_ids(
        graph_condition_ids,
        label="graph",
        expected_length=int(graph_array.size),
    )
    baseline_ids = _formal_condition_ids(
        baseline_condition_ids,
        label="baseline",
        expected_length=int(baseline_array.size),
    )
    if set(graph_ids) != set(baseline_ids):
        raise ValueError("paired endpoint arrays must be aligned")
    baseline_by_id = dict(zip(baseline_ids, baseline_array, strict=True))
    aligned_baseline = np.asarray(
        [baseline_by_id[condition_id] for condition_id in graph_ids], dtype=float
    )
    return graph_array, aligned_baseline, graph_ids


def _condition_ids_sha256(condition_ids: Sequence[str]) -> str:
    payload = "\n".join(condition_ids).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _require_registered_resamples(resamples: int) -> None:
    if resamples != REGISTERED_BOOTSTRAP_RESAMPLES:
        raise ValueError("contribution lock requires exactly 10,000 resamples")


def paired_condition_bootstrap(
    graph: Sequence[bool],
    baseline: Sequence[bool],
    *,
    graph_condition_ids: Sequence[str],
    baseline_condition_ids: Sequence[str],
    baseline_name: str,
    resamples: int,
    seed: int,
    endpoint: str,
) -> dict[str, Any]:
    if baseline_name not in MATCHED_BASELINES:
        raise ValueError(f"unregistered matched baseline: {baseline_name}")
    graph_array, baseline_array, condition_ids = _aligned_binary_arrays(
        graph,
        baseline,
        graph_condition_ids=graph_condition_ids,
        baseline_condition_ids=baseline_condition_ids,
    )
    _require_registered_resamples(resamples)
    if endpoint == "short_contact_rejection":
        improvement = baseline_array - graph_array
        definition = "baseline rejection minus GRAPH_VIABILITY rejection"
    elif endpoint in {
        "symmetry_valid_legal_terminal",
        "fixed_cell_symmetry_preserving_physical_survival",
    }:
        improvement = graph_array - baseline_array
        definition = "GRAPH_VIABILITY minus baseline"
    else:
        raise ValueError(f"unregistered contribution endpoint: {endpoint}")

    rng = np.random.default_rng(seed)
    indices = rng.integers(
        0,
        improvement.size,
        size=(resamples, improvement.size),
    )
    deltas = improvement[indices].mean(axis=1)
    return {
        "endpoint": endpoint,
        "baseline": baseline_name,
        "condition_count": int(improvement.size),
        "condition_ids_sha256": _condition_ids_sha256(condition_ids),
        "observed_graph_rate": float(graph_array.mean()),
        "observed_baseline_rate": float(baseline_array.mean()),
        "observed_delta": float(improvement.mean()),
        "confidence_interval_95": [
            float(np.quantile(deltas, 0.025)),
            float(np.quantile(deltas, 0.975)),
        ],
        "improvement_definition": definition,
        "resamples": int(resamples),
        "seed": int(seed),
        "resampling_unit": "paired condition",
        "uncertainty_scope": (
            "condition-level uncertainty conditional on one training seed"
        ),
    }


def space_group_macro_comparison(
    *,
    graph: Sequence[bool],
    baseline: Sequence[bool],
    graph_condition_ids: Sequence[str],
    baseline_condition_ids: Sequence[str],
    baseline_name: str,
    space_groups: Sequence[int],
    required_space_groups: Sequence[int],
) -> dict[str, Any]:
    if baseline_name not in MATCHED_BASELINES:
        raise ValueError(f"unregistered matched baseline: {baseline_name}")
    graph_array, baseline_array, condition_ids = _aligned_binary_arrays(
        graph,
        baseline,
        graph_condition_ids=graph_condition_ids,
        baseline_condition_ids=baseline_condition_ids,
    )
    group_array = np.asarray(space_groups, dtype=int)
    if group_array.shape != graph_array.shape:
        raise ValueError("space-group labels must be aligned with paired outcomes")
    required = tuple(int(value) for value in required_space_groups)
    if required != FROZEN_SPACE_GROUPS:
        raise ValueError("required space groups must be exactly the eight frozen groups")
    unexpected = sorted(set(group_array.tolist()) - set(FROZEN_SPACE_GROUPS))
    if unexpected:
        raise ValueError(f"space-group labels outside the frozen set: {unexpected}")
    graph_rates: list[float] = []
    baseline_rates: list[float] = []
    counts: dict[str, int] = {}
    for space_group in required:
        indices = np.flatnonzero(group_array == space_group)
        if indices.size == 0:
            raise ValueError(
                f"required space group has no paired conditions: {space_group}"
            )
        counts[str(space_group)] = int(indices.size)
        graph_rates.append(float(graph_array[indices].mean()))
        baseline_rates.append(float(baseline_array[indices].mean()))
    graph_macro = float(np.mean(graph_rates))
    baseline_macro = float(np.mean(baseline_rates))
    return {
        "baseline": baseline_name,
        "condition_count": int(graph_array.size),
        "condition_ids_sha256": _condition_ids_sha256(condition_ids),
        "space_groups": list(required),
        "condition_count_by_space_group": counts,
        "observed_graph_macro_rate": graph_macro,
        "observed_baseline_macro_rate": baseline_macro,
        "observed_delta": graph_macro - baseline_macro,
        "improvement_definition": "GRAPH_VIABILITY minus baseline",
    }


def _validate_comparison_map(
    values: Mapping[str, Mapping[str, Any]],
    *,
    expected_endpoint: str | None,
) -> str:
    if set(values) != set(MATCHED_BASELINES):
        raise ValueError(
            "comparison map must contain exactly UNIFORM_LEGAL and "
            "FINAL_SET_MEMBERSHIP"
        )
    condition_hashes: set[str] = set()
    for baseline in MATCHED_BASELINES:
        comparison = values[baseline]
        if comparison.get("baseline") != baseline:
            raise ValueError(f"comparison baseline is not bound to {baseline}")
        if int(comparison.get("condition_count", -1)) != FORMAL_CONDITION_COUNT:
            raise ValueError("comparison must preserve the formal 300-condition denominator")
        condition_hash = comparison.get("condition_ids_sha256")
        if not isinstance(condition_hash, str) or len(condition_hash) != 64 or any(
            character not in "0123456789abcdef" for character in condition_hash.lower()
        ):
            raise ValueError("comparison requires a valid condition cohort SHA256")
        condition_hashes.add(condition_hash.lower())
        expected_direction = "GRAPH_VIABILITY minus baseline"
        if expected_endpoint == "short_contact_rejection":
            expected_direction = (
                "baseline rejection minus GRAPH_VIABILITY rejection"
            )
        if comparison.get("improvement_definition") != expected_direction:
            raise ValueError(
                f"comparison has the wrong improvement direction for {baseline}"
            )
        delta = float(comparison["observed_delta"])
        if not np.isfinite(delta):
            raise ValueError(f"non-finite observed delta for {baseline}")
        if not -1.0 <= delta <= 1.0:
            raise ValueError(f"observed delta is outside the valid range for {baseline}")
        if expected_endpoint is not None:
            if comparison.get("endpoint") != expected_endpoint:
                raise ValueError(f"comparison endpoint mismatch for {baseline}")
            if int(comparison.get("resamples", -1)) != REGISTERED_BOOTSTRAP_RESAMPLES:
                raise ValueError("comparison must use exactly 10,000 resamples")
            if comparison.get("resampling_unit") != "paired condition":
                raise ValueError("comparison resampling unit must be paired condition")
            interval = comparison["confidence_interval_95"]
            if len(interval) != 2:
                raise ValueError(f"invalid confidence interval for {baseline}")
            if not all(np.isfinite(float(value)) for value in interval):
                raise ValueError(f"non-finite confidence interval for {baseline}")
            if float(interval[0]) > float(interval[1]):
                raise ValueError(f"confidence interval must be ordered for {baseline}")
            if any(not -1.0 <= float(value) <= 1.0 for value in interval):
                raise ValueError(
                    f"confidence interval is outside the valid range for {baseline}"
                )
        else:
            if tuple(comparison.get("space_groups", ())) != FROZEN_SPACE_GROUPS:
                raise ValueError("macro comparison must use exactly the frozen space groups")
    if len(condition_hashes) != 1:
        raise ValueError("comparison maps must use one condition cohort")
    return next(iter(condition_hashes))


def _strict_dual_ci_positive(
    values: Mapping[str, Mapping[str, Any]],
) -> bool:
    return all(
        float(values[baseline]["observed_delta"]) > 0.0
        and float(values[baseline]["confidence_interval_95"][0]) > 0.0
        for baseline in MATCHED_BASELINES
    )


def evaluate_orbit_graph_signal(
    *,
    endpoint1: Mapping[str, Mapping[str, Any]],
    endpoint2: Mapping[str, Mapping[str, Any]],
    short_contact: Mapping[str, Mapping[str, Any]],
    space_group_macro: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    condition_hashes = {
        _validate_comparison_map(
            endpoint1, expected_endpoint="symmetry_valid_legal_terminal"
        ),
        _validate_comparison_map(
            endpoint2,
            expected_endpoint="fixed_cell_symmetry_preserving_physical_survival",
        ),
        _validate_comparison_map(
            short_contact, expected_endpoint="short_contact_rejection"
        ),
        _validate_comparison_map(space_group_macro, expected_endpoint=None),
    }
    if len(condition_hashes) != 1:
        raise ValueError("all contribution statistics must use one condition cohort")

    endpoint1_pass = _strict_dual_ci_positive(endpoint1)
    endpoint2_pass = _strict_dual_ci_positive(endpoint2)
    short_contact_pass = _strict_dual_ci_positive(short_contact)
    macro_pass = all(
        float(space_group_macro[baseline]["observed_delta"]) > 0.0
        for baseline in MATCHED_BASELINES
    )
    supported = endpoint1_pass and (endpoint2_pass or short_contact_pass) and macro_pass
    secondary_route: str | None = None
    if endpoint2_pass:
        secondary_route = "PRIMARY_ENDPOINT_2"
    elif short_contact_pass:
        secondary_route = "SHORT_CONTACT"
    status = "SUPPORTED" if supported else "NOT_SUPPORTED"
    return {
        "ORBIT_GRAPH_CONTRIBUTION_SIGNAL": status,
        "status": status,
        "endpoint1_dual_strict_ci_pass": endpoint1_pass,
        "endpoint2_dual_strict_ci_pass": endpoint2_pass,
        "short_contact_dual_strict_ci_pass": short_contact_pass,
        "space_group_macro_dual_direction_pass": macro_pass,
        "secondary_route": secondary_route,
        "matched_baselines": list(MATCHED_BASELINES),
        "strict_ci_rule": "95% CI lower bound must be greater than zero",
    }


def hierarchical_training_seed_bootstrap(
    graph_by_seed: Mapping[int, Sequence[bool]],
    uniform_by_seed: Mapping[int, Sequence[bool]],
    *,
    graph_condition_ids_by_seed: Mapping[int, Sequence[str]],
    uniform_condition_ids_by_seed: Mapping[int, Sequence[str]],
    resamples: int,
    seed: int,
) -> dict[str, Any]:
    _require_registered_resamples(resamples)
    registered = set(REGISTERED_TRAINING_SEEDS)
    key_sets = (
        set(graph_by_seed),
        set(uniform_by_seed),
        set(graph_condition_ids_by_seed),
        set(uniform_condition_ids_by_seed),
    )
    if any(keys != registered for keys in key_sets):
        raise ValueError(
            "hierarchical bootstrap requires exactly seeds "
            "20260823, 20260824, and 20260825"
        )
    training_seeds = list(REGISTERED_TRAINING_SEEDS)
    improvements: dict[int, np.ndarray] = {}
    observed_seed_deltas: dict[str, float] = {}
    reference_condition_ids: set[str] | None = None
    for training_seed in training_seeds:
        graph_array, uniform_array, condition_ids = _aligned_binary_arrays(
            graph_by_seed[training_seed],
            uniform_by_seed[training_seed],
            graph_condition_ids=graph_condition_ids_by_seed[training_seed],
            baseline_condition_ids=uniform_condition_ids_by_seed[training_seed],
        )
        if reference_condition_ids is None:
            reference_condition_ids = set(condition_ids)
        elif set(condition_ids) != reference_condition_ids:
            raise ValueError("all training seeds must use the same paired conditions")
        delta = graph_array - uniform_array
        improvements[training_seed] = delta
        observed_seed_deltas[str(training_seed)] = float(delta.mean())

    rng = np.random.default_rng(seed)
    sampled_deltas = np.empty(resamples, dtype=float)
    seed_count = len(training_seeds)
    for sample_index in range(resamples):
        sampled_seed_indices = rng.integers(0, seed_count, size=seed_count)
        within_seed: list[float] = []
        for seed_index in sampled_seed_indices:
            delta = improvements[training_seeds[int(seed_index)]]
            condition_indices = rng.integers(0, delta.size, size=delta.size)
            within_seed.append(float(delta[condition_indices].mean()))
        sampled_deltas[sample_index] = float(np.mean(within_seed))

    observed_mean = float(np.mean(list(observed_seed_deltas.values())))
    all_positive = all(value > 0.0 for value in observed_seed_deltas.values())
    replicated = all_positive and observed_mean > 0.0
    return {
        "training_seeds": training_seeds,
        "condition_count_per_seed": FORMAL_CONDITION_COUNT,
        "condition_ids_sha256": _condition_ids_sha256(
            sorted(reference_condition_ids or set())
        ),
        "seed_level_observed_deltas": observed_seed_deltas,
        "observed_mean_delta": observed_mean,
        "observed_std_delta": float(
            np.std(list(observed_seed_deltas.values()), ddof=1)
        ),
        "all_seed_observed_deltas_positive": all_positive,
        "confidence_interval_95": [
            float(np.quantile(sampled_deltas, 0.025)),
            float(np.quantile(sampled_deltas, 0.975)),
        ],
        "resamples": int(resamples),
        "seed": int(seed),
        "resampling_order": "training seed then paired condition",
        "ORBIT_GRAPH_CONTRIBUTION_REPLICATED": replicated,
    }


def choose_final_contribution_label(
    *,
    first_round_graph_exceeds_both: bool,
    orbit_graph_replicated: bool,
    relation_gain_replicated: bool,
    prior_art_distinct: bool,
) -> str:
    if relation_gain_replicated and not orbit_graph_replicated:
        raise ValueError("relation gain cannot precede orbit-graph replication")
    if orbit_graph_replicated and not first_round_graph_exceeds_both:
        raise ValueError("orbit-graph replication requires first-round matched gains")
    if not prior_art_distinct and (
        first_round_graph_exceeds_both
        or orbit_graph_replicated
        or relation_gain_replicated
    ):
        raise ValueError(
            "empirical contribution signal without a prior-art-distinct formulation "
            "has no preregistered final label"
        )

    if prior_art_distinct and relation_gain_replicated:
        decision = "CONTRIBUTION_LOCKED_MULTI_OPERATOR"
    elif prior_art_distinct and orbit_graph_replicated:
        decision = "CONTRIBUTION_LOCKED_ORBIT_GRAPH"
    elif prior_art_distinct and first_round_graph_exceeds_both:
        decision = "NOVEL_FORMULATION_WITHOUT_EMPIRICAL_GAIN"
    else:
        decision = "CONTRIBUTION_NOT_SUPPORTED"
    if decision not in ALLOWED_FINAL_LABELS:
        raise AssertionError("unregistered contribution decision")
    return decision
