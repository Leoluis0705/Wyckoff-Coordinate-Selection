from __future__ import annotations

import hashlib
import json
import math
import warnings
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from statistics import mean
from typing import Any, Iterable

import numpy as np
import spglib
from pymatgen.analysis.structure_matcher import StructureMatcher
from pymatgen.core import Lattice, Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
from pyxtal.symmetry import Group

from crysalis_g1.symmetry.wyckoff import (
    PRIMARY_SYMPREC,
    ConstrainedLattice,
    OrbitState,
    SpaceGroupConditionedWyckoffExpander,
    SpaceGroupConstrainedLatticeHead,
    SpaceGroupSetting,
    WyckoffExpansionError,
)


TOP8_SPACE_GROUPS = (225, 139, 12, 63, 189, 194, 123, 164)


class ParentRecoveryError(ValueError):
    def __init__(self, reason_code: str, detail: str):
        self.reason_code = reason_code
        self.detail = detail
        super().__init__(f"{reason_code}: {detail}")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            try:
                yield json.loads(line)
            except json.JSONDecodeError as error:
                raise ValueError(f"invalid JSONL at {path}:{line_number}") from error


def _periodic_set_match(
    left: np.ndarray, right: np.ndarray, *, tolerance: float
) -> bool:
    if left.shape != right.shape or left.ndim != 2 or left.shape[1] != 3:
        return False
    unmatched = list(range(len(right)))
    for coordinate in left:
        selected = None
        for candidate in unmatched:
            delta = coordinate - right[candidate]
            delta -= np.round(delta)
            if np.max(np.abs(delta)) <= tolerance:
                selected = candidate
                break
        if selected is None:
            return False
        unmatched.remove(selected)
    return not unmatched


def _canonical_conventional(coordinates: np.ndarray) -> np.ndarray:
    result: list[np.ndarray] = []
    for coordinate in np.mod(np.asarray(coordinates, dtype=float), 1.0):
        if not any(
            np.max(np.abs((coordinate - existing) - np.round(coordinate - existing)))
            <= 1e-8
            for existing in result
        ):
            result.append(coordinate)
    return np.asarray(result)


def _recover_free_parameters(
    target_space_group: int,
    wyckoff_letter: str,
    conventional_coordinates: np.ndarray,
) -> tuple[float, ...]:
    position = Group(target_space_group).get_wyckoff_position(wyckoff_letter)
    target = _canonical_conventional(conventional_coordinates)
    if len(target) != int(position.multiplicity):
        raise ParentRecoveryError(
            "CONVENTIONAL_MULTIPLICITY_MISMATCH",
            f"SG {target_space_group} {position.get_label()} expected "
            f"{position.multiplicity}, observed {len(target)}",
        )
    for coordinate in target:
        generator = position.search_generator(
            coordinate, tol=0.05, symmetrize=True
        )
        if generator is None:
            continue
        free = tuple(
            float(value) for value in position.get_free_xyzs(generator)
        )
        rebuilt_generator = position.get_position_from_free_xyzs(list(free))
        rebuilt = _canonical_conventional(position.apply_ops(rebuilt_generator))
        if _periodic_set_match(target, rebuilt, tolerance=5e-5):
            return free
    raise ParentRecoveryError(
        "FREE_PARAMETER_RECOVERY_FAILED",
        f"no generator recovered for SG {target_space_group} {position.get_label()}",
    )


@dataclass(frozen=True, slots=True)
class RecoveredParent:
    material_id: str
    target_space_group: int
    recovery_symprec: float
    cell_index: int
    cell_transform_values: tuple[tuple[int, int, int], ...]
    setting: SpaceGroupSetting
    lattice: ConstrainedLattice
    orbits: tuple[OrbitState, ...]
    reconstructed_atomic_numbers: tuple[int, ...]
    reconstructed_fractional_coordinates: tuple[tuple[float, float, float], ...]
    detected_space_groups: dict[float, int]
    composition_roundtrip: bool
    multiplicity_roundtrip: bool
    orbit_membership_roundtrip: bool
    space_group_roundtrip: bool
    structure_match: bool
    coordinate_residual_angstrom: float

    @property
    def passed(self) -> bool:
        return bool(
            self.composition_roundtrip
            and self.multiplicity_roundtrip
            and self.orbit_membership_roundtrip
            and self.space_group_roundtrip
            and self.structure_match
        )

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["detected_space_groups"] = {
            f"{symprec:.2f}": value
            for symprec, value in self.detected_space_groups.items()
        }
        payload["passed"] = self.passed
        return payload

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> RecoveredParent:
        lattice_payload = payload["lattice"]
        return cls(
            material_id=str(payload["material_id"]),
            target_space_group=int(payload["target_space_group"]),
            recovery_symprec=float(payload["recovery_symprec"]),
            cell_index=int(payload["cell_index"]),
            cell_transform_values=tuple(
                tuple(int(value) for value in row)
                for row in payload["cell_transform_values"]
            ),
            setting=SpaceGroupSetting.for_number(
                int(payload["target_space_group"])
            ),
            lattice=ConstrainedLattice(
                target_space_group=int(lattice_payload["target_space_group"]),
                crystal_system=str(lattice_payload["crystal_system"]),
                conventional_parameters=tuple(
                    float(value)
                    for value in lattice_payload["conventional_parameters"]
                ),
                conventional_matrix=tuple(
                    tuple(float(value) for value in row)
                    for row in lattice_payload["conventional_matrix"]
                ),
                base_primitive_matrix=tuple(
                    tuple(float(value) for value in row)
                    for row in lattice_payload["base_primitive_matrix"]
                ),
                primitive_matrix=tuple(
                    tuple(float(value) for value in row)
                    for row in lattice_payload["primitive_matrix"]
                ),
                cell_transform_values=tuple(
                    tuple(int(value) for value in row)
                    for row in lattice_payload["cell_transform_values"]
                ),
            ),
            orbits=tuple(
                OrbitState.from_dict(item) for item in payload["orbits"]
            ),
            reconstructed_atomic_numbers=tuple(
                int(value) for value in payload["reconstructed_atomic_numbers"]
            ),
            reconstructed_fractional_coordinates=tuple(
                tuple(float(value) for value in row)
                for row in payload["reconstructed_fractional_coordinates"]
            ),
            detected_space_groups={
                float(symprec): int(value)
                for symprec, value in payload["detected_space_groups"].items()
            },
            composition_roundtrip=bool(payload["composition_roundtrip"]),
            multiplicity_roundtrip=bool(payload["multiplicity_roundtrip"]),
            orbit_membership_roundtrip=bool(
                payload["orbit_membership_roundtrip"]
            ),
            space_group_roundtrip=bool(payload["space_group_roundtrip"]),
            structure_match=bool(payload["structure_match"]),
            coordinate_residual_angstrom=float(
                payload["coordinate_residual_angstrom"]
            ),
        )


def _recovery_symprec(payload: dict[str, Any], target_space_group: int) -> float:
    matching = sorted(
        float(observation["symprec"])
        for observation in payload.get("observations", ())
        if int(observation["space_group"]) == target_space_group
    )
    return matching[0] if matching else PRIMARY_SYMPREC


def structure_match_reconstruction(
    source: Structure,
    reconstructed: Structure,
    *,
    target_space_group: int,
    source_symprec: float,
) -> tuple[bool, float]:
    source_analyzer = SpacegroupAnalyzer(
        source, symprec=source_symprec, angle_tolerance=5.0
    )
    reconstructed_analyzer = SpacegroupAnalyzer(
        reconstructed, symprec=PRIMARY_SYMPREC, angle_tolerance=5.0
    )
    if (
        source_analyzer.get_space_group_number() != target_space_group
        or reconstructed_analyzer.get_space_group_number() != target_space_group
    ):
        return False, math.inf
    source_primitive = source_analyzer.get_primitive_standard_structure()
    reconstructed_primitive = (
        reconstructed_analyzer.get_primitive_standard_structure()
    )
    matcher = StructureMatcher(
        ltol=0.2,
        stol=0.3,
        angle_tol=5.0,
        primitive_cell=False,
        scale=True,
        attempt_supercell=False,
    )
    matched = bool(matcher.fit(source_primitive, reconstructed_primitive))
    if not matched:
        return False, math.inf
    rms = matcher.get_rms_dist(source_primitive, reconstructed_primitive)
    if rms is None:
        return True, math.inf
    free_length = (
        reconstructed_primitive.volume / max(len(reconstructed_primitive), 1)
    ) ** (1.0 / 3.0)
    return True, float(rms[0]) * free_length


def recover_parent_orbit_states(payload: dict[str, Any]) -> RecoveredParent:
    material_id = str(payload["material_id"])
    target_space_group = int(payload["space_group"])
    lattice = np.asarray(payload["lattice"], dtype=float)
    coordinates = np.asarray(payload["fractional_coordinates"], dtype=float)
    atomic_numbers = np.asarray(payload["atomic_numbers"], dtype=int)
    orbit_payloads = tuple(payload["orbits"])
    if lattice.shape != (3, 3) or coordinates.shape != (len(atomic_numbers), 3):
        raise ParentRecoveryError("INVALID_PARENT_SHAPE", material_id)
    orbit_labels = np.zeros(len(atomic_numbers), dtype=int)
    for orbit_index, orbit in enumerate(orbit_payloads, 1):
        indices = np.asarray(orbit["canonical_site_indices"], dtype=int)
        if np.any(indices < 0) or np.any(indices >= len(atomic_numbers)):
            raise ParentRecoveryError("ORBIT_SITE_INDEX_INVALID", material_id)
        if np.any(orbit_labels[indices] != 0):
            raise ParentRecoveryError("ORBIT_MEMBERSHIP_OVERLAP", material_id)
        orbit_labels[indices] = orbit_index
    if np.any(orbit_labels == 0):
        raise ParentRecoveryError("ORBIT_MEMBERSHIP_INCOMPLETE", material_id)
    recovery_symprec = _recovery_symprec(payload, target_space_group)
    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore", message="Set OLD_ERROR_HANDLING to false.*"
        )
        parent_dataset = spglib.get_symmetry_dataset(
            (lattice, coordinates, atomic_numbers),
            symprec=recovery_symprec,
            angle_tolerance=5.0,
        )
    if parent_dataset is None:
        raise ParentRecoveryError(
            "CONVENTIONAL_STANDARDIZATION_FAILED", material_id
        )
    if int(parent_dataset.number) != target_space_group:
        detected = int(parent_dataset.number)
        raise ParentRecoveryError(
            "CANONICAL_TARGET_STANDARDIZATION_FAILED",
            f"{material_id}: target {target_space_group}, detected {detected} "
            f"at recovery symprec={recovery_symprec}",
        )
    conventional_lattice = np.asarray(parent_dataset.std_lattice, dtype=float)
    conventional_coordinates = np.asarray(
        parent_dataset.std_positions, dtype=float
    )
    mapping_to_primitive = np.asarray(
        parent_dataset.mapping_to_primitive, dtype=int
    )
    standard_mapping_to_primitive = np.asarray(
        parent_dataset.std_mapping_to_primitive, dtype=int
    )
    conventional_geometry = Lattice(conventional_lattice)
    base_orbits = []
    cell_indices = []
    for orbit in orbit_payloads:
        source_indices = np.asarray(orbit["canonical_site_indices"], dtype=int)
        primitive_ids = set(int(value) for value in mapping_to_primitive[source_indices])
        member_indices = np.asarray(
            [
                index
                for index, primitive_id in enumerate(
                    standard_mapping_to_primitive
                )
                if int(primitive_id) in primitive_ids
            ],
            dtype=int,
        )
        member_coordinates = conventional_coordinates[member_indices]
        standard_letters = {
            str(parent_dataset.wyckoffs[index]) for index in source_indices
        }
        if len(standard_letters) != 1:
            raise ParentRecoveryError(
                "STANDARD_WYCKOFF_RELABEL_AMBIGUOUS",
                f"{material_id} orbit {orbit['orbit_id']} maps to {sorted(standard_letters)}",
            )
        standard_letter = next(iter(standard_letters))
        free_parameters = _recover_free_parameters(
            target_space_group,
            standard_letter,
            member_coordinates,
        )
        base_orbit = OrbitState.create(
            target_space_group,
            standard_letter,
            int(orbit["atomic_number"]),
            free_parameters,
            orbit_instance_id=str(orbit["orbit_id"]),
        )
        cached_multiplicity = int(orbit["multiplicity"])
        if cached_multiplicity % base_orbit.multiplicity != 0:
            raise ParentRecoveryError(
                "NONINTEGER_CELL_INDEX",
                f"{material_id} orbit {orbit['orbit_id']}: cached multiplicity "
                f"{cached_multiplicity}, base multiplicity {base_orbit.multiplicity}",
            )
        cell_indices.append(cached_multiplicity // base_orbit.multiplicity)
        base_orbits.append((orbit, standard_letter, free_parameters))
    if not cell_indices or len(set(cell_indices)) != 1 or cell_indices[0] <= 0:
        raise ParentRecoveryError(
            "INCONSISTENT_CELL_INDEX",
            f"{material_id}: per-orbit indices={cell_indices}",
        )
    cell_index = cell_indices[0]
    cell_transform = ((cell_index, 0, 0), (0, 1, 0), (0, 0, 1))
    constrained = SpaceGroupConstrainedLatticeHead().constrain(
        target_space_group,
        (
            conventional_geometry.a,
            conventional_geometry.b,
            conventional_geometry.c,
            conventional_geometry.alpha,
            conventional_geometry.beta,
            conventional_geometry.gamma,
        ),
        cell_transform=cell_transform,
    )
    recovered_orbits = tuple(
        OrbitState.create(
            target_space_group,
            standard_letter,
            int(orbit["atomic_number"]),
            free_parameters,
            cell_transform=cell_transform,
            orbit_instance_id=str(orbit["orbit_id"]),
        )
        for orbit, standard_letter, free_parameters in base_orbits
    )
    try:
        expanded = SpaceGroupConditionedWyckoffExpander().expand_many(
            recovered_orbits,
            constrained.primitive_matrix,
            require_target_space_group=False,
        )
    except WyckoffExpansionError as error:
        raise ParentRecoveryError(error.reason_code, error.detail) from error
    original_composition = Counter(int(value) for value in atomic_numbers)
    reconstructed_composition = Counter(expanded.atomic_numbers)
    expected_multiplicity = {
        str(orbit["orbit_id"]): int(orbit["multiplicity"])
        for orbit in orbit_payloads
    }
    observed_multiplicity = {
        orbit.orbit_instance_id: orbit.multiplicity for orbit in recovered_orbits
    }
    original = Structure(
        Lattice(lattice), atomic_numbers, coordinates, to_unit_cell=True
    )
    reconstructed = Structure(
        Lattice(constrained.primitive_matrix),
        expanded.atomic_numbers,
        expanded.fractional_coordinates,
        to_unit_cell=True,
    )
    structure_match, residual = structure_match_reconstruction(
        original,
        reconstructed,
        target_space_group=target_space_group,
        source_symprec=recovery_symprec,
    )
    return RecoveredParent(
        material_id=material_id,
        target_space_group=target_space_group,
        recovery_symprec=recovery_symprec,
        cell_index=cell_index,
        cell_transform_values=cell_transform,
        setting=SpaceGroupSetting.for_number(target_space_group),
        lattice=constrained,
        orbits=tuple(recovered_orbits),
        reconstructed_atomic_numbers=expanded.atomic_numbers,
        reconstructed_fractional_coordinates=expanded.fractional_coordinates,
        detected_space_groups=expanded.detected_space_groups,
        composition_roundtrip=original_composition == reconstructed_composition,
        multiplicity_roundtrip=expected_multiplicity == observed_multiplicity,
        orbit_membership_roundtrip=expanded.orbit_membership_valid,
        space_group_roundtrip=(
            expanded.detected_space_groups[PRIMARY_SYMPREC]
            == target_space_group
        ),
        structure_match=structure_match,
        coordinate_residual_angstrom=residual,
    )


def _synthetic_raw_lattice(space_group: int) -> tuple[float, ...]:
    if space_group == 12:
        return (5.1, 6.2, 7.3, 74.0, 103.0, 112.0)
    return (5.1, 6.2, 7.3, 82.0, 101.0, 113.0)


def run_synthetic_wyckoff_tests() -> dict[str, Any]:
    records = []
    expander = SpaceGroupConditionedWyckoffExpander()
    head = SpaceGroupConstrainedLatticeHead()
    for target_space_group in sorted(TOP8_SPACE_GROUPS):
        group = Group(target_space_group)
        general = group.Wyckoff_positions[0]
        specials = [
            position
            for position in reversed(group.Wyckoff_positions)
            if int(position.get_dof()) < 3
        ][:2]
        positions = (general, *specials)
        if len(positions) != 3:
            raise RuntimeError(
                f"SG {target_space_group} lacks two synthetic special positions"
            )
        orbits = []
        multiplicity_checks = []
        serialize_checks = []
        wrap_checks = []
        for position_index, position in enumerate(positions):
            dof = int(position.get_dof())
            parameters = tuple(
                (0.173, 0.287, 0.391)[index] + position_index * 0.037
                for index in range(dof)
            )
            orbit = OrbitState.create(
                target_space_group,
                str(position.letter),
                (6, 8, 14)[position_index],
                parameters,
                orbit_instance_id=(
                    f"synthetic-{target_space_group}-{position.get_label()}"
                ),
            )
            expected_primitive = round(
                int(position.multiplicity)
                * abs(
                    np.linalg.det(
                        SpaceGroupSetting.for_number(
                            target_space_group
                        ).primitive_transform
                    )
                )
            )
            multiplicity_checks.append(orbit.multiplicity == expected_primitive)
            serialize_checks.append(OrbitState.from_dict(orbit.to_dict()) == orbit)
            wrapped = OrbitState.create(
                target_space_group,
                str(position.letter),
                (6, 8, 14)[position_index],
                tuple(value + 1.0 for value in parameters),
                orbit_instance_id=orbit.orbit_instance_id,
            )
            wrap_checks.append(wrapped.free_parameters == orbit.free_parameters)
            orbits.append(orbit)
        constrained = head.constrain(
            target_space_group, _synthetic_raw_lattice(target_space_group)
        )
        try:
            expanded = expander.expand_many(
                orbits, constrained.primitive_matrix
            )
            space_group_roundtrip = (
                expanded.detected_space_groups[PRIMARY_SYMPREC]
                == target_space_group
            )
            failure = None
        except WyckoffExpansionError as error:
            expanded = None
            space_group_roundtrip = False
            failure = {
                "reason_code": error.reason_code,
                "detail": error.detail,
            }
        record = {
            "target_space_group": target_space_group,
            "hall_number": SpaceGroupSetting.for_number(
                target_space_group
            ).hall_number,
            "wyckoff_positions": [
                {
                    "id": str(position.get_label()),
                    "letter": str(position.letter),
                    "dof": int(position.get_dof()),
                    "kind": "general" if int(position.get_dof()) == 3 else "special",
                }
                for position in positions
            ],
            "general_position_count": sum(
                int(position.get_dof()) == 3 for position in positions
            ),
            "special_position_count": sum(
                int(position.get_dof()) < 3 for position in positions
            ),
            "multiplicity_passed": all(multiplicity_checks),
            "serialize_reload_passed": all(serialize_checks),
            "periodic_wrap_passed": all(wrap_checks),
            "space_group_roundtrip_passed": space_group_roundtrip,
            "detected_space_groups": (
                None
                if expanded is None
                else {
                    f"{value:.2f}": detected
                    for value, detected in expanded.detected_space_groups.items()
                }
            ),
            "nonorthogonal_or_skew_lattice_covered": bool(
                target_space_group in {12, 164, 189, 194}
                or SpaceGroupSetting.for_number(target_space_group).centering
                != "P"
            ),
            "failure": failure,
        }
        record["passed"] = bool(
            record["general_position_count"] >= 1
            and record["special_position_count"] >= 2
            and record["multiplicity_passed"]
            and record["serialize_reload_passed"]
            and record["periodic_wrap_passed"]
            and record["space_group_roundtrip_passed"]
        )
        records.append(record)
    nonorthogonal_covered = any(
        record["nonorthogonal_or_skew_lattice_covered"] for record in records
    )
    return {
        "schema_version": "g1-c0-symmetry-wyckoff-tests.1.0.0",
        "space_groups": sorted(TOP8_SPACE_GROUPS),
        "space_group_count": len(records),
        "nonorthogonal_or_skew_lattice_covered": nonorthogonal_covered,
        "records": records,
        "passed": nonorthogonal_covered
        and all(record["passed"] for record in records),
    }


def _rate(count: int, total: int) -> float:
    return count / total if total else 0.0


def run_reconstruction_gate(
    phase2a_root: str | Path,
    *,
    expected_manifest_sha256: str,
) -> tuple[dict[str, Any], dict[str, RecoveredParent]]:
    root = Path(phase2a_root)
    manifest_path = root / "phase2a_manifest.json"
    observed_manifest_sha256 = _sha256(manifest_path)
    if observed_manifest_sha256 != expected_manifest_sha256:
        raise RuntimeError(
            "Phase 2A manifest hash mismatch: "
            f"expected {expected_manifest_sha256}, observed {observed_manifest_sha256}"
        )
    selected_ids = {
        str(row["parent_structure_id"])
        for row in _read_jsonl(root / "trajectories" / "d_orbit.jsonl")
    }
    parent_payloads = {
        str(row["material_id"]): row
        for row in _read_jsonl(
            root / "canonical_cache" / "canonical_parents.jsonl"
        )
        if str(row["material_id"]) in selected_ids
    }
    if set(parent_payloads) != selected_ids:
        raise RuntimeError("selected Phase 2A parents are incomplete")
    recovered: dict[str, RecoveredParent] = {}
    failures = []
    failure_taxonomy: Counter[str] = Counter()
    failure_by_space_group: dict[int, Counter[str]] = defaultdict(Counter)
    failure_by_wyckoff: Counter[str] = Counter()
    for material_id in sorted(parent_payloads):
        payload = parent_payloads[material_id]
        try:
            result = recover_parent_orbit_states(payload)
            recovered[material_id] = result
            if not result.passed:
                reason = "ROUNDTRIP_METRIC_FAILURE"
                failure_taxonomy[reason] += 1
                failure_by_space_group[result.target_space_group][reason] += 1
                failures.append(
                    {
                        "material_id": material_id,
                        "target_space_group": result.target_space_group,
                        "reason_code": reason,
                        "composition_roundtrip": result.composition_roundtrip,
                        "multiplicity_roundtrip": result.multiplicity_roundtrip,
                        "orbit_membership_roundtrip": result.orbit_membership_roundtrip,
                        "space_group_roundtrip": result.space_group_roundtrip,
                        "structure_match": result.structure_match,
                        "detected_space_groups": {
                            f"{value:.2f}": detected
                            for value, detected in result.detected_space_groups.items()
                        },
                    }
                )
        except (ParentRecoveryError, ValueError) as error:
            reason = getattr(error, "reason_code", type(error).__name__)
            target_space_group = int(payload["space_group"])
            failure_taxonomy[reason] += 1
            failure_by_space_group[target_space_group][reason] += 1
            for orbit in payload["orbits"]:
                failure_by_wyckoff[
                    f"{target_space_group}:{orbit['wyckoff_letter']}"
                ] += 1
            failures.append(
                {
                    "material_id": material_id,
                    "target_space_group": target_space_group,
                    "reason_code": reason,
                    "detail": str(error),
                    "wyckoff_letters": [
                        str(orbit["wyckoff_letter"])
                        for orbit in payload["orbits"]
                    ],
                }
            )
    total = len(parent_payloads)
    success_results = list(recovered.values())
    metric_counts = {
        "space_group_roundtrip": sum(
            result.space_group_roundtrip for result in success_results
        ),
        "orbit_membership_roundtrip": sum(
            result.orbit_membership_roundtrip for result in success_results
        ),
        "multiplicity_roundtrip": sum(
            result.multiplicity_roundtrip for result in success_results
        ),
        "composition_roundtrip": sum(
            result.composition_roundtrip for result in success_results
        ),
        "structure_match": sum(result.structure_match for result in success_results),
    }
    top8 = {}
    for target_space_group in TOP8_SPACE_GROUPS:
        ids = [
            material_id
            for material_id, payload in parent_payloads.items()
            if int(payload["space_group"]) == target_space_group
        ]
        results = [recovered[value] for value in ids if value in recovered]
        top8[str(target_space_group)] = {
            "parent_count": len(ids),
            "recovered_count": len(results),
            "space_group_roundtrip_rate": _rate(
                sum(value.space_group_roundtrip for value in results), len(ids)
            ),
            "orbit_membership_roundtrip_rate": _rate(
                sum(value.orbit_membership_roundtrip for value in results), len(ids)
            ),
            "multiplicity_roundtrip_rate": _rate(
                sum(value.multiplicity_roundtrip for value in results), len(ids)
            ),
            "composition_roundtrip_rate": _rate(
                sum(value.composition_roundtrip for value in results), len(ids)
            ),
            "structure_match_rate": _rate(
                sum(value.structure_match for value in results), len(ids)
            ),
        }
    finite_residuals = [
        value.coordinate_residual_angstrom
        for value in success_results
        if math.isfinite(value.coordinate_residual_angstrom)
    ]
    report = {
        "schema_version": "g1-c0-symmetry-reconstruction.1.0.0",
        "phase2a_manifest_sha256": observed_manifest_sha256,
        "parent_count": total,
        "recovered_parent_count": len(recovered),
        "space_group_roundtrip_rate": _rate(
            metric_counts["space_group_roundtrip"], total
        ),
        "orbit_membership_roundtrip_rate": _rate(
            metric_counts["orbit_membership_roundtrip"], total
        ),
        "multiplicity_roundtrip_rate": _rate(
            metric_counts["multiplicity_roundtrip"], total
        ),
        "composition_roundtrip_rate": _rate(
            metric_counts["composition_roundtrip"], total
        ),
        "structure_matcher_reconstruction_rate": _rate(
            metric_counts["structure_match"], total
        ),
        "coordinate_residual_angstrom": {
            "mean": mean(finite_residuals) if finite_residuals else None,
            "maximum": max(finite_residuals) if finite_residuals else None,
            "count": len(finite_residuals),
        },
        "top8": top8,
        "failure_taxonomy": dict(sorted(failure_taxonomy.items())),
        "failure_taxonomy_by_space_group": {
            str(space_group): dict(sorted(counts.items()))
            for space_group, counts in sorted(failure_by_space_group.items())
        },
        "failure_taxonomy_by_wyckoff": dict(
            sorted(failure_by_wyckoff.items())
        ),
        "known_setting_or_tolerance_ambiguities": [
            failure
            for failure in failures
            if failure["reason_code"]
            in {
                "TARGET_SPACE_GROUP_MISMATCH",
                "ROUNDTRIP_METRIC_FAILURE",
            }
        ],
        "failures": failures,
    }
    report["passed"] = bool(
        report["composition_roundtrip_rate"] == 1.0
        and report["multiplicity_roundtrip_rate"] == 1.0
        and report["space_group_roundtrip_rate"] == 1.0
        and report["orbit_membership_roundtrip_rate"] == 1.0
        and report["structure_matcher_reconstruction_rate"] == 1.0
    )
    return report, recovered
