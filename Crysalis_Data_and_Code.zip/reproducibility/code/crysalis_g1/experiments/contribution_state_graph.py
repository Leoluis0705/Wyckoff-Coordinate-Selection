from __future__ import annotations

import hashlib
import math
from collections import Counter
from collections.abc import Iterable, Mapping
from dataclasses import asdict, dataclass, replace

from crysalis_assembly.serialization import canonical_payload_json
from crysalis_g1.data.canonical import CanonicalParentRecord
from crysalis_g1.data.structural_operators import (
    OPERATOR_SCHEMA_VERSION,
    DeconstructionState,
    OperatorReplayError,
    RelationRegistry,
    StructuralAction,
    StructuralTrajectory,
    apply_structural_action,
    initial_deconstruction_state,
    replay_trajectory,
)
from crysalis_g1.experiments.c0_symmetry_reconstruction import RecoveredParent
from crysalis_g1.symmetry.assembly import (
    AddOrbitAction,
    C0SymmetryProjector,
    LegalAddOrbit,
    SpaceGroupLegalActionCompiler,
    SymmetryAssemblyState,
)
from crysalis_g1.symmetry.wyckoff import ConstrainedLattice, OrbitState

STATE_CONTRACT_SCHEMA_VERSION = "g1-contribution-state-contract.1.0.0"


@dataclass(frozen=True, slots=True, order=True)
class ActionDescription:
    """C0 compiler action fields permitted in the contribution label schema."""

    operator: str
    wyckoff_letter: str
    atomic_number: int
    multiplicity: int
    free_parameter_count: int

    def __post_init__(self) -> None:
        if self.operator != "D_orbit":
            raise ValueError("contribution labels support only D_orbit")
        if not self.wyckoff_letter:
            raise ValueError("wyckoff_letter must be non-empty")
        if (
            not 1 <= self.atomic_number <= 118
            or self.multiplicity <= 0
            or self.free_parameter_count < 0
        ):
            raise ValueError("invalid C0 legal-action description")


@dataclass(frozen=True, slots=True)
class FrozenLatticeContract:
    target_space_group: int
    conventional_parameters: tuple[float, ...]
    primitive_matrix: tuple[tuple[float, float, float], ...]
    cell_transform_values: tuple[tuple[int, int, int], ...]


@dataclass(frozen=True, slots=True)
class PresentOrbitContract:
    orbit_instance_id: str
    wyckoff_letter: str
    atomic_number: int
    multiplicity: int


@dataclass(frozen=True, slots=True)
class C0AssemblyStateContract:
    target_space_group: int
    full_composition: tuple[tuple[int, int], ...]
    remaining_composition: tuple[tuple[int, int], ...]
    present_orbits: tuple[PresentOrbitContract, ...]
    frozen_lattice: FrozenLatticeContract
    state_hash: str


@dataclass(frozen=True, slots=True)
class StateGraphNode:
    state: DeconstructionState
    state_hash: str
    c0_state: C0AssemblyStateContract
    compiler_state: SymmetryAssemblyState
    legal_action_set: tuple[ActionDescription, ...]
    compiler_state_verified: bool
    projector_verified: bool | None
    termination_verified: bool
    depth: int
    number_of_future_completion_paths: int
    minimum_remaining_steps: int


@dataclass(frozen=True, slots=True)
class AssemblyEdge:
    source_state_hash: str
    destination_state_hash: str
    source_c0_state_hash: str
    destination_c0_state_hash: str
    compiler_successor_state_hash: str
    target_orbit_id: str
    action_description: ActionDescription
    restore_state_hash: str
    remove_state_hash: str
    offline_c0_verified: bool


@dataclass(frozen=True, slots=True)
class ParentStateGraph:
    record: CanonicalParentRecord
    registry: RelationRegistry
    recovered_parent: RecoveredParent
    max_sites: int
    minimum_distance: float
    d_orbit_trajectory_sequence_hashes: tuple[str, ...]
    nodes: tuple[StateGraphNode, ...]
    assembly_edges: tuple[AssemblyEdge, ...]


@dataclass(frozen=True, slots=True)
class GroupedOfflineLabelRecord:
    """Offline labels; identifiers and C0 state are not model features."""

    parent_structure_id: str
    split: str
    state_hash: str
    depth: int
    viable_action_set: tuple[ActionDescription, ...]
    nonviable_legal_action_set: tuple[ActionDescription, ...]
    positive_successor_orbit_ids: Mapping[ActionDescription, tuple[str, ...]]
    successor_path_counts: Mapping[ActionDescription, Mapping[str, int]]
    future_path_count_by_action: Mapping[ActionDescription, int]
    log1p_future_path_count_by_action: Mapping[ActionDescription, float]
    number_of_future_completion_paths: int
    minimum_remaining_steps: int
    operator_provenance: Mapping[str, object]


@dataclass(frozen=True, slots=True)
class StateGraphCorpus:
    graphs: tuple[ParentStateGraph, ...]
    labels: tuple[GroupedOfflineLabelRecord, ...]


def _frozen_lattice_contract(lattice: ConstrainedLattice) -> FrozenLatticeContract:
    return FrozenLatticeContract(
        target_space_group=lattice.target_space_group,
        conventional_parameters=tuple(
            float(value) for value in lattice.conventional_parameters
        ),
        primitive_matrix=tuple(
            tuple(float(value) for value in row) for row in lattice.primitive_matrix
        ),
        cell_transform_values=tuple(
            tuple(int(value) for value in row) for row in lattice.cell_transform_values
        ),
    )


def _full_composition(parent: RecoveredParent) -> tuple[tuple[int, int], ...]:
    composition = Counter()
    for orbit in parent.orbits:
        composition[orbit.species] += orbit.multiplicity
    return tuple(sorted(composition.items()))


def _action_description(legal: LegalAddOrbit) -> ActionDescription:
    return ActionDescription(
        operator="D_orbit",
        wyckoff_letter=legal.wyckoff_letter,
        atomic_number=legal.species,
        multiplicity=legal.multiplicity,
        free_parameter_count=legal.free_parameter_count,
    )


def _state_contract(
    state: SymmetryAssemblyState,
    *,
    full_composition: tuple[tuple[int, int], ...],
) -> C0AssemblyStateContract:
    present_orbits = tuple(
        sorted(
            (
                PresentOrbitContract(
                    orbit_instance_id=orbit.orbit_instance_id,
                    wyckoff_letter=orbit.wyckoff_letter,
                    atomic_number=orbit.species,
                    multiplicity=orbit.multiplicity,
                )
                for orbit in state.orbits
            ),
            key=lambda orbit: orbit.orbit_instance_id,
        )
    )
    lattice = _frozen_lattice_contract(state.lattice)
    payload = {
        "schema_version": STATE_CONTRACT_SCHEMA_VERSION,
        "target_space_group": state.target_space_group,
        "full_composition": full_composition,
        "remaining_composition": state.remaining_composition,
        "present_orbits": tuple(asdict(orbit) for orbit in present_orbits),
        "frozen_lattice": asdict(lattice),
    }
    return C0AssemblyStateContract(
        target_space_group=state.target_space_group,
        full_composition=full_composition,
        remaining_composition=state.remaining_composition,
        present_orbits=present_orbits,
        frozen_lattice=lattice,
        state_hash=hashlib.sha256(
            canonical_payload_json(payload).encode("utf-8")
        ).hexdigest(),
    )


def _state_for_active_orbits(
    record: CanonicalParentRecord,
    registry: RelationRegistry,
    active_orbit_ids: tuple[str, ...],
) -> DeconstructionState:
    state = initial_deconstruction_state(record, registry)
    active = set(active_orbit_ids)
    for orbit_id in sorted(
        orbit.orbit_id for orbit in record.orbits if orbit.orbit_id not in active
    ):
        state = apply_structural_action(
            state,
            StructuralAction("D_orbit", "REMOVE", orbit_id),
            record,
            registry,
        )
    if state.active_orbit_ids != active_orbit_ids:
        raise RuntimeError("D_ORBIT_STATE_CONSTRUCTION_MISMATCH")
    return state


def _validate_recovered_parent(
    record: CanonicalParentRecord, recovered_parent: RecoveredParent | None
) -> RecoveredParent:
    if recovered_parent is None:
        raise ValueError("recovered parent is required for contribution graph")
    if recovered_parent.material_id != record.material_id:
        raise ValueError("recovered parent belongs to a different canonical parent")
    if not recovered_parent.passed:
        raise ValueError("recovered parent did not pass C0 recovery")
    if recovered_parent.target_space_group != record.space_group:
        raise ValueError("canonical and recovered target space groups differ")
    canonical_composition = tuple(sorted(Counter(record.atomic_numbers).items()))
    if _full_composition(recovered_parent) != canonical_composition:
        raise ValueError("canonical and recovered full compositions differ")
    canonical_orbits = {orbit.orbit_id: orbit for orbit in record.orbits}
    recovered_orbits = {
        orbit.orbit_instance_id: orbit for orbit in recovered_parent.orbits
    }
    if set(canonical_orbits) != set(recovered_orbits):
        raise ValueError("canonical and recovered orbit identities differ")
    for orbit_id, canonical in canonical_orbits.items():
        recovered = recovered_orbits[orbit_id]
        if (
            canonical.wyckoff_letter != recovered.wyckoff_letter
            or canonical.atomic_number != recovered.species
            or canonical.multiplicity != recovered.multiplicity
        ):
            raise ValueError("canonical and recovered orbit contracts differ")
    return recovered_parent


def _matching_legal_action(
    compiler: SpaceGroupLegalActionCompiler,
    state: SymmetryAssemblyState,
    orbit: OrbitState,
) -> LegalAddOrbit:
    matches = [
        legal
        for legal in compiler.legal_add_actions(state)
        if legal.wyckoff_letter == orbit.wyckoff_letter
        and legal.species == orbit.species
        and legal.multiplicity == orbit.multiplicity
        and legal.free_parameter_count == len(orbit.free_parameters)
    ]
    if len(matches) != 1:
        raise ValueError("true D_orbit action is not uniquely C0 compiler-legal")
    return matches[0]


def _apply_true_orbit(
    compiler: SpaceGroupLegalActionCompiler,
    projector: C0SymmetryProjector,
    state: SymmetryAssemblyState,
    orbit: OrbitState,
    *,
    require_termination: bool,
) -> tuple[SymmetryAssemblyState, LegalAddOrbit]:
    legal = _matching_legal_action(compiler, state, orbit)
    next_state = compiler.apply_add(
        state,
        AddOrbitAction(
            wyckoff_letter=orbit.wyckoff_letter,
            species=orbit.species,
            free_parameters=orbit.free_parameters,
            orbit_instance_id=orbit.orbit_instance_id,
        ),
    )
    receipt = projector.project(next_state)
    if not receipt.accepted or (
        require_termination and not compiler.can_terminate(next_state, receipt)
    ):
        raise ValueError(
            "true D_orbit action failed C0 compiler/projector verification"
        )
    return next_state, legal


def _build_c0_node_state(
    recovered_parent: RecoveredParent,
    active_orbit_ids: tuple[str, ...],
    *,
    max_sites: int,
    minimum_distance: float,
) -> tuple[
    SymmetryAssemblyState,
    C0AssemblyStateContract,
    tuple[ActionDescription, ...],
    bool,
    bool | None,
    bool,
]:
    full_composition = _full_composition(recovered_parent)
    state = SymmetryAssemblyState.empty(
        target_space_group=recovered_parent.target_space_group,
        composition=full_composition,
        lattice=recovered_parent.lattice,
    )
    compiler = SpaceGroupLegalActionCompiler(max_sites=max_sites)
    projector = C0SymmetryProjector(minimum_distance=minimum_distance)
    orbits = {orbit.orbit_instance_id: orbit for orbit in recovered_parent.orbits}
    for orbit_id in active_orbit_ids:
        orbit = orbits.get(orbit_id)
        if orbit is None:
            raise ValueError("C0 state requested an unknown orbit")
        state, _ = _apply_true_orbit(
            compiler,
            projector,
            state,
            orbit,
            require_termination=False,
        )
    compiler_state_verified = True
    projector_verified: bool | None = None
    termination_verified = False
    if active_orbit_ids:
        receipt = projector.project(state)
        if not receipt.accepted:
            raise ValueError("precomputed C0 node state was rejected")
        projector_verified = True
        if not state.remaining_composition and not compiler.can_terminate(
            state, receipt
        ):
            raise ValueError("complete C0 node cannot terminate")
        termination_verified = not state.remaining_composition
    elif not compiler.legal_add_actions(state):
        raise ValueError("empty C0 node has no compiler-legal action")
    contract = _state_contract(state, full_composition=full_composition)
    legal_actions = tuple(
        sorted(
            {_action_description(legal) for legal in compiler.legal_add_actions(state)}
        )
    )
    return (
        state,
        contract,
        legal_actions,
        compiler_state_verified,
        projector_verified,
        termination_verified,
    )


def _expected_trajectory_sequence_hash(
    record: CanonicalParentRecord, trajectory: StructuralTrajectory
) -> str:
    payload = {
        "schema_version": OPERATOR_SCHEMA_VERSION,
        "canonical_structure_hash": record.canonical_structure_hash,
        "operator": trajectory.operator,
        "forward_actions": tuple(
            action.to_dict() for action in trajectory.forward_actions
        ),
        "inverse_actions": tuple(
            action.to_dict() for action in trajectory.inverse_actions
        ),
    }
    return hashlib.sha256(canonical_payload_json(payload).encode("utf-8")).hexdigest()


def _validate_trajectories(
    record: CanonicalParentRecord,
    registry: RelationRegistry,
    trajectories: Iterable[StructuralTrajectory],
) -> tuple[str, ...]:
    supplied = tuple(trajectories)
    if not supplied:
        raise ValueError("at least one D_orbit trajectory is required")
    sequence_hashes = []
    for trajectory in supplied:
        if (
            trajectory.operator != "D_orbit"
            or trajectory.parent_structure_id != record.material_id
        ):
            raise ValueError(
                "D_orbit trajectory belongs to a different parent or operator"
            )
        if trajectory.sequence_hash != _expected_trajectory_sequence_hash(
            record, trajectory
        ):
            raise ValueError("D_orbit trajectory sequence hash mismatch")
        try:
            result = replay_trajectory(record, registry, trajectory)
        except OperatorReplayError as error:
            raise ValueError("D_orbit trajectory replay failed") from error
        if not result.passed:
            raise ValueError("D_orbit trajectory replay failed")
        sequence_hashes.append(trajectory.sequence_hash)
    if len(set(sequence_hashes)) != len(sequence_hashes):
        raise ValueError("duplicate D_orbit trajectory sequence hash")
    return tuple(sorted(sequence_hashes))


def build_parent_state_graph(
    record: CanonicalParentRecord,
    registry: RelationRegistry,
    *,
    recovered_parent: RecoveredParent | None,
    d_orbit_trajectories: Iterable[StructuralTrajectory],
    max_sites: int = 20,
    minimum_distance: float = 0.5,
) -> ParentStateGraph:
    """Build a fail-closed exhaustive D_orbit graph with C0 state contracts."""

    if max_sites != 20:
        raise ValueError("max_sites must be frozen at 20")
    if minimum_distance != 0.5:
        raise ValueError("minimum_distance must be frozen at 0.5")
    if registry.material_id != record.material_id:
        raise ValueError("relation registry belongs to a different parent")
    if registry.canonical_structure_hash != record.canonical_structure_hash:
        raise ValueError("relation registry structure hash mismatch")
    orbit_ids = tuple(sorted(orbit.orbit_id for orbit in record.orbits))
    if not 1 <= len(orbit_ids) <= 8:
        raise ValueError("D_orbit graph orbit count must satisfy 1 <= K <= 8")
    recovered = _validate_recovered_parent(record, recovered_parent)
    sequence_hashes = _validate_trajectories(record, registry, d_orbit_trajectories)

    nodes_by_active: dict[tuple[str, ...], StateGraphNode] = {}
    for mask in range(1 << len(orbit_ids)):
        active = tuple(
            orbit_id for index, orbit_id in enumerate(orbit_ids) if mask & (1 << index)
        )
        state = _state_for_active_orbits(record, registry, active)
        (
            compiler_state,
            c0_state,
            legal_actions,
            compiler_state_verified,
            projector_verified,
            termination_verified,
        ) = _build_c0_node_state(
            recovered,
            active,
            max_sites=max_sites,
            minimum_distance=minimum_distance,
        )
        if (
            tuple(orbit.orbit_instance_id for orbit in c0_state.present_orbits)
            != active
        ):
            raise RuntimeError("C0_NODE_ORBIT_IDENTITY_MISMATCH")
        nodes_by_active[active] = StateGraphNode(
            state=state,
            state_hash=state.content_hash(),
            c0_state=c0_state,
            compiler_state=compiler_state,
            legal_action_set=legal_actions,
            compiler_state_verified=compiler_state_verified,
            projector_verified=projector_verified,
            termination_verified=termination_verified,
            depth=len(active),
            number_of_future_completion_paths=0,
            minimum_remaining_steps=len(orbit_ids) - len(active),
        )
    if len({node.state_hash for node in nodes_by_active.values()}) != len(
        nodes_by_active
    ):
        raise RuntimeError("D_ORBIT_SUBSET_HASH_COLLISION")

    recovered_orbits = {orbit.orbit_instance_id: orbit for orbit in recovered.orbits}
    edges = []
    for active, source_node in sorted(nodes_by_active.items()):
        compiler = SpaceGroupLegalActionCompiler(max_sites=max_sites)
        projector = C0SymmetryProjector(minimum_distance=minimum_distance)
        for target_orbit_id in orbit_ids:
            if target_orbit_id in active:
                continue
            destination_active = tuple(sorted((*active, target_orbit_id)))
            destination_node = nodes_by_active[destination_active]
            restored = apply_structural_action(
                source_node.state,
                StructuralAction("D_orbit", "RESTORE", target_orbit_id),
                record,
                registry,
            )
            removed = apply_structural_action(
                restored,
                StructuralAction("D_orbit", "REMOVE", target_orbit_id),
                record,
                registry,
            )
            if restored.content_hash() != destination_node.state_hash:
                raise RuntimeError("D_ORBIT_RESTORE_DESTINATION_MISMATCH")
            if removed.content_hash() != source_node.state_hash:
                raise RuntimeError("D_ORBIT_REMOVE_SOURCE_MISMATCH")
            successor_state, legal = _apply_true_orbit(
                compiler,
                projector,
                source_node.compiler_state,
                recovered_orbits[target_orbit_id],
                require_termination=not destination_node.c0_state.remaining_composition,
            )
            successor_contract = _state_contract(
                successor_state,
                full_composition=source_node.c0_state.full_composition,
            )
            if successor_contract != destination_node.c0_state:
                raise RuntimeError("C0_EDGE_SUCCESSOR_CONTRACT_MISMATCH")
            action_description = _action_description(legal)
            if action_description not in source_node.legal_action_set:
                raise RuntimeError("C0_EDGE_ACTION_MISSING_FROM_LEGAL_SET")
            edges.append(
                AssemblyEdge(
                    source_state_hash=source_node.state_hash,
                    destination_state_hash=destination_node.state_hash,
                    source_c0_state_hash=source_node.c0_state.state_hash,
                    destination_c0_state_hash=destination_node.c0_state.state_hash,
                    compiler_successor_state_hash=successor_contract.state_hash,
                    target_orbit_id=target_orbit_id,
                    action_description=action_description,
                    restore_state_hash=restored.content_hash(),
                    remove_state_hash=removed.content_hash(),
                    offline_c0_verified=True,
                )
            )

    outgoing: dict[str, list[AssemblyEdge]] = {}
    for edge in edges:
        outgoing.setdefault(edge.source_state_hash, []).append(edge)
    future_counts: dict[str, int] = {}
    for node in sorted(
        nodes_by_active.values(), key=lambda item: item.depth, reverse=True
    ):
        successors = outgoing.get(node.state_hash, ())
        future_counts[node.state_hash] = (
            1
            if not successors
            else sum(future_counts[edge.destination_state_hash] for edge in successors)
        )
    nodes = tuple(
        sorted(
            (
                replace(
                    node,
                    number_of_future_completion_paths=future_counts[node.state_hash],
                )
                for node in nodes_by_active.values()
            ),
            key=lambda node: (node.depth, node.state_hash),
        )
    )
    return ParentStateGraph(
        record=record,
        registry=registry,
        recovered_parent=recovered,
        max_sites=max_sites,
        minimum_distance=minimum_distance,
        d_orbit_trajectory_sequence_hashes=sequence_hashes,
        nodes=nodes,
        assembly_edges=tuple(edges),
    )


def build_contribution_corpus(
    graphs: Iterable[ParentStateGraph],
    *,
    structure_ood_splits: Mapping[str, str],
) -> StateGraphCorpus:
    """Create compiler-derived grouped legal-action labels from graph edges."""

    graphs_tuple = tuple(graphs)
    labels = []
    for graph in graphs_tuple:
        split = structure_ood_splits.get(graph.record.material_id)
        if split is None:
            raise ValueError("missing Structure-OOD split for contribution parent")
        nodes_by_hash = {node.state_hash: node for node in graph.nodes}
        outgoing: dict[str, list[AssemblyEdge]] = {}
        for edge in graph.assembly_edges:
            outgoing.setdefault(edge.source_state_hash, []).append(edge)
        for node in graph.nodes:
            successors = outgoing.get(node.state_hash, ())
            positive_ids: dict[ActionDescription, list[str]] = {}
            path_counts: dict[ActionDescription, dict[str, int]] = {}
            for edge in successors:
                positive_ids.setdefault(edge.action_description, []).append(
                    edge.target_orbit_id
                )
                path_counts.setdefault(edge.action_description, {})[
                    edge.target_orbit_id
                ] = nodes_by_hash[
                    edge.destination_state_hash
                ].number_of_future_completion_paths
            viable = tuple(sorted(positive_ids))
            compiler = SpaceGroupLegalActionCompiler(max_sites=graph.max_sites)
            legal = tuple(
                sorted(
                    {
                        _action_description(legal)
                        for legal in compiler.legal_add_actions(node.compiler_state)
                    }
                )
            )
            if legal != node.legal_action_set:
                raise RuntimeError("C0 node legal-action contract drifted")
            if not set(viable).issubset(legal):
                raise RuntimeError("C0 graph lost a true legal D_orbit action")
            aggregate_counts = {
                action: sum(path_counts.get(action, {}).values()) for action in legal
            }
            labels.append(
                GroupedOfflineLabelRecord(
                    parent_structure_id=graph.record.material_id,
                    split=split,
                    state_hash=node.state_hash,
                    depth=node.depth,
                    viable_action_set=viable,
                    nonviable_legal_action_set=tuple(
                        action for action in legal if action not in positive_ids
                    ),
                    positive_successor_orbit_ids={
                        action: tuple(sorted(orbit_ids))
                        for action, orbit_ids in positive_ids.items()
                    },
                    successor_path_counts={
                        action: dict(sorted(counts.items()))
                        for action, counts in path_counts.items()
                    },
                    future_path_count_by_action=aggregate_counts,
                    log1p_future_path_count_by_action={
                        action: math.log1p(count)
                        for action, count in aggregate_counts.items()
                    },
                    number_of_future_completion_paths=node.number_of_future_completion_paths,
                    minimum_remaining_steps=node.minimum_remaining_steps,
                    operator_provenance={
                        "operator": "D_orbit",
                        "direction": "RESTORE",
                        "structural_operator_schema_version": OPERATOR_SCHEMA_VERSION,
                        "compiler_state_verified": node.compiler_state_verified,
                        "projector_verified": node.projector_verified,
                        "outgoing_edge_c0_verified": (
                            all(edge.offline_c0_verified for edge in successors)
                            if successors
                            else None
                        ),
                        "terminal_c0_termination_verified": node.termination_verified,
                        "compiler_legal_action_set_derived": True,
                        "max_sites": graph.max_sites,
                        "minimum_distance": graph.minimum_distance,
                        "d_orbit_trajectory_sequence_hashes": (
                            graph.d_orbit_trajectory_sequence_hashes
                        ),
                    },
                )
            )
    return StateGraphCorpus(graphs=graphs_tuple, labels=tuple(labels))
