from __future__ import annotations

import hashlib
import math
from collections import defaultdict
from typing import Mapping, Sequence

import numpy as np

from crysalis_g1.experiments.physics_aware_orbit import (
    hierarchical_paired_bootstrap,
)


REGISTERED_STREAM_SEEDS = (20260823, 20260824)
REGISTERED_ARMS = ("I", "P")
BOOTSTRAP_REPLICATES = 10_000
MINIMUM_SUBGROUP_TRAJECTORIES = 48
TERMINAL_NONHARM_MARGIN_PP = -3.0
MINIMUM_ORDERED_FORCE_GAP = 0.10
MINIMUM_ORDERED_TERMINAL_GAP_PP = 3.0
MINIMUM_ORDERED_CORRELATION = 0.80

REQUIRED_STEP_FIELDS = (
    "parent_id",
    "stream_seed",
    "arm",
    "trajectory_id",
    "step_index",
    "stable_join_key",
    "assembly_progress",
    "remaining_orbit_count",
    "remaining_composition",
    "target_space_group",
    "crystal_system",
    "lattice_summary",
    "chosen_action_signature",
    "wyckoff_id",
    "multiplicity",
    "free_dof_count",
    "legal_candidate_count",
    "chosen_action_inverse_probability",
    "inverse_policy_entropy",
    "inverse_policy_top1_top2_margin",
    "inverse_policy_logit",
    "predicted_terminal_probability",
    "predicted_log1p_force",
    "mdn_mixture_entropy",
    "mdn_maximum_component_probability",
    "mdn_effective_component_count",
    "mdn_probability_weighted_mean_kappa",
    "mdn_maximum_active_dof_kappa",
    "mdn_active_dof_count",
    "mdn_predicted_circular_dispersion",
    "expansion_success",
    "projector_accepted",
    "geometry_rejection_reason",
    "minimum_interatomic_distance_angstrom",
    "discrete_dead_end",
    "terminal_valid",
    "terminal_composition_match",
    "terminal_target_sg_match",
    "branch_type",
    "first_off_parent_step",
)


def _sigmoid(value: float) -> float:
    if value >= 0.0:
        exponential = math.exp(-value)
        return 1.0 / (1.0 + exponential)
    exponential = math.exp(value)
    return exponential / (1.0 + exponential)


def _policy_summary(probabilities: Sequence[float]) -> tuple[float | None, float | None]:
    values = np.asarray(probabilities, dtype=float)
    if not len(values):
        return None, None
    if values.ndim != 1 or np.any(values < 0.0) or not np.isfinite(values).all():
        raise ValueError("inverse-policy probabilities must be a finite nonnegative vector")
    if not math.isclose(float(values.sum()), 1.0, rel_tol=1e-5, abs_tol=1e-5):
        raise ValueError("inverse-policy probabilities must sum to one")
    entropy = float(-sum(value * math.log(value) for value in values if value > 0.0))
    ordered = np.sort(values)[::-1]
    margin = float(ordered[0] - (ordered[1] if len(ordered) > 1 else 0.0))
    return entropy, margin


def enrich_step_record(
    raw: Mapping[str, object],
    *,
    trajectory: Mapping[str, object],
    registered_arm: str,
    parent_orbit_count: int,
    crystal_system: str,
    lattice_summary: Mapping[str, object],
) -> dict[str, object]:
    if registered_arm not in REGISTERED_ARMS:
        raise ValueError(f"unregistered replay arm: {registered_arm}")
    if parent_orbit_count <= 0:
        raise ValueError("parent orbit count must be positive")
    parent_id = str(raw["parent_id"])
    stream_seed = int(raw["stream_seed"])
    step_index = int(raw["step_index"])
    if step_index <= 0:
        raise ValueError("step index must be one-based")
    trajectory_id = f"validation:{stream_seed}:{registered_arm}:{parent_id}"
    probabilities = [float(value) for value in raw["learned_candidate_probabilities"]]
    entropy, margin = _policy_summary(probabilities)
    chosen_id = raw["chosen_hidden_orbit_instance_id"]
    candidate_ids = [str(value) for value in raw["candidate_hidden_orbit_instance_ids"]]
    if chosen_id is None:
        inverse_probability = None
    else:
        try:
            chosen_index = candidate_ids.index(str(chosen_id))
        except ValueError as error:
            raise ValueError("chosen action is absent from candidate IDs") from error
        inverse_probability = probabilities[chosen_index]
    signature = raw["chosen_action_signature"]
    if signature is None:
        species = wyckoff = multiplicity = free_dof = None
        branch_type = "unresolved"
    else:
        species = int(signature["species"])
        wyckoff = str(signature["wyckoff_letter"])
        multiplicity = int(signature["multiplicity"])
        free_dof = int(signature["free_dof_count"])
        branch_type = (
            "parent-consistent"
            if bool(raw["strict_parent_orbit_id_match"])
            else "alternative"
        )
    terminal_logit = raw["terminal_value_logit"]
    mdn = raw["direct_mdn_distribution_features"]
    mdn = {} if mdn is None else mdn
    failure = trajectory["failure"]
    output = dict(raw)
    output.update(
        {
            "schema_version": "validation-step-logged-physical-value.1.0.0",
            "source_record_id": raw.get("record_id"),
            "record_id": trajectory_id,
            "parent_id": parent_id,
            "stream_seed": stream_seed,
            "arm": registered_arm,
            "trajectory_id": trajectory_id,
            "stable_join_key": [
                parent_id,
                stream_seed,
                registered_arm,
                trajectory_id,
                step_index,
            ],
            "step_index": step_index,
            "assembly_progress": (step_index - 1) / parent_orbit_count,
            "remaining_orbit_count": max(parent_orbit_count - (step_index - 1), 0),
            "remaining_composition": raw["remaining_composition"],
            "target_space_group": int(raw["target_space_group"]),
            "crystal_system": str(crystal_system),
            "lattice_summary": dict(lattice_summary),
            "chosen_action_signature": signature,
            "chosen_species": species,
            "wyckoff_id": wyckoff,
            "multiplicity": multiplicity,
            "free_dof_count": free_dof,
            "legal_candidate_count": int(raw["legal_candidate_count"]),
            "selected_score_probability": raw.get("chosen_action_probability"),
            "chosen_action_probability": inverse_probability,
            "chosen_action_inverse_probability": inverse_probability,
            "policy_entropy": entropy,
            "inverse_policy_entropy": entropy,
            "top1_top2_margin": margin,
            "inverse_policy_top1_top2_margin": margin,
            "inverse_policy_logit": raw["inverse_policy_logit"],
            "predicted_terminal_probability": None
            if terminal_logit is None
            else _sigmoid(float(terminal_logit)),
            "predicted_force_value": raw["predicted_log1p_force"],
            "predicted_log1p_force": raw["predicted_log1p_force"],
            "mdn_mixture_entropy": mdn.get("mixture_entropy"),
            "mdn_maximum_component_probability": mdn.get(
                "maximum_component_probability"
            ),
            "mdn_effective_component_count": mdn.get("effective_component_count"),
            "mdn_probability_weighted_mean_kappa": mdn.get(
                "probability_weighted_mean_kappa"
            ),
            "mdn_maximum_active_dof_kappa": mdn.get(
                "maximum_active_dof_kappa"
            ),
            "mdn_active_dof_count": mdn.get("active_dof_count"),
            "mdn_predicted_circular_dispersion": mdn.get(
                "predicted_circular_dispersion"
            ),
            "expansion_success": raw["official_expansion_status"] == "EXPANDED",
            "projector_accepted": raw["projector_accepted"],
            "geometry_rejection": failure == "PROJECTOR_REJECTED",
            "geometry_rejection_reason": raw["projector_rejection_reason"],
            "minimum_interatomic_distance_angstrom": raw[
                "minimum_interatomic_distance_angstrom"
            ],
            "discrete_dead_end": failure == "NO_LEGAL_ACTION",
            "terminal_valid": bool(trajectory["terminal_valid"]),
            "terminal_legal_status": bool(trajectory["terminal_valid"]),
            "terminal_composition_match": bool(trajectory["composition_match"]),
            "terminal_target_sg_match": bool(
                trajectory["target_space_group_valid"]
            ),
            "force_target_log1p": trajectory["force_target_log1p"],
            "parent_consistent": branch_type == "parent-consistent",
            "alternative_branch": branch_type == "alternative",
            "branch_type": branch_type,
            "first_off_parent_step": trajectory["first_off_parent_step"],
        }
    )
    missing = [field for field in REQUIRED_STEP_FIELDS if field not in output]
    if missing:
        raise RuntimeError(f"enriched step record lacks fields: {missing}")
    return output


def validate_force_join(
    step_rows: Sequence[Mapping[str, object]],
    force_rows: Sequence[Mapping[str, object]],
) -> bool:
    step_trajectory_ids = {str(row["trajectory_id"]) for row in step_rows}
    force_by_id: dict[str, Mapping[str, object]] = {}
    for row in force_rows:
        trajectory_id = str(row["trajectory_id"])
        if trajectory_id in force_by_id:
            raise ValueError(f"duplicate force row: {trajectory_id}")
        force_by_id[trajectory_id] = row
    missing = sorted(step_trajectory_ids - set(force_by_id))
    extra = sorted(set(force_by_id) - step_trajectory_ids)
    if missing or extra:
        raise ValueError(
            f"force row coverage differs from step trajectories: missing={missing[:3]}, extra={extra[:3]}"
        )
    for trajectory_id, row in force_by_id.items():
        terminal = bool(row["terminal_valid"])
        force = row["terminal_max_force_ev_per_angstrom"]
        target = row["force_target_log1p"]
        if terminal:
            if force is None or target is None:
                raise ValueError(f"legal terminal lacks force row label: {trajectory_id}")
            force_value = float(force)
            target_value = float(target)
            if force_value < 0.0 or not math.isfinite(force_value):
                raise ValueError(f"invalid terminal force: {trajectory_id}")
            if not math.isclose(
                math.log1p(force_value), target_value, rel_tol=1e-7, abs_tol=1e-7
            ):
                raise ValueError(f"force/log1p mismatch: {trajectory_id}")
        elif force is not None or target is not None:
            raise ValueError(f"failed trajectory was assigned a force: {trajectory_id}")
    for row in step_rows:
        force_row = force_by_id[str(row["trajectory_id"])]
        if row["force_target_log1p"] != force_row["force_target_log1p"]:
            raise ValueError(f"step/force target mismatch: {row['trajectory_id']}")
    return True


def _bootstrap_metric(
    values_by_stream: Mapping[int, Sequence[float]],
    *,
    seed_key: str,
    replicates: int,
) -> dict[str, float | None]:
    populated = {
        int(stream): np.asarray(values, dtype=float)
        for stream, values in values_by_stream.items()
        if len(values)
    }
    point = (
        float(np.concatenate(list(populated.values())).mean()) if populated else None
    )
    if set(populated) != set(REGISTERED_STREAM_SEEDS):
        return {"point": point, "ci95_lower": None, "ci95_upper": None}
    seed = int(hashlib.sha256(seed_key.encode("utf-8")).hexdigest()[:8], 16)
    result = hierarchical_paired_bootstrap(
        [populated[stream] for stream in REGISTERED_STREAM_SEEDS],
        seed=seed,
        replicates=replicates,
    )
    return result


def _quartile_groups(
    rows: Sequence[Mapping[str, object]], feature: str
) -> list[tuple[str, object, object, list[Mapping[str, object]]]]:
    values = np.asarray([float(row[feature]) for row in rows], dtype=float)
    if not len(values) or not np.isfinite(values).all():
        raise ValueError(f"quartile feature is unavailable: {feature}")
    edges = np.quantile(values, (0.0, 0.25, 0.50, 0.75, 1.0))
    output = []
    for index, subgroup in enumerate(("Q1", "Q2", "Q3", "Q4")):
        lower = float(edges[index])
        upper = float(edges[index + 1])
        selected = [
            row
            for row in rows
            if (
                lower <= float(row[feature]) <= upper
                if index == 0
                else lower < float(row[feature]) <= upper
            )
        ]
        output.append((subgroup, lower, upper, selected))
    return output


def _categorical_groups(
    rows: Sequence[Mapping[str, object]],
    feature: str,
    levels: Sequence[object],
) -> list[tuple[str, object, object, list[Mapping[str, object]]]]:
    return [
        (
            str(level),
            level,
            level,
            [row for row in rows if str(row[feature]) == str(level)],
        )
        for level in levels
    ]


def _subgroup_effect(
    *,
    variable: str,
    subgroup: str,
    lower: object,
    upper: object,
    selected_steps: Sequence[Mapping[str, object]],
    outcome_by_key: Mapping[tuple[int, str, str], Mapping[str, object]],
    stream_seeds: Sequence[int],
    replicates: int,
) -> dict[str, object]:
    selected_keys = sorted(
        {(int(row["stream_seed"]), str(row["parent_id"])) for row in selected_steps}
    )
    paired_keys = [
        key
        for key in selected_keys
        if (key[0], key[1], "I") in outcome_by_key
        and (key[0], key[1], "P") in outcome_by_key
    ]
    metric_values: dict[str, dict[int, list[float]]] = {
        "terminal": defaultdict(list),
        "geometry": defaultdict(list),
        "dead_end": defaultdict(list),
        "force": defaultdict(list),
    }
    force_deltas = []
    for stream_seed, parent_id in paired_keys:
        inverse = outcome_by_key[(stream_seed, parent_id, "I")]
        physics = outcome_by_key[(stream_seed, parent_id, "P")]
        metric_values["terminal"][stream_seed].append(
            float(bool(physics["terminal_valid"]))
            - float(bool(inverse["terminal_valid"]))
        )
        metric_values["geometry"][stream_seed].append(
            float(physics["failure"] == "PROJECTOR_REJECTED")
            - float(inverse["failure"] == "PROJECTOR_REJECTED")
        )
        metric_values["dead_end"][stream_seed].append(
            float(physics["failure"] == "NO_LEGAL_ACTION")
            - float(inverse["failure"] == "NO_LEGAL_ACTION")
        )
        if bool(inverse["terminal_valid"]) and bool(physics["terminal_valid"]):
            inverse_force = inverse["force_target_log1p"]
            physics_force = physics["force_target_log1p"]
            if inverse_force is None or physics_force is None:
                raise ValueError("common-legal subgroup pair lacks a force target")
            delta = float(physics_force) - float(inverse_force)
            metric_values["force"][stream_seed].append(delta)
            force_deltas.append(delta)
    bootstraps = {
        metric: _bootstrap_metric(
            values,
            seed_key=f"{variable}:{subgroup}:{metric}",
            replicates=replicates,
        )
        for metric, values in metric_values.items()
    }
    output: dict[str, object] = {
        "analysis_cohort": "256_parent_validation_primary",
        "comparison": "P_minus_I",
        "stratification_anchor": "inverse_arm_chosen_state_action",
        "variable": variable,
        "subgroup": subgroup,
        "lower": lower,
        "upper": upper,
        "sample_n": len(selected_steps),
        "paired_trajectory_n": len(paired_keys),
        "terminal_success_delta_pp": None
        if bootstraps["terminal"]["point"] is None
        else 100.0 * float(bootstraps["terminal"]["point"]),
        "terminal_success_ci95_lower_pp": None
        if bootstraps["terminal"]["ci95_lower"] is None
        else 100.0 * float(bootstraps["terminal"]["ci95_lower"]),
        "terminal_success_ci95_upper_pp": None
        if bootstraps["terminal"]["ci95_upper"] is None
        else 100.0 * float(bootstraps["terminal"]["ci95_upper"]),
        "geometry_rejection_delta_pp": None
        if bootstraps["geometry"]["point"] is None
        else 100.0 * float(bootstraps["geometry"]["point"]),
        "geometry_rejection_ci95_lower_pp": None
        if bootstraps["geometry"]["ci95_lower"] is None
        else 100.0 * float(bootstraps["geometry"]["ci95_lower"]),
        "geometry_rejection_ci95_upper_pp": None
        if bootstraps["geometry"]["ci95_upper"] is None
        else 100.0 * float(bootstraps["geometry"]["ci95_upper"]),
        "discrete_dead_end_delta_pp": None
        if bootstraps["dead_end"]["point"] is None
        else 100.0 * float(bootstraps["dead_end"]["point"]),
        "discrete_dead_end_ci95_lower_pp": None
        if bootstraps["dead_end"]["ci95_lower"] is None
        else 100.0 * float(bootstraps["dead_end"]["ci95_lower"]),
        "discrete_dead_end_ci95_upper_pp": None
        if bootstraps["dead_end"]["ci95_upper"] is None
        else 100.0 * float(bootstraps["dead_end"]["ci95_upper"]),
        "common_legal_n": len(force_deltas),
        "paired_log1p_force_delta": bootstraps["force"]["point"],
        "force_ci95_lower": bootstraps["force"]["ci95_lower"],
        "force_ci95_upper": bootstraps["force"]["ci95_upper"],
        "force_win_rate": None
        if not force_deltas
        else float(np.mean(np.asarray(force_deltas) < 0.0)),
        "bootstrap_replicates": replicates,
    }
    for stream_seed in stream_seeds:
        for metric, label, scale in (
            ("terminal", "terminal_delta_pp", 100.0),
            ("geometry", "geometry_rejection_delta_pp", 100.0),
            ("dead_end", "dead_end_delta_pp", 100.0),
            ("force", "force_delta", 1.0),
        ):
            values = metric_values[metric].get(int(stream_seed), [])
            output[f"stream_{stream_seed}_{label}"] = (
                None if not values else scale * float(np.mean(values))
            )
    return output


def build_subgroup_effect_rows(
    inverse_step_rows: Sequence[Mapping[str, object]],
    force_rows: Sequence[Mapping[str, object]],
    *,
    stream_seeds: Sequence[int] = REGISTERED_STREAM_SEEDS,
    replicates: int = BOOTSTRAP_REPLICATES,
) -> list[dict[str, object]]:
    if tuple(int(value) for value in stream_seeds) != REGISTERED_STREAM_SEEDS:
        raise ValueError("state-dependent replay requires the two registered streams")
    chosen_steps = [
        row
        for row in inverse_step_rows
        if row["arm"] == "I" and row["chosen_action_signature"] is not None
    ]
    if not chosen_steps:
        raise ValueError("inverse validation step records contain no chosen actions")
    outcome_by_key: dict[tuple[int, str, str], Mapping[str, object]] = {}
    for row in force_rows:
        key = (int(row["stream_seed"]), str(row["parent_id"]), str(row["arm"]))
        if key in outcome_by_key:
            raise ValueError(f"duplicate trajectory outcome key: {key}")
        outcome_by_key[key] = row
    groups: list[tuple[str, str, object, object, list[Mapping[str, object]]]] = []
    for variable, feature in (
        ("assembly_progress", "assembly_progress"),
        ("legal_candidate_count", "legal_candidate_count"),
        ("inverse_confidence", "chosen_action_inverse_probability"),
        ("policy_entropy", "inverse_policy_entropy"),
        ("mdn_uncertainty", "mdn_mixture_entropy"),
    ):
        for subgroup, lower, upper, selected in _quartile_groups(chosen_steps, feature):
            groups.append((variable, subgroup, lower, upper, selected))
    for variable, feature, levels in (
        ("free_dof", "free_dof_count", (0, 1, 2, 3)),
        (
            "crystal_system",
            "crystal_system",
            tuple(sorted({str(row["crystal_system"]) for row in chosen_steps})),
        ),
        ("branch_type", "branch_type", ("parent-consistent", "alternative")),
    ):
        for subgroup, lower, upper, selected in _categorical_groups(
            chosen_steps, feature, levels
        ):
            groups.append((variable, subgroup, lower, upper, selected))
    return [
        _subgroup_effect(
            variable=variable,
            subgroup=subgroup,
            lower=lower,
            upper=upper,
            selected_steps=selected,
            outcome_by_key=outcome_by_key,
            stream_seeds=stream_seeds,
            replicates=replicates,
        )
        for variable, subgroup, lower, upper, selected in groups
    ]


def _ordered_rows(
    rows: Sequence[Mapping[str, object]], variable: str, labels: Sequence[str]
) -> list[Mapping[str, object]] | None:
    by_label = {
        str(row["subgroup"]): row for row in rows if row["variable"] == variable
    }
    if not all(label in by_label for label in labels):
        return None
    return [by_label[label] for label in labels]


def _two_stream_negative(row: Mapping[str, object], metric: str) -> bool:
    values = [
        row.get(f"stream_{stream}_{metric}") for stream in REGISTERED_STREAM_SEEDS
    ]
    return all(value is not None and float(value) < 0.0 for value in values)


def _ordered_force_status(
    ordered: Sequence[Mapping[str, object]] | None,
    *,
    minimum_subgroup_n: int,
) -> str:
    if ordered is None or any(row["paired_log1p_force_delta"] is None for row in ordered):
        return "UNRESOLVED"
    forces = np.asarray([float(row["paired_log1p_force_delta"]) for row in ordered])
    correlation = float(np.corrcoef(np.arange(len(forces)), forces)[0, 1])
    high = ordered[-1]
    supported = (
        int(high["paired_trajectory_n"]) >= minimum_subgroup_n
        and correlation <= -MINIMUM_ORDERED_CORRELATION
        and float(forces[-1] - forces[0]) <= -MINIMUM_ORDERED_FORCE_GAP
        and high["force_ci95_upper"] is not None
        and float(high["force_ci95_upper"]) < 0.0
        and high["terminal_success_ci95_lower_pp"] is not None
        and float(high["terminal_success_ci95_lower_pp"])
        > TERMINAL_NONHARM_MARGIN_PP
        and _two_stream_negative(high, "force_delta")
    )
    return "SUPPORTED" if supported else "NOT_SUPPORTED"


def _inverse_confidence_status(
    ordered: Sequence[Mapping[str, object]] | None,
    *,
    minimum_subgroup_n: int,
) -> str:
    if ordered is None or any(row["terminal_success_delta_pp"] is None for row in ordered):
        return "UNRESOLVED"
    terminal = np.asarray([float(row["terminal_success_delta_pp"]) for row in ordered])
    correlation = float(np.corrcoef(np.arange(len(terminal)), terminal)[0, 1])
    high = ordered[-1]
    supported = (
        int(high["paired_trajectory_n"]) >= minimum_subgroup_n
        and correlation <= -MINIMUM_ORDERED_CORRELATION
        and float(terminal[-1] - terminal[0]) <= -MINIMUM_ORDERED_TERMINAL_GAP_PP
        and _two_stream_negative(high, "terminal_delta_pp")
    )
    return "SUPPORTED" if supported else "NOT_SUPPORTED"


def _free_dof_status(
    rows: Sequence[Mapping[str, object]], *, minimum_subgroup_n: int
) -> str:
    ordered = _ordered_rows(rows, "free_dof", ("0", "1", "2", "3"))
    if ordered is None:
        return "UNRESOLVED"
    usable = [
        row
        for row in ordered
        if int(row["paired_trajectory_n"]) >= minimum_subgroup_n
        and row["paired_log1p_force_delta"] is not None
    ]
    if len(usable) < 3 or str(usable[0]["subgroup"]) != "0":
        return "UNRESOLVED"
    return _ordered_force_status(usable, minimum_subgroup_n=minimum_subgroup_n)


def _branch_status(
    rows: Sequence[Mapping[str, object]], *, minimum_subgroup_n: int
) -> str:
    ordered = _ordered_rows(
        rows, "branch_type", ("parent-consistent", "alternative")
    )
    if ordered is None or any(row["paired_log1p_force_delta"] is None for row in ordered):
        return "UNRESOLVED"
    parent, alternative = ordered
    supported = (
        int(alternative["paired_trajectory_n"]) >= minimum_subgroup_n
        and float(alternative["paired_log1p_force_delta"])
        - float(parent["paired_log1p_force_delta"])
        <= -MINIMUM_ORDERED_FORCE_GAP
        and alternative["force_ci95_upper"] is not None
        and float(alternative["force_ci95_upper"]) < 0.0
        and alternative["terminal_success_ci95_lower_pp"] is not None
        and float(alternative["terminal_success_ci95_lower_pp"])
        > TERMINAL_NONHARM_MARGIN_PP
        and _two_stream_negative(alternative, "force_delta")
    )
    return "SUPPORTED" if supported else "NOT_SUPPORTED"


def _strongest_heterogeneity(
    rows: Sequence[Mapping[str, object]], *, minimum_subgroup_n: int
) -> tuple[str, Mapping[str, object] | None]:
    by_variable: dict[str, list[Mapping[str, object]]] = defaultdict(list)
    for row in rows:
        if (
            int(row["paired_trajectory_n"]) >= minimum_subgroup_n
            and row["paired_log1p_force_delta"] is not None
            and row["terminal_success_ci95_lower_pp"] is not None
            and float(row["terminal_success_ci95_lower_pp"])
            > TERMINAL_NONHARM_MARGIN_PP
        ):
            by_variable[str(row["variable"])].append(row)
    candidates = []
    for variable, variable_rows in by_variable.items():
        if len(variable_rows) < 2:
            continue
        forces = [float(row["paired_log1p_force_delta"]) for row in variable_rows]
        spread = max(forces) - min(forces)
        best = min(variable_rows, key=lambda row: float(row["paired_log1p_force_delta"]))
        candidates.append((spread, variable, best))
    if not candidates:
        return "NONE", None
    _, variable, best = max(candidates, key=lambda item: (item[0], item[1]))
    return variable, best


def adjudicate_state_dependent_signal(
    rows: Sequence[Mapping[str, object]],
    *,
    minimum_subgroup_n: int = MINIMUM_SUBGROUP_TRAJECTORIES,
) -> dict[str, object]:
    h1 = _ordered_force_status(
        _ordered_rows(rows, "mdn_uncertainty", ("Q1", "Q2", "Q3", "Q4")),
        minimum_subgroup_n=minimum_subgroup_n,
    )
    h2 = _inverse_confidence_status(
        _ordered_rows(rows, "inverse_confidence", ("Q1", "Q2", "Q3", "Q4")),
        minimum_subgroup_n=minimum_subgroup_n,
    )
    h3 = _ordered_force_status(
        _ordered_rows(rows, "assembly_progress", ("Q1", "Q2", "Q3", "Q4")),
        minimum_subgroup_n=minimum_subgroup_n,
    )
    h4 = _free_dof_status(rows, minimum_subgroup_n=minimum_subgroup_n)
    h5 = _branch_status(rows, minimum_subgroup_n=minimum_subgroup_n)
    statuses = (h1, h2, h3, h4, h5)
    if any(status == "SUPPORTED" for status in (h1, h3, h4)):
        signal = "SUPPORTED"
    elif all(status == "UNRESOLVED" for status in statuses):
        signal = "UNRESOLVED"
    else:
        signal = "NOT_SUPPORTED"
    strongest, best = _strongest_heterogeneity(
        rows, minimum_subgroup_n=minimum_subgroup_n
    )
    if signal == "SUPPORTED":
        branch = "RETAIN_FOR_ONE_ADAPTIVE_GATE_EXPERIMENT"
        target = "STATE_DEPENDENT_COMPATIBILITY_GATE"
    elif signal == "NOT_SUPPORTED":
        branch = "STOP"
        target = "INVERSE_POLICY_PLUS_DIRECT_MDN_BASELINE"
    else:
        branch = "UNRESOLVED"
        target = "USER_DECISION"
    return {
        "STATE_DEPENDENT_PHYSICAL_VALUE_SIGNAL": signal,
        "H1_MDN_UNCERTAINTY": h1,
        "H2_INVERSE_CONFIDENCE": h2,
        "H3_ASSEMBLY_STAGE": h3,
        "H4_FREE_DOF": h4,
        "H5_ALTERNATIVE_BRANCH": h5,
        "STRONGEST_HETEROGENEITY_VARIABLE": strongest,
        "BEST_VALID_SUBGROUP": None if best is None else best["subgroup"],
        "BEST_VALID_SUBGROUP_N": None
        if best is None
        else int(best["paired_trajectory_n"]),
        "BEST_VALID_SUBGROUP_TERMINAL_DELTA_PP": None
        if best is None
        else best["terminal_success_delta_pp"],
        "BEST_VALID_SUBGROUP_FORCE_DELTA": None
        if best is None
        else best["paired_log1p_force_delta"],
        "VALUE_HEAD_BRANCH": branch,
        "NEXT_MODEL_TARGET": target,
        "decision_constants": {
            "minimum_subgroup_trajectories": minimum_subgroup_n,
            "terminal_nonharm_margin_pp": TERMINAL_NONHARM_MARGIN_PP,
            "minimum_ordered_force_gap": MINIMUM_ORDERED_FORCE_GAP,
            "minimum_ordered_terminal_gap_pp": MINIMUM_ORDERED_TERMINAL_GAP_PP,
            "minimum_ordered_correlation": MINIMUM_ORDERED_CORRELATION,
        },
    }


__all__ = [
    "BOOTSTRAP_REPLICATES",
    "MINIMUM_SUBGROUP_TRAJECTORIES",
    "REGISTERED_ARMS",
    "REGISTERED_STREAM_SEEDS",
    "REQUIRED_STEP_FIELDS",
    "adjudicate_state_dependent_signal",
    "build_subgroup_effect_rows",
    "enrich_step_record",
    "validate_force_join",
]
