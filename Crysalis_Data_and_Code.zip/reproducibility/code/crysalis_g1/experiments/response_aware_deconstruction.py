from __future__ import annotations

import hashlib
import math
import time
from collections import defaultdict
from typing import Any, Mapping, Sequence

import numpy as np
from pymatgen.core import Structure


SELECTION_SEED = 20260901
MINIMUM_CELL_VECTOR_ANGSTROM = 8.0
MAXIMUM_SUPERCELL_ATOMS = 128
PAIR_SEARCH_RADIUS_ANGSTROM = 6.0
PAIR_CUTOFF_SCALE = 1.25
PAIR_CUTOFF_MAX_ANGSTROM = 4.5
PROBE_COUNT = 24
PROBE_RADIUS_ANGSTROM = 0.75
LOCAL_RELATION_RADIUS_ANGSTROM = 5.0
FINGERPRINT_RADIUS_ANGSTROM = 6.0
FINGERPRINT_BIN_COUNT = 24
SEVERE_CONTACT_ANGSTROM = 0.50
CATASTROPHIC_CONTACT_ANGSTROM = 0.35


class DeconstructionDeadline(RuntimeError):
    pass


def deterministic_parent_order(
    rows: Sequence[Mapping[str, object]], *, seed: int = SELECTION_SEED
) -> tuple[str, ...]:
    if not rows:
        raise ValueError("parent selection rows must not be empty")
    grouped: dict[tuple[object, ...], list[str]] = defaultdict(list)
    for row in rows:
        parent_id = str(row["parent_id"])
        grouped[
            (
                str(row["crystal_system"]),
                int(row["number_of_elements"]),
                int(row["atom_count"]),
                int(row["inequivalent_site_count"]),
            )
        ].append(parent_id)
    all_ids = [parent_id for values in grouped.values() for parent_id in values]
    if len(all_ids) != len(set(all_ids)):
        raise ValueError("parent IDs must be unique")
    priorities = []
    for stratum, parent_ids in grouped.items():
        ranked = sorted(
            parent_ids,
            key=lambda parent_id: (
                hashlib.sha256(f"{seed}:{parent_id}".encode("utf-8")).hexdigest(),
                parent_id,
            ),
        )
        for rank, parent_id in enumerate(ranked):
            digest = hashlib.sha256(
                f"{seed}:{parent_id}".encode("utf-8")
            ).hexdigest()
            priorities.append(
                ((rank + 0.5) / len(ranked), repr(stratum), digest, parent_id)
            )
    return tuple(item[-1] for item in sorted(priorities))


def choose_supercell_multiplier(
    lattice_lengths: Sequence[float],
    *,
    atom_count: int,
    minimum_vector: float = MINIMUM_CELL_VECTOR_ANGSTROM,
    maximum_atoms: int = MAXIMUM_SUPERCELL_ATOMS,
) -> tuple[int, int, int]:
    lengths = tuple(float(value) for value in lattice_lengths)
    if len(lengths) != 3 or any(value <= 0.0 for value in lengths):
        raise ValueError("lattice lengths must contain three positive values")
    if atom_count <= 0 or maximum_atoms < atom_count:
        raise ValueError("atom budget must accommodate the primitive structure")
    maximum_product = maximum_atoms // atom_count
    candidates = []
    for first in range(1, maximum_product + 1):
        for second in range(1, maximum_product // first + 1):
            for third in range(1, maximum_product // (first * second) + 1):
                product = first * second * third
                minimum_length = min(
                    lengths[0] * first,
                    lengths[1] * second,
                    lengths[2] * third,
                )
                candidates.append(
                    ((first, second, third), product, minimum_length)
                )
    satisfying = [
        item for item in candidates if item[2] >= minimum_vector - 1e-12
    ]
    if satisfying:
        return min(
            satisfying,
            key=lambda item: (item[1], -item[2], item[0]),
        )[0]
    return min(
        candidates,
        key=lambda item: (-item[1], -item[2], item[0]),
    )[0]


def parent_site_metadata(parent: Any) -> list[dict[str, object]]:
    atomic_numbers = tuple(int(value) for value in parent.reconstructed_atomic_numbers)
    coordinates = tuple(
        tuple(float(value) for value in coordinate)
        for coordinate in parent.reconstructed_fractional_coordinates
    )
    if len(atomic_numbers) != len(coordinates):
        raise ValueError("recovered parent species and coordinates differ in length")
    output = []
    site_index = 0
    for orbit in parent.orbits:
        for orbit_member_index in range(int(orbit.multiplicity)):
            if site_index >= len(atomic_numbers):
                raise ValueError("orbit multiplicities exceed reconstructed atom count")
            species = int(orbit.species)
            if atomic_numbers[site_index] != species:
                raise ValueError("recovered atom order differs from orbit order")
            output.append(
                {
                    "atom_identity": f"atom:{site_index}",
                    "parent_site_index": site_index,
                    "orbit_member_index": orbit_member_index,
                    "orbit_id": str(orbit.orbit_instance_id),
                    "wyckoff_id": str(orbit.wyckoff_position_id),
                    "wyckoff_letter": str(orbit.wyckoff_letter),
                    "species": species,
                    "parent_fractional_coordinate": list(coordinates[site_index]),
                }
            )
            site_index += 1
    if site_index != len(atomic_numbers):
        raise ValueError("orbit multiplicities do not cover reconstructed atoms")
    return output


def species_pair_cutoffs(
    structure: Structure,
    *,
    search_radius: float = PAIR_SEARCH_RADIUS_ANGSTROM,
    scale: float = PAIR_CUTOFF_SCALE,
    maximum_cutoff: float = PAIR_CUTOFF_MAX_ANGSTROM,
) -> dict[tuple[int, int], float]:
    if len(structure) < 2:
        return {}
    if search_radius <= 0.0 or scale <= 0.0 or maximum_cutoff <= 0.0:
        raise ValueError("pair-cutoff parameters must be positive")
    species = [int(site.specie.Z) for site in structure]
    distances = np.asarray(structure.distance_matrix, dtype=float)
    minimum: dict[tuple[int, int], float] = {}
    for left in range(len(structure)):
        for right in range(left + 1, len(structure)):
            distance = float(distances[left, right])
            if not 0.0 < distance <= search_radius:
                continue
            key = tuple(sorted((species[left], species[right])))
            minimum[key] = min(minimum.get(key, math.inf), distance)
    return {
        key: min(maximum_cutoff, scale * distance)
        for key, distance in minimum.items()
    }


def neighbor_graph(
    structure: Structure,
    cutoffs: Mapping[tuple[int, int], float],
) -> set[tuple[str, str]]:
    try:
        identities = [str(value) for value in structure.site_properties["atom_identity"]]
    except KeyError as error:
        raise ValueError("structure lacks stable atom_identity site properties") from error
    if len(identities) != len(set(identities)):
        raise ValueError("atom identities must be unique")
    species = [int(site.specie.Z) for site in structure]
    distances = np.asarray(structure.distance_matrix, dtype=float)
    edges = set()
    for left in range(len(structure)):
        for right in range(left + 1, len(structure)):
            key = tuple(sorted((species[left], species[right])))
            cutoff = cutoffs.get(key)
            if cutoff is not None and distances[left, right] <= float(cutoff) + 1e-10:
                edges.add(tuple(sorted((identities[left], identities[right]))))
    return edges


def _identity_species(structure: Structure) -> dict[str, int]:
    try:
        identities = [str(value) for value in structure.site_properties["atom_identity"]]
    except KeyError as error:
        raise ValueError("structure lacks stable atom_identity site properties") from error
    if len(identities) != len(set(identities)):
        raise ValueError("atom identities must be unique")
    return {
        identity: int(site.specie.Z)
        for identity, site in zip(identities, structure, strict=True)
    }


def _identity_fractional_coordinates(structure: Structure) -> dict[str, np.ndarray]:
    identities = [str(value) for value in structure.site_properties["atom_identity"]]
    if len(identities) != len(set(identities)):
        raise ValueError("atom identities must be unique")
    return {
        identity: np.asarray(coordinate, dtype=float)
        for identity, coordinate in zip(
            identities, structure.frac_coords, strict=True
        )
    }


def _identity_displacements(
    initial: Structure, observed: Structure
) -> dict[str, float]:
    left = _identity_fractional_coordinates(initial)
    right = _identity_fractional_coordinates(observed)
    if set(left) != set(right):
        raise ValueError("displacement structures have different atom identities")
    if not np.allclose(
        initial.lattice.matrix,
        observed.lattice.matrix,
        rtol=1e-10,
        atol=1e-10,
    ):
        raise ValueError("fixed-cell displacement structures have different lattices")
    lattice = np.asarray(initial.lattice.matrix, dtype=float)
    output = {}
    for identity in sorted(left):
        delta = right[identity] - left[identity]
        delta -= np.round(delta)
        output[identity] = float(np.linalg.norm(delta @ lattice))
    return output


def identity_displacement_summary(
    initial: Structure, observed: Structure
) -> dict[str, float]:
    values = np.asarray(
        list(_identity_displacements(initial, observed).values()), dtype=float
    )
    if not len(values):
        raise ValueError("displacement summary requires remaining atoms")
    return {
        "rms_displacement_angstrom": float(np.sqrt(np.mean(values**2))),
        "median_displacement_angstrom": float(np.median(values)),
        "p90_displacement_angstrom": float(np.quantile(values, 0.90)),
        "maximum_displacement_angstrom": float(np.max(values)),
    }


def graph_change_metrics(
    reference_edges: set[tuple[str, str]],
    observed_edges: set[tuple[str, str]],
) -> dict[str, float | int]:
    intersection = reference_edges & observed_edges
    union = reference_edges | observed_edges
    reference_n = len(reference_edges)
    return {
        "remaining_framework_edge_retention": len(intersection) / reference_n
        if reference_n
        else float(not observed_edges),
        "edge_deletion_rate": len(reference_edges - observed_edges) / reference_n
        if reference_n
        else 0.0,
        "edge_creation_rate": len(observed_edges - reference_edges)
        / max(reference_n, 1),
        "graph_jaccard_similarity": len(intersection) / len(union)
        if union
        else 1.0,
        "reference_edge_n": reference_n,
        "observed_edge_n": len(observed_edges),
    }


def _species_coordination(
    edges: set[tuple[str, str]], species_by_identity: Mapping[str, int]
) -> dict[str, dict[int, int]]:
    output: dict[str, dict[int, int]] = {
        identity: defaultdict(int) for identity in species_by_identity
    }
    for left, right in edges:
        output[left][int(species_by_identity[right])] += 1
        output[right][int(species_by_identity[left])] += 1
    return {identity: dict(values) for identity, values in output.items()}


def _coordination_response(
    *,
    parent_edges: set[tuple[str, str]],
    observed_edges: set[tuple[str, str]],
    parent_species: Mapping[str, int],
    observed_species: Mapping[str, int],
    removed_identity: str,
) -> tuple[float, float, dict[str, float]]:
    target = _species_coordination(parent_edges, parent_species)
    observed = _species_coordination(observed_edges, observed_species)
    per_identity = {}
    for identity in sorted(observed_species):
        channels = set(target[identity]) | set(observed[identity])
        per_identity[identity] = float(
            sum(
                abs(target[identity].get(channel, 0) - observed[identity].get(channel, 0))
                for channel in channels
            )
        )
    local_neighbors = {
        right if left == removed_identity else left
        for left, right in parent_edges
        if removed_identity in {left, right}
    }
    numerator = 0
    denominator = 0
    for identity in local_neighbors & set(observed_species):
        for channel, count in target[identity].items():
            denominator += count
            numerator += min(count, observed[identity].get(channel, 0))
    local_retention = numerator / denominator if denominator else 1.0
    average_l1 = float(np.mean(list(per_identity.values()))) if per_identity else 0.0
    return average_l1, local_retention, per_identity


def _normalized_histogram(values: Sequence[float], *, radius: float, bins: int) -> np.ndarray:
    histogram, _ = np.histogram(
        np.asarray(values, dtype=float), bins=bins, range=(0.0, radius)
    )
    histogram = histogram.astype(float)
    return histogram / histogram.sum() if histogram.sum() else histogram


def _distance_fingerprints(
    structure: Structure,
    *,
    radius: float = FINGERPRINT_RADIUS_ANGSTROM,
    bins: int = FINGERPRINT_BIN_COUNT,
) -> tuple[np.ndarray, dict[tuple[int, int], np.ndarray]]:
    species = [int(site.specie.Z) for site in structure]
    distances = np.asarray(structure.distance_matrix, dtype=float)
    all_values = []
    by_pair: dict[tuple[int, int], list[float]] = defaultdict(list)
    for left in range(len(structure)):
        for right in range(left + 1, len(structure)):
            distance = float(distances[left, right])
            if 0.0 < distance <= radius:
                all_values.append(distance)
                by_pair[tuple(sorted((species[left], species[right])))].append(distance)
    global_histogram = _normalized_histogram(all_values, radius=radius, bins=bins)
    pair_histograms = {
        key: _normalized_histogram(values, radius=radius, bins=bins)
        for key, values in by_pair.items()
    }
    return global_histogram, pair_histograms


def _histogram_l1(left: np.ndarray, right: np.ndarray) -> float:
    return float(np.abs(np.asarray(left) - np.asarray(right)).sum() / 2.0)


def _pair_fingerprint_l1(
    left: Mapping[tuple[int, int], np.ndarray],
    right: Mapping[tuple[int, int], np.ndarray],
) -> float:
    keys = sorted(set(left) | set(right))
    if not keys:
        return 0.0
    zero = np.zeros(FINGERPRINT_BIN_COUNT, dtype=float)
    return float(np.mean([_histogram_l1(left.get(key, zero), right.get(key, zero)) for key in keys]))


def _minimum_distance(structure: Structure) -> float | None:
    if len(structure) < 2:
        return None
    distances = np.asarray(structure.distance_matrix, dtype=float)
    np.fill_diagonal(distances, np.inf)
    value = float(np.min(distances))
    return value if math.isfinite(value) else None


def framework_response_metrics(
    *,
    parent_reference: Structure,
    damaged_reference: Structure,
    observed: Structure,
    removed_identity: str,
    removed_fractional_coordinate: Sequence[float],
    cutoffs: Mapping[tuple[int, int], float],
) -> dict[str, object]:
    displacement_by_id = _identity_displacements(damaged_reference, observed)
    displacement = identity_displacement_summary(damaged_reference, observed)
    parent_edges = neighbor_graph(parent_reference, cutoffs)
    reference_edges = {
        edge for edge in parent_edges if removed_identity not in edge
    }
    observed_edges = neighbor_graph(observed, cutoffs)
    graph = graph_change_metrics(reference_edges, observed_edges)
    parent_species = _identity_species(parent_reference)
    observed_species = _identity_species(observed)
    coordination_l1, local_retention, per_identity_l1 = _coordination_response(
        parent_edges=parent_edges,
        observed_edges=observed_edges,
        parent_species=parent_species,
        observed_species=observed_species,
        removed_identity=removed_identity,
    )
    reference_global, reference_pairs = _distance_fingerprints(damaged_reference)
    observed_global, observed_pairs = _distance_fingerprints(observed)
    removed_fractional = np.asarray(removed_fractional_coordinate, dtype=float)
    radial_distances = np.asarray(
        observed.lattice.get_all_distances(
            [removed_fractional], damaged_reference.frac_coords
        )[0],
        dtype=float,
    )
    identities = [
        str(value) for value in damaged_reference.site_properties["atom_identity"]
    ]
    shells = {}
    for label, lower, upper in (
        ("0_2", 0.0, 2.0),
        ("2_3.5", 2.0, 3.5),
        ("3.5_5", 3.5, 5.0),
        ("gt_5", 5.0, math.inf),
    ):
        values = [
            displacement_by_id[identity]
            for identity, distance in zip(identities, radial_distances, strict=True)
            if lower < distance <= upper or (lower == 0.0 and 0.0 <= distance <= upper)
        ]
        shells[label] = {
            "atom_n": len(values),
            "rms_displacement_angstrom": None
            if not values
            else float(np.sqrt(np.mean(np.asarray(values) ** 2))),
            "p90_displacement_angstrom": None
            if not values
            else float(np.quantile(values, 0.90)),
        }
    finite = bool(
        np.isfinite(observed.frac_coords).all()
        and np.isfinite(observed.lattice.matrix).all()
        and observed.lattice.volume > 0.0
    )
    return {
        **displacement,
        "radial_shell_displacement": shells,
        "average_coordination_l1_change": coordination_l1,
        "local_coordination_retention": local_retention,
        "per_identity_coordination_l1": per_identity_l1,
        **graph,
        "pair_distance_fingerprint_change": _pair_fingerprint_l1(
            reference_pairs, observed_pairs
        ),
        "radial_distribution_fingerprint_change": _histogram_l1(
            reference_global, observed_global
        ),
        "minimum_distance_angstrom": _minimum_distance(observed),
        "finite_geometry": finite,
        "remaining_atom_n": len(observed),
    }


def _relation_descriptor(
    framework: Structure,
    *,
    candidate_species: int,
    candidate_fractional_coordinate: Sequence[float],
    species_order: Sequence[int],
    cutoffs: Mapping[tuple[int, int], float],
) -> dict[str, object]:
    distances = np.asarray(
        framework.lattice.get_all_distances(
            [np.asarray(candidate_fractional_coordinate, dtype=float)],
            framework.frac_coords,
        )[0],
        dtype=float,
    )
    framework_species = np.asarray([int(site.specie.Z) for site in framework])
    histograms = {}
    coordination = {}
    minimum_by_species = {}
    for species in species_order:
        values = distances[framework_species == int(species)]
        histograms[str(species)] = _normalized_histogram(
            values[values <= LOCAL_RELATION_RADIUS_ANGSTROM],
            radius=LOCAL_RELATION_RADIUS_ANGSTROM,
            bins=FINGERPRINT_BIN_COUNT,
        ).tolist()
        minimum_by_species[str(species)] = (
            None if not len(values) else float(np.min(values))
        )
        cutoff = cutoffs.get(tuple(sorted((int(candidate_species), int(species)))))
        coordination[str(species)] = int(np.sum(values <= cutoff)) if cutoff else 0
    radial = _normalized_histogram(
        distances[distances <= LOCAL_RELATION_RADIUS_ANGSTROM],
        radius=LOCAL_RELATION_RADIUS_ANGSTROM,
        bins=FINGERPRINT_BIN_COUNT,
    )
    return {
        "species_distance_histograms": histograms,
        "coordination_counts": coordination,
        "radial_histogram": radial.tolist(),
        "minimum_distance_by_species": minimum_by_species,
    }


def target_local_relation(
    parent_reference: Structure,
    removed_identity: str,
    cutoffs: Mapping[tuple[int, int], float],
) -> dict[str, object]:
    identities = [
        str(value) for value in parent_reference.site_properties["atom_identity"]
    ]
    if removed_identity not in identities:
        raise ValueError("removed atom identity is absent from parent reference")
    index = identities.index(removed_identity)
    selected_species = int(parent_reference[index].specie.Z)
    selected_fractional = np.asarray(parent_reference[index].frac_coords, dtype=float)
    framework = parent_reference.copy()
    framework.remove_sites([index])
    species_order = sorted({int(site.specie.Z) for site in framework})
    descriptor = _relation_descriptor(
        framework,
        candidate_species=selected_species,
        candidate_fractional_coordinate=selected_fractional,
        species_order=species_order,
        cutoffs=cutoffs,
    )
    return {
        "selected_species": selected_species,
        "species_order": species_order,
        **descriptor,
    }


def compatibility_score(
    framework: Structure,
    *,
    candidate_species: int,
    candidate_fractional_coordinate: Sequence[float],
    target_relation: Mapping[str, object],
    cutoffs: Mapping[tuple[int, int], float],
) -> dict[str, float]:
    if int(target_relation["selected_species"]) != int(candidate_species):
        raise ValueError("candidate species differs from target relation")
    species_order = [int(value) for value in target_relation["species_order"]]
    candidate = _relation_descriptor(
        framework,
        candidate_species=int(candidate_species),
        candidate_fractional_coordinate=candidate_fractional_coordinate,
        species_order=species_order,
        cutoffs=cutoffs,
    )
    species_distances = []
    for species in species_order:
        target_histogram = np.asarray(
            target_relation["species_distance_histograms"][str(species)], dtype=float
        )
        candidate_histogram = np.asarray(
            candidate["species_distance_histograms"][str(species)], dtype=float
        )
        species_distances.append(_histogram_l1(target_histogram, candidate_histogram))
    species_distance = float(np.mean(species_distances)) if species_distances else 0.0
    target_coordination = target_relation["coordination_counts"]
    candidate_coordination = candidate["coordination_counts"]
    coordination_l1 = sum(
        abs(int(target_coordination[str(species)]) - int(candidate_coordination[str(species)]))
        for species in species_order
    )
    coordination_scale = max(
        sum(int(target_coordination[str(species)]) for species in species_order),
        sum(int(candidate_coordination[str(species)]) for species in species_order),
        1,
    )
    coordination_distance = min(1.0, coordination_l1 / coordination_scale)
    radial_distance = _histogram_l1(
        np.asarray(target_relation["radial_histogram"], dtype=float),
        np.asarray(candidate["radial_histogram"], dtype=float),
    )
    relation_distance = float(
        np.mean((species_distance, coordination_distance, radial_distance))
    )
    contact_residual = 0.0
    for species in species_order:
        observed_minimum = candidate["minimum_distance_by_species"][str(species)]
        if observed_minimum is None:
            continue
        target_minimum = target_relation["minimum_distance_by_species"][str(species)]
        if target_minimum is None:
            cutoff = cutoffs.get(tuple(sorted((int(candidate_species), species))))
            target_minimum = None if cutoff is None else float(cutoff) / PAIR_CUTOFF_SCALE
        if target_minimum is None or float(target_minimum) <= 0.0:
            continue
        safe_distance = 0.65 * float(target_minimum)
        contact_residual = max(
            contact_residual,
            float(
                np.clip(
                    (safe_distance - float(observed_minimum)) / safe_distance,
                    0.0,
                    1.0,
                )
            ),
        )
    return {
        "species_distance_fingerprint_distance": species_distance,
        "coordination_fingerprint_distance": float(coordination_distance),
        "radial_environment_distance": radial_distance,
        "relation_distance": relation_distance,
        "contact_residual": contact_residual,
        "compatibility_energy": relation_distance + contact_residual,
    }


def classify_response(metrics: Mapping[str, object]) -> str:
    if bool(metrics.get("mlip_failed")) or not bool(metrics.get("finite_geometry")):
        return "COLLAPSE"
    minimum_distance = metrics.get("minimum_distance_angstrom")
    edge_retention = metrics.get("remaining_framework_edge_retention")
    displacement_p90 = metrics.get("p90_displacement_angstrom")
    if minimum_distance is None or edge_retention is None or displacement_p90 is None:
        return "COLLAPSE"
    if (
        float(edge_retention) <= 0.50
        or float(displacement_p90) >= 1.50
        or float(minimum_distance) < CATASTROPHIC_CONTACT_ANGSTROM
    ):
        return "COLLAPSE"
    if (
        bool(metrics.get("converged"))
        and float(minimum_distance) >= SEVERE_CONTACT_ANGSTROM
        and float(edge_retention) >= 0.80
        and float(displacement_p90) <= 0.75
    ):
        return "SURVIVE"
    return "INTERMEDIATE"


def is_severe_intermediate(metrics: Mapping[str, object]) -> bool:
    return bool(
        metrics.get("response_label") == "INTERMEDIATE"
        and (
            float(metrics["remaining_framework_edge_retention"]) < 0.65
            or float(metrics["p90_displacement_angstrom"]) >= 1.0
            or float(metrics["minimum_distance_angstrom"]) < SEVERE_CONTACT_ANGSTROM
        )
    )


def reverse_reconstruction_metrics(
    *,
    parent_reference: Structure,
    reconstructed: Structure,
    cutoffs: Mapping[tuple[int, int], float],
) -> dict[str, object]:
    displacement = identity_displacement_summary(parent_reference, reconstructed)
    parent_graph = neighbor_graph(parent_reference, cutoffs)
    reconstructed_graph = neighbor_graph(reconstructed, cutoffs)
    graph = graph_change_metrics(parent_graph, reconstructed_graph)
    return {
        "reconstruction_rmsd_angstrom": displacement[
            "rms_displacement_angstrom"
        ],
        "reconstruction_p90_angstrom": displacement[
            "p90_displacement_angstrom"
        ],
        "neighbor_relation_recovery": graph[
            "remaining_framework_edge_retention"
        ],
        "reverse_graph_jaccard": graph["graph_jaccard_similarity"],
        "minimum_distance_angstrom": _minimum_distance(reconstructed),
        "finite_geometry": bool(
            np.isfinite(reconstructed.frac_coords).all()
            and np.isfinite(reconstructed.lattice.matrix).all()
            and reconstructed.lattice.volume > 0.0
        ),
    }


def _bootstrap_seed(label: str) -> int:
    return int(hashlib.sha256(label.encode("utf-8")).hexdigest()[:8], 16)


def _parent_bootstrap_mean(
    rows: Sequence[tuple[str, float]],
    *,
    label: str,
    replicates: int,
) -> dict[str, float]:
    if not rows:
        raise ValueError("parent bootstrap requires observations")
    by_parent: dict[str, list[float]] = defaultdict(list)
    for parent_id, value in rows:
        if not math.isfinite(float(value)):
            raise ValueError("bootstrap observations must be finite")
        by_parent[str(parent_id)].append(float(value))
    parent_ids = sorted(by_parent)
    point = float(np.mean([value for values in by_parent.values() for value in values]))
    rng = np.random.default_rng(_bootstrap_seed(label))
    estimates = np.empty(replicates, dtype=float)
    for index in range(replicates):
        selected = rng.integers(0, len(parent_ids), size=len(parent_ids))
        sample = [
            value
            for parent_index in selected
            for value in by_parent[parent_ids[int(parent_index)]]
        ]
        estimates[index] = float(np.mean(sample))
    return {
        "point": point,
        "ci95_lower": float(np.quantile(estimates, 0.025)),
        "ci95_upper": float(np.quantile(estimates, 0.975)),
    }


def _two_group_parent_bootstrap_difference(
    left: Sequence[tuple[str, float]],
    right: Sequence[tuple[str, float]],
    *,
    label: str,
    replicates: int,
) -> dict[str, float]:
    if not left or not right:
        raise ValueError("two-group bootstrap requires both groups")
    left_by_parent: dict[str, list[float]] = defaultdict(list)
    right_by_parent: dict[str, list[float]] = defaultdict(list)
    for parent_id, value in left:
        left_by_parent[str(parent_id)].append(float(value))
    for parent_id, value in right:
        right_by_parent[str(parent_id)].append(float(value))
    left_ids = sorted(left_by_parent)
    right_ids = sorted(right_by_parent)
    point = float(
        np.mean([value for values in left_by_parent.values() for value in values])
        - np.mean([value for values in right_by_parent.values() for value in values])
    )
    rng = np.random.default_rng(_bootstrap_seed(label))
    estimates = np.empty(replicates, dtype=float)
    for index in range(replicates):
        left_selected = rng.integers(0, len(left_ids), size=len(left_ids))
        right_selected = rng.integers(0, len(right_ids), size=len(right_ids))
        left_sample = [
            value
            for parent_index in left_selected
            for value in left_by_parent[left_ids[int(parent_index)]]
        ]
        right_sample = [
            value
            for parent_index in right_selected
            for value in right_by_parent[right_ids[int(parent_index)]]
        ]
        estimates[index] = float(np.mean(left_sample) - np.mean(right_sample))
    return {
        "point": point,
        "ci95_lower": float(np.quantile(estimates, 0.025)),
        "ci95_upper": float(np.quantile(estimates, 0.975)),
    }


def analyze_framework_response(
    rows: Sequence[Mapping[str, object]], *, replicates: int = 10_000
) -> dict[str, object]:
    lookup: dict[tuple[str, str], Mapping[str, object]] = {}
    for row in rows:
        key = (str(row["event_id"]), str(row["arm"]))
        if key in lookup:
            raise ValueError(f"duplicate framework response row: {key}")
        lookup[key] = row
    per_arm = {}
    supporting_arm = None
    for arm in ("LOCAL_RESPONSE", "GLOBAL_RESPONSE"):
        event_ids = sorted(
            event_id
            for event_id, observed_arm in lookup
            if observed_arm == arm and (event_id, "STATIC") in lookup
        )
        if not event_ids:
            per_arm[arm] = {
                "event_n": 0,
                "systematic_metric_n": 0,
                "heterogeneity": False,
                "metrics": {},
            }
            continue
        definitions = (
            (
                "p90_displacement_increase",
                "p90_displacement_angstrom",
                0.05,
                1.0,
            ),
            (
                "graph_jaccard_change",
                "graph_jaccard_similarity",
                0.02,
                -1.0,
            ),
            (
                "coordination_l1_change",
                "average_coordination_l1_change",
                0.05,
                1.0,
            ),
            (
                "radial_fingerprint_change",
                "radial_distribution_fingerprint_change",
                0.02,
                1.0,
            ),
        )
        metric_results = {}
        systematic_count = 0
        for metric_name, field, minimum, sign in definitions:
            deltas = []
            for event_id in event_ids:
                response = lookup[(event_id, arm)]
                static = lookup[(event_id, "STATIC")]
                delta = sign * (float(response[field]) - float(static[field]))
                deltas.append((str(response["parent_id"]), delta))
            bootstrap = _parent_bootstrap_mean(
                deltas,
                label=f"framework:{arm}:{metric_name}",
                replicates=replicates,
            )
            if metric_name in {
                "coordination_l1_change",
                "radial_fingerprint_change",
            }:
                supported = bool(
                    abs(bootstrap["point"]) >= minimum
                    and (
                        bootstrap["ci95_lower"] > 0.0
                        or bootstrap["ci95_upper"] < 0.0
                    )
                )
            else:
                supported = bool(
                    bootstrap["point"] >= minimum
                    and bootstrap["ci95_lower"] > 0.0
                )
            metric_results[metric_name] = {
                **bootstrap,
                "minimum_systematic_magnitude": minimum,
                "supported": supported,
            }
            systematic_count += int(supported)
        response_rows = [lookup[(event_id, arm)] for event_id in event_ids]
        displacement_values = np.asarray(
            [float(row["p90_displacement_angstrom"]) for row in response_rows]
        )
        retention_values = np.asarray(
            [float(row["remaining_framework_edge_retention"]) for row in response_rows]
        )
        displacement_iqr = float(
            np.quantile(displacement_values, 0.75)
            - np.quantile(displacement_values, 0.25)
        )
        retention_iqr = float(
            np.quantile(retention_values, 0.75)
            - np.quantile(retention_values, 0.25)
        )
        heterogeneity_values = (
            displacement_values if displacement_iqr >= 0.10 else retention_values
        )
        heterogeneity_threshold_met = bool(
            displacement_iqr >= 0.10 or retention_iqr >= 0.10
        )
        median = float(np.median(heterogeneity_values))
        lower_parents = {
            str(row["parent_id"])
            for row, value in zip(response_rows, heterogeneity_values, strict=True)
            if float(value) <= median
        }
        upper_parents = {
            str(row["parent_id"])
            for row, value in zip(response_rows, heterogeneity_values, strict=True)
            if float(value) >= median
        }
        heterogeneity = bool(
            heterogeneity_threshold_met
            and len(lower_parents) >= 4
            and len(upper_parents) >= 4
        )
        per_arm[arm] = {
            "event_n": len(event_ids),
            "systematic_metric_n": systematic_count,
            "heterogeneity": heterogeneity,
            "displacement_p90_iqr_angstrom": displacement_iqr,
            "graph_retention_iqr": retention_iqr,
            "heterogeneity_lower_parent_n": len(lower_parents),
            "heterogeneity_upper_parent_n": len(upper_parents),
            "metrics": metric_results,
        }
        if systematic_count >= 2 and heterogeneity and supporting_arm is None:
            supporting_arm = arm
    return {
        "FRAMEWORK_RESPONSE_SIGNAL": "SUPPORTED"
        if supporting_arm is not None
        else "NOT_SUPPORTED",
        "supporting_arm": supporting_arm,
        "per_arm": per_arm,
    }


def analyze_outcome_diversity(
    rows: Sequence[Mapping[str, object]],
) -> dict[str, object]:
    survive = [row for row in rows if row["response_label"] == "SURVIVE"]
    collapse = [row for row in rows if row["response_label"] == "COLLAPSE"]
    severe_intermediate = [
        row
        for row in rows
        if row["response_label"] == "INTERMEDIATE"
        and bool(row.get("severe_intermediate"))
    ]
    survive_parents = {str(row["parent_id"]) for row in survive}
    severe_parents = {
        str(row["parent_id"]) for row in collapse + severe_intermediate
    }
    supported = len(survive_parents) >= 2 and len(severe_parents) >= 2
    return {
        "DECONSTRUCTION_OUTCOME_DIVERSITY": "SUPPORTED"
        if supported
        else "NOT_SUPPORTED",
        "survive_event_n": len(survive),
        "collapse_event_n": len(collapse),
        "severe_intermediate_event_n": len(severe_intermediate),
        "survive_parent_n": len(survive_parents),
        "severe_parent_n": len(severe_parents),
    }


def analyze_compatibility(
    probe_rows: Sequence[Mapping[str, object]],
    reverse_rows: Sequence[Mapping[str, object]],
    *,
    replicates: int = 10_000,
) -> dict[str, object]:
    original: dict[tuple[str, str], Mapping[str, object]] = {}
    for row in probe_rows:
        if not bool(row["is_original_parent_coordinate"]):
            continue
        key = (str(row["event_id"]), str(row["arm"]))
        if key in original:
            raise ValueError(f"duplicate original compatibility probe: {key}")
        original[key] = row
    rates = {}
    for arm in ("STATIC", "LOCAL_RESPONSE", "GLOBAL_RESPONSE"):
        arm_rows = [row for (event_id, row_arm), row in original.items() if row_arm == arm]
        rates[arm] = (
            None
            if not arm_rows
            else float(np.mean([int(row["compatibility_rank"]) <= 3 for row in arm_rows]))
        )
    support_basis = None
    top3_comparisons = {}
    for arm in ("LOCAL_RESPONSE", "GLOBAL_RESPONSE"):
        event_ids = sorted(
            event_id
            for event_id, observed_arm in original
            if observed_arm == arm and (event_id, "STATIC") in original
        )
        if not event_ids:
            top3_comparisons[arm] = None
            continue
        deltas = [
            (
                str(original[(event_id, arm)]["parent_id"]),
                float(int(original[(event_id, arm)]["compatibility_rank"]) <= 3)
                - float(int(original[(event_id, "STATIC")]["compatibility_rank"]) <= 3),
            )
            for event_id in event_ids
        ]
        bootstrap = _parent_bootstrap_mean(
            deltas,
            label=f"compatibility:{arm}:top3",
            replicates=replicates,
        )
        top3_comparisons[arm] = bootstrap
        if (
            support_basis is None
            and bootstrap["point"] >= 0.10
            and bootstrap["ci95_lower"] > 0.0
        ):
            support_basis = f"{arm}_TOP3_IMPROVEMENT"
    secondary = {}
    best_rows = [
        row
        for row in probe_rows
        if row["arm"] in {"LOCAL_RESPONSE", "GLOBAL_RESPONSE"}
        and int(row["compatibility_rank"]) == 1
        and not bool(row["is_original_parent_coordinate"])
        and float(row["candidate_distance_to_parent_angstrom"]) <= PROBE_RADIUS_ANGSTROM
    ]
    reverse_lookup = {
        (str(row["event_id"]), str(row["arm"]), str(row["candidate_role"])): row
        for row in reverse_rows
    }
    for arm in ("LOCAL_RESPONSE", "GLOBAL_RESPONSE"):
        arm_best = [row for row in best_rows if row["arm"] == arm]
        parent_n = len({str(row["parent_id"]) for row in arm_best})
        paired = []
        for row in arm_best:
            key = (str(row["event_id"]), arm)
            good = reverse_lookup.get((*key, "GOOD"))
            bad = reverse_lookup.get((*key, "BAD"))
            if good is not None and bad is not None:
                paired.append((row, good, bad))
        finite_good = [bool(good["finite_after_reverse"]) for _, good, _ in paired]
        finite_bad = [bool(bad["finite_after_reverse"]) for _, _, bad in paired]
        force_pairs = [
            (
                str(row["parent_id"]),
                math.log1p(float(good["final_max_force_movable_ev_per_angstrom"]))
                - math.log1p(float(bad["final_max_force_movable_ev_per_angstrom"])),
            )
            for row, good, bad in paired
            if bool(good["finite_after_reverse"])
            and bool(bad["finite_after_reverse"])
            and good["final_max_force_movable_ev_per_angstrom"] is not None
            and bad["final_max_force_movable_ev_per_angstrom"] is not None
        ]
        recovery_pairs = [
            (
                str(row["parent_id"]),
                float(good["neighbor_relation_recovery"])
                - float(bad["neighbor_relation_recovery"]),
            )
            for row, good, bad in paired
            if good["neighbor_relation_recovery"] is not None
            and bad["neighbor_relation_recovery"] is not None
        ]
        force = (
            _parent_bootstrap_mean(
                force_pairs,
                label=f"compatibility:{arm}:reverse_force",
                replicates=replicates,
            )
            if force_pairs
            else None
        )
        recovery = (
            _parent_bootstrap_mean(
                recovery_pairs,
                label=f"compatibility:{arm}:reverse_recovery",
                replicates=replicates,
            )
            if recovery_pairs
            else None
        )
        good_finite_rate = float(np.mean(finite_good)) if finite_good else None
        bad_finite_rate = float(np.mean(finite_bad)) if finite_bad else None
        secondary_supported = bool(
            len(arm_best) >= 12
            and parent_n >= 4
            and force is not None
            and force["ci95_upper"] < 0.0
            and recovery is not None
            and recovery["point"] >= 0.05
            and recovery["ci95_lower"] > 0.0
            and good_finite_rate is not None
            and bad_finite_rate is not None
            and good_finite_rate >= bad_finite_rate
        )
        secondary[arm] = {
            "new_basin_event_n": len(arm_best),
            "new_basin_parent_n": parent_n,
            "paired_reverse_n": len(paired),
            "good_finite_rate": good_finite_rate,
            "bad_finite_rate": bad_finite_rate,
            "good_minus_bad_log1p_force": force,
            "good_minus_bad_relation_recovery": recovery,
            "supported": secondary_supported,
        }
        if support_basis is None and secondary_supported:
            support_basis = f"{arm}_NEW_BASIN_REVERSE_SANITY"
    return {
        "STATIC_COMPAT_TOP3_RATE": rates["STATIC"],
        "LOCAL_RESPONSE_COMPAT_TOP3_RATE": rates["LOCAL_RESPONSE"],
        "GLOBAL_RESPONSE_COMPAT_TOP3_RATE": rates["GLOBAL_RESPONSE"],
        "ASSEMBLY_COMPATIBILITY_SIGNAL": "SUPPORTED"
        if support_basis is not None
        else "NOT_SUPPORTED",
        "support_basis": support_basis,
        "top3_comparisons": top3_comparisons,
        "secondary_new_basin": secondary,
    }


def analyze_negative_supervision(
    response_rows: Sequence[Mapping[str, object]],
    reverse_rows: Sequence[Mapping[str, object]],
    *,
    replicates: int = 10_000,
    minimum_events: int = 8,
    minimum_parents: int = 3,
) -> dict[str, object]:
    response_lookup = {
        (str(row["event_id"]), str(row["arm"])): row
        for row in response_rows
        if row["arm"] in {"LOCAL_RESPONSE", "GLOBAL_RESPONSE"}
    }
    joined = []
    for reverse in reverse_rows:
        if reverse["candidate_role"] != "GOOD":
            continue
        key = (str(reverse["event_id"]), str(reverse["arm"]))
        response = response_lookup.get(key)
        if response is None:
            continue
        severe = bool(
            response["response_label"] == "COLLAPSE"
            or (
                response["response_label"] == "INTERMEDIATE"
                and bool(response.get("severe_intermediate"))
            )
        )
        survive = response["response_label"] == "SURVIVE"
        if severe or survive:
            joined.append((response, reverse, "severe" if severe else "survive"))
    severe_rows = [item for item in joined if item[2] == "severe"]
    survive_rows = [item for item in joined if item[2] == "survive"]
    severe_parents = {str(item[0]["parent_id"]) for item in severe_rows}
    survive_parents = {str(item[0]["parent_id"]) for item in survive_rows}
    sufficient = bool(
        len(severe_rows) >= minimum_events
        and len(survive_rows) >= minimum_events
        and len(severe_parents) >= minimum_parents
        and len(survive_parents) >= minimum_parents
    )
    base = {
        "severe_event_n": len(severe_rows),
        "survive_event_n": len(survive_rows),
        "severe_parent_n": len(severe_parents),
        "survive_parent_n": len(survive_parents),
    }
    if not sufficient:
        return {
            **base,
            "NEGATIVE_ASSEMBLY_SUPERVISION_SIGNAL": "UNRESOLVED",
            "reverse_failure_rate_difference": None,
            "force_log1p_difference": None,
            "force_ci95_lower": None,
            "force_ci95_upper": None,
            "relation_recovery_difference": None,
            "relation_ci95_lower": None,
            "relation_ci95_upper": None,
        }
    severe_failure = float(
        np.mean([not bool(item[1]["finite_after_reverse"]) for item in severe_rows])
    )
    survive_failure = float(
        np.mean([not bool(item[1]["finite_after_reverse"]) for item in survive_rows])
    )
    failure_difference = severe_failure - survive_failure
    severe_force = [
        (
            str(response["parent_id"]),
            math.log1p(float(reverse["final_max_force_movable_ev_per_angstrom"])),
        )
        for response, reverse, _ in severe_rows
        if bool(reverse["finite_after_reverse"])
        and reverse["final_max_force_movable_ev_per_angstrom"] is not None
    ]
    survive_force = [
        (
            str(response["parent_id"]),
            math.log1p(float(reverse["final_max_force_movable_ev_per_angstrom"])),
        )
        for response, reverse, _ in survive_rows
        if bool(reverse["finite_after_reverse"])
        and reverse["final_max_force_movable_ev_per_angstrom"] is not None
    ]
    force = (
        _two_group_parent_bootstrap_difference(
            severe_force,
            survive_force,
            label="negative_supervision:force",
            replicates=replicates,
        )
        if severe_force and survive_force
        else None
    )
    severe_recovery = [
        (str(response["parent_id"]), float(reverse["neighbor_relation_recovery"]))
        for response, reverse, _ in severe_rows
        if reverse["neighbor_relation_recovery"] is not None
    ]
    survive_recovery = [
        (str(response["parent_id"]), float(reverse["neighbor_relation_recovery"]))
        for response, reverse, _ in survive_rows
        if reverse["neighbor_relation_recovery"] is not None
    ]
    recovery = (
        _two_group_parent_bootstrap_difference(
            severe_recovery,
            survive_recovery,
            label="negative_supervision:recovery",
            replicates=replicates,
        )
        if severe_recovery and survive_recovery
        else None
    )
    supported = bool(
        failure_difference >= 0.20
        or (
            force is not None
            and force["point"] >= 0.20
            and force["ci95_lower"] > 0.0
        )
        or (
            recovery is not None
            and recovery["point"] <= -0.10
            and recovery["ci95_upper"] < 0.0
        )
    )
    return {
        **base,
        "NEGATIVE_ASSEMBLY_SUPERVISION_SIGNAL": "SUPPORTED"
        if supported
        else "NOT_SUPPORTED",
        "reverse_failure_rate_difference": failure_difference,
        "force_log1p_difference": None if force is None else force["point"],
        "force_ci95_lower": None if force is None else force["ci95_lower"],
        "force_ci95_upper": None if force is None else force["ci95_upper"],
        "relation_recovery_difference": None
        if recovery is None
        else recovery["point"],
        "relation_ci95_lower": None
        if recovery is None
        else recovery["ci95_lower"],
        "relation_ci95_upper": None
        if recovery is None
        else recovery["ci95_upper"],
    }


def response_aware_verdict(
    *,
    framework_response_signal: str,
    outcome_diversity: str,
    assembly_compatibility_signal: str,
    negative_assembly_supervision_signal: str,
) -> tuple[str, str]:
    if framework_response_signal != "SUPPORTED":
        return "NOT_SUPPORTED", "STOP_RESPONSE_AWARE_REDEVELOPMENT"
    if outcome_diversity == "SUPPORTED" and (
        assembly_compatibility_signal == "SUPPORTED"
        or negative_assembly_supervision_signal == "SUPPORTED"
    ):
        return "SUPPORTED", "DESIGN_RESPONSE_AWARE_CRYSALIS_V3"
    return "RESPONSE_ONLY", "REDEFINE_ASSEMBLY_INFORMATION_EXTRACTION"


def safe_fixed_cell_relaxation_once(
    structure: Structure,
    *,
    calculator: Any,
    movable_indices: Sequence[int],
    fmax: float,
    maximum_steps: int,
    deadline: float | None = None,
) -> dict[str, object]:
    from ase.constraints import FixAtoms
    from ase.optimize import FIRE
    from pymatgen.io.ase import AseAtomsAdaptor

    if fmax <= 0.0 or maximum_steps <= 0:
        raise ValueError("FIRE force target and step budget must be positive")
    movable = tuple(sorted({int(index) for index in movable_indices}))
    if any(index < 0 or index >= len(structure) for index in movable):
        raise ValueError("movable atom index is out of range")
    atoms = AseAtomsAdaptor.get_atoms(structure)
    atoms.calc = calculator
    fixed = sorted(set(range(len(atoms))) - set(movable))
    if fixed:
        atoms.set_constraint(FixAtoms(indices=fixed))
    started_lattice = np.asarray(structure.lattice.matrix, dtype=float)
    try:
        initial_forces = np.asarray(
            atoms.get_forces(apply_constraint=False), dtype=float
        )
        initial_energy = float(atoms.get_potential_energy())
        optimizer = FIRE(atoms, logfile=None)
        if deadline is not None:
            def enforce_deadline() -> None:
                if time.monotonic() >= deadline:
                    raise DeconstructionDeadline(
                        "fixed-cell FIRE exceeded the total wall-clock deadline"
                    )

            optimizer.attach(enforce_deadline, interval=1)
        optimizer_converged = bool(optimizer.run(fmax=fmax, steps=maximum_steps))
        final_forces = np.asarray(
            atoms.get_forces(apply_constraint=False), dtype=float
        )
        final_energy = float(atoms.get_potential_energy())
        converted = AseAtomsAdaptor.get_structure(atoms)
        final_structure = Structure(
            structure.lattice,
            [int(site.specie.Z) for site in structure],
            np.asarray(converted.frac_coords, dtype=float),
            to_unit_cell=True,
            site_properties={
                key: list(values) for key, values in structure.site_properties.items()
            },
        )
        if not np.allclose(
            final_structure.lattice.matrix,
            started_lattice,
            rtol=1e-12,
            atol=1e-12,
        ):
            raise RuntimeError("fixed-cell FIRE changed the lattice")
        initial_norm = np.linalg.norm(initial_forces, axis=1)
        final_norm = np.linalg.norm(final_forces, axis=1)
        movable_norm = final_norm[np.asarray(movable, dtype=int)] if movable else np.zeros(1)
        converged = bool(
            optimizer_converged and float(np.max(movable_norm)) <= fmax
        )
        return {
            "status": "EVALUATED",
            "mlip_failed": False,
            "retry_count": 0,
            "converged": converged,
            "relaxation_steps": int(optimizer.nsteps),
            "movable_atom_n": len(movable),
            "fixed_atom_n": len(fixed),
            "initial_max_force_all_ev_per_angstrom": float(np.max(initial_norm)),
            "initial_mean_force_all_ev_per_angstrom": float(np.mean(initial_norm)),
            "final_max_force_all_ev_per_angstrom": float(np.max(final_norm)),
            "final_mean_force_all_ev_per_angstrom": float(np.mean(final_norm)),
            "final_max_force_movable_ev_per_angstrom": float(np.max(movable_norm)),
            "initial_energy_ev": initial_energy,
            "final_energy_ev": final_energy,
            "energy_change_ev": final_energy - initial_energy,
            "final_structure": final_structure,
        }
    except Exception as error:
        if (
            isinstance(error, (MemoryError, DeconstructionDeadline))
            or "out of memory" in str(error).lower()
        ):
            raise
        return {
            "status": "MLIP_RELAXATION_FAILED",
            "mlip_failed": True,
            "retry_count": 0,
            "converged": False,
            "relaxation_steps": 0,
            "movable_atom_n": len(movable),
            "fixed_atom_n": len(fixed),
            "initial_max_force_all_ev_per_angstrom": None,
            "initial_mean_force_all_ev_per_angstrom": None,
            "final_max_force_all_ev_per_angstrom": None,
            "final_mean_force_all_ev_per_angstrom": None,
            "final_max_force_movable_ev_per_angstrom": None,
            "initial_energy_ev": None,
            "final_energy_ev": None,
            "energy_change_ev": None,
            "exception_type": type(error).__name__,
            "exception_message": str(error),
            "final_structure": structure.copy(),
        }


def choose_parent_prefix_from_eta(
    *,
    startup_minutes: float,
    first_eight_event_minutes: float,
    event_counts: Mapping[int, int],
    aggregation_minutes: float = 2.0,
    maximum_minutes: float = 45.0,
) -> tuple[int | None, dict[int, float]]:
    if startup_minutes < 0.0 or first_eight_event_minutes <= 0.0:
        raise ValueError("ETA timing observations must be positive")
    if set(event_counts) != {48, 32, 24}:
        raise ValueError("ETA gate requires the preregistered 48/32/24 prefixes")
    if any(int(count) < 8 for count in event_counts.values()):
        raise ValueError("each parent prefix must contain at least eight events")
    per_event_minutes = first_eight_event_minutes / 8.0
    projections = {
        parent_n: float(
            startup_minutes
            + per_event_minutes * int(event_counts[parent_n])
            + aggregation_minutes
        )
        for parent_n in (48, 32, 24)
    }
    selected = next(
        (
            parent_n
            for parent_n in (48, 32, 24)
            if projections[parent_n] <= maximum_minutes
        ),
        None,
    )
    return selected, projections


def select_deconstruction_sites(
    metadata: Sequence[Mapping[str, object]],
    graph: set[tuple[str, str]],
) -> list[dict[str, object]]:
    if not metadata:
        raise ValueError("site selection requires parent metadata")
    degree = _identity_degrees(graph)
    representatives: dict[str, Mapping[str, object]] = {}
    for row in metadata:
        representatives.setdefault(str(row["orbit_id"]), row)
    ranked = [
        {
            **dict(row),
            "local_connectivity": int(degree.get(str(row["atom_identity"]), 0)),
        }
        for row in representatives.values()
    ]
    low = min(
        ranked,
        key=lambda row: (
            int(row["local_connectivity"]),
            str(row["orbit_id"]),
            int(row["parent_site_index"]),
        ),
    )
    selected = [{**low, "site_role": "SITE_A"}]
    if len(ranked) > 1:
        remaining = [row for row in ranked if row["orbit_id"] != low["orbit_id"]]
        high = min(
            remaining,
            key=lambda row: (
                -int(row["local_connectivity"]),
                str(row["orbit_id"]),
                int(row["parent_site_index"]),
            ),
        )
        selected.append({**high, "site_role": "SITE_B"})
    return selected


def _identity_degrees(edges: set[tuple[str, str]]) -> dict[str, int]:
    counts: dict[str, int] = defaultdict(int)
    for left, right in edges:
        counts[left] += 1
        counts[right] += 1
    return dict(counts)


def deterministic_probe_offsets(
    *, count: int = PROBE_COUNT, radius: float = PROBE_RADIUS_ANGSTROM
) -> np.ndarray:
    if count <= 0 or radius <= 0.0:
        raise ValueError("probe count and radius must be positive")
    golden_angle = math.pi * (3.0 - math.sqrt(5.0))
    output = []
    for index in range(count):
        z = 1.0 - 2.0 * (index + 0.5) / count
        radial_xy = math.sqrt(max(0.0, 1.0 - z * z))
        angle = golden_angle * index
        direction = np.asarray(
            [radial_xy * math.cos(angle), radial_xy * math.sin(angle), z],
            dtype=float,
        )
        shell_radius = radius * ((index + 0.5) / count) ** (1.0 / 3.0)
        output.append(direction * shell_radius)
    return np.asarray(output, dtype=float)


__all__ = [
    "DeconstructionDeadline",
    "analyze_compatibility",
    "analyze_framework_response",
    "analyze_negative_supervision",
    "analyze_outcome_diversity",
    "choose_supercell_multiplier",
    "choose_parent_prefix_from_eta",
    "classify_response",
    "compatibility_score",
    "deterministic_parent_order",
    "deterministic_probe_offsets",
    "framework_response_metrics",
    "graph_change_metrics",
    "identity_displacement_summary",
    "is_severe_intermediate",
    "neighbor_graph",
    "parent_site_metadata",
    "reverse_reconstruction_metrics",
    "response_aware_verdict",
    "safe_fixed_cell_relaxation_once",
    "select_deconstruction_sites",
    "species_pair_cutoffs",
    "target_local_relation",
]
