from __future__ import annotations

import json
import math
from collections import Counter, defaultdict
from collections.abc import Mapping, Sequence, Set
from pathlib import Path

import numpy as np
from pymatgen.core import Element, Lattice
from scipy.stats import spearmanr

from crysalis_g1.experiments.singleton_full_orbit_alignment import (
    fixed_cutoff_from_radii,
)

DEVELOPMENT_SPLITS = frozenset({"policy_train", "policy_validation"})

_GEOMETRY_INPUTS = (
    "current_partial_species",
    "current_partial_coordinates",
    "current_lattice",
    "candidate_species",
    "candidate_orbit_coordinates",
    "fixed_element_radii",
    "fixed_constants",
    "pbc",
)

FEATURE_SCHEMA: tuple[dict[str, object], ...] = (
    {
        "name": "candidate_framework_min_distance_min",
        "formula": "minimum over orbit atoms of their minimum PBC framework distance",
        "source_arrays": [
            "framework_fractional_coordinates",
            "candidate_fractional_coordinates",
        ],
        "allowed_inputs": list(_GEOMETRY_INPUTS),
    },
    {
        "name": "candidate_framework_min_distance_mean",
        "formula": "mean over orbit atoms of their minimum PBC framework distance",
        "source_arrays": [
            "framework_fractional_coordinates",
            "candidate_fractional_coordinates",
        ],
        "allowed_inputs": list(_GEOMETRY_INPUTS),
    },
    {
        "name": "candidate_framework_coordination_mean",
        "formula": "mean candidate-atom count of framework neighbours within c_fixed",
        "source_arrays": [
            "framework_atomic_numbers",
            "framework_fractional_coordinates",
            "candidate_fractional_coordinates",
        ],
        "allowed_inputs": list(_GEOMETRY_INPUTS),
    },
    {
        "name": "candidate_framework_coordination_min",
        "formula": "minimum candidate-atom count of framework neighbours within c_fixed",
        "source_arrays": [
            "framework_atomic_numbers",
            "framework_fractional_coordinates",
            "candidate_fractional_coordinates",
        ],
        "allowed_inputs": list(_GEOMETRY_INPUTS),
    },
    {
        "name": "candidate_framework_same_species_coordination_mean",
        "formula": "mean candidate-atom count of same-species framework neighbours within c_fixed",
        "source_arrays": [
            "framework_atomic_numbers",
            "framework_fractional_coordinates",
            "candidate_fractional_coordinates",
        ],
        "allowed_inputs": list(_GEOMETRY_INPUTS),
    },
    {
        "name": "candidate_neighbor_Z_mean",
        "formula": "mean atomic number across all coordinated candidate-framework edges",
        "source_arrays": [
            "framework_atomic_numbers",
            "framework_fractional_coordinates",
            "candidate_fractional_coordinates",
        ],
        "allowed_inputs": list(_GEOMETRY_INPUTS),
    },
    {
        "name": "candidate_neighbor_Z_std",
        "formula": "atomic-number standard deviation across coordinated candidate-framework edges",
        "source_arrays": [
            "framework_atomic_numbers",
            "framework_fractional_coordinates",
            "candidate_fractional_coordinates",
        ],
        "allowed_inputs": list(_GEOMETRY_INPUTS),
    },
    {
        "name": "candidate_coordinated_distance_mean",
        "formula": "mean PBC distance across coordinated candidate-framework edges",
        "source_arrays": [
            "framework_atomic_numbers",
            "framework_fractional_coordinates",
            "candidate_fractional_coordinates",
        ],
        "allowed_inputs": list(_GEOMETRY_INPUTS),
    },
    {
        "name": "orbit_internal_min_distance",
        "formula": "minimum PBC pair distance between distinct full-orbit atoms",
        "source_arrays": ["candidate_fractional_coordinates"],
        "allowed_inputs": list(_GEOMETRY_INPUTS),
    },
    {
        "name": "orbit_internal_pair_distance_mean",
        "formula": "mean PBC pair distance between distinct full-orbit atoms",
        "source_arrays": ["candidate_fractional_coordinates"],
        "allowed_inputs": list(_GEOMETRY_INPUTS),
    },
    {
        "name": "short_contact_residual_max",
        "formula": "maximum clip((safe_distance-distance)/safe_distance,0,1) over candidate-framework pairs",
        "source_arrays": [
            "framework_atomic_numbers",
            "framework_fractional_coordinates",
            "candidate_fractional_coordinates",
        ],
        "allowed_inputs": list(_GEOMETRY_INPUTS),
    },
    {
        "name": "short_contact_residual_mean",
        "formula": "mean over orbit atoms of each atom's maximum candidate-framework contact residual",
        "source_arrays": [
            "framework_atomic_numbers",
            "framework_fractional_coordinates",
            "candidate_fractional_coordinates",
        ],
        "allowed_inputs": list(_GEOMETRY_INPUTS),
    },
    {
        "name": "static_full_orbit_contact_score",
        "formula": "0.5*(short_contact_residual_max+short_contact_residual_mean)",
        "source_arrays": ["short_contact_residual_max", "short_contact_residual_mean"],
        "allowed_inputs": list(_GEOMETRY_INPUTS),
    },
    {
        "name": "multiplicity",
        "formula": "expanded full-orbit atom count",
        "source_arrays": ["candidate_fractional_coordinates"],
        "allowed_inputs": ["candidate_orbit_coordinates", "action_identity"],
    },
    {
        "name": "free_DOF",
        "formula": "registered action free-parameter count",
        "source_arrays": ["candidate_free_parameters"],
        "allowed_inputs": ["candidate_free_parameters", "action_identity"],
    },
    {
        "name": "assembly_progress",
        "formula": "partial-state site count divided by complete target site count",
        "source_arrays": ["partial_site_count", "complete_site_count"],
        "allowed_inputs": ["assembly_progress", "action_identity"],
    },
)


def _composition(orbits: Sequence[Mapping[str, object]]) -> tuple[tuple[int, int], ...]:
    counts: Counter[int] = Counter()
    for orbit in orbits:
        counts[int(orbit["species"])] += int(orbit["multiplicity"])
    return tuple(sorted(counts.items()))


def choose_terminal_completion_events(
    parent_payloads: Mapping[str, Mapping[str, object]],
    graph_rows: Sequence[Mapping[str, object]],
    *,
    forbidden_parent_ids: Set[str],
) -> list[dict[str, object]]:
    candidates: dict[str, list[dict[str, object]]] = defaultdict(list)
    forbidden = {str(value) for value in forbidden_parent_ids}
    for graph_line_number, row in enumerate(graph_rows, start=1):
        parent_id = str(row["parent_id"])
        split = str(row["split"])
        if parent_id in forbidden or split not in DEVELOPMENT_SPLITS:
            continue
        parent = parent_payloads.get(parent_id)
        if parent is None or not bool(parent.get("passed", False)):
            continue
        orbits = [dict(value) for value in parent["orbits"]]  # type: ignore[index]
        orbit_ids = [str(orbit["orbit_instance_id"]) for orbit in orbits]
        if len(orbit_ids) != len(set(orbit_ids)):
            raise ValueError(f"duplicate canonical orbit identity: {parent_id}")
        active_raw = tuple(str(value) for value in row["active_orbit_ids"])  # type: ignore[index]
        active = set(active_raw)
        if not active <= set(orbit_ids):
            raise ValueError(f"noncanonical active orbit identity: {parent_id}")
        missing = set(orbit_ids) - active
        if len(missing) != 1:
            continue
        target_orbit_id = next(iter(missing))
        positive = {str(value) for value in row["positive_orbit_ids"]}  # type: ignore[index]
        if target_orbit_id not in positive:
            continue
        canonical_event_index = orbit_ids.index(target_orbit_id)
        target = orbits[canonical_event_index]
        free_dof = len(target.get("free_parameters", []))
        if not 1 <= free_dof <= 3:
            continue
        action_key = (
            str(target["wyckoff_letter"]),
            int(target["species"]),
            int(target["multiplicity"]),
            free_dof,
        )
        positive_keys = {
            tuple(value) for value in row.get("positive_action_keys", [])  # type: ignore[arg-type]
        }
        if positive_keys and action_key not in positive_keys:
            raise ValueError(
                f"target orbit action is absent from positive actions: {parent_id}"
            )
        full_composition = _composition(orbits)
        active_orbits = [
            orbit for orbit in orbits if str(orbit["orbit_instance_id"]) in active
        ]
        partial_composition = Counter(dict(_composition(active_orbits)))
        remaining = Counter(dict(full_composition))
        remaining.subtract(partial_composition)
        remaining = Counter({key: value for key, value in remaining.items() if value})
        expected_remaining = Counter(
            {int(target["species"]): int(target["multiplicity"])}
        )
        if remaining != expected_remaining:
            raise ValueError(f"terminal-completion composition mismatch: {parent_id}")
        crystal_system = str(parent["lattice"]["crystal_system"])  # type: ignore[index]
        event_id = (
            f"full-orbit:{parent_id}:canonical-{canonical_event_index:02d}:"
            f"{target_orbit_id}"
        )
        candidates[parent_id].append(
            {
                "event_id": event_id,
                "parent_id": parent_id,
                "original_split_source": split,
                "crystal_system": crystal_system,
                "target_space_group": int(parent["target_space_group"]),
                "canonical_event_index": canonical_event_index,
                "graph_line_number": graph_line_number,
                "active_orbit_ids": active_raw,
                "target_orbit_id": target_orbit_id,
                "wyckoff_position_id": str(target["wyckoff_position_id"]),
                "wyckoff_letter": str(target["wyckoff_letter"]),
                "species": int(target["species"]),
                "multiplicity": int(target["multiplicity"]),
                "free_dof": free_dof,
                "parent_u_star": tuple(
                    float(value) for value in target["free_parameters"]
                ),
                "full_composition": full_composition,
                "remaining_composition": tuple(sorted(remaining.items())),
                "partial_site_count": sum(
                    int(orbit["multiplicity"]) for orbit in active_orbits
                ),
                "complete_site_count": sum(count for _, count in full_composition),
                "partial_state_reference": json.dumps(
                    {
                        "parent_id": parent_id,
                        "graph_line_number": graph_line_number,
                        "active_orbit_ids": active_raw,
                    },
                    sort_keys=True,
                    separators=(",", ":"),
                ),
            }
        )
    selected = []
    for parent_id in sorted(candidates):
        ordered = sorted(
            candidates[parent_id],
            key=lambda event: (
                int(event["canonical_event_index"]),
                str(event["wyckoff_position_id"]),
                int(event["species"]),
                int(event["multiplicity"]),
            ),
        )
        selected.append(ordered[0])
    return selected


def _stratum(event: Mapping[str, object]) -> tuple[str, str, int, int]:
    return (
        str(event["original_split_source"]),
        str(event["crystal_system"]),
        int(event["multiplicity"]),
        int(event["free_dof"]),
    )


def stratified_systematic_select(
    events: Sequence[Mapping[str, object]], *, target_n: int
) -> list[dict[str, object]]:
    if target_n <= 0 or target_n > len(events):
        raise ValueError("target_n must be positive and no larger than the event pool")
    grouped: dict[tuple[str, str, int, int], list[Mapping[str, object]]] = defaultdict(
        list
    )
    for event in events:
        grouped[_stratum(event)].append(event)
    keys = sorted(grouped)
    if target_n < len(keys):
        raise ValueError("target_n is too small to cover every nonempty stratum")
    allocation = {key: 1 for key in keys}
    remaining_slots = target_n - len(keys)
    residual_capacity = {key: len(grouped[key]) - 1 for key in keys}
    total_capacity = sum(residual_capacity.values())
    if remaining_slots and total_capacity <= 0:
        raise ValueError("strata have insufficient residual capacity")
    quotas = {
        key: (
            remaining_slots * residual_capacity[key] / total_capacity
            if total_capacity
            else 0.0
        )
        for key in keys
    }
    for key in keys:
        allocation[key] += int(math.floor(quotas[key]))
    leftover = target_n - sum(allocation.values())
    remainder_order = sorted(
        keys,
        key=lambda key: (-(quotas[key] - math.floor(quotas[key])), key),
    )
    for key in remainder_order:
        if leftover == 0:
            break
        if allocation[key] < len(grouped[key]):
            allocation[key] += 1
            leftover -= 1
    if leftover:
        raise ValueError("could not complete deterministic stratum allocation")
    selected_by_stratum: dict[tuple[str, str, int, int], list[dict[str, object]]] = {}
    for key in keys:
        values = sorted(
            grouped[key],
            key=lambda event: (
                str(event["parent_id"]),
                int(event.get("canonical_event_index", 0)),
                str(event.get("wyckoff_position_id", "")),
                int(event.get("species", 0)),
                int(event.get("multiplicity", 0)),
            ),
        )
        take_n = allocation[key]
        indices = [
            int(math.floor((index + 0.5) * len(values) / take_n))
            for index in range(take_n)
        ]
        if len(indices) != len(set(indices)):
            raise RuntimeError(f"systematic positions collided for stratum {key}")
        selected_by_stratum[key] = [dict(values[index]) for index in indices]
    selected: list[dict[str, object]] = []
    for rank in range(max(len(values) for values in selected_by_stratum.values())):
        for key in keys:
            values = selected_by_stratum[key]
            if rank < len(values):
                selected.append(values[rank])
    if len(selected) != target_n:
        raise RuntimeError("stratified selection count mismatch")
    if len({str(event["parent_id"]) for event in selected}) != target_n:
        raise RuntimeError("stratified selection is not parent-disjoint")
    return selected


def _radical_inverse(index: int, base: int) -> float:
    value = 0.0
    factor = 1.0 / base
    remaining = int(index)
    while remaining:
        value += factor * (remaining % base)
        remaining //= base
        factor /= base
    return value


def shifted_halton_points(free_dof: int, *, count: int = 24) -> np.ndarray:
    if not 1 <= int(free_dof) <= 3:
        raise ValueError("free_dof must be between 1 and 3")
    if count <= 0:
        raise ValueError("count must be positive")
    bases = (2, 3, 5)
    shifts = (math.sqrt(2.0) - 1.0, math.sqrt(3.0) - 1.0, math.sqrt(5.0) - 2.0)
    points = np.empty((int(count), int(free_dof)), dtype=float)
    for row in range(int(count)):
        for column in range(int(free_dof)):
            points[row, column] = (
                _radical_inverse(row + 1, bases[column]) + shifts[column]
            ) % 1.0
    return points


def element_radius_angstrom(atomic_number: int) -> float:
    if not 1 <= int(atomic_number) <= 118:
        raise ValueError("atomic_number must be between 1 and 118")
    element = Element.from_Z(int(atomic_number))
    for value in (element.atomic_radius, element.atomic_radius_calculated):
        if value is not None and math.isfinite(float(value)) and float(value) > 0.0:
            return float(value)
    return 1.0


def _rounded(value: float) -> float:
    return round(float(value), 12)


def full_orbit_parent_free_features(
    *,
    lattice: Lattice,
    framework_atomic_numbers: np.ndarray,
    framework_fractional_coordinates: np.ndarray,
    candidate_atomic_number: int,
    candidate_fractional_coordinates: np.ndarray,
    free_dof: int,
    assembly_progress: float,
) -> dict[str, float]:
    framework_z = np.asarray(framework_atomic_numbers, dtype=int)
    framework_frac = np.asarray(framework_fractional_coordinates, dtype=float)
    candidate_frac = np.asarray(candidate_fractional_coordinates, dtype=float)
    if framework_z.ndim != 1 or framework_frac.shape != (len(framework_z), 3):
        raise ValueError("framework arrays have incompatible shapes")
    if len(framework_z) == 0:
        raise ValueError("terminal-completion framework must contain at least one atom")
    if (
        candidate_frac.ndim != 2
        or candidate_frac.shape[1:] != (3,)
        or len(candidate_frac) == 0
    ):
        raise ValueError("candidate orbit must be a nonempty N x 3 array")
    if not np.isfinite(framework_frac).all() or not np.isfinite(candidate_frac).all():
        raise ValueError("feature coordinates must be finite")
    if not 1 <= int(free_dof) <= 3:
        raise ValueError("free_dof must be between 1 and 3")
    if (
        not math.isfinite(float(assembly_progress))
        or not 0.0 <= float(assembly_progress) < 1.0
    ):
        raise ValueError("assembly_progress must be finite in [0,1)")
    candidate_radius = element_radius_angstrom(int(candidate_atomic_number))
    cutoff_values = []
    safe_values = []
    for atomic_number in framework_z:
        cutoff, safe = fixed_cutoff_from_radii(
            candidate_radius, element_radius_angstrom(int(atomic_number))
        )
        cutoff_values.append(cutoff)
        safe_values.append(safe)
    cutoffs = np.asarray(cutoff_values, dtype=float)[None, :]
    safe_distances = np.asarray(safe_values, dtype=float)[None, :]
    distances = np.asarray(
        lattice.get_all_distances(candidate_frac, framework_frac), dtype=float
    )
    per_atom_minimum = distances.min(axis=1)
    coordinated = distances <= (cutoffs + 1e-12)
    coordination = coordinated.sum(axis=1)
    same_species = framework_z == int(candidate_atomic_number)
    same_species_coordination = coordinated[:, same_species].sum(axis=1)
    neighbour_z_matrix = np.broadcast_to(framework_z[None, :], distances.shape)
    neighbour_z = neighbour_z_matrix[coordinated]
    coordinated_distances = distances[coordinated]
    pair_residuals = np.clip((safe_distances - distances) / safe_distances, 0.0, 1.0)
    per_atom_residual = pair_residuals.max(axis=1)
    if len(candidate_frac) > 1:
        internal_matrix = np.asarray(
            lattice.get_all_distances(candidate_frac, candidate_frac), dtype=float
        )
        left, right = np.triu_indices(len(candidate_frac), k=1)
        internal = internal_matrix[left, right]
        internal_minimum = float(internal.min())
        internal_mean = float(internal.mean())
    else:
        internal_minimum = 0.0
        internal_mean = 0.0
    residual_max = float(per_atom_residual.max())
    residual_mean = float(per_atom_residual.mean())
    return {
        "candidate_framework_min_distance_min": _rounded(per_atom_minimum.min()),
        "candidate_framework_min_distance_mean": _rounded(per_atom_minimum.mean()),
        "candidate_framework_coordination_mean": _rounded(coordination.mean()),
        "candidate_framework_coordination_min": _rounded(coordination.min()),
        "candidate_framework_same_species_coordination_mean": _rounded(
            same_species_coordination.mean()
        ),
        "candidate_neighbor_Z_mean": (
            _rounded(neighbour_z.mean()) if neighbour_z.size else 0.0
        ),
        "candidate_neighbor_Z_std": (
            _rounded(neighbour_z.std()) if neighbour_z.size else 0.0
        ),
        "candidate_coordinated_distance_mean": (
            _rounded(coordinated_distances.mean())
            if coordinated_distances.size
            else 0.0
        ),
        "orbit_internal_min_distance": _rounded(internal_minimum),
        "orbit_internal_pair_distance_mean": _rounded(internal_mean),
        "short_contact_residual_max": _rounded(residual_max),
        "short_contact_residual_mean": _rounded(residual_mean),
        "static_full_orbit_contact_score": _rounded(
            0.5 * (residual_max + residual_mean)
        ),
        "multiplicity": float(len(candidate_frac)),
        "free_DOF": float(free_dof),
        "assembly_progress": _rounded(assembly_progress),
    }


def summarize_event_forces(
    candidate_rows: Sequence[Mapping[str, object]],
) -> dict[str, object]:
    forces = np.asarray(
        [
            float(row["initial_max_force_ev_per_angstrom"])
            for row in candidate_rows
            if row.get("chgnet_status") == "EVALUATED"
            and row.get("initial_max_force_ev_per_angstrom") is not None
            and math.isfinite(float(row["initial_max_force_ev_per_angstrom"]))
        ],
        dtype=float,
    )
    accepted_n = sum(
        bool(row.get("projector_accepted", False)) for row in candidate_rows
    )
    if not len(forces):
        return {
            "finite_force_n": 0,
            "projector_accepted_n": accepted_n,
            "force_min": None,
            "force_median": None,
            "force_max": None,
            "force_iqr": None,
            "force_p90_p10_ratio": None,
            "force_log1p_iqr": None,
            "ranking_spread": None,
            "landscape_nontrivial": False,
        }
    logs = np.log1p(forces)
    q25, q75 = np.quantile(forces, [0.25, 0.75])
    log_q25, log_q75 = np.quantile(logs, [0.25, 0.75])
    p10, p90 = np.quantile(forces, [0.10, 0.90])
    log_iqr = float(log_q75 - log_q25)
    return {
        "finite_force_n": int(len(forces)),
        "projector_accepted_n": accepted_n,
        "force_min": float(np.min(forces)),
        "force_median": float(np.median(forces)),
        "force_max": float(np.max(forces)),
        "force_iqr": float(q75 - q25),
        "force_p90_p10_ratio": float(p90 / max(float(p10), 1e-12)),
        "force_log1p_iqr": log_iqr,
        "ranking_spread": float(np.max(logs) - np.min(logs)),
        "landscape_nontrivial": bool(
            len(forces) >= 18 and accepted_n >= 1 and log_iqr >= math.log(1.25)
        ),
    }


def compatibility_dataset_verdict(
    *,
    expansion_valid_rate: float,
    landscape_supported: bool,
    contact_signal: bool,
) -> tuple[str, str]:
    if (
        float(expansion_valid_rate) >= 0.95
        and bool(landscape_supported)
        and bool(contact_signal)
    ):
        return "SUPPORTED", "TRAIN_STRICT_PARENT_FREE_FULL_ORBIT_OPERATOR"
    if float(expansion_valid_rate) >= 0.95 and bool(landscape_supported):
        return "LANDSCAPE_ONLY", "DESIGN_FULL_ORBIT_GEOMETRIC_REPRESENTATION"
    return "NOT_SUPPORTED", "RETURN_TO_DIRECT_MDN_GEOMETRY"


def _spearman(left: Sequence[float], right: Sequence[float]) -> float | None:
    if len(left) < 2 or len(left) != len(right):
        return None
    left_array = np.asarray(left, dtype=float)
    right_array = np.asarray(right, dtype=float)
    if not np.isfinite(left_array).all() or not np.isfinite(right_array).all():
        return None
    if np.unique(left_array).size < 2 or np.unique(right_array).size < 2:
        return None
    value = float(spearmanr(left_array, right_array).statistic)
    return value if math.isfinite(value) else None


def aggregate_poc(
    candidate_rows: Sequence[Mapping[str, object]],
    event_rows: Sequence[Mapping[str, object]],
) -> dict[str, object]:
    if not candidate_rows or not event_rows:
        raise ValueError("candidate and event rows must be nonempty")
    grouped: dict[str, list[Mapping[str, object]]] = defaultdict(list)
    candidate_keys = set()
    for row in candidate_rows:
        event_id = str(row["event_id"])
        key = (event_id, int(row["candidate_index"]))
        if key in candidate_keys:
            raise ValueError(f"duplicate candidate grain: {key}")
        candidate_keys.add(key)
        grouped[event_id].append(row)
    event_by_id = {str(row["event_id"]): row for row in event_rows}
    if len(event_by_id) != len(event_rows) or set(grouped) != set(event_by_id):
        raise ValueError("candidate/event grain mismatch")
    if any(len(rows) != 24 for rows in grouped.values()):
        raise ValueError("every retained event must have exactly 24 candidate rows")
    expansion_valid_n = sum(
        bool(row.get("expansion_valid", False)) for row in candidate_rows
    )
    evaluated = [
        row
        for row in candidate_rows
        if row.get("chgnet_status") == "EVALUATED"
        and row.get("initial_max_force_ev_per_angstrom") is not None
        and math.isfinite(float(row["initial_max_force_ev_per_angstrom"]))
    ]
    event_summaries = []
    for event_id in sorted(grouped):
        summary = summarize_event_forces(grouped[event_id])
        event_summaries.append({"event_id": event_id, **summary})
    landscape_rate = float(
        np.mean([bool(row["landscape_nontrivial"]) for row in event_summaries])
    )
    landscape_supported = landscape_rate >= 0.70
    contact_values = [
        float(row["static_full_orbit_contact_score"]) for row in evaluated
    ]
    force_values = [
        float(row["initial_max_force_ev_per_angstrom"]) for row in evaluated
    ]
    overall_spearman = _spearman(contact_values, force_values)
    event_spearman_values = []
    best_forces = []
    worst_forces = []
    for event_id in sorted(grouped):
        finite = [
            row
            for row in grouped[event_id]
            if row.get("chgnet_status") == "EVALUATED"
            and row.get("initial_max_force_ev_per_angstrom") is not None
            and math.isfinite(float(row["initial_max_force_ev_per_angstrom"]))
        ]
        score = [float(row["static_full_orbit_contact_score"]) for row in finite]
        force = [float(row["initial_max_force_ev_per_angstrom"]) for row in finite]
        event_value = _spearman(score, force)
        if event_value is not None:
            event_spearman_values.append(event_value)
        if len(finite) >= 4:
            ordered = sorted(
                finite,
                key=lambda row: (
                    float(row["static_full_orbit_contact_score"]),
                    int(row["candidate_index"]),
                ),
            )
            quartile_n = max(1, len(ordered) // 4)
            best_forces.extend(
                float(row["initial_max_force_ev_per_angstrom"])
                for row in ordered[:quartile_n]
            )
            worst_forces.extend(
                float(row["initial_max_force_ev_per_angstrom"])
                for row in ordered[-quartile_n:]
            )
    event_mean_spearman = (
        float(np.mean(event_spearman_values)) if event_spearman_values else 0.0
    )
    best_median = float(np.median(best_forces)) if best_forces else float("nan")
    worst_median = float(np.median(worst_forces)) if worst_forces else float("nan")
    contact_signal = bool(
        overall_spearman is not None
        and overall_spearman >= 0.30
        and event_mean_spearman >= 0.20
        and math.isfinite(best_median)
        and math.isfinite(worst_median)
        and best_median < worst_median
    )
    expansion_valid_rate = expansion_valid_n / len(candidate_rows)
    signal, next_action = compatibility_dataset_verdict(
        expansion_valid_rate=expansion_valid_rate,
        landscape_supported=landscape_supported,
        contact_signal=contact_signal,
    )
    oracle_forces = [
        float(row["parent_oracle_force"])
        for row in event_rows
        if row.get("parent_oracle_force") is not None
        and math.isfinite(float(row["parent_oracle_force"]))
    ]
    force_iqrs = [
        float(row["force_iqr"])
        for row in event_summaries
        if row["force_iqr"] is not None
    ]
    return {
        "event_n": len(event_rows),
        "candidate_n": len(candidate_rows),
        "expansion_valid_rate": float(expansion_valid_rate),
        "chgnet_finite_rate": (
            float(len(evaluated) / expansion_valid_n) if expansion_valid_n else 0.0
        ),
        "full_orbit_force_median": (
            float(np.median(force_values)) if force_values else float("nan")
        ),
        "event_force_iqr_median": (
            float(np.median(force_iqrs)) if force_iqrs else float("nan")
        ),
        "landscape_event_rate": landscape_rate,
        "full_orbit_landscape_exists": (
            "SUPPORTED" if landscape_supported else "NOT_SUPPORTED"
        ),
        "contact_force_spearman": (
            float(overall_spearman) if overall_spearman is not None else 0.0
        ),
        "event_mean_contact_force_spearman": event_mean_spearman,
        "event_contact_spearman_defined_n": len(event_spearman_values),
        "best_contact_quartile_force_median": best_median,
        "worst_contact_quartile_force_median": worst_median,
        "parent_oracle_force_median": (
            float(np.median(oracle_forces)) if oracle_forces else float("nan")
        ),
        "contact_ranking_signal": contact_signal,
        "full_orbit_compatibility_dataset_signal": signal,
        "next_action": next_action,
        "event_summaries": event_summaries,
    }


def choose_event_budget(
    *, elapsed_minutes_at_eight: float, max_wall_clock_minutes: float = 25.0
) -> int:
    elapsed = float(elapsed_minutes_at_eight)
    deadline = float(max_wall_clock_minutes)
    if not math.isfinite(elapsed) or elapsed <= 0.0:
        raise ValueError("elapsed_minutes_at_eight must be finite and positive")
    if not math.isfinite(deadline) or deadline <= 0.0:
        raise ValueError("max_wall_clock_minutes must be finite and positive")
    rate = elapsed / 8.0
    if rate * 64 <= deadline:
        return 64
    if rate * 48 <= deadline:
        return 48
    return 32


def validate_new_output_path(path: str | Path) -> Path:
    output = Path(path)
    if output.exists():
        raise FileExistsError(f"output path already exists: {output}")
    return output


__all__ = [
    "DEVELOPMENT_SPLITS",
    "FEATURE_SCHEMA",
    "aggregate_poc",
    "choose_terminal_completion_events",
    "choose_event_budget",
    "compatibility_dataset_verdict",
    "element_radius_angstrom",
    "full_orbit_parent_free_features",
    "shifted_halton_points",
    "stratified_systematic_select",
    "summarize_event_forces",
    "validate_new_output_path",
]
