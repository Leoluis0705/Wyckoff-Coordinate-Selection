from __future__ import annotations

import hashlib
import json
import math
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from statistics import median
from typing import Any

import torch

from crysalis_g1.experiments.local_pilot_data import (
    AssemblyExampleKey,
    FrozenPhase2ACorpus,
)
from crysalis_g1.experiments.local_pilot_training import (
    _CorpusSampler,
    derive_named_seed,
)
from crysalis_g1.model.local_pilot_model import (
    PilotLossScales,
    UnifiedLocalPilotModel,
    compute_pilot_losses,
)


_VRAM_LIMIT_BYTES = 11 * 1024**3


@dataclass(slots=True)
class BackendScreenResult:
    backend: str
    forward_backward_finite: bool
    unhandled_oom: bool
    rollout_record_count: int
    legal_terminal_count: int
    peak_reserved_vram_bytes: int
    post_relax_survival_rate: float
    free_rollout_completion_rate: float
    short_contact_free_rate: float
    pre_projector_validity_rate: float
    generation_latency_p50_seconds: float
    coordinate_error: float
    lattice_error: float
    steps_per_second: float

    @property
    def quality_score(self) -> float:
        return (
            0.40 * self.post_relax_survival_rate
            + 0.30 * self.free_rollout_completion_rate
            + 0.20 * self.short_contact_free_rate
            + 0.10 * self.pre_projector_validity_rate
        )

    @property
    def hard_pass(self) -> bool:
        return bool(
            self.forward_backward_finite
            and not self.unhandled_oom
            and self.rollout_record_count == 100
            and self.legal_terminal_count >= 1
            and self.peak_reserved_vram_bytes <= _VRAM_LIMIT_BYTES
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            **asdict(self),
            "quality_score": self.quality_score,
            "hard_pass": self.hard_pass,
            "peak_reserved_vram_gib": self.peak_reserved_vram_bytes / 1024**3,
        }


def select_geometry_backend(
    *, periodic: BackendScreenResult, e3nn: BackendScreenResult
) -> dict[str, Any]:
    if periodic.backend != "periodic_egnn" or e3nn.backend != "e3nn_lite":
        raise ValueError("C0 backend identities are invalid")
    passing = [result for result in (periodic, e3nn) if result.hard_pass]
    if not passing:
        raise RuntimeError("both C0 geometry backends failed hard pass conditions")
    if len(passing) == 1:
        selected = passing[0]
        rule = "ONLY_HARD_PASSING_BACKEND"
    else:
        major_periodic = (
            periodic.post_relax_survival_rate,
            periodic.free_rollout_completion_rate,
            periodic.short_contact_free_rate,
            periodic.pre_projector_validity_rate,
        )
        major_e3nn = (
            e3nn.post_relax_survival_rate,
            e3nn.free_rollout_completion_rate,
            e3nn.short_contact_free_rate,
            e3nn.pre_projector_validity_rate,
        )
        e3nn_guards = bool(
            e3nn.quality_score >= periodic.quality_score + 0.03 - 1e-12
            and e3nn.generation_latency_p50_seconds
            <= periodic.generation_latency_p50_seconds * 3.0
            and e3nn.peak_reserved_vram_bytes <= _VRAM_LIMIT_BYTES
            and all(
                candidate >= baseline - 0.05 - 1e-12
                for candidate, baseline in zip(
                    major_e3nn, major_periodic, strict=True
                )
            )
        )
        if e3nn_guards:
            selected = e3nn
            rule = "E3NN_REGISTERED_MARGIN_AND_GUARDS"
        else:
            selected = periodic
            rule = "PERIODIC_DEFAULT_RULE"
    return {
        "schema_version": "g1-geometry-backend-freeze.1.0.0",
        "status": "PASS",
        "selected_backend": selected.backend,
        "selection_rule": rule,
        "periodic_egnn": periodic.as_dict(),
        "e3nn_lite": e3nn.as_dict(),
        "e3nn_quality_margin_required": 0.03,
        "e3nn_latency_multiple_limit": 3.0,
        "major_metric_drop_limit": 0.05,
        "peak_reserved_vram_limit_bytes": _VRAM_LIMIT_BYTES,
        "root_seed": 20260823,
        "three_seed_authorized": False,
        "server_deployment_authorized": False,
    }


@dataclass(frozen=True, slots=True)
class ThroughputConfig:
    root_seed: int
    device: str
    batch_size: int
    gradient_accumulation_steps: int
    mixed_precision: bool
    forward_backward_batches: int
    throughput_steps: int
    learning_rate: float
    weight_decay: float
    gradient_clip_norm: float

    def __post_init__(self) -> None:
        if self.root_seed != 20260823:
            raise ValueError("throughput root seed must remain 20260823")
        if self.device not in {"cpu", "cuda"}:
            raise ValueError("throughput device must be cpu or cuda")
        if self.mixed_precision and self.device != "cuda":
            raise ValueError("mixed precision requires CUDA")
        counts = (
            self.batch_size,
            self.gradient_accumulation_steps,
            self.forward_backward_batches,
            self.throughput_steps,
        )
        if any(type(value) is not int or value <= 0 for value in counts):
            raise ValueError("throughput counts must be positive integers")


def _sync(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)


def benchmark_forward_backward_and_throughput(
    *,
    model: UnifiedLocalPilotModel,
    corpus: FrozenPhase2ACorpus,
    train_keys: tuple[AssemblyExampleKey, ...],
    loss_scales: PilotLossScales,
    config: ThroughputConfig,
) -> dict[str, Any]:
    device = torch.device(config.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA throughput requested but unavailable")
    torch.manual_seed(
        derive_named_seed(config.root_seed, "c0:throughput:model-runtime")
    )
    torch.cuda.manual_seed_all(
        derive_named_seed(config.root_seed, "c0:throughput:model-runtime")
    )
    model = model.to(device).train()
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=config.learning_rate,
        weight_decay=config.weight_decay,
    )
    scaler = torch.amp.GradScaler(
        "cuda",
        enabled=config.mixed_precision,
        init_scale=1024.0,
        growth_interval=1_000_000_000,
    )
    sampler = _CorpusSampler(
        corpus,
        train_keys,
        seed=derive_named_seed(
            config.root_seed, "c0:shared-throughput-batch-schedule"
        ),
    )
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    finite_batch_count = 0
    for _ in range(config.forward_backward_batches):
        optimizer.zero_grad(set_to_none=True)
        batch = sampler.batch(config.batch_size).to(device)
        with torch.autocast(
            device_type=device.type,
            dtype=torch.float16,
            enabled=config.mixed_precision,
        ):
            loss = compute_pilot_losses(model(batch), batch, loss_scales).validation_objective
        if not bool(torch.isfinite(loss)):
            raise FloatingPointError("non-finite C0 forward/backward loss")
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        if not all(
            parameter.grad is None or bool(torch.isfinite(parameter.grad).all())
            for parameter in model.parameters()
        ):
            raise FloatingPointError("non-finite C0 forward/backward gradient")
        torch.nn.utils.clip_grad_norm_(
            model.parameters(), config.gradient_clip_norm
        )
        previous_scale = scaler.get_scale()
        scaler.step(optimizer)
        scaler.update()
        if scaler.get_scale() < previous_scale:
            raise FloatingPointError("C0 forward/backward optimizer step was skipped")
        finite_batch_count += 1

    latencies: list[float] = []
    for _ in range(config.throughput_steps):
        started = time.perf_counter()
        optimizer.zero_grad(set_to_none=True)
        for _ in range(config.gradient_accumulation_steps):
            batch = sampler.batch(config.batch_size).to(device)
            with torch.autocast(
                device_type=device.type,
                dtype=torch.float16,
                enabled=config.mixed_precision,
            ):
                loss = (
                    compute_pilot_losses(model(batch), batch, loss_scales)
                    .validation_objective
                    / config.gradient_accumulation_steps
                )
            if not bool(torch.isfinite(loss)):
                raise FloatingPointError("non-finite C0 throughput loss")
            scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), config.gradient_clip_norm)
        scaler.step(optimizer)
        scaler.update()
        _sync(device)
        latencies.append(time.perf_counter() - started)
    elapsed = sum(latencies)
    return {
        "status": "PASS",
        "forward_backward_finite": True,
        "forward_backward_batch_count": finite_batch_count,
        "throughput_step_count": config.throughput_steps,
        "steps_per_second": config.throughput_steps / max(elapsed, 1e-12),
        "step_latency_p50_seconds": median(latencies),
        "peak_allocated_vram_bytes": (
            int(torch.cuda.max_memory_allocated(device))
            if device.type == "cuda"
            else 0
        ),
        "peak_reserved_vram_bytes": (
            int(torch.cuda.max_memory_reserved(device))
            if device.type == "cuda"
            else 0
        ),
        "batch_schedule_sha256": hashlib.sha256(
            "c0:shared-throughput-batch-schedule".encode()
        ).hexdigest(),
    }


def evaluate_geometry_errors(
    *,
    model: UnifiedLocalPilotModel,
    corpus: FrozenPhase2ACorpus,
    validation_keys: tuple[AssemblyExampleKey, ...],
    root_seed: int,
    batch_size: int,
    batch_count: int,
    device_name: str,
    mixed_precision: bool,
) -> dict[str, float]:
    device = torch.device(device_name)
    sampler = _CorpusSampler(
        corpus,
        validation_keys,
        seed=derive_named_seed(
            root_seed, "c0:shared-geometry-validation-schedule"
        ),
    )
    coordinate_squared_error = 0.0
    coordinate_count = 0
    lattice_squared_error = 0.0
    lattice_count = 0
    model = model.to(device).eval()
    with torch.no_grad():
        for _ in range(batch_count):
            batch = sampler.batch(batch_size).to(device)
            with torch.autocast(
                device_type=device.type,
                dtype=torch.float16,
                enabled=mixed_precision,
            ):
                output = model(batch)
            mask = batch.target_orbit_mask
            if bool(mask.any()):
                delta = (
                    output.predicted_fractional_coordinate[mask]
                    - batch.target_fractional_coordinates[mask]
                )
                delta -= torch.round(delta)
                coordinate_squared_error += float(delta.square().sum())
                coordinate_count += int(mask.sum()) * 3
            predicted_metric = output.predicted_lattice @ output.predicted_lattice.transpose(-1, -2)
            target_metric = batch.target_lattice @ batch.target_lattice.transpose(-1, -2)
            target_scale = target_metric.square().mean(dim=(-1, -2)).sqrt().clamp_min(1.0)
            relative = (predicted_metric - target_metric) / target_scale[:, None, None]
            lattice_squared_error += float(relative.square().sum())
            lattice_count += relative.numel()
    return {
        "coordinate_error": math.sqrt(
            coordinate_squared_error / max(coordinate_count, 1)
        ),
        "lattice_error": math.sqrt(
            lattice_squared_error / max(lattice_count, 1)
        ),
    }


def summarize_rollout_and_chgnet(
    *, rollout: dict[str, Any], chgnet: dict[str, Any]
) -> dict[str, float | int]:
    records = rollout["records"]
    attempted_projector_states = sum(
        int(record["projector"]["attempted_state_count"]) for record in records
    )
    pre_valid = sum(
        int(record["projector"]["pre_valid_count"]) for record in records
    )
    short_contact_free = sum(bool(record["short_contact_free"]) for record in records)
    attempts = len(records)
    return {
        "rollout_record_count": attempts,
        "legal_terminal_count": sum(
            bool(record["legal_terminal_crystal"]) for record in records
        ),
        "free_rollout_completion_rate": float(rollout["completion_rate"]),
        "short_contact_free_rate": short_contact_free / attempts,
        "pre_projector_validity_rate": pre_valid
        / max(attempted_projector_states, 1),
        "post_relax_survival_rate": float(
            chgnet["post_relax_survival_rate_all_attempts"]
        ),
        "generation_latency_p50_seconds": float(
            rollout["generation_latency_p50_seconds"]
        ),
    }


def write_geometry_freeze(
    output_dir: str | Path,
    freeze: dict[str, Any],
    *,
    phase2a_manifest_sha256: str,
    code_sha256: str,
) -> None:
    output_dir = Path(output_dir)
    freeze = {
        **freeze,
        "phase2a_manifest_sha256": phase2a_manifest_sha256,
        "code_sha256": code_sha256,
    }
    encoded = json.dumps(
        freeze,
        ensure_ascii=False,
        allow_nan=False,
        indent=2,
        sort_keys=True,
    ) + "\n"
    path = output_dir / "GEOMETRY_BACKEND_FREEZE.json"
    if path.exists():
        raise FileExistsError(f"geometry freeze refuses to overwrite: {path}")
    path.write_text(encoded, encoding="utf-8")
