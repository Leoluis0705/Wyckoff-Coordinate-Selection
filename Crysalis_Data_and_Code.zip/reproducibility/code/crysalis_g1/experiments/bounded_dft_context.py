from __future__ import annotations

from collections.abc import Mapping, Sequence
import math
import re


_TOTEN_RE = re.compile(
    r"free\s+energy\s+TOTEN\s*=\s*([-+0-9.Ee]+)\s+eV"
)
_FORCE_ROW_RE = re.compile(
    r"^\s*"
    r"([-+0-9.Ee]+)\s+([-+0-9.Ee]+)\s+([-+0-9.Ee]+)\s+"
    r"([-+0-9.Ee]+)\s+([-+0-9.Ee]+)\s+([-+0-9.Ee]+)\s*$"
)


def select_quartile_events(
    rows: Sequence[Mapping[str, object]],
) -> list[dict[str, object]]:
    if len(rows) != 24:
        raise ValueError("each registered force quartile must contain 24 events")
    ordered = sorted(
        rows, key=lambda row: (str(row["parent_id"]), str(row["event_id"]))
    )
    return [dict(ordered[index]) for index in (5, 11, 17)]


def parse_outcar_text(text: str) -> dict[str, float | bool]:
    energies = [float(value) for value in _TOTEN_RE.findall(text)]
    if not energies:
        raise ValueError("OUTCAR does not contain a TOTEN value")

    force_blocks: list[list[float]] = []
    active_block: list[float] | None = None
    for line in text.splitlines():
        if "TOTAL-FORCE (eV/Angst)" in line:
            active_block = []
            continue
        if active_block is None:
            continue
        match = _FORCE_ROW_RE.match(line)
        if match:
            fx, fy, fz = (float(match.group(index)) for index in (4, 5, 6))
            active_block.append(math.sqrt(fx * fx + fy * fy + fz * fz))
        elif active_block:
            force_blocks.append(active_block)
            active_block = None
    if active_block:
        force_blocks.append(active_block)
    if not force_blocks:
        raise ValueError("OUTCAR does not contain a complete force block")

    final_forces = force_blocks[-1]
    return {
        "total_energy_ev": energies[-1],
        "max_force_ev_per_a": max(final_forces),
        "mean_force_ev_per_a": sum(final_forces) / len(final_forces),
        "scf_converged": "aborting loop because EDIFF is reached" in text,
    }


def dft_context_signal(
    *,
    mean_delta: float,
    context_win_n: int,
    tail_supported: bool,
    systematic_failure_imbalance: bool,
) -> str:
    if float(mean_delta) >= 0.0:
        return "NOT_SUPPORTED"
    if (
        int(context_win_n) >= 7
        and bool(tail_supported)
        and not bool(systematic_failure_imbalance)
    ):
        return "SUPPORTED"
    return "INCONCLUSIVE_POSITIVE"
