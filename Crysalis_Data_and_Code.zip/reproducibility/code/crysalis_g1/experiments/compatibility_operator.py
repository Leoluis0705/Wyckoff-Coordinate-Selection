from __future__ import annotations

import hashlib
import math
import time
from collections import Counter
from typing import Mapping, Sequence

import numpy as np
import torch
from pymatgen.core import Lattice, Structure
from scipy.stats import pearsonr, spearmanr
from torch import nn
from torch.nn import functional as F


FOLD_SEED = 20260901
RBF_CENTERS_ANGSTROM = np.linspace(0.5, 5.0, 8, dtype=float)
RBF_WIDTH_ANGSTROM = 0.5
GEOMETRY_FEATURE_N = 64
RESPONSE_FEATURE_N = 21
MAX_UPDATES = 300
BATCH_SIZE = 512
LEARNING_RATE = 0.002
WEIGHT_DECAY = 1e-4


def stable_parent_folds(
    parent_ids: Sequence[str], *, seed: int = FOLD_SEED
) -> tuple[tuple[str, ...], ...]:
    values = [str(value) for value in parent_ids]
    if len(values) != 32 or len(set(values)) != 32:
        raise ValueError("fixed four-fold CV requires 32 unique parents")
    ordered = sorted(
        values,
        key=lambda parent_id: (
            hashlib.sha256(
                f"{seed}:compatibility-fold:{parent_id}".encode()
            ).hexdigest(),
            parent_id,
        ),
    )
    folds = tuple(tuple(ordered[index::4]) for index in range(4))
    if tuple(map(len, folds)) != (8, 8, 8, 8):
        raise AssertionError("parent fold construction drifted")
    return folds


def audit_state_candidate_join(
    states: Sequence[Mapping[str, object]],
    candidates: Sequence[Mapping[str, object]],
    *,
    candidates_per_state: int = 32,
) -> dict[str, object]:
    if candidates_per_state <= 0:
        raise ValueError("candidates_per_state must be positive")
    state_ids = [str(row["state_id"]) for row in states]
    duplicate = sorted(
        state_id for state_id, count in Counter(state_ids).items() if count != 1
    )
    if duplicate:
        raise ValueError(f"duplicate state_id values: {duplicate[:3]}")
    candidate_ids = [str(row["candidate_id"]) for row in candidates]
    if len(candidate_ids) != len(set(candidate_ids)):
        raise ValueError("duplicate candidate_id values")
    allowed = set(state_ids)
    matched = [row for row in candidates if str(row["state_id"]) in allowed]
    counts = Counter(str(row["state_id"]) for row in matched)
    exact_state_n = sum(counts.get(state_id, 0) == candidates_per_state for state_id in state_ids)
    success_rate = len(matched) / len(candidates) if candidates else 0.0
    complete = bool(
        states
        and len(matched) == len(candidates)
        and exact_state_n == len(states)
        and len(candidates) == len(states) * candidates_per_state
    )
    return {
        "state_n": len(states),
        "candidate_n": len(candidates),
        "matched_candidate_n": len(matched),
        "state_with_exact_candidate_n": exact_state_n,
        "join_success_rate": float(success_rate),
        "complete": complete,
    }


def _structure_from_state(state: Mapping[str, object]) -> Structure:
    return Structure(
        Lattice(np.asarray(state["lattice_matrix"], dtype=float)),
        [int(value) for value in state["framework_species"]],
        np.asarray(state["framework_fractional_coordinates"], dtype=float),
        to_unit_cell=True,
    )


def _cutoffs_from_state(
    state: Mapping[str, object],
) -> dict[tuple[int, int], float]:
    result = {}
    for row in state["species_pair_cutoffs"]:
        left = int(row["species_a"])
        right = int(row["species_b"])
        result[tuple(sorted((left, right)))] = float(row["cutoff_angstrom"])
    return result


def _geometry_features(
    state: Mapping[str, object], candidate: Mapping[str, object]
) -> tuple[list[float], list[str]]:
    structure = _structure_from_state(state)
    lattice = structure.lattice
    raw_fractional = np.asarray(candidate["candidate_fractional_coordinate"], dtype=float)
    fractional = np.mod(raw_fractional, 1.0)
    inserted_species = int(candidate["inserted_species"])
    species = np.asarray([int(site.specie.Z) for site in structure], dtype=float)
    distances = np.asarray(
        lattice.get_all_distances([fractional], structure.frac_coords)[0], dtype=float
    )

    values: list[float] = []
    names: list[str] = []
    for axis, coordinate in zip("abc", fractional, strict=True):
        values.extend(
            [math.sin(2.0 * math.pi * float(coordinate)), math.cos(2.0 * math.pi * float(coordinate))]
        )
        names.extend([f"candidate_frac_{axis}_sin", f"candidate_frac_{axis}_cos"])

    values.extend(float(value) / 10.0 for value in lattice.lengths)
    names.extend(["lattice_a_over_10", "lattice_b_over_10", "lattice_c_over_10"])
    values.extend(math.cos(math.radians(float(value))) for value in lattice.angles)
    names.extend(["lattice_alpha_cos", "lattice_beta_cos", "lattice_gamma_cos"])
    values.append(float(lattice.volume) / max(len(structure), 1) / 100.0)
    names.append("lattice_volume_per_framework_atom_over_100")

    values.extend(
        [
            inserted_species / 94.0,
            len(structure) / 128.0,
            len(set(int(value) for value in species)) / 10.0,
        ]
    )
    names.extend(
        [
            "inserted_atomic_number_over_94",
            "framework_atom_count_over_128",
            "framework_element_count_over_10",
        ]
    )

    for index, center in enumerate(RBF_CENTERS_ANGSTROM):
        weights = np.exp(-0.5 * ((distances - center) / RBF_WIDTH_ANGSTROM) ** 2)
        scale = 12.0
        values.extend(
            [
                float(np.sum(weights)) / scale,
                float(np.sum(weights * species / 94.0)) / scale,
                float(np.sum(weights * np.abs(species - inserted_species) / 94.0)) / scale,
                float(np.sum(weights * (species == inserted_species))) / scale,
            ]
        )
        names.extend(
            [
                f"rbf_{index}_count",
                f"rbf_{index}_atomic_number",
                f"rbf_{index}_species_mismatch",
                f"rbf_{index}_same_species",
            ]
        )

    nearest = sorted(float(value) for value in distances)[:8]
    nearest.extend([6.0] * (8 - len(nearest)))
    values.extend(min(value, 6.0) / 6.0 for value in nearest)
    names.extend(f"nearest_periodic_distance_{index}_over_6" for index in range(8))

    cutoffs = _cutoffs_from_state(state)
    coordinated = np.asarray(
        [
            index
            for index, (atomic_number, distance) in enumerate(zip(species, distances, strict=True))
            if (cutoff := cutoffs.get(tuple(sorted((inserted_species, int(atomic_number))))))
            is not None
            and float(distance) <= float(cutoff) + 1e-12
        ],
        dtype=int,
    )
    neighbor_species = species[coordinated] if coordinated.size else np.asarray([], dtype=float)
    neighbor_distances = distances[coordinated] if coordinated.size else np.asarray([], dtype=float)
    values.extend(
        [
            len(coordinated) / 12.0,
            float(np.sum(neighbor_species == inserted_species)) / 12.0,
            float(np.mean(neighbor_species)) / 94.0 if coordinated.size else 0.0,
            float(np.std(neighbor_species)) / 94.0 if coordinated.size else 0.0,
            min(float(np.min(distances)), 5.0) / 5.0,
            min(float(np.mean(neighbor_distances)), 5.0) / 5.0 if coordinated.size else 1.0,
        ]
    )
    names.extend(
        [
            "candidate_coordination_over_12",
            "candidate_same_species_coordination_over_12",
            "candidate_neighbor_atomic_number_mean_over_94",
            "candidate_neighbor_atomic_number_std_over_94",
            "candidate_minimum_periodic_distance_over_5",
            "candidate_coordinated_distance_mean_over_5",
        ]
    )

    pbc_residual = float(
        np.sum(np.maximum(-raw_fractional, 0.0) + np.maximum(raw_fractional - 1.0, 0.0))
    )
    values.extend([float(candidate["short_contact_residual"]), pbc_residual])
    names.extend(["short_contact_residual", "pbc_legality_residual"])
    if len(values) != GEOMETRY_FEATURE_N:
        raise AssertionError(f"geometry feature count drifted: {len(values)}")
    return values, names


def _response_features(state: Mapping[str, object]) -> tuple[list[float], list[str]]:
    levels = (
        "LEVEL1_SINGLE_SITE",
        "LEVEL2_COUPLED_SITE_PAIR",
        "LEVEL3_STRUCTURAL_UNIT",
    )
    arms = ("STATIC", "LOCAL_RESPONSE", "GLOBAL_RESPONSE")
    level = str(state["severity_level"])
    arm = str(state["response_arm"])
    if level not in levels or arm not in arms:
        raise ValueError("unknown severity level or response arm")
    values = [float(level == value) for value in levels]
    names = [f"severity_{value.lower()}" for value in levels]
    values.extend(float(arm == value) for value in arms)
    names.extend(f"response_arm_{value.lower()}" for value in arms)

    removed = np.asarray([int(value) for value in state["removed_species"]], dtype=float)
    values.extend(
        [
            len(removed) / 3.0,
            float(np.mean(removed)) / 94.0 if removed.size else 0.0,
            float(np.std(removed)) / 94.0 if removed.size else 0.0,
            float(np.max(removed)) / 94.0 if removed.size else 0.0,
        ]
    )
    names.extend(
        [
            "removed_site_count_over_3",
            "removed_atomic_number_mean_over_94",
            "removed_atomic_number_std_over_94",
            "removed_atomic_number_max_over_94",
        ]
    )

    coordination = list(state["removed_local_coordination"].values())
    totals = np.asarray([float(row["total"]) for row in coordination], dtype=float)
    neighbor_numbers = []
    for row in coordination:
        for atomic_number, count in row["species_counts"].items():
            neighbor_numbers.extend([int(atomic_number)] * int(count))
    values.extend(
        [
            float(np.mean(totals)) / 12.0 if totals.size else 0.0,
            float(np.max(totals)) / 12.0 if totals.size else 0.0,
            float(np.mean(neighbor_numbers)) / 94.0 if neighbor_numbers else 0.0,
        ]
    )
    names.extend(
        [
            "removed_coordination_mean_over_12",
            "removed_coordination_max_over_12",
            "removed_neighbor_atomic_number_mean_over_94",
        ]
    )

    displacement = state["displacement_summary"]
    values.append(float(state["framework_response_magnitude"]))
    names.append("framework_response_magnitude")
    values.extend(
        [
            min(float(displacement["p50_displacement_angstrom"]) / 0.25, 2.0),
            min(float(displacement["p90_displacement_angstrom"]) / 0.75, 2.0),
            min(float(displacement["maximum_displacement_angstrom"]) / 1.50, 2.0),
        ]
    )
    names.extend(
        [
            "response_displacement_p50_scaled",
            "response_displacement_p90_scaled",
            "response_displacement_max_scaled",
        ]
    )
    values.extend(
        [
            float(state["edge_retention"]),
            float(state["edge_creation"]),
            float(state["edge_deletion"]),
            float(state["coordination_change"]),
        ]
    )
    names.extend(
        [
            "response_edge_retention",
            "response_edge_creation",
            "response_edge_deletion",
            "response_coordination_change",
        ]
    )
    if len(values) != RESPONSE_FEATURE_N:
        raise AssertionError(f"response feature count drifted: {len(values)}")
    return values, names


def derive_feature_vector(
    state: Mapping[str, object],
    *,
    static_state: Mapping[str, object],
    candidate: Mapping[str, object],
    static_candidate: Mapping[str, object] | None = None,
    include_response: bool,
) -> tuple[np.ndarray, tuple[str, ...]]:
    geometry_state = state if include_response else static_state
    geometry_candidate = (
        candidate
        if include_response
        else (candidate if static_candidate is None else static_candidate)
    )
    geometry, geometry_names = _geometry_features(geometry_state, geometry_candidate)
    response, response_names = _response_features(state)
    if not include_response:
        response = [0.0] * len(response)
    output = np.asarray([*geometry, *response], dtype=np.float32)
    if not np.isfinite(output).all():
        raise ValueError("derived features are nonfinite")
    return output, tuple([*geometry_names, *response_names])


class MatchedMLP(nn.Module):
    def __init__(self, input_n: int, hidden_n: int = 128) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(input_n, hidden_n),
            nn.SiLU(),
            nn.Linear(hidden_n, hidden_n),
            nn.SiLU(),
            nn.Linear(hidden_n, 1),
        )

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        return self.network(values).squeeze(-1)


class _SplineKANLayer(nn.Module):
    def __init__(
        self,
        input_n: int,
        output_n: int,
        *,
        grid_n: int = 5,
        spline_order: int = 3,
    ) -> None:
        super().__init__()
        if input_n <= 0 or output_n <= 0 or grid_n <= 0 or spline_order <= 0:
            raise ValueError("KAN dimensions and grid must be positive")
        self.input_n = int(input_n)
        self.output_n = int(output_n)
        self.grid_n = int(grid_n)
        self.spline_order = int(spline_order)
        step = 6.0 / grid_n
        knots = (
            torch.arange(-spline_order, grid_n + spline_order + 1, dtype=torch.float32)
            * step
            - 3.0
        )
        self.register_buffer("knots", knots)
        basis_n = grid_n + spline_order
        self.base_weight = nn.Parameter(torch.empty(output_n, input_n))
        self.spline_weight = nn.Parameter(torch.empty(output_n, input_n, basis_n))
        self.bias = nn.Parameter(torch.zeros(output_n))
        nn.init.xavier_uniform_(self.base_weight)
        nn.init.normal_(self.spline_weight, mean=0.0, std=0.02)

    def _basis(self, values: torch.Tensor) -> torch.Tensor:
        clipped = torch.clamp(values, -3.0, 3.0).unsqueeze(-1)
        knots = self.knots.to(dtype=values.dtype)
        basis = ((clipped >= knots[:-1]) & (clipped < knots[1:])).to(values.dtype)
        for degree in range(1, self.spline_order + 1):
            new_n = basis.shape[-1] - 1
            left_denominator = knots[degree : degree + new_n] - knots[:new_n]
            right_denominator = (
                knots[degree + 1 : degree + 1 + new_n] - knots[1 : 1 + new_n]
            )
            left = (
                (clipped - knots[:new_n])
                / torch.where(left_denominator == 0, torch.ones_like(left_denominator), left_denominator)
                * basis[..., :new_n]
            )
            right = (
                (knots[degree + 1 : degree + 1 + new_n] - clipped)
                / torch.where(right_denominator == 0, torch.ones_like(right_denominator), right_denominator)
                * basis[..., 1 : new_n + 1]
            )
            basis = left + right
        return basis

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        base = F.silu(values) @ self.base_weight.T
        spline = torch.einsum("nib,oib->no", self._basis(values), self.spline_weight)
        return base + spline + self.bias


class SplineKAN(nn.Module):
    def __init__(self, input_n: int, hidden_n: int = 32) -> None:
        super().__init__()
        self.first = _SplineKANLayer(input_n, hidden_n)
        self.second = _SplineKANLayer(hidden_n, 1)

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        return self.second(torch.tanh(self.first(values))).squeeze(-1)


class ConstraintKAN(nn.Module):
    def __init__(self, input_n: int, hidden_n: int = 32) -> None:
        super().__init__()
        self.learned = SplineKAN(input_n, hidden_n)

    def forward(self, values: torch.Tensor, hard_residual: torch.Tensor) -> torch.Tensor:
        return self.learned(values) + hard_residual


def trainable_parameter_count(model: nn.Module) -> int:
    return sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)


def fit_standardization(values: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    array = np.asarray(values, dtype=float)
    mean = np.mean(array, axis=0)
    scale = np.std(array, axis=0)
    scale = np.where(scale > 1e-8, scale, 1.0)
    return mean, scale


def train_fixed_regressor(
    model: nn.Module,
    x_train: np.ndarray,
    y_train: np.ndarray,
    *,
    device: str,
    seed: int,
    hard_train: np.ndarray | None = None,
    deadline: float | None = None,
    updates: int = MAX_UPDATES,
) -> dict[str, object]:
    if updates <= 0:
        raise ValueError("training updates must be positive")
    torch.manual_seed(int(seed))
    if device == "cuda":
        torch.cuda.manual_seed_all(int(seed))
    model = model.to(device)
    model.train()
    x_tensor = torch.as_tensor(x_train, dtype=torch.float32, device=device)
    y_tensor = torch.as_tensor(y_train, dtype=torch.float32, device=device)
    hard_tensor = (
        None
        if hard_train is None
        else torch.as_tensor(hard_train, dtype=torch.float32, device=device)
    )
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=LEARNING_RATE, weight_decay=WEIGHT_DECAY
    )
    generator = torch.Generator(device="cpu")
    generator.manual_seed(int(seed))
    final_loss = math.nan
    for _ in range(updates):
        if deadline is not None and time.monotonic() >= deadline:
            raise TimeoutError("compatibility operator reached the total deadline")
        indices = torch.randint(
            0,
            len(x_tensor),
            (min(BATCH_SIZE, len(x_tensor)),),
            generator=generator,
        ).to(device)
        optimizer.zero_grad(set_to_none=True)
        if isinstance(model, ConstraintKAN):
            if hard_tensor is None:
                raise ValueError("ConstraintKAN requires hard residuals")
            prediction = model(x_tensor[indices], hard_tensor[indices])
        else:
            prediction = model(x_tensor[indices])
        loss = F.huber_loss(prediction, y_tensor[indices], delta=1.0)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        optimizer.step()
        final_loss = float(loss.detach().cpu())
    return {"model": model, "final_training_loss": final_loss}


@torch.no_grad()
def predict_regressor(
    model: nn.Module,
    values: np.ndarray,
    *,
    device: str,
    hard_residual: np.ndarray | None = None,
) -> np.ndarray:
    model.eval()
    tensor = torch.as_tensor(values, dtype=torch.float32, device=device)
    outputs = []
    for start in range(0, len(tensor), 2048):
        batch = tensor[start : start + 2048]
        if isinstance(model, ConstraintKAN):
            if hard_residual is None:
                raise ValueError("ConstraintKAN requires hard residuals")
            hard = torch.as_tensor(
                hard_residual[start : start + 2048], dtype=torch.float32, device=device
            )
            prediction = model(batch, hard)
        else:
            prediction = model(batch)
        outputs.append(prediction.detach().cpu().numpy())
    return np.concatenate(outputs) if outputs else np.asarray([], dtype=float)


def ranking_group_metrics(
    *,
    force: np.ndarray,
    prediction: np.ndarray,
    contact_residual: np.ndarray,
    k: int = 5,
) -> dict[str, float]:
    force = np.asarray(force, dtype=float)
    prediction = np.asarray(prediction, dtype=float)
    contact = np.asarray(contact_residual, dtype=float)
    if not (len(force) == len(prediction) == len(contact)) or len(force) == 0:
        raise ValueError("ranking arrays must have the same positive length")
    if not np.isfinite(force).all() or not np.isfinite(prediction).all():
        raise ValueError("ranking arrays must be finite")
    y = np.log1p(force)
    relevance = float(np.max(y)) - y
    ordered = np.argsort(prediction, kind="stable")[: min(k, len(force))]
    ideal = np.argsort(y, kind="stable")[: min(k, len(force))]

    def dcg(indices: np.ndarray) -> float:
        gains = np.exp2(relevance[indices]) - 1.0
        discounts = np.log2(np.arange(2, len(indices) + 2, dtype=float))
        return float(np.sum(gains / discounts))

    ideal_dcg = dcg(ideal)
    ndcg = dcg(ordered) / ideal_dcg if ideal_dcg > 0.0 else 1.0
    left, right = np.triu_indices(len(force), k=1)
    true_difference = y[left] - y[right]
    predicted_difference = prediction[left] - prediction[right]
    informative = np.abs(true_difference) > 1e-12
    products = true_difference[informative] * predicted_difference[informative]
    if products.size:
        pairwise = float(np.mean(np.where(products > 0.0, 1.0, np.where(products == 0.0, 0.5, 0.0))))
    else:
        pairwise = 1.0
    top1 = int(np.argmin(prediction))
    quartile_n = max(1, int(math.ceil(len(force) / 4.0)))
    top_quartile = np.argsort(prediction, kind="stable")[:quartile_n]
    return {
        "ndcg5": float(ndcg),
        "pairwise_accuracy": pairwise,
        "top1_force": float(force[top1]),
        "top1_finite": float(np.isfinite(force[top1])),
        "top1_contact_failure": float(contact[top1] > 0.0),
        "top_quartile_force_median": float(np.median(force[top_quartile])),
    }


def regression_metrics(force: np.ndarray, prediction_log_force: np.ndarray) -> dict[str, float]:
    force = np.asarray(force, dtype=float)
    truth = np.log1p(force)
    prediction = np.asarray(prediction_log_force, dtype=float)
    error = prediction - truth
    if len(force) < 2:
        raise ValueError("regression metrics require at least two samples")
    pearson = float(pearsonr(truth, prediction).statistic)
    spearman = float(spearmanr(truth, prediction).statistic)
    return {
        "mae": float(np.mean(np.abs(error))),
        "rmse": float(np.sqrt(np.mean(np.square(error)))),
        "pearson": pearson,
        "spearman": spearman,
    }


def _directional_fold_n(
    better: Mapping[str, object], worse: Mapping[str, object]
) -> int:
    return sum(
        float(left_ndcg) > float(right_ndcg)
        and float(left_force) < float(right_force)
        for left_ndcg, right_ndcg, left_force, right_force in zip(
            better["fold_ndcg5"],
            worse["fold_ndcg5"],
            better["fold_top1_force_median"],
            worse["fold_top1_force_median"],
            strict=True,
        )
    )


def compatibility_operator_verdict(
    *,
    mlp_full: Mapping[str, object],
    mlp_no_response: Mapping[str, object],
    kan_full: Mapping[str, object],
    constraint_kan_full: Mapping[str, object],
    random_baseline: Mapping[str, object],
) -> dict[str, object]:
    response_directional = _directional_fold_n(mlp_full, mlp_no_response)
    response_supported = bool(
        float(mlp_full["mean_ndcg5"]) > float(mlp_no_response["mean_ndcg5"])
        and float(mlp_full["top1_force_median"])
        < float(mlp_no_response["top1_force_median"])
        and response_directional >= 3
    )
    kan_directional = _directional_fold_n(kan_full, mlp_full)
    kan_supported = bool(
        float(kan_full["mean_ndcg5"]) > float(mlp_full["mean_ndcg5"])
        and float(kan_full["top1_force_median"]) < float(mlp_full["top1_force_median"])
        and kan_directional >= 3
    )
    constraint_supported = bool(
        float(constraint_kan_full["contact_failure_rate"])
        < float(kan_full["contact_failure_rate"])
        and float(constraint_kan_full["mean_ndcg5"]) >= float(kan_full["mean_ndcg5"])
        and float(constraint_kan_full["top1_force_median"])
        <= float(kan_full["top1_force_median"])
    )
    static_directional = _directional_fold_n(mlp_no_response, random_baseline)
    static_predictive = bool(
        float(mlp_no_response["mean_ndcg5"]) > float(random_baseline["mean_ndcg5"])
        and float(mlp_no_response["top1_force_median"])
        < float(random_baseline["top1_force_median"])
        and static_directional >= 3
    )
    if response_supported:
        learned = "SUPPORTED"
        next_operator = "KAN" if kan_supported else "MLP"
        next_action = "DESIGN_CRYSALIS_V3_REASSEMBLY_MODEL"
    elif static_predictive:
        learned = "STATIC_ONLY"
        next_operator = "NONE"
        next_action = "REASSESS_RESPONSE_AWARE_NOVELTY"
    else:
        learned = "NOT_SUPPORTED"
        next_operator = "NONE"
        next_action = "STOP_COMPATIBILITY_OPERATOR_BRANCH"
    return {
        "RESPONSE_INFORMATION_INCREMENTAL_VALUE": (
            "SUPPORTED" if response_supported else "NOT_SUPPORTED"
        ),
        "KAN_OPERATOR_VALUE": "SUPPORTED" if kan_supported else "NOT_SUPPORTED",
        "CONSTRAINT_OPERATOR_VALUE": (
            "SUPPORTED" if constraint_supported else "NOT_SUPPORTED"
        ),
        "LEARNED_COMPATIBILITY_FIELD": learned,
        "NEXT_OPERATOR": next_operator,
        "NEXT_ACTION": next_action,
        "response_directional_fold_n": response_directional,
        "kan_directional_fold_n": kan_directional,
        "static_directional_fold_n": static_directional,
    }


def check_replay_match(
    frozen: Mapping[str, object], replay: Mapping[str, object]
) -> dict[str, object]:
    tolerances = {
        "LEVEL1_RESPONSE_MEDIAN": 5e-4,
        "LEVEL2_RESPONSE_MEDIAN": 5e-4,
        "LEVEL3_RESPONSE_MEDIAN": 5e-4,
        "ASSEMBLY_SCORE_FORCE_CORRELATION": 1e-3,
        "BEST_QUARTILE_FORCE_MEDIAN": 1e-6,
        "WORST_QUARTILE_FORCE_MEDIAN": 1e-6,
    }
    differences = {
        key: abs(float(replay[key]) - float(frozen[key])) for key in tolerances
    }
    return {
        "REPLAY_MATCH": all(differences[key] <= tolerances[key] for key in tolerances),
        "absolute_differences": differences,
        "absolute_tolerances": tolerances,
    }


__all__ = [
    "BATCH_SIZE",
    "GEOMETRY_FEATURE_N",
    "LEARNING_RATE",
    "MAX_UPDATES",
    "RESPONSE_FEATURE_N",
    "ConstraintKAN",
    "MatchedMLP",
    "SplineKAN",
    "audit_state_candidate_join",
    "check_replay_match",
    "compatibility_operator_verdict",
    "derive_feature_vector",
    "fit_standardization",
    "predict_regressor",
    "ranking_group_metrics",
    "regression_metrics",
    "stable_parent_folds",
    "train_fixed_regressor",
    "trainable_parameter_count",
]
