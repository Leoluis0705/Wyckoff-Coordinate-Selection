from __future__ import annotations

import hashlib
import json
import math
import time
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Sequence

import numpy as np
import torch
from pymatgen.analysis.structure_matcher import StructureMatcher
from pymatgen.core import Lattice, Structure

from crysalis_g1.experiments.c0_symmetry_data import (
    C0SymmetryExample,
    collate_c0_symmetry_examples,
    decode_lattice_degrees,
    verify_frozen_phase2a,
)
from crysalis_g1.experiments.c0_symmetry_oracle import load_recovered_parents
from crysalis_g1.experiments.chgnet_terminal import (
    CHGNetEvaluationConfig,
    CHGNetTerminalEvaluator,
)
from crysalis_g1.experiments.final_diagnostic_v1 import (
    perturb_control_parent,
    select_control_parents,
)
from crysalis_g1.model.c0_symmetry import C0SymmetryConfig, C0SymmetryModel
from crysalis_g1.symmetry.assembly import (
    AddOrbitAction,
    C0SymmetryProjector,
    LegalAddOrbit,
    SpaceGroupLegalActionCompiler,
    SymmetryAssemblyState,
)
from crysalis_g1.symmetry.wyckoff import SpaceGroupConstrainedLatticeHead


@dataclass(frozen=True, slots=True)
class ConditionSource:
    material_id: str
    canonical_structure_hash: str
    composition: tuple[tuple[int, int], ...]
    space_group: int


def build_parent_free_conditions(
    sources: Sequence[ConditionSource], *, count: int, root_seed: int
) -> list[dict[str, Any]]:
    if count <= 0:
        raise ValueError("condition count must be positive")
    if not sources:
        raise ValueError("condition sources must not be empty")
    candidates = sorted(
        sources,
        key=lambda source: hashlib.sha256(
            f"condition-order:{root_seed}:{source.canonical_structure_hash}".encode()
        ).hexdigest(),
    )
    conditions = []
    for attempt_index in range(count):
        source = candidates[attempt_index % len(candidates)]
        condition_seed = int.from_bytes(
            hashlib.sha256(
                f"condition-seed:{root_seed}:{attempt_index}".encode()
            ).digest()[:8],
            "big",
        ) % (2**31 - 1)
        public = {
            "attempt_index": attempt_index,
            "root_seed": root_seed,
            "condition_seed": condition_seed,
            "composition": [list(item) for item in source.composition],
            "space_group": source.space_group,
        }
        condition_id = "condition-" + hashlib.sha256(
            json.dumps(public, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()
        conditions.append({"condition_id": condition_id, **public})
    return conditions


def load_validation_condition_sources(
    phase2a_root: str | Path, recovered_parent_cache: str | Path
) -> tuple[ConditionSource, ...]:
    root = Path(phase2a_root)
    verify_frozen_phase2a(root)
    parents = load_recovered_parents(recovered_parent_cache)
    sources = []
    with (root / "splits" / "structure_ood_manifest.jsonl").open(
        encoding="utf-8"
    ) as stream:
        for line in stream:
            row = json.loads(line)
            if row["split"] != "validation":
                continue
            parent = parents.get(str(row["material_id"]))
            if parent is None:
                continue
            composition = Counter(parent.reconstructed_atomic_numbers)
            sources.append(
                ConditionSource(
                    material_id=parent.material_id,
                    canonical_structure_hash=str(row["canonical_structure_hash"]),
                    composition=tuple(sorted(composition.items())),
                    space_group=parent.target_space_group,
                )
            )
    if not sources:
        raise ValueError("no validation condition sources are available")
    return tuple(sources)


def load_c0_symmetry_checkpoint(
    checkpoint_path: str | Path, *, device: str
) -> tuple[C0SymmetryModel, dict[str, Any]]:
    payload = torch.load(checkpoint_path, map_location=device, weights_only=False)
    if payload.get("schema_version") != "g1-c0-symmetry-checkpoint.1.0.0":
        raise ValueError("unsupported C0-Symmetry checkpoint schema")
    if payload.get("old_checkpoint_loaded") is not False:
        raise ValueError("checkpoint does not prove fresh initialization")
    config = C0SymmetryConfig(**payload["model_config"])
    model = C0SymmetryModel(config).to(device)
    model.load_state_dict(payload["model_state"], strict=True)
    model.eval()
    return model, payload


def _canonical_cell_transform(index: int) -> tuple[tuple[int, int, int], ...]:
    if index <= 0:
        raise ValueError("cell index must be positive")
    return ((index, 0, 0), (0, 1, 0), (0, 0, 1))


def _embryo_lattice(space_group: int, site_count: int):
    length = max(3.0, (18.0 * site_count) ** (1.0 / 3.0))
    return SpaceGroupConstrainedLatticeHead().constrain(
        space_group, (length, length * 1.03, length * 1.07, 90.0, 90.0, 100.0)
    )


def _inference_example(
    condition: dict[str, Any],
    state: SymmetryAssemblyState,
    legal_actions: Iterable[LegalAddOrbit],
) -> C0SymmetryExample:
    return C0SymmetryExample(
        material_id=str(condition["condition_id"]),
        split="free_rollout",
        sequence_hash="",
        step_index=len(state.orbits),
        target_space_group=state.target_space_group,
        composition=state.composition,
        lattice=state.lattice,
        active_orbits=state.orbits,
        target_orbit=None,
        legal_action_pairs=tuple(
            sorted(
                {
                    (action.wyckoff_letter, action.species, action.multiplicity)
                    for action in legal_actions
                }
            )
        ),
        input_lattice_override=state.lattice,
    )


def _model_output(
    model: C0SymmetryModel,
    example: C0SymmetryExample,
    *,
    device: str,
):
    orbit_slots = max(1, len(example.active_orbits))
    batch = collate_c0_symmetry_examples(
        (example,), maximum_orbits=min(model.config.maximum_orbits, orbit_slots)
    ).to(device)
    with torch.no_grad():
        return model(batch)


def _choose_action(
    output: Any,
    legal_actions: Sequence[LegalAddOrbit],
    *,
    rng: np.random.Generator,
    temperature: float,
) -> LegalAddOrbit:
    if not legal_actions:
        raise ValueError("cannot choose from an empty legal action set")
    scores = []
    for action in legal_actions:
        wyckoff_index = ord(action.wyckoff_letter) - ord("a")
        score = (
            output.wyckoff_logits[0, wyckoff_index]
            + output.species_logits[0, action.species]
            + output.multiplicity_logits[0, action.multiplicity]
        )
        scores.append(float(score.detach().cpu()))
    array = np.asarray(scores, dtype=float) / temperature
    array -= array.max()
    probabilities = np.exp(array)
    probabilities /= probabilities.sum()
    return legal_actions[int(rng.choice(len(legal_actions), p=probabilities))]


def generate_attempts(
    model: C0SymmetryModel,
    conditions: Sequence[dict[str, Any]],
    *,
    device: str,
    minimum_distance: float = 0.5,
    temperature: float = 0.8,
) -> list[dict[str, Any]]:
    if not conditions:
        raise ValueError("free rollout conditions must not be empty")
    records = []
    compiler = SpaceGroupLegalActionCompiler(max_sites=model.config.maximum_sites)
    projector = C0SymmetryProjector(minimum_distance=minimum_distance)
    for condition in conditions:
        started = time.perf_counter()
        composition = tuple(
            (int(atomic_number), int(count))
            for atomic_number, count in condition["composition"]
        )
        target_space_group = int(condition["space_group"])
        rng = np.random.default_rng(int(condition["condition_seed"]))
        site_count = sum(count for _, count in composition)
        placeholder = _embryo_lattice(target_space_group, site_count)
        embryo_state = SymmetryAssemblyState.empty(
            target_space_group=target_space_group,
            composition=composition,
            lattice=placeholder,
        )
        embryo_output = _model_output(
            model,
            _inference_example(condition, embryo_state, ()),
            device=device,
        )
        cell_logits = embryo_output.cell_index_logits[0].detach().cpu().clone()
        cell_logits[0] = -math.inf
        cell_index = int(cell_logits.argmax())
        predicted_degrees = (
            embryo_output.lattice_degree_prediction[0].detach().cpu().tolist()
        )
        lattice = decode_lattice_degrees(
            target_space_group,
            predicted_degrees,
            cell_transform=_canonical_cell_transform(cell_index),
        )
        state = SymmetryAssemblyState.empty(
            target_space_group=target_space_group,
            composition=composition,
            lattice=lattice,
        )
        actions: list[dict[str, Any]] = []
        receipts = []
        failure_code: str | None = None
        completed = False
        terminal_receipt = None
        for step_index in range(model.config.maximum_orbits + 1):
            legal_actions = compiler.legal_add_actions(state)
            output = _model_output(
                model,
                _inference_example(condition, state, legal_actions),
                device=device,
            )
            termination_requested = bool(
                int(output.terminate_logits[0].argmax().detach().cpu()) == 1
            )
            if not state.remaining_composition:
                terminal_receipt = projector.project(state)
                receipts.append(terminal_receipt)
                if termination_requested and compiler.can_terminate(
                    state, terminal_receipt
                ):
                    completed = True
                else:
                    failure_code = (
                        "TERMINATION_NOT_SELECTED"
                        if terminal_receipt.accepted
                        else "TERMINAL_PROJECTOR_REJECTED"
                    )
                break
            if not legal_actions:
                failure_code = "NO_LEGAL_ADD_ORBIT_ACTION"
                break
            selected = _choose_action(
                output,
                legal_actions,
                rng=rng,
                temperature=temperature,
            )
            free = tuple(
                float(value)
                for value in output.free_parameter_prediction[
                    0, : selected.free_parameter_count
                ]
                .detach()
                .cpu()
                .tolist()
            )
            orbit_id = f"{condition['condition_id']}:orbit:{step_index}"
            next_state = compiler.apply_add(
                state,
                AddOrbitAction(
                    selected.wyckoff_letter,
                    selected.species,
                    free,
                    orbit_id,
                ),
            )
            receipt = projector.project(next_state)
            receipts.append(receipt)
            actions.append(
                {
                    "step_index": step_index,
                    "wyckoff_position_id": selected.wyckoff_position_id,
                    "wyckoff_letter": selected.wyckoff_letter,
                    "species": selected.species,
                    "multiplicity": selected.multiplicity,
                    "free_parameters": list(free),
                    "orbit_instance_id": orbit_id,
                    "termination_requested_while_illegal": termination_requested,
                    "projector": receipt.to_dict(),
                }
            )
            if not receipt.accepted:
                failure_code = "PROJECTOR_REJECTED"
                break
            state = next_state
        else:
            failure_code = "MAXIMUM_ORBIT_STEPS_EXCEEDED"
        final_receipt = terminal_receipt or (receipts[-1] if receipts else None)
        detected_space_group = (
            int(final_receipt.detected_space_groups.get(0.03, 0))
            if final_receipt is not None
            else 0
        )
        target_match = detected_space_group == target_space_group
        legal_terminal = bool(
            completed
            and final_receipt is not None
            and final_receipt.accepted
            and target_match
        )
        candidate = None
        if legal_terminal and final_receipt is not None:
            candidate = {
                "atomic_numbers": list(final_receipt.atomic_numbers),
                "fractional_coordinates": [
                    list(value) for value in final_receipt.fractional_coordinates
                ],
                "lattice": [list(value) for value in final_receipt.lattice],
                "orbit_states": [asdict(orbit) for orbit in state.orbits],
            }
        rejection_reasons = [
            reason
            for receipt in receipts
            if not receipt.accepted
            for reason in receipt.reason_codes
        ]
        records.append(
            {
                "condition": dict(condition),
                "selected_cell_index": cell_index,
                "selected_lattice_degrees": predicted_degrees,
                "selected_lattice": [list(value) for value in lattice.primitive_matrix],
                "actions": actions,
                "completed": completed,
                "legal_terminal_crystal": legal_terminal,
                "failure_code": failure_code,
                "pre_projector_target_space_group_match": target_match,
                "post_projector_target_space_group_match": target_match,
                "wyckoff_orbit_valid": bool(
                    final_receipt
                    and final_receipt.orbit_membership_valid
                    and final_receipt.distinct_orbit_instances_valid
                ),
                "composition_valid": bool(
                    final_receipt and final_receipt.composition_valid
                ),
                "multiplicity_valid": bool(
                    final_receipt and final_receipt.multiplicity_valid
                ),
                "short_contact_free": bool(
                    final_receipt and final_receipt.minimum_distance_valid
                ),
                "detected_space_group": detected_space_group,
                "projector_attempt_count": len(receipts),
                "projector_rejection_count": sum(
                    not receipt.accepted for receipt in receipts
                ),
                "projector_rejection_reasons": rejection_reasons,
                "candidate": candidate,
                "latency_seconds": time.perf_counter() - started,
                "retry_count": 0,
                "refill_count": 0,
            }
        )
    return records


def summarize_generation(records: Sequence[dict[str, Any]]) -> dict[str, Any]:
    if not records:
        raise ValueError("generation records must not be empty")
    count = len(records)
    projector_attempts = sum(int(row["projector_attempt_count"]) for row in records)
    projector_rejections = sum(
        int(row["projector_rejection_count"]) for row in records
    )
    taxonomy = Counter(
        reason for row in records for reason in row["projector_rejection_reasons"]
    )
    latencies = np.asarray([float(row["latency_seconds"]) for row in records])
    return {
        "schema_version": "g1-c0-symmetry-generation.1.0.0",
        "attempt_count": count,
        "failure_denominator_includes_all_attempts": True,
        "refill_count": sum(int(row.get("refill_count", 0)) for row in records),
        "free_rollout_completion_rate": sum(bool(row["completed"]) for row in records)
        / count,
        "target_space_group_match_rate_pre_projector": sum(
            bool(row["pre_projector_target_space_group_match"]) for row in records
        )
        / count,
        "target_space_group_match_rate_post_projector": sum(
            bool(row["post_projector_target_space_group_match"]) for row in records
        )
        / count,
        "wyckoff_orbit_validity_rate": sum(
            bool(row["wyckoff_orbit_valid"]) for row in records
        )
        / count,
        "composition_validity_rate": sum(
            bool(row["composition_valid"]) for row in records
        )
        / count,
        "multiplicity_validity_rate": sum(
            bool(row["multiplicity_valid"]) for row in records
        )
        / count,
        "symmetry_valid_legal_terminal_rate": sum(
            bool(row["legal_terminal_crystal"]) for row in records
        )
        / count,
        "short_contact_free_rate": sum(
            bool(row["short_contact_free"]) for row in records
        )
        / count,
        "projector_rejection_rate": projector_rejections
        / max(projector_attempts, 1),
        "projector_attempt_count": projector_attempts,
        "projector_rejection_count": projector_rejections,
        "projector_rejection_taxonomy": dict(sorted(taxonomy.items())),
        "generation_latency_p50_seconds": float(np.quantile(latencies, 0.50)),
        "generation_latency_p95_seconds": float(np.quantile(latencies, 0.95)),
        "p1_non_target_counted_as_failure": all(
            not row["legal_terminal_crystal"]
            for row in records
            if int(row.get("detected_space_group", 0)) == 1
            and int(row["condition"]["space_group"]) != 1
        ),
        "failure_taxonomy": dict(
            sorted(
                Counter(
                    str(row.get("failure_code") or "NONE") for row in records
                ).items()
            )
        ),
    }


def _formula_key(atomic_numbers: Iterable[int]) -> tuple[tuple[int, int], ...]:
    counts = Counter(int(value) for value in atomic_numbers)
    divisor = math.gcd(*counts.values()) if counts else 1
    return tuple(
        sorted((atomic_number, count // divisor) for atomic_number, count in counts.items())
    )


def _structure_from_candidate(candidate: dict[str, Any]) -> Structure:
    return Structure(
        Lattice(np.asarray(candidate["lattice"], dtype=float)),
        [int(value) for value in candidate["atomic_numbers"]],
        np.asarray(candidate["fractional_coordinates"], dtype=float),
        to_unit_cell=True,
    )


def structural_uniqueness_and_novelty(
    records: Sequence[dict[str, Any]],
    *,
    phase2a_root: str | Path,
    recovered_parent_cache: str | Path,
) -> dict[str, Any]:
    root = Path(phase2a_root)
    verify_frozen_phase2a(root)
    generated: list[Structure] = []
    parse_failures = 0
    for record in records:
        if not record.get("legal_terminal_crystal"):
            continue
        try:
            generated.append(_structure_from_candidate(record["candidate"]))
        except Exception:
            parse_failures += 1
    matcher = StructureMatcher(
        primitive_cell=False,
        scale=True,
        attempt_supercell=False,
        ltol=0.2,
        stol=0.3,
        angle_tol=5.0,
    )
    representatives: dict[tuple[tuple[int, int], ...], list[Structure]] = {}
    matcher_failures = 0
    for structure in generated:
        key = _formula_key(int(site.specie.Z) for site in structure)
        bucket = representatives.setdefault(key, [])
        try:
            duplicate = any(matcher.fit(structure, prior) for prior in bucket)
        except Exception:
            matcher_failures += 1
            duplicate = False
        if not duplicate:
            bucket.append(structure)
    unique = [structure for bucket in representatives.values() for structure in bucket]
    train_ids = set()
    with (root / "splits" / "structure_ood_manifest.jsonl").open(
        encoding="utf-8"
    ) as stream:
        for line in stream:
            row = json.loads(line)
            if row["split"] == "train_fit":
                train_ids.add(str(row["material_id"]))
    parents = load_recovered_parents(recovered_parent_cache)
    train_buckets: dict[tuple[tuple[int, int], ...], list[Structure]] = {}
    for material_id in train_ids:
        parent = parents.get(material_id)
        if parent is None:
            continue
        key = _formula_key(parent.reconstructed_atomic_numbers)
        train_buckets.setdefault(key, []).append(
            Structure(
                Lattice(parent.lattice.primitive_matrix),
                parent.reconstructed_atomic_numbers,
                parent.reconstructed_fractional_coordinates,
                to_unit_cell=True,
            )
        )
    novel = 0
    for structure in unique:
        key = _formula_key(int(site.specie.Z) for site in structure)
        try:
            is_novel = not any(
                matcher.fit(structure, parent) for parent in train_buckets.get(key, ())
            )
        except Exception:
            matcher_failures += 1
            is_novel = False
        novel += int(is_novel)
    legal_count = len(generated)
    unique_count = len(unique)
    return {
        "novelty_scope": "symmetry-valid legal terminal structures only",
        "legal_terminal_structure_count": legal_count,
        "unique_count": unique_count,
        "unique_rate": unique_count / max(legal_count, 1),
        "novel_count": novel,
        "novelty_rate": novel / max(unique_count, 1),
        "candidate_parse_failure_count": parse_failures,
        "structure_matcher_failure_count": matcher_failures,
        "novelty_reference_split": "train_fit",
        "structure_matcher": {
            "primitive_cell": False,
            "scale": True,
            "attempt_supercell": False,
            "ltol": 0.2,
            "stol": 0.3,
            "angle_tol": 5.0,
        },
    }


def _read_canonical_parents(path: Path) -> Iterable[dict[str, Any]]:
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            yield json.loads(line)


def _control_records(
    phase2a_root: Path, *, root_seed: int
) -> tuple[list[dict[str, Any]], dict[str, str]]:
    selected = select_control_parents(
        _read_canonical_parents(
            phase2a_root / "canonical_cache" / "canonical_parents.jsonl"
        ),
        count=20,
    )
    records = []
    groups: dict[str, str] = {}
    for parent in selected:
        material_id = str(parent["material_id"])
        clean_id = f"MP::{material_id}"
        clean = {
            "condition": {
                "condition_id": clean_id,
                "space_group": int(parent["space_group"]),
            },
            "legal_terminal_crystal": True,
            "candidate": {
                "atomic_numbers": parent["atomic_numbers"],
                "fractional_coordinates": parent["fractional_coordinates"],
                "lattice": parent["lattice"],
            },
        }
        records.append(clean)
        groups[clean_id] = "REAL_MP_CONTROL"
        perturbed = perturb_control_parent(parent, root_seed=root_seed)
        perturbed_id = str(perturbed["sample_id"])
        records.append(
            {
                "condition": {
                    "condition_id": perturbed_id,
                    "space_group": int(parent["space_group"]),
                },
                "legal_terminal_crystal": True,
                "candidate": {
                    "atomic_numbers": perturbed["atomic_numbers"],
                    "fractional_coordinates": perturbed[
                        "fractional_coordinates"
                    ],
                    "lattice": perturbed["lattice"],
                },
                "perturbation": perturbed["perturbation"],
            }
        )
        groups[perturbed_id] = "PERTURBED_MP_CONTROL"
    return records, groups


def _protocol_summary(records: Sequence[dict[str, Any]]) -> dict[str, Any]:
    evaluated = [record for record in records if record["status"] == "EVALUATED"]
    initial_forces = [
        float(record["pre_max_force_ev_per_angstrom"]) for record in evaluated
    ]
    final_forces = [
        float(record["post_max_force_ev_per_angstrom"]) for record in evaluated
    ]
    return {
        "attempt_count": len(records),
        "evaluated_count": len(evaluated),
        "exception_or_skip_count": len(records) - len(evaluated),
        "convergence_count": sum(bool(record["converged"]) for record in records),
        "physical_survival_count": sum(
            bool(record["post_relax_survival"]) for record in records
        ),
        "target_space_group_match_count": sum(
            bool(record.get("space_group_match")) for record in evaluated
        ),
        "symmetry_preserving_survival_count": sum(
            bool(record["post_relax_survival"])
            and bool(record.get("space_group_match"))
            for record in evaluated
        ),
        "initial_max_force_mean_ev_per_angstrom": (
            float(np.mean(initial_forces)) if initial_forces else None
        ),
        "initial_max_force_median_ev_per_angstrom": (
            float(np.median(initial_forces)) if initial_forces else None
        ),
        "final_max_force_mean_ev_per_angstrom": (
            float(np.mean(final_forces)) if final_forces else None
        ),
    }


def run_chgnet_evaluation(
    generation_records: list[dict[str, Any]],
    *,
    phase2a_root: str | Path,
    output_root: str | Path,
    root_seed: int,
    device: str,
    chgnet_config: dict[str, Any],
    prior_control_results: str | Path,
) -> dict[str, Any]:
    phase2a = Path(phase2a_root)
    output = Path(output_root)
    verify_frozen_phase2a(phase2a)
    fixed_config = CHGNetEvaluationConfig(
        package_version=str(chgnet_config["package_version"]),
        model_version=str(chgnet_config["model_version"]),
        weight_path=str(chgnet_config["weight_path"]),
        weight_sha256=str(chgnet_config["weight_sha256"]),
        optimizer=str(chgnet_config["optimizer"]),
        force_threshold_ev_per_angstrom=float(
            chgnet_config["force_threshold_ev_per_angstrom"]
        ),
        maximum_steps=int(chgnet_config["maximum_steps"]),
        relax_cell=False,
        short_contact_distance=float(chgnet_config["short_contact_distance"]),
        device=device,
    )
    cell_config = CHGNetEvaluationConfig(
        **{**asdict(fixed_config), "relax_cell": True}
    )
    fixed_evaluator = CHGNetTerminalEvaluator(fixed_config)
    cell_evaluator = CHGNetTerminalEvaluator(
        cell_config, optimizer=fixed_evaluator.optimizer
    )
    engineering = output / "engineering"
    generated_fixed = fixed_evaluator.evaluate(
        generation_records,
        output_path=engineering / "chgnet_generated_fixed_cell_fire300.json",
    )
    generated_cell = cell_evaluator.evaluate(
        generation_records,
        output_path=engineering / "chgnet_generated_cell_relax_fire300.json",
    )
    controls, control_groups = _control_records(phase2a, root_seed=root_seed)
    controls_fixed = fixed_evaluator.evaluate(
        controls,
        output_path=engineering / "chgnet_controls_fixed_cell_fire300.json",
    )
    controls_cell = cell_evaluator.evaluate(
        controls,
        output_path=engineering / "chgnet_controls_cell_relax_fire300.json",
    )
    control_summary: dict[str, Any] = {}
    for group in ("REAL_MP_CONTROL", "PERTURBED_MP_CONTROL"):
        identifiers = {
            condition_id
            for condition_id, sample_group in control_groups.items()
            if sample_group == group
        }
        control_summary[group] = {
            "fixed_cell_fire300": _protocol_summary(
                [
                    record
                    for record in controls_fixed["records"]
                    if record["condition_id"] in identifiers
                ]
            ),
            "cell_relax_fire300": _protocol_summary(
                [
                    record
                    for record in controls_cell["records"]
                    if record["condition_id"] in identifiers
                ]
            ),
        }
    prior = json.loads(Path(prior_control_results).read_text(encoding="utf-8"))
    prior_summary = prior["summary"]
    controls_normal = all(
        control_summary[group][protocol]["evaluated_count"] == 20
        and control_summary[group][protocol]["convergence_count"]
        == int(
            prior_summary[group][prior_protocol]["final_converged_count"]
        )
        for group in ("REAL_MP_CONTROL", "PERTURBED_MP_CONTROL")
        for protocol, prior_protocol in (
            ("fixed_cell_fire300", "B_FIXED_CELL_FIRE_300"),
            ("cell_relax_fire300", "C_CELL_RELAX_FIRE_300"),
        )
    )
    generated_fixed_summary = _protocol_summary(generated_fixed["records"])
    generated_cell_summary = _protocol_summary(generated_cell["records"])
    fixed_success = {
        record["condition_id"]
        for record in generated_fixed["records"]
        if record["status"] == "EVALUATED" and record["converged"]
    }
    cell_success = {
        record["condition_id"]
        for record in generated_cell["records"]
        if record["status"] == "EVALUATED"
        and record["post_relax_survival"]
    }
    return {
        "schema_version": "g1-c0-symmetry-chgnet.1.0.0",
        "provenance": {
            "package_version": fixed_config.package_version,
            "model_version": fixed_config.model_version,
            "weight_path": fixed_config.weight_path,
            "weight_sha256": fixed_config.weight_sha256,
            "optimizer": fixed_config.optimizer,
            "force_threshold_ev_per_angstrom": fixed_config.force_threshold_ev_per_angstrom,
            "maximum_steps": fixed_config.maximum_steps,
            "checkpoint_selection_role": False,
        },
        "generated": {
            "fixed_cell_fire300": generated_fixed_summary,
            "cell_relax_fire300": generated_cell_summary,
            "converged_or_survived_condition_count": len(
                fixed_success | cell_success
            ),
        },
        "controls": control_summary,
        "prior_control_results_path": str(Path(prior_control_results).resolve()),
        "control_evaluator_behavior_unchanged": controls_normal,
        "controls_normal": controls_normal,
        "raw_artifacts": {
            "generated_fixed_cell": str(
                (engineering / "chgnet_generated_fixed_cell_fire300.json").resolve()
            ),
            "generated_cell_relax": str(
                (engineering / "chgnet_generated_cell_relax_fire300.json").resolve()
            ),
            "controls_fixed_cell": str(
                (engineering / "chgnet_controls_fixed_cell_fire300.json").resolve()
            ),
            "controls_cell_relax": str(
                (engineering / "chgnet_controls_cell_relax_fire300.json").resolve()
            ),
        },
    }
