from __future__ import annotations

import hashlib
import json
import math
import re
import time
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np

from crysalis_g1.experiments.c0_symmetry_data import (
    decode_lattice_degrees,
    verify_frozen_phase2a,
)
from crysalis_g1.experiments.c0_symmetry_evaluation import (
    _canonical_cell_transform,
    _embryo_lattice,
    _inference_example,
    _model_output,
)
from crysalis_g1.model.c0_symmetry import C0SymmetryModel
from crysalis_g1.symmetry.assembly import (
    AddOrbitAction,
    C0SymmetryProjector,
    LegalAddOrbit,
    SpaceGroupLegalActionCompiler,
    SymmetryAssemblyState,
)


_POLICY_NAMESPACES = {
    "policy_attribution:uniform",
    "policy_attribution:empirical",
}
_POLICY_STREAM_NAMESPACE = re.compile(
    r"^policy_attribution:(uniform|empirical):stream:[0-9]{2}$"
)


def _policy_namespace_arm(namespace: str) -> str:
    if namespace in _POLICY_NAMESPACES:
        return namespace.rsplit(":", 1)[-1]
    match = _POLICY_STREAM_NAMESPACE.fullmatch(namespace)
    if match is None:
        raise ValueError(f"unsupported policy-attribution namespace: {namespace}")
    return str(match.group(1))


def derive_policy_seed(
    root_seed: int,
    condition_id: str,
    *,
    namespace: str,
) -> int:
    _policy_namespace_arm(namespace)
    digest = hashlib.sha256(
        f"{int(root_seed)}:{namespace}:{condition_id}".encode("utf-8")
    ).digest()
    return int.from_bytes(digest[:8], "big") % (2**63)


@dataclass(frozen=True, slots=True)
class EmpiricalFrequencyPrior:
    alpha: float
    exact_counts: Mapping[tuple[int, str, int, int], int]
    marginal_counts: Mapping[tuple[int, str, int], int]
    space_group_label_counts: Mapping[int, int]
    label_count: int

    @classmethod
    def from_labels(
        cls,
        labels: Iterable[Mapping[str, Any]],
        *,
        alpha: float,
    ) -> EmpiricalFrequencyPrior:
        if alpha <= 0:
            raise ValueError("Laplace alpha must be positive")
        exact: Counter[tuple[int, str, int, int]] = Counter()
        marginal: Counter[tuple[int, str, int]] = Counter()
        by_space_group: Counter[int] = Counter()
        label_count = 0
        for label in labels:
            if str(label["split"]) != "train_fit":
                raise ValueError("empirical prior accepts train_fit labels only")
            space_group = int(label["target_space_group"])
            position_id = str(label["wyckoff_position_id"])
            multiplicity = int(label["multiplicity"])
            species = int(label["species"])
            exact[(space_group, position_id, multiplicity, species)] += 1
            marginal[(space_group, position_id, multiplicity)] += 1
            by_space_group[space_group] += 1
            label_count += 1
        if label_count == 0:
            raise ValueError("empirical prior requires at least one train_fit label")
        return cls(
            alpha=float(alpha),
            exact_counts=dict(exact),
            marginal_counts=dict(marginal),
            space_group_label_counts=dict(by_space_group),
            label_count=label_count,
        )

    def to_dict(self, *, audit: Mapping[str, Any]) -> dict[str, Any]:
        exact = [
            {
                "target_space_group": key[0],
                "wyckoff_position_id": key[1],
                "multiplicity": key[2],
                "species": key[3],
                "count": count,
            }
            for key, count in sorted(self.exact_counts.items())
        ]
        marginal = [
            {
                "target_space_group": key[0],
                "wyckoff_position_id": key[1],
                "multiplicity": key[2],
                "count": count,
            }
            for key, count in sorted(self.marginal_counts.items())
        ]
        return {
            "schema_version": "g1-policy-attribution-empirical-prior.1.0.0",
            "training_split_used": ["train_fit"],
            "validation_or_test_frequency_used": False,
            "alpha": self.alpha,
            "label_count": self.label_count,
            "space_group_label_counts": {
                str(key): value
                for key, value in sorted(self.space_group_label_counts.items())
            },
            "exact_counts": exact,
            "marginal_counts": marginal,
            "audit": dict(audit),
        }


def collect_train_fit_inverse_labels(
    *,
    split_rows: Iterable[Mapping[str, Any]],
    parent_rows: Iterable[Mapping[str, Any]],
    trajectory_rows: Iterable[Mapping[str, Any]],
) -> tuple[list[dict[str, Any]], dict[str, int]]:
    train_ids = {
        str(row["material_id"])
        for row in split_rows
        if str(row["split"]) == "train_fit"
    }
    if not train_ids:
        raise ValueError("Structure-OOD split has no train_fit parents")
    train_parents: dict[str, Mapping[str, Any]] = {}
    for row in parent_rows:
        material_id = str(row["material_id"])
        if material_id in train_ids:
            train_parents[material_id] = row
    missing = sorted(train_ids - train_parents.keys())
    if missing:
        raise ValueError(f"train_fit parents missing from recovered cache: {missing[:5]}")
    labels: list[dict[str, Any]] = []
    train_trajectory_count = 0
    skipped_trajectory_count = 0
    for trajectory in trajectory_rows:
        parent_id = str(trajectory["parent_structure_id"])
        if parent_id not in train_ids:
            skipped_trajectory_count += 1
            continue
        train_trajectory_count += 1
        parent = train_parents[parent_id]
        orbit_by_id = {
            str(orbit["orbit_instance_id"]): orbit for orbit in parent["orbits"]
        }
        for action in trajectory["inverse_actions"]:
            target_id = str(action["target_id"])
            orbit = orbit_by_id.get(target_id)
            if orbit is None:
                raise ValueError(f"unknown train_fit inverse target: {parent_id}:{target_id}")
            labels.append(
                {
                    "split": "train_fit",
                    "target_space_group": int(parent["target_space_group"]),
                    "wyckoff_position_id": str(orbit["wyckoff_position_id"]),
                    "multiplicity": int(orbit["multiplicity"]),
                    "species": int(orbit["species"]),
                }
            )
    audit = {
        "train_fit_parent_count": len(train_parents),
        "train_fit_trajectory_count": train_trajectory_count,
        "train_fit_inverse_label_count": len(labels),
        "non_train_trajectory_count_skipped_before_label_lookup": skipped_trajectory_count,
        "validation_or_test_label_count_accessed": 0,
    }
    return labels, audit


def _read_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            try:
                yield json.loads(line)
            except json.JSONDecodeError as error:
                raise ValueError(f"invalid JSONL at {path}:{line_number}") from error


def build_empirical_frequency_prior(
    *,
    phase2a_root: str | Path,
    recovered_parent_cache: str | Path,
    alpha: float = 1.0,
) -> tuple[EmpiricalFrequencyPrior, dict[str, Any]]:
    root = Path(phase2a_root)
    verify_frozen_phase2a(root)
    labels, audit = collect_train_fit_inverse_labels(
        split_rows=_read_jsonl(root / "splits" / "structure_ood_manifest.jsonl"),
        parent_rows=_read_jsonl(Path(recovered_parent_cache)),
        trajectory_rows=_read_jsonl(root / "trajectories" / "d_orbit.jsonl"),
    )
    prior = EmpiricalFrequencyPrior.from_labels(labels, alpha=alpha)
    return prior, prior.to_dict(audit=audit)


def uniform_legal_probabilities(
    legal_actions: Sequence[LegalAddOrbit],
) -> tuple[np.ndarray, dict[str, Any]]:
    if not legal_actions:
        raise ValueError("cannot score an empty legal action set")
    probabilities = np.full(len(legal_actions), 1.0 / len(legal_actions), dtype=float)
    return probabilities, {
        "backend": "UNIFORM_LEGAL",
        "legal_action_count": len(legal_actions),
        "learned_action_logits_used": False,
    }


def empirical_legal_probabilities(
    prior: EmpiricalFrequencyPrior,
    *,
    target_space_group: int,
    legal_actions: Sequence[LegalAddOrbit],
    remaining_composition: Sequence[tuple[int, int]],
) -> tuple[np.ndarray, dict[str, Any]]:
    if not legal_actions:
        raise ValueError("cannot score an empty legal action set")
    if prior.space_group_label_counts.get(int(target_space_group), 0) == 0:
        probabilities, _ = uniform_legal_probabilities(legal_actions)
        return probabilities, {
            "backend": "UNIFORM_UNSUPPORTED_SPACE_GROUP",
            "fallback_reason": "NO_TRAIN_FIT_LABELS_FOR_SPACE_GROUP",
            "legal_action_count": len(legal_actions),
            "learned_action_logits_used": False,
        }
    remaining = {int(species): int(count) for species, count in remaining_composition}
    remaining_total = sum(remaining.values())
    if remaining_total <= 0:
        raise ValueError("remaining composition must be positive")
    raw_scores: list[float] = []
    score_backends: list[str] = []
    for action in legal_actions:
        exact_key = (
            int(target_space_group),
            action.wyckoff_position_id,
            action.multiplicity,
            action.species,
        )
        exact = int(prior.exact_counts.get(exact_key, 0))
        if exact > 0:
            raw_scores.append(float(exact))
            score_backends.append("EXACT_SPECIES")
            continue
        marginal_key = (
            int(target_space_group),
            action.wyckoff_position_id,
            action.multiplicity,
        )
        marginal = int(prior.marginal_counts.get(marginal_key, 0))
        species_ratio = remaining.get(action.species, 0) / remaining_total
        raw_scores.append(float(marginal * species_ratio))
        score_backends.append("SPECIES_RATIO_FALLBACK")
    smoothed = np.asarray(raw_scores, dtype=float) + prior.alpha
    probabilities = smoothed / smoothed.sum()
    return probabilities, {
        "backend": "EMPIRICAL_FREQUENCY",
        "legal_action_count": len(legal_actions),
        "alpha": prior.alpha,
        "raw_scores": raw_scores,
        "score_backends": score_backends,
        "learned_action_logits_used": False,
    }


def generate_baseline_attempts(
    model: C0SymmetryModel,
    conditions: Sequence[dict[str, Any]],
    *,
    arm: str,
    empirical_prior: EmpiricalFrequencyPrior | None,
    root_seed: int,
    device: str,
    minimum_distance: float = 0.5,
    policy_namespace: str | None = None,
) -> list[dict[str, Any]]:
    if arm not in {"UNIFORM_LEGAL", "EMPIRICAL_FREQUENCY"}:
        raise ValueError(f"unsupported policy-attribution arm: {arm}")
    if arm == "EMPIRICAL_FREQUENCY" and empirical_prior is None:
        raise ValueError("EMPIRICAL_FREQUENCY requires a frozen empirical prior")
    if not conditions:
        raise ValueError("free rollout conditions must not be empty")
    expected_namespace_arm = (
        "uniform" if arm == "UNIFORM_LEGAL" else "empirical"
    )
    namespace = policy_namespace or (
        f"policy_attribution:{expected_namespace_arm}"
    )
    if _policy_namespace_arm(namespace) != expected_namespace_arm:
        raise ValueError(
            f"policy namespace {namespace!r} does not match arm {arm!r}"
        )
    model = model.to(device).eval()
    records: list[dict[str, Any]] = []
    compiler = SpaceGroupLegalActionCompiler(max_sites=model.config.maximum_sites)
    projector = C0SymmetryProjector(minimum_distance=minimum_distance)
    for condition in conditions:
        if int(condition.get("root_seed", root_seed)) != int(root_seed):
            raise ValueError("condition root seed does not match attribution root seed")
        started = time.perf_counter()
        composition = tuple(
            (int(atomic_number), int(count))
            for atomic_number, count in condition["composition"]
        )
        target_space_group = int(condition["space_group"])
        policy_seed = derive_policy_seed(
            root_seed,
            str(condition["condition_id"]),
            namespace=namespace,
        )
        rng = np.random.default_rng(policy_seed)
        site_count = sum(count for _, count in composition)
        placeholder = _embryo_lattice(target_space_group, site_count)
        embryo_state = SymmetryAssemblyState.empty(
            target_space_group=target_space_group,
            composition=composition,
            lattice=placeholder,
        )
        embryo_output = _model_output(
            model,
            _inference_example(condition, embryo_state, ()),
            device=device,
        )
        cell_logits = embryo_output.cell_index_logits[0].detach().cpu().clone()
        cell_logits[0] = -math.inf
        cell_index = int(cell_logits.argmax())
        predicted_degrees = (
            embryo_output.lattice_degree_prediction[0].detach().cpu().tolist()
        )
        lattice = decode_lattice_degrees(
            target_space_group,
            predicted_degrees,
            cell_transform=_canonical_cell_transform(cell_index),
        )
        state = SymmetryAssemblyState.empty(
            target_space_group=target_space_group,
            composition=composition,
            lattice=lattice,
        )
        actions: list[dict[str, Any]] = []
        receipts = []
        selection_trace: list[dict[str, Any]] = []
        failure_code: str | None = None
        completed = False
        terminal_receipt = None
        for step_index in range(model.config.maximum_orbits + 1):
            legal_actions = compiler.legal_add_actions(state)
            output = _model_output(
                model,
                _inference_example(condition, state, legal_actions),
                device=device,
            )
            termination_requested = bool(
                int(output.terminate_logits[0].argmax().detach().cpu()) == 1
            )
            if not state.remaining_composition:
                terminal_receipt = projector.project(state)
                receipts.append(terminal_receipt)
                if termination_requested and compiler.can_terminate(
                    state, terminal_receipt
                ):
                    completed = True
                else:
                    failure_code = (
                        "TERMINATION_NOT_SELECTED"
                        if terminal_receipt.accepted
                        else "TERMINAL_PROJECTOR_REJECTED"
                    )
                break
            if not legal_actions:
                failure_code = "NO_LEGAL_ADD_ORBIT_ACTION"
                break
            if arm == "UNIFORM_LEGAL":
                probabilities, selection_audit = uniform_legal_probabilities(
                    legal_actions
                )
            else:
                assert empirical_prior is not None
                probabilities, selection_audit = empirical_legal_probabilities(
                    empirical_prior,
                    target_space_group=target_space_group,
                    legal_actions=legal_actions,
                    remaining_composition=state.remaining_composition,
                )
            selected_index = int(rng.choice(len(legal_actions), p=probabilities))
            selected = legal_actions[selected_index]
            selection_trace.append(
                {
                    "step_index": step_index,
                    "policy_namespace": namespace,
                    "policy_seed": policy_seed,
                    "legal_actions": [asdict(action) for action in legal_actions],
                    "probabilities": probabilities.tolist(),
                    "selected_index": selected_index,
                    "selected_action": asdict(selected),
                    **selection_audit,
                }
            )
            free = tuple(
                float(value)
                for value in output.free_parameter_prediction[
                    0, : selected.free_parameter_count
                ]
                .detach()
                .cpu()
                .tolist()
            )
            orbit_id = f"{condition['condition_id']}:orbit:{step_index}"
            next_state = compiler.apply_add(
                state,
                AddOrbitAction(
                    selected.wyckoff_letter,
                    selected.species,
                    free,
                    orbit_id,
                ),
            )
            receipt = projector.project(next_state)
            receipts.append(receipt)
            actions.append(
                {
                    "step_index": step_index,
                    "wyckoff_position_id": selected.wyckoff_position_id,
                    "wyckoff_letter": selected.wyckoff_letter,
                    "species": selected.species,
                    "multiplicity": selected.multiplicity,
                    "free_parameters": list(free),
                    "orbit_instance_id": orbit_id,
                    "termination_requested_while_illegal": termination_requested,
                    "projector": receipt.to_dict(),
                }
            )
            if not receipt.accepted:
                failure_code = "PROJECTOR_REJECTED"
                break
            state = next_state
        else:
            failure_code = "MAXIMUM_ORBIT_STEPS_EXCEEDED"
        assert all(
            trace["learned_action_logits_used"] is False
            for trace in selection_trace
        ), "LEARNED_ACTION_LOGITS_USED must remain false for baseline arms"
        final_receipt = terminal_receipt or (receipts[-1] if receipts else None)
        detected_space_group = (
            int(final_receipt.detected_space_groups.get(0.03, 0))
            if final_receipt is not None
            else 0
        )
        target_match = detected_space_group == target_space_group
        legal_terminal = bool(
            completed
            and final_receipt is not None
            and final_receipt.accepted
            and target_match
        )
        candidate = None
        if legal_terminal and final_receipt is not None:
            candidate = {
                "atomic_numbers": list(final_receipt.atomic_numbers),
                "fractional_coordinates": [
                    list(value) for value in final_receipt.fractional_coordinates
                ],
                "lattice": [list(value) for value in final_receipt.lattice],
                "orbit_states": [asdict(orbit) for orbit in state.orbits],
            }
        rejection_reasons = [
            reason
            for receipt in receipts
            if not receipt.accepted
            for reason in receipt.reason_codes
        ]
        records.append(
            {
                "condition": dict(condition),
                "policy_arm": arm,
                "policy_namespace": namespace,
                "policy_seed": policy_seed,
                "runtime_assertions": {"LEARNED_ACTION_LOGITS_USED": False},
                "policy_selection_trace": selection_trace,
                "selected_cell_index": cell_index,
                "selected_lattice_degrees": predicted_degrees,
                "selected_lattice": [
                    list(value) for value in lattice.primitive_matrix
                ],
                "actions": actions,
                "completed": completed,
                "legal_terminal_crystal": legal_terminal,
                "failure_code": failure_code,
                "pre_projector_target_space_group_match": target_match,
                "post_projector_target_space_group_match": target_match,
                "wyckoff_orbit_valid": bool(
                    final_receipt
                    and final_receipt.orbit_membership_valid
                    and final_receipt.distinct_orbit_instances_valid
                ),
                "composition_valid": bool(
                    final_receipt and final_receipt.composition_valid
                ),
                "multiplicity_valid": bool(
                    final_receipt and final_receipt.multiplicity_valid
                ),
                "short_contact_free": bool(
                    final_receipt and final_receipt.minimum_distance_valid
                ),
                "detected_space_group": detected_space_group,
                "projector_attempt_count": len(receipts),
                "projector_rejection_count": sum(
                    not receipt.accepted for receipt in receipts
                ),
                "projector_rejection_reasons": rejection_reasons,
                "candidate": candidate,
                "latency_seconds": time.perf_counter() - started,
                "retry_count": 0,
                "refill_count": 0,
            }
        )
    return records
