from __future__ import annotations

import json
import math
from collections import defaultdict
from collections.abc import Mapping, Sequence
from itertools import combinations

import numpy as np
from pymatgen.core import Element
from scipy.optimize import linear_sum_assignment
from scipy.stats import spearmanr

from crysalis_g1.experiments.full_orbit_compatibility import (
    element_radius_angstrom,
)

STAGES = ("EARLY", "MID", "LATE", "TERMINAL")
STAGE_TARGETS = {"EARLY": 0.25, "MID": 0.50, "LATE": 0.75}

ORBIT_ONLY_FEATURE_NAMES = (
    "target_space_group_scaled",
    *(f"wyckoff_letter_{chr(ord('a') + index)}" for index in range(26)),
    "multiplicity",
    "free_DOF",
    "inserted_species_Z_scaled",
    "inserted_species_radius",
    "inserted_species_electronegativity",
    "u0_sin",
    "u0_cos",
    "u1_sin",
    "u1_cos",
    "u2_sin",
    "u2_cos",
    "orbit_internal_min_distance",
    "orbit_internal_pair_distance_mean",
    "lattice_a",
    "lattice_b",
    "lattice_c",
    "lattice_alpha",
    "lattice_beta",
    "lattice_gamma",
)

_CONTEXT_ADDITIONS = (
    "candidate_framework_min_distance_min",
    "candidate_framework_min_distance_mean",
    "candidate_framework_coordination_mean",
    "candidate_framework_coordination_min",
    "candidate_framework_same_species_coordination_mean",
    "candidate_neighbor_Z_mean",
    "candidate_neighbor_Z_std",
    "candidate_coordinated_distance_mean",
    "short_contact_residual_max",
    "short_contact_residual_mean",
    "static_full_orbit_contact_score",
    "assembly_progress",
)
CONTEXT_FEATURE_NAMES = (*ORBIT_ONLY_FEATURE_NAMES, *_CONTEXT_ADDITIONS)


def species_class(atomic_number: int) -> str:
    element = Element.from_Z(int(atomic_number))
    block = str(element.block).lower()
    if block not in {"s", "p", "d", "f"}:
        raise ValueError(f"unsupported periodic-table block: {block}")
    return block


def action_signature(event: Mapping[str, object]) -> tuple[int, str, int, int, str]:
    return (
        int(event["target_space_group"]),
        str(event["wyckoff_letter"]),
        int(event["multiplicity"]),
        int(event["free_dof"]),
        species_class(int(event["species"])),
    )


def _stage_for_event(event: Mapping[str, object]) -> str:
    if int(event["missing_orbit_count"]) == 1:
        return "TERMINAL"
    fraction = float(event["active_orbit_fraction"])
    if fraction < 0.375:
        return "EARLY"
    if fraction < 0.625:
        return "MID"
    return "LATE"


def select_parent_events(
    event_pool: Sequence[Mapping[str, object]],
) -> list[dict[str, object]]:
    """Choose at most one deterministic event per parent and assembly stage."""

    grouped: dict[str, list[Mapping[str, object]]] = defaultdict(list)
    for event in event_pool:
        grouped[str(event["parent_id"])].append(event)
    chosen: list[dict[str, object]] = []
    stage_rank = {stage: index for index, stage in enumerate(STAGES)}
    depth_stages = ("EARLY", "MID", "LATE")
    for parent_id, rows in grouped.items():
        terminal_rows = [row for row in rows if int(row["missing_orbit_count"]) == 1]
        depth_rows = [row for row in rows if int(row["missing_orbit_count"]) != 1]
        depth_rows.sort(
            key=lambda row: (
                int(row.get("canonical_event_index", 0)),
                str(row.get("wyckoff_position_id", "")),
                int(row.get("species", 0)),
                int(row.get("multiplicity", 0)),
                int(row.get("graph_line_number", 0)),
            )
        )
        if depth_rows:
            cost = np.asarray(
                [
                    [
                        abs(float(row["active_orbit_fraction"]) - STAGE_TARGETS[stage])
                        + row_index * 1e-12
                        for stage in depth_stages
                    ]
                    for row_index, row in enumerate(depth_rows)
                ],
                dtype=float,
            )
            row_indices, stage_indices = linear_sum_assignment(cost)
            for row_index, stage_index in zip(row_indices, stage_indices, strict=True):
                selected = depth_rows[int(row_index)]
                stage = depth_stages[int(stage_index)]
                result = dict(selected)
                result["stage"] = stage
                result["event_id"] = f"{selected['event_base_id']}:{stage.lower()}"
                chosen.append(result)
        if terminal_rows:
            selected = min(
                terminal_rows,
                key=lambda row: (
                    int(row.get("canonical_event_index", 0)),
                    str(row.get("wyckoff_position_id", "")),
                    int(row.get("species", 0)),
                    int(row.get("multiplicity", 0)),
                    int(row.get("graph_line_number", 0)),
                ),
            )
            result = dict(selected)
            result["stage"] = "TERMINAL"
            result["event_id"] = f"{selected['event_base_id']}:terminal"
            chosen.append(result)
    chosen.sort(key=lambda row: (str(row["parent_id"]), stage_rank[str(row["stage"])]))
    event_bases = [str(row["event_base_id"]) for row in chosen]
    if len(event_bases) != len(set(event_bases)):
        raise RuntimeError("one canonical graph event was assigned to multiple stages")
    return chosen


def deterministic_parent_folds(parent_ids: Sequence[str]) -> dict[str, int]:
    values = sorted(set(map(str, parent_ids)))
    if len(values) < 4:
        raise ValueError("four-fold CV requires at least four unique parents")
    return {parent_id: index % 4 for index, parent_id in enumerate(values)}


def stratified_parent_order(
    parent_rows: Sequence[Mapping[str, object]],
) -> list[dict[str, object]]:
    """Return a deterministic nested order that tracks structural stratum mass."""

    groups: dict[tuple[str, int, int, tuple[int, ...]], list[dict[str, object]]] = defaultdict(list)
    seen = set()
    for row in parent_rows:
        parent_id = str(row["parent_id"])
        if parent_id in seen:
            raise ValueError(f"duplicate parent_id: {parent_id}")
        seen.add(parent_id)
        key = (
            str(row["crystal_system"]),
            int(row["element_count"]),
            int(row["final_orbit_count"]),
            tuple(int(value) for value in row["available_free_dof_classes"]),
        )
        groups[key].append(dict(row))
    if not groups:
        raise ValueError("parent cohort cannot be empty")
    for values in groups.values():
        values.sort(key=lambda row: str(row["parent_id"]))
    total = sum(map(len, groups.values()))
    selected_by_key = {key: 0 for key in groups}
    result = []
    for position in range(total):
        available = [key for key in groups if selected_by_key[key] < len(groups[key])]
        key = min(
            available,
            key=lambda value: (
                -(
                    (position + 1) * len(groups[value]) / total
                    - selected_by_key[value]
                ),
                value,
            ),
        )
        result.append(groups[key][selected_by_key[key]])
        selected_by_key[key] += 1
    return result


def _as_sequence(value: object) -> list[float]:
    if isinstance(value, str):
        parsed = json.loads(value)
    else:
        parsed = value
    if not isinstance(parsed, (list, tuple, np.ndarray)):
        raise ValueError("legal_u must be a sequence")
    return [float(item) for item in parsed]


def _orbit_only_features(row: Mapping[str, object]) -> list[float]:
    letter = str(row["wyckoff_letter"]).lower()
    if len(letter) != 1 or not "a" <= letter <= "z":
        raise ValueError(f"invalid Wyckoff letter: {letter}")
    atomic_number = int(row["species"])
    element = Element.from_Z(atomic_number)
    electronegativity = element.X
    u = _as_sequence(row["legal_u"])
    if len(u) != int(row["free_dof"]) or not 1 <= len(u) <= 3:
        raise ValueError("legal_u dimension differs from free_dof")
    cyclic = []
    for index in range(3):
        value = u[index] if index < len(u) else 0.0
        cyclic.extend([math.sin(2.0 * math.pi * value), math.cos(2.0 * math.pi * value)])
    one_hot = [float(index == ord(letter) - ord("a")) for index in range(26)]
    return [
        int(row["target_space_group"]) / 230.0,
        *one_hot,
        float(row["multiplicity"]),
        float(row["free_dof"]),
        atomic_number / 118.0,
        element_radius_angstrom(atomic_number),
        0.0 if electronegativity is None else float(electronegativity),
        *cyclic,
        float(row["orbit_internal_min_distance"]),
        float(row["orbit_internal_pair_distance_mean"]),
        float(row["lattice_a"]),
        float(row["lattice_b"]),
        float(row["lattice_c"]),
        float(row["lattice_alpha"]),
        float(row["lattice_beta"]),
        float(row["lattice_gamma"]),
    ]


def build_matched_feature_matrices(
    candidate_rows: Sequence[Mapping[str, object]],
) -> tuple[np.ndarray, np.ndarray]:
    orbit_rows = []
    context_rows = []
    for row in candidate_rows:
        orbit = _orbit_only_features(row)
        context = [*orbit, *(float(row[name]) for name in _CONTEXT_ADDITIONS)]
        orbit_rows.append(orbit)
        context_rows.append(context)
    orbit_array = np.asarray(orbit_rows, dtype=float)
    context_array = np.asarray(context_rows, dtype=float)
    if orbit_array.shape != (len(candidate_rows), len(ORBIT_ONLY_FEATURE_NAMES)):
        raise RuntimeError("orbit-only feature width drifted")
    if context_array.shape != (len(candidate_rows), len(CONTEXT_FEATURE_NAMES)):
        raise RuntimeError("context feature width drifted")
    if not np.isfinite(orbit_array).all() or not np.isfinite(context_array).all():
        raise ValueError("model features must be finite")
    return orbit_array, context_array


def trainable_parameter_ratio(
    orbit_input_n: int, context_input_n: int, *, hidden_n: int = 128
) -> float:
    def count(input_n: int) -> int:
        return (
            input_n * hidden_n
            + hidden_n
            + hidden_n * hidden_n
            + hidden_n
            + hidden_n
            + 1
        )

    return count(context_input_n) / count(orbit_input_n)


def _finite_force(row: Mapping[str, object]) -> float | None:
    value = row.get("initial_max_force_ev_per_angstrom")
    if row.get("chgnet_status") != "EVALUATED" or value is None:
        return None
    force = float(value)
    return force if math.isfinite(force) and force >= 0.0 else None


def summarize_landscapes(
    events: Sequence[Mapping[str, object]],
    candidate_rows: Sequence[Mapping[str, object]],
) -> dict[str, object]:
    by_event: dict[str, list[Mapping[str, object]]] = defaultdict(list)
    for row in candidate_rows:
        by_event[str(row["event_id"])].append(row)
    summaries = []
    for event in events:
        event_id = str(event["event_id"])
        rows = by_event[event_id]
        forces = np.asarray(
            [force for row in rows if (force := _finite_force(row)) is not None],
            dtype=float,
        )
        if not len(forces):
            summary = {
                "event_id": event_id,
                "parent_id": str(event["parent_id"]),
                "stage": str(event["stage"]),
                "candidate_validity_rate": 0.0,
                "rugged_event": False,
            }
        else:
            q10, q25, q75, q90 = np.quantile(forces, [0.10, 0.25, 0.75, 0.90])
            log_iqr = float(np.quantile(np.log1p(forces), 0.75) - np.quantile(np.log1p(forces), 0.25))
            median = float(np.median(forces))
            summary = {
                "event_id": event_id,
                "parent_id": str(event["parent_id"]),
                "stage": str(event["stage"]),
                "finite_force_n": int(len(forces)),
                "candidate_validity_rate": float(len(forces) / max(len(rows), 1)),
                "force_median": median,
                "force_iqr": float(q75 - q25),
                "log1p_force_iqr": log_iqr,
                "p90_p10_spread": float(q90 - q10),
                "force_min": float(np.min(forces)),
                "force_max": float(np.max(forces)),
                "min_median_ratio": float(np.min(forces) / max(median, 1e-12)),
                "lowest_force_quartile_fraction": float(np.mean(forces <= q25)),
                "force_below_1_fraction": float(np.mean(forces < 1.0)),
                "force_below_5_fraction": float(np.mean(forces < 5.0)),
                "rugged_event": bool(log_iqr >= 0.50),
            }
        summaries.append(summary)
    rugged = np.asarray([bool(row["rugged_event"]) for row in summaries], dtype=float)
    stage_rates = {}
    for stage in STAGES:
        values = [bool(row["rugged_event"]) for row in summaries if row["stage"] == stage]
        stage_rates[stage] = float(np.mean(values)) if values else math.nan
    return {
        "event_summaries": summaries,
        "overall_rugged_rate": float(np.mean(rugged)) if len(rugged) else math.nan,
        "stage_rugged_rate": stage_rates,
    }


def cross_context_analysis(
    events: Sequence[Mapping[str, object]],
    candidate_rows: Sequence[Mapping[str, object]],
) -> dict[str, object]:
    by_signature: dict[tuple[int, str, int, int, str], list[Mapping[str, object]]] = defaultdict(list)
    for event in events:
        by_signature[action_signature(event)].append(event)
    force_by_event: dict[str, dict[int, float]] = defaultdict(dict)
    for row in candidate_rows:
        force = _finite_force(row)
        if force is not None:
            force_by_event[str(row["event_id"])][int(row["candidate_index"])] = force
    correlations = []
    signature_rows = []
    for signature, signature_events in sorted(by_signature.items()):
        parent_n = len({str(row["parent_id"]) for row in signature_events})
        if parent_n < 4:
            continue
        pair_values = []
        for left, right in combinations(signature_events, 2):
            if str(left["parent_id"]) == str(right["parent_id"]):
                continue
            left_force = force_by_event[str(left["event_id"])]
            right_force = force_by_event[str(right["event_id"])]
            common = sorted(set(left_force) & set(right_force))
            if len(common) < 3:
                continue
            correlation = float(
                spearmanr(
                    [left_force[index] for index in common],
                    [right_force[index] for index in common],
                ).statistic
            )
            if math.isfinite(correlation):
                correlations.append(correlation)
                pair_values.append(correlation)
        signature_rows.append(
            {
                "signature": signature,
                "parent_n": parent_n,
                "event_n": len(signature_events),
                "pair_n": len(pair_values),
                "spearman_median": float(np.median(pair_values)) if pair_values else math.nan,
            }
        )
    return {
        "qualifying_signature_n": len(signature_rows),
        "pair_n": len(correlations),
        "spearman_median": float(np.median(correlations)) if correlations else math.nan,
        "signature_rows": signature_rows,
    }


def choose_parent_budget(
    *,
    elapsed_minutes_at_16: float,
    event_counts: Mapping[int, int],
    max_minutes: float = 35.0,
) -> int:
    if set(event_counts) != {256, 192, 128}:
        raise ValueError("ETA gate requires 256, 192, and 128 parent event counts")
    if not math.isfinite(elapsed_minutes_at_16) or elapsed_minutes_at_16 <= 0.0:
        raise ValueError("elapsed time at 16 events must be positive and finite")
    for parent_n in (256, 192, 128):
        projected = elapsed_minutes_at_16 * int(event_counts[parent_n]) / 16.0
        if projected <= max_minutes:
            return parent_n
    raise TimeoutError("projected 128-parent Atlas exceeds the 35-minute deadline")


def context_value_verdict(
    *,
    orbit_ndcg5: float,
    context_ndcg5: float,
    orbit_top1_force: float,
    context_top1_force: float,
    fold_top1_log_deltas: Sequence[float],
    ci_upper: float,
) -> dict[str, object]:
    fold_values = [float(value) for value in fold_top1_log_deltas]
    if len(fold_values) != 4 or not np.isfinite(fold_values).all():
        raise ValueError("context verdict requires four finite fold deltas")
    directional = sum(value < 0.0 for value in fold_values)
    conditions = {
        "context_ndcg5_higher": float(context_ndcg5) > float(orbit_ndcg5),
        "context_top1_force_lower": float(context_top1_force) < float(orbit_top1_force),
        "at_least_three_folds": directional >= 3,
        "paired_ci_upper_below_zero": float(ci_upper) < 0.0,
    }
    return {
        "status": "SUPPORTED" if all(conditions.values()) else "NOT_SUPPORTED",
        "directional_fold_n": directional,
        "conditions": conditions,
    }


def assembly_stage_effect(stage_rows: Mapping[str, Mapping[str, float]]) -> str:
    if set(stage_rows) != set(STAGES):
        raise ValueError("stage effect requires EARLY, MID, LATE, and TERMINAL summaries")

    def gain(stage: str) -> bool:
        row = stage_rows[stage]
        return (
            float(row["context_ndcg5"]) > float(row["orbit_ndcg5"])
            and float(row["context_top1_force"]) < float(row["orbit_top1_force"])
        )

    return "SUPPORTED" if gain("MID") and gain("LATE") and not gain("EARLY") else "NOT_SUPPORTED"


def atlas_verdict(
    *,
    overall_rugged_rate: float,
    mid_rugged_rate: float,
    late_rugged_rate: float,
    context_value: str,
    cross_context_spearman_median: float,
) -> dict[str, str]:
    ubiquity = (
        "SUPPORTED"
        if float(overall_rugged_rate) >= 0.75
        and float(mid_rugged_rate) >= 0.70
        and float(late_rugged_rate) >= 0.70
        else "NOT_SUPPORTED"
    )
    conditional = (
        "SUPPORTED"
        if ubiquity == "SUPPORTED"
        and context_value == "SUPPORTED"
        and math.isfinite(float(cross_context_spearman_median))
        and float(cross_context_spearman_median) < 0.75
        else "NOT_SUPPORTED"
    )
    if conditional == "SUPPORTED":
        claim = "CONTEXT_CONDITIONAL_WYCKOFF_PHYSICAL_LANDSCAPE"
        next_action = "INDEPENDENT_POTENTIAL_AND_EXTERNAL_ATLAS_VALIDATION"
    elif ubiquity == "SUPPORTED":
        claim = "GLOBAL_SYMMETRY_RESTRICTED_LANDSCAPE_NOT_NOVEL_ENOUGH"
        next_action = "REASSESS_NC_DIRECTION"
    else:
        claim = "REJECT_LANDSCAPE_AS_NC_CORE"
        next_action = "STOP_LANDSCAPE_NC_DIRECTION"
    return {
        "wyckoff_landscape_ubiquity": ubiquity,
        "conditional_landscape_signal": conditional,
        "nc_core_claim_candidate": claim,
        "next_action": next_action,
    }


__all__ = [
    "CONTEXT_FEATURE_NAMES",
    "ORBIT_ONLY_FEATURE_NAMES",
    "STAGES",
    "action_signature",
    "assembly_stage_effect",
    "atlas_verdict",
    "build_matched_feature_matrices",
    "choose_parent_budget",
    "context_value_verdict",
    "cross_context_analysis",
    "deterministic_parent_folds",
    "select_parent_events",
    "species_class",
    "stratified_parent_order",
    "summarize_landscapes",
    "trainable_parameter_ratio",
]
