from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

import numpy as np


def duplicate_force_records_consistent(
    force_values: Sequence[float], *, absolute_tolerance: float = 2e-4
) -> bool:
    values = np.asarray(force_values, dtype=float)
    return bool(
        len(values)
        and np.isfinite(values).all()
        and np.all(values >= 0.0)
        and float(np.ptp(values)) <= float(absolute_tolerance)
    )


def classify_bd_pair(b_legal: bool, d_legal: bool) -> str:
    return (
        f"B_{'LEGAL' if bool(b_legal) else 'FAIL'}_"
        f"D_{'LEGAL' if bool(d_legal) else 'FAIL'}"
    )


def first_trajectory_divergence(
    b_steps: Sequence[Mapping[str, Any]],
    d_steps: Sequence[Mapping[str, Any]],
    *,
    action_key: str,
    geometry_key: str,
) -> dict[str, int | bool | None]:
    first_geometry = None
    first_action = None
    for index, (b_step, d_step) in enumerate(zip(b_steps, d_steps, strict=False), 1):
        if first_geometry is None and b_step.get(geometry_key) != d_step.get(
            geometry_key
        ):
            first_geometry = index
        if first_action is None and b_step.get(action_key) != d_step.get(action_key):
            first_action = index
    return {
        "first_geometry_divergence_step": first_geometry,
        "first_action_divergence_step": first_action,
        "action_diverged_after_geometry": bool(
            first_geometry is not None
            and first_action is not None
            and first_action > first_geometry
        ),
    }


def terminal_loss_primary_cause(
    *,
    b_legal_d_fail_n: int,
    b_fail_d_legal_n: int,
    paired_new_geometry_rejection_n: int,
    paired_resolved_geometry_rejection_n: int,
    action_divergence_after_geometry_n: int,
) -> str:
    net_terminal_loss = int(b_legal_d_fail_n) - int(b_fail_d_legal_n)
    net_new_rejections = int(paired_new_geometry_rejection_n) - int(
        paired_resolved_geometry_rejection_n
    )
    if net_terminal_loss <= 0:
        return "UNRESOLVED"
    tolerance = max(1, round(0.25 * net_terminal_loss))
    rejection_explains_loss = (
        net_new_rejections > 0
        and abs(net_new_rejections - net_terminal_loss) <= tolerance
    )
    if rejection_explains_loss and int(action_divergence_after_geometry_n) == 0:
        return "COMPATIBILITY_GEOMETRY_REJECTION"
    if net_new_rejections <= 0 and int(action_divergence_after_geometry_n) > 0:
        return "LATER_DISCRETE_DIVERGENCE"
    if net_new_rejections > 0 and int(action_divergence_after_geometry_n) > 0:
        return "MIXED"
    return "UNRESOLVED"


def assign_baseline_force_quartiles(
    rows: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    ordered = sorted(
        (dict(row) for row in rows),
        key=lambda row: (float(row["b_force"]), str(row["pair_id"])),
    )
    bins = np.array_split(np.arange(len(ordered)), 4)
    for quartile, indices in enumerate(bins, 1):
        for index in indices:
            ordered[int(index)]["b_force_quartile"] = f"Q{quartile}"
    return ordered


def physical_effect_pattern(quartile_mean_deltas: Mapping[str, float]) -> str:
    values = {
        f"Q{index}": float(quartile_mean_deltas[f"Q{index}"]) for index in range(1, 5)
    }
    negative = {key for key, value in values.items() if value < -1e-12}
    positive = {key for key, value in values.items() if value > 1e-12}
    if len(negative) >= 3:
        return "BROAD_IMPROVEMENT"
    if negative == {"Q4"}:
        return "HIGH_FORCE_TAIL_REDUCTION"
    if negative and negative <= {"Q1", "Q2"} and not ({"Q3", "Q4"} & negative):
        return "LOW_FORCE_ONLY"
    if negative and positive:
        return "MIXED"
    return "NO_CLEAR_PATTERN"


__all__ = [
    "assign_baseline_force_quartiles",
    "classify_bd_pair",
    "duplicate_force_records_consistent",
    "first_trajectory_divergence",
    "physical_effect_pattern",
    "terminal_loss_primary_cause",
]
