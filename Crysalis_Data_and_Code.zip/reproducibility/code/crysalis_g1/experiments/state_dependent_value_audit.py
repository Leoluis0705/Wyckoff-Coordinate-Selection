from __future__ import annotations

from collections import Counter
from typing import Sequence

import numpy as np


def quartile_subgroups(values: Sequence[float]) -> list[dict[str, object]]:
    array = np.asarray(values, dtype=float)
    if array.ndim != 1 or not len(array) or not np.isfinite(array).all():
        raise ValueError("quartile values must be a non-empty finite vector")
    edges = np.quantile(array, (0.0, 0.25, 0.50, 0.75, 1.0))
    output = []
    for index, label in enumerate(("Q1", "Q2", "Q3", "Q4")):
        lower = float(edges[index])
        upper = float(edges[index + 1])
        if index == 0:
            mask = (array >= lower) & (array <= upper)
        else:
            mask = (array > lower) & (array <= upper)
        output.append(
            {
                "subgroup": label,
                "lower": lower,
                "upper": upper,
                "sample_n": int(mask.sum()),
            }
        )
    return output


def categorical_subgroups(
    values: Sequence[object], *, levels: Sequence[object] | None = None
) -> list[dict[str, object]]:
    counts = Counter(str(value) for value in values)
    ordered = (
        tuple(str(value) for value in levels)
        if levels is not None
        else tuple(sorted(counts))
    )
    return [
        {"subgroup": value, "sample_n": int(counts[value])} for value in ordered
    ]


def state_dependent_audit_verdict(
    *,
    validation_inverse_trajectory_n: int,
    validation_joint_trajectory_n: int,
    validation_inverse_step_n: int,
    validation_joint_step_n: int,
    selected_lambda_diagnostic_step_n: int,
) -> dict[str, str]:
    primary_complete = all(
        count > 0
        for count in (
            validation_inverse_trajectory_n,
            validation_joint_trajectory_n,
            validation_inverse_step_n,
            validation_joint_step_n,
        )
    )
    if primary_complete:
        raise ValueError("complete primary records require effect-based adjudication")
    return {
        "STATE_DEPENDENT_PHYSICAL_VALUE_SIGNAL": "UNRESOLVED",
        "H1_MDN_UNCERTAINTY": "UNRESOLVED",
        "H2_INVERSE_CONFIDENCE": "UNRESOLVED",
        "H3_ASSEMBLY_STAGE": "UNRESOLVED",
        "H4_FREE_DOF": "UNRESOLVED",
        "H5_ALTERNATIVE_BRANCH": "UNRESOLVED",
        "STRONGEST_HETEROGENEITY_VARIABLE": "NONE",
        "BEST_SUBGROUP_TERMINAL_DELTA_PP": "NA",
        "BEST_SUBGROUP_FORCE_DELTA": "NA",
        "NEXT_MODEL_TARGET": "UNRESOLVED",
    }


__all__ = [
    "categorical_subgroups",
    "quartile_subgroups",
    "state_dependent_audit_verdict",
]
