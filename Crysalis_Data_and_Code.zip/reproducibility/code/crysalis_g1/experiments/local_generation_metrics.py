from __future__ import annotations

import hashlib
import json
import math
from collections import Counter, defaultdict
from typing import Any

import numpy as np
from pymatgen.analysis.structure_matcher import StructureMatcher
from pymatgen.core import Lattice, Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer

from crysalis_g1.experiments.local_pilot_data import FrozenPhase2ACorpus


def _safe_mean(values: list[float]) -> float | None:
    finite = [value for value in values if math.isfinite(value)]
    return sum(finite) / len(finite) if finite else None


def _formula_key(atomic_numbers: list[int]) -> tuple[tuple[int, int], ...]:
    counts = Counter(atomic_numbers)
    divisor = math.gcd(*counts.values()) if counts else 1
    return tuple(sorted((number, count // divisor) for number, count in counts.items()))


def _candidate_structure(record: dict[str, Any]) -> Structure:
    candidate = record["candidate"]
    return Structure(
        Lattice(np.asarray(candidate["lattice"], dtype=float)),
        [int(value) for value in candidate["atomic_numbers"]],
        np.asarray(candidate["fractional_coordinates"], dtype=float),
    )


def _parent_structure(parent: object) -> Structure:
    atomic_numbers: list[int] = []
    coordinates: list[tuple[float, float, float]] = []
    for orbit in getattr(parent, "orbits"):
        atomic_numbers.extend(
            [int(getattr(orbit, "atomic_number"))]
            * int(getattr(orbit, "multiplicity"))
        )
        coordinates.extend(getattr(orbit, "expanded_fractional_coordinates"))
    return Structure(
        Lattice(np.asarray(getattr(parent, "target_lattice"), dtype=float)),
        atomic_numbers,
        coordinates,
    )


def _exact_generated_hash(structure: Structure) -> str:
    sites = sorted(
        (
            int(site.specie.Z),
            tuple(round(float(value) % 1.0, 6) for value in site.frac_coords),
        )
        for site in structure
    )
    payload = {
        "lattice": np.asarray(structure.lattice.matrix).round(6).tolist(),
        "sites": sites,
    }
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


def _structural_uniqueness_and_novelty(
    records: list[dict[str, Any]], corpus: FrozenPhase2ACorpus
) -> dict[str, Any]:
    matcher = StructureMatcher(
        primitive_cell=False,
        scale=True,
        attempt_supercell=False,
        ltol=0.2,
        stol=0.3,
        angle_tol=5.0,
    )
    generated: list[tuple[str, Structure]] = []
    parse_failures = 0
    for record in records:
        if not record.get("legal_terminal_crystal", False):
            continue
        try:
            generated.append(
                (str(record["condition"]["condition_id"]), _candidate_structure(record))
            )
        except Exception:
            parse_failures += 1
    generated_buckets: dict[
        tuple[tuple[int, int], ...], list[tuple[str, Structure]]
    ] = defaultdict(list)
    for condition_id, structure in generated:
        generated_buckets[_formula_key([int(site.specie.Z) for site in structure])].append(
            (condition_id, structure)
        )
    unique_representatives: list[Structure] = []
    unique_count = 0
    matcher_failures = 0
    for members in generated_buckets.values():
        representatives: list[Structure] = []
        for _, structure in members:
            try:
                duplicate = any(matcher.fit(structure, prior) for prior in representatives)
            except Exception:
                matcher_failures += 1
                duplicate = _exact_generated_hash(structure) in {
                    _exact_generated_hash(prior) for prior in representatives
                }
            if not duplicate:
                representatives.append(structure)
                unique_representatives.append(structure)
                unique_count += 1

    train_buckets: dict[tuple[tuple[int, int], ...], list[Structure]] = defaultdict(list)
    for parent_id, parent in corpus._parents.items():
        if corpus._splits[parent_id] != "train_fit":
            continue
        train_buckets[_formula_key([z for z, count in parent.composition for _ in range(count)])].append(
            _parent_structure(parent)
        )
    novel_count = 0
    for structure in unique_representatives:
        bucket = train_buckets[
            _formula_key([int(site.specie.Z) for site in structure])
        ]
        try:
            is_novel = not any(matcher.fit(structure, parent) for parent in bucket)
        except Exception:
            matcher_failures += 1
            is_novel = True
        novel_count += int(is_novel)
    legal_count = len(generated)
    return {
        "legal_structure_count": legal_count,
        "structure_matcher_unique_count": unique_count,
        "structure_matcher_uniqueness_rate_all_attempts": unique_count
        / max(len(records), 1),
        "structure_matcher_uniqueness_rate_legal": unique_count
        / max(legal_count, 1),
        "structure_matcher_novel_count": novel_count,
        "structure_matcher_novelty_rate_all_attempts": novel_count
        / max(len(records), 1),
        "structure_matcher_novelty_rate_unique": novel_count
        / max(unique_count, 1),
        "candidate_parse_failure_count": parse_failures,
        "structure_matcher_failure_count": matcher_failures,
        "novelty_reference_split": "train_fit",
        "novelty_matcher": {
            "primitive_cell": False,
            "scale": True,
            "attempt_supercell": False,
            "ltol": 0.2,
            "stol": 0.3,
            "angle_tol": 5.0,
        },
    }


def aggregate_generation_metrics(
    *,
    arm_id: str,
    rollout: dict[str, Any],
    chgnet: dict[str, Any],
    corpus: FrozenPhase2ACorpus,
) -> dict[str, Any]:
    records = list(rollout["records"])
    chgnet_records = list(chgnet["records"])
    attempts = len(records)
    if attempts == 0 or len(chgnet_records) != attempts:
        raise ValueError("generation and CHGNet records must share a non-empty denominator")
    projector_states = sum(
        int(record["projector"]["attempted_state_count"]) for record in records
    )
    pre_valid = sum(
        int(record["projector"]["pre_valid_count"]) for record in records
    )
    post_valid = sum(
        int(record["projector"]["post_valid_count"]) for record in records
    )
    rejected = sum(
        int(record["projector"]["rejection_count"]) for record in records
    )
    correction = [
        float(record["projector"]["correction_amount_mean"])
        for record in records
    ]
    generation_failures = Counter(
        str(record.get("failure_code") or "NONE") for record in records
    )
    for record in records:
        for action in record["actions"]:
            if not action.get("accepted", True):
                generation_failures[
                    "ACTION_" + str(action.get("reason_code", "REJECTED"))
                ] += 1
    chgnet_failures = Counter(str(record["status"]) for record in chgnet_records)
    pre_space_group_matches = 0
    pre_space_group_evaluated = 0
    pre_space_groups: Counter[int] = Counter()
    for record in records:
        if not record.get("legal_terminal_crystal", False):
            continue
        try:
            structure = _candidate_structure(record)
            detected = int(
                SpacegroupAnalyzer(structure, symprec=0.1).get_space_group_number()
            )
            pre_space_groups[detected] += 1
            pre_space_group_evaluated += 1
            pre_space_group_matches += int(
                detected == int(record["condition"]["space_group"])
            )
        except Exception:
            generation_failures["PRE_SPACE_GROUP_ANALYSIS_FAILED"] += 1
    evaluated_records = [
        record for record in chgnet_records if record["status"] == "EVALUATED"
    ]
    structural = _structural_uniqueness_and_novelty(records, corpus)
    return {
        "schema_version": "g1-generation-metrics.1.0.0",
        "arm_id": arm_id,
        "attempt_count": attempts,
        "failure_denominator_includes_all_attempts": True,
        "refill_count": 0,
        "completion_count": int(rollout["completion_count"]),
        "free_rollout_completion_rate": float(rollout["completion_rate"]),
        "legal_terminal_count": int(rollout["legal_terminal_count"]),
        "legal_terminal_rate": float(rollout["legal_terminal_rate"]),
        "short_contact_free_count": sum(
            bool(record["short_contact_free"]) for record in records
        ),
        "short_contact_free_rate": sum(
            bool(record["short_contact_free"]) for record in records
        )
        / attempts,
        "pre_projector_validity_rate": pre_valid / max(projector_states, 1),
        "post_projector_validity_rate": post_valid / max(projector_states, 1),
        "projector_rejection_rate": rejected / max(projector_states, 1),
        "projector_correction_amount_mean": _safe_mean(correction),
        "projector_state_count": projector_states,
        "generation_latency_p50_seconds": float(
            rollout["generation_latency_p50_seconds"]
        ),
        "generation_latency_p95_seconds": float(
            rollout["generation_latency_p95_seconds"]
        ),
        "chgnet_evaluated_count": int(chgnet["evaluated_count"]),
        "chgnet_convergence_count": int(chgnet["convergence_count"]),
        "chgnet_convergence_rate_all_attempts": float(
            chgnet["convergence_rate_all_attempts"]
        ),
        "post_relax_survival_count": int(chgnet["post_relax_survival_count"]),
        "post_relax_survival_rate_all_attempts": float(
            chgnet["post_relax_survival_rate_all_attempts"]
        ),
        "pre_max_force_mean_ev_per_angstrom": _safe_mean(
            [float(record["pre_max_force_ev_per_angstrom"]) for record in evaluated_records]
        ),
        "post_max_force_mean_ev_per_angstrom": _safe_mean(
            [float(record["post_max_force_ev_per_angstrom"]) for record in evaluated_records]
        ),
        "relaxation_rmsd_mean_angstrom": _safe_mean(
            [float(record["relaxation_rmsd_angstrom"]) for record in evaluated_records]
        ),
        "lattice_relative_change_mean": _safe_mean(
            [float(record["lattice_relative_change"]) for record in evaluated_records]
        ),
        "pre_relax_space_group_evaluated_count": pre_space_group_evaluated,
        "pre_relax_space_group_match_rate_all_attempts": pre_space_group_matches
        / attempts,
        "pre_relax_detected_space_group_histogram": {
            str(key): value for key, value in sorted(pre_space_groups.items())
        },
        "post_relax_space_group_match_count": sum(
            bool(record.get("space_group_match")) for record in evaluated_records
        ),
        "post_relax_space_group_match_rate_all_attempts": sum(
            bool(record.get("space_group_match")) for record in evaluated_records
        )
        / attempts,
        "generation_failure_taxonomy": dict(sorted(generation_failures.items())),
        "chgnet_status_taxonomy": dict(sorted(chgnet_failures.items())),
        **structural,
    }
