from __future__ import annotations

import hashlib
import math
from collections import defaultdict
from typing import Mapping, Sequence

import numpy as np
from pymatgen.core import Structure
from scipy.stats import rankdata

from crysalis_g1.experiments import response_aware_deconstruction as _response


SELECTION_SEED = 20260901
LANDSCAPE_CANDIDATE_N = 32
LANDSCAPE_RADIUS_ANGSTROM = 1.50
LEVELS = (
    "LEVEL1_SINGLE_SITE",
    "LEVEL2_COUPLED_SITE_PAIR",
    "LEVEL3_STRUCTURAL_UNIT",
)
RESPONSE_ARMS = ("LOCAL_RESPONSE", "GLOBAL_RESPONSE")
CATASTROPHIC_CONTACT_ANGSTROM = 0.35
LARGE_P90_DISPLACEMENT_ANGSTROM = 1.50
LARGE_MAX_DISPLACEMENT_ANGSTROM = 3.00


def deterministic_severity_parent_order(
    rows: Sequence[Mapping[str, object]], *, seed: int = SELECTION_SEED
) -> tuple[str, ...]:
    if not rows:
        raise ValueError("parent selection rows must not be empty")
    grouped: dict[tuple[object, ...], list[str]] = defaultdict(list)
    for row in rows:
        grouped[
            (
                str(row["crystal_system"]),
                int(row["number_of_elements"]),
                int(row["inequivalent_site_count"]),
                str(row["coordination_complexity_bin"]),
            )
        ].append(str(row["parent_id"]))
    parent_ids = [parent_id for values in grouped.values() for parent_id in values]
    if len(parent_ids) != len(set(parent_ids)):
        raise ValueError("parent IDs must be unique")
    priorities = []
    for stratum, values in grouped.items():
        ranked = sorted(
            values,
            key=lambda parent_id: (
                hashlib.sha256(f"{seed}:{parent_id}".encode()).hexdigest(),
                parent_id,
            ),
        )
        for index, parent_id in enumerate(ranked):
            digest = hashlib.sha256(f"{seed}:{parent_id}".encode()).hexdigest()
            priorities.append(
                ((index + 0.5) / len(ranked), repr(stratum), digest, parent_id)
            )
    return tuple(item[-1] for item in sorted(priorities))


def coordination_complexity_bin(signature_n: int) -> str:
    value = int(signature_n)
    if value <= 0:
        raise ValueError("coordination complexity must be positive")
    if value == 1:
        return "1"
    if value == 2:
        return "2"
    if value <= 4:
        return "3-4"
    return "5+"


def _identity_data(structure: Structure) -> tuple[list[str], dict[str, int]]:
    try:
        identities = [str(value) for value in structure.site_properties["atom_identity"]]
    except KeyError as error:
        raise ValueError("structure lacks atom_identity site properties") from error
    if len(identities) != len(set(identities)):
        raise ValueError("atom identities must be unique")
    return identities, {identity: index for index, identity in enumerate(identities)}


def _graph_from_cutoffs(
    structure: Structure, cutoffs: Mapping[tuple[int, int], float]
) -> set[tuple[str, str]]:
    identities, _ = _identity_data(structure)
    species = [int(site.specie.Z) for site in structure]
    distances = np.asarray(structure.distance_matrix, dtype=float)
    edges = set()
    for left in range(len(structure)):
        for right in range(left + 1, len(structure)):
            cutoff = cutoffs.get(tuple(sorted((species[left], species[right]))))
            if cutoff is not None and distances[left, right] <= float(cutoff) + 1e-10:
                edges.add(tuple(sorted((identities[left], identities[right]))))
    return edges


def _adjacency(
    identities: Sequence[str], edges: set[tuple[str, str]]
) -> dict[str, set[str]]:
    result = {identity: set() for identity in identities}
    for left, right in edges:
        result[left].add(right)
        result[right].add(left)
    return result


def _pair_order_key(
    left: str,
    right: str,
    *,
    structure: Structure,
    index_by_id: Mapping[str, int],
    adjacency: Mapping[str, set[str]],
    cutoffs: Mapping[tuple[int, int], float],
) -> tuple[float, ...]:
    pair = tuple(sorted((left, right)))
    direct = float(right in adjacency[left])
    shared = float(len(adjacency[left] & adjacency[right]))
    left_index = int(index_by_id[left])
    right_index = int(index_by_id[right])
    distance = float(structure.get_distance(left_index, right_index))
    species = tuple(
        sorted((int(structure[left_index].specie.Z), int(structure[right_index].specie.Z)))
    )
    cutoff = float(cutoffs.get(species, 0.0))
    proximity = cutoff / distance if direct and distance > 0.0 else 0.0
    degree_sum = float(len(adjacency[left]) + len(adjacency[right]))
    ordered_indices = tuple(sorted((left_index, right_index)))
    return (
        direct,
        shared,
        proximity,
        degree_sum,
        -float(ordered_indices[0]),
        -float(ordered_indices[1]),
    )


def build_nested_deconstruction_actions(
    structure: Structure,
    cutoffs: Mapping[tuple[int, int], float],
) -> tuple[dict[str, object], dict[str, object], dict[str, object]]:
    if len(structure) < 12:
        raise ValueError("level-three deletion would exceed one quarter")
    identities, index_by_id = _identity_data(structure)
    edges = _graph_from_cutoffs(structure, cutoffs)
    if not edges:
        raise ValueError("parent neighbor graph is empty")
    adjacency = _adjacency(identities, edges)
    pairs = [tuple(edge) for edge in edges]
    coupled_pair = max(
        pairs,
        key=lambda pair: _pair_order_key(
            pair[0],
            pair[1],
            structure=structure,
            index_by_id=index_by_id,
            adjacency=adjacency,
            cutoffs=cutoffs,
        ),
    )
    anchor = min(
        coupled_pair,
        key=lambda identity: (
            -len(adjacency[identity]),
            index_by_id[identity],
        ),
    )
    partner = coupled_pair[1] if coupled_pair[0] == anchor else coupled_pair[0]
    anchor_index = index_by_id[anchor]
    partner_index = index_by_id[partner]
    partner_distance = float(structure.get_distance(anchor_index, partner_index))
    partner_species = int(structure[partner_index].specie.Z)
    remaining_neighbors = [
        identity for identity in adjacency[anchor] if identity != partner
    ]
    same_shell = [
        identity
        for identity in remaining_neighbors
        if int(structure[index_by_id[identity]].specie.Z) == partner_species
        and abs(
            float(structure.get_distance(anchor_index, index_by_id[identity]))
            - partner_distance
        )
        <= 0.15 + 1e-12
    ]

    def strongest_identity(values: Sequence[str]) -> str:
        return max(
            values,
            key=lambda identity: _pair_order_key(
                anchor,
                identity,
                structure=structure,
                index_by_id=index_by_id,
                adjacency=adjacency,
                cutoffs=cutoffs,
            ),
        )

    if same_shell:
        third = strongest_identity(same_shell)
        fallback = "SAME_SPECIES_DISTANCE_SHELL"
    elif remaining_neighbors:
        third = strongest_identity(remaining_neighbors)
        fallback = "STRONGEST_REMAINING_ANCHOR_NEIGHBOR"
    else:
        candidates = [identity for identity in identities if identity not in coupled_pair]
        if not candidates:
            raise ValueError("parent cannot form a three-site structural unit")

        def pair_sum(identity: str) -> tuple[float, ...]:
            keys = [
                _pair_order_key(
                    endpoint,
                    identity,
                    structure=structure,
                    index_by_id=index_by_id,
                    adjacency=adjacency,
                    cutoffs=cutoffs,
                )
                for endpoint in coupled_pair
            ]
            return tuple(sum(key[position] for key in keys) for position in range(4)) + (
                -float(index_by_id[identity]),
            )

        third = max(candidates, key=pair_sum)
        fallback = "STRONGEST_COUPLING_TO_PAIR"
    levels = ((anchor,), (anchor, partner), (anchor, partner, third))
    output = []
    for level, removed in zip(LEVELS, levels, strict=True):
        ordered = tuple(sorted(removed, key=index_by_id.__getitem__))
        output.append(
            {
                "severity_level": level,
                "removed_identities": ordered,
                "removed_indices": tuple(index_by_id[value] for value in ordered),
                "removed_atom_fraction": len(ordered) / len(structure),
                "anchor_identity": anchor,
                "anchor_index": anchor_index,
                "representative_species": int(structure[anchor_index].specie.Z),
                "construction_branch": "PRIMARY" if level != LEVELS[2] else fallback,
            }
        )
    if float(output[-1]["removed_atom_fraction"]) > 0.25 + 1e-12:
        raise ValueError("level-three deletion would exceed one quarter")
    return tuple(output)  # type: ignore[return-value]


def deterministic_landscape_offsets(
    *, count: int = LANDSCAPE_CANDIDATE_N, radius: float = LANDSCAPE_RADIUS_ANGSTROM
) -> np.ndarray:
    if count <= 0 or radius <= 0.0:
        raise ValueError("candidate count and radius must be positive")
    golden_angle = math.pi * (3.0 - math.sqrt(5.0))
    rows = []
    for index in range(count):
        z = 1.0 - 2.0 * (index + 0.5) / count
        radial_xy = math.sqrt(max(0.0, 1.0 - z * z))
        angle = golden_angle * index
        direction = np.asarray(
            [radial_xy * math.cos(angle), radial_xy * math.sin(angle), z],
            dtype=float,
        )
        shell_radius = radius * ((index + 0.5) / count) ** (1.0 / 3.0)
        rows.append(direction * shell_radius)
    return np.asarray(rows, dtype=float)


def multi_removed_framework_metrics(
    *,
    damaged_reference: Structure,
    observed: Structure,
    removed_fractional_coordinates: Sequence[Sequence[float]],
    cutoffs: Mapping[tuple[int, int], float],
) -> dict[str, object]:
    displacement = _response.identity_displacement_summary(damaged_reference, observed)
    displacement_by_id = _response._identity_displacements(damaged_reference, observed)
    reference_edges = _response.neighbor_graph(damaged_reference, cutoffs)
    observed_edges = _response.neighbor_graph(observed, cutoffs)
    graph = _response.graph_change_metrics(reference_edges, observed_edges)
    reference_species = _response._identity_species(damaged_reference)
    observed_species = _response._identity_species(observed)
    reference_coordination = _response._species_coordination(
        reference_edges, reference_species
    )
    observed_coordination = _response._species_coordination(
        observed_edges, observed_species
    )
    relative_by_identity = {}
    for identity in sorted(reference_species):
        channels = set(reference_coordination[identity]) | set(
            observed_coordination[identity]
        )
        difference = sum(
            abs(
                reference_coordination[identity].get(channel, 0)
                - observed_coordination[identity].get(channel, 0)
            )
            for channel in channels
        )
        scale = max(
            sum(reference_coordination[identity].values()),
            sum(observed_coordination[identity].values()),
            1,
        )
        relative_by_identity[identity] = min(1.0, difference / scale)
    identities = [
        str(value) for value in damaged_reference.site_properties["atom_identity"]
    ]
    removed = np.asarray(removed_fractional_coordinates, dtype=float)
    if removed.size:
        distances = np.asarray(
            damaged_reference.lattice.get_all_distances(
                removed.reshape((-1, 3)), damaged_reference.frac_coords
            ),
            dtype=float,
        )
        local_ids = {
            identity
            for identity, distance in zip(identities, np.min(distances, axis=0), strict=True)
            if float(distance) <= 5.0 + 1e-12
        }
    else:
        local_ids = set()
    reference_global, reference_pairs = _response._distance_fingerprints(
        damaged_reference
    )
    observed_global, observed_pairs = _response._distance_fingerprints(observed)
    finite = bool(
        np.isfinite(observed.frac_coords).all()
        and np.isfinite(observed.lattice.matrix).all()
        and observed.lattice.volume > 0.0
    )
    return {
        **displacement,
        "p50_displacement_angstrom": float(displacement["median_displacement_angstrom"]),
        **graph,
        "relative_coordination_change": float(
            np.mean(list(relative_by_identity.values()))
        )
        if relative_by_identity
        else 0.0,
        "local_environment_change": float(
            np.mean([relative_by_identity[identity] for identity in sorted(local_ids)])
        )
        if local_ids
        else 0.0,
        "per_identity_relative_coordination_change": relative_by_identity,
        "pair_distance_fingerprint_change": _response._pair_fingerprint_l1(
            reference_pairs, observed_pairs
        ),
        "radial_distribution_fingerprint_change": _response._histogram_l1(
            reference_global, observed_global
        ),
        "minimum_distance_angstrom": _response._minimum_distance(observed),
        "finite_geometry": finite,
        "remaining_atom_n": len(observed),
        "radial_displacement_by_identity": displacement_by_id,
    }


def _clip(value: object, scale: float = 1.0) -> float:
    return float(np.clip(float(value) / scale, 0.0, 1.0))


def framework_response_magnitude(record: Mapping[str, object]) -> float:
    if not bool(record.get("finite_geometry", False)) or bool(
        record.get("mlip_failed", False)
    ):
        return 1.0
    force = record.get("final_max_force_all_ev_per_angstrom")
    if force is None or not math.isfinite(float(force)):
        return 1.0
    displacement = float(
        np.mean(
            (
                _clip(record["p50_displacement_angstrom"], 0.25),
                _clip(record["p90_displacement_angstrom"], 0.75),
                _clip(record["maximum_displacement_angstrom"], 1.50),
            )
        )
    )
    topology = float(
        np.mean(
            (
                _clip(record["edge_deletion_rate"]),
                _clip(record["edge_creation_rate"]),
                _clip(record["relative_coordination_change"]),
            )
        )
    )
    environment = float(
        np.mean(
            (
                _clip(record["local_environment_change"], 2.0),
                _clip(record["pair_distance_fingerprint_change"], 2.0),
                _clip(record["radial_distribution_fingerprint_change"], 2.0),
            )
        )
    )
    symmetry = 1.0 if bool(record["detected_symmetry_changed_from_static"]) else 0.0
    force_block = float(
        np.clip(math.log1p(max(0.0, float(force))) / math.log1p(5.0), 0.0, 1.0)
    )
    convergence = 0.0 if bool(record.get("converged", False)) else 1.0
    return float(
        np.mean((displacement, topology, environment, symmetry, force_block, convergence))
    )


def classify_severity_response(record: Mapping[str, object]) -> str:
    finite = bool(record.get("finite_geometry", False))
    failed = bool(record.get("mlip_failed", False))
    minimum_distance = record.get("minimum_distance_angstrom")
    edge_retention = record.get("remaining_framework_edge_retention")
    p90 = record.get("p90_displacement_angstrom")
    maximum = record.get("maximum_displacement_angstrom")
    collapse = (
        not finite
        or failed
        or minimum_distance is None
        or edge_retention is None
        or p90 is None
        or maximum is None
        or float(minimum_distance) < CATASTROPHIC_CONTACT_ANGSTROM
        or float(edge_retention) < 0.40
        or float(p90) >= LARGE_P90_DISPLACEMENT_ANGSTROM
        or float(maximum) >= LARGE_MAX_DISPLACEMENT_ANGSTROM
    )
    if collapse:
        return "COLLAPSE"
    if not bool(record.get("converged", False)):
        return "INDETERMINATE_RESPONSE"
    if float(edge_retention) >= 0.80:
        return "STABLE_RESPONSE"
    return "RECONSTRUCTED_RESPONSE"


def _bootstrap_mean(
    values: Sequence[float], *, replicates: int, label: str
) -> dict[str, float]:
    array = np.asarray(values, dtype=float)
    if not len(array):
        return {"point": math.nan, "ci95_lower": math.nan, "ci95_upper": math.nan}
    digest = hashlib.sha256(label.encode()).hexdigest()
    rng = np.random.default_rng(int(digest[:16], 16))
    sampled = rng.choice(array, size=(int(replicates), len(array)), replace=True).mean(axis=1)
    return {
        "point": float(np.mean(array)),
        "ci95_lower": float(np.quantile(sampled, 0.025)),
        "ci95_upper": float(np.quantile(sampled, 0.975)),
    }


def analyze_severity_response(
    rows: Sequence[Mapping[str, object]], *, bootstrap_replicates: int = 10_000
) -> dict[str, object]:
    grouped: dict[str, dict[str, dict[str, float]]] = defaultdict(
        lambda: defaultdict(dict)
    )
    for row in rows:
        arm = str(row["arm"])
        if arm not in RESPONSE_ARMS:
            continue
        grouped[str(row["parent_id"])][str(row["severity_level"])][arm] = float(
            row["framework_response_magnitude"]
        )
    parent_values: dict[str, dict[str, float]] = {}
    for parent_id, levels in grouped.items():
        if all(
            level in levels and all(arm in levels[level] for arm in RESPONSE_ARMS)
            for level in LEVELS
        ):
            parent_values[parent_id] = {
                level: float(np.mean([levels[level][arm] for arm in RESPONSE_ARMS]))
                for level in LEVELS
            }
    ordered_parents = sorted(parent_values)
    level_medians = {
        level: float(np.median([parent_values[parent][level] for parent in ordered_parents]))
        if ordered_parents
        else math.nan
        for level in LEVELS
    }
    differences = [
        parent_values[parent][LEVELS[2]] - parent_values[parent][LEVELS[0]]
        for parent in ordered_parents
    ]
    paired = _bootstrap_mean(
        differences,
        replicates=bootstrap_replicates,
        label="deconstruction-severity-level3-minus-level1",
    )
    monotonic_parent_n = sum(
        parent_values[parent][LEVELS[0]]
        < parent_values[parent][LEVELS[1]]
        < parent_values[parent][LEVELS[2]]
        for parent in ordered_parents
    )
    arm_results = {}
    for arm in RESPONSE_ARMS:
        valid = [
            parent
            for parent in sorted(grouped)
            if all(level in grouped[parent] and arm in grouped[parent][level] for level in LEVELS)
        ]
        arm_differences = [
            grouped[parent][LEVELS[2]][arm] - grouped[parent][LEVELS[0]][arm]
            for parent in valid
        ]
        arm_results[arm] = {
            "parent_n": len(valid),
            "level3_minus_level1": _bootstrap_mean(
                arm_differences,
                replicates=bootstrap_replicates,
                label=f"deconstruction-severity-{arm}",
            ),
        }
    medians_increase = (
        level_medians[LEVELS[0]]
        < level_medians[LEVELS[1]]
        < level_medians[LEVELS[2]]
    )
    supported = bool(
        len(ordered_parents) >= 17
        and math.isfinite(float(paired["ci95_lower"]))
        and float(paired["ci95_lower"]) > 0.0
        and medians_increase
        and monotonic_parent_n >= 17
    )
    return {
        "SEVERITY_RESPONSE_SIGNAL": "SUPPORTED" if supported else "NOT_SUPPORTED",
        "valid_parent_n": len(ordered_parents),
        "level_medians": level_medians,
        "level3_minus_level1": paired,
        "monotonic_parent_n": int(monotonic_parent_n),
        "arm_results": arm_results,
    }


def _spearman(left: Sequence[float], right: Sequence[float]) -> float | None:
    x = np.asarray(left, dtype=float)
    y = np.asarray(right, dtype=float)
    if len(x) < 2 or np.allclose(x, x[0]) or np.allclose(y, y[0]):
        return None
    rank_x = rankdata(x, method="average")
    rank_y = rankdata(y, method="average")
    return float(np.corrcoef(rank_x, rank_y)[0, 1])


def analyze_assembly_landscape(
    rows: Sequence[Mapping[str, object]], *, bootstrap_replicates: int = 10_000
) -> dict[str, object]:
    grouped: dict[tuple[str, str, str], list[Mapping[str, object]]] = defaultdict(list)
    for row in rows:
        grouped[(str(row["parent_id"]), str(row["event_id"]), str(row["arm"]))].append(
            row
        )
    states = []
    for (parent_id, event_id, arm), values in sorted(grouped.items()):
        finite = [
            row
            for row in values
            if bool(row.get("finite_geometry", False))
            and row.get("compatibility_score") is not None
            and row.get("candidate_local_max_force_ev_per_angstrom") is not None
            and math.isfinite(float(row["candidate_local_max_force_ev_per_angstrom"]))
        ]
        if len(finite) != LANDSCAPE_CANDIDATE_N:
            continue
        ordered = sorted(
            finite,
            key=lambda row: (float(row["compatibility_score"]), int(row["candidate_index"])),
        )
        scores = [float(row["compatibility_score"]) for row in ordered]
        forces = [float(row["candidate_local_max_force_ev_per_angstrom"]) for row in ordered]
        correlation = _spearman(scores, [math.log1p(value) for value in forces])
        if correlation is None:
            continue
        best = float(np.median(forces[:8]))
        worst = float(np.median(forces[-8:]))
        states.append(
            {
                "parent_id": parent_id,
                "event_id": event_id,
                "severity_level": str(values[0]["severity_level"]),
                "arm": arm,
                "correlation": correlation,
                "best_force_median": best,
                "worst_force_median": worst,
                "log1p_difference": math.log1p(best) - math.log1p(worst),
            }
        )
    by_parent: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in states:
        by_parent[str(row["parent_id"])].append(row)
    parent_rows = []
    for parent_id, values in sorted(by_parent.items()):
        if len(values) < 6:
            continue
        parent_rows.append(
            {
                "parent_id": parent_id,
                "correlation": float(np.mean([float(row["correlation"]) for row in values])),
                "best_force": float(np.mean([float(row["best_force_median"]) for row in values])),
                "worst_force": float(np.mean([float(row["worst_force_median"]) for row in values])),
                "log1p_difference": float(
                    np.mean([float(row["log1p_difference"]) for row in values])
                ),
            }
        )
    correlation = _bootstrap_mean(
        [float(row["correlation"]) for row in parent_rows],
        replicates=bootstrap_replicates,
        label="assembly-landscape-correlation",
    )
    force_difference = _bootstrap_mean(
        [float(row["log1p_difference"]) for row in parent_rows],
        replicates=bootstrap_replicates,
        label="assembly-landscape-best-minus-worst",
    )
    directional_parent_n = sum(
        float(row["best_force"]) < float(row["worst_force"]) for row in parent_rows
    )
    supported = bool(
        len(parent_rows) >= 24
        and math.isfinite(float(correlation["point"]))
        and float(correlation["point"]) >= 0.20
        and float(correlation["ci95_lower"]) > 0.0
        and float(force_difference["ci95_upper"]) < 0.0
        and directional_parent_n >= 17
    )
    state_best = [float(row["best_force_median"]) for row in states]
    state_worst = [float(row["worst_force_median"]) for row in states]
    by_level_arm: dict[str, dict[str, object]] = {}
    subgrouped: dict[tuple[str, str], list[dict[str, object]]] = defaultdict(list)
    for row in states:
        subgrouped[(str(row["severity_level"]), str(row["arm"]))].append(row)
    for (level, arm), values in sorted(subgrouped.items()):
        by_level_arm[f"{level}|{arm}"] = {
            "severity_level": level,
            "arm": arm,
            "state_n": len(values),
            "parent_n": len({str(row["parent_id"]) for row in values}),
            "mean_correlation": float(
                np.mean([float(row["correlation"]) for row in values])
            ),
            "best_quartile_force_median": float(
                np.median([float(row["best_force_median"]) for row in values])
            ),
            "worst_quartile_force_median": float(
                np.median([float(row["worst_force_median"]) for row in values])
            ),
        }
    return {
        "ASSEMBLY_LANDSCAPE_SIGNAL": "SUPPORTED" if supported else "NOT_SUPPORTED",
        "ASSEMBLY_SCORE_FORCE_CORRELATION": float(correlation["point"]),
        "correlation_ci95_lower": float(correlation["ci95_lower"]),
        "correlation_ci95_upper": float(correlation["ci95_upper"]),
        "BEST_QUARTILE_FORCE_MEDIAN": float(np.median(state_best))
        if state_best
        else math.nan,
        "WORST_QUARTILE_FORCE_MEDIAN": float(np.median(state_worst))
        if state_worst
        else math.nan,
        "best_minus_worst_log1p_force": force_difference,
        "valid_parent_n": len(parent_rows),
        "valid_state_n": len(states),
        "directional_parent_n": int(directional_parent_n),
        "by_level_arm": by_level_arm,
    }


def severity_transition_verdict(
    severity_response_signal: str, assembly_landscape_signal: str
) -> tuple[str, str]:
    if severity_response_signal not in {"SUPPORTED", "NOT_SUPPORTED"}:
        raise ValueError("invalid severity response signal")
    if assembly_landscape_signal not in {"SUPPORTED", "NOT_SUPPORTED"}:
        raise ValueError("invalid assembly landscape signal")
    if severity_response_signal == "SUPPORTED" and assembly_landscape_signal == "SUPPORTED":
        return "SUPPORTED", "DESIGN_CRYSALIS_V3_RESPONSE_OPERATOR"
    if severity_response_signal == "SUPPORTED":
        return "RESPONSE_ONLY", "REVISE_COMPATIBILITY_REPRESENTATION"
    return "NOT_SUPPORTED", "STOP_RESPONSE_AWARE_BRANCH"


__all__ = [
    "LANDSCAPE_CANDIDATE_N",
    "LEVELS",
    "RESPONSE_ARMS",
    "analyze_assembly_landscape",
    "analyze_severity_response",
    "build_nested_deconstruction_actions",
    "classify_severity_response",
    "coordination_complexity_bin",
    "deterministic_landscape_offsets",
    "deterministic_severity_parent_order",
    "framework_response_magnitude",
    "multi_removed_framework_metrics",
    "severity_transition_verdict",
]
