from __future__ import annotations

import hashlib
import json
import shutil
import traceback
from dataclasses import asdict
from pathlib import Path
from typing import Any

import torch

from crysalis_g1.experiments.chgnet_terminal import (
    CHGNetEvaluationConfig,
    CHGNetTerminalEvaluator,
)
from crysalis_g1.experiments.local_c0_screening import (
    BackendScreenResult,
    ThroughputConfig,
    benchmark_forward_backward_and_throughput,
    evaluate_geometry_errors,
    select_geometry_backend,
    summarize_rollout_and_chgnet,
    write_geometry_freeze,
)
from crysalis_g1.experiments.local_free_rollout import (
    FreeRolloutConfig,
    run_free_rollouts,
)
from crysalis_g1.experiments.local_generation_metrics import (
    aggregate_generation_metrics,
)
from crysalis_g1.experiments.local_pilot_config import (
    geometry_candidates,
    pilot_model_config,
    select_geometry,
)
from crysalis_g1.experiments.local_pilot_data import FrozenPhase2ACorpus
from crysalis_g1.experiments.local_pilot_training import (
    TrainingLoopConfig,
    common_non_geometry_state,
    derive_named_seed,
    derive_training_loss_scales,
    run_training,
    state_dict_sha256,
)
from crysalis_g1.experiments.local_relation_learning import (
    RelationLearningCorpus,
    RelationTrainingConfig,
    run_relation_stage,
)
from crysalis_g1.experiments.local_run_state import LocalRunConfig, LocalRunState
from crysalis_g1.model.local_pilot_model import (
    PilotLossScales,
    UnifiedLocalPilotModel,
)


_ARMS = ("C0", "C1", "C2", "C3-Full")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _write_json_new(path: Path, payload: object) -> None:
    if path.exists():
        raise FileExistsError(f"artifact refuses to overwrite: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            allow_nan=False,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


def _write_text_new(path: Path, text: str) -> None:
    if path.exists():
        raise FileExistsError(f"artifact refuses to overwrite: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def _source_tree_sha256(repo_root: Path) -> str:
    paths = sorted((repo_root / "crysalis_g1").rglob("*.py"))
    paths.extend(
        path
        for path in (
            repo_root / "pyproject.toml",
            repo_root / "configs" / "g1_autonomous_local_single_seed_20260825.json",
        )
        if path.is_file()
    )
    digest = hashlib.sha256()
    for path in sorted(paths):
        digest.update(path.relative_to(repo_root).as_posix().encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _load_payload(config_path: str | Path) -> dict[str, Any]:
    payload = json.loads(Path(config_path).read_text(encoding="utf-8"))
    required_true = (
        "local_autonomous_execution_authorized",
        "local_single_seed_pilot_authorized",
        "no_refill",
    )
    if any(payload.get(name) is not True for name in required_true):
        raise ValueError("local autonomous authorization flags are incomplete")
    if payload.get("server_deployment_authorized") is not False:
        raise ValueError("server deployment must remain unauthorized")
    if payload.get("three_seed_authorized") is not False:
        raise ValueError("three-seed execution must remain unauthorized")
    if int(payload.get("root_seed", -1)) != 20260823:
        raise ValueError("root seed must remain 20260823")
    return payload


def _run_config(payload: dict[str, Any]) -> LocalRunConfig:
    fields = LocalRunConfig.__dataclass_fields__
    return LocalRunConfig(**{name: payload[name] for name in fields})


def _new_model(
    *,
    arm_id: str,
    backend: str,
    seed: int,
    relation_library_backend: str = "matched_mlp",
) -> UnifiedLocalPilotModel:
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    geometry = select_geometry(backend)
    return UnifiedLocalPilotModel(
        pilot_model_config(
            arm_id=arm_id,
            geometry=geometry,
            relation_library_backend=relation_library_backend,
        )
    )


def _clone_state(state: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
    return {name: value.detach().cpu().clone() for name, value in state.items()}


def _load_training_checkpoint(
    model: UnifiedLocalPilotModel, training_dir: Path, summary: dict[str, Any]
) -> tuple[Path, str]:
    update = int(summary["best_validation_update"])
    checkpoint = training_dir / "checkpoints" / f"update-{update}.pt"
    if not checkpoint.is_file():
        raise RuntimeError(f"best validation checkpoint is missing: {checkpoint}")
    payload = torch.load(checkpoint, map_location="cpu", weights_only=True)
    if int(payload["completed_updates"]) != update:
        raise RuntimeError("checkpoint completed-update trace is inconsistent")
    model.load_state_dict(payload["model_state_dict"], strict=True)
    return checkpoint, _sha256(checkpoint)


def _chgnet_config(payload: dict[str, Any]) -> CHGNetEvaluationConfig:
    return CHGNetEvaluationConfig(
        package_version=str(payload["chgnet_package_version"]),
        model_version=str(payload["chgnet_model_version"]),
        weight_path=str(payload["chgnet_weight_path"]),
        weight_sha256=str(payload["chgnet_weight_sha256"]),
        optimizer=str(payload["chgnet_optimizer"]),
        force_threshold_ev_per_angstrom=float(
            payload["chgnet_force_threshold_ev_per_angstrom"]
        ),
        maximum_steps=int(payload["chgnet_maximum_steps"]),
        relax_cell=bool(payload["chgnet_relax_cell"]),
        short_contact_distance=float(payload["short_contact_distance"]),
        device=str(payload["device"]),
    )


def _rollout_config(payload: dict[str, Any], *, temperature: float | None = None) -> FreeRolloutConfig:
    return FreeRolloutConfig(
        root_seed=int(payload["root_seed"]),
        max_assembly_steps=int(payload["max_assembly_steps"]),
        max_orbits=int(payload["max_orbits"]),
        short_contact_distance=float(payload["short_contact_distance"]),
        device=str(payload["device"]),
        mixed_precision=bool(payload["mixed_precision"]),
        sampling_temperature=(
            float(payload["sampling_temperature"])
            if temperature is None
            else temperature
        ),
        coordinate_proposal_budget=int(payload["coordinate_proposal_budget"]),
    )


def _condition_manifest(
    corpus: FrozenPhase2ACorpus,
    *,
    count: int,
    root_seed: int,
    path: Path,
) -> tuple[list[dict[str, Any]], str]:
    conditions = corpus.build_condition_manifest(
        count=count, split="validation", root_seed=root_seed
    )
    forbidden = {
        "material_id",
        "parent_coordinates",
        "parent_lattice",
        "canonical_structure_hash",
    }
    if any(forbidden.intersection(condition) for condition in conditions):
        raise RuntimeError("parent information leaked into condition manifest")
    _write_json_new(
        path,
        {
            "schema_version": "g1-parent-free-condition-manifest.1.0.0",
            "root_seed": root_seed,
            "attempt_count": count,
            "parent_coordinates_present": False,
            "parent_lattice_present": False,
            "material_id_lookup_present": False,
            "conditions": conditions,
        },
    )
    return conditions, _sha256(path)


def _c0_markdown(
    freeze: dict[str, Any],
    *,
    parameter_match: dict[str, Any],
) -> str:
    rows = []
    for backend, label in (("periodic_egnn", "periodic-EGNN"), ("e3nn_lite", "e3nn-lite")):
        value = freeze[backend]
        rows.append(
            f"| {label} | {value['coordinate_error']:.6f} | {value['lattice_error']:.6f} | "
            f"{value['pre_projector_validity_rate']:.4f} | {value['free_rollout_completion_rate']:.4f} | "
            f"{value['short_contact_free_rate']:.4f} | {value['post_relax_survival_rate']:.4f} | "
            f"{value['steps_per_second']:.3f} | {value['peak_reserved_vram_gib']:.3f} | "
            f"{value['generation_latency_p50_seconds']:.4f} | {value['quality_score']:.4f} | "
            f"{value['hard_pass']} |"
        )
    return "\n".join(
        (
            "# C0 Backend Screening Results",
            "",
            "Both C0 backends used the corrected frozen Phase 2A cache, root seed "
            "20260823, a shared non-geometry initialization, the same batch schedule, "
            "500 updates, 100 parent-free rollout attempts, and the same frozen CHGNet evaluator.",
            "",
            "| Backend | Coordinate error | Lattice error | Pre-projector valid | Completion | Short-contact free | Post-relax survival | steps/s | Peak VRAM GiB | Gen p50 s | Quality | Hard pass |",
            "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
            *rows,
            "",
            f"Geometry-only parameter counts were {parameter_match['periodic_parameter_count']} "
            f"and {parameter_match['e3nn_parameter_count']} (relative gap "
            f"{parameter_match['relative_difference']:.6f}).",
            "",
            f"Frozen backend: `{freeze['selected_backend']}` via "
            f"`{freeze['selection_rule']}`.",
            "",
            "This screen compares only C0. It does not create a C0-C3 by backend eight-arm matrix.",
            "",
        )
    )


def _stage_c0_screening(
    *,
    state: LocalRunState,
    payload: dict[str, Any],
    code_sha256: str,
) -> None:
    stage = "C0_BACKEND_SCREENING"
    output_root = state.root
    stage_root = output_root / "c0_backend_screening"
    freeze_path = output_root / "GEOMETRY_BACKEND_FREEZE.json"
    recovery_inputs = [
        stage_root / backend / name
        for backend in ("periodic_egnn", "e3nn_lite")
        for name in (
            "engineering_benchmark.json",
            "training/training_summary.json",
            "rollout_summary.json",
            "chgnet_terminal.json",
        )
    ]
    if freeze_path.is_file() and all(path.is_file() for path in recovery_inputs):
        state.start_stage(stage, checkpoint_path=None)
        freeze = json.loads(freeze_path.read_text(encoding="utf-8"))
        parameter_match = json.loads(
            (stage_root / "geometry_parameter_match.json").read_text(
                encoding="utf-8"
            )
        )
        engineering = {
            backend: json.loads(
                (
                    stage_root / backend / "engineering_benchmark.json"
                ).read_text(encoding="utf-8")
            )
            for backend in ("periodic_egnn", "e3nn_lite")
        }
        training = {
            backend: json.loads(
                (
                    stage_root
                    / backend
                    / "training"
                    / "training_summary.json"
                ).read_text(encoding="utf-8")
            )
            for backend in ("periodic_egnn", "e3nn_lite")
        }
        rollout = {
            backend: json.loads(
                (stage_root / backend / "rollout_summary.json").read_text(
                    encoding="utf-8"
                )
            )
            for backend in ("periodic_egnn", "e3nn_lite")
        }
        chgnet = {}
        for backend in ("periodic_egnn", "e3nn_lite"):
            full = json.loads(
                (stage_root / backend / "chgnet_terminal.json").read_text(
                    encoding="utf-8"
                )
            )
            chgnet[backend] = {
                name: value for name, value in full.items() if name != "records"
            }
        summary_path = stage_root / "screening_summary.json"
        if not summary_path.exists():
            _write_json_new(
                summary_path,
                {
                    "freeze": freeze,
                    "parameter_match": parameter_match,
                    "engineering": engineering,
                    "training": training,
                    "rollout": rollout,
                    "chgnet": chgnet,
                    "recovered_from_complete_artifacts": True,
                    "recovery_reason": "WINDOWS_CASE_INSENSITIVE_FREEZE_FILENAME_COLLISION",
                },
            )
        report_path = output_root / "C0_BACKEND_SCREENING_RESULTS.md"
        if not report_path.exists():
            _write_text_new(
                report_path,
                _c0_markdown(freeze, parameter_match=parameter_match),
            )
        recovery_path = stage_root / "stage_recovery.json"
        if not recovery_path.exists():
            _write_json_new(
                recovery_path,
                {
                    "status": "RECOVERED",
                    "reason_code": "WINDOWS_CASE_INSENSITIVE_FREEZE_FILENAME_COLLISION",
                    "scientific_stages_rerun": False,
                    "complete_artifacts_verified": True,
                    "previous_code_sha256": freeze["code_sha256"],
                    "recovery_code_sha256": code_sha256,
                },
            )
        state.complete_stage(stage, next_stage="RELATION_LEARNING")
        return
    state.start_stage(stage, checkpoint_path=None)
    stage_root.mkdir()
    corpus = FrozenPhase2ACorpus.load(
        payload["phase2a_root"],
        expected_manifest_sha256=payload["expected_phase2a_manifest_sha256"],
    )
    train_keys = corpus.example_keys("train_fit")
    validation_keys = corpus.example_keys("validation")
    conditions, condition_sha = _condition_manifest(
        corpus,
        count=int(payload["c0_rollout_attempts"]),
        root_seed=int(payload["root_seed"]),
        path=stage_root / "c0_conditions_100.json",
    )
    match = geometry_candidates()
    parameter_match = {
        "periodic_parameter_count": match.periodic_parameter_count,
        "e3nn_parameter_count": match.e3nn_parameter_count,
        "relative_difference": match.relative_difference,
        "periodic_config": asdict(match.periodic_config),
        "e3nn_config": asdict(match.e3nn_config),
    }
    _write_json_new(stage_root / "geometry_parameter_match.json", parameter_match)

    initialization_seed = derive_named_seed(
        int(payload["root_seed"]), "c0:shared-common-initialization"
    )
    initial_models = {
        backend: _new_model(
            arm_id="C0", backend=backend, seed=initialization_seed
        )
        for backend in ("periodic_egnn", "e3nn_lite")
    }
    initial_models["e3nn_lite"].load_state_dict(
        common_non_geometry_state(initial_models["periodic_egnn"]),
        strict=False,
    )
    non_geometry = {
        backend: common_non_geometry_state(model)
        for backend, model in initial_models.items()
    }
    periodic_hash = state_dict_sha256(non_geometry["periodic_egnn"])
    e3nn_hash = state_dict_sha256(non_geometry["e3nn_lite"])
    if periodic_hash != e3nn_hash:
        raise RuntimeError("C0 non-geometry common initialization mismatch")
    common_initialization_sha = periodic_hash
    torch.save(
        non_geometry["periodic_egnn"], stage_root / "common_non_geometry_state.pt"
    )
    _write_json_new(
        stage_root / "common_initialization.json",
        {
            "root_seed": payload["root_seed"],
            "stream": "c0:shared-common-initialization",
            "stream_seed": initialization_seed,
            "non_geometry_state_sha256": common_initialization_sha,
            "identical_across_backends": True,
        },
    )

    engineering: dict[str, dict[str, Any]] = {}
    training_summaries: dict[str, dict[str, Any]] = {}
    rollout_summaries: dict[str, dict[str, Any]] = {}
    geometry_errors: dict[str, dict[str, float]] = {}
    for backend in ("periodic_egnn", "e3nn_lite"):
        backend_root = stage_root / backend
        backend_root.mkdir()
        initial_state = _clone_state(initial_models[backend].state_dict())
        benchmark_model = _new_model(
            arm_id="C0", backend=backend, seed=initialization_seed
        )
        benchmark_model.load_state_dict(initial_state)
        throughput = benchmark_forward_backward_and_throughput(
            model=benchmark_model,
            corpus=corpus,
            train_keys=train_keys,
            loss_scales=PilotLossScales.unit(),
            config=ThroughputConfig(
                root_seed=int(payload["root_seed"]),
                device=str(payload["device"]),
                batch_size=int(payload["batch_size"]),
                gradient_accumulation_steps=int(
                    payload["gradient_accumulation_steps"]
                ),
                mixed_precision=bool(payload["mixed_precision"]),
                forward_backward_batches=int(
                    payload["c0_forward_backward_batches"]
                ),
                throughput_steps=int(payload["c0_throughput_steps"]),
                learning_rate=float(payload["learning_rate"]),
                weight_decay=float(payload["weight_decay"]),
                gradient_clip_norm=float(payload["gradient_clip_norm"]),
            ),
        )
        engineering[backend] = throughput
        _write_json_new(backend_root / "engineering_benchmark.json", throughput)
        del benchmark_model
        torch.cuda.empty_cache()

        training_model = _new_model(
            arm_id="C0", backend=backend, seed=initialization_seed
        )
        training_model.load_state_dict(initial_state)
        training_dir = backend_root / "training"
        training_summary = run_training(
            model=training_model,
            corpus=corpus,
            train_keys=train_keys,
            validation_keys=validation_keys,
            loss_scales=PilotLossScales.unit(),
            config=TrainingLoopConfig(
                root_seed=int(payload["root_seed"]),
                stream_name=f"c0-screen:{backend}",
                device=str(payload["device"]),
                batch_size=int(payload["batch_size"]),
                gradient_accumulation_steps=int(
                    payload["gradient_accumulation_steps"]
                ),
                mixed_precision=bool(payload["mixed_precision"]),
                learning_rate=float(payload["learning_rate"]),
                weight_decay=float(payload["weight_decay"]),
                gradient_clip_norm=float(payload["gradient_clip_norm"]),
                maximum_updates=int(payload["c0_training_updates"]),
                minimum_updates=int(payload["c0_training_updates"]),
                validation_interval=100,
                checkpoint_interval=100,
                early_stopping_patience=10,
                validation_batches=25,
            ),
            output_dir=training_dir,
            code_sha256=code_sha256,
            phase2a_manifest_sha256=payload[
                "expected_phase2a_manifest_sha256"
            ],
            common_initialization_sha256=common_initialization_sha,
            progress_callback=lambda update, checkpoint, backend=backend: state.heartbeat(
                update=update,
                checkpoint_path=(
                    str(
                        stage_root
                        / backend
                        / "training"
                        / "checkpoints"
                        / checkpoint
                    )
                    if checkpoint
                    else None
                ),
            ),
        )
        training_summaries[backend] = training_summary
        checkpoint_path, checkpoint_sha = _load_training_checkpoint(
            training_model, training_dir, training_summary
        )
        training_summary["selected_checkpoint_path"] = str(checkpoint_path)
        training_summary["selected_checkpoint_sha256"] = checkpoint_sha
        geometry_errors[backend] = evaluate_geometry_errors(
            model=training_model,
            corpus=corpus,
            validation_keys=validation_keys,
            root_seed=int(payload["root_seed"]),
            batch_size=int(payload["batch_size"]),
            batch_count=25,
            device_name=str(payload["device"]),
            mixed_precision=bool(payload["mixed_precision"]),
        )
        rollout_path = backend_root / "rollouts.jsonl"
        rollout = run_free_rollouts(
            model=training_model,
            conditions=conditions,
            config=_rollout_config(payload),
            output_path=rollout_path,
        )
        rollout["condition_manifest_sha256"] = condition_sha
        rollout["selected_checkpoint_sha256"] = checkpoint_sha
        rollout_summaries[backend] = rollout
        _write_json_new(
            backend_root / "rollout_summary.json",
            {name: value for name, value in rollout.items() if name != "records"},
        )
        training_model.cpu()
        del training_model
        torch.cuda.empty_cache()

    if all(
        int(rollout_summaries[backend]["legal_terminal_count"]) == 0
        for backend in rollout_summaries
    ):
        for repair_round, temperature in ((1, 0.6), (2, 0.4)):
            repaired: dict[str, dict[str, Any]] = {}
            for backend in ("periodic_egnn", "e3nn_lite"):
                backend_root = stage_root / backend
                model = _new_model(
                    arm_id="C0", backend=backend, seed=initialization_seed
                )
                _load_training_checkpoint(
                    model, backend_root / "training", training_summaries[backend]
                )
                rollout = run_free_rollouts(
                    model=model,
                    conditions=conditions,
                    config=_rollout_config(payload, temperature=temperature),
                    output_path=backend_root
                    / f"repair-{repair_round}-rollouts.jsonl",
                )
                repaired[backend] = rollout
                model.cpu()
                del model
                torch.cuda.empty_cache()
            rollout_summaries = repaired
            if any(
                int(value["legal_terminal_count"]) > 0
                for value in rollout_summaries.values()
            ):
                _write_json_new(
                    stage_root / "core_generation_repair.json",
                    {
                        "repair_round": repair_round,
                        "sampling_temperature": temperature,
                        "root_seed_unchanged": True,
                        "attempt_count_unchanged": True,
                        "data_unchanged": True,
                    },
                )
                break

    evaluator = CHGNetTerminalEvaluator(_chgnet_config(payload))
    chgnet_summaries: dict[str, dict[str, Any]] = {}
    screen_results: dict[str, BackendScreenResult] = {}
    for backend in ("periodic_egnn", "e3nn_lite"):
        backend_root = stage_root / backend
        chgnet = evaluator.evaluate(
            rollout_summaries[backend]["records"],
            output_path=backend_root / "chgnet_terminal.json",
        )
        chgnet_summaries[backend] = chgnet
        generated = summarize_rollout_and_chgnet(
            rollout=rollout_summaries[backend], chgnet=chgnet
        )
        screen_results[backend] = BackendScreenResult(
            backend=backend,
            forward_backward_finite=bool(
                engineering[backend]["forward_backward_finite"]
            ),
            unhandled_oom=False,
            rollout_record_count=int(generated["rollout_record_count"]),
            legal_terminal_count=int(generated["legal_terminal_count"]),
            peak_reserved_vram_bytes=max(
                int(engineering[backend]["peak_reserved_vram_bytes"]),
                int(training_summaries[backend]["peak_reserved_vram_bytes"]),
                int(rollout_summaries[backend]["peak_reserved_vram_bytes"]),
            ),
            post_relax_survival_rate=float(
                generated["post_relax_survival_rate"]
            ),
            free_rollout_completion_rate=float(
                generated["free_rollout_completion_rate"]
            ),
            short_contact_free_rate=float(generated["short_contact_free_rate"]),
            pre_projector_validity_rate=float(
                generated["pre_projector_validity_rate"]
            ),
            generation_latency_p50_seconds=float(
                generated["generation_latency_p50_seconds"]
            ),
            coordinate_error=geometry_errors[backend]["coordinate_error"],
            lattice_error=geometry_errors[backend]["lattice_error"],
            steps_per_second=float(engineering[backend]["steps_per_second"]),
        )
    freeze = select_geometry_backend(
        periodic=screen_results["periodic_egnn"],
        e3nn=screen_results["e3nn_lite"],
    )
    freeze["condition_manifest_sha256"] = condition_sha
    freeze["phase2a_manifest_sha256"] = payload[
        "expected_phase2a_manifest_sha256"
    ]
    freeze["code_sha256"] = code_sha256
    write_geometry_freeze(
        output_root,
        freeze,
        phase2a_manifest_sha256=payload["expected_phase2a_manifest_sha256"],
        code_sha256=code_sha256,
    )
    _write_json_new(
        stage_root / "screening_summary.json",
        {
            "freeze": freeze,
            "parameter_match": parameter_match,
            "engineering": engineering,
            "training": training_summaries,
            "rollout": {
                backend: {
                    name: value
                    for name, value in summary.items()
                    if name != "records"
                }
                for backend, summary in rollout_summaries.items()
            },
            "chgnet": {
                backend: {
                    name: value
                    for name, value in summary.items()
                    if name != "records"
                }
                for backend, summary in chgnet_summaries.items()
            },
        },
    )
    _write_text_new(
        output_root / "C0_BACKEND_SCREENING_RESULTS.md",
        _c0_markdown(freeze, parameter_match=parameter_match),
    )
    state.complete_stage(stage, next_stage="RELATION_LEARNING")


def _stage_relation_learning(
    *,
    state: LocalRunState,
    payload: dict[str, Any],
    code_sha256: str,
) -> None:
    stage = "RELATION_LEARNING"
    state.start_stage(stage, checkpoint_path=None)
    relation_root = state.root / "relation_learning"
    corpus = RelationLearningCorpus.load(
        payload["phase2a_root"],
        expected_manifest_sha256=payload["expected_phase2a_manifest_sha256"],
    )
    result = run_relation_stage(
        corpus=corpus,
        train_split="train_fit",
        validation_split="validation",
        config=RelationTrainingConfig(
            root_seed=int(payload["root_seed"]),
            device=str(payload["device"]),
            batch_size=int(payload["relation_batch_size"]),
            learning_rate=float(payload["relation_learning_rate"]),
            weight_decay=float(payload["relation_weight_decay"]),
            maximum_updates=int(payload["relation_maximum_updates"]),
            minimum_updates=int(payload["relation_minimum_updates"]),
            validation_interval=int(payload["relation_validation_interval"]),
            early_stopping_patience=int(
                payload["relation_early_stopping_patience"]
            ),
            latency_repetitions=50,
        ),
        output_dir=relation_root,
        phase2a_manifest_sha256=payload["expected_phase2a_manifest_sha256"],
        code_sha256=code_sha256,
        student_maximum_updates=int(payload["student_maximum_updates"]),
        student_minimum_updates=int(payload["student_minimum_updates"]),
        student_validation_interval=int(payload["student_validation_interval"]),
    )
    for name in (
        "RELATION_TEACHER_COMPARISON.md",
        "RELATION_LIBRARY_ARTIFACT.json",
        "relation_library_state_dict.pt",
    ):
        destination = state.root / name
        if destination.exists():
            raise FileExistsError(f"relation deliverable already exists: {destination}")
        shutil.copy2(relation_root / name, destination)
    state.heartbeat(
        update=max(
            int(result["teachers"][name]["completed_updates"])
            for name in ("cr_kan", "matched_mlp")
        ),
        checkpoint_path=str(relation_root / "relation_library_state_dict.pt"),
    )
    state.complete_stage(stage, next_stage="FORMAL_ARM_TRAINING")


def _load_relation_library_state(
    relation_root: Path,
) -> tuple[str, dict[str, torch.Tensor], dict[str, Any]]:
    artifact_path = relation_root / "RELATION_LIBRARY_ARTIFACT.json"
    artifact = json.loads(artifact_path.read_text(encoding="utf-8"))
    state_path = relation_root / str(artifact["state_dict_file"])
    if _sha256(state_path) != artifact["state_dict_sha256"]:
        raise RuntimeError("relation-library artifact hash mismatch")
    relation_state = torch.load(state_path, map_location="cpu", weights_only=True)
    return str(artifact["selected_backend"]), relation_state, artifact


def _stage_formal_training(
    *,
    state: LocalRunState,
    payload: dict[str, Any],
    code_sha256: str,
) -> None:
    stage = "FORMAL_ARM_TRAINING"
    state.start_stage(stage, checkpoint_path=None)
    output_root = state.root
    stage_root = output_root / "formal_arm_training"
    stage_root.mkdir()
    freeze = json.loads(
        (output_root / "GEOMETRY_BACKEND_FREEZE.json").read_text(encoding="utf-8")
    )
    backend = str(freeze["selected_backend"])
    relation_backend, relation_state, relation_artifact = _load_relation_library_state(
        output_root / "relation_learning"
    )
    corpus = FrozenPhase2ACorpus.load(
        payload["phase2a_root"],
        expected_manifest_sha256=payload["expected_phase2a_manifest_sha256"],
    )
    train_keys = corpus.example_keys("train_fit")
    validation_keys = corpus.example_keys("validation")
    common_seed = derive_named_seed(
        int(payload["root_seed"]), "formal-arms:common-initialization"
    )
    common_model = _new_model(
        arm_id="C0",
        backend=backend,
        seed=common_seed,
        relation_library_backend=relation_backend,
    )
    common_model.relation_library.network.load_state_dict(
        relation_state, strict=True
    )
    common_state = _clone_state(common_model.state_dict())
    common_sha = state_dict_sha256(common_state)
    torch.save(common_state, stage_root / "common_initialization_state.pt")
    scales, scale_report = derive_training_loss_scales(
        model=common_model,
        corpus=corpus,
        train_keys=train_keys,
        root_seed=int(payload["root_seed"]),
        batch_size=int(payload["batch_size"]),
        batch_count=128,
        device_name=str(payload["device"]),
        mixed_precision=bool(payload["mixed_precision"]),
    )
    _write_json_new(stage_root / "LOSS_SCALE_ARTIFACT.json", scale_report)
    common_model.cpu()
    del common_model
    torch.cuda.empty_cache()
    _write_json_new(
        stage_root / "common_initialization.json",
        {
            "root_seed": payload["root_seed"],
            "stream": "formal-arms:common-initialization",
            "stream_seed": common_seed,
            "state_dict_sha256": common_sha,
            "geometry_backend": backend,
            "relation_library_backend": relation_backend,
            "relation_library_state_sha256": relation_artifact[
                "state_dict_sha256"
            ],
            "copied_independently_to_each_arm": True,
            "sequential_inheritance": False,
        },
    )

    arm_results: dict[str, dict[str, Any]] = {}
    for arm_index, arm_id in enumerate(_ARMS):
        arm_root = stage_root / arm_id
        model = _new_model(
            arm_id=arm_id,
            backend=backend,
            seed=common_seed,
            relation_library_backend=relation_backend,
        )
        model.load_state_dict(common_state, strict=True)
        if state_dict_sha256(_clone_state(model.state_dict())) != common_sha:
            raise RuntimeError(f"{arm_id} did not start from common initialization")
        try:
            training_summary = run_training(
                model=model,
                corpus=corpus,
                train_keys=train_keys,
                validation_keys=validation_keys,
                loss_scales=scales,
                config=TrainingLoopConfig(
                    root_seed=int(payload["root_seed"]),
                    stream_name=f"formal-single-seed:{arm_id}",
                    device=str(payload["device"]),
                    batch_size=int(payload["batch_size"]),
                    gradient_accumulation_steps=int(
                        payload["gradient_accumulation_steps"]
                    ),
                    mixed_precision=bool(payload["mixed_precision"]),
                    learning_rate=float(payload["learning_rate"]),
                    weight_decay=float(payload["weight_decay"]),
                    gradient_clip_norm=float(payload["gradient_clip_norm"]),
                    maximum_updates=int(payload["arm_maximum_updates"]),
                    minimum_updates=int(payload["arm_minimum_updates"]),
                    validation_interval=int(payload["arm_validation_interval"]),
                    checkpoint_interval=int(payload["arm_checkpoint_interval"]),
                    early_stopping_patience=int(
                        payload["arm_early_stopping_patience"]
                    ),
                    validation_batches=50,
                ),
                output_dir=arm_root,
                code_sha256=code_sha256,
                phase2a_manifest_sha256=payload[
                    "expected_phase2a_manifest_sha256"
                ],
                common_initialization_sha256=common_sha,
                progress_callback=lambda update, checkpoint, arm_id=arm_id: state.heartbeat(
                    update=update,
                    checkpoint_path=(
                        str(
                            stage_root
                            / arm_id
                            / "checkpoints"
                            / checkpoint
                        )
                        if checkpoint
                        else None
                    ),
                ),
            )
            checkpoint_path, checkpoint_sha = _load_training_checkpoint(
                model, arm_root, training_summary
            )
            training_summary["selected_checkpoint_path"] = str(checkpoint_path)
            training_summary["selected_checkpoint_sha256"] = checkpoint_sha
            training_summary["common_initialization_verified"] = True
            arm_results[arm_id] = training_summary
        except Exception as error:
            arm_results[arm_id] = {
                "status": "FAILED",
                "arm_id": arm_id,
                "exception_type": type(error).__name__,
                "exception_message": str(error),
                "traceback": traceback.format_exc(),
                "common_initialization_verified": True,
                "failure_preserved": True,
            }
            _write_json_new(
                stage_root / f"{arm_id}-training-failure.json",
                arm_results[arm_id],
            )
        finally:
            model.cpu()
            del model
            torch.cuda.empty_cache()
        state.heartbeat(
            update=(arm_index + 1) * int(payload["arm_maximum_updates"]),
            checkpoint_path=arm_results[arm_id].get("selected_checkpoint_path"),
        )
    manifest = {
        "schema_version": "g1-formal-arm-training-manifest.1.0.0",
        "status": "PASS_WITH_RECORDED_ARM_FAILURES"
        if any(value["status"] != "PASS" for value in arm_results.values())
        else "PASS",
        "root_seed": payload["root_seed"],
        "geometry_backend": backend,
        "relation_library_backend": relation_backend,
        "common_initialization_sha256": common_sha,
        "phase2a_manifest_sha256": payload[
            "expected_phase2a_manifest_sha256"
        ],
        "same_training_batch_schedule": True,
        "same_training_budget": True,
        "independent_parameters_optimizers_schedulers_checkpoints": True,
        "sequential_arm_inheritance": False,
        "arms": arm_results,
    }
    _write_json_new(stage_root / "arm_training_manifest.json", manifest)
    state.complete_stage(stage, next_stage="FREE_GENERATION")


def _failure_rollout_summary(
    *,
    conditions: list[dict[str, Any]],
    failure_code: str,
    output_path: Path,
) -> dict[str, Any]:
    records = []
    with output_path.open("x", encoding="utf-8") as stream:
        for condition in conditions:
            record = {
                "condition": condition,
                "completed": False,
                "failure_code": failure_code,
                "legal_terminal_crystal": False,
                "composition_complete": False,
                "short_contact_free": False,
                "minimum_distance_angstrom": None,
                "actions": [],
                "relation_memory_trace": [],
                "candidate": {
                    "atomic_numbers": [],
                    "fractional_coordinates": [],
                    "lattice": [],
                    "orbit_count": 0,
                },
                "projector": {
                    "pre_valid_count": 0,
                    "post_valid_count": 0,
                    "attempted_state_count": 0,
                    "rejection_count": 0,
                    "correction_amount_mean": 0.0,
                },
                "generation_latency_seconds": 0.0,
            }
            records.append(record)
            stream.write(
                json.dumps(record, sort_keys=True, separators=(",", ":"))
                + "\n"
            )
    return {
        "root_seed": 20260823,
        "attempt_count": len(records),
        "completion_count": 0,
        "failure_count": len(records),
        "legal_terminal_count": 0,
        "refill_count": 0,
        "completion_rate": 0.0,
        "legal_terminal_rate": 0.0,
        "generation_latency_p50_seconds": 0.0,
        "generation_latency_p95_seconds": 0.0,
        "wall_seconds": 0.0,
        "peak_allocated_vram_bytes": 0,
        "peak_reserved_vram_bytes": 0,
        "records": records,
    }


def _stage_free_generation(
    *, state: LocalRunState, payload: dict[str, Any]
) -> None:
    stage = "FREE_GENERATION"
    state.start_stage(stage, checkpoint_path=None)
    output_root = state.root
    stage_root = output_root / "formal_generation"
    stage_root.mkdir()
    corpus = FrozenPhase2ACorpus.load(
        payload["phase2a_root"],
        expected_manifest_sha256=payload["expected_phase2a_manifest_sha256"],
    )
    conditions, condition_sha = _condition_manifest(
        corpus,
        count=int(payload["formal_rollout_attempts"]),
        root_seed=int(payload["root_seed"]),
        path=stage_root / "shared_conditions_300.json",
    )
    training_root = output_root / "formal_arm_training"
    training_manifest = json.loads(
        (training_root / "arm_training_manifest.json").read_text(encoding="utf-8")
    )
    common_state = torch.load(
        training_root / "common_initialization_state.pt",
        map_location="cpu",
        weights_only=True,
    )
    backend = str(training_manifest["geometry_backend"])
    relation_backend = str(training_manifest["relation_library_backend"])
    generation_manifest: dict[str, Any] = {
        "schema_version": "g1-formal-generation-manifest.1.0.0",
        "root_seed": payload["root_seed"],
        "condition_manifest_sha256": condition_sha,
        "same_condition_manifest": True,
        "same_generation_budget": True,
        "attempts_per_arm": len(conditions),
        "refill_count": 0,
        "arms": {},
    }
    common_seed = derive_named_seed(
        int(payload["root_seed"]), "formal-arms:common-initialization"
    )
    for arm_index, arm_id in enumerate(_ARMS):
        arm_root = stage_root / arm_id
        arm_root.mkdir()
        training = training_manifest["arms"][arm_id]
        rollout_path = arm_root / "rollouts.jsonl"
        if training["status"] != "PASS":
            rollout = _failure_rollout_summary(
                conditions=conditions,
                failure_code="ARM_TRAINING_FAILED",
                output_path=rollout_path,
            )
            checkpoint_sha = None
        else:
            model = _new_model(
                arm_id=arm_id,
                backend=backend,
                seed=common_seed,
                relation_library_backend=relation_backend,
            )
            model.load_state_dict(common_state, strict=True)
            checkpoint_path = Path(training["selected_checkpoint_path"])
            checkpoint_sha = _sha256(checkpoint_path)
            if checkpoint_sha != training["selected_checkpoint_sha256"]:
                raise RuntimeError(f"{arm_id} rollout checkpoint hash mismatch")
            checkpoint = torch.load(
                checkpoint_path, map_location="cpu", weights_only=True
            )
            model.load_state_dict(checkpoint["model_state_dict"], strict=True)
            rollout = run_free_rollouts(
                model=model,
                conditions=conditions,
                config=_rollout_config(payload),
                output_path=rollout_path,
            )
            model.cpu()
            del model
            torch.cuda.empty_cache()
        summary = {
            name: value for name, value in rollout.items() if name != "records"
        }
        summary["condition_manifest_sha256"] = condition_sha
        summary["selected_checkpoint_sha256"] = checkpoint_sha
        _write_json_new(arm_root / "rollout_summary.json", summary)
        generation_manifest["arms"][arm_id] = summary
        state.heartbeat(
            update=(arm_index + 1) * len(conditions),
            checkpoint_path=(
                str(training.get("selected_checkpoint_path"))
                if checkpoint_sha
                else None
            ),
        )
    _write_json_new(stage_root / "generation_manifest.json", generation_manifest)
    state.complete_stage(stage, next_stage="CHGNET_TERMINAL_EVALUATION")


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    records = []
    with path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError as error:
                raise ValueError(f"invalid JSONL at {path}:{line_number}") from error
    return records


def _stage_chgnet(
    *, state: LocalRunState, payload: dict[str, Any]
) -> None:
    stage = "CHGNET_TERMINAL_EVALUATION"
    state.start_stage(stage, checkpoint_path=None)
    generation_root = state.root / "formal_generation"
    evaluation_root = state.root / "chgnet_terminal_evaluation"
    evaluation_root.mkdir()
    evaluator = CHGNetTerminalEvaluator(_chgnet_config(payload))
    aggregate: dict[str, Any] = {
        "schema_version": "g1-chgnet-terminal-evaluation.1.0.0",
        "provenance": asdict(_chgnet_config(payload)),
        "training_role": "TERMINAL_EVALUATION_ONLY",
        "enters_loss": False,
        "writes_generation_state": False,
        "checkpoint_selection": False,
        "arms": {},
    }
    for arm_index, arm_id in enumerate(_ARMS):
        records = _read_jsonl(generation_root / arm_id / "rollouts.jsonl")
        result = evaluator.evaluate(
            records,
            output_path=evaluation_root / f"{arm_id}.json",
        )
        aggregate["arms"][arm_id] = {
            name: value for name, value in result.items() if name != "records"
        }
        state.heartbeat(
            update=(arm_index + 1) * len(records), checkpoint_path=None
        )
    _write_json_new(state.root / "CHGNET_TERMINAL_EVALUATION.json", aggregate)
    state.complete_stage(stage, next_stage="FINAL_REPORTING")


def _arm_quality(metrics: dict[str, Any]) -> float:
    return (
        0.40 * float(metrics["post_relax_survival_rate_all_attempts"])
        + 0.30 * float(metrics["free_rollout_completion_rate"])
        + 0.20 * float(metrics["short_contact_free_rate"])
        + 0.10 * float(metrics["pre_projector_validity_rate"])
    )


def _pilot_results_markdown(
    *,
    metrics: dict[str, dict[str, Any]],
    training: dict[str, Any],
    backend: str,
    relation_backend: str,
) -> str:
    rows = []
    for arm_id in _ARMS:
        value = metrics[arm_id]
        train = training["arms"][arm_id]
        rows.append(
            f"| {arm_id} | {train['status']} | {train.get('completed_updates', 0)} | "
            f"{value['free_rollout_completion_rate']:.4f} | {value['legal_terminal_rate']:.4f} | "
            f"{value['short_contact_free_rate']:.4f} | {value['post_relax_survival_rate_all_attempts']:.4f} | "
            f"{value['structure_matcher_uniqueness_rate_all_attempts']:.4f} | "
            f"{value['structure_matcher_novelty_rate_all_attempts']:.4f} | "
            f"{value['pre_relax_space_group_match_rate_all_attempts']:.4f} | "
            f"{value['generation_latency_p50_seconds']:.4f} | {_arm_quality(value):.4f} |"
        )
    return "\n".join(
        (
            "# Crysalis-G1 Local Single-Seed Pilot Results",
            "",
            f"Frozen geometry backend: `{backend}`. Frozen relation-library backend: "
            f"`{relation_backend}`. All four arms use root seed 20260823, the same frozen "
            "data and split, the same batch order, the same train/validation budgets, "
            "independent optimizers and checkpoints, and one shared parent-free 300-condition manifest.",
            "",
            "| Arm | Training | Updates | Completion | Legal terminal | Short-contact free | Post-relax survival | Uniqueness/all | Novelty/all | SG match pre/all | Gen p50 s | Quality |",
            "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
            *rows,
            "",
            "Switch matrix:",
            "",
            "| Arm | Relation memory | Relation library | Stepwise physics |",
            "|---|---:|---:|---:|",
            "| C0 | false | false | false |",
            "| C1 | true | false | false |",
            "| C2 | true | true | false |",
            "| C3-Full | true | true | true |",
            "",
            "The formal deconstruction scope in this run is only `D_orbit + "
            "D_relation_interface`. `D_motif`, `D_sublattice`, and `D_distortion` "
            "remain unimplemented and are not claimed as coverage.",
            "",
            "CHGNet is terminal evaluation only; it did not enter training losses, "
            "generation state, or checkpoint selection.",
            "",
        )
    )


def _failure_markdown(metrics: dict[str, dict[str, Any]]) -> str:
    sections = [
        "# Failure Cases",
        "",
        "All failed attempts remain in the denominator. No refill, seed replacement, "
        "or deletion of abnormal samples was performed.",
        "",
    ]
    for arm_id in _ARMS:
        value = metrics[arm_id]
        sections.extend(
            (
                f"## {arm_id}",
                "",
                "Generation failure taxonomy:",
                "",
                "```json",
                json.dumps(
                    value["generation_failure_taxonomy"],
                    ensure_ascii=False,
                    indent=2,
                    sort_keys=True,
                ),
                "```",
                "",
                "CHGNet status taxonomy:",
                "",
                "```json",
                json.dumps(
                    value["chgnet_status_taxonomy"],
                    ensure_ascii=False,
                    indent=2,
                    sort_keys=True,
                ),
                "```",
                "",
            )
        )
    return "\n".join(sections)


def _next_stage_markdown(
    metrics: dict[str, dict[str, Any]], runtime: dict[str, Any]
) -> str:
    capability = bool(metrics["C0"]["legal_terminal_count"] > 0)
    c0_quality = _arm_quality(metrics["C0"])
    c1_quality = _arm_quality(metrics["C1"])
    c2_quality = _arm_quality(metrics["C2"])
    c3_quality = _arm_quality(metrics["C3-Full"])
    retain_memory = c1_quality >= c0_quality
    retain_library = c2_quality >= c1_quality
    retain_physics = c3_quality >= c2_quality
    worth_three_seed = capability and max(c1_quality, c2_quality, c3_quality) >= c0_quality
    peak = int(runtime["peak_reserved_vram_bytes_max"])
    server_needed = peak > 11 * 1024**3
    return "\n".join(
        (
            "# Next Stage Decision",
            "",
            "## 当前模型是否形成正向生成能力",
            "",
            (
                "是：C0 在严格 parent-free 自由生成中产生了至少一个合法终端晶体。"
                if capability
                else "否：C0 未产生合法终端晶体，当前不能声称已形成正向生成能力。"
            ),
            "",
            "## C1/C2/C3 各模块是否保留",
            "",
            f"- Persistent relation memory (C1): {'保留候选' if retain_memory else '暂不保留'}。",
            f"- Offline relation library (C2): {'保留候选' if retain_library else '暂不保留'}。",
            f"- Physics feedback (C3-Full): {'保留候选' if retain_physics else '暂不保留'}。",
            "",
            "以上仅是单随机种子内部架构筛选结论，不是正式统计结论。",
            "",
            "## 是否值得进入三随机种子正式矩阵",
            "",
            (
                "值得提交授权审议；但 `three_seed_authorized=false`，本次未启动。"
                if worth_three_seed
                else "暂不值得；应先修复单种子下的核心生成或模块退化。"
            ),
            "",
            "## 是否需要服务器",
            "",
            (
                "需要：本地实测峰值超过 11 GiB 安全门限。"
                if server_needed
                else "本轮不需要；本地显存满足已执行配置。服务器仍未授权，也未使用。"
            ),
            "",
        )
    )


def _stage_final_reporting(
    *,
    state: LocalRunState,
    payload: dict[str, Any],
    code_sha256: str,
) -> None:
    stage = "FINAL_REPORTING"
    state.start_stage(stage, checkpoint_path=None)
    output_root = state.root
    corpus = FrozenPhase2ACorpus.load(
        payload["phase2a_root"],
        expected_manifest_sha256=payload["expected_phase2a_manifest_sha256"],
    )
    training = json.loads(
        (
            output_root
            / "formal_arm_training"
            / "arm_training_manifest.json"
        ).read_text(encoding="utf-8")
    )
    generation_manifest = json.loads(
        (
            output_root / "formal_generation" / "generation_manifest.json"
        ).read_text(encoding="utf-8")
    )
    metrics: dict[str, dict[str, Any]] = {}
    for arm_id in _ARMS:
        rollout_records = _read_jsonl(
            output_root / "formal_generation" / arm_id / "rollouts.jsonl"
        )
        rollout_summary = json.loads(
            (
                output_root
                / "formal_generation"
                / arm_id
                / "rollout_summary.json"
            ).read_text(encoding="utf-8")
        )
        rollout = {**rollout_summary, "records": rollout_records}
        chgnet = json.loads(
            (
                output_root
                / "chgnet_terminal_evaluation"
                / f"{arm_id}.json"
            ).read_text(encoding="utf-8")
        )
        metrics[arm_id] = aggregate_generation_metrics(
            arm_id=arm_id,
            rollout=rollout,
            chgnet=chgnet,
            corpus=corpus,
        )
        state.heartbeat(
            update=len(metrics) * int(payload["formal_rollout_attempts"]),
            checkpoint_path=training["arms"][arm_id].get(
                "selected_checkpoint_path"
            ),
        )
    generation_metrics = {
        "schema_version": "g1-local-single-seed-generation-metrics.1.0.0",
        "root_seed": payload["root_seed"],
        "phase2a_manifest_sha256": payload[
            "expected_phase2a_manifest_sha256"
        ],
        "condition_manifest_sha256": generation_manifest[
            "condition_manifest_sha256"
        ],
        "attempts_per_arm": payload["formal_rollout_attempts"],
        "no_refill": True,
        "three_seed_authorized": False,
        "server_deployment_authorized": False,
        "arms": metrics,
    }
    _write_json_new(output_root / "GENERATION_METRICS.json", generation_metrics)

    c0 = json.loads(
        (output_root / "c0_backend_screening" / "screening_summary.json").read_text(
            encoding="utf-8"
        )
    )
    peak_values: list[int] = []
    wall_values: list[float] = []
    for backend in ("periodic_egnn", "e3nn_lite"):
        peak_values.extend(
            (
                int(c0["engineering"][backend]["peak_reserved_vram_bytes"]),
                int(c0["training"][backend]["peak_reserved_vram_bytes"]),
                int(c0["rollout"][backend]["peak_reserved_vram_bytes"]),
            )
        )
        wall_values.extend(
            (
                float(c0["training"][backend]["wall_seconds"]),
                float(c0["rollout"][backend]["wall_seconds"]),
            )
        )
    for arm_id in _ARMS:
        train = training["arms"][arm_id]
        if train["status"] == "PASS":
            peak_values.append(int(train["peak_reserved_vram_bytes"]))
            wall_values.append(float(train["wall_seconds"]))
        generation = generation_manifest["arms"][arm_id]
        peak_values.append(int(generation["peak_reserved_vram_bytes"]))
        wall_values.append(float(generation["wall_seconds"]))
    runtime = {
        "schema_version": "g1-vram-runtime-report.1.0.0",
        "device": payload["device"],
        "peak_reserved_vram_bytes_max": max(peak_values, default=0),
        "peak_reserved_vram_gib_max": max(peak_values, default=0) / 1024**3,
        "recorded_training_and_generation_wall_seconds": sum(wall_values),
        "c0": {
            "engineering": c0["engineering"],
            "training": c0["training"],
            "rollout": c0["rollout"],
        },
        "formal_training": training["arms"],
        "formal_generation": generation_manifest["arms"],
        "vram_hard_limit_bytes": 11 * 1024**3,
    }
    _write_json_new(output_root / "VRAM_RUNTIME_REPORT.json", runtime)
    _write_text_new(
        output_root / "LOCAL_SINGLE_SEED_PILOT_RESULTS.md",
        _pilot_results_markdown(
            metrics=metrics,
            training=training,
            backend=str(training["geometry_backend"]),
            relation_backend=str(training["relation_library_backend"]),
        ),
    )
    _write_text_new(
        output_root / "FAILURE_CASES.md", _failure_markdown(metrics)
    )
    _write_text_new(
        output_root / "NEXT_STAGE_DECISION.md",
        _next_stage_markdown(metrics, runtime),
    )

    required = (
        "C0_BACKEND_SCREENING_RESULTS.md",
        "GEOMETRY_BACKEND_FREEZE.json",
        "RELATION_TEACHER_COMPARISON.md",
        "RELATION_LIBRARY_ARTIFACT.json",
        "LOCAL_SINGLE_SEED_PILOT_RESULTS.md",
        "GENERATION_METRICS.json",
        "CHGNET_TERMINAL_EVALUATION.json",
        "VRAM_RUNTIME_REPORT.json",
        "FAILURE_CASES.md",
        "NEXT_STAGE_DECISION.md",
    )
    missing = [name for name in required if not (output_root / name).is_file()]
    if missing:
        raise RuntimeError(f"final deliverables are missing: {missing}")
    manifest = {
        "schema_version": "g1-local-single-seed-final-manifest.1.0.0",
        "status": "PASS",
        "root_seed": payload["root_seed"],
        "code_sha256": code_sha256,
        "phase2a_manifest_sha256": payload[
            "expected_phase2a_manifest_sha256"
        ],
        "formal_deconstruction_operators": [
            "D_orbit",
            "D_relation_interface",
        ],
        "unimplemented_deconstruction_operators": [
            "D_motif",
            "D_sublattice",
            "D_distortion",
        ],
        "no_refill": True,
        "server_used": False,
        "three_seed_started": False,
        "file_sha256": {
            name: _sha256(output_root / name) for name in required
        },
    }
    _write_json_new(output_root / "FINAL_RUN_MANIFEST.json", manifest)
    state.complete_stage(stage, next_stage="COMPLETE")
    state.finish()


def run_local_single_seed(
    config_path: str | Path,
    *,
    repo_root: str | Path,
) -> dict[str, Any]:
    payload = _load_payload(config_path)
    torch.use_deterministic_algorithms(True, warn_only=False)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cuda.matmul.allow_tf32 = False
    run_config = _run_config(payload)
    repo_root = Path(repo_root).resolve()
    code_sha256 = _source_tree_sha256(repo_root)
    if Path(run_config.output_root).exists():
        state = LocalRunState.resume(run_config)
        if state.state.get("status") == "COMPLETE":
            return state.state
    else:
        state = LocalRunState.initialize(run_config, code_sha256=code_sha256)
        _write_json_new(
            state.root / "AUTONOMOUS_LOCAL_RUN_CONFIG.json",
            {
                **payload,
                "source_config_path": str(Path(config_path).resolve()),
                "source_config_sha256": _sha256(Path(config_path)),
                "code_sha256": code_sha256,
            },
        )
    dispatch = {
        "C0_BACKEND_SCREENING": lambda: _stage_c0_screening(
            state=state, payload=payload, code_sha256=code_sha256
        ),
        "RELATION_LEARNING": lambda: _stage_relation_learning(
            state=state, payload=payload, code_sha256=code_sha256
        ),
        "FORMAL_ARM_TRAINING": lambda: _stage_formal_training(
            state=state, payload=payload, code_sha256=code_sha256
        ),
        "FREE_GENERATION": lambda: _stage_free_generation(
            state=state, payload=payload
        ),
        "CHGNET_TERMINAL_EVALUATION": lambda: _stage_chgnet(
            state=state, payload=payload
        ),
        "FINAL_REPORTING": lambda: _stage_final_reporting(
            state=state, payload=payload, code_sha256=code_sha256
        ),
    }
    while state.current_stage != "COMPLETE":
        try:
            dispatch[state.current_stage]()
        except Exception as error:
            message = str(error)
            hard_reason = None
            if "Phase 2A manifest hash mismatch" in message:
                hard_reason = "PHASE2A_MANIFEST_HASH_MISMATCH"
            elif "parent information leaked" in message or "forbidden parent" in message:
                hard_reason = "PARENT_INFORMATION_LEAKAGE"
            elif "both C0 geometry backends failed" in message:
                hard_reason = "CORE_GENERATION_COMPLETELY_FAILED_AFTER_TWO_REPAIRS"
            elif isinstance(error, (OSError, MemoryError)) and "disk" in message.lower():
                hard_reason = "LOCAL_DISK_OR_HARDWARE_SAFETY_RISK"
            if hard_reason is not None:
                state.fail(
                    reason_code=hard_reason,
                    message=message,
                    traceback_text=traceback.format_exc(),
                )
            else:
                state.engineering_error(
                    reason_code="UNRESOLVED_ENGINEERING_ERROR",
                    message=message,
                    traceback_text=traceback.format_exc(),
                )
            raise
    return state.state
