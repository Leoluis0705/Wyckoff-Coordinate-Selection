from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path
from typing import Any

from crysalis_g1.experiments.c0_symmetry_data import C0SymmetryCorpus
from crysalis_g1.experiments.c0_symmetry_evaluation import (
    build_parent_free_conditions,
    generate_attempts,
    load_c0_symmetry_checkpoint,
    load_validation_condition_sources,
    run_chgnet_evaluation,
    structural_uniqueness_and_novelty,
    summarize_generation,
)
from crysalis_g1.experiments.c0_symmetry_training import (
    C0TrainingConfig,
    run_c0_symmetry_training,
)
from crysalis_g1.model.c0_symmetry import C0SymmetryConfig


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _write_json_new(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(payload, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def assert_crystallographic_gates(
    reconstruction: dict[str, Any], oracle: dict[str, Any]
) -> None:
    if not reconstruction.get("passed"):
        raise RuntimeError("crystallographic reconstruction gate did not pass")
    if not (
        oracle.get("passed")
        and oracle.get("sample_passed")
        and oracle.get("all_applicable_executed")
        and int(oracle.get("failure_count", -1)) == 0
    ):
        raise RuntimeError("full inverse assembly oracle gate did not pass")


def choose_c0_symmetry_decision(
    *,
    legal_terminal_count: int,
    chgnet_converged_or_survived_count: int,
    controls_normal: bool,
    gates_passed: bool,
    training_passed: bool,
) -> str:
    if not controls_normal or not gates_passed or not training_passed:
        raise RuntimeError("final decision prerequisites are not satisfied")
    if legal_terminal_count > 0 and chgnet_converged_or_survived_count > 0:
        return "CORE_METHOD_VIABLE_SIGNAL"
    return "CURRENT_CORE_METHOD_NOT_SUPPORTED"


def _training_config(
    payload: dict[str, Any], *, root_seed: int, device: str
) -> C0TrainingConfig:
    allowed = {
        "updates",
        "batch_size",
        "validation_interval",
        "validation_batch_size",
        "learning_rate",
        "weight_decay",
        "gradient_clip_norm",
        "maximum_validation_examples",
        "checkpoint_interval",
        "use_amp",
    }
    return C0TrainingConfig(
        root_seed=root_seed,
        device=device,
        **{key: value for key, value in payload.items() if key in allowed},
    )


def run_training_stage(config: dict[str, Any]) -> dict[str, Any]:
    output_root = Path(config["output_root"])
    reconstruction = _read_json(
        output_root / "CRYSTALLOGRAPHIC_RECONSTRUCTION_REPORT.json"
    )
    oracle = _read_json(output_root / "INVERSE_ASSEMBLY_ORACLE_REPLAY.json")
    assert_crystallographic_gates(reconstruction, oracle)
    corpus = C0SymmetryCorpus.build(
        config["phase2a_root"],
        config["recovered_parent_cache"],
        maximum_sites=int(config["model"]["maximum_sites"]),
    )
    model_config = C0SymmetryConfig(**config["model"])
    checkpoint_root = output_root / "checkpoints"
    preflight = run_c0_symmetry_training(
        corpus,
        output_directory=checkpoint_root,
        phase="preflight_500",
        model_config=model_config,
        training_config=_training_config(
            config["preflight"],
            root_seed=int(config["root_seed"]),
            device=str(config["device"]),
        ),
    )
    preflight_passed = bool(
        preflight["passed"]
        and preflight["finite_forward_backward"]
        and preflight["action_loss_decreased"]
        and preflight["teacher_forced_space_group_preservation_rate"] == 1.0
    )
    if not preflight_passed:
        report = {
            "schema_version": "g1-c0-symmetry-training-report.1.0.0",
            "preflight": preflight,
            "preflight_gate_passed": False,
            "formal_training_started": False,
            "passed": False,
        }
        _write_json_new(output_root / "C0_SYMMETRY_TRAINING_REPORT.json", report)
        return report
    formal_payload = dict(config["formal_training"])
    updates = int(formal_payload["updates"])
    if not int(formal_payload["minimum_updates"]) <= updates <= int(
        formal_payload["maximum_updates"]
    ):
        raise ValueError("formal update count lies outside the authorized range")
    formal = run_c0_symmetry_training(
        corpus,
        output_directory=checkpoint_root,
        phase="formal_single_seed",
        model_config=model_config,
        training_config=_training_config(
            formal_payload,
            root_seed=int(config["root_seed"]),
            device=str(config["device"]),
        ),
    )
    report = {
        "schema_version": "g1-c0-symmetry-training-report.1.0.0",
        "phase2a_manifest_sha256": config["phase2a_manifest_sha256"],
        "root_seed": config["root_seed"],
        "corpus": {
            "parent_count": corpus.parent_count,
            "trajectory_count": corpus.trajectory_count,
            "train_example_count": len(corpus.train_examples),
            "validation_example_count": len(corpus.validation_examples),
        },
        "preflight": preflight,
        "preflight_gate_passed": True,
        "formal_training_started": True,
        "formal": formal,
        "formal_reinitialized_from_scratch": True,
        "preflight_checkpoint_extended": False,
        "common_fresh_initialization_sha256_match": (
            preflight["initial_state_sha256"] == formal["initial_state_sha256"]
        ),
        "chgnet_used_for_checkpoint_selection": False,
        "passed": bool(formal["passed"]),
    }
    _write_json_new(output_root / "C0_SYMMETRY_TRAINING_REPORT.json", report)
    return report


def run_generation_stage(config: dict[str, Any]) -> dict[str, Any]:
    output_root = Path(config["output_root"])
    training = _read_json(output_root / "C0_SYMMETRY_TRAINING_REPORT.json")
    if not training.get("passed"):
        raise RuntimeError("formal training did not pass")
    generation_config = config["generation"]
    attempt_count = int(generation_config["attempt_count"])
    if attempt_count != 300 or generation_config.get("refill") is not False:
        raise ValueError("generation must use exactly 300 attempts with no refill")
    sources = load_validation_condition_sources(
        config["phase2a_root"], config["recovered_parent_cache"]
    )
    conditions = build_parent_free_conditions(
        sources, count=attempt_count, root_seed=int(config["root_seed"])
    )
    condition_path = output_root / "engineering" / "condition_manifest.json"
    _write_json_new(
        condition_path,
        {
            "schema_version": "g1-c0-symmetry-condition-manifest.1.0.0",
            "attempt_count": attempt_count,
            "root_seed": config["root_seed"],
            "parent_coordinates_present": False,
            "parent_lattice_present": False,
            "material_id_lookup_present": False,
            "true_orbit_count_present": False,
            "true_wyckoff_sequence_present": False,
            "true_termination_step_present": False,
            "conditions": conditions,
        },
    )
    checkpoint_path = training["formal"]["checkpoint_path"]
    model, checkpoint = load_c0_symmetry_checkpoint(
        checkpoint_path, device=str(config["device"])
    )
    records = generate_attempts(
        model,
        conditions,
        device=str(config["device"]),
        minimum_distance=float(generation_config["minimum_distance_angstrom"]),
        temperature=float(generation_config["temperature"]),
    )
    if len(records) != attempt_count:
        raise RuntimeError("free rollout changed the preregistered denominator")
    raw_path = output_root / "engineering" / "generation_records.json"
    _write_json_new(
        raw_path,
        {
            "schema_version": "g1-c0-symmetry-generation-records.1.0.0",
            "checkpoint_sha256": training["formal"]["checkpoint_sha256"],
            "records": records,
        },
    )
    metrics = summarize_generation(records)
    metrics.update(
        structural_uniqueness_and_novelty(
            records,
            phase2a_root=config["phase2a_root"],
            recovered_parent_cache=config["recovered_parent_cache"],
        )
    )
    metrics.update(
        {
            "root_seed": config["root_seed"],
            "condition_manifest_path": str(condition_path.resolve()),
            "condition_manifest_sha256": _sha256(condition_path),
            "checkpoint_path": str(Path(checkpoint_path).resolve()),
            "checkpoint_sha256": training["formal"]["checkpoint_sha256"],
            "generation_records_path": str(raw_path.resolve()),
            "generation_records_sha256": _sha256(raw_path),
            "old_checkpoint_loaded": bool(checkpoint["old_checkpoint_loaded"]),
            "retry_count": 0,
        }
    )
    _write_json_new(output_root / "C0_SYMMETRY_GENERATION_METRICS.json", metrics)
    return metrics


def run_chgnet_stage(config: dict[str, Any]) -> dict[str, Any]:
    output_root = Path(config["output_root"])
    raw = _read_json(output_root / "engineering" / "generation_records.json")
    records = list(raw["records"])
    if len(records) != 300:
        raise RuntimeError("CHGNet input must preserve all 300 generation attempts")
    report = run_chgnet_evaluation(
        records,
        phase2a_root=config["phase2a_root"],
        output_root=output_root,
        root_seed=int(config["root_seed"]),
        device=str(config["device"]),
        chgnet_config=config["chgnet"],
        prior_control_results=config["prior_control_results"],
    )
    _write_json_new(output_root / "C0_SYMMETRY_CHGNET_EVALUATION.json", report)
    return report


def _write_text_new(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(text.rstrip() + "\n")


def _write_failure_ledger(output_root: Path, records: list[dict[str, Any]]) -> int:
    path = output_root / "C0_SYMMETRY_FAILURES.jsonl"
    failures = [record for record in records if not record["legal_terminal_crystal"]]
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        for record in failures:
            payload = {
                "schema_version": "g1-c0-symmetry-failure.1.0.0",
                "condition_id": record["condition"]["condition_id"],
                "attempt_index": record["condition"]["attempt_index"],
                "failure_code": record.get("failure_code"),
                "detected_space_group": record.get("detected_space_group"),
                "target_space_group": record["condition"]["space_group"],
                "projector_rejection_reasons": record[
                    "projector_rejection_reasons"
                ],
                "retry_count": 0,
                "refill_count": 0,
            }
            stream.write(json.dumps(payload, sort_keys=True) + "\n")
    return len(failures)


def run_final_stage(config: dict[str, Any]) -> dict[str, Any]:
    output_root = Path(config["output_root"])
    reconstruction = _read_json(
        output_root / "CRYSTALLOGRAPHIC_RECONSTRUCTION_REPORT.json"
    )
    oracle = _read_json(output_root / "INVERSE_ASSEMBLY_ORACLE_REPLAY.json")
    assert_crystallographic_gates(reconstruction, oracle)
    training = _read_json(output_root / "C0_SYMMETRY_TRAINING_REPORT.json")
    generation = _read_json(output_root / "C0_SYMMETRY_GENERATION_METRICS.json")
    chgnet = _read_json(output_root / "C0_SYMMETRY_CHGNET_EVALUATION.json")
    raw = _read_json(output_root / "engineering" / "generation_records.json")
    records = list(raw["records"])
    legal_count = sum(bool(record["legal_terminal_crystal"]) for record in records)
    physical_count = int(
        chgnet["generated"]["converged_or_survived_condition_count"]
    )
    decision = choose_c0_symmetry_decision(
        legal_terminal_count=legal_count,
        chgnet_converged_or_survived_count=physical_count,
        controls_normal=bool(chgnet["controls_normal"]),
        gates_passed=True,
        training_passed=bool(training["passed"]),
    )
    failure_count = _write_failure_ledger(output_root, records)
    audit = f"""# C0-Symmetry Implementation Audit

- Formal experiment: `C0-SYMMETRY`; root seed: `{config['root_seed']}`.
- Frozen Phase2A manifest: `{config['phase2a_manifest_sha256']}`; rebuilt: `false`.
- Old C0/C1/C2/C3 checkpoints loaded: `false`; preflight checkpoint extended: `false`.
- Old golden-ratio expansion in formal path: `false`.
- Geometry backend: orbit-manifold `periodic_egnn`; equivalent-site atomwise deltas: `forbidden`.
- Orbit state: SG/Hall/setting/Wyckoff/multiplicity/species/free parameters/orbit-instance ID.
- Lattice: crystal-system constrained degrees plus predicted integer cell index.
- Formal deconstruction operator used for inverse assembly: `D_orbit`.
- Reconstruction: `{reconstruction['recovered_parent_count']}/{reconstruction['parent_count']}` parents.
- Inverse oracle: `{oracle['pass_count']}/{oracle['applicable_trajectory_count']}` trajectories.
- Training: 500-update fresh preflight, then `{training['formal']['updates_completed']}`-update fresh single-seed run.
- Generation: exactly `{generation['attempt_count']}` attempts; refill count `{generation['refill_count']}`.
- Excluded scope: KAN, Relation Student/Library/Memory, physics, e3nn comparison, C1-C3, server, three-seed, DFT.
"""
    _write_text_new(output_root / "C0_SYMMETRY_IMPLEMENTATION_AUDIT.md", audit)
    decision_text = f"""# C0-Symmetry Final Decision

RESULT={decision}

- Symmetry-valid legal terminals: `{legal_count}/300`.
- CHGNet converged or physically survived conditions: `{physical_count}`.
- Control evaluator behavior unchanged: `{str(chgnet['control_evaluator_behavior_unchanged']).lower()}`.
- Generation failures retained: `{failure_count}`; refill: `0`; retries: `0`.
- Server used: `false`; three-seed matrix: `false`; DFT: `false`.
"""
    _write_text_new(output_root / "C0_SYMMETRY_FINAL_DECISION.md", decision_text)
    required = (
        "C0_SYMMETRY_IMPLEMENTATION_AUDIT.md",
        "WYCKOFF_EXPANDER_TESTS.json",
        "CRYSTALLOGRAPHIC_RECONSTRUCTION_REPORT.json",
        "INVERSE_ASSEMBLY_ORACLE_REPLAY.json",
        "C0_SYMMETRY_TRAINING_REPORT.json",
        "C0_SYMMETRY_GENERATION_METRICS.json",
        "C0_SYMMETRY_CHGNET_EVALUATION.json",
        "C0_SYMMETRY_FAILURES.jsonl",
        "C0_SYMMETRY_FINAL_DECISION.md",
    )
    missing = [name for name in required if not (output_root / name).is_file()]
    if missing:
        raise RuntimeError(f"required final artifacts are missing: {missing}")
    phase_manifest = Path(config["phase2a_root"]) / "phase2a_manifest.json"
    phase_sha = _sha256(phase_manifest)
    if phase_sha != config["phase2a_manifest_sha256"]:
        raise RuntimeError("Phase2A manifest changed before finalization")
    files = sorted(
        path
        for path in output_root.rglob("*")
        if path.is_file() and path.name != "C0_SYMMETRY_MANIFEST.json"
    )
    try:
        code_commit = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], text=True
        ).strip()
    except (OSError, subprocess.CalledProcessError):
        code_commit = None
    implementation_files = (
        "configs/g1_c0_symmetry_20260825.json",
        "crysalis_g1/symmetry/__init__.py",
        "crysalis_g1/symmetry/assembly.py",
        "crysalis_g1/symmetry/wyckoff.py",
        "crysalis_g1/model/c0_symmetry.py",
        "crysalis_g1/experiments/c0_symmetry_data.py",
        "crysalis_g1/experiments/c0_symmetry_evaluation.py",
        "crysalis_g1/experiments/c0_symmetry_oracle.py",
        "crysalis_g1/experiments/c0_symmetry_reconstruction.py",
        "crysalis_g1/experiments/c0_symmetry_runner.py",
        "crysalis_g1/experiments/c0_symmetry_training.py",
        "tests/crysalis_g1/test_c0_symmetry_assembly.py",
        "tests/crysalis_g1/test_c0_symmetry_evaluation.py",
        "tests/crysalis_g1/test_c0_symmetry_model.py",
        "tests/crysalis_g1/test_c0_symmetry_reconstruction.py",
        "tests/crysalis_g1/test_c0_symmetry_runner.py",
        "tests/crysalis_g1/test_c0_symmetry_training.py",
        "tests/crysalis_g1/test_c0_symmetry_wyckoff.py",
    )
    repository_root = Path.cwd()
    implementation_hashes = {
        relative: _sha256(repository_root / relative)
        for relative in implementation_files
    }
    manifest = {
        "schema_version": "g1-c0-symmetry-manifest.1.0.0",
        "result": decision,
        "root_seed": config["root_seed"],
        "phase2a_manifest_sha256_before_after": phase_sha,
        "phase2a_rebuilt": False,
        "sealed_or_blind_data_accessed": False,
        "refill_count": 0,
        "server_used": False,
        "three_seed_authorized": False,
        "dft_used": False,
        "code_commit_sha": code_commit,
        "code_commit_contains_implementation": False,
        "implementation_worktree_state": "UNCOMMITTED",
        "implementation_file_sha256": implementation_hashes,
        "required_artifacts": list(required),
        "file_sha256": {
            str(path.relative_to(output_root)).replace("\\", "/"): _sha256(path)
            for path in files
        },
    }
    _write_json_new(output_root / "C0_SYMMETRY_MANIFEST.json", manifest)
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser(description="Execute C0-Symmetry stages")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument(
        "--stage", choices=("training", "generation", "chgnet", "final"), required=True
    )
    args = parser.parse_args()
    config = _read_json(args.config)
    if args.stage == "training":
        report = run_training_stage(config)
    elif args.stage == "generation":
        report = run_generation_stage(config)
    elif args.stage == "chgnet":
        report = run_chgnet_stage(config)
    elif args.stage == "final":
        report = run_final_stage(config)
    else:
        raise AssertionError(args.stage)
    print(json.dumps(report, sort_keys=True))
    if args.stage == "training":
        return 0 if report.get("passed") else 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
