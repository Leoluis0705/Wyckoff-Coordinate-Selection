from __future__ import annotations

import hashlib
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


@dataclass(frozen=True, slots=True)
class CHGNetEvaluationConfig:
    package_version: str
    model_version: str
    weight_path: str
    weight_sha256: str
    optimizer: str
    force_threshold_ev_per_angstrom: float
    maximum_steps: int
    relax_cell: bool
    short_contact_distance: float
    device: str

    def __post_init__(self) -> None:
        if self.package_version != "0.4.2":
            raise ValueError("CHGNet package version must remain frozen at 0.4.2")
        if self.model_version != "0.3.0":
            raise ValueError("CHGNet model version must remain frozen at 0.3.0")
        try:
            digest = bytes.fromhex(self.weight_sha256)
        except ValueError as error:
            raise ValueError("invalid CHGNet weight SHA-256") from error
        if len(digest) != 32:
            raise ValueError("invalid CHGNet weight SHA-256")
        if self.optimizer != "FIRE":
            raise ValueError("terminal relaxation optimizer must remain FIRE")
        if self.force_threshold_ev_per_angstrom <= 0 or self.maximum_steps <= 0:
            raise ValueError("CHGNet relaxation budget must be positive")
        if self.short_contact_distance <= 0:
            raise ValueError("short-contact threshold must be positive")
        if self.device not in {"cpu", "cuda"}:
            raise ValueError("CHGNet device must be cpu or cuda")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def _maximum_force(forces: Any) -> float:
    array = np.asarray(forces, dtype=float)
    value = float(np.linalg.norm(array, axis=-1).max())
    if not math.isfinite(value):
        raise FloatingPointError("non-finite CHGNet force")
    return value


def _short_contact_free(structure: Structure, threshold: float) -> bool:
    if len(structure) == 0:
        return False
    if len(structure) == 1:
        return True
    distances = np.asarray(structure.distance_matrix, dtype=float)
    np.fill_diagonal(distances, np.inf)
    return bool(np.isfinite(distances).any() and distances.min() >= threshold)


def _rmsd(initial: Structure, final: Structure) -> float:
    if len(initial) != len(final) or len(initial) == 0:
        return math.nan
    delta = np.asarray(final.frac_coords) - np.asarray(initial.frac_coords)
    delta -= np.round(delta)
    cartesian = delta @ np.asarray(final.lattice.matrix)
    return float(np.sqrt(np.mean(np.sum(cartesian * cartesian, axis=1))))


def _structure_payload(structure: Structure) -> dict[str, Any]:
    return {
        "atomic_numbers": [int(site.specie.Z) for site in structure],
        "fractional_coordinates": np.asarray(structure.frac_coords).tolist(),
        "lattice": np.asarray(structure.lattice.matrix).tolist(),
    }


class CHGNetTerminalEvaluator:
    """Frozen terminal-only CHGNet relaxation evaluator."""

    def __init__(self, config: CHGNetEvaluationConfig, *, optimizer: Any | None = None) -> None:
        import chgnet

        self.config = config
        if chgnet.__version__ != config.package_version:
            raise RuntimeError(
                f"CHGNet package version mismatch: {chgnet.__version__}"
            )
        weight_path = Path(config.weight_path)
        if not weight_path.is_file():
            raise RuntimeError(f"CHGNet weight is missing: {weight_path}")
        observed = _sha256(weight_path)
        if observed != config.weight_sha256.upper():
            raise RuntimeError(
                f"CHGNet weight hash mismatch: expected {config.weight_sha256}, observed {observed}"
            )
        if optimizer is None:
            from chgnet.model import CHGNet, StructOptimizer

            model = CHGNet.load(
                model_name=config.model_version,
                use_device=config.device,
                verbose=False,
            )
            if str(getattr(model, "version", "")) != config.model_version:
                raise RuntimeError("loaded CHGNet model version mismatch")
            optimizer = StructOptimizer(
                model=model,
                optimizer_class=config.optimizer,
                use_device=config.device,
                on_isolated_atoms="error",
            )
        self.optimizer = optimizer

    def _evaluate_record(self, record: dict[str, Any]) -> dict[str, Any]:
        condition_id = str(record["condition"]["condition_id"])
        if not record.get("legal_terminal_crystal", False):
            return {
                "condition_id": condition_id,
                "status": "SKIPPED_GENERATION_FAILURE",
                "generation_failure_code": record.get("failure_code"),
                "converged": False,
                "post_relax_survival": False,
            }
        candidate = record["candidate"]
        atomic_numbers = [int(value) for value in candidate["atomic_numbers"]]
        if not atomic_numbers or max(atomic_numbers) > 94:
            return {
                "condition_id": condition_id,
                "status": "UNSUPPORTED_ELEMENT_DOMAIN",
                "converged": False,
                "post_relax_survival": False,
                "maximum_atomic_number": max(atomic_numbers, default=0),
            }
        initial = Structure(
            Lattice(np.asarray(candidate["lattice"], dtype=float)),
            atomic_numbers,
            np.asarray(candidate["fractional_coordinates"], dtype=float),
        )
        started = time.perf_counter()
        try:
            result = self.optimizer.relax(
                initial,
                fmax=self.config.force_threshold_ev_per_angstrom,
                steps=self.config.maximum_steps,
                relax_cell=self.config.relax_cell,
                loginterval=1,
                verbose=False,
            )
            final = result["final_structure"]
            trajectory = result["trajectory"]
            pre_force = _maximum_force(trajectory.forces[0])
            post_force = _maximum_force(trajectory.forces[-1])
            converged = post_force <= self.config.force_threshold_ev_per_angstrom
            contact_free = _short_contact_free(
                final, self.config.short_contact_distance
            )
            finite = bool(
                np.isfinite(final.frac_coords).all()
                and np.isfinite(final.lattice.matrix).all()
                and final.lattice.volume > 0
            )
            survival = bool(converged and contact_free and finite)
            initial_lattice = np.asarray(initial.lattice.matrix)
            final_lattice = np.asarray(final.lattice.matrix)
            lattice_change = float(
                np.linalg.norm(final_lattice - initial_lattice)
                / max(np.linalg.norm(initial_lattice), 1e-12)
            )
            try:
                detected_space_group = int(
                    SpacegroupAnalyzer(final, symprec=0.1).get_space_group_number()
                )
            except Exception:
                detected_space_group = 0
            return {
                "condition_id": condition_id,
                "status": "EVALUATED",
                "converged": converged,
                "post_relax_survival": survival,
                "short_contact_free_after_relax": contact_free,
                "finite_after_relax": finite,
                "pre_max_force_ev_per_angstrom": pre_force,
                "post_max_force_ev_per_angstrom": post_force,
                "relaxation_rmsd_angstrom": _rmsd(initial, final),
                "lattice_relative_change": lattice_change,
                "relaxation_observation_count": len(trajectory.forces),
                "detected_space_group": detected_space_group,
                "target_space_group": int(record["condition"]["space_group"]),
                "space_group_match": detected_space_group
                == int(record["condition"]["space_group"]),
                "latency_seconds": time.perf_counter() - started,
                "final_structure": _structure_payload(final),
            }
        except Exception as error:
            if isinstance(error, (MemoryError, FloatingPointError)) or (
                "out of memory" in str(error).lower()
            ):
                raise
            return {
                "condition_id": condition_id,
                "status": "CHGNET_RELAXATION_FAILED",
                "exception_type": type(error).__name__,
                "exception_message": str(error),
                "converged": False,
                "post_relax_survival": False,
                "latency_seconds": time.perf_counter() - started,
            }

    def evaluate(
        self, records: list[dict[str, Any]], *, output_path: str | Path
    ) -> dict[str, Any]:
        if not records:
            raise ValueError("CHGNet evaluation records must not be empty")
        output_path = Path(output_path)
        if output_path.exists():
            raise FileExistsError(f"CHGNet evaluation refuses to overwrite: {output_path}")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        evaluated = [self._evaluate_record(record) for record in records]
        attempt_count = len(evaluated)
        evaluated_count = sum(record["status"] == "EVALUATED" for record in evaluated)
        convergence_count = sum(bool(record["converged"]) for record in evaluated)
        survival_count = sum(
            bool(record["post_relax_survival"]) for record in evaluated
        )
        payload = {
            "provenance": {
                "package_version": self.config.package_version,
                "model_version": self.config.model_version,
                "weight_sha256": self.config.weight_sha256.upper(),
                "optimizer": self.config.optimizer,
                "force_threshold_ev_per_angstrom": self.config.force_threshold_ev_per_angstrom,
                "maximum_steps": self.config.maximum_steps,
                "relax_cell": self.config.relax_cell,
                "training_role": "TERMINAL_EVALUATION_ONLY",
                "enters_loss": False,
                "writes_generation_state": False,
                "checkpoint_selection": False,
            },
            "attempt_count": attempt_count,
            "evaluated_count": evaluated_count,
            "convergence_count": convergence_count,
            "post_relax_survival_count": survival_count,
            "convergence_rate_all_attempts": convergence_count / attempt_count,
            "post_relax_survival_rate_all_attempts": survival_count / attempt_count,
            "records": evaluated,
        }
        output_path.write_text(
            json.dumps(
                payload,
                ensure_ascii=False,
                allow_nan=False,
                indent=2,
                sort_keys=True,
            )
            + "\n",
            encoding="utf-8",
        )
        return payload
