from __future__ import annotations

import argparse
import json
from pathlib import Path

from crysalis_g1.experiments.local_single_seed_runner import run_local_single_seed


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run the authorized Crysalis-G1 autonomous local single-seed pilot"
    )
    parser.add_argument("--config", required=True)
    parser.add_argument(
        "--repo-root",
        default=str(Path(__file__).resolve().parents[2]),
    )
    arguments = parser.parse_args()
    result = run_local_single_seed(
        arguments.config,
        repo_root=arguments.repo_root,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
