from __future__ import annotations

import argparse

from crysalis_assembly.serialization import canonical_payload_json
from crysalis_g1.training.public_trajectory import (
    PublicTrajectoryConfig,
    run_public_trajectory_benchmark,
)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run public real-trajectory Crysalis-G1 L3/L4 benchmark"
    )
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    summary = run_public_trajectory_benchmark(
        PublicTrajectoryConfig.from_json(args.config)
    )
    print(canonical_payload_json(summary), flush=True)


if __name__ == "__main__":
    main()
