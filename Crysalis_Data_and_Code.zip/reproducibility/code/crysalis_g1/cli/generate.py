from __future__ import annotations

import argparse
import json
from pathlib import Path

from crysalis_g1.generation.sampler import generate_smoke_candidates
from crysalis_g1.training.smoke import SmokeConfig


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate deterministic G1 smoke candidates")
    parser.add_argument("--config", required=True)
    parser.add_argument("--count", type=int, default=100)
    args = parser.parse_args()
    config = SmokeConfig.from_json(args.config)
    candidates = generate_smoke_candidates(count=args.count, seed=config.seed)
    output = Path(config.output_root)
    output.mkdir(parents=True, exist_ok=True)
    path = output / "trajectories.jsonl"
    with path.open("w", encoding="utf-8") as handle:
        for candidate in candidates:
            handle.write(candidate.trajectory.to_json() + "\n")
    print(json.dumps({"count": len(candidates), "path": str(path)}, sort_keys=True))


if __name__ == "__main__":
    main()

