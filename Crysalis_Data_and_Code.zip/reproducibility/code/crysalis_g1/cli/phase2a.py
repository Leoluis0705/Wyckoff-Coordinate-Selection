from __future__ import annotations

import argparse

from crysalis_assembly.serialization import canonical_payload_json
from crysalis_g1.data.phase2a import Phase2AConfig, run_phase2a


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build the public-only Crysalis-G1 Phase 2A cache"
    )
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    result = run_phase2a(Phase2AConfig.from_json(args.config))
    print(canonical_payload_json(result))


if __name__ == "__main__":
    main()
