from __future__ import annotations

import argparse
import json

from crysalis_g1.training.smoke import SmokeConfig, run_smoke


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the Crysalis-G1 engineering smoke")
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    summary = run_smoke(SmokeConfig.from_json(args.config))
    print(json.dumps(summary, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()

