from __future__ import annotations

import argparse

from crysalis_assembly.serialization import canonical_payload_json
from crysalis_g1.training.phase2b_preflight import (
    Phase2BPreflightConfig,
    run_phase2b_preflight,
)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run the local Crysalis-G1 Phase 2B model-skeleton preflight"
    )
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    result = run_phase2b_preflight(Phase2BPreflightConfig.from_json(args.config))
    print(canonical_payload_json(result))


if __name__ == "__main__":
    main()
