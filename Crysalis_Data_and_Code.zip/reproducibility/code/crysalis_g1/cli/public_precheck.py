from __future__ import annotations

import argparse

from crysalis_assembly.serialization import canonical_payload_json
from crysalis_g1.data.public_precheck import L2Config, run_l2_precheck


def main() -> None:
    parser = argparse.ArgumentParser(description="Run Crysalis-G1 public-only L2 precheck")
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    print(canonical_payload_json(run_l2_precheck(L2Config.from_json(args.config))))


if __name__ == "__main__":
    main()

