from __future__ import annotations

import hashlib
import warnings
from collections import Counter, defaultdict
from collections.abc import Sequence
from dataclasses import asdict, dataclass
from statistics import median
from typing import Any

from pymatgen.core import Lattice, Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer

from crysalis_assembly.serialization import canonical_payload_json

from .public_precheck import ParentCrystal


CANONICAL_SCHEMA_VERSION = "g1-phase2a-canonical.1.0.0"


class CanonicalizationError(ValueError):
    def __init__(
        self,
        reason_code: str,
        detail: str,
        *,
        observations: Sequence[SymmetrySignature] = (),
    ):
        self.reason_code = reason_code
        self.detail = detail
        self.observations = tuple(observations)
        super().__init__(f"{reason_code}: {detail}")


@dataclass(frozen=True, slots=True)
class SymmetrySignature:
    symprec: float
    space_group: int
    equivalent_atoms: tuple[int, ...]
    wyckoff_letters: tuple[str, ...]

    @property
    def identity(self) -> tuple[object, ...]:
        groups: dict[int, list[int]] = defaultdict(list)
        for site_index, group in enumerate(self.equivalent_atoms):
            groups[group].append(site_index)
        normalized = tuple(
            sorted(
                (
                    self.wyckoff_letters[site_indices[0]],
                    tuple(site_indices),
                )
                for site_indices in groups.values()
            )
        )
        return self.space_group, normalized

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class CanonicalOrbitRecord:
    orbit_id: str
    canonical_site_indices: tuple[int, ...]
    source_site_indices: tuple[int, ...]
    atomic_number: int
    multiplicity: int
    wyckoff_letter: str

    def __post_init__(self) -> None:
        if not self.orbit_id:
            raise ValueError("orbit_id must be non-empty")
        if not self.canonical_site_indices:
            raise ValueError("canonical orbit membership must be non-empty")
        if self.multiplicity != len(self.canonical_site_indices):
            raise ValueError("orbit multiplicity must equal canonical membership size")
        if len(self.source_site_indices) != self.multiplicity:
            raise ValueError("source membership size must equal orbit multiplicity")
        if not 1 <= self.atomic_number <= 118:
            raise ValueError("atomic_number must be from 1 to 118")
        if not self.wyckoff_letter:
            raise ValueError("wyckoff_letter must be non-empty")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class CanonicalParentRecord:
    material_id: str
    source_partition: str
    source_prototype_family: str
    source_structure_hash: str
    canonical_structure_hash: str
    lattice: tuple[tuple[float, float, float], ...]
    atomic_numbers: tuple[int, ...]
    fractional_coordinates: tuple[tuple[float, float, float], ...]
    canonical_to_source_site: tuple[int, ...]
    source_space_group: int
    space_group: int
    symmetry_status: str
    observations: tuple[SymmetrySignature, ...]
    orbits: tuple[CanonicalOrbitRecord, ...]
    reduced_formula_key: tuple[tuple[int, int], ...]

    @property
    def site_count(self) -> int:
        return len(self.atomic_numbers)

    @property
    def element_count(self) -> int:
        return len(set(self.atomic_numbers))

    def to_structure(self) -> Structure:
        return Structure(
            Lattice(self.lattice),
            self.atomic_numbers,
            self.fractional_coordinates,
            coords_are_cartesian=False,
            to_unit_cell=True,
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def choose_symmetry_signature(
    observations: Sequence[SymmetrySignature],
) -> tuple[SymmetrySignature, str]:
    if len(observations) != 3:
        raise ValueError("symmetry ensemble must contain exactly three observations")
    counts = Counter(observation.identity for observation in observations)
    identity, count = counts.most_common(1)[0]
    if count < 2:
        raise CanonicalizationError(
            "AMBIGUOUS_SYMMETRY",
            "no two-of-three symmetry signature majority",
            observations=observations,
        )
    candidates = [item for item in observations if item.identity == identity]
    midpoint = median(item.symprec for item in observations)
    chosen = min(candidates, key=lambda item: (abs(item.symprec - midpoint), item.symprec))
    return chosen, "stable" if count == 3 else "majority"


def _canonical_site_order(
    parent: ParentCrystal,
) -> tuple[
    tuple[int, ...],
    tuple[int, ...],
    tuple[tuple[float, float, float], ...],
]:
    rows = []
    for source_index, (atomic_number, coordinate) in enumerate(
        zip(parent.atomic_numbers, parent.fractional_coordinates, strict=True)
    ):
        wrapped = tuple(float(value) % 1.0 for value in coordinate)
        rows.append((int(atomic_number), wrapped, source_index))
    rows.sort(
        key=lambda row: (
            row[0],
            *(round(value, 10) for value in row[1]),
            row[2],
        )
    )
    atomic_numbers = tuple(row[0] for row in rows)
    coordinates = tuple(row[1] for row in rows)
    canonical_to_source = tuple(row[2] for row in rows)
    return atomic_numbers, canonical_to_source, coordinates


def _canonical_structure_hash(
    lattice: tuple[tuple[float, float, float], ...],
    atomic_numbers: tuple[int, ...],
    fractional_coordinates: tuple[tuple[float, float, float], ...],
) -> str:
    payload = {
        "schema_version": CANONICAL_SCHEMA_VERSION,
        "lattice": tuple(
            tuple(round(float(value), 8) for value in row) for row in lattice
        ),
        "sites": tuple(
            {
                "atomic_number": atomic_number,
                "fractional": tuple(round(float(value) % 1.0, 8) for value in coordinate),
            }
            for atomic_number, coordinate in zip(
                atomic_numbers, fractional_coordinates, strict=True
            )
        ),
    }
    return hashlib.sha256(canonical_payload_json(payload).encode("utf-8")).hexdigest()


def _observe_symmetry(
    structure: Structure, *, symprec: float, angle_tolerance: float
) -> SymmetrySignature:
    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            message="Set OLD_ERROR_HANDLING to false and catch the errors directly.*",
            category=DeprecationWarning,
        )
        dataset = SpacegroupAnalyzer(
            structure,
            symprec=symprec,
            angle_tolerance=angle_tolerance,
        ).get_symmetry_dataset()
    if dataset is None:
        raise CanonicalizationError(
            "AMBIGUOUS_SYMMETRY",
            f"spglib returned no dataset at symprec={symprec}",
        )
    return SymmetrySignature(
        symprec=float(symprec),
        space_group=int(dataset.number),
        equivalent_atoms=tuple(int(value) for value in dataset.equivalent_atoms),
        wyckoff_letters=tuple(str(value) for value in dataset.wyckoffs),
    )


def _build_orbits(
    *,
    material_id: str,
    canonical_structure_hash: str,
    atomic_numbers: tuple[int, ...],
    canonical_to_source: tuple[int, ...],
    observation: SymmetrySignature,
) -> tuple[CanonicalOrbitRecord, ...]:
    groups: dict[int, list[int]] = defaultdict(list)
    for site_index, group in enumerate(observation.equivalent_atoms):
        groups[group].append(site_index)
    records = []
    for site_indices in sorted(groups.values(), key=lambda values: min(values)):
        membership = tuple(site_indices)
        species = {atomic_numbers[index] for index in membership}
        if len(species) != 1:
            raise CanonicalizationError(
                "MIXED_ORBIT_SPECIES",
                f"{material_id}: equivalent membership contains {sorted(species)}",
            )
        atomic_number = next(iter(species))
        source_membership = tuple(
            sorted(canonical_to_source[index] for index in membership)
        )
        identity = {
            "schema_version": CANONICAL_SCHEMA_VERSION,
            "canonical_structure_hash": canonical_structure_hash,
            "canonical_site_indices": membership,
            "atomic_number": atomic_number,
            "multiplicity": len(membership),
        }
        orbit_id = "orbit-" + hashlib.sha256(
            canonical_payload_json(identity).encode("utf-8")
        ).hexdigest()
        records.append(
            CanonicalOrbitRecord(
                orbit_id=orbit_id,
                canonical_site_indices=membership,
                source_site_indices=source_membership,
                atomic_number=atomic_number,
                multiplicity=len(membership),
                wyckoff_letter=observation.wyckoff_letters[membership[0]],
            )
        )
    return tuple(records)


def canonicalize_parent(
    parent: ParentCrystal,
    *,
    symprec_values: Sequence[float],
    angle_tolerance: float,
) -> CanonicalParentRecord:
    normalized_symprec = tuple(float(value) for value in symprec_values)
    if normalized_symprec != (0.03, 0.05, 0.1):
        raise ValueError("symprec_values must be exactly (0.03, 0.05, 0.1)")
    atomic_numbers, canonical_to_source, coordinates = _canonical_site_order(parent)
    lattice = tuple(
        tuple(float(value) for value in row) for row in parent.lattice
    )
    structure = Structure(
        Lattice(lattice),
        atomic_numbers,
        coordinates,
        coords_are_cartesian=False,
        to_unit_cell=True,
    )
    canonical_hash = _canonical_structure_hash(
        lattice,
        atomic_numbers,
        coordinates,
    )
    observations = tuple(
        _observe_symmetry(
            structure,
            symprec=symprec,
            angle_tolerance=angle_tolerance,
        )
        for symprec in normalized_symprec
    )
    chosen, symmetry_status = choose_symmetry_signature(observations)
    orbits = _build_orbits(
        material_id=parent.material_id,
        canonical_structure_hash=canonical_hash,
        atomic_numbers=atomic_numbers,
        canonical_to_source=canonical_to_source,
        observation=chosen,
    )
    return CanonicalParentRecord(
        material_id=parent.material_id,
        source_partition=parent.partition,
        source_prototype_family=parent.prototype_family,
        source_structure_hash=parent.structure_hash,
        canonical_structure_hash=canonical_hash,
        lattice=lattice,
        atomic_numbers=atomic_numbers,
        fractional_coordinates=coordinates,
        canonical_to_source_site=canonical_to_source,
        source_space_group=parent.space_group,
        space_group=chosen.space_group,
        symmetry_status=symmetry_status,
        observations=observations,
        orbits=orbits,
        reduced_formula_key=parent.reduced_formula_key,
    )
