from __future__ import annotations

import hashlib
import json
import math
import warnings
from collections import defaultdict
from dataclasses import asdict, dataclass
from functools import lru_cache
from itertools import permutations
from typing import Any, Literal

import numpy as np
from pymatgen.core import Element, Lattice
from pymatgen.util.coord import pbc_shortest_vectors

from crysalis_assembly.serialization import canonical_payload_json

from .canonical import CanonicalParentRecord


OPERATOR_SCHEMA_VERSION = "g1-phase2a-operators.1.0.0"
OperatorName = Literal["D_orbit", "D_relation_interface"]
ActionMode = Literal["REMOVE", "RESTORE"]


class OperatorReplayError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class CanonicalRelationRecord:
    relation_id: str
    source_site_index: int
    target_site_index: int
    source_orbit_id: str
    target_orbit_id: str
    image: tuple[int, int, int]
    distance: float

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class RelationInterfaceGroup:
    group_id: str
    source_orbit_id: str
    target_orbit_id: str
    relation_ids: tuple[str, ...]

    def __post_init__(self) -> None:
        if not self.relation_ids:
            raise ValueError("relation interface must contain at least one relation")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class RelationRegistry:
    material_id: str
    canonical_structure_hash: str
    relations: tuple[CanonicalRelationRecord, ...]
    interface_groups: tuple[RelationInterfaceGroup, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class DeconstructionState:
    canonical_structure_hash: str
    active_orbit_ids: tuple[str, ...]
    active_relation_ids: tuple[str, ...]

    def __post_init__(self) -> None:
        if self.active_orbit_ids != tuple(sorted(set(self.active_orbit_ids))):
            raise ValueError("active orbit IDs must be sorted and unique")
        if self.active_relation_ids != tuple(sorted(set(self.active_relation_ids))):
            raise ValueError("active relation IDs must be sorted and unique")

    def content_hash(self) -> str:
        return hashlib.sha256(
            canonical_payload_json(asdict(self)).encode("utf-8")
        ).hexdigest()


@dataclass(frozen=True, slots=True)
class StructuralAction:
    operator: OperatorName
    mode: ActionMode
    target_id: str

    def __post_init__(self) -> None:
        if self.operator not in {"D_orbit", "D_relation_interface"}:
            raise ValueError(f"unsupported structural operator {self.operator}")
        if self.mode not in {"REMOVE", "RESTORE"}:
            raise ValueError(f"unsupported structural action mode {self.mode}")
        if not self.target_id:
            raise ValueError("structural action target must be non-empty")

    def to_dict(self) -> dict[str, str]:
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> StructuralAction:
        return cls(
            operator=str(payload["operator"]),
            mode=str(payload["mode"]),
            target_id=str(payload["target_id"]),
        )


@dataclass(frozen=True, slots=True)
class StructuralTrajectory:
    parent_structure_id: str
    operator: OperatorName
    path_index: int
    forward_actions: tuple[StructuralAction, ...]
    inverse_actions: tuple[StructuralAction, ...]
    forward_state_hashes: tuple[str, ...]
    inverse_state_hashes: tuple[str, ...]
    sequence_hash: str

    def __post_init__(self) -> None:
        if len(self.forward_actions) != len(self.forward_state_hashes):
            raise ValueError("forward action/hash length mismatch")
        if len(self.inverse_actions) != len(self.inverse_state_hashes):
            raise ValueError("inverse action/hash length mismatch")
        if any(action.operator != self.operator for action in self.forward_actions):
            raise ValueError("forward action operator mismatch")
        if any(action.operator != self.operator for action in self.inverse_actions):
            raise ValueError("inverse action operator mismatch")

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": OPERATOR_SCHEMA_VERSION,
            "parent_structure_id": self.parent_structure_id,
            "operator": self.operator,
            "path_index": self.path_index,
            "forward_actions": [action.to_dict() for action in self.forward_actions],
            "inverse_actions": [action.to_dict() for action in self.inverse_actions],
            "forward_state_hashes": self.forward_state_hashes,
            "inverse_state_hashes": self.inverse_state_hashes,
            "sequence_hash": self.sequence_hash,
        }

    def to_json(self) -> str:
        return canonical_payload_json(self.to_dict())

    @classmethod
    def from_json(cls, encoded: str) -> StructuralTrajectory:
        payload = json.loads(encoded)
        if payload.get("schema_version") != OPERATOR_SCHEMA_VERSION:
            raise ValueError("unsupported structural trajectory schema")
        return cls(
            parent_structure_id=str(payload["parent_structure_id"]),
            operator=str(payload["operator"]),
            path_index=int(payload["path_index"]),
            forward_actions=tuple(
                StructuralAction.from_dict(item) for item in payload["forward_actions"]
            ),
            inverse_actions=tuple(
                StructuralAction.from_dict(item) for item in payload["inverse_actions"]
            ),
            forward_state_hashes=tuple(str(value) for value in payload["forward_state_hashes"]),
            inverse_state_hashes=tuple(str(value) for value in payload["inverse_state_hashes"]),
            sequence_hash=str(payload["sequence_hash"]),
        )


@dataclass(frozen=True, slots=True)
class ReplayResult:
    passed: bool
    initial_state_hash: str
    final_state_hash: str
    forward_step_count: int
    inverse_step_count: int
    forward_replay_passed: bool
    inverse_replay_passed: bool
    periodic_image_replay_passed: bool
    skew_lattice_translation_replay_passed: bool
    periodic_image_relation_count: int
    skew_lattice_translation_relation_count: int

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class PeriodicRelationReplayResult:
    passed: bool
    periodic_image_relation_count: int
    skew_lattice_translation_relation_count: int

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@lru_cache(maxsize=256)
def _radius(atomic_number: int, fallback: float) -> float:
    element = Element.from_Z(atomic_number)
    if element.atomic_radius is not None and float(element.atomic_radius) > 0:
        return float(element.atomic_radius)
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="No data available.*")
        calculated = element.atomic_radius_calculated
    if calculated is not None and float(calculated) > 0:
        return float(calculated)
    return fallback


def _site_orbit_map(record: CanonicalParentRecord) -> dict[int, str]:
    result: dict[int, str] = {}
    for orbit in record.orbits:
        for site_index in orbit.canonical_site_indices:
            if site_index in result:
                raise ValueError("canonical site belongs to multiple orbits")
            result[site_index] = orbit.orbit_id
    if set(result) != set(range(record.site_count)):
        raise ValueError("canonical orbit membership does not cover all sites")
    return result


def build_relation_registry(
    record: CanonicalParentRecord,
    *,
    alpha_values: tuple[float, float, float],
    max_distance: float,
    radius_fallback: float,
) -> RelationRegistry:
    if tuple(sorted(alpha_values)) != alpha_values or any(
        value <= 0 for value in alpha_values
    ):
        raise ValueError("alpha_values must be sorted and positive")
    if max_distance <= 0 or radius_fallback <= 0:
        raise ValueError("relation distance parameters must be positive")
    lattice = np.asarray(record.lattice, dtype=float)
    fractions = np.asarray(record.fractional_coordinates, dtype=float)
    vectors, distance_squared = pbc_shortest_vectors(
        Lattice(lattice),
        fractions,
        fractions,
        return_d2=True,
    )
    inverse_lattice = np.linalg.inv(lattice)
    radii = tuple(_radius(number, radius_fallback) for number in record.atomic_numbers)
    site_orbit = _site_orbit_map(record)
    relations = []
    for source in range(record.site_count):
        for target in range(source + 1, record.site_count):
            distance = float(math.sqrt(max(0.0, distance_squared[source, target])))
            stable_count = sum(
                distance
                <= min(
                    max_distance,
                    alpha * (radii[source] + radii[target]),
                )
                + 1e-12
                for alpha in alpha_values
            )
            if stable_count < 2:
                continue
            raw_fractional = fractions[target] - fractions[source]
            shortest_fractional = vectors[source, target] @ inverse_lattice
            image_array = np.rint(shortest_fractional - raw_fractional).astype(int)
            image = (
                int(image_array[0]),
                int(image_array[1]),
                int(image_array[2]),
            )
            identity = {
                "schema_version": OPERATOR_SCHEMA_VERSION,
                "canonical_structure_hash": record.canonical_structure_hash,
                "source_site_index": source,
                "target_site_index": target,
                "image": image,
                "relation_type": "stable_neighbor",
            }
            relation_id = "relation-" + hashlib.sha256(
                canonical_payload_json(identity).encode("utf-8")
            ).hexdigest()
            relations.append(
                CanonicalRelationRecord(
                    relation_id=relation_id,
                    source_site_index=source,
                    target_site_index=target,
                    source_orbit_id=site_orbit[source],
                    target_orbit_id=site_orbit[target],
                    image=image,
                    distance=distance,
                )
            )
    relations.sort(key=lambda item: item.relation_id)
    group_relations: dict[tuple[str, str], list[str]] = defaultdict(list)
    for relation in relations:
        endpoints = tuple(
            sorted((relation.source_orbit_id, relation.target_orbit_id))
        )
        group_relations[endpoints].append(relation.relation_id)
    groups = []
    for endpoints, relation_ids in sorted(group_relations.items()):
        relation_ids_tuple = tuple(sorted(relation_ids))
        identity = {
            "schema_version": OPERATOR_SCHEMA_VERSION,
            "canonical_structure_hash": record.canonical_structure_hash,
            "endpoint_orbit_ids": endpoints,
            "relation_ids": relation_ids_tuple,
        }
        group_id = "relation-interface-" + hashlib.sha256(
            canonical_payload_json(identity).encode("utf-8")
        ).hexdigest()
        groups.append(
            RelationInterfaceGroup(
                group_id=group_id,
                source_orbit_id=endpoints[0],
                target_orbit_id=endpoints[1],
                relation_ids=relation_ids_tuple,
            )
        )
    return RelationRegistry(
        material_id=record.material_id,
        canonical_structure_hash=record.canonical_structure_hash,
        relations=tuple(relations),
        interface_groups=tuple(groups),
    )


def initial_deconstruction_state(
    record: CanonicalParentRecord,
    registry: RelationRegistry,
) -> DeconstructionState:
    if registry.material_id != record.material_id:
        raise ValueError("relation registry belongs to a different parent")
    return DeconstructionState(
        canonical_structure_hash=record.canonical_structure_hash,
        active_orbit_ids=tuple(sorted(orbit.orbit_id for orbit in record.orbits)),
        active_relation_ids=tuple(
            sorted(relation.relation_id for relation in registry.relations)
        ),
    )


def replay_periodic_relations(
    record: CanonicalParentRecord,
    registry: RelationRegistry,
) -> PeriodicRelationReplayResult:
    if registry.material_id != record.material_id:
        raise OperatorReplayError("RELATION_REGISTRY_PARENT_MISMATCH")
    if registry.canonical_structure_hash != record.canonical_structure_hash:
        raise OperatorReplayError("RELATION_REGISTRY_STRUCTURE_HASH_MISMATCH")
    lattice = np.asarray(record.lattice, dtype=float)
    fractions = np.asarray(record.fractional_coordinates, dtype=float)
    vectors, distance_squared = pbc_shortest_vectors(
        Lattice(lattice),
        fractions,
        fractions,
        return_d2=True,
    )
    inverse_lattice = np.linalg.inv(lattice)
    source_translation = np.asarray((1, -1, 2), dtype=int)
    target_translation = np.asarray((-2, 1, -1), dtype=int)
    for relation in registry.relations:
        source = relation.source_site_index
        target = relation.target_site_index
        if not (
            0 <= source < record.site_count
            and 0 <= target < record.site_count
            and source < target
        ):
            raise OperatorReplayError("RELATION_SITE_INDEX_INVALID")
        raw_fractional = fractions[target] - fractions[source]
        shortest_fractional = vectors[source, target] @ inverse_lattice
        expected_image_array = np.rint(
            shortest_fractional - raw_fractional
        ).astype(int)
        expected_image = tuple(int(value) for value in expected_image_array)
        if relation.image != expected_image:
            raise OperatorReplayError(
                f"PERIODIC_IMAGE_MISMATCH:{relation.relation_id}"
            )
        stored_fractional = raw_fractional + np.asarray(relation.image, dtype=int)
        stored_cartesian = stored_fractional @ lattice
        if not np.allclose(
            stored_cartesian,
            vectors[source, target],
            rtol=1e-9,
            atol=1e-9,
        ):
            raise OperatorReplayError(
                f"PERIODIC_VECTOR_MISMATCH:{relation.relation_id}"
            )
        expected_distance = float(
            math.sqrt(max(0.0, distance_squared[source, target]))
        )
        if not math.isclose(
            relation.distance,
            expected_distance,
            rel_tol=1e-9,
            abs_tol=1e-9,
        ):
            raise OperatorReplayError(
                f"PERIODIC_DISTANCE_MISMATCH:{relation.relation_id}"
            )
        translated_source = fractions[source] + source_translation
        translated_target = fractions[target] + target_translation
        translated_image = (
            np.asarray(relation.image, dtype=int)
            + source_translation
            - target_translation
        )
        translated_fractional = (
            translated_target + translated_image - translated_source
        )
        translated_cartesian = translated_fractional @ lattice
        if not np.allclose(
            translated_cartesian,
            stored_cartesian,
            rtol=1e-9,
            atol=1e-9,
        ):
            raise OperatorReplayError(
                f"SKEW_LATTICE_TRANSLATION_MISMATCH:{relation.relation_id}"
            )
    relation_count = len(registry.relations)
    return PeriodicRelationReplayResult(
        passed=True,
        periodic_image_relation_count=relation_count,
        skew_lattice_translation_relation_count=relation_count,
    )


def apply_structural_action(
    state: DeconstructionState,
    action: StructuralAction,
    record: CanonicalParentRecord,
    registry: RelationRegistry,
) -> DeconstructionState:
    if state.canonical_structure_hash != record.canonical_structure_hash:
        raise OperatorReplayError("STATE_PARENT_MISMATCH")
    orbit_ids = {orbit.orbit_id for orbit in record.orbits}
    relations_by_id = {
        relation.relation_id: relation for relation in registry.relations
    }
    groups_by_id = {group.group_id: group for group in registry.interface_groups}
    active_orbits = set(state.active_orbit_ids)
    active_relations = set(state.active_relation_ids)
    if action.operator == "D_orbit":
        if action.target_id not in orbit_ids:
            raise OperatorReplayError("UNKNOWN_ORBIT")
        if action.mode == "REMOVE":
            if action.target_id not in active_orbits:
                raise OperatorReplayError("ORBIT_NOT_ACTIVE")
            active_orbits.remove(action.target_id)
            active_relations = {
                relation_id
                for relation_id in active_relations
                if action.target_id
                not in (
                    relations_by_id[relation_id].source_orbit_id,
                    relations_by_id[relation_id].target_orbit_id,
                )
            }
        else:
            if action.target_id in active_orbits:
                raise OperatorReplayError("ORBIT_ALREADY_ACTIVE")
            active_orbits.add(action.target_id)
            for relation in registry.relations:
                if (
                    relation.source_orbit_id in active_orbits
                    and relation.target_orbit_id in active_orbits
                ):
                    active_relations.add(relation.relation_id)
    else:
        group = groups_by_id.get(action.target_id)
        if group is None:
            raise OperatorReplayError("UNKNOWN_RELATION_INTERFACE")
        group_relations = set(group.relation_ids)
        present = group_relations & active_relations
        if action.mode == "REMOVE":
            if present != group_relations:
                raise OperatorReplayError("RELATION_INTERFACE_NOT_FULLY_ACTIVE")
            active_relations.difference_update(group_relations)
        else:
            if present:
                raise OperatorReplayError("RELATION_INTERFACE_PARTIAL_OR_ACTIVE")
            if (
                group.source_orbit_id not in active_orbits
                or group.target_orbit_id not in active_orbits
            ):
                raise OperatorReplayError("RELATION_INTERFACE_ENDPOINT_INACTIVE")
            active_relations.update(group_relations)
    return DeconstructionState(
        canonical_structure_hash=state.canonical_structure_hash,
        active_orbit_ids=tuple(sorted(active_orbits)),
        active_relation_ids=tuple(sorted(active_relations)),
    )


def _orbit_path_candidates(
    record: CanonicalParentRecord, seed: int
) -> list[tuple[str, ...]]:
    base = tuple(sorted(orbit.orbit_id for orbit in record.orbits))
    candidates = [base, tuple(reversed(base))]
    candidates.extend(base[offset:] + base[:offset] for offset in range(1, len(base)))
    candidates.append(
        tuple(
            sorted(
                base,
                key=lambda orbit_id: (
                    hashlib.sha256(
                        f"g1-phase2a:{seed}:{record.material_id}:{orbit_id}".encode(
                            "utf-8"
                        )
                    ).hexdigest(),
                    orbit_id,
                ),
            )
        )
    )
    if len(base) <= 8:
        candidates.extend(permutations(base))
    unique = []
    for candidate in candidates:
        if candidate not in unique:
            unique.append(candidate)
    return unique


def _trajectory(
    *,
    record: CanonicalParentRecord,
    registry: RelationRegistry,
    operator: OperatorName,
    path_index: int,
    targets: tuple[str, ...],
) -> StructuralTrajectory:
    state = initial_deconstruction_state(record, registry)
    forward_actions = tuple(
        StructuralAction(operator, "REMOVE", target_id) for target_id in targets
    )
    forward_hashes = []
    for action in forward_actions:
        state = apply_structural_action(state, action, record, registry)
        forward_hashes.append(state.content_hash())
    inverse_actions = tuple(
        StructuralAction(operator, "RESTORE", target_id)
        for target_id in reversed(targets)
    )
    inverse_hashes = []
    for action in inverse_actions:
        state = apply_structural_action(state, action, record, registry)
        inverse_hashes.append(state.content_hash())
    action_payload = {
        "schema_version": OPERATOR_SCHEMA_VERSION,
        "canonical_structure_hash": record.canonical_structure_hash,
        "operator": operator,
        "forward_actions": tuple(action.to_dict() for action in forward_actions),
        "inverse_actions": tuple(action.to_dict() for action in inverse_actions),
    }
    return StructuralTrajectory(
        parent_structure_id=record.material_id,
        operator=operator,
        path_index=path_index,
        forward_actions=forward_actions,
        inverse_actions=inverse_actions,
        forward_state_hashes=tuple(forward_hashes),
        inverse_state_hashes=tuple(inverse_hashes),
        sequence_hash=hashlib.sha256(
            canonical_payload_json(action_payload).encode("utf-8")
        ).hexdigest(),
    )


def build_d_orbit_trajectories(
    record: CanonicalParentRecord,
    registry: RelationRegistry,
    *,
    seed: int,
    paths_per_parent: int = 4,
) -> tuple[StructuralTrajectory, ...]:
    if paths_per_parent <= 0:
        raise ValueError("paths_per_parent must be positive")
    candidates = _orbit_path_candidates(record, seed)
    if len(candidates) < paths_per_parent:
        raise OperatorReplayError("INSUFFICIENT_UNIQUE_D_ORBIT_PATHS")
    trajectories = tuple(
        _trajectory(
            record=record,
            registry=registry,
            operator="D_orbit",
            path_index=path_index,
            targets=targets,
        )
        for path_index, targets in enumerate(candidates[:paths_per_parent])
    )
    if len({item.sequence_hash for item in trajectories}) != paths_per_parent:
        raise OperatorReplayError("D_ORBIT_SEQUENCE_HASH_COLLISION")
    return trajectories


def build_d_relation_trajectory(
    record: CanonicalParentRecord,
    registry: RelationRegistry,
) -> StructuralTrajectory | None:
    targets = tuple(group.group_id for group in registry.interface_groups)
    if not targets:
        return None
    return _trajectory(
        record=record,
        registry=registry,
        operator="D_relation_interface",
        path_index=0,
        targets=targets,
    )


def replay_trajectory(
    record: CanonicalParentRecord,
    registry: RelationRegistry,
    trajectory: StructuralTrajectory,
) -> ReplayResult:
    if trajectory.parent_structure_id != record.material_id:
        raise OperatorReplayError("TRAJECTORY_PARENT_MISMATCH")
    periodic_replay = replay_periodic_relations(record, registry)
    state = initial_deconstruction_state(record, registry)
    initial_hash = state.content_hash()
    for step_index, (action, expected_hash) in enumerate(
        zip(
            trajectory.forward_actions,
            trajectory.forward_state_hashes,
            strict=True,
        )
    ):
        state = apply_structural_action(state, action, record, registry)
        if state.content_hash() != expected_hash:
            raise OperatorReplayError(f"FORWARD_STATE_HASH_MISMATCH:{step_index}")
    for step_index, (action, expected_hash) in enumerate(
        zip(
            trajectory.inverse_actions,
            trajectory.inverse_state_hashes,
            strict=True,
        )
    ):
        state = apply_structural_action(state, action, record, registry)
        if state.content_hash() != expected_hash:
            raise OperatorReplayError(f"INVERSE_STATE_HASH_MISMATCH:{step_index}")
    final_hash = state.content_hash()
    if final_hash != initial_hash:
        raise OperatorReplayError("ROUNDTRIP_FINAL_STATE_MISMATCH")
    return ReplayResult(
        passed=True,
        initial_state_hash=initial_hash,
        final_state_hash=final_hash,
        forward_step_count=len(trajectory.forward_actions),
        inverse_step_count=len(trajectory.inverse_actions),
        forward_replay_passed=True,
        inverse_replay_passed=True,
        periodic_image_replay_passed=periodic_replay.passed,
        skew_lattice_translation_replay_passed=periodic_replay.passed,
        periodic_image_relation_count=(
            periodic_replay.periodic_image_relation_count
        ),
        skew_lattice_translation_relation_count=(
            periodic_replay.skew_lattice_translation_relation_count
        ),
    )
