from __future__ import annotations

import hashlib
import math
import warnings
from collections import Counter, defaultdict
from collections.abc import Callable, Iterable, Sequence
from dataclasses import asdict, dataclass
from itertools import combinations
from typing import Any

from pymatgen.analysis.structure_matcher import StructureMatcher

from crysalis_assembly.serialization import canonical_payload_json

from .canonical import CanonicalParentRecord


@dataclass(frozen=True, slots=True, order=True)
class AnonymousMatchEdge:
    left_material_id: str
    right_material_id: str

    def __post_init__(self) -> None:
        if not self.left_material_id or not self.right_material_id:
            raise ValueError("anonymous match endpoints must be non-empty")
        if self.left_material_id >= self.right_material_id:
            raise ValueError("anonymous match endpoints must be sorted and distinct")

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class AnonymousMatchEnumeration:
    parent_count: int
    candidate_pair_count: int
    same_prototype_skipped_count: int
    compared_pair_count: int
    confirmed_edge_count: int
    exhaustive_within_necessary_prefilter: bool
    necessary_prefilter_fields: tuple[str, ...]
    edges: tuple[AnonymousMatchEdge, ...]

    def __post_init__(self) -> None:
        if self.compared_pair_count != (
            self.candidate_pair_count - self.same_prototype_skipped_count
        ):
            raise ValueError("anonymous enumeration pair counts are inconsistent")
        if self.confirmed_edge_count != len(self.edges):
            raise ValueError("anonymous enumeration edge count is inconsistent")

    def to_dict(self, *, include_edges: bool = True) -> dict[str, Any]:
        payload = asdict(self)
        if not include_edges:
            payload.pop("edges")
        return payload


@dataclass(frozen=True, slots=True)
class SplitAssignment:
    material_id: str
    source_partition: str
    split: str
    component_id: str
    reason_codes: tuple[str, ...]

    def __post_init__(self) -> None:
        if self.source_partition not in {"train_fit", "validation"}:
            raise ValueError("source partition must be train_fit or validation")
        if self.split not in {"train_fit", "validation"}:
            raise ValueError("split must be train_fit or validation")
        if not self.material_id or not self.component_id:
            raise ValueError("assignment identity must be non-empty")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class SplitAuditReport:
    split_name: str
    require_formula_disjoint: bool
    parent_count: int
    train_fit_count: int
    validation_count: int
    duplicate_material_id_count: int
    cross_partition_structure_hash_count: int
    cross_partition_prototype_family_count: int
    cross_partition_anonymous_near_duplicate_count: int
    cross_partition_reduced_formula_count: int
    cross_partition_reduced_formula_parent_count: int

    @property
    def passes(self) -> bool:
        structural_pass = (
            self.duplicate_material_id_count == 0
            and self.cross_partition_structure_hash_count == 0
            and self.cross_partition_prototype_family_count == 0
            and self.cross_partition_anonymous_near_duplicate_count == 0
            and self.train_fit_count > 0
            and self.validation_count > 0
        )
        return structural_pass and (
            not self.require_formula_disjoint
            or self.cross_partition_reduced_formula_count == 0
        )

    def to_dict(self) -> dict[str, Any]:
        return {**asdict(self), "passes": self.passes}


class _UnionFind:
    def __init__(self, keys: Iterable[str]):
        self._parent = {key: key for key in keys}

    def find(self, key: str) -> str:
        parent = self._parent[key]
        if parent != key:
            self._parent[key] = self.find(parent)
        return self._parent[key]

    def union(self, left: str, right: str) -> None:
        left_root = self.find(left)
        right_root = self.find(right)
        if left_root == right_root:
            return
        first, second = sorted((left_root, right_root))
        self._parent[second] = first

    def components(self) -> tuple[tuple[str, ...], ...]:
        grouped: dict[str, list[str]] = defaultdict(list)
        for key in self._parent:
            grouped[self.find(key)].append(key)
        return tuple(
            sorted(
                (tuple(sorted(members)) for members in grouped.values()),
                key=lambda members: members,
            )
        )


def _records_by_id(
    records: Sequence[CanonicalParentRecord],
) -> dict[str, CanonicalParentRecord]:
    by_id = {record.material_id: record for record in records}
    if len(by_id) != len(records):
        raise ValueError("canonical records must have unique material IDs")
    if not by_id:
        raise ValueError("split construction requires at least one record")
    return by_id


def _anonymous_formula_signature(
    record: CanonicalParentRecord,
) -> tuple[int, ...]:
    counts = Counter(record.atomic_numbers)
    divisor = math.gcd(*counts.values())
    return tuple(sorted(value // divisor for value in counts.values()))


def _anonymous_bucket(record: CanonicalParentRecord) -> tuple[object, ...]:
    return (
        record.site_count,
        _anonymous_formula_signature(record),
    )


def _fit_anonymous(
    matcher: StructureMatcher,
    left: object,
    right: object,
) -> bool:
    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            message="Set OLD_ERROR_HANDLING to false and catch the errors directly.*",
            category=DeprecationWarning,
        )
        return bool(
            matcher.fit_anonymous(
                left,
                right,
                skip_structure_reduction=True,
            )
        )


def enumerate_anonymous_matches(
    records: Sequence[CanonicalParentRecord],
    *,
    progress_interval: int = 0,
    progress_callback: Callable[[int, int, int], None] | None = None,
) -> AnonymousMatchEnumeration:
    _records_by_id(records)
    if progress_interval < 0:
        raise ValueError("progress_interval must be non-negative")
    if progress_interval and progress_callback is None:
        raise ValueError("progress_callback is required when progress is enabled")
    buckets: dict[tuple[object, ...], list[CanonicalParentRecord]] = defaultdict(list)
    for record in records:
        buckets[_anonymous_bucket(record)].append(record)
    matcher = StructureMatcher(
        primitive_cell=False,
        scale=True,
        attempt_supercell=False,
        ltol=0.2,
        stol=0.3,
        angle_tol=5.0,
    )
    candidate_pair_count = sum(
        len(members) * (len(members) - 1) // 2 for members in buckets.values()
    )
    same_prototype_skipped_count = sum(
        1
        for members in buckets.values()
        for left, right in combinations(members, 2)
        if left.source_prototype_family == right.source_prototype_family
    )
    compared_pair_count = candidate_pair_count - same_prototype_skipped_count
    prepared_structures = {
        record.material_id: record.to_structure().get_reduced_structure(
            reduction_algo="niggli"
        )
        for record in records
    }
    edges: set[AnonymousMatchEdge] = set()
    compared = 0
    for members in buckets.values():
        for left, right in combinations(members, 2):
            if left.source_prototype_family == right.source_prototype_family:
                continue
            compared += 1
            if _fit_anonymous(
                matcher,
                prepared_structures[left.material_id],
                prepared_structures[right.material_id],
            ):
                left_id, right_id = sorted((left.material_id, right.material_id))
                edges.add(AnonymousMatchEdge(left_id, right_id))
            if (
                progress_interval
                and progress_callback is not None
                and (
                    compared % progress_interval == 0
                    or compared == compared_pair_count
                )
            ):
                progress_callback(compared, compared_pair_count, len(edges))
    sorted_edges = tuple(sorted(edges))
    return AnonymousMatchEnumeration(
        parent_count=len(records),
        candidate_pair_count=candidate_pair_count,
        same_prototype_skipped_count=same_prototype_skipped_count,
        compared_pair_count=compared,
        confirmed_edge_count=len(sorted_edges),
        exhaustive_within_necessary_prefilter=True,
        necessary_prefilter_fields=(
            "site_count",
            "anonymous_stoichiometry",
        ),
        edges=sorted_edges,
    )


def find_anonymous_match_edges(
    records: Sequence[CanonicalParentRecord],
) -> tuple[AnonymousMatchEdge, ...]:
    return enumerate_anonymous_matches(records).edges


def _structure_union(
    records: Sequence[CanonicalParentRecord],
    edges: Sequence[AnonymousMatchEdge],
) -> _UnionFind:
    by_id = _records_by_id(records)
    union = _UnionFind(by_id)
    family_members: dict[str, list[str]] = defaultdict(list)
    hash_members: dict[str, list[str]] = defaultdict(list)
    for record in records:
        family_members[record.source_prototype_family].append(record.material_id)
        hash_members[record.canonical_structure_hash].append(record.material_id)
    for groups in (family_members.values(), hash_members.values()):
        for members in groups:
            for member in members[1:]:
                union.union(members[0], member)
    for edge in edges:
        if edge.left_material_id not in by_id or edge.right_material_id not in by_id:
            raise ValueError("anonymous match edge contains an unknown material ID")
        union.union(edge.left_material_id, edge.right_material_id)
    return union


def _component_id(prefix: str, members: tuple[str, ...]) -> str:
    digest = hashlib.sha256(
        canonical_payload_json({"members": members}).encode("utf-8")
    ).hexdigest()
    return f"{prefix}-{digest}"


def build_structure_ood_split(
    records: Sequence[CanonicalParentRecord],
    edges: Sequence[AnonymousMatchEdge],
) -> tuple[SplitAssignment, ...]:
    by_id = _records_by_id(records)
    union = _structure_union(records, edges)
    assignments = []
    for members in union.components():
        source_partitions = {by_id[member].source_partition for member in members}
        unknown = source_partitions - {"train_fit", "validation"}
        if unknown:
            raise ValueError(f"unsupported source partitions: {sorted(unknown)}")
        split = "train_fit" if "train_fit" in source_partitions else "validation"
        component_id = _component_id("structure", members)
        for material_id in members:
            source_partition = by_id[material_id].source_partition
            reasons = ["STRUCTURAL_COMPONENT_ASSIGNMENT"]
            if source_partition == "validation" and split == "train_fit":
                reasons.append("MOVED_TO_PROTECT_STRUCTURE_OOD_VALIDATION")
            assignments.append(
                SplitAssignment(
                    material_id=material_id,
                    source_partition=source_partition,
                    split=split,
                    component_id=component_id,
                    reason_codes=tuple(reasons),
                )
            )
    return tuple(sorted(assignments, key=lambda item: item.material_id))


def build_composition_ood_split(
    records: Sequence[CanonicalParentRecord],
    edges: Sequence[AnonymousMatchEdge],
    *,
    seed: int,
    validation_fraction: float,
) -> tuple[SplitAssignment, ...]:
    if not 0 < validation_fraction < 1 or not math.isfinite(validation_fraction):
        raise ValueError("validation_fraction must be finite and in (0, 1)")
    by_id = _records_by_id(records)
    union = _structure_union(records, edges)
    formula_members: dict[tuple[tuple[int, int], ...], list[str]] = defaultdict(list)
    for record in records:
        formula_members[record.reduced_formula_key].append(record.material_id)
    for members in formula_members.values():
        for member in members[1:]:
            union.union(members[0], member)
    components = union.components()
    ranked = sorted(
        components,
        key=lambda members: (
            -len(members),
            hashlib.sha256(
                f"{seed}:{'|'.join(members)}".encode("utf-8")
            ).hexdigest(),
            members,
        ),
    )
    target_validation = validation_fraction * len(records)
    validation_count = 0
    split_by_component: dict[tuple[str, ...], str] = {}
    for members in ranked:
        add_distance = abs(validation_count + len(members) - target_validation)
        keep_distance = abs(validation_count - target_validation)
        split = "validation" if add_distance < keep_distance else "train_fit"
        split_by_component[members] = split
        if split == "validation":
            validation_count += len(members)
    assignments = []
    for members in components:
        split = split_by_component[members]
        component_id = _component_id("composition", members)
        for material_id in members:
            assignments.append(
                SplitAssignment(
                    material_id=material_id,
                    source_partition=by_id[material_id].source_partition,
                    split=split,
                    component_id=component_id,
                    reason_codes=("COMPOSITION_COMPONENT_ASSIGNMENT",),
                )
            )
    return tuple(sorted(assignments, key=lambda item: item.material_id))


def _cross_partition_groups(
    records: Sequence[CanonicalParentRecord],
    split_by_id: dict[str, str],
    *,
    field: str,
) -> tuple[int, int]:
    groups: dict[str, list[str]] = defaultdict(list)
    for record in records:
        value = getattr(record, field)
        key = canonical_payload_json(value)
        groups[key].append(record.material_id)
    overlaps = [
        members
        for members in groups.values()
        if len({split_by_id[material_id] for material_id in members}) > 1
    ]
    return len(overlaps), len({material_id for members in overlaps for material_id in members})


def audit_split(
    records: Sequence[CanonicalParentRecord],
    assignments: Sequence[SplitAssignment],
    edges: Sequence[AnonymousMatchEdge],
    *,
    require_formula_disjoint: bool,
) -> SplitAuditReport:
    by_id = _records_by_id(records)
    assignment_ids = [item.material_id for item in assignments]
    duplicate_assignment_ids = len(assignment_ids) - len(set(assignment_ids))
    if set(assignment_ids) != set(by_id):
        raise ValueError("split assignments and canonical records differ")
    split_by_id = {item.material_id: item.split for item in assignments}
    structure_overlap, _ = _cross_partition_groups(
        records,
        split_by_id,
        field="canonical_structure_hash",
    )
    family_overlap, _ = _cross_partition_groups(
        records,
        split_by_id,
        field="source_prototype_family",
    )
    formula_overlap, formula_parent_count = _cross_partition_groups(
        records,
        split_by_id,
        field="reduced_formula_key",
    )
    anonymous_overlap = sum(
        split_by_id[edge.left_material_id] != split_by_id[edge.right_material_id]
        for edge in edges
    )
    return SplitAuditReport(
        split_name="composition_ood" if require_formula_disjoint else "structure_ood",
        require_formula_disjoint=require_formula_disjoint,
        parent_count=len(records),
        train_fit_count=sum(item.split == "train_fit" for item in assignments),
        validation_count=sum(item.split == "validation" for item in assignments),
        duplicate_material_id_count=duplicate_assignment_ids,
        cross_partition_structure_hash_count=structure_overlap,
        cross_partition_prototype_family_count=family_overlap,
        cross_partition_anonymous_near_duplicate_count=anonymous_overlap,
        cross_partition_reduced_formula_count=formula_overlap,
        cross_partition_reduced_formula_parent_count=formula_parent_count,
    )
