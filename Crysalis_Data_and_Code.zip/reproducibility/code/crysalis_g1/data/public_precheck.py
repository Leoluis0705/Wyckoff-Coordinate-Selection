from __future__ import annotations

import hashlib
import itertools
import json
import math
import os
import re
import time
import warnings
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

import numpy as np
import torch
from pymatgen.core import Element, Lattice
from pymatgen.util.coord import pbc_shortest_vectors

from crysalis_assembly.experiments.model_data import CompletionRecord
from crysalis_assembly.serialization import canonical_payload_json


class PublicCacheError(ValueError):
    pass


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _payload_hash(payload: object) -> str:
    return hashlib.sha256(canonical_payload_json(payload).encode()).hexdigest()


def _write_json(path: Path, payload: object) -> None:
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
        + "\n",
        encoding="utf-8",
    )


def _write_jsonl(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(canonical_payload_json(row) + "\n")


@dataclass(frozen=True)
class L2Config:
    public_cache_path: str
    expected_public_cache_sha256: str
    output_root: str
    seed: int
    min_sites: int
    max_sites: int
    min_elements: int
    max_elements: int
    min_orbits: int
    paths_per_parent: int
    common_space_group_count: int
    min_accepted_parents: int
    max_accepted_parents: int
    alpha_values: tuple[float, float, float]
    max_neighbor_distance: float
    radius_fallback: float
    code_commit_sha: str

    def __post_init__(self) -> None:
        if not 1 <= self.min_sites <= self.max_sites <= 20:
            raise ValueError("invalid site-count range")
        if not 1 <= self.min_elements <= self.max_elements:
            raise ValueError("invalid element-count range")
        if self.min_orbits < 1 or self.paths_per_parent != 4:
            raise ValueError("L2 requires four paths and at least one orbit")
        if not 3 <= self.common_space_group_count <= 8:
            raise ValueError("common_space_group_count must be from 3 to 8")
        if not 1 <= self.min_accepted_parents <= self.max_accepted_parents:
            raise ValueError("invalid accepted-parent range")
        if tuple(sorted(self.alpha_values)) != self.alpha_values:
            raise ValueError("alpha values must be sorted")
        if any(value <= 0 for value in self.alpha_values):
            raise ValueError("alpha values must be positive")
        if self.max_neighbor_distance <= 0 or self.radius_fallback <= 0:
            raise ValueError("neighbor parameters must be positive")
        if len(self.expected_public_cache_sha256) != 64:
            raise ValueError("expected public cache SHA-256 must have length 64")
        if self.code_commit_sha != "AUTO" and not re.fullmatch(
            r"[0-9a-f]{40}", self.code_commit_sha
        ):
            raise ValueError("code commit SHA must be AUTO or a 40-character SHA")

    @classmethod
    def from_json(cls, path: str | Path) -> L2Config:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        payload["alpha_values"] = tuple(float(value) for value in payload["alpha_values"])
        return cls(**payload)

    def resolved_code_commit_sha(self) -> str:
        value = (
            os.environ.get("CRYSALIS_G1_CODE_SHA", "")
            if self.code_commit_sha == "AUTO"
            else self.code_commit_sha
        )
        if not re.fullmatch(r"[0-9a-f]{40}", value):
            raise PublicCacheError(
                "CRYSALIS_G1_CODE_SHA must contain the frozen 40-character commit SHA"
            )
        return value

    def effective_payload(self) -> dict[str, object]:
        payload = asdict(self)
        payload["code_commit_sha"] = self.resolved_code_commit_sha()
        return payload

    def sha256(self) -> str:
        return _payload_hash(self.effective_payload())


@dataclass(frozen=True)
class ParentCrystal:
    material_id: str
    prototype_family: str
    partition: str
    lattice: tuple[tuple[float, float, float], ...]
    atomic_numbers: tuple[int, ...]
    fractional_coordinates: tuple[tuple[float, float, float], ...]
    orbit_multiplicities: tuple[int, ...]
    wyckoff_indices: tuple[int, ...]
    space_group: int
    structure_hash: str
    reduced_formula_key: tuple[tuple[int, int], ...]

    @classmethod
    def from_completion_record(cls, record: CompletionRecord) -> ParentCrystal:
        partition = record.model_partition or record.split
        if partition not in {"train_fit", "validation"}:
            raise PublicCacheError(f"non-public partition in public cache: {partition}")
        counts = Counter(record.atomic_numbers)
        divisor = math.gcd(*counts.values())
        formula = tuple(sorted((number, count // divisor) for number, count in counts.items()))
        payload = {
            "lattice": record.lattice,
            "atomic_numbers": record.atomic_numbers,
            "fractional_coordinates": record.fractional_coordinates,
            "orbit_multiplicities": record.orbit_multiplicities,
            "wyckoff_indices": record.wyckoff_indices,
            "space_group": record.space_group,
        }
        return cls(
            material_id=record.material_id,
            prototype_family=record.prototype_family,
            partition=partition,
            lattice=record.lattice,
            atomic_numbers=record.atomic_numbers,
            fractional_coordinates=record.fractional_coordinates,
            orbit_multiplicities=record.orbit_multiplicities,
            wyckoff_indices=record.wyckoff_indices,
            space_group=record.space_group,
            structure_hash=_payload_hash(payload),
            reduced_formula_key=formula,
        )

    @property
    def site_count(self) -> int:
        return len(self.atomic_numbers)

    @property
    def orbit_groups(self) -> tuple[tuple[int, tuple[int, ...]], ...]:
        groups: dict[int, list[int]] = defaultdict(list)
        for site_index, orbit_index in enumerate(self.wyckoff_indices):
            groups[orbit_index].append(site_index)
        return tuple(
            (orbit_index, tuple(site_indices))
            for orbit_index, site_indices in sorted(groups.items())
        )


@dataclass(frozen=True)
class SemanticTrajectory:
    parent_structure_id: str
    path_index: int
    orbit_order: tuple[int, ...]
    sequence_hash: str
    deconstruction_state_hashes: tuple[str, ...]
    inverse_orbit_order: tuple[int, ...]
    final_visible_site_indices: tuple[int, ...]
    replay_hash: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def load_public_parents(
    path: str | Path, *, expected_sha256: str
) -> tuple[ParentCrystal, ...]:
    cache_path = Path(path)
    actual = _sha256(cache_path)
    if actual != expected_sha256.lower():
        raise PublicCacheError(
            f"public cache SHA-256 mismatch: expected {expected_sha256}, received {actual}"
        )
    payload = torch.load(cache_path, map_location="cpu", weights_only=False)
    if not isinstance(payload, dict) or payload.get("schema_version") != "2.0.0":
        raise PublicCacheError("unsupported public cache schema")
    if payload.get("sealed_manifest_accessed") is not False:
        raise PublicCacheError("public cache indicates sealed access")
    ledgers = payload.get("ledgers")
    if not isinstance(ledgers, dict) or "P-S-multi" not in ledgers:
        raise PublicCacheError("P-S-multi public ledger missing")
    by_id: dict[str, ParentCrystal] = {}
    for record in ledgers["P-S-multi"]:
        if not isinstance(record, CompletionRecord):
            raise PublicCacheError("unexpected public ledger record type")
        parent = ParentCrystal.from_completion_record(record)
        previous = by_id.setdefault(parent.material_id, parent)
        if previous.structure_hash != parent.structure_hash:
            raise PublicCacheError(f"inconsistent duplicate parent {parent.material_id}")
    return tuple(by_id[key] for key in sorted(by_id))


def _path_candidates(parent: ParentCrystal, seed: int) -> list[tuple[int, ...]]:
    base = tuple(orbit_index for orbit_index, _ in parent.orbit_groups)
    candidates = [base, tuple(reversed(base))]
    candidates.extend(base[offset:] + base[:offset] for offset in range(1, len(base)))
    candidates.append(
        tuple(
            sorted(
                base,
                key=lambda orbit: (
                    hashlib.sha256(
                        f"g1-l2:{seed}:{parent.material_id}:{orbit}".encode()
                    ).hexdigest(),
                    orbit,
                ),
            )
        )
    )
    if len(base) <= 8:
        candidates.extend(itertools.permutations(base))
    unique: list[tuple[int, ...]] = []
    for candidate in candidates:
        if candidate not in unique:
            unique.append(candidate)
        if len(unique) == 4:
            return unique
    return unique


def _visible_hash(parent: ParentCrystal, visible: set[int]) -> str:
    payload = {
        "parent_structure_hash": parent.structure_hash,
        "visible_site_indices": tuple(sorted(visible)),
    }
    return _payload_hash(payload)


def build_four_orbit_paths(
    parent: ParentCrystal, *, seed: int
) -> tuple[SemanticTrajectory, ...]:
    groups = dict(parent.orbit_groups)
    orders = _path_candidates(parent, seed)
    if len(orders) < 4:
        raise ValueError("REJECTED_INSUFFICIENT_LEGAL_PATHS")
    all_sites = set(range(parent.site_count))
    trajectories = []
    for path_index, order in enumerate(orders[:4]):
        visible = set(all_sites)
        state_hashes = [_visible_hash(parent, visible)]
        for orbit_index in order:
            visible.difference_update(groups[orbit_index])
            state_hashes.append(_visible_hash(parent, visible))
        final_visible = tuple(sorted(visible))
        for orbit_index in reversed(order):
            visible.update(groups[orbit_index])
        replay_hash = parent.structure_hash if visible == all_sites else "REPLAY_FAILED"
        sequence_hash = _payload_hash(
            {
                "parent": parent.structure_hash,
                "operators": tuple(("D_orbit", orbit) for orbit in order),
            }
        )
        trajectories.append(
            SemanticTrajectory(
                parent.material_id,
                path_index,
                order,
                sequence_hash,
                tuple(state_hashes),
                tuple(reversed(order)),
                final_visible,
                replay_hash,
            )
        )
    if len({item.sequence_hash for item in trajectories}) != 4:
        raise AssertionError("trajectory sequence hashes are not unique")
    return tuple(trajectories)


def audit_public_partitions(parents: tuple[ParentCrystal, ...]) -> dict[str, object]:
    family_partitions: dict[str, set[str]] = defaultdict(set)
    hash_partitions: dict[str, set[str]] = defaultdict(set)
    material_partitions: dict[str, set[str]] = defaultdict(set)
    formula_partitions: dict[tuple[tuple[int, int], ...], set[str]] = defaultdict(set)
    for parent in parents:
        family_partitions[parent.prototype_family].add(parent.partition)
        hash_partitions[parent.structure_hash].add(parent.partition)
        material_partitions[parent.material_id].add(parent.partition)
        formula_partitions[parent.reduced_formula_key].add(parent.partition)
    family_overlap = sorted(key for key, values in family_partitions.items() if len(values) > 1)
    structure_overlap = sorted(key for key, values in hash_partitions.items() if len(values) > 1)
    material_overlap = sorted(key for key, values in material_partitions.items() if len(values) > 1)
    formula_overlap = sorted(key for key, values in formula_partitions.items() if len(values) > 1)
    passed = not family_overlap and not structure_overlap and not material_overlap
    return {
        "pass": passed,
        "cross_partition_family_count": len(family_overlap),
        "cross_partition_structure_hash_count": len(structure_overlap),
        "cross_partition_material_id_count": len(material_overlap),
        "cross_partition_reduced_formula_count_descriptive": len(formula_overlap),
        "near_duplicate_provenance": "INHERITED_FROM_HASH_LOCKED_GATE1B_V2_PUBLIC_MANIFEST",
        "anonymous_structure_matcher_status": "NOT_RERUN_IN_L2",
    }


@lru_cache(maxsize=256)
def _radius(atomic_number: int, fallback: float) -> float:
    element = Element.from_Z(atomic_number)
    if element.atomic_radius is not None and float(element.atomic_radius) > 0:
        return float(element.atomic_radius)
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="No data available.*")
        calculated = element.atomic_radius_calculated
    if calculated is not None and float(calculated) > 0:
        return float(calculated)
    return fallback


def _neighbor_edge_sets(
    parent: ParentCrystal,
    *,
    alpha_values: tuple[float, float, float],
    max_distance: float,
    radius_fallback: float,
) -> tuple[set[tuple[int, int, int, int, int]], ...]:
    lattice = np.asarray(parent.lattice, dtype=float)
    pymatgen_lattice = Lattice(lattice)
    fractions = np.asarray(parent.fractional_coordinates, dtype=float)
    vectors, distance_squared = pbc_shortest_vectors(
        pymatgen_lattice, fractions, fractions, return_d2=True
    )
    inverse = np.linalg.inv(lattice)
    radii = np.asarray(
        [_radius(number, radius_fallback) for number in parent.atomic_numbers]
    )
    results = []
    for alpha in alpha_values:
        edges: set[tuple[int, int, int, int, int]] = set()
        for source in range(parent.site_count):
            for target in range(source + 1, parent.site_count):
                distance = float(math.sqrt(max(0.0, distance_squared[source, target])))
                threshold = min(
                    max_distance, alpha * (radii[source] + radii[target])
                )
                if distance > threshold + 1e-12:
                    continue
                raw = fractions[target] - fractions[source]
                shortest_fractional = vectors[source, target] @ inverse
                image_array = np.rint(shortest_fractional - raw).astype(int)
                edges.add(
                    (
                        source,
                        target,
                        int(image_array[0]),
                        int(image_array[1]),
                        int(image_array[2]),
                    )
                )
        results.append(edges)
    return tuple(results)


def _stability_certificates(
    parent: ParentCrystal, config: L2Config
) -> tuple[dict[str, int | bool], dict[str, int | bool]]:
    edge_sets = _neighbor_edge_sets(
        parent,
        alpha_values=config.alpha_values,
        max_distance=config.max_neighbor_distance,
        radius_fallback=config.radius_fallback,
    )
    edge_counts = Counter(edge for edges in edge_sets for edge in edges)
    stable_edges = {edge for edge, count in edge_counts.items() if count >= 2}
    coordination: Counter[int] = Counter()
    for source, target, *_ in stable_edges:
        coordination[source] += 1
        coordination[target] += 1
    tetrahedra = sum(value == 4 for value in coordination.values())
    octahedra = sum(value == 6 for value in coordination.values())

    orbit_species: dict[int, set[int]] = defaultdict(set)
    for orbit_index, atomic_number in zip(
        parent.wyckoff_indices, parent.atomic_numbers, strict=True
    ):
        orbit_species[orbit_index].add(atomic_number)
    element_orbits: dict[int, set[int]] = defaultdict(set)
    for orbit_index, species in orbit_species.items():
        if len(species) == 1:
            element_orbits[next(iter(species))].add(orbit_index)
    sublattices = sum(
        0 < len(orbits) < len(parent.orbit_groups) for orbits in element_orbits.values()
    )
    return (
        {
            "has_stable_motif": bool(tetrahedra or octahedra),
            "stable_edge_count": len(stable_edges),
            "tetrahedron_center_count": tetrahedra,
            "octahedron_center_count": octahedra,
        },
        {
            "has_stable_sublattice": bool(sublattices),
            "stable_sublattice_count": sublattices,
        },
    )


def run_l2_precheck(config: L2Config) -> dict[str, Any]:
    started = time.perf_counter()
    code_commit_sha = config.resolved_code_commit_sha()
    output_root = Path(config.output_root)
    if output_root.exists() and any(output_root.iterdir()):
        raise PublicCacheError(f"L2 output directory is not empty: {output_root}")
    output_root.mkdir(parents=True, exist_ok=True)
    trajectory_dir = output_root / "trajectory_cache"
    trajectory_dir.mkdir()
    parents = load_public_parents(
        config.public_cache_path,
        expected_sha256=config.expected_public_cache_sha256,
    )
    rejections: Counter[str] = Counter()
    structurally_eligible = []
    oxide_eligible = 0
    for parent in parents:
        element_count = len(set(parent.atomic_numbers))
        if not config.min_sites <= parent.site_count <= config.max_sites:
            rejections["SITE_COUNT_OUT_OF_RANGE"] += 1
            continue
        if not config.min_elements <= element_count <= config.max_elements:
            rejections["ELEMENT_COUNT_OUT_OF_RANGE"] += 1
            continue
        if len(parent.orbit_groups) < config.min_orbits:
            rejections["INSUFFICIENT_ORBITS_FOR_FOUR_PATHS"] += 1
            continue
        structurally_eligible.append(parent)
        if 8 in parent.atomic_numbers:
            oxide_eligible += 1
    sg_counts = Counter(parent.space_group for parent in structurally_eligible)
    common_space_groups = tuple(
        space_group
        for space_group, _ in sorted(
            sg_counts.items(), key=lambda item: (-item[1], item[0])
        )[: config.common_space_group_count]
    )
    domain_candidates = [
        parent
        for parent in structurally_eligible
        if parent.space_group in common_space_groups
    ]
    domain_candidates.sort(
        key=lambda parent: (
            hashlib.sha256(
                f"g1-l2-select:{config.seed}:{parent.material_id}".encode()
            ).hexdigest(),
            parent.material_id,
        )
    )
    if len(domain_candidates) > config.max_accepted_parents:
        for _ in domain_candidates[config.max_accepted_parents :]:
            rejections["DETERMINISTIC_MAX_PARENT_CAP"] += 1
        domain_candidates = domain_candidates[: config.max_accepted_parents]

    accepted: list[ParentCrystal] = []
    trajectories: list[SemanticTrajectory] = []
    motif_counts: Counter[str] = Counter()
    sublattice_counts: Counter[str] = Counter()
    for index, parent in enumerate(domain_candidates, start=1):
        try:
            parent_trajectories = build_four_orbit_paths(parent, seed=config.seed)
        except ValueError as exc:
            rejections[str(exc)] += 1
            continue
        if any(item.replay_hash != parent.structure_hash for item in parent_trajectories):
            rejections["TRAJECTORY_REPLAY_MISMATCH"] += 1
            continue
        motif, sublattice = _stability_certificates(parent, config)
        motif_counts["parents_with_stable_motif"] += int(motif["has_stable_motif"])
        motif_counts["stable_edges"] += int(motif["stable_edge_count"])
        motif_counts["tetrahedron_centers"] += int(motif["tetrahedron_center_count"])
        motif_counts["octahedron_centers"] += int(motif["octahedron_center_count"])
        sublattice_counts["parents_with_stable_sublattice"] += int(
            sublattice["has_stable_sublattice"]
        )
        sublattice_counts["stable_sublattices"] += int(
            sublattice["stable_sublattice_count"]
        )
        accepted.append(parent)
        trajectories.extend(parent_trajectories)
        if index % 250 == 0:
            print(
                canonical_payload_json(
                    {
                        "stage": "l2_public_precheck",
                        "processed": index,
                        "candidate_total": len(domain_candidates),
                        "accepted": len(accepted),
                        "trajectories": len(trajectories),
                    }
                ),
                flush=True,
            )

    accepted_tuple = tuple(accepted)
    leakage = audit_public_partitions(accepted_tuple)
    accepted_hash_by_id = {
        parent.material_id: parent.structure_hash for parent in accepted
    }
    exact_replay_count = sum(
        trajectory.replay_hash
        == accepted_hash_by_id[trajectory.parent_structure_id]
        for trajectory in trajectories
    )
    trajectory_count = len(trajectories)
    passed = (
        len(accepted) >= config.min_accepted_parents
        and trajectory_count == len(accepted) * config.paths_per_parent
        and exact_replay_count == trajectory_count
        and leakage["pass"] is True
    )
    public_manifest_rows = [
        {
            "parent_structure_id": parent.material_id,
            "prototype_family": parent.prototype_family,
            "partition": parent.partition,
            "structure_hash": parent.structure_hash,
            "reduced_formula_key": parent.reduced_formula_key,
            "site_count": parent.site_count,
            "orbit_count": len(parent.orbit_groups),
            "space_group": parent.space_group,
            "domain": "ordered_2to4_general_inorganic",
        }
        for parent in accepted
    ]
    trajectory_rows = [trajectory.to_dict() for trajectory in trajectories]
    public_manifest_path = output_root / "generation_split_public_manifest.jsonl"
    trajectory_path = trajectory_dir / "trajectories.jsonl"
    _write_jsonl(public_manifest_path, public_manifest_rows)
    _write_jsonl(trajectory_path, trajectory_rows)

    canonicalization_summary = {
        "status": "INHERITED_AND_REVALIDATED_FROM_HASH_LOCKED_PUBLIC_CACHE",
        "source_parent_count": len(parents),
        "structurally_eligible_count": len(structurally_eligible),
        "oxide_eligible_count": oxide_eligible,
        "oxide_domain_minimum_met": oxide_eligible >= config.min_accepted_parents,
        "selected_domain": "ordered_2to4_general_inorganic",
        "common_space_groups": common_space_groups,
        "domain_candidate_count": len(domain_candidates),
        "public_cache_sha256": config.expected_public_cache_sha256,
        "sealed_or_blind_accessed": False,
    }
    _write_json(output_root / "canonicalization_summary.json", canonicalization_summary)
    _write_json(
        output_root / "motif_stability_summary.json",
        {
            **dict(motif_counts),
            "alpha_values": config.alpha_values,
            "max_neighbor_distance": config.max_neighbor_distance,
            "acceptance_required_for_parent": False,
        },
    )
    _write_json(
        output_root / "sublattice_stability_summary.json",
        {**dict(sublattice_counts), "acceptance_required_for_parent": False},
    )
    trajectory_summary = {
        "accepted_parent_count": len(accepted),
        "trajectory_count": trajectory_count,
        "paths_per_parent": config.paths_per_parent,
        "exact_replay_count": exact_replay_count,
        "rejection_counts": dict(sorted(rejections.items())),
        "no_refill": True,
    }
    _write_json(output_root / "trajectory_acceptance_summary.json", trajectory_summary)
    _write_json(output_root / "leakage_audit.json", leakage)
    trajectory_manifest = {
        "schema_version": "g1-l2.0.0",
        "trajectory_cache_sha256": _sha256(trajectory_path),
        "trajectory_count": trajectory_count,
        "parent_count": len(accepted),
        "public_manifest_sha256": _sha256(public_manifest_path),
        "source_public_cache_sha256": config.expected_public_cache_sha256,
        "config_sha256": config.sha256(),
        "code_commit_sha": code_commit_sha,
        "seed": config.seed,
        "sealed_or_blind_accessed": False,
    }
    _write_json(output_root / "trajectory_cache_manifest.json", trajectory_manifest)
    wall_seconds = time.perf_counter() - started
    summary: dict[str, Any] = {
        "status": "PASS" if passed else "STOPPED",
        "accepted_parent_count": len(accepted),
        "trajectory_count": trajectory_count,
        "exact_replay_count": exact_replay_count,
        "minimum_parent_requirement": config.min_accepted_parents,
        "maximum_parent_cap": config.max_accepted_parents,
        "leakage_audit_pass": leakage["pass"],
        "sealed_or_blind_accessed": False,
        "formal_training_started": False,
        "wall_seconds": wall_seconds,
        "config_sha256": config.sha256(),
        "code_commit_sha": code_commit_sha,
        "trajectory_cache_sha256": trajectory_manifest["trajectory_cache_sha256"],
        "public_manifest_sha256": trajectory_manifest["public_manifest_sha256"],
        "next_stage_authorized_if_pass": True,
    }
    _write_json(output_root / "l2_exit.json", summary)
    print(canonical_payload_json(summary), flush=True)
    return summary
