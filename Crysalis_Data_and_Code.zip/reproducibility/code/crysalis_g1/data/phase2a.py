from __future__ import annotations

import hashlib
import json
import math
import os
import platform
import re
import time
from collections import Counter
from collections.abc import Iterable
from dataclasses import asdict, dataclass
from importlib.metadata import version as distribution_version
from pathlib import Path
from typing import Any

from crysalis_assembly.serialization import canonical_payload_json

from .canonical import (
    CanonicalParentRecord,
    CanonicalizationError,
    SymmetrySignature,
    canonicalize_parent,
)
from .public_precheck import PublicCacheError, load_public_parents
from .split_audit import (
    SplitAssignment,
    audit_split,
    build_composition_ood_split,
    build_structure_ood_split,
    enumerate_anonymous_matches,
)
from .structural_operators import (
    OperatorReplayError,
    StructuralTrajectory,
    build_d_orbit_trajectories,
    build_d_relation_trajectory,
    build_relation_registry,
    replay_trajectory,
)


PHASE2A_SCHEMA_VERSION = "g1-phase2a-cache.1.1.0"


class Phase2AError(ValueError):
    pass


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _payload_hash(payload: object) -> str:
    return hashlib.sha256(canonical_payload_json(payload).encode("utf-8")).hexdigest()


def _dependency_versions() -> dict[str, str]:
    return {
        "python": platform.python_version(),
        "pymatgen": distribution_version("pymatgen"),
        "spglib": distribution_version("spglib"),
        "torch": distribution_version("torch"),
    }


def _write_json(path: Path, payload: object) -> None:
    path.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n",
        encoding="utf-8",
    )


def _write_jsonl(path: Path, rows: Iterable[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(canonical_payload_json(row) + "\n")


@dataclass(frozen=True, slots=True)
class Phase2AConfig:
    public_cache_path: str
    expected_public_cache_sha256: str
    output_root: str
    code_commit_sha: str
    selection_seed: int
    selection_namespace: str
    min_sites: int
    max_sites: int
    min_elements: int
    max_elements: int
    min_orbits: int
    paths_per_parent: int
    common_space_group_count: int
    max_selected_parents: int
    symprec_values: tuple[float, float, float]
    angle_tolerance: float
    alpha_values: tuple[float, float, float]
    max_neighbor_distance: float
    radius_fallback: float
    composition_validation_fraction: float
    phase_2a_data_implementation_authorized: bool
    phase_2b_model_implementation_authorized: bool
    server_deployment_authorized: bool
    formal_training_started: bool
    three_seed_authorized: bool
    no_refill: bool
    canonical_ambiguity_policy: str = "FAIL"
    excluded_parent_id: str = ""
    exclusion_reason: str = ""
    exclude_from_canonical_cache: bool = False
    exclude_from_trajectory_build: bool = False
    retain_failure_record: bool = False
    phase2a_corrected_rerun_authorized: bool = False

    def __post_init__(self) -> None:
        if len(self.expected_public_cache_sha256) != 64:
            raise ValueError("expected public cache SHA-256 must have length 64")
        if self.code_commit_sha != "AUTO" and not re.fullmatch(
            r"[0-9a-f]{40}", self.code_commit_sha
        ):
            raise ValueError("code commit SHA must be AUTO or a 40-character SHA")
        if self.selection_namespace != "g1-revised-pilot:20260823":
            raise ValueError("selection namespace differs from the audited Phase 2A value")
        if not 1 <= self.min_sites <= self.max_sites <= 20:
            raise ValueError("invalid site-count range")
        if not 1 <= self.min_elements <= self.max_elements:
            raise ValueError("invalid element-count range")
        if self.min_orbits < 3 or self.paths_per_parent != 4:
            raise ValueError("Phase 2A requires at least three orbits and four paths")
        if not 1 <= self.common_space_group_count <= 8:
            raise ValueError("common_space_group_count must be from 1 to 8")
        if self.max_selected_parents <= 0:
            raise ValueError("max_selected_parents must be positive")
        if self.symprec_values != (0.03, 0.05, 0.1):
            raise ValueError("symprec_values must be exactly (0.03, 0.05, 0.1)")
        if tuple(sorted(self.alpha_values)) != self.alpha_values or any(
            value <= 0 for value in self.alpha_values
        ):
            raise ValueError("alpha_values must be sorted and positive")
        if (
            self.angle_tolerance <= 0
            or self.max_neighbor_distance <= 0
            or self.radius_fallback <= 0
        ):
            raise ValueError("geometry parameters must be positive")
        if not 0 < self.composition_validation_fraction < 1 or not math.isfinite(
            self.composition_validation_fraction
        ):
            raise ValueError("composition validation fraction must be in (0, 1)")
        if self.phase_2a_data_implementation_authorized is not True:
            raise ValueError("Phase 2A data implementation is not authorized")
        forbidden_flags = {
            "phase_2b_model_implementation_authorized": (
                self.phase_2b_model_implementation_authorized
            ),
            "server_deployment_authorized": self.server_deployment_authorized,
            "formal_training_started": self.formal_training_started,
            "three_seed_authorized": self.three_seed_authorized,
        }
        enabled = [name for name, value in forbidden_flags.items() if value]
        if enabled:
            raise ValueError(f"unauthorized Phase 2A flags enabled: {enabled}")
        if self.no_refill is not True:
            raise ValueError("Phase 2A requires no_refill=true")
        exclusion_values = (
            self.canonical_ambiguity_policy,
            self.excluded_parent_id,
            self.exclusion_reason,
            self.exclude_from_canonical_cache,
            self.exclude_from_trajectory_build,
            self.retain_failure_record,
        )
        if self.phase2a_corrected_rerun_authorized:
            expected = (
                "EXCLUDE_WITH_REASON",
                "mp-1173150",
                "SYMMETRY_TOLERANCE_AMBIGUITY",
                True,
                True,
                True,
            )
            if exclusion_values != expected:
                raise ValueError(
                    "corrected rerun exclusion policy differs from user authorization"
                )
        elif exclusion_values != ("FAIL", "", "", False, False, False):
            raise ValueError("canonical exclusion requires corrected rerun authorization")

    @classmethod
    def from_json(cls, path: str | Path) -> Phase2AConfig:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        payload["symprec_values"] = tuple(
            float(value) for value in payload["symprec_values"]
        )
        payload["alpha_values"] = tuple(
            float(value) for value in payload["alpha_values"]
        )
        return cls(**payload)

    def resolved_code_commit_sha(self) -> str:
        value = (
            os.environ.get("CRYSALIS_G1_CODE_SHA", "")
            if self.code_commit_sha == "AUTO"
            else self.code_commit_sha
        )
        if not re.fullmatch(r"[0-9a-f]{40}", value):
            raise Phase2AError(
                "CRYSALIS_G1_CODE_SHA must contain the frozen 40-character commit SHA"
            )
        return value

    def effective_payload(self) -> dict[str, object]:
        payload = asdict(self)
        payload["code_commit_sha"] = self.resolved_code_commit_sha()
        return payload

    def sha256(self) -> str:
        return _payload_hash(self.effective_payload())


def _distribution(values: list[int]) -> dict[str, float | int]:
    if not values:
        return {"count": 0, "min": 0, "p50": 0, "p95": 0, "max": 0, "mean": 0.0}
    ordered = sorted(values)

    def percentile(fraction: float) -> int:
        index = max(0, math.ceil(fraction * len(ordered)) - 1)
        return ordered[index]

    return {
        "count": len(ordered),
        "min": ordered[0],
        "p50": percentile(0.50),
        "p95": percentile(0.95),
        "max": ordered[-1],
        "mean": sum(ordered) / len(ordered),
    }


def _orbit_memberships(
    observation: SymmetrySignature,
) -> tuple[tuple[int, ...], ...]:
    groups: dict[int, list[int]] = {}
    for site_index, group_id in enumerate(observation.equivalent_atoms):
        groups.setdefault(group_id, []).append(site_index)
    return tuple(sorted(tuple(indices) for indices in groups.values()))


def _wyckoff_signature(
    observation: SymmetrySignature,
) -> tuple[tuple[str, tuple[int, ...]], ...]:
    return tuple(
        sorted(
            (
                observation.wyckoff_letters[membership[0]],
                membership,
            )
            for membership in _orbit_memberships(observation)
        )
    )


def _symmetry_observation_payload(
    observation: SymmetrySignature,
) -> dict[str, object]:
    return {
        **observation.to_dict(),
        "orbit_memberships": _orbit_memberships(observation),
        "wyckoff_signature": _wyckoff_signature(observation),
    }


def _symmetry_pairwise_differences(
    observations: tuple[SymmetrySignature, ...],
) -> tuple[dict[str, object], ...]:
    differences = []
    for left_index, left in enumerate(observations):
        for right in observations[left_index + 1 :]:
            differences.append(
                {
                    "left_symprec": left.symprec,
                    "right_symprec": right.symprec,
                    "space_group_equal": left.space_group == right.space_group,
                    "orbit_membership_equal": (
                        _orbit_memberships(left) == _orbit_memberships(right)
                    ),
                    "wyckoff_signature_equal": (
                        _wyckoff_signature(left) == _wyckoff_signature(right)
                    ),
                }
            )
    return tuple(differences)


def _is_authorized_ambiguity_exclusion(
    config: Phase2AConfig,
    *,
    material_id: str,
    error: CanonicalizationError,
) -> bool:
    return (
        config.phase2a_corrected_rerun_authorized
        and material_id == config.excluded_parent_id
        and error.reason_code == "AMBIGUOUS_SYMMETRY"
        and len(error.observations) == 3
    )


def _canonical_failure_record(
    *,
    config: Phase2AConfig,
    parent: object,
    error: CanonicalizationError,
) -> dict[str, object]:
    material_id = str(getattr(parent, "material_id"))
    source_structure_hash = str(getattr(parent, "structure_hash"))
    if _is_authorized_ambiguity_exclusion(
        config,
        material_id=material_id,
        error=error,
    ):
        observations = tuple(error.observations)
        return {
            "stage": "canonicalization",
            "status": "EXCLUDED",
            "material_id": material_id,
            "original_structure_hash": source_structure_hash,
            "reason_code": config.exclusion_reason,
            "detail": error.detail,
            "canonical_ambiguity_policy": config.canonical_ambiguity_policy,
            "excluded_from_canonical_cache": config.exclude_from_canonical_cache,
            "excluded_from_trajectory_build": config.exclude_from_trajectory_build,
            "no_refill": config.no_refill,
            "symmetry_observations": tuple(
                _symmetry_observation_payload(observation)
                for observation in observations
            ),
            "pairwise_signature_differences": _symmetry_pairwise_differences(
                observations
            ),
        }
    record: dict[str, object] = {
        "stage": "canonicalization",
        "status": "FAIL",
        "material_id": material_id,
        "original_structure_hash": source_structure_hash,
        "reason_code": error.reason_code,
        "detail": error.detail,
    }
    if error.observations:
        record["symmetry_observations"] = tuple(
            _symmetry_observation_payload(observation)
            for observation in error.observations
        )
    return record


def _selection(
    records: tuple[CanonicalParentRecord, ...],
    config: Phase2AConfig,
) -> tuple[tuple[CanonicalParentRecord, ...], dict[str, object]]:
    rejections: Counter[str] = Counter()
    eligible = []
    for record in records:
        if not config.min_sites <= record.site_count <= config.max_sites:
            rejections["SITE_COUNT_OUT_OF_RANGE"] += 1
            continue
        if not config.min_elements <= record.element_count <= config.max_elements:
            rejections["ELEMENT_COUNT_OUT_OF_RANGE"] += 1
            continue
        if len(record.orbits) < config.min_orbits:
            rejections["INSUFFICIENT_CANONICAL_ORBITS"] += 1
            continue
        eligible.append(record)
    space_group_counts = Counter(record.space_group for record in eligible)
    common_space_groups = tuple(
        space_group
        for space_group, _ in sorted(
            space_group_counts.items(),
            key=lambda item: (-item[1], item[0]),
        )[: config.common_space_group_count]
    )
    candidates = [
        record for record in eligible if record.space_group in common_space_groups
    ]
    candidates.sort(
        key=lambda record: (
            hashlib.sha256(
                f"{config.selection_namespace}:{record.material_id}".encode("utf-8")
            ).hexdigest(),
            record.material_id,
        )
    )
    if len(candidates) > config.max_selected_parents:
        rejections["DETERMINISTIC_MAX_PARENT_CAP"] += (
            len(candidates) - config.max_selected_parents
        )
        candidates = candidates[: config.max_selected_parents]
    selected = tuple(candidates)
    return selected, {
        "structurally_eligible_count": len(eligible),
        "selected_parent_count": len(selected),
        "common_space_groups": common_space_groups,
        "common_space_group_counts": {
            str(space_group): space_group_counts[space_group]
            for space_group in common_space_groups
        },
        "rejection_counts": dict(sorted(rejections.items())),
        "no_refill": True,
    }


def _split_rows(
    records: tuple[CanonicalParentRecord, ...],
    assignments: tuple[SplitAssignment, ...],
) -> Iterable[dict[str, object]]:
    by_id = {record.material_id: record for record in records}
    for assignment in assignments:
        record = by_id[assignment.material_id]
        yield {
            **assignment.to_dict(),
            "canonical_structure_hash": record.canonical_structure_hash,
            "source_prototype_family": record.source_prototype_family,
            "reduced_formula_key": record.reduced_formula_key,
            "space_group": record.space_group,
            "site_count": record.site_count,
            "orbit_count": len(record.orbits),
        }


def _markdown_results(
    *,
    canonical_report: dict[str, object],
    leakage_report: dict[str, object],
    coverage_report: dict[str, object],
    replay_report: dict[str, object],
    summary: dict[str, object],
) -> str:
    structure_ood = leakage_report["structure_ood"]
    composition_ood = leakage_report["composition_ood"]
    operators = coverage_report["operators"]
    return "\n".join(
        (
            "# Crysalis-G1 Phase 2A Results",
            "",
            f"- status: {summary['status']}",
            f"- source parents: {summary['source_parent_count']}",
            f"- canonical parents: {canonical_report['canonical_parent_count']}",
            (
                "- authorized canonical exclusions: "
                f"{canonical_report['authorized_exclusion_count']}"
            ),
            (
                "- canonical ambiguity policy: "
                f"{summary['canonical_ambiguity_policy']}"
            ),
            f"- selected parents: {summary['selected_parent_count']}",
            f"- canonical cache SHA-256: {summary['canonical_cache_sha256']}",
            f"- Structure-OOD pass: {structure_ood['passes']}",
            (
                "- Structure-OOD reduced-formula overlap groups "
                f"(descriptive): {structure_ood['cross_partition_reduced_formula_count']}"
            ),
            f"- Composition-OOD pass: {composition_ood['passes']}",
            f"- D_orbit trajectories: {operators['D_orbit']['trajectory_count']}",
            (
                "- D_relation_interface trajectories: "
                f"{operators['D_relation_interface']['trajectory_count']}"
            ),
            f"- replay: {replay_report['successful_replay_count']}/{replay_report['trajectory_count']}",
            (
                "- forward replay: "
                f"{replay_report['forward_replay_count']}/{replay_report['trajectory_count']}"
            ),
            (
                "- inverse replay: "
                f"{replay_report['inverse_replay_count']}/{replay_report['trajectory_count']}"
            ),
            (
                "- serialization replay: "
                f"{replay_report['serialization_replay_count']}/{replay_report['trajectory_count']}"
            ),
            (
                "- periodic-image replay: "
                f"{replay_report['periodic_image_replay_count']}/{replay_report['trajectory_count']}"
            ),
            (
                "- skew-lattice translation replay: "
                f"{replay_report['skew_lattice_translation_replay_count']}/{replay_report['trajectory_count']}"
            ),
            "- D_motif formal coverage: NOT_MEASURED",
            "- D_sublattice formal coverage: NOT_MEASURED",
            "- D_distortion formal coverage: NOT_MEASURED",
            "- phase_2b_model_implementation_authorized: false",
            "- server_deployment_authorized: false",
            "- formal_training_started: false",
            "- three_seed_authorized: false",
            "",
        )
    )


def run_phase2a(config: Phase2AConfig) -> dict[str, Any]:
    started = time.perf_counter()
    code_commit_sha = config.resolved_code_commit_sha()
    output_root = Path(config.output_root)
    if output_root.exists() and any(output_root.iterdir()):
        raise Phase2AError(f"Phase 2A output directory is not empty: {output_root}")
    parents = load_public_parents(
        config.public_cache_path,
        expected_sha256=config.expected_public_cache_sha256,
    )
    output_root.mkdir(parents=True, exist_ok=True)
    canonical_dir = output_root / "canonical_cache"
    split_dir = output_root / "splits"
    trajectory_dir = output_root / "trajectories"
    report_dir = output_root / "reports"
    for directory in (canonical_dir, split_dir, trajectory_dir, report_dir):
        directory.mkdir()

    failures: list[dict[str, object]] = []
    canonical_records = []
    for index, parent in enumerate(parents, start=1):
        try:
            canonical_records.append(
                canonicalize_parent(
                    parent,
                    symprec_values=config.symprec_values,
                    angle_tolerance=config.angle_tolerance,
                )
            )
        except CanonicalizationError as exc:
            failures.append(
                _canonical_failure_record(
                    config=config,
                    parent=parent,
                    error=exc,
                )
            )
        if index % 500 == 0:
            print(
                canonical_payload_json(
                    {
                        "stage": "phase2a_canonicalization",
                        "processed": index,
                        "source_total": len(parents),
                        "accepted": len(canonical_records),
                        "failed": len(failures),
                    }
                ),
                flush=True,
            )
    canonical_tuple = tuple(
        sorted(canonical_records, key=lambda record: record.material_id)
    )
    canonical_path = canonical_dir / "canonical_parents.jsonl"
    _write_jsonl(canonical_path, (record.to_dict() for record in canonical_tuple))

    selected, selection_report = _selection(canonical_tuple, config)
    if not selected:
        raise Phase2AError("Phase 2A selected cohort is empty")
    anonymous_enumeration = enumerate_anonymous_matches(
        selected,
        progress_interval=25_000,
        progress_callback=lambda processed, total, confirmed: print(
            canonical_payload_json(
                {
                    "stage": "phase2a_anonymous_matching",
                    "processed": processed,
                    "candidate_total": total,
                    "confirmed_edges": confirmed,
                }
            ),
            flush=True,
        ),
    )
    anonymous_edges = anonymous_enumeration.edges
    structure_assignments = build_structure_ood_split(selected, anonymous_edges)
    composition_assignments = build_composition_ood_split(
        selected,
        anonymous_edges,
        seed=config.selection_seed,
        validation_fraction=config.composition_validation_fraction,
    )
    structure_audit = audit_split(
        selected,
        structure_assignments,
        anonymous_edges,
        require_formula_disjoint=False,
    )
    composition_audit = audit_split(
        selected,
        composition_assignments,
        anonymous_edges,
        require_formula_disjoint=True,
    )
    _write_jsonl(
        split_dir / "structure_ood_manifest.jsonl",
        _split_rows(selected, structure_assignments),
    )
    _write_jsonl(
        split_dir / "composition_ood_manifest.jsonl",
        _split_rows(selected, composition_assignments),
    )

    relation_path = canonical_dir / "canonical_relations.jsonl"
    d_orbit_path = trajectory_dir / "d_orbit.jsonl"
    d_relation_path = trajectory_dir / "d_relation_interface.jsonl"
    d_orbit_count = 0
    d_relation_count = 0
    d_relation_parent_count = 0
    relation_count = 0
    relation_group_count = 0
    replay_count = 0
    forward_replay_count = 0
    inverse_replay_count = 0
    serialization_replay_count = 0
    periodic_image_replay_count = 0
    skew_lattice_translation_replay_count = 0
    periodic_image_relation_check_count = 0
    skew_lattice_translation_relation_check_count = 0
    replay_failures = 0
    with (
        relation_path.open("w", encoding="utf-8", newline="\n") as relation_handle,
        d_orbit_path.open("w", encoding="utf-8", newline="\n") as orbit_handle,
        d_relation_path.open("w", encoding="utf-8", newline="\n") as relation_trajectory_handle,
    ):
        for index, record in enumerate(selected, start=1):
            registry = build_relation_registry(
                record,
                alpha_values=config.alpha_values,
                max_distance=config.max_neighbor_distance,
                radius_fallback=config.radius_fallback,
            )
            relation_handle.write(canonical_payload_json(registry.to_dict()) + "\n")
            relation_count += len(registry.relations)
            relation_group_count += len(registry.interface_groups)
            try:
                orbit_trajectories = build_d_orbit_trajectories(
                    record,
                    registry,
                    seed=config.selection_seed,
                    paths_per_parent=config.paths_per_parent,
                )
                for trajectory in orbit_trajectories:
                    encoded = trajectory.to_json()
                    decoded = StructuralTrajectory.from_json(encoded)
                    result = replay_trajectory(record, registry, decoded)
                    serialization_replay_count += int(decoded == trajectory)
                    replay_count += int(result.passed)
                    forward_replay_count += int(result.forward_replay_passed)
                    inverse_replay_count += int(result.inverse_replay_passed)
                    periodic_image_replay_count += int(
                        result.periodic_image_replay_passed
                    )
                    skew_lattice_translation_replay_count += int(
                        result.skew_lattice_translation_replay_passed
                    )
                    periodic_image_relation_check_count += (
                        result.periodic_image_relation_count
                    )
                    skew_lattice_translation_relation_check_count += (
                        result.skew_lattice_translation_relation_count
                    )
                    orbit_handle.write(encoded + "\n")
                    d_orbit_count += 1
            except (OperatorReplayError, ValueError) as exc:
                replay_failures += 1
                failures.append(
                    {
                        "stage": "D_orbit",
                        "status": "FAIL",
                        "material_id": record.material_id,
                        "reason_code": type(exc).__name__,
                        "detail": str(exc),
                    }
                )
            try:
                relation_trajectory = build_d_relation_trajectory(record, registry)
                if relation_trajectory is None:
                    failures.append(
                        {
                            "stage": "D_relation_interface",
                            "status": "NOT_APPLICABLE",
                            "material_id": record.material_id,
                            "reason_code": "NO_RELATION_INTERFACE",
                        }
                    )
                else:
                    encoded = relation_trajectory.to_json()
                    decoded = StructuralTrajectory.from_json(encoded)
                    result = replay_trajectory(record, registry, decoded)
                    serialization_replay_count += int(decoded == relation_trajectory)
                    replay_count += int(result.passed)
                    forward_replay_count += int(result.forward_replay_passed)
                    inverse_replay_count += int(result.inverse_replay_passed)
                    periodic_image_replay_count += int(
                        result.periodic_image_replay_passed
                    )
                    skew_lattice_translation_replay_count += int(
                        result.skew_lattice_translation_replay_passed
                    )
                    periodic_image_relation_check_count += (
                        result.periodic_image_relation_count
                    )
                    skew_lattice_translation_relation_check_count += (
                        result.skew_lattice_translation_relation_count
                    )
                    relation_trajectory_handle.write(encoded + "\n")
                    d_relation_count += 1
                    d_relation_parent_count += 1
            except (OperatorReplayError, ValueError) as exc:
                replay_failures += 1
                failures.append(
                    {
                        "stage": "D_relation_interface",
                        "status": "FAIL",
                        "material_id": record.material_id,
                        "reason_code": type(exc).__name__,
                        "detail": str(exc),
                    }
                )
            if index % 250 == 0:
                print(
                    canonical_payload_json(
                        {
                            "stage": "phase2a_operator_cache",
                            "processed": index,
                            "selected_total": len(selected),
                            "d_orbit_trajectories": d_orbit_count,
                            "d_relation_trajectories": d_relation_count,
                        }
                    ),
                    flush=True,
                )

    total_trajectory_count = d_orbit_count + d_relation_count
    canonical_failures = [
        row
        for row in failures
        if row["stage"] == "canonicalization" and row["status"] == "FAIL"
    ]
    authorized_exclusions = [
        row
        for row in failures
        if row["stage"] == "canonicalization" and row["status"] == "EXCLUDED"
    ]
    canonical_report: dict[str, object] = {
        "schema_version": PHASE2A_SCHEMA_VERSION,
        "source_parent_count": len(parents),
        "canonical_parent_count": len(canonical_tuple),
        "canonical_failure_count": len(canonical_failures),
        "authorized_exclusion_count": len(authorized_exclusions),
        "authorized_excluded_parent_ids": tuple(
            str(row["material_id"]) for row in authorized_exclusions
        ),
        "canonical_ambiguity_policy": config.canonical_ambiguity_policy,
        "phase2a_corrected_rerun_authorized": (
            config.phase2a_corrected_rerun_authorized
        ),
        "symmetry_stable_count": sum(
            record.symmetry_status == "stable" for record in canonical_tuple
        ),
        "symmetry_majority_count": sum(
            record.symmetry_status == "majority" for record in canonical_tuple
        ),
        "source_space_group_mismatch_count": sum(
            record.source_space_group != record.space_group for record in canonical_tuple
        ),
        "site_count_distribution": _distribution(
            [record.site_count for record in selected]
        ),
        "orbit_count_distribution": _distribution(
            [len(record.orbits) for record in selected]
        ),
        **selection_report,
        "sealed_or_blind_data_accessed": False,
        "no_refill": True,
    }
    leakage_report: dict[str, object] = {
        "schema_version": PHASE2A_SCHEMA_VERSION,
        "anonymous_match_edge_count": len(anonymous_edges),
        "anonymous_match_edges": [edge.to_dict() for edge in anonymous_edges],
        "anonymous_match_enumeration": anonymous_enumeration.to_dict(
            include_edges=False
        ),
        "structure_ood": structure_audit.to_dict(),
        "composition_ood": composition_audit.to_dict(),
        "reduced_formula_overlap_is_automatic_leakage": False,
    }
    coverage_report: dict[str, object] = {
        "schema_version": PHASE2A_SCHEMA_VERSION,
        "selected_parent_count": len(selected),
        "relation_count": relation_count,
        "relation_interface_group_count": relation_group_count,
        "operators": {
            "D_orbit": {
                "status": "FORMAL",
                "eligible_parent_count": len(selected),
                "trajectory_count": d_orbit_count,
                "expected_trajectory_count": len(selected) * config.paths_per_parent,
                "roundtrip_replay_count": d_orbit_count,
            },
            "D_relation_interface": {
                "status": "FORMAL",
                "eligible_parent_count": d_relation_parent_count,
                "parent_coverage": d_relation_parent_count / len(selected),
                "trajectory_count": d_relation_count,
                "roundtrip_replay_count": d_relation_count,
            },
            "D_motif": {"status": "NOT_MEASURED"},
            "D_sublattice": {"status": "NOT_MEASURED"},
            "D_distortion": {"status": "NOT_MEASURED"},
        },
    }
    replay_status = (
        "PASS"
        if replay_count == total_trajectory_count
        and forward_replay_count == total_trajectory_count
        and inverse_replay_count == total_trajectory_count
        and serialization_replay_count == total_trajectory_count
        and periodic_image_replay_count == total_trajectory_count
        and skew_lattice_translation_replay_count == total_trajectory_count
        and replay_failures == 0
        else "FAIL"
    )
    replay_report: dict[str, object] = {
        "schema_version": PHASE2A_SCHEMA_VERSION,
        "status": replay_status,
        "trajectory_count": total_trajectory_count,
        "successful_replay_count": replay_count,
        "forward_replay_count": forward_replay_count,
        "inverse_replay_count": inverse_replay_count,
        "serialization_replay_count": serialization_replay_count,
        "periodic_image_replay_count": periodic_image_replay_count,
        "skew_lattice_translation_replay_count": (
            skew_lattice_translation_replay_count
        ),
        "periodic_image_relation_check_count": (
            periodic_image_relation_check_count
        ),
        "skew_lattice_translation_relation_check_count": (
            skew_lattice_translation_relation_check_count
        ),
        "replay_failure_count": replay_failures,
    }
    _write_json(report_dir / "canonical_cache_report.json", canonical_report)
    _write_json(report_dir / "leakage_report.json", leakage_report)
    _write_json(report_dir / "operator_coverage_report.json", coverage_report)
    _write_json(report_dir / "replay_report.json", replay_report)
    _write_jsonl(output_root / "failures.jsonl", failures)

    expected_exclusion_count = int(config.phase2a_corrected_rerun_authorized)
    passed = (
        len(canonical_tuple) + len(authorized_exclusions) == len(parents)
        and len(canonical_failures) == 0
        and len(authorized_exclusions) == expected_exclusion_count
        and structure_audit.passes
        and composition_audit.passes
        and d_orbit_count == len(selected) * config.paths_per_parent
        and d_relation_count > 0
        and replay_status == "PASS"
    )
    canonical_cache_sha = _sha256(canonical_path)
    summary: dict[str, Any] = {
        "schema_version": PHASE2A_SCHEMA_VERSION,
        "status": "PASS" if passed else "STOPPED",
        "source_parent_count": len(parents),
        "canonical_parent_count": len(canonical_tuple),
        "authorized_exclusion_count": len(authorized_exclusions),
        "authorized_excluded_parent_ids": tuple(
            str(row["material_id"]) for row in authorized_exclusions
        ),
        "canonical_ambiguity_policy": config.canonical_ambiguity_policy,
        "phase2a_corrected_rerun_authorized": (
            config.phase2a_corrected_rerun_authorized
        ),
        "selected_parent_count": len(selected),
        "canonical_cache_sha256": canonical_cache_sha,
        "structure_ood_pass": structure_audit.passes,
        "composition_ood_pass": composition_audit.passes,
        "d_orbit_trajectory_count": d_orbit_count,
        "d_relation_interface_trajectory_count": d_relation_count,
        "successful_replay_count": replay_count,
        "trajectory_count": total_trajectory_count,
        "phase_2a_data_implementation_authorized": True,
        "phase_2b_model_implementation_authorized": False,
        "server_deployment_authorized": False,
        "formal_training_started": False,
        "three_seed_authorized": False,
        "sealed_or_blind_data_accessed": False,
        "no_refill": True,
        "code_commit_sha": code_commit_sha,
        "config_sha256": config.sha256(),
        "wall_seconds": time.perf_counter() - started,
    }
    (report_dir / "PHASE2A_RESULTS.md").write_text(
        _markdown_results(
            canonical_report=canonical_report,
            leakage_report=leakage_report,
            coverage_report=coverage_report,
            replay_report=replay_report,
            summary=summary,
        ),
        encoding="utf-8",
        newline="\n",
    )
    report_files = sorted(
        path
        for path in output_root.rglob("*")
        if path.is_file()
        and path.name not in {"phase2a_manifest.json", "phase2a_exit.json"}
    )
    manifest: dict[str, object] = {
        "schema_version": PHASE2A_SCHEMA_VERSION,
        "source_public_cache_sha256": config.expected_public_cache_sha256,
        "code_commit_sha": code_commit_sha,
        "config_sha256": config.sha256(),
        "dependency_versions": _dependency_versions(),
        "failure_record_count": len(failures),
        "failure_status_counts": dict(
            sorted(Counter(str(row["status"]) for row in failures).items())
        ),
        "failure_reason_counts": dict(
            sorted(Counter(str(row["reason_code"]) for row in failures).items())
        ),
        "file_sha256": {
            path.relative_to(output_root).as_posix(): _sha256(path)
            for path in report_files
        },
        "sealed_or_blind_data_accessed": False,
        "formal_training_started": False,
        "no_refill": True,
    }
    _write_json(output_root / "phase2a_manifest.json", manifest)
    summary["phase2a_manifest_sha256"] = _sha256(
        output_root / "phase2a_manifest.json"
    )
    _write_json(output_root / "phase2a_exit.json", summary)
    print(canonical_payload_json(summary), flush=True)
    return summary


__all__ = ["Phase2AConfig", "Phase2AError", "run_phase2a", "PublicCacheError"]
