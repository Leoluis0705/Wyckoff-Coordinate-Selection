from __future__ import annotations

import pytest

from crysalis_g1.experiments.context_landscape_second_mlip import (
    context_effect_mechanism,
    delta_distribution,
    independent_context_verdict,
    rank_quartile_labels,
    second_mlip_candidate_plan,
    stratified_event_selection,
)


def test_stratified_selection_is_deterministic_and_ignores_force_columns() -> None:
    rows = [
        {
            "event_id": f"e-{index:02d}",
            "parent_id": f"p-{index:02d}",
            "stage": stage,
            "crystal_system": crystal,
            "force_median": 1000.0 - index,
        }
        for index, (stage, crystal) in enumerate(
            [
                ("EARLY", "cubic"),
                ("EARLY", "hexagonal"),
                ("MID", "cubic"),
                ("MID", "hexagonal"),
                ("LATE", "cubic"),
                ("LATE", "hexagonal"),
                ("TERMINAL", "cubic"),
                ("TERMINAL", "hexagonal"),
            ]
            * 2
        )
    ]
    selected = stratified_event_selection(rows, target_n=8)
    mutated = [{**row, "force_median": -float(row["force_median"])} for row in rows]
    assert [row["event_id"] for row in selected] == [
        row["event_id"] for row in stratified_event_selection(mutated, target_n=8)
    ]
    assert {row["stage"] for row in selected} == {"EARLY", "MID", "LATE", "TERMINAL"}


def test_candidate_plan_deduplicates_identical_arm_choices() -> None:
    rows = [
        {
            "candidate_id": f"c-{index}",
            "candidate_index": str(index),
            "context_top1": str(index == 3),
            "orbit_only_top1": str(index == 3),
            "contact_top1": str(index == 8),
            "fixed_reference_index_12": str(index == 12),
        }
        for index in range(24)
    ]
    planned = second_mlip_candidate_plan(rows)
    assert [row["candidate_id"] for row in planned] == ["c-3", "c-8", "c-12"]
    assert planned[0]["arms"] == ("CONTEXT", "ORBIT_ONLY")


def test_independent_context_verdict_uses_all_three_registered_gates() -> None:
    assert (
        independent_context_verdict(
            mean_delta=-0.2,
            ci_lower=-0.3,
            ci_upper=-0.1,
            win_rate=0.61,
            context_median=2.0,
            orbit_median=3.0,
        )
        == "SUPPORTED"
    )
    assert (
        independent_context_verdict(
            mean_delta=-0.05,
            ci_lower=-0.2,
            ci_upper=0.1,
            win_rate=0.7,
            context_median=2.0,
            orbit_median=3.0,
        )
        == "INCONCLUSIVE"
    )
    assert (
        independent_context_verdict(
            mean_delta=-0.2,
            ci_lower=-0.3,
            ci_upper=-0.1,
            win_rate=0.54,
            context_median=2.0,
            orbit_median=3.0,
        )
        == "INCONCLUSIVE"
    )
    assert (
        independent_context_verdict(
            mean_delta=0.01,
            ci_lower=-0.1,
            ci_upper=0.2,
            win_rate=0.55,
            context_median=3.0,
            orbit_median=2.0,
        )
        == "NOT_SUPPORTED"
    )


def test_delta_distribution_reports_registered_quantiles_and_fractions() -> None:
    summary = delta_distribution([-1.0, -0.5, 0.0, 1.0])
    assert summary["mean"] == -0.125
    assert summary["median"] == -0.25
    assert summary["p10"] == -0.85
    assert summary["p90"] == pytest.approx(0.7)
    assert summary["fraction_lt_0"] == 0.5
    assert summary["fraction_lt_neg_0_50"] == 0.25
    assert summary["fraction_gt_pos_0_50"] == 0.25


def test_rank_quartiles_are_equal_sized_and_ties_use_event_identity() -> None:
    labels = rank_quartile_labels(
        [1.0] * 8,
        ["e7", "e1", "e5", "e3", "e2", "e8", "e6", "e4"],
    )
    assert labels == {
        "e1": "Q1", "e2": "Q1", "e3": "Q2", "e4": "Q2",
        "e5": "Q3", "e6": "Q3", "e7": "Q4", "e8": "Q4",
    }


def test_q4_unique_negative_minimum_with_negative_ci_is_tail_suppression() -> None:
    quartiles = {
        "Q1": {"mean_delta": -0.1, "ci_upper": 0.1},
        "Q2": {"mean_delta": -0.2, "ci_upper": 0.1},
        "Q3": {"mean_delta": -0.3, "ci_upper": 0.1},
        "Q4": {"mean_delta": -0.8, "ci_upper": -0.2},
    }
    stages = {stage: {"mean_delta": -0.1, "ci_upper": 0.1} for stage in ("EARLY", "MID", "LATE", "TERMINAL")}
    assert context_effect_mechanism(quartiles, stages) == "HIGH_FORCE_TAIL_SUPPRESSION"
