from __future__ import annotations

import math

import numpy as np
import pytest
import torch

from crysalis_g1.experiments.context_conditional_landscape import (
    CONTEXT_FEATURE_NAMES,
    ORBIT_ONLY_FEATURE_NAMES,
    action_signature,
    assembly_stage_effect,
    atlas_verdict,
    build_matched_feature_matrices,
    choose_parent_budget,
    context_value_verdict,
    cross_context_analysis,
    deterministic_parent_folds,
    stratified_parent_order,
    select_parent_events,
    summarize_landscapes,
    trainable_parameter_ratio,
)
from crysalis_g1.experiments.full_orbit_operator import FullOrbitCompatibilityMLP
from scripts.run_context_conditional_wyckoff_atlas import (
    ensure_new_output,
    save_reload_checkpoint,
    select_structural_parent_cohort,
)


def _event(
    parent: str,
    *,
    active: int,
    final: int = 8,
    missing: int | None = None,
    free_dof: int = 1,
    line: int = 1,
) -> dict[str, object]:
    return {
        "event_base_id": f"{parent}:{line}",
        "event_id": f"{parent}:{line}",
        "parent_id": parent,
        "active_orbit_count": active,
        "final_orbit_count": final,
        "active_orbit_fraction": active / final,
        "missing_orbit_count": final - active if missing is None else missing,
        "graph_line_number": line,
        "canonical_event_index": line,
        "wyckoff_position_id": "sg-62:c",
        "wyckoff_letter": "c",
        "target_space_group": 62,
        "species": 14,
        "multiplicity": 4,
        "free_dof": free_dof,
    }


def _candidate(event_id: str, index: int, force: float) -> dict[str, object]:
    row: dict[str, object] = {
        "event_id": event_id,
        "candidate_index": index,
        "initial_max_force_ev_per_angstrom": force,
        "chgnet_status": "EVALUATED",
        "target_space_group": 62,
        "wyckoff_letter": "c",
        "multiplicity": 4,
        "free_dof": 2,
        "species": 14,
        "legal_u": [0.1 + index / 100.0, 0.2 + index / 100.0],
        "lattice_a": 5.0,
        "lattice_b": 6.0,
        "lattice_c": 7.0,
        "lattice_alpha": 90.0,
        "lattice_beta": 90.0,
        "lattice_gamma": 120.0,
        "orbit_internal_min_distance": 1.5,
        "orbit_internal_pair_distance_mean": 2.5,
        "assembly_progress": 0.5,
    }
    context_values = {
        "candidate_framework_min_distance_min": 1.1,
        "candidate_framework_min_distance_mean": 1.8,
        "candidate_framework_coordination_mean": 4.0,
        "candidate_framework_coordination_min": 2.0,
        "candidate_framework_same_species_coordination_mean": 1.0,
        "candidate_neighbor_Z_mean": 12.0,
        "candidate_neighbor_Z_std": 2.0,
        "candidate_coordinated_distance_mean": 2.1,
        "short_contact_residual_max": 0.2,
        "short_contact_residual_mean": 0.1,
        "static_full_orbit_contact_score": 0.15,
    }
    row.update(context_values)
    return row


def test_select_parent_events_assigns_each_graph_state_to_only_one_depth_stage() -> None:
    rows = [
        _event("p1", active=2, line=1),
        _event("p1", active=4, line=2),
        _event("p1", active=6, line=3),
        _event("p1", active=7, missing=1, line=4),
    ]

    selected = select_parent_events(rows)

    assert [row["stage"] for row in selected] == ["EARLY", "MID", "LATE", "TERMINAL"]
    assert len({row["event_base_id"] for row in selected}) == 4


def test_select_parent_events_skips_missing_stage_without_refill() -> None:
    selected = select_parent_events([_event("p1", active=4, line=2)])
    assert [row["stage"] for row in selected] == ["MID"]


def test_select_parent_events_uses_distinct_nearest_states_for_early_mid_late() -> None:
    rows = [
        _event("p1", active=2, final=10, line=1),
        _event("p1", active=4, final=10, line=2),
        _event("p1", active=6, final=10, line=3),
    ]
    selected = select_parent_events(rows)
    assert [row["stage"] for row in selected] == ["EARLY", "MID", "LATE"]
    assert [row["active_orbit_fraction"] for row in selected] == [0.2, 0.4, 0.6]


def test_action_signature_uses_species_block_not_exact_atomic_number() -> None:
    silicon = _event("p1", active=4)
    carbon = {**silicon, "species": 6}
    assert action_signature(silicon) == action_signature(carbon)
    assert action_signature(silicon) == (62, "c", 4, 1, "p")


def test_matched_feature_schema_keeps_orbit_model_context_free() -> None:
    row = _candidate("event", 0, 2.0)
    orbit, context = build_matched_feature_matrices([row])

    assert orbit.shape == (1, len(ORBIT_ONLY_FEATURE_NAMES))
    assert context.shape == (1, len(CONTEXT_FEATURE_NAMES))
    assert set(ORBIT_ONLY_FEATURE_NAMES).isdisjoint(
        {
            "candidate_framework_min_distance_min",
            "candidate_framework_coordination_mean",
            "static_full_orbit_contact_score",
            "assembly_progress",
        }
    )
    assert CONTEXT_FEATURE_NAMES[: len(ORBIT_ONLY_FEATURE_NAMES)] == ORBIT_ONLY_FEATURE_NAMES
    assert np.isfinite(orbit).all() and np.isfinite(context).all()
    assert 0.7 <= trainable_parameter_ratio(len(ORBIT_ONLY_FEATURE_NAMES), len(CONTEXT_FEATURE_NAMES)) <= 1.3


def test_parent_folds_keep_all_events_from_parent_together() -> None:
    parents = [f"p{index:02d}" for index in range(9)]
    fold_by_parent = deterministic_parent_folds(parents)
    assert set(fold_by_parent) == set(parents)
    assert set(fold_by_parent.values()) == {0, 1, 2, 3}
    assert max(np.bincount(list(fold_by_parent.values()))) - min(
        np.bincount(list(fold_by_parent.values()))
    ) <= 1


def test_stratified_parent_order_is_nested_and_uses_only_structural_strata() -> None:
    parents = []
    for index in range(8):
        parents.append(
            {
                "parent_id": f"p{index}",
                "crystal_system": "cubic" if index < 4 else "hexagonal",
                "element_count": 2,
                "final_orbit_count": 4,
                "available_free_dof_classes": (1, 2),
                "force": -10_000.0 + index,
            }
        )
    ordered = stratified_parent_order(parents)
    assert len(ordered) == 8
    assert {row["crystal_system"] for row in ordered[:4]} == {"cubic", "hexagonal"}
    assert [row["parent_id"] for row in ordered] == [
        row["parent_id"] for row in stratified_parent_order(list(reversed(parents)))
    ]


def test_cross_context_requires_four_parents_and_compares_candidate_indices() -> None:
    events = []
    candidates = []
    orders = {
        "p0": [1.0, 2.0, 3.0, 4.0],
        "p1": [1.0, 2.0, 3.0, 4.0],
        "p2": [4.0, 3.0, 2.0, 1.0],
        "p3": [4.0, 3.0, 2.0, 1.0],
    }
    for parent, forces in orders.items():
        event = _event(parent, active=4)
        event["event_id"] = f"event-{parent}"
        events.append(event)
        candidates.extend(
            _candidate(str(event["event_id"]), index, force)
            for index, force in enumerate(forces)
        )

    result = cross_context_analysis(events, candidates)

    assert result["qualifying_signature_n"] == 1
    assert result["pair_n"] == 6
    assert result["spearman_median"] == pytest.approx(-1.0)


def test_ruggedness_uses_registered_log1p_iqr_thresholds() -> None:
    events = [
        {**_event("p1", active=2), "event_id": "rugged", "stage": "EARLY"},
        {**_event("p2", active=4), "event_id": "flat", "stage": "MID"},
    ]
    candidates = []
    candidates.extend(_candidate("rugged", i, force) for i, force in enumerate([0.0, 0.0, 10.0, 10.0]))
    candidates.extend(_candidate("flat", i, 2.0) for i in range(4))

    result = summarize_landscapes(events, candidates)

    assert result["overall_rugged_rate"] == pytest.approx(0.5)
    assert result["stage_rugged_rate"]["EARLY"] == pytest.approx(1.0)
    assert result["stage_rugged_rate"]["MID"] == pytest.approx(0.0)
    assert result["event_summaries"][0]["rugged_event"] is True


@pytest.mark.parametrize(
    ("elapsed", "counts", "expected"),
    [
        (0.5, {256: 800, 192: 600, 128: 400}, 256),
        (1.0, {256: 1000, 192: 400, 128: 300}, 192),
        (2.0, {256: 600, 192: 400, 128: 200}, 128),
    ],
)
def test_budget_reduces_only_in_registered_order(
    elapsed: float, counts: dict[int, int], expected: int
) -> None:
    assert choose_parent_budget(elapsed_minutes_at_16=elapsed, event_counts=counts) == expected


def test_budget_stops_when_128_parent_eta_exceeds_limit() -> None:
    with pytest.raises(TimeoutError, match="128-parent"):
        choose_parent_budget(
            elapsed_minutes_at_16=2.0,
            event_counts={256: 1000, 192: 700, 128: 400},
        )


def test_context_value_verdict_requires_both_metrics_three_folds_and_negative_ci() -> None:
    supported = context_value_verdict(
        orbit_ndcg5=0.70,
        context_ndcg5=0.75,
        orbit_top1_force=5.0,
        context_top1_force=2.0,
        fold_top1_log_deltas=[-1.0, -0.5, 0.1, -0.2],
        ci_upper=-0.01,
    )
    failed = context_value_verdict(
        orbit_ndcg5=0.70,
        context_ndcg5=0.75,
        orbit_top1_force=5.0,
        context_top1_force=2.0,
        fold_top1_log_deltas=[-1.0, -0.5, 0.1, 0.2],
        ci_upper=-0.01,
    )
    assert supported["status"] == "SUPPORTED"
    assert supported["directional_fold_n"] == 3
    assert failed["status"] == "NOT_SUPPORTED"


def test_assembly_stage_effect_requires_mid_late_gain_and_early_weakness() -> None:
    stage_rows = {
        "EARLY": {"orbit_ndcg5": 0.7, "context_ndcg5": 0.69, "orbit_top1_force": 4.0, "context_top1_force": 5.0},
        "MID": {"orbit_ndcg5": 0.7, "context_ndcg5": 0.8, "orbit_top1_force": 8.0, "context_top1_force": 3.0},
        "LATE": {"orbit_ndcg5": 0.7, "context_ndcg5": 0.8, "orbit_top1_force": 7.0, "context_top1_force": 2.0},
        "TERMINAL": {"orbit_ndcg5": 0.7, "context_ndcg5": 0.75, "orbit_top1_force": 6.0, "context_top1_force": 4.0},
    }
    assert assembly_stage_effect(stage_rows) == "SUPPORTED"


def test_atlas_verdict_respects_registered_three_part_gate() -> None:
    supported = atlas_verdict(
        overall_rugged_rate=0.8,
        mid_rugged_rate=0.75,
        late_rugged_rate=0.70,
        context_value="SUPPORTED",
        cross_context_spearman_median=0.5,
    )
    orbit_only = atlas_verdict(
        overall_rugged_rate=0.8,
        mid_rugged_rate=0.75,
        late_rugged_rate=0.70,
        context_value="NOT_SUPPORTED",
        cross_context_spearman_median=0.5,
    )
    absent = atlas_verdict(
        overall_rugged_rate=0.7,
        mid_rugged_rate=0.75,
        late_rugged_rate=0.70,
        context_value="SUPPORTED",
        cross_context_spearman_median=0.5,
    )
    assert supported["conditional_landscape_signal"] == "SUPPORTED"
    assert supported["next_action"] == "INDEPENDENT_POTENTIAL_AND_EXTERNAL_ATLAS_VALIDATION"
    assert orbit_only["nc_core_claim_candidate"] == "GLOBAL_SYMMETRY_RESTRICTED_LANDSCAPE_NOT_NOVEL_ENOUGH"
    assert absent["nc_core_claim_candidate"] == "REJECT_LANDSCAPE_AS_NC_CORE"
    assert absent["next_action"] == "STOP_LANDSCAPE_NC_DIRECTION"


def test_output_gate_refuses_to_overwrite_existing_artifacts(tmp_path) -> None:
    target = tmp_path / "atlas"
    assert ensure_new_output(target) == target
    target.mkdir()
    with pytest.raises(FileExistsError):
        ensure_new_output(target)


def test_saved_context_model_reloads_and_reproduces_sanity_predictions(tmp_path) -> None:
    torch.manual_seed(7)
    model = FullOrbitCompatibilityMLP(input_n=3)
    sanity = np.asarray([[0.1, 0.2, 0.3], [1.0, -1.0, 0.0]], dtype=float)
    normalization = {
        "x_mean": [0.0, 0.0, 0.0],
        "x_scale": [1.0, 1.0, 1.0],
        "y_mean": 0.0,
        "y_scale": 1.0,
    }
    path = tmp_path / "model.pt"

    result = save_reload_checkpoint(
        path=path,
        model=model,
        feature_names=("a", "b", "c"),
        normalization=normalization,
        sanity_x=sanity,
        sanity_candidate_ids=("c0", "c1"),
        metadata={"model_label": "TEST"},
    )

    assert path.is_file()
    assert result["reloadable"] is True
    assert result["maximum_absolute_error"] <= 1e-7


def test_structural_parent_selection_precedes_expensive_official_event_validation() -> None:
    parent_rows = [
        {
            "parent_id": f"p{index:03d}",
            "crystal_system": "cubic" if index % 2 else "hexagonal",
            "element_count": 2,
            "final_orbit_count": 4,
            "available_free_dof_classes": (1,),
        }
        for index in range(300)
    ]
    events = [{**_event(row["parent_id"], active=2), "stage": "EARLY"} for row in parent_rows]

    selected_ids, selected_events = select_structural_parent_cohort(
        parent_rows, events, target_n=256
    )

    assert len(selected_ids) == 256
    assert len(selected_events) == 256
    assert {row["parent_id"] for row in selected_events} == set(selected_ids)
