from __future__ import annotations

import pytest

from crysalis_g1.experiments.context_landscape_external import (
    choose_external_parent_budget,
    external_replication_verdict,
    external_stage_effect,
    nc_landscape_verdict,
    second_mlip_verdict,
    unique_selection_indices,
)


def test_external_budget_keeps_128_when_projected_run_fits() -> None:
    assert (
        choose_external_parent_budget(
            elapsed_minutes_at_16=0.5, event_counts={128: 450, 96: 340}
        )
        == 128
    )


def test_external_budget_reduces_to_96_but_never_below() -> None:
    assert (
        choose_external_parent_budget(
            elapsed_minutes_at_16=1.5, event_counts={128: 450, 96: 340}
        )
        == 96
    )
    with pytest.raises(TimeoutError, match="96-parent"):
        choose_external_parent_budget(
            elapsed_minutes_at_16=2.0, event_counts={128: 450, 96: 340}
        )


def test_independent_candidate_subset_deduplicates_without_force_input() -> None:
    assert unique_selection_indices(
        context_index=3, orbit_index=3, contact_index=7, reference_index=12
    ) == (3, 7, 12)


def test_external_replication_requires_metrics_ci_and_three_nonreverse_stages() -> None:
    assert (
        external_replication_verdict(
            orbit_ndcg5=0.6,
            context_ndcg5=0.7,
            orbit_top1_force=4.0,
            context_top1_force=2.0,
            ci_upper=-0.01,
            nonreverse_stage_n=3,
        )
        == "SUPPORTED"
    )
    assert (
        external_replication_verdict(
            orbit_ndcg5=0.6,
            context_ndcg5=0.7,
            orbit_top1_force=4.0,
            context_top1_force=2.0,
            ci_upper=0.01,
            nonreverse_stage_n=4,
        )
        == "NOT_SUPPORTED"
    )


@pytest.mark.parametrize(
    ("mean_delta", "ci_upper", "win_rate", "expected"),
    [
        (-0.4, -0.01, 0.60, "SUPPORTED"),
        (-0.2, 0.10, 0.70, "INCONCLUSIVE"),
        (0.1, 0.30, 0.40, "NOT_SUPPORTED"),
    ],
)
def test_second_mlip_verdict_has_registered_three_way_gate(
    mean_delta: float, ci_upper: float, win_rate: float, expected: str
) -> None:
    assert (
        second_mlip_verdict(
            mean_delta=mean_delta, ci_upper=ci_upper, win_rate=win_rate
        )
        == expected
    )


def test_stage_effect_needs_two_clear_gains_among_mid_late_terminal() -> None:
    rows = {
        "EARLY": {"ndcg_delta": -0.1, "top1_force_delta": 1.0},
        "MID": {"ndcg_delta": 0.1, "top1_force_delta": -1.0},
        "LATE": {"ndcg_delta": 0.2, "top1_force_delta": -2.0},
        "TERMINAL": {"ndcg_delta": -0.1, "top1_force_delta": -1.0},
    }
    assert external_stage_effect(rows) == "SUPPORTED"
    rows["LATE"] = {"ndcg_delta": -0.2, "top1_force_delta": -2.0}
    assert external_stage_effect(rows) == "NOT_SUPPORTED"


def test_nc_verdict_treats_missing_second_mlip_as_pending_not_failure() -> None:
    assert nc_landscape_verdict("SUPPORTED", "NOT_RUN") == {
        "nc_landscape_core": "SUPPORTED_PENDING_INDEPENDENT_PHYSICS",
        "next_action": "EXPAND_SECOND_MLIP_CHECK",
    }
    assert nc_landscape_verdict("SUPPORTED", "SUPPORTED")["nc_landscape_core"] == "STRONGLY_SUPPORTED"
    assert nc_landscape_verdict("NOT_SUPPORTED", "SUPPORTED")["nc_landscape_core"] == "NOT_REPLICATED"
