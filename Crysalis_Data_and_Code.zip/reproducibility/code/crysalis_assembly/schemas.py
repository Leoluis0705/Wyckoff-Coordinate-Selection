from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from math import isfinite
from typing import TypeAlias


SCHEMA_VERSION = "1.0.0"

JsonScalar: TypeAlias = str | int | float | bool | None
Vector3: TypeAlias = tuple[float, float, float]
Image3: TypeAlias = tuple[int, int, int]
Matrix3: TypeAlias = tuple[Vector3, Vector3, Vector3]


def _require_text(name: str, value: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} must be a non-empty string")


def _require_unique(name: str, values: tuple[str, ...]) -> None:
    if len(values) != len(set(values)):
        raise ValueError(f"{name} must be unique")


def _require_positive_int(name: str, value: int) -> None:
    if type(value) is not int or value <= 0:
        raise ValueError(f"{name} must be a positive integer")


class ActionType(str, Enum):
    BIND_ELEMENT = "bind_element"
    ADD_ORBIT = "add_orbit"
    EXPAND_ORBIT = "expand_orbit"
    ADD_PERIODIC_EDGE_SET = "add_periodic_edge_set"
    INSTANTIATE_MOTIF = "instantiate_motif"
    REFINE_COORDINATES = "refine_coordinates"
    STOP = "stop"


class NodeStatus(str, Enum):
    ACTIVE = "active"
    MISSING = "missing"
    KNOWN = "known"
    LOCKED = "locked"


class ConstraintLevel(str, Enum):
    HARD = "hard"
    CONDITIONAL_HARD = "conditional_hard"
    SOFT = "soft"


class ReasonCode(str, Enum):
    FRACTIONAL_COORDINATE_OUT_OF_RANGE = "fractional_coordinate_out_of_range"
    FRACTIONAL_COORDINATE_WRAPPED = "fractional_coordinate_wrapped"
    NON_POSITIVE_LATTICE = "non_positive_lattice"
    ATOM_BUDGET_EXCEEDED = "atom_budget_exceeded"
    DISALLOWED_ELEMENT = "disallowed_element"
    COMPOSITION_BUDGET_EXCEEDED = "composition_budget_exceeded"
    ACTION_SOURCE_MISMATCH = "action_source_mismatch"
    UNKNOWN_ACTION_TARGET = "unknown_action_target"
    INCOMPLETE_COMPOSITION = "incomplete_composition"


@dataclass(frozen=True)
class ElementCount:
    element: str
    count: int

    def __post_init__(self) -> None:
        _require_text("element", self.element)
        _require_positive_int("count", self.count)


@dataclass(frozen=True)
class AssemblyBudget:
    max_atoms: int
    max_actions: int
    max_volume: float | None = None

    def __post_init__(self) -> None:
        _require_positive_int("max_atoms", self.max_atoms)
        _require_positive_int("max_actions", self.max_actions)
        if self.max_volume is not None:
            if not isinstance(self.max_volume, (int, float)) or not isfinite(
                self.max_volume
            ) or self.max_volume <= 0:
                raise ValueError("max_volume must be finite and positive")


@dataclass(frozen=True)
class RoleSlot:
    stable_id: str
    role: str
    allowed_elements: tuple[str, ...]

    def __post_init__(self) -> None:
        _require_text("role slot stable_id", self.stable_id)
        _require_text("role", self.role)
        if not self.allowed_elements:
            raise ValueError("role slot allowed_elements must not be empty")
        for element in self.allowed_elements:
            _require_text("allowed element", element)
        _require_unique("role slot allowed_elements", self.allowed_elements)


@dataclass(frozen=True)
class OrbitSlot:
    stable_id: str
    multiplicity: int
    role_slot_id: str

    def __post_init__(self) -> None:
        _require_text("orbit slot stable_id", self.stable_id)
        _require_positive_int("orbit slot multiplicity", self.multiplicity)
        _require_text("role_slot_id", self.role_slot_id)


@dataclass(frozen=True)
class MaterialEmbryo:
    embryo_id: str
    task: str
    composition_budget: tuple[ElementCount, ...]
    allowed_elements: tuple[str, ...]
    role_slots: tuple[RoleSlot, ...]
    orbit_slots: tuple[OrbitSlot, ...]
    budget: AssemblyBudget
    space_group: int | None = None
    prototype: str | None = None

    def __post_init__(self) -> None:
        _require_text("embryo_id", self.embryo_id)
        _require_text("task", self.task)
        if not self.composition_budget:
            raise ValueError("composition_budget must not be empty")
        if not self.allowed_elements:
            raise ValueError("allowed_elements must not be empty")

        composition_elements = tuple(item.element for item in self.composition_budget)
        _require_unique("composition elements", composition_elements)
        for element in self.allowed_elements:
            _require_text("allowed element", element)
        _require_unique("allowed_elements", self.allowed_elements)
        allowed = set(self.allowed_elements)
        for element in composition_elements:
            if element not in allowed:
                raise ValueError(f"composition element {element} is not allowed")

        role_ids = tuple(slot.stable_id for slot in self.role_slots)
        orbit_slot_ids = tuple(slot.stable_id for slot in self.orbit_slots)
        _require_unique("role slot stable IDs", role_ids)
        _require_unique("orbit slot stable IDs", orbit_slot_ids)
        known_roles = set(role_ids)
        for role_slot in self.role_slots:
            unknown = set(role_slot.allowed_elements) - allowed
            if unknown:
                raise ValueError(
                    f"role slot contains disallowed elements: {sorted(unknown)}"
                )
        for orbit_slot in self.orbit_slots:
            if orbit_slot.role_slot_id not in known_roles:
                raise ValueError(
                    f"orbit slot {orbit_slot.stable_id} references unknown role slot"
                )

        if self.space_group is not None:
            if type(self.space_group) is not int or not 1 <= self.space_group <= 230:
                raise ValueError("space_group must be an integer from 1 to 230")
        if self.prototype is not None:
            _require_text("prototype", self.prototype)


@dataclass(frozen=True)
class OrbitNode:
    stable_id: str
    slot_id: str
    multiplicity: int
    role: str
    element: str | None = None
    wyckoff_label: str | None = None
    occupancy: float = 1.0
    status: NodeStatus = NodeStatus.ACTIVE

    def __post_init__(self) -> None:
        _require_text("orbit stable_id", self.stable_id)
        _require_text("orbit slot_id", self.slot_id)
        _require_positive_int("orbit multiplicity", self.multiplicity)
        _require_text("orbit role", self.role)
        if self.element is not None:
            _require_text("orbit element", self.element)
        if self.wyckoff_label is not None:
            _require_text("wyckoff_label", self.wyckoff_label)
        if not isinstance(self.occupancy, (int, float)) or not isfinite(
            self.occupancy
        ) or not 0 < self.occupancy <= 1:
            raise ValueError("occupancy must be finite and in (0, 1]")
        if not isinstance(self.status, NodeStatus):
            raise ValueError("orbit status must be a NodeStatus")


@dataclass(frozen=True)
class AtomNode:
    stable_id: str
    orbit_id: str
    element: str
    fractional_position: Vector3
    status: NodeStatus = NodeStatus.ACTIVE

    def __post_init__(self) -> None:
        _require_text("atom stable_id", self.stable_id)
        _require_text("atom orbit_id", self.orbit_id)
        _require_text("atom element", self.element)
        if len(self.fractional_position) != 3 or any(
            not isinstance(value, (int, float)) or not isfinite(value)
            for value in self.fractional_position
        ):
            raise ValueError("fractional_position must contain three finite values")
        if not isinstance(self.status, NodeStatus):
            raise ValueError("atom status must be a NodeStatus")


@dataclass(frozen=True)
class PeriodicEdge:
    source_id: str
    target_id: str
    image: Image3
    relation_type: str
    active: bool = True

    def __post_init__(self) -> None:
        _require_text("edge source_id", self.source_id)
        _require_text("edge target_id", self.target_id)
        _require_text("edge relation_type", self.relation_type)
        if len(self.image) != 3 or any(type(value) is not int for value in self.image):
            raise ValueError("periodic image must contain three integers")
        if type(self.active) is not bool:
            raise ValueError("edge active must be boolean")


@dataclass(frozen=True)
class MotifFactor:
    stable_id: str
    motif_type: str
    member_ids: tuple[str, ...]
    uncertainty: float = 0.0

    def __post_init__(self) -> None:
        _require_text("motif stable_id", self.stable_id)
        _require_text("motif_type", self.motif_type)
        if len(self.member_ids) < 2:
            raise ValueError("motif must contain at least two members")
        for member_id in self.member_ids:
            _require_text("motif member_id", member_id)
        _require_unique("motif member IDs", self.member_ids)
        if not isinstance(self.uncertainty, (int, float)) or not isfinite(
            self.uncertainty
        ) or not 0 <= self.uncertainty <= 1:
            raise ValueError("motif uncertainty must be finite and in [0, 1]")


@dataclass(frozen=True)
class LedgerEntry:
    constraint_id: str
    level: ConstraintLevel
    satisfied: bool | None
    detail: str = ""
    assumption_branch: str | None = None

    def __post_init__(self) -> None:
        _require_text("constraint_id", self.constraint_id)
        if not isinstance(self.level, ConstraintLevel):
            raise ValueError("ledger level must be a ConstraintLevel")
        if self.satisfied is not None and type(self.satisfied) is not bool:
            raise ValueError("ledger satisfied must be boolean or None")
        if not isinstance(self.detail, str):
            raise ValueError("ledger detail must be a string")
        if self.assumption_branch is not None:
            _require_text("assumption_branch", self.assumption_branch)


@dataclass(frozen=True)
class AssemblyState:
    state_id: str
    embryo: MaterialEmbryo
    orbit_nodes: tuple[OrbitNode, ...]
    atom_nodes: tuple[AtomNode, ...]
    edges: tuple[PeriodicEdge, ...]
    factors: tuple[MotifFactor, ...]
    lattice: Matrix3
    ledger: tuple[LedgerEntry, ...] = ()
    step_index: int = 0
    parent_state_id: str | None = None
    action_history: tuple[str, ...] = ()
    energy_eligible: bool = False
    uncertainty: tuple[tuple[str, float], ...] = ()

    def __post_init__(self) -> None:
        _require_text("state_id", self.state_id)
        if not isinstance(self.embryo, MaterialEmbryo):
            raise ValueError("embryo must be a MaterialEmbryo")
        if len(self.lattice) != 3 or any(len(row) != 3 for row in self.lattice):
            raise ValueError("lattice must be a finite 3x3 matrix")
        if any(
            not isinstance(value, (int, float)) or not isfinite(value)
            for row in self.lattice
            for value in row
        ):
            raise ValueError("lattice must be a finite 3x3 matrix")
        if type(self.step_index) is not int or self.step_index < 0:
            raise ValueError("step_index must be a non-negative integer")
        if self.parent_state_id is not None:
            _require_text("parent_state_id", self.parent_state_id)
            if self.parent_state_id == self.state_id:
                raise ValueError("parent_state_id must differ from state_id")
        if type(self.energy_eligible) is not bool:
            raise ValueError("energy_eligible must be boolean")

        orbit_ids = tuple(node.stable_id for node in self.orbit_nodes)
        atom_ids = tuple(node.stable_id for node in self.atom_nodes)
        factor_ids = tuple(factor.stable_id for factor in self.factors)
        all_stable_ids = orbit_ids + atom_ids + factor_ids
        if len(all_stable_ids) != len(set(all_stable_ids)):
            raise ValueError("stable IDs must be globally unique")

        known_slots = {slot.stable_id for slot in self.embryo.orbit_slots}
        for orbit in self.orbit_nodes:
            if orbit.slot_id not in known_slots:
                raise ValueError(
                    f"orbit {orbit.stable_id} references unknown orbit slot"
                )
        known_orbits = set(orbit_ids)
        for atom in self.atom_nodes:
            if atom.orbit_id not in known_orbits:
                raise ValueError(f"atom {atom.stable_id} references unknown orbit")

        known_nodes = known_orbits | set(atom_ids)
        for edge in self.edges:
            if edge.source_id not in known_nodes or edge.target_id not in known_nodes:
                raise ValueError("edge references unknown node")
        for factor in self.factors:
            if not set(factor.member_ids).issubset(known_nodes):
                raise ValueError("motif references unknown node")

        ledger_ids = tuple(entry.constraint_id for entry in self.ledger)
        _require_unique("constraint ledger IDs", ledger_ids)
        for action_id in self.action_history:
            _require_text("action_history entry", action_id)
        _require_unique("action_history IDs", self.action_history)

        uncertainty_names = tuple(name for name, _ in self.uncertainty)
        _require_unique("uncertainty names", uncertainty_names)
        for name, value in self.uncertainty:
            _require_text("uncertainty name", name)
            if not isinstance(value, (int, float)) or not isfinite(value) or value < 0:
                raise ValueError("uncertainty values must be finite and non-negative")


@dataclass(frozen=True)
class AssemblyAction:
    action_id: str
    source_state_id: str
    action_type: ActionType
    targets: tuple[str, ...] = ()
    parameters: tuple[tuple[str, JsonScalar], ...] = ()
    preconditions: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        _require_text("action_id", self.action_id)
        _require_text("source_state_id", self.source_state_id)
        if not isinstance(self.action_type, ActionType):
            raise ValueError("action_type must be an ActionType")
        for target in self.targets:
            _require_text("action target", target)
        _require_unique("action targets", self.targets)

        parameter_names = tuple(name for name, _ in self.parameters)
        for name, value in self.parameters:
            _require_text("action parameter name", name)
            if not isinstance(value, (str, int, float, bool, type(None))):
                raise ValueError("action parameter values must be JSON scalars")
            if isinstance(value, float) and not isfinite(value):
                raise ValueError("action parameter float values must be finite")
        _require_unique("action parameter names", parameter_names)

        for precondition in self.preconditions:
            _require_text("action precondition", precondition)
        _require_unique("action preconditions", self.preconditions)

    def parameter(self, name: str, default: JsonScalar = None) -> JsonScalar:
        for key, value in self.parameters:
            if key == name:
                return value
        return default


@dataclass(frozen=True)
class TrajectoryStep:
    action: AssemblyAction
    state: AssemblyState

    def __post_init__(self) -> None:
        if not isinstance(self.action, AssemblyAction):
            raise ValueError("trajectory step action must be an AssemblyAction")
        if not isinstance(self.state, AssemblyState):
            raise ValueError("trajectory step state must be an AssemblyState")


@dataclass(frozen=True)
class Trajectory:
    trajectory_id: str
    parent_structure_id: str
    split: str
    operator_version: str
    seed: int
    initial_state: AssemblyState
    steps: tuple[TrajectoryStep, ...] = ()

    def __post_init__(self) -> None:
        _require_text("trajectory_id", self.trajectory_id)
        _require_text("parent_structure_id", self.parent_structure_id)
        _require_text("split", self.split)
        _require_text("operator_version", self.operator_version)
        if type(self.seed) is not int or self.seed < 0:
            raise ValueError("seed must be a non-negative integer")
        if not isinstance(self.initial_state, AssemblyState):
            raise ValueError("initial_state must be an AssemblyState")

        state_ids = [self.initial_state.state_id]
        action_ids: list[str] = []
        previous = self.initial_state
        for step in self.steps:
            if step.action.source_state_id != previous.state_id:
                raise ValueError("action source_state_id must match previous state_id")
            if step.state.parent_state_id != previous.state_id:
                raise ValueError("state parent_state_id must match previous state_id")
            if step.state.step_index != previous.step_index + 1:
                raise ValueError("trajectory state step_index must be consecutive")
            if step.state.embryo.embryo_id != self.initial_state.embryo.embryo_id:
                raise ValueError("all trajectory states must share one embryo_id")
            state_ids.append(step.state.state_id)
            action_ids.append(step.action.action_id)
            previous = step.state
        if len(state_ids) != len(set(state_ids)):
            raise ValueError("trajectory state IDs must be unique")
        if len(action_ids) != len(set(action_ids)):
            raise ValueError("trajectory action IDs must be unique")


@dataclass(frozen=True)
class ConstraintViolation:
    code: ReasonCode
    message: str
    object_id: str | None = None
    constraint_id: str | None = None


@dataclass(frozen=True)
class ConstraintRepair:
    code: ReasonCode
    message: str
    magnitude: float
    object_id: str | None = None


@dataclass(frozen=True)
class ConstraintReport:
    pre_violations: tuple[ConstraintViolation, ...] = ()
    post_violations: tuple[ConstraintViolation, ...] = ()
    repairs: tuple[ConstraintRepair, ...] = ()
    rejected: bool = False

    @property
    def projection_magnitude(self) -> float:
        return max((repair.magnitude for repair in self.repairs), default=0.0)


@dataclass(frozen=True)
class ProjectionResult:
    state: AssemblyState | None
    report: ConstraintReport
