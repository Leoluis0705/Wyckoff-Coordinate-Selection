"""Independent Crysalis Stage A Gate 1b experiment components."""

