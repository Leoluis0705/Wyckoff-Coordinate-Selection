from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

from .paired_corruptions import PairedState


GATE1B_A_ARMS = (
    "A0-T-R",
    "A0-T-S-single",
    "A0-T-S-multi",
    "A0-T-M",
)


class Gate1bAError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class Gate1bAMatrixAudit:
    run_count: int
    expected_run_count: int
    parameter_count: int
    completed_updates: int
    config_hash: str
    public_manifest_hash: str


def _rank(seed: int, update: int, state: PairedState) -> str:
    return hashlib.sha256(
        (
            f"{seed}:{update}:{state.parent_structure_id}:"
            f"{state.evaluation_pair_id}:{state.corruption_type.value}"
        ).encode("utf-8")
    ).hexdigest()


def _take_ranked(
    states: tuple[PairedState, ...], count: int, seed: int, update: int
) -> tuple[PairedState, ...]:
    if not states:
        raise ValueError("mixed training source is empty")
    ranked = tuple(sorted(states, key=lambda row: (_rank(seed, update, row), row.evaluation_pair_id)))
    return tuple(ranked[index % len(ranked)] for index in range(count))


def mixed_training_batch(
    random_states: tuple[PairedState, ...],
    semantic_states: tuple[PairedState, ...],
    *,
    update: int,
    batch_size: int,
    seed: int,
) -> tuple[PairedState, ...]:
    if batch_size <= 0 or batch_size % 2:
        raise ValueError("mixed batch size must be positive and even")
    half = batch_size // 2
    random = _take_ranked(random_states, half, seed, update)
    semantic = _take_ranked(semantic_states, half, seed, update)
    return tuple(
        state
        for pair in zip(random, semantic, strict=True)
        for state in pair
    )


def _file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _read_manifest(path: Path) -> dict[str, object]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise Gate1bAError(f"cannot read run manifest {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise Gate1bAError(f"run manifest {path} must contain an object")
    return payload


def _as_int(value: object, *, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, str)):
        raise Gate1bAError(f"{label} must be an integer")
    try:
        return int(value)
    except ValueError as exc:
        raise Gate1bAError(f"{label} must be an integer") from exc


def _as_string_set(value: object, *, label: str) -> set[str]:
    if not isinstance(value, (list, tuple)) or any(
        not isinstance(item, str) for item in value
    ):
        raise Gate1bAError(f"{label} must be a string list")
    return set(value)


def validate_gate1b_a_matrix(
    root: Path,
    *,
    seeds: tuple[int, ...],
    config_hash: str,
    completed_updates: int,
) -> Gate1bAMatrixAudit:
    root = Path(root)
    expected = tuple(
        (arm, seed, root / arm / f"seed-{seed}")
        for arm in GATE1B_A_ARMS
        for seed in seeds
    )
    missing = [
        f"{arm}/seed-{seed}"
        for arm, seed, run in expected
        if not (run / "run_manifest.json").is_file()
    ]
    if missing:
        raise Gate1bAError(f"missing Gate 1b-A runs: {missing}")
    parameter_counts: set[int] = set()
    public_hashes: set[str] = set()
    for arm, seed, run in expected:
        manifest = _read_manifest(run / "run_manifest.json")
        if manifest.get("status") != "completed":
            raise Gate1bAError(f"run is incomplete: {arm}/seed-{seed}")
        if manifest.get("arm") != arm or manifest.get("seed") != seed:
            raise Gate1bAError(f"run identity mismatch: {arm}/seed-{seed}")
        if manifest.get("config_hash") != config_hash:
            raise Gate1bAError(f"config hash mismatch: {arm}/seed-{seed}")
        if manifest.get("model_architecture") != "A0":
            raise Gate1bAError(f"Gate 1b-A must use A0: {arm}/seed-{seed}")
        if manifest.get("completed_updates") != completed_updates:
            raise Gate1bAError(f"update mismatch: {arm}/seed-{seed}")
        accessed = _as_string_set(
            manifest.get("partitions_accessed", ()), label="partitions_accessed"
        )
        if accessed - {"train_fit", "validation"}:
            raise Gate1bAError(f"blind partition was accessed: {arm}/seed-{seed}")
        checkpoint = run / "checkpoint.pt"
        metrics = run / "metrics.jsonl"
        if not checkpoint.is_file() or _file_hash(checkpoint) != manifest.get(
            "checkpoint_sha256"
        ):
            raise Gate1bAError(f"checkpoint hash mismatch: {arm}/seed-{seed}")
        if not metrics.is_file() or _file_hash(metrics) != manifest.get(
            "metrics_sha256"
        ):
            raise Gate1bAError(f"metrics hash mismatch: {arm}/seed-{seed}")
        parameter_counts.add(
            _as_int(manifest.get("parameter_count", -1), label="parameter_count")
        )
        public_hashes.add(str(manifest.get("public_manifest_hash", "")))
    if len(parameter_counts) != 1:
        raise Gate1bAError(f"A0 parameter counts differ: {sorted(parameter_counts)}")
    if len(public_hashes) != 1 or "" in public_hashes:
        raise Gate1bAError("run matrix does not share one public manifest hash")
    return Gate1bAMatrixAudit(
        run_count=len(expected),
        expected_run_count=len(expected),
        parameter_count=next(iter(parameter_counts)),
        completed_updates=completed_updates,
        config_hash=config_hash,
        public_manifest_hash=next(iter(public_hashes)),
    )
