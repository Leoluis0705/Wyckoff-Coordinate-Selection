from __future__ import annotations

import hashlib
from dataclasses import dataclass, replace
from enum import Enum

from ..experiments.deconstruction import (
    CorruptionVariant,
    matched_corruptions,
    semantic_paths,
)
from ..experiments.symmetry import CanonicalCrystal


class CorruptionType(str, Enum):
    RANDOM = "random"
    SEMANTIC = "semantic"


class TrainingDistribution(str, Enum):
    RANDOM = "T-R"
    SEMANTIC_SINGLE = "T-S-single"
    SEMANTIC_MULTI = "T-S-multi"
    MIXED = "T-M"


@dataclass(frozen=True, slots=True)
class PairedState:
    parent_structure_id: str
    prototype_family: str
    path_index: int
    evaluation_pair_id: str
    corruption_type: CorruptionType
    example_seed: int
    missing_site_indices: tuple[int, ...]
    missing_orbit_indices: tuple[int, ...]
    is_semantic_union: bool
    unique_semantic_path_count: int

    @property
    def missing_count(self) -> int:
        return len(self.missing_site_indices)


@dataclass(frozen=True, slots=True)
class EvaluationPair:
    parent_structure_id: str
    prototype_family: str
    missing_count: int
    evaluation_pair_id: str
    random: PairedState
    semantic: PairedState

    def __post_init__(self) -> None:
        if self.random.missing_count != self.semantic.missing_count:
            raise ValueError("paired random and semantic missing counts differ")
        if self.missing_count != self.random.missing_count:
            raise ValueError("pair missing count does not match its states")
        if not (
            self.random.evaluation_pair_id
            == self.semantic.evaluation_pair_id
            == self.evaluation_pair_id
        ):
            raise ValueError("evaluation pair IDs differ")


def _seeded_int(*parts: object) -> int:
    encoded = ":".join(str(part) for part in parts).encode("utf-8")
    return int.from_bytes(hashlib.sha256(encoded).digest()[:8], "big")


def _pair_id(material_id: str, path_index: int, missing_count: int, seed: int) -> str:
    digest = hashlib.sha256(
        f"gate1b:{seed}:{material_id}:{path_index}:{missing_count}".encode("utf-8")
    ).hexdigest()[:20]
    return f"{material_id}:gate1b-pair:{digest}"


def paired_corruptions(
    crystal: CanonicalCrystal,
    *,
    prototype_family: str,
    count: int,
    min_fraction: float,
    max_fraction: float,
    seed: int,
) -> tuple[EvaluationPair, ...]:
    semantic = semantic_paths(
        crystal,
        count=count,
        min_fraction=min_fraction,
        max_fraction=max_fraction,
        seed=seed,
    )
    examples = matched_corruptions(
        crystal,
        semantic,
        count=count,
        min_fraction=min_fraction,
        max_fraction=max_fraction,
        seed=seed,
    )
    indexed = {(row.variant, row.path_index): row for row in examples}
    pairs = []
    for path_index in range(count):
        random_row = indexed[(CorruptionVariant.M1, path_index)]
        semantic_row = indexed[(CorruptionVariant.M3, path_index)]
        pair_id = _pair_id(
            crystal.material_id,
            path_index,
            len(semantic_row.missing_site_indices),
            seed,
        )
        random_state = PairedState(
            parent_structure_id=crystal.material_id,
            prototype_family=prototype_family,
            path_index=path_index,
            evaluation_pair_id=pair_id,
            corruption_type=CorruptionType.RANDOM,
            example_seed=random_row.example_seed,
            missing_site_indices=random_row.missing_site_indices,
            missing_orbit_indices=random_row.missing_orbit_indices,
            is_semantic_union=random_row.is_semantic_union,
            unique_semantic_path_count=random_row.unique_semantic_path_count,
        )
        semantic_state = PairedState(
            parent_structure_id=crystal.material_id,
            prototype_family=prototype_family,
            path_index=path_index,
            evaluation_pair_id=pair_id,
            corruption_type=CorruptionType.SEMANTIC,
            example_seed=semantic_row.example_seed,
            missing_site_indices=semantic_row.missing_site_indices,
            missing_orbit_indices=semantic_row.missing_orbit_indices,
            is_semantic_union=True,
            unique_semantic_path_count=semantic_row.unique_semantic_path_count,
        )
        pairs.append(
            EvaluationPair(
                parent_structure_id=crystal.material_id,
                prototype_family=prototype_family,
                missing_count=semantic_state.missing_count,
                evaluation_pair_id=pair_id,
                random=random_state,
                semantic=semantic_state,
            )
        )
    return tuple(pairs)


def training_states(
    pairs: tuple[EvaluationPair, ...],
    distribution: TrainingDistribution,
) -> tuple[PairedState, ...]:
    if not pairs:
        raise ValueError("training states require evaluation pairs")
    if distribution is TrainingDistribution.RANDOM:
        return tuple(pair.random for pair in pairs)
    if distribution is TrainingDistribution.SEMANTIC_MULTI:
        return tuple(pair.semantic for pair in pairs)
    if distribution is TrainingDistribution.SEMANTIC_SINGLE:
        canonical = pairs[0].semantic
        return tuple(
            replace(
                canonical,
                path_index=index,
                evaluation_pair_id=(
                    f"{canonical.parent_structure_id}:gate1b-single:{index:03d}"
                ),
                example_seed=_seeded_int(
                    "gate1b-single",
                    canonical.parent_structure_id,
                    index,
                    canonical.example_seed,
                ),
            )
            for index in range(len(pairs))
        )
    if distribution is TrainingDistribution.MIXED:
        if len(pairs) % 2:
            raise ValueError("mixed training requires an even number of pairs")
        return tuple(
            pair.random if index % 2 == 0 else pair.semantic
            for index, pair in enumerate(pairs)
        )
    raise TypeError("unsupported training distribution")
