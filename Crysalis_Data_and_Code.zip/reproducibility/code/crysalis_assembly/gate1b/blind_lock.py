from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path


class BlindAccessError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class BlindAccessGrant:
    lock_hash: str
    blind_manifest_sha256: str
    grant_hash: str


def _canonical_json(payload: object) -> str:
    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    )


def _payload_hash(payload: object) -> str:
    return hashlib.sha256(_canonical_json(payload).encode("utf-8")).hexdigest()


def _file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _atomic_json(path: Path, payload: object) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(_canonical_json(payload) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def _read_json(path: Path) -> dict[str, object]:
    try:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise BlindAccessError(f"cannot read {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise BlindAccessError(f"{path} must contain a JSON object")
    return payload


def _read_jsonl(path: Path) -> tuple[dict[str, object], ...]:
    try:
        rows = tuple(
            json.loads(line)
            for line in Path(path).read_text(encoding="utf-8").splitlines()
            if line.strip()
        )
    except (OSError, json.JSONDecodeError) as exc:
        raise BlindAccessError(f"cannot read {path}: {exc}") from exc
    if not rows or any(not isinstance(row, dict) for row in rows):
        raise BlindAccessError(f"{path} must contain JSON objects")
    return rows


def open_public_manifest(path: Path) -> tuple[dict[str, object], ...]:
    rows = _read_jsonl(path)
    invalid = sorted(
        {
            str(row.get("partition", ""))
            for row in rows
            if row.get("partition") not in {"train_fit", "validation"}
        }
    )
    if invalid:
        raise BlindAccessError(
            f"public training manifest contains forbidden partitions: {invalid}"
        )
    return rows


def freeze_blind_lock(
    lock_path: Path,
    *,
    preregistration_path: Path,
    threshold_path: Path,
    split_summary_path: Path,
    public_manifest_path: Path,
    blind_manifest_path: Path,
) -> Path:
    paths = {
        "preregistration": Path(preregistration_path).resolve(),
        "thresholds": Path(threshold_path).resolve(),
        "split_summary": Path(split_summary_path).resolve(),
        "public_manifest": Path(public_manifest_path).resolve(),
        "blind_manifest": Path(blind_manifest_path).resolve(),
    }
    missing = [name for name, path in paths.items() if not path.is_file()]
    if missing:
        raise BlindAccessError(f"cannot freeze lock; missing artifacts: {missing}")
    payload = {
        "schema_version": "1.0.0",
        "artifacts": {
            name: {"path": str(path), "sha256": _file_hash(path)}
            for name, path in sorted(paths.items())
        },
    }
    lock = {**payload, "lock_hash": _payload_hash(payload)}
    lock_path = Path(lock_path)
    _atomic_json(lock_path, lock)
    return lock_path


def _verified_lock(lock_path: Path) -> dict[str, object]:
    lock = _read_json(lock_path)
    claimed = str(lock.get("lock_hash", ""))
    payload = {key: value for key, value in lock.items() if key != "lock_hash"}
    if not claimed or _payload_hash(payload) != claimed:
        raise BlindAccessError("blind lock hash mismatch")
    artifacts = lock.get("artifacts")
    if not isinstance(artifacts, dict):
        raise BlindAccessError("blind lock artifact ledger is missing")
    for name, raw in artifacts.items():
        if not isinstance(raw, dict):
            raise BlindAccessError(f"blind lock entry {name} is malformed")
        path = Path(str(raw.get("path", "")))
        expected = str(raw.get("sha256", ""))
        if not path.is_file() or _file_hash(path) != expected:
            raise BlindAccessError(f"artifact hash mismatch: {name}")
    return lock


def _require_receipt(path: Path, label: str, expected: str) -> str:
    receipt = _read_json(path)
    if receipt.get("status") != expected:
        raise BlindAccessError(f"{label} receipt is not {expected}")
    return _file_hash(path)


def grant_blind_access(
    lock_path: Path,
    *,
    run_matrix_receipt: Path,
    validation_receipt: Path,
    code_audit_receipt: Path,
    output_hash_receipt: Path,
    access_receipt_path: Path,
) -> BlindAccessGrant:
    access_receipt_path = Path(access_receipt_path)
    if access_receipt_path.exists():
        raise BlindAccessError("blind access has already been granted")
    lock = _verified_lock(lock_path)
    receipt_hashes = {
        "run_matrix": _require_receipt(run_matrix_receipt, "run matrix", "complete"),
        "validation": _require_receipt(validation_receipt, "validation", "frozen"),
        "code_audit": _require_receipt(code_audit_receipt, "code audit", "pass"),
        "output_hashes": _require_receipt(output_hash_receipt, "output hash", "complete"),
    }
    artifacts = lock["artifacts"]
    assert isinstance(artifacts, dict)
    blind = artifacts["blind_manifest"]
    assert isinstance(blind, dict)
    payload = {
        "schema_version": "1.0.0",
        "lock_hash": lock["lock_hash"],
        "blind_manifest_sha256": blind["sha256"],
        "receipt_hashes": receipt_hashes,
        "granted_at_utc": datetime.now(UTC).isoformat(),
    }
    grant_hash = _payload_hash(payload)
    _atomic_json(access_receipt_path, {**payload, "grant_hash": grant_hash})
    return BlindAccessGrant(
        lock_hash=str(lock["lock_hash"]),
        blind_manifest_sha256=str(blind["sha256"]),
        grant_hash=grant_hash,
    )


def open_blind_manifest(
    path: Path, grant: BlindAccessGrant
) -> tuple[dict[str, object], ...]:
    if _file_hash(path) != grant.blind_manifest_sha256:
        raise BlindAccessError("blind manifest does not match the access grant")
    rows = _read_jsonl(path)
    invalid = sorted(
        {
            str(row.get("partition", ""))
            for row in rows
            if row.get("partition") not in {"iid_test", "blind_ood"}
        }
    )
    if invalid:
        raise BlindAccessError(f"sealed manifest contains invalid partitions: {invalid}")
    return rows
