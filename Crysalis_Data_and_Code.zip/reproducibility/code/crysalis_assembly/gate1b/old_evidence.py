from __future__ import annotations

import json
from collections import Counter, defaultdict
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path

import numpy as np


class EvidenceError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class SeedEffect:
    seed: int
    m1: float
    m3: float
    difference: float


@dataclass(frozen=True, slots=True)
class OldGate1Recalculation:
    test_rows: int
    iid_rows: int
    m1_ood_micro: float
    m3_ood_micro: float
    absolute_gain: float
    m1_family_macro: float
    m3_family_macro: float
    paired_family_difference: float
    bootstrap_lower_95: float
    bootstrap_upper_95: float
    family_count: int
    per_seed: tuple[SeedEffect, ...]
    iid_m1_micro: float
    iid_m3_micro: float
    m3_failure_counts: tuple[tuple[str, int], ...]


@dataclass(frozen=True, slots=True)
class EvidenceDifference:
    metric: str
    recomputed: float
    frozen: float


def _as_int(value: object, *, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, str)):
        raise EvidenceError(f"{label} must be an integer")
    try:
        return int(value)
    except ValueError as exc:
        raise EvidenceError(f"{label} must be an integer") from exc


def _read_jsonl(path: Path) -> tuple[dict[str, object], ...]:
    try:
        rows = tuple(
            json.loads(line)
            for line in Path(path).read_text(encoding="utf-8").splitlines()
            if line.strip()
        )
    except (OSError, json.JSONDecodeError) as exc:
        raise EvidenceError(f"cannot read evidence {path}: {exc}") from exc
    if not rows or any(not isinstance(row, dict) for row in rows):
        raise EvidenceError(f"evidence {path} must contain JSON objects")
    return rows


def _variant(
    rows: tuple[dict[str, object], ...], name: str
) -> tuple[dict[str, object], ...]:
    selected = tuple(row for row in rows if row.get("variant") == name)
    if not selected:
        raise EvidenceError(f"paired M1/M3 keys do not match: no {name} rows")
    return selected


def _strict_rate(rows: tuple[dict[str, object], ...]) -> float:
    return sum(bool(row.get("strict_success")) for row in rows) / len(rows)


def _family_macro(rows: tuple[dict[str, object], ...]) -> float:
    by_family: dict[str, list[float]] = defaultdict(list)
    for row in rows:
        family = str(row.get("prototype_family", ""))
        if not family:
            raise EvidenceError("evidence row has no prototype family")
        by_family[family].append(float(bool(row.get("strict_success"))))
    return float(np.mean([np.mean(values) for values in by_family.values()]))


def _index(
    rows: tuple[dict[str, object], ...]
) -> dict[tuple[str, int, int], dict[str, object]]:
    indexed: dict[tuple[str, int, int], dict[str, object]] = {}
    for row in rows:
        key = (
            str(row.get("material_id", "")),
            _as_int(row.get("path_index", -1), label="path_index"),
            _as_int(row.get("seed", -1), label="seed"),
        )
        if not key[0] or key[1] < 0 or key[2] < 0:
            raise EvidenceError(f"invalid paired evidence key {key}")
        if key in indexed:
            raise EvidenceError(f"duplicate paired evidence key {key}")
        indexed[key] = row
    return indexed


def _require_pairs(
    m1: tuple[dict[str, object], ...], m3: tuple[dict[str, object], ...]
) -> tuple[
    dict[tuple[str, int, int], dict[str, object]],
    dict[tuple[str, int, int], dict[str, object]],
]:
    left = _index(m1)
    right = _index(m3)
    if set(left) != set(right):
        raise EvidenceError("paired M1/M3 keys do not match")
    return left, right


def recompute_old_gate1(
    test_jsonl: Path,
    iid_jsonl: Path,
    *,
    draws: int,
    seed: int,
) -> OldGate1Recalculation:
    if draws <= 0:
        raise ValueError("draws must be positive")
    test_rows = _read_jsonl(test_jsonl)
    iid_rows = _read_jsonl(iid_jsonl)
    m1 = _variant(test_rows, "m1")
    m3 = _variant(test_rows, "m3")
    m1_index, m3_index = _require_pairs(m1, m3)

    family_differences: dict[str, list[float]] = defaultdict(list)
    for key in sorted(m1_index):
        left = m1_index[key]
        right = m3_index[key]
        family = str(right.get("prototype_family", ""))
        if family != str(left.get("prototype_family", "")):
            raise EvidenceError(f"paired family mismatch for {key}")
        family_differences[family].append(
            float(bool(right.get("strict_success")))
            - float(bool(left.get("strict_success")))
        )
    family_means = np.asarray(
        [np.mean(values) for _, values in sorted(family_differences.items())],
        dtype=float,
    )
    rng = np.random.default_rng(seed)
    sampled = rng.choice(
        family_means, size=(draws, len(family_means)), replace=True
    ).mean(axis=1)
    quantiles = np.asarray(np.quantile(sampled, (0.025, 0.975)), dtype=float)
    lower = float(quantiles[0])
    upper = float(quantiles[1])

    seeds = sorted({key[2] for key in m1_index})
    per_seed = tuple(
        SeedEffect(
            seed=item,
            m1=_strict_rate(
                tuple(row for row in m1 if _as_int(row["seed"], label="seed") == item)
            ),
            m3=_strict_rate(
                tuple(row for row in m3 if _as_int(row["seed"], label="seed") == item)
            ),
            difference=(
                _strict_rate(
                    tuple(
                        row
                        for row in m3
                        if _as_int(row["seed"], label="seed") == item
                    )
                )
                - _strict_rate(
                    tuple(
                        row
                        for row in m1
                        if _as_int(row["seed"], label="seed") == item
                    )
                )
            ),
        )
        for item in seeds
    )
    iid_m1 = _variant(iid_rows, "m1")
    iid_m3 = _variant(iid_rows, "m3")
    _require_pairs(iid_m1, iid_m3)
    failures: Counter[str] = Counter()
    for row in m3:
        reasons = row.get("failure_reasons", ())
        if not isinstance(reasons, Sequence) or isinstance(reasons, (str, bytes)):
            raise EvidenceError("failure_reasons must be a sequence")
        failures.update(str(reason) for reason in reasons)

    return OldGate1Recalculation(
        test_rows=len(test_rows),
        iid_rows=len(iid_rows),
        m1_ood_micro=_strict_rate(m1),
        m3_ood_micro=_strict_rate(m3),
        absolute_gain=_strict_rate(m3) - _strict_rate(m1),
        m1_family_macro=_family_macro(m1),
        m3_family_macro=_family_macro(m3),
        paired_family_difference=float(family_means.mean()),
        bootstrap_lower_95=lower,
        bootstrap_upper_95=upper,
        family_count=len(family_means),
        per_seed=per_seed,
        iid_m1_micro=_strict_rate(iid_m1),
        iid_m3_micro=_strict_rate(iid_m3),
        m3_failure_counts=tuple(sorted(failures.items())),
    )


def compare_frozen_decision(
    recalculation: OldGate1Recalculation,
    decision_json: Path,
    *,
    tolerance: float = 1e-15,
) -> tuple[EvidenceDifference, ...]:
    try:
        payload = json.loads(Path(decision_json).read_text(encoding="utf-8"))
        decision = payload["decision"]
        bootstrap = decision["bootstrap"]
    except (OSError, json.JSONDecodeError, KeyError, TypeError) as exc:
        raise EvidenceError(f"cannot read frozen decision: {exc}") from exc
    pairs = (
        ("m1_ood_micro", recalculation.m1_ood_micro, decision["baseline_ood_strict_success"]),
        ("m3_ood_micro", recalculation.m3_ood_micro, decision["m3_ood_strict_success"]),
        ("absolute_gain", recalculation.absolute_gain, decision["absolute_gain"]),
        ("iid_m1_micro", recalculation.iid_m1_micro, decision["baseline_iid_strict_success"]),
        ("iid_m3_micro", recalculation.iid_m3_micro, decision["m3_iid_strict_success"]),
        ("paired_family_difference", recalculation.paired_family_difference, bootstrap["mean_difference"]),
        ("bootstrap_lower_95", recalculation.bootstrap_lower_95, bootstrap["lower_95"]),
        ("bootstrap_upper_95", recalculation.bootstrap_upper_95, bootstrap["upper_95"]),
    )
    return tuple(
        EvidenceDifference(metric, float(observed), float(frozen))
        for metric, observed, frozen in pairs
        if abs(float(observed) - float(frozen)) > tolerance
    )
