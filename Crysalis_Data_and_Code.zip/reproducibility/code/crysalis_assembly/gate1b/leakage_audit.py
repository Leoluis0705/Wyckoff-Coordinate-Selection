from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping
from dataclasses import dataclass, replace
import hashlib
from itertools import combinations
import warnings

from pymatgen.analysis.structure_matcher import StructureMatcher

from ..experiments.symmetry import CanonicalCrystal
from .fresh_split import FreshCandidate, FreshPartition, FreshSplitEntry


@dataclass(frozen=True, slots=True)
class Gate1bLeakageAudit:
    duplicate_material_ids: int
    prototype_family_forbidden_overlap: int
    exact_structure_hash_overlap: int
    reduced_formula_overlap_counts: tuple[tuple[str, str, int], ...]
    confirmed_near_duplicate_cross_partition: int
    blind_ood_near_duplicate_count: int

    @property
    def passes(self) -> bool:
        return (
            self.duplicate_material_ids == 0
            and self.prototype_family_forbidden_overlap == 0
            and self.exact_structure_hash_overlap == 0
            and self.blind_ood_near_duplicate_count == 0
        )


def _matcher_fit(
    matcher: StructureMatcher, left: CanonicalCrystal, right: CanonicalCrystal
) -> bool:
    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            message="Set OLD_ERROR_HANDLING to false and catch the errors directly.*",
            category=DeprecationWarning,
        )
        return bool(matcher.fit(left.structure, right.structure))


def merge_near_duplicate_families(
    candidates: tuple[FreshCandidate, ...],
    crystals_by_id: Mapping[str, CanonicalCrystal],
) -> tuple[FreshCandidate, ...]:
    """Co-group exact-composition near duplicates before any split is assigned."""
    by_id = {row.material_id: row for row in candidates}
    if set(by_id) != set(crystals_by_id):
        raise ValueError("candidate and canonical-crystal IDs differ")
    parent = {family: family for family in {row.prototype_family for row in candidates}}

    def find(family: str) -> str:
        while parent[family] != family:
            parent[family] = parent[parent[family]]
            family = parent[family]
        return family

    def union(left: str, right: str) -> None:
        left_root = find(left)
        right_root = find(right)
        if left_root == right_root:
            return
        first, second = sorted((left_root, right_root))
        parent[second] = first

    buckets: dict[tuple[str, int], list[FreshCandidate]] = defaultdict(list)
    for row in candidates:
        buckets[(row.reduced_formula, row.space_group)].append(row)
    matcher = StructureMatcher(
        primitive_cell=False,
        scale=True,
        attempt_supercell=False,
        ltol=0.2,
        stol=0.3,
        angle_tol=5.0,
    )
    for members in buckets.values():
        for left, right in combinations(members, 2):
            if find(left.prototype_family) == find(right.prototype_family):
                continue
            if _matcher_fit(
                matcher,
                crystals_by_id[left.material_id],
                crystals_by_id[right.material_id],
            ):
                union(left.prototype_family, right.prototype_family)

    components: dict[str, set[str]] = defaultdict(set)
    for family in parent:
        components[find(family)].add(family)
    label_by_family: dict[str, str] = {}
    for families in components.values():
        if len(families) == 1:
            label = next(iter(families))
        else:
            digest = hashlib.sha256("|".join(sorted(families)).encode()).hexdigest()[:20]
            label = f"proto-merged-{digest}"
        for family in families:
            label_by_family[family] = label
    return tuple(
        replace(row, prototype_family=label_by_family[row.prototype_family])
        for row in sorted(candidates, key=lambda item: item.material_id)
    )


def find_confirmed_near_duplicate_pairs(
    entries: tuple[FreshSplitEntry, ...],
    crystals_by_id: Mapping[str, CanonicalCrystal],
) -> tuple[tuple[str, str], ...]:
    by_bucket: dict[tuple[str, int], list[FreshSplitEntry]] = defaultdict(list)
    for row in entries:
        if row.material_id not in crystals_by_id:
            raise ValueError(f"missing canonical crystal {row.material_id}")
        by_bucket[(row.reduced_formula, row.space_group)].append(row)
    matcher = StructureMatcher(
        primitive_cell=False,
        scale=True,
        attempt_supercell=False,
        ltol=0.2,
        stol=0.3,
        angle_tol=5.0,
    )
    confirmed: set[tuple[str, str]] = set()
    for members in by_bucket.values():
        for left, right in combinations(members, 2):
            if left.partition is right.partition:
                continue
            pair = (
                min(left.material_id, right.material_id),
                max(left.material_id, right.material_id),
            )
            if left.structure_hash == right.structure_hash:
                confirmed.add(pair)
                continue
            with warnings.catch_warnings():
                warnings.filterwarnings(
                    "ignore",
                    message="Set OLD_ERROR_HANDLING to false and catch the errors directly.*",
                    category=DeprecationWarning,
                )
                if _matcher_fit(
                    matcher,
                    crystals_by_id[left.material_id],
                    crystals_by_id[right.material_id],
                ):
                    confirmed.add(pair)
    return tuple(sorted(confirmed))


def audit_gate1b_split(
    entries: tuple[FreshSplitEntry, ...],
    *,
    confirmed_near_duplicate_pairs: tuple[tuple[str, str], ...] = (),
) -> Gate1bLeakageAudit:
    if not entries:
        raise ValueError("cannot audit an empty Gate 1b split")
    by_id = {row.material_id: row for row in entries}
    duplicate_ids = len(entries) - len(by_id)

    by_family: dict[str, set[FreshPartition]] = defaultdict(set)
    by_hash: dict[str, set[FreshPartition]] = defaultdict(set)
    by_formula: dict[str, set[FreshPartition]] = defaultdict(set)
    for row in entries:
        by_family[row.prototype_family].add(row.partition)
        by_hash[row.structure_hash].add(row.partition)
        by_formula[row.reduced_formula].add(row.partition)
    allowed_family_sets = {
        frozenset((FreshPartition.TRAIN_FIT,)),
        frozenset((FreshPartition.TRAIN_FIT, FreshPartition.IID_TEST)),
        frozenset((FreshPartition.VALIDATION,)),
        frozenset((FreshPartition.BLIND_OOD,)),
    }
    forbidden_family = sum(
        frozenset(partitions) not in allowed_family_sets
        for partitions in by_family.values()
    )
    exact_overlap = sum(len(partitions) > 1 for partitions in by_hash.values())

    formula_counts = []
    for left, right in combinations(FreshPartition, 2):
        count = sum(
            left in partitions and right in partitions
            for partitions in by_formula.values()
        )
        formula_counts.append((left.value, right.value, count))

    normalized_pairs = {
        (min(pair), max(pair)) for pair in confirmed_near_duplicate_pairs
    }
    unknown = {
        material_id
        for pair in normalized_pairs
        for material_id in pair
        if material_id not in by_id
    }
    if unknown:
        raise ValueError(f"near-duplicate pairs contain unknown IDs: {sorted(unknown)}")
    cross_pairs = {
        pair
        for pair in normalized_pairs
        if by_id[pair[0]].partition != by_id[pair[1]].partition
    }
    blind_pairs = {
        pair
        for pair in cross_pairs
        if FreshPartition.BLIND_OOD
        in (by_id[pair[0]].partition, by_id[pair[1]].partition)
    }
    return Gate1bLeakageAudit(
        duplicate_material_ids=duplicate_ids,
        prototype_family_forbidden_overlap=forbidden_family,
        exact_structure_hash_overlap=exact_overlap,
        reduced_formula_overlap_counts=tuple(formula_counts),
        confirmed_near_duplicate_cross_partition=len(cross_pairs),
        blind_ood_near_duplicate_count=len(blind_pairs),
    )
