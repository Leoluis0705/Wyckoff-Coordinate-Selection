from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from enum import Enum

import numpy as np


class AnalysisError(ValueError):
    pass


class SignalStatus(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    INCONCLUSIVE = "INCONCLUSIVE"


@dataclass(frozen=True, slots=True)
class StrictOutcome:
    parent_structure_id: str
    prototype_family: str
    evaluation_pair_id: str
    evaluation_type: str
    training_arm: str
    seed: int
    strict_success: bool
    site_count: int
    missing_count: int
    space_group: int


@dataclass(frozen=True, slots=True)
class SignalThresholds:
    minimum_ood_families: int
    bootstrap_draws: int
    bootstrap_seed: int
    minimum_family_macro_gain: float
    minimum_micro_gain: float
    minimum_positive_seeds: int
    maximum_er_micro_degradation: float
    maximum_er_family_macro_degradation: float
    reversal_minimum_pairs: int
    reversal_ci_upper_floor: float


@dataclass(frozen=True, slots=True)
class SignalDecision:
    status: SignalStatus
    family_count: int
    micro_effect: float
    family_macro_effect: float
    bootstrap_lower_95: float
    bootstrap_upper_95: float
    positive_seed_directions: int
    er_micro_effect: float
    er_family_macro_effect: float
    odds_ratio: float
    relative_success_increase: float | None
    failed_checks: tuple[str, ...]
    inconclusive_reasons: tuple[str, ...]


def _index(
    rows: tuple[StrictOutcome, ...], arm: str, evaluation_type: str
) -> dict[tuple[str, str, int], StrictOutcome]:
    index: dict[tuple[str, str, int], StrictOutcome] = {}
    for row in rows:
        if row.training_arm != arm or row.evaluation_type != evaluation_type:
            continue
        key = (row.parent_structure_id, row.evaluation_pair_id, row.seed)
        if key in index:
            raise AnalysisError(f"duplicate paired outcome key {key}")
        index[key] = row
    if not index:
        raise AnalysisError(f"no outcomes for {arm}/{evaluation_type}")
    return index


def _paired_differences(
    rows: tuple[StrictOutcome, ...], evaluation_type: str
) -> tuple[np.ndarray, dict[str, list[float]], dict[int, list[float]], tuple[StrictOutcome, ...], tuple[StrictOutcome, ...]]:
    random = _index(rows, "T-R", evaluation_type)
    semantic = _index(rows, "T-S-multi", evaluation_type)
    if set(random) != set(semantic):
        raise AnalysisError(f"paired keys differ on {evaluation_type}")
    by_family: dict[str, list[float]] = defaultdict(list)
    by_seed: dict[int, list[float]] = defaultdict(list)
    differences = []
    random_rows = []
    semantic_rows = []
    for key in sorted(random):
        left = random[key]
        right = semantic[key]
        metadata_left = (
            left.prototype_family,
            left.site_count,
            left.missing_count,
            left.space_group,
        )
        metadata_right = (
            right.prototype_family,
            right.site_count,
            right.missing_count,
            right.space_group,
        )
        if metadata_left != metadata_right:
            raise AnalysisError(f"paired metadata differ for {key}")
        value = float(right.strict_success) - float(left.strict_success)
        differences.append(value)
        by_family[right.prototype_family].append(value)
        by_seed[right.seed].append(value)
        random_rows.append(left)
        semantic_rows.append(right)
    return (
        np.asarray(differences, dtype=float),
        by_family,
        by_seed,
        tuple(random_rows),
        tuple(semantic_rows),
    )


def _bootstrap(
    family_values: dict[str, list[float]], *, draws: int, seed: int
) -> tuple[float, float, float]:
    means = np.asarray(
        [np.mean(values) for _, values in sorted(family_values.items())], dtype=float
    )
    rng = np.random.default_rng(seed)
    sampled = rng.choice(means, size=(draws, len(means)), replace=True).mean(axis=1)
    quantiles = np.asarray(np.quantile(sampled, (0.025, 0.975)), dtype=float)
    return float(means.mean()), float(quantiles[0]), float(quantiles[1])


def _site_bin(site_count: int) -> str:
    if site_count <= 8:
        return "N<=8"
    if site_count <= 16:
        return "9<=N<=16"
    if site_count <= 32:
        return "17<=N<=32"
    return "N>32"


def scientific_signal_decision(
    rows: tuple[StrictOutcome, ...],
    thresholds: SignalThresholds,
    *,
    adjusted_semantic_coefficient: float | None,
) -> SignalDecision:
    (
        es_differences,
        es_families,
        es_seeds,
        es_random,
        es_semantic,
    ) = _paired_differences(rows, "E-S")
    er_differences, er_families, _, _, _ = _paired_differences(rows, "E-R")
    family_effect, lower, upper = _bootstrap(
        es_families,
        draws=thresholds.bootstrap_draws,
        seed=thresholds.bootstrap_seed,
    )
    er_family_effect, _, _ = _bootstrap(
        er_families,
        draws=thresholds.bootstrap_draws,
        seed=thresholds.bootstrap_seed,
    )
    positive_seeds = int(
        sum(bool(np.mean(values) > 0) for values in es_seeds.values())
    )

    by_site: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    for left, right, difference in zip(
        es_random, es_semantic, es_differences, strict=True
    ):
        label = _site_bin(right.site_count)
        by_site[label][right.prototype_family].append(float(difference))
    systematic_reversal = False
    for family_values in by_site.values():
        pair_count = sum(len(values) for values in family_values.values())
        if pair_count < thresholds.reversal_minimum_pairs:
            continue
        _, _, stratum_upper = _bootstrap(
            family_values,
            draws=thresholds.bootstrap_draws,
            seed=thresholds.bootstrap_seed,
        )
        systematic_reversal |= (
            stratum_upper < thresholds.reversal_ci_upper_floor
        )

    micro_effect = float(es_differences.mean())
    er_micro_effect = float(er_differences.mean())
    checks = {
        "clustered_ci_lower_positive": lower > 0.0,
        "minimum_family_macro_gain": family_effect
        >= thresholds.minimum_family_macro_gain,
        "minimum_micro_gain": micro_effect >= thresholds.minimum_micro_gain,
        "positive_seed_directions": positive_seeds
        >= thresholds.minimum_positive_seeds,
        "E-R_micro_noninferiority": er_micro_effect
        >= -thresholds.maximum_er_micro_degradation,
        "E-R_family_macro_noninferiority": er_family_effect
        >= -thresholds.maximum_er_family_macro_degradation,
        "no_systematic_site_count_reversal": not systematic_reversal,
    }
    failed = tuple(name for name, passed in checks.items() if not passed)
    inconclusive = []
    if len(es_families) < thresholds.minimum_ood_families:
        inconclusive.append("minimum_ood_families")
    if adjusted_semantic_coefficient is None or adjusted_semantic_coefficient < 0:
        inconclusive.append("adjusted_semantic_coefficient")
    if failed:
        status = SignalStatus.FAIL
    elif inconclusive:
        status = SignalStatus.INCONCLUSIVE
    else:
        status = SignalStatus.PASS

    semantic_success = sum(row.strict_success for row in es_semantic)
    random_success = sum(row.strict_success for row in es_random)
    semantic_failure = len(es_semantic) - semantic_success
    random_failure = len(es_random) - random_success
    odds_ratio = (
        ((semantic_success + 0.5) / (semantic_failure + 0.5))
        / ((random_success + 0.5) / (random_failure + 0.5))
    )
    random_rate = random_success / len(es_random)
    semantic_rate = semantic_success / len(es_semantic)
    relative_success = (
        semantic_rate / random_rate - 1.0 if random_rate > 0 else None
    )
    return SignalDecision(
        status=status,
        family_count=len(es_families),
        micro_effect=micro_effect,
        family_macro_effect=family_effect,
        bootstrap_lower_95=lower,
        bootstrap_upper_95=upper,
        positive_seed_directions=positive_seeds,
        er_micro_effect=er_micro_effect,
        er_family_macro_effect=er_family_effect,
        odds_ratio=float(odds_ratio),
        relative_success_increase=relative_success,
        failed_checks=failed,
        inconclusive_reasons=tuple(inconclusive),
    )
