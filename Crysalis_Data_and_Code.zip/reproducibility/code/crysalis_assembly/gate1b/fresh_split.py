from __future__ import annotations

import hashlib
import json
import math
import os
from collections import defaultdict
from collections.abc import Sequence
from dataclasses import asdict
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from ..experiments.splits import assign_verified_families
from ..experiments.symmetry import CanonicalCrystal


class FreshPartition(str, Enum):
    TRAIN_FIT = "train_fit"
    VALIDATION = "validation"
    IID_TEST = "iid_test"
    BLIND_OOD = "blind_ood"


@dataclass(frozen=True, slots=True)
class FreshCandidate:
    material_id: str
    prototype_family: str
    reduced_formula: str
    structure_hash: str
    site_count: int
    space_group: int

    def __post_init__(self) -> None:
        if not all(
            (
                self.material_id,
                self.prototype_family,
                self.reduced_formula,
                self.structure_hash,
            )
        ):
            raise ValueError("fresh candidate identity fields must be non-empty")
        if self.site_count <= 0 or not 1 <= self.space_group <= 230:
            raise ValueError("fresh candidate crystallographic fields are invalid")


@dataclass(frozen=True, slots=True)
class FreshSplitEntry:
    material_id: str
    prototype_family: str
    reduced_formula: str
    structure_hash: str
    site_count: int
    space_group: int
    partition: FreshPartition

    @classmethod
    def from_candidate(
        cls, candidate: FreshCandidate, partition: FreshPartition
    ) -> FreshSplitEntry:
        return cls(
            material_id=candidate.material_id,
            prototype_family=candidate.prototype_family,
            reduced_formula=candidate.reduced_formula,
            structure_hash=candidate.structure_hash,
            site_count=candidate.site_count,
            space_group=candidate.space_group,
            partition=partition,
        )


@dataclass(frozen=True, slots=True)
class Gate1bSplit:
    entries: tuple[FreshSplitEntry, ...]
    excluded_old_selected: int
    excluded_old_test_family: int


@dataclass(frozen=True, slots=True)
class SplitArtifacts:
    public_path: Path
    blind_path: Path
    summary_path: Path
    public_sha256: str
    blind_sha256: str


def joint_fresh_candidates(
    crystals: Sequence[CanonicalCrystal],
) -> tuple[FreshCandidate, ...]:
    families = assign_verified_families(crystals)
    return tuple(
        FreshCandidate(
            material_id=crystal.material_id,
            prototype_family=families[crystal.material_id],
            reduced_formula=crystal.reduced_formula,
            structure_hash=crystal.structure_hash,
            site_count=crystal.site_count,
            space_group=crystal.space_group,
        )
        for crystal in sorted(crystals, key=lambda item: item.material_id)
    )


def _rank(seed: int, label: str) -> str:
    return hashlib.sha256(f"{seed}:{label}".encode("utf-8")).hexdigest()


def build_fresh_split(
    candidates: tuple[FreshCandidate, ...],
    *,
    old_selected_ids: set[str],
    old_test_ids: set[str],
    seed: int,
    iid_fraction: float,
) -> Gate1bSplit:
    if len({row.material_id for row in candidates}) != len(candidates):
        raise ValueError("fresh candidates contain duplicate material IDs")
    if not old_test_ids.issubset({row.material_id for row in candidates}):
        raise ValueError("old test IDs are absent from joint family candidates")
    if not 0 < iid_fraction < 1:
        raise ValueError("iid_fraction must lie in (0, 1)")

    family_by_id = {row.material_id: row.prototype_family for row in candidates}
    forbidden_families = {family_by_id[material_id] for material_id in old_test_ids}
    excluded_old_selected = sum(
        row.material_id in old_selected_ids for row in candidates
    )
    excluded_old_test_family = sum(
        row.material_id not in old_selected_ids
        and row.prototype_family in forbidden_families
        for row in candidates
    )
    eligible = tuple(
        row
        for row in candidates
        if row.material_id not in old_selected_ids
        and row.prototype_family not in forbidden_families
    )
    if not eligible:
        raise ValueError("fresh split has no eligible candidates")

    families: dict[str, list[FreshCandidate]] = defaultdict(list)
    for row in eligible:
        families[row.prototype_family].append(row)
    family_pools = ("train", "validation", "blind_ood")
    ratios = {"train": 0.70, "validation": 0.15, "blind_ood": 0.15}
    targets = {name: ratios[name] * len(eligible) for name in family_pools}
    counts = {name: 0 for name in family_pools}
    assignment: dict[str, str] = {}
    ranked = sorted(
        families.items(),
        key=lambda item: (-len(item[1]), _rank(seed, item[0]), item[0]),
    )
    for family, members in ranked:
        chosen = max(
            family_pools,
            key=lambda name: (
                (targets[name] - counts[name]) / max(targets[name], 1.0),
                -family_pools.index(name),
            ),
        )
        assignment[family] = chosen
        counts[chosen] += len(members)

    entries: list[FreshSplitEntry] = []
    for family, members in sorted(families.items()):
        pool = assignment[family]
        ordered = sorted(
            members,
            key=lambda row: (_rank(seed, row.material_id), row.material_id),
        )
        iid_ids: set[str] = set()
        if pool == "train" and len(ordered) >= 3:
            requested = max(1, math.floor(iid_fraction * len(ordered)))
            iid_ids = {
                row.material_id for row in ordered[: min(len(ordered) - 1, requested)]
            }
        for row in ordered:
            if row.material_id in iid_ids:
                partition = FreshPartition.IID_TEST
            elif pool == "train":
                partition = FreshPartition.TRAIN_FIT
            elif pool == "validation":
                partition = FreshPartition.VALIDATION
            else:
                partition = FreshPartition.BLIND_OOD
            entries.append(FreshSplitEntry.from_candidate(row, partition))

    observed = {entry.partition for entry in entries}
    if observed != set(FreshPartition):
        raise ValueError(f"fresh split is missing partitions: {set(FreshPartition) - observed}")
    return Gate1bSplit(
        entries=tuple(sorted(entries, key=lambda row: row.material_id)),
        excluded_old_selected=excluded_old_selected,
        excluded_old_test_family=excluded_old_test_family,
    )


def _canonical_json(payload: object) -> str:
    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _atomic_text(path: Path, text: str) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(text, encoding="utf-8", newline="\n")
    os.replace(temporary, path)


def _entry_payload(entry: FreshSplitEntry) -> dict[str, object]:
    payload = asdict(entry)
    payload["partition"] = entry.partition.value
    return payload


def write_split_artifacts(split: Gate1bSplit, output_dir: Path) -> SplitArtifacts:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    public_path = output_dir / "gate1b_public_manifest.jsonl"
    blind_path = output_dir / "gate1b_blind_manifest.jsonl"
    summary_path = output_dir / "gate1b_split_manifest.json"
    public = tuple(
        row
        for row in split.entries
        if row.partition in {FreshPartition.TRAIN_FIT, FreshPartition.VALIDATION}
    )
    blind = tuple(
        row
        for row in split.entries
        if row.partition in {FreshPartition.IID_TEST, FreshPartition.BLIND_OOD}
    )
    if not public or not blind:
        raise ValueError("split artifacts require public and blind rows")
    _atomic_text(
        public_path,
        "".join(_canonical_json(_entry_payload(row)) + "\n" for row in public),
    )
    _atomic_text(
        blind_path,
        "".join(_canonical_json(_entry_payload(row)) + "\n" for row in blind),
    )
    public_hash = _sha256(public_path)
    blind_hash = _sha256(blind_path)
    counts = {
        partition.value: sum(row.partition is partition for row in split.entries)
        for partition in FreshPartition
    }
    summary = {
        "schema_version": "1.0.0",
        "counts": counts,
        "excluded_old_selected": split.excluded_old_selected,
        "excluded_old_test_family": split.excluded_old_test_family,
        "public_manifest_sha256": public_hash,
        "blind_manifest_sha256": blind_hash,
    }
    _atomic_text(summary_path, _canonical_json(summary) + "\n")
    return SplitArtifacts(
        public_path=public_path,
        blind_path=blind_path,
        summary_path=summary_path,
        public_sha256=public_hash,
        blind_sha256=blind_hash,
    )
