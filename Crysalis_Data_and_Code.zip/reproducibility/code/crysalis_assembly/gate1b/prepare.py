from __future__ import annotations

import argparse
import json
from collections import Counter
from collections.abc import Callable, Sequence
from dataclasses import asdict, dataclass
from pathlib import Path

from ..experiments.deconstruction import DeconstructionError, semantic_paths
from ..experiments.mp20 import MP20Record, load_mp20_records
from ..experiments.symmetry import (
    CanonicalCrystal,
    StructureRejection,
    canonicalize_record,
)
from .blind_lock import freeze_blind_lock
from .fresh_split import (
    Gate1bSplit,
    build_fresh_split,
    joint_fresh_candidates,
    write_split_artifacts,
)
from .leakage_audit import (
    Gate1bLeakageAudit,
    audit_gate1b_split,
    find_confirmed_near_duplicate_pairs,
    merge_near_duplicate_families,
)


class PreparationError(ValueError):
    """Raised when Gate 1b cannot be frozen without violating its protocol."""


@dataclass(frozen=True, slots=True)
class HistoricalContract:
    old_selected_ids: frozenset[str]
    old_test_ids: frozenset[str]
    source_hashes: tuple[tuple[str, str], ...]


@dataclass(frozen=True, slots=True)
class PreparationSummary:
    source_records: int
    joint_records: int
    canonical_joint_records: int
    semantic_eligible_joint_records: int
    old_selected_records: int
    old_test_records: int
    fresh_split_records: int
    family_count: int
    partition_counts: tuple[tuple[str, int], ...]
    rejection_counts: tuple[tuple[str, int], ...]
    leakage_pass: bool
    max_sites: int
    unavailable_site_count_bins: tuple[str, ...]


def _read_object(path: Path) -> dict[str, object]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise PreparationError(f"cannot read {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise PreparationError(f"{path} must contain a JSON object")
    return payload


def _read_objects(path: Path) -> tuple[dict[str, object], ...]:
    try:
        rows = tuple(
            json.loads(line)
            for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        )
    except (OSError, json.JSONDecodeError) as exc:
        raise PreparationError(f"cannot read {path}: {exc}") from exc
    if any(not isinstance(row, dict) for row in rows):
        raise PreparationError(f"{path} must contain JSON objects")
    return rows


def load_historical_contract(gate0_dir: Path) -> HistoricalContract:
    gate0_dir = Path(gate0_dir)
    source = _read_object(gate0_dir / "source_manifest.json")
    corruption_rows = _read_objects(gate0_dir / "corruption_manifest.jsonl")
    selected_raw = source.get("selected_material_ids")
    hashes_raw = source.get("sha256_by_file")
    if not isinstance(selected_raw, list) or not selected_raw:
        raise PreparationError("old source manifest has no selected material IDs")
    if not isinstance(hashes_raw, list):
        raise PreparationError("old source manifest has no source hash ledger")
    try:
        source_hashes = tuple(
            sorted((str(name), str(value)) for name, value in hashes_raw)
        )
    except (TypeError, ValueError) as exc:
        raise PreparationError("old source hash ledger is malformed") from exc
    old_selected_ids = frozenset(str(value) for value in selected_raw)
    old_test_ids = frozenset(
        str(row.get("parent_material_id", ""))
        for row in corruption_rows
        if row.get("split") == "test" and row.get("variant") == "m3"
    )
    if not old_test_ids or not old_test_ids.issubset(old_selected_ids):
        raise PreparationError("old test IDs are missing or outside the old selection")
    return HistoricalContract(
        old_selected_ids=old_selected_ids,
        old_test_ids=old_test_ids,
        source_hashes=source_hashes,
    )


def select_joint_records(
    records: Sequence[MP20Record],
    *,
    old_selected_ids: frozenset[str],
    old_test_ids: frozenset[str],
) -> tuple[MP20Record, ...]:
    by_id = {record.material_id: record for record in records}
    if len(by_id) != len(records):
        raise PreparationError("MP-20 records contain duplicate material IDs")
    absent = sorted(old_test_ids - by_id.keys())
    if absent:
        raise PreparationError(f"old test IDs are absent from MP-20: {absent[:5]}")
    return tuple(
        sorted(
            (
                record
                for record in records
                if record.material_id not in old_selected_ids
                or record.material_id in old_test_ids
            ),
            key=lambda row: row.material_id,
        )
    )


def canonicalize_semantic_eligible(
    records: Sequence[MP20Record],
    *,
    paths_per_parent: int,
    min_fraction: float,
    max_fraction: float,
    seed: int,
    progress: Callable[[int, int], None] | None = None,
) -> tuple[tuple[CanonicalCrystal, ...], tuple[tuple[str, int], ...]]:
    accepted: list[CanonicalCrystal] = []
    rejections: Counter[str] = Counter()
    total = len(records)
    for index, record in enumerate(records, start=1):
        try:
            crystal = canonicalize_record(
                record,
                symprec_values=(0.03, 0.05, 0.10),
                angle_tolerance=5.0,
                max_sites=20,
                min_elements=2,
                max_elements=4,
            )
            semantic_paths(
                crystal,
                count=paths_per_parent,
                min_fraction=min_fraction,
                max_fraction=max_fraction,
                seed=seed,
            )
        except StructureRejection as exc:
            rejections[f"structure:{exc.code.value}"] += 1
        except DeconstructionError as exc:
            rejections[f"semantic:{exc}"] += 1
        else:
            accepted.append(crystal)
        if progress is not None and (index == total or index % 500 == 0):
            progress(index, total)
    return tuple(accepted), tuple(sorted(rejections.items()))


def _audit_payload(audit: Gate1bLeakageAudit) -> dict[str, object]:
    payload = asdict(audit)
    payload["passes"] = audit.passes
    return payload


def prepare_gate1b_split(
    *,
    mp20_root: Path,
    old_gate0_dir: Path,
    output_dir: Path,
    preregistration_path: Path,
    threshold_path: Path,
    seed: int = 20260821,
    iid_fraction: float = 0.10,
    paths_per_parent: int = 4,
    min_fraction: float = 0.20,
    max_fraction: float = 0.40,
    progress: Callable[[int, int], None] | None = None,
) -> tuple[PreparationSummary, Gate1bSplit]:
    contract = load_historical_contract(old_gate0_dir)
    records, source_manifest = load_mp20_records(
        Path(mp20_root),
        expected_hashes=dict(contract.source_hashes),
        strict_hashes=True,
    )
    joint_records = select_joint_records(
        records,
        old_selected_ids=contract.old_selected_ids,
        old_test_ids=contract.old_test_ids,
    )
    crystals, rejections = canonicalize_semantic_eligible(
        joint_records,
        paths_per_parent=paths_per_parent,
        min_fraction=min_fraction,
        max_fraction=max_fraction,
        seed=seed,
        progress=progress,
    )
    accepted_ids = {crystal.material_id for crystal in crystals}
    missing_old_test = sorted(contract.old_test_ids - accepted_ids)
    if missing_old_test:
        raise PreparationError(
            "old clean test structures failed the joint canonical/semantic contract: "
            f"{missing_old_test[:5]}"
        )
    candidates = merge_near_duplicate_families(
        joint_fresh_candidates(crystals),
        {crystal.material_id: crystal for crystal in crystals},
    )
    split = build_fresh_split(
        candidates,
        old_selected_ids=set(contract.old_selected_ids),
        old_test_ids=set(contract.old_test_ids),
        seed=seed,
        iid_fraction=iid_fraction,
    )
    crystals_by_id = {
        crystal.material_id: crystal
        for crystal in crystals
        if crystal.material_id not in contract.old_selected_ids
    }
    near_pairs = find_confirmed_near_duplicate_pairs(split.entries, crystals_by_id)
    audit = audit_gate1b_split(
        split.entries,
        confirmed_near_duplicate_pairs=near_pairs,
    )
    if not audit.passes:
        raise PreparationError(
            "fresh split leakage audit failed; no blind lock was created: "
            f"{_audit_payload(audit)}"
        )

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    artifacts = write_split_artifacts(split, output_dir)
    audit_path = output_dir / "gate1b_leakage_audit.json"
    audit_path.write_text(
        json.dumps(_audit_payload(audit), sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    counts = Counter(row.partition.value for row in split.entries)
    summary = PreparationSummary(
        source_records=source_manifest.total_records,
        joint_records=len(joint_records),
        canonical_joint_records=len(crystals),
        semantic_eligible_joint_records=len(crystals),
        old_selected_records=len(contract.old_selected_ids),
        old_test_records=len(contract.old_test_ids),
        fresh_split_records=len(split.entries),
        family_count=len({row.prototype_family for row in split.entries}),
        partition_counts=tuple(sorted(counts.items())),
        rejection_counts=rejections,
        leakage_pass=True,
        max_sites=20,
        unavailable_site_count_bins=("21-32", ">32"),
    )
    summary_path = output_dir / "gate1b_preparation_summary.json"
    summary_path.write_text(
        json.dumps(asdict(summary), sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    freeze_blind_lock(
        output_dir / "gate1b_blind_lock.json",
        preregistration_path=preregistration_path,
        threshold_path=threshold_path,
        split_summary_path=artifacts.summary_path,
        public_manifest_path=artifacts.public_path,
        blind_manifest_path=artifacts.blind_path,
    )
    return summary, split


def _main() -> int:
    parser = argparse.ArgumentParser(description="Prepare and lock Gate 1b fresh data")
    parser.add_argument("--mp20-root", type=Path, required=True)
    parser.add_argument("--old-gate0-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--preregistration", type=Path, required=True)
    parser.add_argument("--thresholds", type=Path, required=True)
    args = parser.parse_args()

    def report(done: int, total: int) -> None:
        print(json.dumps({"canonicalized": done, "total": total}), flush=True)

    summary, _ = prepare_gate1b_split(
        mp20_root=args.mp20_root,
        old_gate0_dir=args.old_gate0_dir,
        output_dir=args.output_dir,
        preregistration_path=args.preregistration,
        threshold_path=args.thresholds,
        progress=report,
    )
    print(json.dumps(asdict(summary), sort_keys=True, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
