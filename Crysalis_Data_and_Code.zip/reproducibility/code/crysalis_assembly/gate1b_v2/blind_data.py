from __future__ import annotations

import argparse
import hashlib
import json
from collections.abc import Mapping, Sequence
from pathlib import Path

import torch

from ..experiments.deconstruction import CorruptionVariant, semantic_paths
from ..experiments.model_data import CompletionRecord
from ..experiments.mp20 import load_mp20_records
from ..experiments.symmetry import CanonicalCrystal, canonicalize_record
from .corruption.connected_region import (
    ConnectedRegionError,
    ConnectedRegionSpec,
    connected_region_corruption,
)
from .data import ArmMask, arm_masks
from .formal_data import _record
from .preregistration.blind_lock import (
    V2BlindAccessGrant,
    grant_v2_blind_access,
    open_v2_blind_manifest,
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def build_blind_ledgers(
    manifest_rows: Sequence[dict[str, object]],
    crystals_by_id: Mapping[str, CanonicalCrystal],
) -> tuple[dict[str, tuple[CompletionRecord, ...]], tuple[dict[str, object], ...]]:
    ledgers: dict[str, list[CompletionRecord]] = {"Q-C": [], "E-R": [], "E-S": []}
    rejections: list[dict[str, object]] = []
    spec = ConnectedRegionSpec(seed=20260821, alpha=1.35, max_distance=5.0)
    for row in sorted(manifest_rows, key=lambda item: str(item["material_id"])):
        material_id = str(row["material_id"])
        try:
            crystal = crystals_by_id[material_id]
        except KeyError as exc:
            raise ValueError(f"sealed parent absent from MP-20: {material_id}") from exc
        if crystal.structure_hash != row.get("structure_hash"):
            raise ValueError(f"sealed structure hash mismatch: {material_id}")
        if crystal.space_group != int(str(row.get("space_group"))):
            raise ValueError(f"sealed space-group mismatch: {material_id}")
        masks = arm_masks(crystal, seed=20260821, paths_per_parent=4)
        ledgers["E-R"].extend(
            _record(crystal, row, mask, variant=CorruptionVariant.M1)
            for mask in masks["P-R"]
        )
        ledgers["E-S"].extend(
            _record(crystal, row, mask, variant=CorruptionVariant.M3)
            for mask in masks["P-S-multi"]
        )
        for path in semantic_paths(
            crystal, count=4, min_fraction=0.2, max_fraction=0.4, seed=20260821
        ):
            try:
                state = connected_region_corruption(
                    crystal,
                    prototype_family=str(row["prototype_family"]),
                    missing_count=len(path.missing_site_indices),
                    path_index=path.path_index,
                    spec=spec,
                )
            except ConnectedRegionError as exc:
                rejections.append(
                    {
                        "material_id": material_id,
                        "prototype_family": str(row["prototype_family"]),
                        "partition": str(row["partition"]),
                        "path_index": path.path_index,
                        "site_count": crystal.site_count,
                        "missing_count": len(path.missing_site_indices),
                        "missing_ratio": len(path.missing_site_indices)
                        / crystal.site_count,
                        "reason": str(exc),
                        "score_policy": "zero_no_refill",
                    }
                )
            else:
                ledgers["Q-C"].append(
                    _record(
                        crystal,
                        row,
                        ArmMask(
                            path_index=path.path_index,
                            missing_site_indices=state.missing_site_indices,
                            mechanism="connected-region",
                            example_seed=int(state.corruption_hash[:16], 16),
                        ),
                        variant=CorruptionVariant.M0,
                    )
                )
    return {name: tuple(records) for name, records in ledgers.items()}, tuple(rejections)


def build_blind_cache(
    *,
    grant: V2BlindAccessGrant,
    mp20_root: Path,
    source_manifest_path: Path,
    output_path: Path,
) -> dict[str, object]:
    rows = open_v2_blind_manifest(grant)
    source_payload = json.loads(source_manifest_path.read_text(encoding="utf-8"))
    source_records, source_manifest = load_mp20_records(
        mp20_root,
        expected_hashes=dict(source_payload["sha256_by_file"]),
        strict_hashes=True,
    )
    requested = {str(row["material_id"]): row for row in rows}
    crystals: dict[str, CanonicalCrystal] = {}
    for source in source_records:
        if source.material_id not in requested:
            continue
        crystals[source.material_id] = canonicalize_record(
            source,
            symprec_values=(0.03, 0.05, 0.1),
            angle_tolerance=5.0,
            max_sites=20,
            min_elements=2,
            max_elements=4,
        )
    ledgers, rejections = build_blind_ledgers(rows, crystals)
    payload = {
        "schema_version": "2.0.0",
        "grant_hash": grant.grant_hash,
        "sealed_manifest_sha256": grant.manifest_sha256,
        "source_manifest_sha256": _sha256(source_manifest_path),
        "source_total_records": source_manifest.total_records,
        "ledgers": ledgers,
        "q_c_rejections": rejections,
        "sealed_manifest_accessed": True,
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(payload, output_path)
    summary = {
        "schema_version": "2.0.0",
        "cache_sha256": _sha256(output_path),
        "grant_hash": grant.grant_hash,
        "sealed_manifest_sha256": grant.manifest_sha256,
        "ledger_counts": {name: len(records) for name, records in ledgers.items()},
        "q_c_rejection_count": len(rejections),
        "sealed_manifest_accessed": True,
    }
    output_path.with_suffix(".summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--lock", type=Path, required=True)
    parser.add_argument("--receipt-dir", type=Path, required=True)
    parser.add_argument("--approval", type=Path, required=True)
    parser.add_argument("--execution-lock", type=Path, required=True)
    parser.add_argument("--access-receipt", type=Path, required=True)
    parser.add_argument("--mp20-root", type=Path, required=True)
    parser.add_argument("--source-manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    grant = grant_v2_blind_access(
        lock_path=args.lock,
        receipt_dir=args.receipt_dir,
        approval_path=args.approval,
        execution_lock_path=args.execution_lock,
        access_receipt_path=args.access_receipt,
    )
    summary = build_blind_cache(
        grant=grant,
        mp20_root=args.mp20_root,
        source_manifest_path=args.source_manifest,
        output_path=args.output,
    )
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
