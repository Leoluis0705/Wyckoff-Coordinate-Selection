"""Crysalis Stage A Gate 1b-v2 causal-transfer study."""

FORMAL_TRAINING_ENABLED = False
