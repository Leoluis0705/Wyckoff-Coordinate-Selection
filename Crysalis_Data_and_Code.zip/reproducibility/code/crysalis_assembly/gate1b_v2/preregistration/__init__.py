"""Gate 1b-v2 preregistration and blind guard."""
