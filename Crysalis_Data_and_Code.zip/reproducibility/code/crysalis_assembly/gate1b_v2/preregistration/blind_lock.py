from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path


class BlindAccessDenied(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class V2BlindAccessGrant:
    manifest_path: Path
    manifest_sha256: str
    lock_hash: str
    grant_hash: str


_RECEIPTS = {
    "matrix_complete_receipt.json": "complete",
    "validation_freeze_receipt.json": "frozen",
    "code_audit_receipt.json": "pass",
    "output_hash_receipt.json": "complete",
}


def require_blind_receipts(receipt_dir: Path) -> tuple[Path, ...]:
    verified = []
    for name, status in _RECEIPTS.items():
        path = Path(receipt_dir) / name
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise BlindAccessDenied(f"missing or invalid blind prerequisite: {name}") from exc
        if payload.get("status") != status:
            raise BlindAccessDenied(f"blind prerequisite has wrong status: {name}")
        verified.append(path)
    return tuple(verified)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _read_object(path: Path, *, label: str) -> dict[str, object]:
    try:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise BlindAccessDenied(f"missing or invalid {label}") from exc
    if not isinstance(payload, dict):
        raise BlindAccessDenied(f"{label} must be a JSON object")
    return payload


def _atomic_json(path: Path, payload: dict[str, object]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    os.replace(temporary, path)


def grant_v2_blind_access(
    *,
    lock_path: Path,
    receipt_dir: Path,
    approval_path: Path,
    execution_lock_path: Path,
    access_receipt_path: Path,
) -> V2BlindAccessGrant:
    access_receipt_path = Path(access_receipt_path)
    if access_receipt_path.exists():
        raise BlindAccessDenied("blind access has already been granted")
    receipt_paths = require_blind_receipts(receipt_dir)
    approval = _read_object(approval_path, label="blind approval")
    execution_lock = _read_object(execution_lock_path, label="blind execution lock")
    if (
        approval.get("status") != "approved"
        or approval.get("scope") != "crysalis_gate1b_v2_blind_evaluation"
        or approval.get("one_time") is not True
        or execution_lock.get("status") != "frozen"
        or approval.get("execution_lock_sha256") != _sha256(execution_lock_path)
    ):
        raise BlindAccessDenied("blind approval is absent or out of scope")
    lock = _read_object(lock_path, label="blind lock")
    artifacts = lock.get("artifacts")
    if not isinstance(artifacts, dict):
        raise BlindAccessDenied("blind lock artifact ledger is missing")
    sealed = artifacts.get("sealed_parent_manifest")
    if not isinstance(sealed, dict):
        raise BlindAccessDenied("sealed parent manifest lock entry is missing")
    manifest_path = Path(str(sealed.get("path", "")))
    expected = str(sealed.get("sha256", ""))
    if not manifest_path.is_file() or not expected or _sha256(manifest_path) != expected:
        raise BlindAccessDenied("sealed parent manifest hash mismatch")
    payload: dict[str, object] = {
        "schema_version": "2.0.0",
        "status": "granted",
        "scope": "crysalis_gate1b_v2_blind_evaluation",
        "one_time": True,
        "granted_at_utc": datetime.now(UTC).isoformat(),
        "lock_hash": str(lock.get("lock_hash", "")),
        "manifest_path": str(manifest_path),
        "manifest_sha256": expected,
        "approval_sha256": _sha256(approval_path),
        "execution_lock_sha256": _sha256(execution_lock_path),
        "receipt_sha256": {path.name: _sha256(path) for path in receipt_paths},
    }
    grant_hash = hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    _atomic_json(access_receipt_path, {**payload, "grant_hash": grant_hash})
    return V2BlindAccessGrant(
        manifest_path=manifest_path,
        manifest_sha256=expected,
        lock_hash=str(lock.get("lock_hash", "")),
        grant_hash=grant_hash,
    )


def open_v2_blind_manifest(
    grant: V2BlindAccessGrant,
) -> tuple[dict[str, object], ...]:
    if _sha256(grant.manifest_path) != grant.manifest_sha256:
        raise BlindAccessDenied("sealed parent manifest hash changed after grant")
    try:
        rows = tuple(
            json.loads(line)
            for line in grant.manifest_path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        )
    except (OSError, json.JSONDecodeError) as exc:
        raise BlindAccessDenied("sealed parent manifest is invalid") from exc
    if not rows or any(not isinstance(row, dict) for row in rows):
        raise BlindAccessDenied("sealed parent manifest must contain JSON objects")
    invalid = sorted(
        {
            str(row.get("partition", ""))
            for row in rows
            if row.get("partition") not in {"iid_test", "blind_ood"}
        }
    )
    if invalid:
        raise BlindAccessDenied(f"sealed manifest contains invalid partitions: {invalid}")
    return rows
