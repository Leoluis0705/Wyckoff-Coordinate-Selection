from __future__ import annotations

REQUIRED_FINAL_STATES = {
    "OLD_GATE1_PROMOTION_DECISION": "NO_GO",
    "SEMANTIC_DECONSTRUCTION_HISTORICAL_SIGNAL": "SUPPORTED",
    "GATE1B_V1_STATUS": "ARCHIVED_BEFORE_TRAINING",
    "FROZEN_PROBE_STATUS": "NOT_RUN",
    "FULL_FINETUNE_STATUS": "NOT_RUN",
    "CROSS_MATRIX_STATUS": "NOT_RUN",
    "GENERAL_TRANSFER_STATUS": "NOT_RUN",
    "TASK_SPECIFIC_BENEFIT_STATUS": "NOT_RUN",
    "FULL_ASSEMBLY_DYNAMICS_STATUS": "NOT_TESTED",
    "FORMAL_TRAINING_STARTED": False,
    "BLIND_TEST_ACCESSED": False,
    "WAITING_FOR_USER_APPROVAL": True,
}


def validate_readiness_states(states: dict[str, object]) -> None:
    mismatches = {
        key: (states.get(key), expected)
        for key, expected in REQUIRED_FINAL_STATES.items()
        if states.get(key) != expected
    }
    if mismatches:
        raise ValueError(f"readiness state mismatch: {mismatches}")
