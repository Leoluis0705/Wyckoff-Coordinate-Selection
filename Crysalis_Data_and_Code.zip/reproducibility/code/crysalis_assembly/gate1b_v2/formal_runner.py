from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import asdict
from pathlib import Path

import torch

from ..experiments.deconstruction import CorruptionVariant
from ..experiments.model_data import CompletionRecord
from ..experiments.train_gate1 import TrainingRunArgs, train_run
from .formal_data import ARM_VARIANTS

ARMS = ("P-R", "P-S-single", "P-S-multi", "P-M")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _require_approval(path: Path) -> str:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("status") != "approved":
        raise ValueError("formal approval receipt is not approved")
    if payload.get("scope") != "crysalis_gate1b_v2_formal_matrix":
        raise ValueError("formal approval receipt scope mismatch")
    if payload.get("blind_access_authorized") is not False:
        raise ValueError("training approval must not authorize blind access")
    return _sha256(path)


def _load_cache(path: Path) -> dict[str, object]:
    summary = json.loads(path.with_suffix(".summary.json").read_text(encoding="utf-8"))
    if _sha256(path) != summary.get("cache_sha256"):
        raise ValueError("formal public cache hash mismatch")
    payload = torch.load(path, map_location="cpu", weights_only=False)
    if payload.get("sealed_manifest_accessed") is not False:
        raise ValueError("formal cache does not certify sealed isolation")
    return payload


def run_stage(
    *,
    stage: str,
    arm: str,
    seed: int,
    cache_path: Path,
    output_root: Path,
    approval_receipt: Path,
    mp20_root: Path,
    gate0_dir: Path,
    config_root: Path,
    device: str,
) -> dict[str, object]:
    approval_hash = _require_approval(approval_receipt)
    cache = _load_cache(cache_path)
    ledgers = cache.get("ledgers")
    if not isinstance(ledgers, dict):
        raise TypeError("formal cache ledger is missing")
    if stage == "pretrain":
        if arm not in ARMS:
            raise ValueError("invalid pretraining arm")
        records = ledgers[arm]
        variant = ARM_VARIANTS[arm]
        config_path = config_root / "pretrain.json"
        initial_checkpoint = None
        frozen_probe = False
        output_dir = output_root / "pretraining" / arm / f"seed-{seed}"
    elif stage in {"probe", "finetune"}:
        if arm not in ARMS:
            raise ValueError("invalid transfer arm")
        records = ledgers["Q-C"]
        variant = CorruptionVariant.M0
        config_path = config_root / "downstream.json"
        initial_checkpoint = (
            output_root / "pretraining" / arm / f"seed-{seed}" / "checkpoint.pt"
        )
        if not initial_checkpoint.is_file():
            raise ValueError("pretraining checkpoint is absent")
        frozen_probe = stage == "probe"
        output_dir = output_root / stage / arm / f"seed-{seed}"
    elif stage == "scratch":
        if arm != "Scratch-Q":
            raise ValueError("scratch stage requires Scratch-Q arm")
        records = ledgers["Q-C"]
        variant = CorruptionVariant.M0
        config_path = config_root / "scratch.json"
        initial_checkpoint = None
        frozen_probe = False
        output_dir = output_root / "scratch" / f"seed-{seed}"
    else:
        raise ValueError("invalid formal stage")
    if not isinstance(records, (tuple, list)) or not all(
        isinstance(record, CompletionRecord) for record in records
    ):
        raise ValueError("formal cache contains invalid completion records")
    manifest = train_run(
        TrainingRunArgs(
            mp20_root=mp20_root,
            gate0_dir=gate0_dir,
            output_dir=output_dir,
            config_path=config_path,
            variant=variant,
            seed=seed,
            device=device,
            initial_checkpoint=initial_checkpoint,
            frozen_probe=frozen_probe,
            balanced_mechanisms=("random", "semantic")
            if stage == "pretrain" and arm == "P-M"
            else None,
        ),
        records=records,
    )
    stage_manifest = {
        "schema_version": "2.0.0",
        "status": "completed",
        "stage": stage,
        "arm": arm,
        "seed": seed,
        "approval_receipt_sha256": approval_hash,
        "public_cache_sha256": _sha256(cache_path),
        "sealed_manifest_accessed": False,
        "training_manifest": asdict(manifest),
    }
    (output_dir / "v2_stage_manifest.json").write_text(
        json.dumps(stage_manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return stage_manifest


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=("pretrain", "probe", "finetune", "scratch"), required=True)
    parser.add_argument("--arm", required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--approval-receipt", type=Path, required=True)
    parser.add_argument("--mp20-root", type=Path, required=True)
    parser.add_argument("--gate0-dir", type=Path, required=True)
    parser.add_argument("--config-root", type=Path, required=True)
    parser.add_argument("--device", default="auto")
    args = parser.parse_args()
    result = run_stage(
        stage=args.stage,
        arm=args.arm,
        seed=args.seed,
        cache_path=args.cache,
        output_root=args.output_root,
        approval_receipt=args.approval_receipt,
        mp20_root=args.mp20_root,
        gate0_dir=args.gate0_dir,
        config_root=args.config_root,
        device=args.device,
    )
    print(json.dumps({"status": result["status"], "stage": result["stage"], "arm": result["arm"], "seed": result["seed"]}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
