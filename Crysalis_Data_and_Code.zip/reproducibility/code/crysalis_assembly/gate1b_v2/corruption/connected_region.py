from __future__ import annotations

import hashlib
import json
import random
import warnings
from collections import deque
from dataclasses import asdict, dataclass
from functools import lru_cache

import numpy as np
from pymatgen.core import Element

from ...experiments.symmetry import CanonicalCrystal


class ConnectedRegionError(ValueError):
    """Raised when the frozen Q-C contract cannot construct a valid state."""


@dataclass(frozen=True, slots=True)
class ConnectedRegionSpec:
    seed: int
    alpha: float
    max_distance: float
    radius_fallback: float = 1.0
    schema_version: str = "1.0.0"

    def __post_init__(self) -> None:
        if self.alpha <= 0 or self.max_distance <= 0 or self.radius_fallback <= 0:
            raise ValueError("Q-C distance parameters must be positive")


@dataclass(frozen=True, slots=True)
class ConnectedRegionState:
    parent_structure_id: str
    prototype_family: str
    path_index: int
    seed_atom: int
    periodic_translation_edges: tuple[tuple[int, int, int, int, int], ...]
    missing_site_indices: tuple[int, ...]
    missing_count: int
    missing_ratio: float
    corruption_hash: str
    is_full_orbit_union: bool
    is_random_reference_equal: bool
    status: str = "accepted"


@lru_cache(maxsize=256)
def _radius(symbol: str, fallback: float) -> float:
    element = Element(symbol)
    if element.atomic_radius is not None and float(element.atomic_radius) > 0:
        return float(element.atomic_radius)
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="No data available.*", category=UserWarning)
        calculated = element.atomic_radius_calculated
    return float(calculated) if calculated is not None and float(calculated) > 0 else fallback


def periodic_neighbor_edges(
    crystal: CanonicalCrystal, spec: ConnectedRegionSpec
) -> tuple[tuple[int, int, int, int, int], ...]:
    fractions = np.asarray(crystal.structure.frac_coords, dtype=float)
    lattice = np.asarray(crystal.structure.lattice.matrix, dtype=float)
    radii = tuple(_radius(site.specie.symbol, spec.radius_fallback) for site in crystal.structure)
    edges: list[tuple[int, int, int, int, int]] = []
    for source in range(crystal.site_count):
        for target in range(crystal.site_count):
            if source == target:
                continue
            raw = fractions[target] - fractions[source]
            translation = -np.rint(raw).astype(int)
            distance = float(np.linalg.norm((raw + translation) @ lattice))
            threshold = min(spec.max_distance, spec.alpha * (radii[source] + radii[target]))
            if distance <= threshold + 1e-12:
                edges.append(
                    (
                        source,
                        target,
                        int(translation[0]),
                        int(translation[1]),
                        int(translation[2]),
                    )
                )
    return tuple(sorted(edges))


def _rank(spec: ConnectedRegionSpec, crystal: CanonicalCrystal, *parts: object) -> str:
    value = ":".join(map(str, (spec.seed, crystal.material_id, *parts)))
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _random_reference(crystal: CanonicalCrystal, missing_count: int, spec: ConnectedRegionSpec, path_index: int) -> tuple[int, ...]:
    digest = hashlib.sha256(
        f"Q-C-random-reference:{spec.seed}:{crystal.material_id}:{path_index}".encode()
    ).digest()
    rng = random.Random(int.from_bytes(digest[:8], "big"))
    return tuple(sorted(rng.sample(range(crystal.site_count), missing_count)))


def _is_orbit_union(crystal: CanonicalCrystal, missing: tuple[int, ...]) -> bool:
    selected = set(missing)
    return all(
        not selected.intersection(orbit.site_indices)
        or set(orbit.site_indices).issubset(selected)
        for orbit in crystal.orbits
    )


def is_periodic_connected(
    missing: tuple[int, ...], edges: tuple[tuple[int, int, int, int, int], ...]
) -> bool:
    selected = set(missing)
    if not selected:
        return False
    adjacency: dict[int, set[int]] = {index: set() for index in selected}
    for source, target, *_ in edges:
        if source in selected and target in selected:
            adjacency[source].add(target)
            adjacency[target].add(source)
    seen = {next(iter(selected))}
    queue = deque(seen)
    while queue:
        node = queue.popleft()
        new = adjacency[node] - seen
        seen.update(new)
        queue.extend(sorted(new))
    return seen == selected


def connected_region_corruption(
    crystal: CanonicalCrystal,
    *,
    prototype_family: str,
    missing_count: int,
    path_index: int,
    spec: ConnectedRegionSpec,
) -> ConnectedRegionState:
    if not 0 < missing_count < crystal.site_count:
        raise ConnectedRegionError("missing count must leave at least one visible site")
    edges = periodic_neighbor_edges(crystal, spec)
    adjacency: dict[int, set[int]] = {
        index: set() for index in range(crystal.site_count)
    }
    for source, target, *_ in edges:
        adjacency[source].add(target)
    seed_order = sorted(
        range(crystal.site_count),
        key=lambda index: (_rank(spec, crystal, path_index, "seed", index), index),
    )
    random_reference = _random_reference(crystal, missing_count, spec, path_index)
    for seed_atom in seed_order:
        chosen: list[int] = []
        queued = {seed_atom}
        queue = deque((seed_atom,))
        while queue and len(chosen) < missing_count:
            node = queue.popleft()
            chosen.append(node)
            neighbors = sorted(
                adjacency[node] - queued,
                key=lambda index: (_rank(spec, crystal, path_index, node, index), index),
            )
            queue.extend(neighbors)
            queued.update(neighbors)
        if len(chosen) != missing_count:
            continue
        missing = tuple(sorted(chosen))
        is_union = _is_orbit_union(crystal, missing)
        is_random_equal = missing == random_reference
        if is_union or is_random_equal:
            continue
        region_edges = tuple(
            edge for edge in edges if edge[0] in missing and edge[1] in missing
        )
        payload = {
            "parent_structure_id": crystal.material_id,
            "prototype_family": prototype_family,
            "path_index": path_index,
            "seed_atom": seed_atom,
            "periodic_translation_edges": region_edges,
            "missing_site_indices": missing,
            "missing_count": missing_count,
            "missing_ratio": missing_count / crystal.site_count,
            "is_full_orbit_union": False,
            "is_random_reference_equal": False,
        }
        corruption_hash = hashlib.sha256(
            json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        state = ConnectedRegionState(
            parent_structure_id=crystal.material_id,
            prototype_family=prototype_family,
            path_index=path_index,
            seed_atom=seed_atom,
            periodic_translation_edges=region_edges,
            missing_site_indices=missing,
            missing_count=missing_count,
            missing_ratio=missing_count / crystal.site_count,
            corruption_hash=corruption_hash,
            is_full_orbit_union=False,
            is_random_reference_equal=False,
        )
        if not is_periodic_connected(missing, region_edges):
            raise AssertionError("BFS produced a disconnected Q-C mask")
        return state
    raise ConnectedRegionError("no_connected_non_orbit_nonrandom_mask")


def state_payload(state: ConnectedRegionState) -> dict[str, object]:
    return asdict(state)
