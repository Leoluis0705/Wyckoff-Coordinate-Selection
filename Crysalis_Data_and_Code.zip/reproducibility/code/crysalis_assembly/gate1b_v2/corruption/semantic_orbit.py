"""Reuse the audited single- and multi-path semantic corruption primitives."""

from ...experiments.deconstruction import semantic_paths

__all__ = ["semantic_paths"]
