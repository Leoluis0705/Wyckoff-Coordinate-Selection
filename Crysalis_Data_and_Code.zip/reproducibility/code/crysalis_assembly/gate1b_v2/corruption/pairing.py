from __future__ import annotations

import json
from dataclasses import asdict

from .connected_region import ConnectedRegionState


def common_state_bytes(state: ConnectedRegionState, pretraining_arm: str) -> bytes:
    """Serialize Q-C independently of arm; the arm argument is audit-only."""
    if not pretraining_arm:
        raise ValueError("pretraining arm must be named")
    return json.dumps(
        asdict(state), sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")


def assert_common_downstream_identity(states: dict[str, ConnectedRegionState]) -> str:
    encodings = {common_state_bytes(state, arm) for arm, state in states.items()}
    if len(encodings) != 1:
        raise ValueError("common downstream states differ across pretraining arms")
    return next(iter(states.values())).corruption_hash
