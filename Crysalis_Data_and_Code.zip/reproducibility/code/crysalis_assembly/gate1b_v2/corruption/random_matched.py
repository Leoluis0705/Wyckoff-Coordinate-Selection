"""Reuse the audited severity-matched random corruption without modifying Gate 1."""

from ...gate1b.paired_corruptions import paired_corruptions

__all__ = ["paired_corruptions"]
