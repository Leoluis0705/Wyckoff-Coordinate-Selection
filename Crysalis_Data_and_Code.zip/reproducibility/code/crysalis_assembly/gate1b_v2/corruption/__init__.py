"""Frozen corruption mechanisms for Gate 1b-v2."""
