"""Equal-budget pretraining arm definitions."""
