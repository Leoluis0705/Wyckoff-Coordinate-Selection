from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class PretrainingArm(str, Enum):
    RANDOM = "P-R"
    SEMANTIC_SINGLE = "P-S-single"
    SEMANTIC_MULTI = "P-S-multi"
    MIXED = "P-M"


@dataclass(frozen=True, slots=True)
class PretrainingBudget:
    updates: int
    batch_size: int
    parameter_count: int


def assert_equal_pretraining_budgets(budgets: dict[PretrainingArm, PretrainingBudget]) -> PretrainingBudget:
    if set(budgets) != set(PretrainingArm):
        raise ValueError("all four preregistered pretraining arms are required")
    unique = set(budgets.values())
    if len(unique) != 1:
        raise ValueError("pretraining arms must have identical compute and capacity budgets")
    budget = next(iter(unique))
    if min(budget.updates, budget.batch_size, budget.parameter_count) <= 0:
        raise ValueError("pretraining budget values must be positive")
    return budget
