from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

import torch

from ..experiments.deconstruction import CorruptionVariant, semantic_paths
from ..experiments.model_data import CompletionRecord, _site_labels
from ..experiments.mp20 import load_mp20_records
from ..experiments.symmetry import CanonicalCrystal, canonicalize_record
from ..gate1b.blind_lock import open_public_manifest
from .corruption.connected_region import (
    ConnectedRegionError,
    ConnectedRegionSpec,
    connected_region_corruption,
)
from .data import ArmMask, arm_masks

ARM_VARIANTS = {
    "P-R": CorruptionVariant.M1,
    "P-S-single": CorruptionVariant.M2,
    "P-S-multi": CorruptionVariant.M3,
    "P-M": CorruptionVariant.M0,
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _as_int(value: object, *, field: str) -> int:
    if not isinstance(value, (int, float, str)):
        raise TypeError(f"{field} must be numeric")
    return int(value)


def _record(
    crystal: CanonicalCrystal,
    row: dict[str, object],
    mask: ArmMask,
    *,
    variant: CorruptionVariant,
) -> CompletionRecord:
    structure = crystal.structure
    multiplicities, wyckoff = _site_labels(crystal)
    lattice = structure.lattice.matrix
    return CompletionRecord(
        material_id=crystal.material_id,
        prototype_family=str(row["prototype_family"]),
        split=str(row["partition"]),
        stress_flags=(f"v2-mechanism:{mask.mechanism}",),
        variant=variant,
        path_index=mask.path_index,
        example_seed=mask.example_seed,
        lattice=(
            (float(lattice[0][0]), float(lattice[0][1]), float(lattice[0][2])),
            (float(lattice[1][0]), float(lattice[1][1]), float(lattice[1][2])),
            (float(lattice[2][0]), float(lattice[2][1]), float(lattice[2][2])),
        ),
        atomic_numbers=tuple(int(site.specie.Z) for site in structure),
        fractional_coordinates=tuple(
            (
                float(site.frac_coords[0]) % 1.0,
                float(site.frac_coords[1]) % 1.0,
                float(site.frac_coords[2]) % 1.0,
            )
            for site in structure
        ),
        orbit_multiplicities=multiplicities,
        wyckoff_indices=wyckoff,
        space_group=crystal.space_group,
        missing_site_indices=mask.missing_site_indices,
        model_partition=str(row["partition"]),
    )


def build_public_cache(
    *,
    mp20_root: Path,
    source_manifest_path: Path,
    public_manifest_path: Path,
    output_path: Path,
) -> dict[str, object]:
    public_rows = open_public_manifest(public_manifest_path)
    public_by_id = {str(row["material_id"]): row for row in public_rows}
    source_payload = json.loads(source_manifest_path.read_text(encoding="utf-8"))
    expected_hashes = dict(source_payload["sha256_by_file"])
    source_records, source_manifest = load_mp20_records(
        mp20_root, expected_hashes=expected_hashes, strict_hashes=True
    )
    source_by_id = {record.material_id: record for record in source_records}
    missing = sorted(set(public_by_id) - set(source_by_id))
    if missing:
        raise ValueError(f"public parents absent from MP-20: {missing[:5]}")

    ledgers: dict[str, list[CompletionRecord]] = {
        "P-R": [],
        "P-S-single": [],
        "P-S-multi": [],
        "P-M": [],
        "Q-C": [],
    }
    rejections: list[dict[str, object]] = []
    spec = ConnectedRegionSpec(seed=20260821, alpha=1.35, max_distance=5.0)
    for index, material_id in enumerate(sorted(public_by_id), start=1):
        row = public_by_id[material_id]
        crystal = canonicalize_record(
            source_by_id[material_id],
            symprec_values=(0.03, 0.05, 0.1),
            angle_tolerance=5.0,
            max_sites=20,
            min_elements=2,
            max_elements=4,
        )
        if crystal.structure_hash != row["structure_hash"]:
            raise ValueError(f"public structure hash mismatch: {material_id}")
        if crystal.space_group != _as_int(row["space_group"], field="space_group"):
            raise ValueError(f"public space-group mismatch: {material_id}")
        masks = arm_masks(crystal, seed=20260821, paths_per_parent=4)
        for arm, arm_rows in masks.items():
            ledgers[arm].extend(
                _record(crystal, row, mask, variant=ARM_VARIANTS[arm])
                for mask in arm_rows
            )
        semantic = semantic_paths(
            crystal, count=4, min_fraction=0.2, max_fraction=0.4, seed=20260821
        )
        for path in semantic:
            try:
                state = connected_region_corruption(
                    crystal,
                    prototype_family=str(row["prototype_family"]),
                    missing_count=len(path.missing_site_indices),
                    path_index=path.path_index,
                    spec=spec,
                )
            except ConnectedRegionError as exc:
                rejections.append(
                    {
                        "parent_structure_id": material_id,
                        "path_index": path.path_index,
                        "partition": row["partition"],
                        "reason": str(exc),
                        "score_policy": "zero_no_refill",
                    }
                )
            else:
                ledgers["Q-C"].append(
                    _record(
                        crystal,
                        row,
                        ArmMask(
                            path_index=path.path_index,
                            missing_site_indices=state.missing_site_indices,
                            mechanism="connected-region",
                            example_seed=int(state.corruption_hash[:16], 16),
                        ),
                        variant=CorruptionVariant.M0,
                    )
                )
        if index % 1000 == 0:
            print(json.dumps({"public_cache_parents": index}), flush=True)

    frozen_ledgers = {name: tuple(records) for name, records in ledgers.items()}
    partition_counts = {
        name: dict(sorted(Counter(record.model_partition for record in records).items()))
        for name, records in frozen_ledgers.items()
    }
    payload = {
        "schema_version": "2.0.0",
        "public_manifest_sha256": _sha256(public_manifest_path),
        "source_manifest_sha256": _sha256(source_manifest_path),
        "source_total_records": source_manifest.total_records,
        "ledgers": frozen_ledgers,
        "q_c_rejections": tuple(rejections),
        "sealed_manifest_accessed": False,
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(payload, output_path)
    summary = {
        "schema_version": "2.0.0",
        "cache_sha256": _sha256(output_path),
        "public_manifest_sha256": payload["public_manifest_sha256"],
        "source_manifest_sha256": payload["source_manifest_sha256"],
        "ledger_counts": {name: len(records) for name, records in frozen_ledgers.items()},
        "partition_counts": partition_counts,
        "q_c_rejection_count": len(rejections),
        "sealed_manifest_accessed": False,
    }
    output_path.with_suffix(".summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mp20-root", type=Path, required=True)
    parser.add_argument("--source-manifest", type=Path, required=True)
    parser.add_argument("--public-manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    summary = build_public_cache(
        mp20_root=args.mp20_root,
        source_manifest_path=args.source_manifest,
        public_manifest_path=args.public_manifest,
        output_path=args.output,
    )
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
