from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class CrossMatrixDecomposition:
    semantic_training_main_effect: float
    evaluation_semantic_main_effect: float
    training_evaluation_interaction: float


def decompose_cross_matrix(*, y_rr: float, y_rs: float, y_sr: float, y_ss: float) -> CrossMatrixDecomposition:
    """Use the standard balanced 2x2 factorial decomposition."""
    training = 0.5 * ((y_sr - y_rr) + (y_ss - y_rs))
    evaluation = 0.5 * ((y_rs - y_rr) + (y_ss - y_sr))
    interaction = (y_ss - y_rs) - (y_sr - y_rr)
    return CrossMatrixDecomposition(training, evaluation, interaction)
