from __future__ import annotations


def supplemental_formula(outcome: str) -> str:
    if outcome not in {"component_pass", "strict_success"}:
        raise ValueError("unsupported mixed-effects outcome")
    return f"{outcome} ~ semantic_training + semantic_evaluation + semantic_training:semantic_evaluation + site_count + missing_ratio + (1|family) + (1|seed)"
