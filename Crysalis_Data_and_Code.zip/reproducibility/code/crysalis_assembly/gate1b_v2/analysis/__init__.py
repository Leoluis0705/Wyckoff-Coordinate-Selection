"""Preregistered Gate 1b-v2 analyses."""
