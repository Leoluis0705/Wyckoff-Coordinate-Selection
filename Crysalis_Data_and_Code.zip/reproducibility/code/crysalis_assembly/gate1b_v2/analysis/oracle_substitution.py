from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

from .component_pass import _as_float, component_pass_from_prediction

_COMPONENTS = frozenset({"coordinates", "orbit", "wyckoff", "edge"})


@dataclass(frozen=True, slots=True)
class OracleRescueResult:
    original_failures: int
    rescued_failures: int
    rescue_rate: float
    counterfactual_strict_rate: float
    family_macro_rescue: float


def _passes(row: dict[str, object], oracle: frozenset[str]) -> bool:
    orbit = "orbit" in oracle or _as_float(row.get("orbit_multiplicity_accuracy", 0.0)) == 1.0
    wyckoff = "wyckoff" in oracle or _as_float(row.get("wyckoff_accuracy", 0.0)) == 1.0
    edge = "edge" in oracle or _as_float(row.get("periodic_edge_f1", 0.0)) == 1.0
    coordinate_system = "coordinates" in oracle or (
        bool(row.get("structure_match")) and not bool(row.get("short_contact"))
    )
    return orbit and wyckoff and edge and coordinate_system


def oracle_rescue(rows: tuple[dict[str, object], ...], *, oracle_components: frozenset[str]) -> OracleRescueResult:
    if not rows or not oracle_components <= _COMPONENTS:
        raise ValueError("invalid oracle substitution")
    original = tuple(bool(row.get("strict_success")) for row in rows)
    counterfactual = tuple(_passes(row, oracle_components) for row in rows)
    failures = sum(not value for value in original)
    rescued = sum((not before) and after for before, after in zip(original, counterfactual, strict=True))
    family_values: dict[str, list[float]] = defaultdict(list)
    for row, before, after in zip(rows, original, counterfactual, strict=True):
        family_values[str(row.get("prototype_family", ""))].append(float(after) - float(before))
        component_pass_from_prediction(row)  # validates the archived component schema
    macro = sum(sum(values) / len(values) for values in family_values.values()) / len(family_values)
    return OracleRescueResult(
        original_failures=failures,
        rescued_failures=rescued,
        rescue_rate=rescued / failures if failures else 0.0,
        counterfactual_strict_rate=sum(counterfactual) / len(counterfactual),
        family_macro_rescue=macro,
    )
