from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter, defaultdict
from dataclasses import asdict
from pathlib import Path

from .oracle_substitution import oracle_rescue

COMBINATIONS = {
    "C0": frozenset(),
    "C1": frozenset({"coordinates"}),
    "C2": frozenset({"orbit"}),
    "C3": frozenset({"wyckoff"}),
    "C4": frozenset({"edge"}),
    "C5": frozenset({"coordinates", "orbit"}),
    "C6": frozenset({"coordinates", "wyckoff"}),
    "C7": frozenset({"coordinates", "edge"}),
    "C8": frozenset({"orbit", "wyckoff"}),
    "C9": frozenset({"orbit", "edge"}),
    "C10": frozenset({"wyckoff", "edge"}),
}


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def run_oracle(predictions: Path, corruption_manifest: Path) -> dict[str, object]:
    before = _hash(predictions)
    rows = tuple(
        row
        for line in predictions.read_text(encoding="utf-8").splitlines()
        if (row := json.loads(line)).get("variant") == "m3"
    )
    site_count: dict[tuple[str, int], int] = {}
    for line in corruption_manifest.read_text(encoding="utf-8").splitlines():
        row = json.loads(line)
        if row.get("variant") == "m3" and row.get("split") == "test":
            site_count[(str(row["parent_material_id"]), int(row["path_index"]))] = int(row["site_count"])
    results = {}
    for label, components in COMBINATIONS.items():
        if not components:
            original_rate = sum(bool(row["strict_success"]) for row in rows) / len(rows)
            results[label] = {
                "oracle_components": [],
                "rescued_failures": 0,
                "rescue_rate": 0.0,
                "counterfactual_strict_rate": original_rate,
                "family_macro_rescue": 0.0,
            }
            continue
        result = oracle_rescue(rows, oracle_components=components)
        results[label] = {"oracle_components": sorted(components), **asdict(result)}

    failures = Counter(reason for row in rows for reason in row.get("failure_reasons", ()))
    site_failures: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        count = site_count[(str(row["material_id"]), int(row["path_index"]))]
        label = "2-8" if count <= 8 else "9-12" if count <= 12 else "13-16" if count <= 16 else "17-20"
        site_failures[label].append(row)
    stratified = {}
    for label, subset in sorted(site_failures.items()):
        stratified[label] = {
            "state_count": len(subset),
            "family_count": len({str(row["prototype_family"]) for row in subset}),
            "C1_coordinates": oracle_rescue(tuple(subset), oracle_components=frozenset({"coordinates"})).rescue_rate,
            "C2_orbit": oracle_rescue(tuple(subset), oracle_components=frozenset({"orbit"})).rescue_rate,
            "C3_wyckoff": oracle_rescue(tuple(subset), oracle_components=frozenset({"wyckoff"})).rescue_rate,
            "C4_edge": oracle_rescue(tuple(subset), oracle_components=frozenset({"edge"})).rescue_rate,
        }
    after = _hash(predictions)
    if after != before:
        raise RuntimeError("oracle analysis altered source predictions")
    return {
        "schema_version": "1.0.0",
        "scope": "old_public_gate1_m3_metric_level_oracle",
        "coordinate_oracle_definition": "set_structure_match_true_and_short_contact_false",
        "source_prediction_sha256_before": before,
        "source_prediction_sha256_after": after,
        "source_unchanged": True,
        "state_count": len(rows),
        "family_count": len({str(row["prototype_family"]) for row in rows}),
        "failure_counts": dict(sorted(failures.items())),
        "combinations": results,
        "site_count_strata": stratified,
        "fresh_blind_accessed": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--corruption-manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    payload = run_oracle(args.predictions, args.corruption_manifest)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
