from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True, slots=True)
class FamilyBootstrapResult:
    family_count: int
    state_count: int
    point_estimate: float
    micro_mean: float
    lower_95: float
    upper_95: float


def paired_family_bootstrap(rows: tuple[tuple[str, float], ...], *, draws: int, seed: int) -> FamilyBootstrapResult:
    if not rows or draws <= 0:
        raise ValueError("bootstrap requires rows and positive draws")
    grouped: dict[str, list[float]] = defaultdict(list)
    for family, difference in rows:
        grouped[family].append(float(difference))
    family_means = np.asarray([np.mean(values) for _, values in sorted(grouped.items())])
    rng = np.random.default_rng(seed)
    samples = rng.choice(family_means, size=(draws, len(family_means)), replace=True).mean(axis=1)
    quantiles = np.asarray(np.quantile(samples, (0.025, 0.975)), dtype=float)
    return FamilyBootstrapResult(
        family_count=len(family_means),
        state_count=len(rows),
        point_estimate=float(family_means.mean()),
        micro_mean=float(np.mean([value for _, value in rows])),
        lower_95=float(quantiles[0]),
        upper_95=float(quantiles[1]),
    )
