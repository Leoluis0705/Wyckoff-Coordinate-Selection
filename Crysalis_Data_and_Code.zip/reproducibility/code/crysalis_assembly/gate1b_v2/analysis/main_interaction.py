"""Named entry point for the preregistered 2x2 mechanism decomposition."""

from .cross_matrix import CrossMatrixDecomposition, decompose_cross_matrix

__all__ = ["CrossMatrixDecomposition", "decompose_cross_matrix"]
