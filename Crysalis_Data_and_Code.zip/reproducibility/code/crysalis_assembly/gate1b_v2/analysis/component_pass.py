from __future__ import annotations


def component_pass_count(
    orbit_exact: bool,
    wyckoff_exact: bool,
    periodic_edge_exact: bool,
    structure_match: bool,
    no_short_contact: bool,
) -> int:
    """Return the sum of the five frozen pass indicators (range 0..5)."""
    return sum(
        map(
            int,
            (orbit_exact, wyckoff_exact, periodic_edge_exact, structure_match, no_short_contact),
        )
    )


def _as_float(value: object) -> float:
    if not isinstance(value, (int, float, str)):
        raise TypeError("prediction metric must be numeric")
    return float(value)


def component_pass_from_prediction(row: dict[str, object]) -> int:
    return component_pass_count(
        _as_float(row.get("orbit_multiplicity_accuracy", 0.0)) == 1.0,
        _as_float(row.get("wyckoff_accuracy", 0.0)) == 1.0,
        _as_float(row.get("periodic_edge_f1", 0.0)) == 1.0,
        bool(row.get("structure_match")),
        not bool(row.get("short_contact")),
    )
