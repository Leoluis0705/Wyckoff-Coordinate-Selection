from __future__ import annotations

import argparse
import json
from collections import defaultdict
from collections.abc import Sequence
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np

from .cross_matrix import decompose_cross_matrix
from .family_bootstrap import paired_family_bootstrap


def _float(value: object) -> float:
    if not isinstance(value, (int, float, str)):
        raise TypeError("blind metric must be numeric")
    return float(value)


def _int(value: object) -> int:
    if not isinstance(value, (int, str)) or isinstance(value, bool):
        raise TypeError("blind metric must be an integer")
    return int(value)


@dataclass(frozen=True, slots=True)
class SignalEvidence:
    primary_gain: float
    primary_ci_lower: float
    full_finetune_gain: float
    positive_seed_directions: int
    positive_component_metrics: int
    worst_component_degradation: float
    e_r_degradation: float
    e_s_reproducible: bool
    q_c_reproducible: bool
    e_r_reproducible: bool
    systematic_reversal_count: int


def classify_signal(evidence: SignalEvidence) -> str:
    general = (
        evidence.primary_gain >= 0.10
        and evidence.primary_ci_lower > 0.0
        and evidence.full_finetune_gain > 0.0
        and evidence.positive_seed_directions >= 2
        and evidence.positive_component_metrics >= 2
        and evidence.worst_component_degradation <= 0.02
        and evidence.e_r_degradation <= 0.05
        and evidence.systematic_reversal_count == 0
    )
    if general:
        return "GENERAL_TRANSFER_SUPPORTED"
    if (
        evidence.e_s_reproducible
        and not evidence.q_c_reproducible
        and not evidence.e_r_reproducible
    ):
        return "TASK_SPECIFIC_SEMANTIC_BENEFIT"
    if (
        evidence.primary_gain <= 0.0
        and evidence.full_finetune_gain <= 0.0
        and not evidence.e_r_reproducible
        and not evidence.e_s_reproducible
    ):
        return "NO_REPRODUCIBLE_BENEFIT"
    return "MIXED_OR_INCONCLUSIVE"


def paired_component_differences(
    rows: Sequence[dict[str, object]], *, treated_arm: str, control_arm: str
) -> tuple[tuple[str, float], ...]:
    def collect(arm: str) -> dict[tuple[str, int, int], dict[str, object]]:
        selected: dict[tuple[str, int, int], dict[str, object]] = {}
        for row in rows:
            if row.get("arm") != arm:
                continue
            key = (
                str(row["material_id"]),
                _int(row["path_index"]),
                _int(row["seed"]),
            )
            if key in selected:
                raise ValueError(f"duplicate paired state key: {key}")
            selected[key] = row
        return selected

    treated = collect(treated_arm)
    control = collect(control_arm)
    if not treated or set(treated) != set(control):
        raise ValueError("treated and control paired state keys differ")
    return tuple(
        (
            str(treated[key]["prototype_family"]),
            _float(treated[key]["component_pass_count"])
            - _float(control[key]["component_pass_count"]),
        )
        for key in sorted(treated)
    )


def _selected(
    rows: Sequence[dict[str, object]],
    *,
    stage: str,
    corruption: str,
    partition: str = "blind_ood",
) -> tuple[dict[str, object], ...]:
    return tuple(
        row
        for row in rows
        if row.get("stage") == stage
        and row.get("corruption") == corruption
        and row.get("partition") == partition
    )


def _family_macro(rows: Sequence[dict[str, object]], arm: str) -> float:
    grouped: dict[str, list[float]] = defaultdict(list)
    for row in rows:
        if row.get("arm") == arm:
            grouped[str(row["prototype_family"])].append(
                _float(row["component_pass_count"])
            )
    if not grouped:
        raise ValueError(f"no rows for arm {arm}")
    return float(np.mean([np.mean(values) for values in grouped.values()]))


def _seed_directions(
    rows: Sequence[dict[str, object]], *, treated_arm: str, control_arm: str
) -> int:
    directions = 0
    for seed in sorted({_int(row["seed"]) for row in rows}):
        seed_rows = tuple(row for row in rows if _int(row["seed"]) == seed)
        differences = paired_component_differences(
            seed_rows, treated_arm=treated_arm, control_arm=control_arm
        )
        directions += float(np.mean([value for _, value in differences])) > 0.0
    return directions


def _component_differences(
    rows: Sequence[dict[str, object]], *, treated_arm: str, control_arm: str
) -> dict[str, float]:
    fields = {
        "orbit_multiplicity_exact": lambda row: _float(row["orbit_multiplicity_accuracy"])
        == 1.0,
        "wyckoff_exact": lambda row: _float(row["wyckoff_accuracy"]) == 1.0,
        "periodic_edge_exact": lambda row: _float(row["periodic_edge_f1"]) == 1.0,
        "structure_match": lambda row: bool(row["structure_match"]),
        "no_short_contact": lambda row: not bool(row["short_contact"]),
    }
    result: dict[str, float] = {}
    for name, indicator in fields.items():
        transformed = tuple(
            {**row, "component_pass_count": int(indicator(row))} for row in rows
        )
        differences = paired_component_differences(
            transformed, treated_arm=treated_arm, control_arm=control_arm
        )
        grouped: dict[str, list[float]] = defaultdict(list)
        for family, value in differences:
            grouped[family].append(value)
        result[name] = float(np.mean([np.mean(values) for values in grouped.values()]))
    return result


def _systematic_reversals(
    rows: Sequence[dict[str, object]], *, treated_arm: str, control_arm: str
) -> tuple[dict[str, object], ...]:
    results: list[dict[str, object]] = []
    for label in ("2-8", "9-12", "13-16", "17-20"):
        selected = tuple(
            row for row in rows if _site_stratum(_int(row["site_count"])) == label
        )
        families = {str(row["prototype_family"]) for row in selected}
        if len(families) < 30:
            continue
        differences = paired_component_differences(
            selected, treated_arm=treated_arm, control_arm=control_arm
        )
        grouped: dict[str, list[float]] = defaultdict(list)
        for family, value in differences:
            grouped[family].append(value)
        effect = float(np.mean([np.mean(values) for values in grouped.values()]))
        if effect < -0.05:
            results.append(
                {
                    "site_count_stratum": label,
                    "family_count": len(families),
                    "family_macro_component_pass_difference": effect,
                }
            )
    return tuple(results)


def analyze_prediction_rows(
    rows: Sequence[dict[str, object]], *, draws: int, seed: int
) -> dict[str, object]:
    primary_rows = _selected(rows, stage="probe", corruption="Q-C")
    primary_pairs = paired_component_differences(
        primary_rows, treated_arm="P-S-multi", control_arm="P-R"
    )
    primary = paired_family_bootstrap(primary_pairs, draws=draws, seed=seed)
    full_rows = _selected(rows, stage="finetune", corruption="Q-C")
    full_pairs = paired_component_differences(
        full_rows, treated_arm="P-S-multi", control_arm="P-R"
    )
    full_gain = paired_family_bootstrap(
        full_pairs, draws=draws, seed=seed
    ).point_estimate
    components = _component_differences(
        primary_rows, treated_arm="P-S-multi", control_arm="P-R"
    )
    cross_rows = _selected(rows, stage="pretraining", corruption="E-R")
    e_r_pairs = paired_component_differences(
        cross_rows, treated_arm="P-S-multi", control_arm="P-R"
    )
    e_r_effect = paired_family_bootstrap(
        e_r_pairs, draws=draws, seed=seed
    ).point_estimate
    e_r_interval = paired_family_bootstrap(e_r_pairs, draws=draws, seed=seed)
    e_r_reproducible = (
        e_r_interval.lower_95 > 0.0
        and _seed_directions(
            cross_rows, treated_arm="P-S-multi", control_arm="P-R"
        )
        >= 2
    )
    e_s_rows = _selected(rows, stage="pretraining", corruption="E-S")
    e_s_pairs = paired_component_differences(
        e_s_rows, treated_arm="P-S-multi", control_arm="P-R"
    )
    e_s_interval = paired_family_bootstrap(e_s_pairs, draws=draws, seed=seed)
    e_s_reproducible = (
        e_s_interval.lower_95 > 0.0
        and _seed_directions(
            e_s_rows, treated_arm="P-S-multi", control_arm="P-R"
        )
        >= 2
    )
    q_c_reproducible = (
        primary.lower_95 > 0.0
        and full_gain > 0.0
        and _seed_directions(
            primary_rows, treated_arm="P-S-multi", control_arm="P-R"
        )
        >= 2
    )
    reversals = _systematic_reversals(
        primary_rows, treated_arm="P-S-multi", control_arm="P-R"
    )
    evidence = SignalEvidence(
        primary_gain=primary.point_estimate,
        primary_ci_lower=primary.lower_95,
        full_finetune_gain=full_gain,
        positive_seed_directions=_seed_directions(
            primary_rows, treated_arm="P-S-multi", control_arm="P-R"
        ),
        positive_component_metrics=sum(value > 0.0 for value in components.values()),
        worst_component_degradation=max(0.0, -min(components.values())),
        e_r_degradation=-e_r_effect,
        e_s_reproducible=e_s_reproducible,
        q_c_reproducible=q_c_reproducible,
        e_r_reproducible=e_r_reproducible,
        systematic_reversal_count=len(reversals),
    )
    all_cross = tuple(
        row
        for row in rows
        if row.get("stage") == "pretraining"
        and row.get("partition") == "blind_ood"
        and row.get("corruption") in {"E-R", "E-S"}
    )
    e_r = tuple(row for row in all_cross if row.get("corruption") == "E-R")
    e_s = tuple(row for row in all_cross if row.get("corruption") == "E-S")
    decomposition = decompose_cross_matrix(
        y_rr=_family_macro(e_r, "P-R"),
        y_rs=_family_macro(e_s, "P-R"),
        y_sr=_family_macro(e_r, "P-S-multi"),
        y_ss=_family_macro(e_s, "P-S-multi"),
    )
    return {
        "classification": classify_signal(evidence),
        "evidence": asdict(evidence),
        "primary": asdict(primary),
        "full_finetune_gain": full_gain,
        "positive_seed_directions": evidence.positive_seed_directions,
        "component_differences": components,
        "positive_component_metrics": evidence.positive_component_metrics,
        "e_r_effect": e_r_effect,
        "e_r_interval": asdict(e_r_interval),
        "e_s_interval": asdict(e_s_interval),
        "systematic_reversals": reversals,
        "cross_matrix": asdict(decomposition),
    }


def _optional_mean(rows: Sequence[dict[str, object]], field: str) -> float | None:
    values = [row.get(field) for row in rows if row.get(field) is not None]
    return float(np.mean([_float(value) for value in values])) if values else None


def _flat_group_summary(rows: Sequence[dict[str, object]]) -> dict[str, object]:
    families: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        families[str(row["prototype_family"])].append(row)
    return {
        "state_count": len(rows),
        "family_count": len(families),
        "micro_component_pass": float(
            np.mean([_float(row["component_pass_count"]) for row in rows])
        ),
        "family_macro_component_pass": float(
            np.mean(
                [
                    np.mean([_float(row["component_pass_count"]) for row in family])
                    for family in families.values()
                ]
            )
        ),
        "micro_strict_success": float(
            np.mean([bool(row["strict_success"]) for row in rows])
        ),
        "family_macro_strict_success": float(
            np.mean(
                [
                    np.mean([bool(row["strict_success"]) for row in family])
                    for family in families.values()
                ]
            )
        ),
        "mean_orbit_multiplicity_accuracy": float(
            np.mean([_float(row["orbit_multiplicity_accuracy"]) for row in rows])
        ),
        "orbit_multiplicity_exact_rate": float(
            np.mean([_float(row["orbit_multiplicity_accuracy"]) == 1.0 for row in rows])
        ),
        "mean_wyckoff_accuracy": float(
            np.mean([_float(row["wyckoff_accuracy"]) for row in rows])
        ),
        "wyckoff_exact_rate": float(
            np.mean([_float(row["wyckoff_accuracy"]) == 1.0 for row in rows])
        ),
        "mean_periodic_edge_f1": float(
            np.mean([_float(row["periodic_edge_f1"]) for row in rows])
        ),
        "periodic_edge_exact_rate": float(
            np.mean([_float(row["periodic_edge_f1"]) == 1.0 for row in rows])
        ),
        "structure_match_rate": float(
            np.mean([bool(row["structure_match"]) for row in rows])
        ),
        "short_contact_free_rate": float(
            np.mean([not bool(row["short_contact"]) for row in rows])
        ),
        "mean_coordinate_smooth_l1": _optional_mean(rows, "coordinate_smooth_l1"),
        "mean_cartesian_mic_rmsd": _optional_mean(rows, "cartesian_mic_rmsd"),
        "generation_rejection_rate": float(
            np.mean([row.get("score_policy") == "zero_no_refill" for row in rows])
        ),
    }


def _site_stratum(site_count: int) -> str:
    if site_count <= 8:
        return "2-8"
    if site_count <= 12:
        return "9-12"
    if site_count <= 16:
        return "13-16"
    return "17-20"


def _group_summary(rows: Sequence[dict[str, object]]) -> dict[str, object]:
    summary = _flat_group_summary(rows)
    strata: dict[str, dict[str, object]] = {}
    for label in ("2-8", "9-12", "13-16", "17-20"):
        subset = tuple(
            row for row in rows if _site_stratum(_int(row["site_count"])) == label
        )
        if subset:
            strata[label] = _flat_group_summary(subset)
    summary["site_count_summaries"] = strata
    return summary


def build_blind_report(rows: Sequence[dict[str, object]]) -> dict[str, object]:
    analysis = analyze_prediction_rows(rows, draws=10000, seed=20260820)
    grouped: dict[str, dict[str, object]] = {}
    group_keys = sorted(
        {
            (
                str(row["partition"]),
                str(row["stage"]),
                str(row["arm"]),
                str(row["corruption"]),
            )
            for row in rows
        }
    )
    for partition, stage, arm, corruption in group_keys:
        subset = tuple(
            row
            for row in rows
            if (
                row["partition"],
                row["stage"],
                row["arm"],
                row["corruption"],
            )
            == (partition, stage, arm, corruption)
        )
        grouped[f"{partition}/{stage}/{arm}/{corruption}"] = _group_summary(
            subset
        )
    classification = str(analysis["classification"])
    return {
        "schema_version": "2.0.0",
        "analysis": analysis,
        "group_summaries": grouped,
        "final_status_fields": {
            "OLD_GATE1_PROMOTION_DECISION": "NO_GO",
            "SEMANTIC_DECONSTRUCTION_HISTORICAL_SIGNAL": "SUPPORTED",
            "GATE1B_V1_STATUS": "ARCHIVED_BEFORE_TRAINING",
            "GATE1B_V2_DESIGN_STATUS": "COMPLETE",
            "COMMON_DOWNSTREAM_TASK_STATUS": "BLIND_EVALUATED",
            "FROZEN_PROBE_STATUS": "COMPLETE",
            "FULL_FINETUNE_STATUS": "COMPLETE",
            "CROSS_MATRIX_STATUS": "COMPLETE",
            "ORACLE_SUBSTITUTION_STATUS": "COMPLETE_OLD_PUBLIC_DATA_ONLY",
            "GENERAL_TRANSFER_STATUS": classification,
            "TASK_SPECIFIC_BENEFIT_STATUS": (
                "SUPPORTED"
                if classification == "TASK_SPECIFIC_SEMANTIC_BENEFIT"
                else "NOT_PRIMARY_CLASSIFICATION"
            ),
            "ARCHITECTURE_BOTTLENECK_STATUS": "NOT_REEVALUATED_ON_FRESH_BLIND",
            "FULL_ASSEMBLY_DYNAMICS_STATUS": "NOT_TESTED",
            "FORMAL_TRAINING_STARTED": True,
            "BLIND_TEST_ACCESSED": True,
            "WAITING_FOR_USER_APPROVAL": False,
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--matrix-root", type=Path, required=True)
    parser.add_argument("--results-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    from ..blind_runner import (
        build_blind_evaluation_jobs,
        job_manifest_path,
        validate_completed_jobs,
    )

    jobs = build_blind_evaluation_jobs(args.matrix_root)
    validate_completed_jobs(args.results_root, jobs)
    rows: list[dict[str, object]] = []
    for job in jobs:
        predictions = job_manifest_path(args.results_root, job).parent / "predictions.jsonl"
        rows.extend(
            json.loads(line)
            for line in predictions.read_text(encoding="utf-8").splitlines()
            if line.strip()
        )
    report = build_blind_report(tuple(rows))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(report["final_status_fields"], sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
