from __future__ import annotations

from dataclasses import dataclass

from ..experiments.deconstruction import (
    CorruptionVariant,
    matched_corruptions,
    semantic_paths,
)
from ..experiments.symmetry import CanonicalCrystal


@dataclass(frozen=True, slots=True)
class ArmMask:
    path_index: int
    missing_site_indices: tuple[int, ...]
    mechanism: str
    example_seed: int


def arm_masks(
    crystal: CanonicalCrystal, *, seed: int, paths_per_parent: int
) -> dict[str, tuple[ArmMask, ...]]:
    semantic = semantic_paths(
        crystal,
        count=paths_per_parent,
        min_fraction=0.2,
        max_fraction=0.4,
        seed=seed,
    )
    matched = matched_corruptions(
        crystal,
        semantic,
        count=paths_per_parent,
        min_fraction=0.2,
        max_fraction=0.4,
        seed=seed,
    )
    indexed = {(row.variant, row.path_index): row for row in matched}
    random_rows = tuple(
        ArmMask(
            path_index=index,
            missing_site_indices=indexed[(CorruptionVariant.M1, index)].missing_site_indices,
            mechanism="random",
            example_seed=indexed[(CorruptionVariant.M1, index)].example_seed,
        )
        for index in range(paths_per_parent)
    )
    semantic_rows = tuple(
        ArmMask(
            path_index=index,
            missing_site_indices=indexed[(CorruptionVariant.M3, index)].missing_site_indices,
            mechanism="semantic",
            example_seed=indexed[(CorruptionVariant.M3, index)].example_seed,
        )
        for index in range(paths_per_parent)
    )
    canonical = semantic_rows[0]
    single_rows = tuple(
        ArmMask(
            path_index=index,
            missing_site_indices=canonical.missing_site_indices,
            mechanism="semantic-single",
            example_seed=canonical.example_seed + index,
        )
        for index in range(paths_per_parent)
    )
    mixed_rows = tuple(
        random_rows[index] if index % 2 == 0 else semantic_rows[index]
        for index in range(paths_per_parent)
    )
    return {
        "P-R": random_rows,
        "P-S-single": single_rows,
        "P-S-multi": semantic_rows,
        "P-M": mixed_rows,
    }
