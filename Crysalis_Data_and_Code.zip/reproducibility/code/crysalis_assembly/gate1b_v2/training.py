from __future__ import annotations

import hashlib
import io
from dataclasses import dataclass
from pathlib import Path

import torch
from torch import nn

from ..experiments.model import PeriodicCompletionModel

HEAD_PREFIXES = (
    "orbit_head",
    "wyckoff_head",
    "edge_mlp",
    "stop_head",
    "invalid_head",
)


@dataclass(frozen=True, slots=True)
class TransferPreparationEvidence:
    initial_checkpoint_sha256: str
    encoder_sha256_before: str
    frozen_probe: bool


def _file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def encoder_digest(model: PeriodicCompletionModel) -> str:
    state = {
        name: value.detach().cpu()
        for name, value in model.state_dict().items()
        if not name.startswith(HEAD_PREFIXES)
    }
    buffer = io.BytesIO()
    torch.save(state, buffer)
    return hashlib.sha256(buffer.getvalue()).hexdigest()


def _reset(module: nn.Module) -> None:
    if isinstance(module, nn.Linear):
        module.reset_parameters()


def prepare_transfer_model(
    model: PeriodicCompletionModel,
    *,
    initial_checkpoint: Path,
    seed: int,
    frozen_probe: bool,
) -> TransferPreparationEvidence:
    checkpoint = torch.load(initial_checkpoint, map_location="cpu", weights_only=False)
    model_state = checkpoint.get("model")
    if not isinstance(model_state, dict):
        raise TypeError("initial checkpoint has no model state")
    model.load_state_dict(model_state)
    before = encoder_digest(model)
    if frozen_probe:
        with torch.random.fork_rng():
            torch.manual_seed(seed)
            model.orbit_head.apply(_reset)
            model.wyckoff_head.apply(_reset)
            model.edge_mlp.apply(_reset)
            model.stop_head.apply(_reset)
            model.invalid_head.apply(_reset)
        for name, parameter in model.named_parameters():
            if not name.startswith(HEAD_PREFIXES):
                parameter.requires_grad_(False)
    return TransferPreparationEvidence(
        initial_checkpoint_sha256=_file_hash(initial_checkpoint),
        encoder_sha256_before=before,
        frozen_probe=frozen_probe,
    )
