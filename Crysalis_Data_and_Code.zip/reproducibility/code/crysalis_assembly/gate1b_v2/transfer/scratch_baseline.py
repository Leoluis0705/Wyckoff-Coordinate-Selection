from __future__ import annotations


def scratch_q_updates(pretraining_updates: int, downstream_updates: int) -> int:
    total = pretraining_updates + downstream_updates
    if total <= 0:
        raise ValueError("training budget must be positive")
    return total
