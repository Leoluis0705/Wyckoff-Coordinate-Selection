from __future__ import annotations

import hashlib
import io

import torch


def freeze_encoder(module: torch.nn.Module) -> None:
    module.requires_grad_(False)


def encoder_digest(module: torch.nn.Module) -> str:
    buffer = io.BytesIO()
    torch.save(module.state_dict(), buffer)
    return hashlib.sha256(buffer.getvalue()).hexdigest()
