"""Common downstream transfer protocols."""
