from __future__ import annotations


def assert_equal_updates(updates_by_arm: dict[str, int]) -> int:
    if not updates_by_arm or len(set(updates_by_arm.values())) != 1:
        raise ValueError("all arms must use equal downstream updates")
    updates = next(iter(updates_by_arm.values()))
    if updates <= 0:
        raise ValueError("downstream updates must be positive")
    return updates
