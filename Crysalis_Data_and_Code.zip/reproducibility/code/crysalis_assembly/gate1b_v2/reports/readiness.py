from __future__ import annotations

from ..preregistration.schema import validate_readiness_states


def assert_design_only_readiness(states: dict[str, object]) -> None:
    validate_readiness_states(states)
