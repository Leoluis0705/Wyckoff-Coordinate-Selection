from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from dataclasses import asdict
from pathlib import Path

from ...experiments.deconstruction import semantic_paths
from ...experiments.mp20 import load_mp20_records
from ...experiments.symmetry import canonicalize_record
from ...gate1b.blind_lock import open_public_manifest
from ..corruption.connected_region import (
    ConnectedRegionError,
    ConnectedRegionSpec,
    connected_region_corruption,
)


def _site_bin(count: int) -> str:
    if count <= 8:
        return "2-8"
    if count <= 12:
        return "9-12"
    if count <= 16:
        return "13-16"
    return "17-20"


def public_qc_feasibility(
    *,
    mp20_root: Path,
    public_manifest: Path,
    source_manifest: Path,
    spec: ConnectedRegionSpec,
) -> dict[str, object]:
    public_rows = open_public_manifest(public_manifest)
    public_by_id = {str(row["material_id"]): row for row in public_rows}
    source_payload = json.loads(source_manifest.read_text(encoding="utf-8"))
    expected_hashes = dict(source_payload["sha256_by_file"])
    records, source = load_mp20_records(
        mp20_root, expected_hashes=expected_hashes, strict_hashes=True
    )
    record_by_id = {record.material_id: record for record in records}
    missing = sorted(set(public_by_id) - set(record_by_id))
    if missing:
        raise ValueError(f"public parents missing from MP-20: {missing[:5]}")
    family_partitions: dict[str, set[str]] = defaultdict(set)
    for row in public_rows:
        family_partitions[str(row["prototype_family"])].add(str(row["partition"]))
    crossing = sum(len(partitions) > 1 for partitions in family_partitions.values())

    state_status: Counter[str] = Counter()
    parent_status: Counter[str] = Counter()
    by_partition: Counter[str] = Counter()
    by_site_bin: Counter[str] = Counter()
    missing_counts: Counter[int] = Counter()
    example_hashes: list[str] = []
    for index, material_id in enumerate(sorted(public_by_id), start=1):
        row = public_by_id[material_id]
        crystal = canonicalize_record(
            record_by_id[material_id],
            symprec_values=(0.03, 0.05, 0.1),
            angle_tolerance=5.0,
            max_sites=20,
            min_elements=2,
            max_elements=4,
        )
        paths = semantic_paths(
            crystal, count=4, min_fraction=0.2, max_fraction=0.4, seed=spec.seed
        )
        accepted_for_parent = 0
        for path in paths:
            try:
                state = connected_region_corruption(
                    crystal,
                    prototype_family=str(row["prototype_family"]),
                    missing_count=len(path.missing_site_indices),
                    path_index=path.path_index,
                    spec=spec,
                )
            except ConnectedRegionError as exc:
                state_status[f"rejected:{exc}"] += 1
            else:
                state_status["accepted"] += 1
                accepted_for_parent += 1
                missing_counts[state.missing_count] += 1
                if len(example_hashes) < 10:
                    example_hashes.append(state.corruption_hash)
        parent_status["all_four_accepted" if accepted_for_parent == 4 else "has_rejection"] += 1
        by_partition[str(row["partition"])] += 1
        by_site_bin[_site_bin(crystal.site_count)] += 1
        if index % 1000 == 0:
            print(json.dumps({"public_parents_checked": index}), flush=True)
    return {
        "schema_version": "1.0.0",
        "source_records": source.total_records,
        "public_parent_count": len(public_rows),
        "public_family_count": len(family_partitions),
        "family_cross_partition_count": crossing,
        "parent_status": dict(sorted(parent_status.items())),
        "state_status": dict(sorted(state_status.items())),
        "partition_counts": dict(sorted(by_partition.items())),
        "site_bin_parent_counts": dict(sorted(by_site_bin.items())),
        "accepted_missing_count_distribution": dict(sorted(missing_counts.items())),
        "first_ten_corruption_hashes": example_hashes,
        "sealed_manifest_opened": False,
        "spec": asdict(spec),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mp20-root", type=Path, required=True)
    parser.add_argument("--public-manifest", type=Path, required=True)
    parser.add_argument("--source-manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    payload = public_qc_feasibility(
        mp20_root=args.mp20_root,
        public_manifest=args.public_manifest,
        source_manifest=args.source_manifest,
        spec=ConnectedRegionSpec(seed=20260821, alpha=1.35, max_distance=5.0),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
