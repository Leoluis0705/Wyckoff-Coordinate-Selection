"""Gate 1b-v2 evidence report helpers."""
