from __future__ import annotations

import argparse
import hashlib
import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path

import torch

from ..experiments.deconstruction import CorruptionVariant
from ..experiments.gate1 import _evaluate_run
from ..experiments.train_gate1 import load_gate1_config
from .analysis.component_pass import component_pass_from_prediction

SEEDS = (20260820, 20260821, 20260822)
TRANSFER_ARMS = ("P-R", "P-S-single", "P-S-multi", "P-M")
CROSS_ARMS = ("P-R", "P-S-multi", "P-M")
PARTITIONS = ("iid_test", "blind_ood")


@dataclass(frozen=True, slots=True)
class BlindEvaluationJob:
    stage: str
    arm: str
    seed: int
    corruption: str
    partition: str
    checkpoint_path: Path

    @property
    def key(self) -> str:
        return "/".join(
            (self.stage, self.arm, str(self.seed), self.corruption, self.partition)
        )


def build_blind_evaluation_jobs(output_root: Path) -> tuple[BlindEvaluationJob, ...]:
    output_root = Path(output_root)
    jobs: list[BlindEvaluationJob] = []
    for stage in ("probe", "finetune"):
        for arm in TRANSFER_ARMS:
            for seed in SEEDS:
                for partition in PARTITIONS:
                    jobs.append(
                        BlindEvaluationJob(
                            stage=stage,
                            arm=arm,
                            seed=seed,
                            corruption="Q-C",
                            partition=partition,
                            checkpoint_path=output_root
                            / stage
                            / arm
                            / f"seed-{seed}"
                            / "checkpoint.pt",
                        )
                    )
    for seed in SEEDS:
        for partition in PARTITIONS:
            jobs.append(
                BlindEvaluationJob(
                    stage="scratch",
                    arm="Scratch-Q",
                    seed=seed,
                    corruption="Q-C",
                    partition=partition,
                    checkpoint_path=output_root
                    / "scratch"
                    / f"seed-{seed}"
                    / "checkpoint.pt",
                )
            )
    for arm in CROSS_ARMS:
        for seed in SEEDS:
            for corruption in ("E-R", "E-S"):
                for partition in PARTITIONS:
                    jobs.append(
                        BlindEvaluationJob(
                            stage="pretraining",
                            arm=arm,
                            seed=seed,
                            corruption=corruption,
                            partition=partition,
                            checkpoint_path=output_root
                            / "pretraining"
                            / arm
                            / f"seed-{seed}"
                            / "checkpoint.pt",
                        )
                    )
    return tuple(jobs)


def job_manifest_path(root: Path, job: BlindEvaluationJob) -> Path:
    return (
        Path(root)
        / job.stage
        / job.arm
        / f"seed-{job.seed}"
        / job.corruption
        / job.partition
        / "blind_job_manifest.json"
    )


def validate_completed_jobs(
    root: Path, jobs: tuple[BlindEvaluationJob, ...]
) -> tuple[Path, ...]:
    completed: list[Path] = []
    missing: list[str] = []
    invalid: list[str] = []
    for job in jobs:
        path = job_manifest_path(root, job)
        if not path.is_file():
            missing.append(job.key)
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            invalid.append(job.key)
            continue
        if payload.get("status") != "completed" or payload.get("job_key") != job.key:
            invalid.append(job.key)
            continue
        predictions = path.parent / "predictions.jsonl"
        try:
            prediction_count = sum(
                bool(line.strip())
                for line in predictions.read_text(encoding="utf-8").splitlines()
            )
        except OSError:
            invalid.append(job.key)
            continue
        if (
            payload.get("predictions_sha256") != _sha256(predictions)
            or payload.get("prediction_count") != prediction_count
            or payload.get("retry_count") != 0
            or payload.get("refill_count") != 0
        ):
            invalid.append(job.key)
            continue
        completed.append(path)
    if missing or invalid:
        parts = []
        if missing:
            parts.append(f"missing blind evaluation jobs: {missing}")
        if invalid:
            parts.append(f"invalid blind evaluation jobs: {invalid}")
        raise ValueError("; ".join(parts))
    return tuple(completed)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _as_int(value: object) -> int:
    if not isinstance(value, (int, str)) or isinstance(value, bool):
        raise TypeError("blind prediction identity must be an integer")
    return int(value)


def _atomic_json(path: Path, payload: dict[str, object]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    os.replace(temporary, path)


def run_blind_job(
    *,
    job: BlindEvaluationJob,
    cache_path: Path,
    output_root: Path,
    config_path: Path,
    device: str,
) -> dict[str, object]:
    output_dir = job_manifest_path(output_root, job).parent
    if output_dir.exists() and any(output_dir.iterdir()):
        raise ValueError(f"blind job output already exists; retry forbidden: {job.key}")
    if not job.checkpoint_path.is_file():
        raise ValueError(f"blind job checkpoint is missing: {job.checkpoint_path}")
    cache = torch.load(cache_path, map_location="cpu", weights_only=False)
    if cache.get("sealed_manifest_accessed") is not True:
        raise ValueError("blind cache does not certify sealed access")
    ledgers = cache.get("ledgers")
    if not isinstance(ledgers, dict) or job.corruption not in ledgers:
        raise ValueError(f"blind cache is missing corruption ledger: {job.corruption}")
    records = tuple(
        record
        for record in ledgers[job.corruption]
        if record.model_partition == job.partition
    )
    rejections = tuple(
        row
        for row in cache.get("q_c_rejections", ())
        if job.corruption == "Q-C" and row.get("partition") == job.partition
    )
    if not records and not rejections:
        raise ValueError(f"blind job has no states: {job.key}")
    config = load_gate1_config(config_path)
    variant = {
        "Q-C": CorruptionVariant.M0,
        "E-R": CorruptionVariant.M1,
        "E-S": CorruptionVariant.M3,
    }[job.corruption]
    resolved = torch.device(
        "cuda" if device == "auto" and torch.cuda.is_available() else device
        if device != "auto"
        else "cpu"
    )
    metrics = (
        _evaluate_run(
            records=records,
            run_dir=job.checkpoint_path.parent,
            config=config,
            variant=variant,
            seed=job.seed,
            device=resolved,
        )
        if records
        else ()
    )
    rows: list[dict[str, object]] = []
    for metric, record in zip(metrics, records, strict=True):
        row = {
            **asdict(metric),
            "stage": job.stage,
            "arm": job.arm,
            "corruption": job.corruption,
            "strict_success": metric.strict_success,
            "failure_reasons": metric.failure_reasons,
            "site_count": len(record.atomic_numbers),
            "space_group": record.space_group,
            "missing_count": len(record.missing_site_indices),
            "missing_ratio": len(record.missing_site_indices)
            / len(record.atomic_numbers),
            "evaluation_pair_id": (
                f"{record.material_id}:{record.path_index}:"
                f"{len(record.missing_site_indices)}"
            ),
        }
        row["component_pass_count"] = component_pass_from_prediction(row)
        rows.append(row)
    rows.extend(
        rejection_prediction(
            material_id=str(row["material_id"]),
            prototype_family=str(row["prototype_family"]),
            partition=str(row["partition"]),
            path_index=int(row["path_index"]),
            stage=job.stage,
            arm=job.arm,
            seed=job.seed,
            corruption=job.corruption,
            reason=str(row["reason"]),
            site_count=int(row["site_count"]),
            missing_count=int(row["missing_count"]),
            missing_ratio=float(row["missing_ratio"]),
        )
        for row in rejections
    )
    rows.sort(
        key=lambda row: (
            str(row["material_id"]),
            _as_int(row["path_index"]),
            _as_int(row["seed"]),
        )
    )
    output_dir.mkdir(parents=True, exist_ok=False)
    predictions = output_dir / "predictions.jsonl"
    temporary = predictions.with_suffix(".jsonl.tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, sort_keys=True, allow_nan=False) + "\n")
    os.replace(temporary, predictions)
    manifest: dict[str, object] = {
        "schema_version": "2.0.0",
        "status": "completed",
        "job_key": job.key,
        "stage": job.stage,
        "arm": job.arm,
        "seed": job.seed,
        "corruption": job.corruption,
        "partition": job.partition,
        "record_count": len(records),
        "rejection_count": len(rejections),
        "prediction_count": len(rows),
        "checkpoint_sha256": _sha256(job.checkpoint_path),
        "cache_sha256": _sha256(cache_path),
        "config_sha256": _sha256(config_path),
        "predictions_sha256": _sha256(predictions),
        "retry_count": 0,
        "refill_count": 0,
    }
    _atomic_json(job_manifest_path(output_root, job), manifest)
    return manifest


def _config_path(config_root: Path, job: BlindEvaluationJob) -> Path:
    return config_root / (
        "pretrain.json"
        if job.stage == "pretraining"
        else "scratch.json"
        if job.stage == "scratch"
        else "downstream.json"
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", required=True)
    parser.add_argument("--arm", required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--corruption", required=True)
    parser.add_argument("--partition", required=True)
    parser.add_argument("--matrix-root", type=Path, required=True)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--config-root", type=Path, required=True)
    parser.add_argument("--device", default="auto")
    args = parser.parse_args()
    jobs = build_blind_evaluation_jobs(args.matrix_root)
    selected = tuple(
        job
        for job in jobs
        if (
            job.stage,
            job.arm,
            job.seed,
            job.corruption,
            job.partition,
        )
        == (args.stage, args.arm, args.seed, args.corruption, args.partition)
    )
    if len(selected) != 1:
        raise ValueError("requested blind job is not in the frozen matrix")
    manifest = run_blind_job(
        job=selected[0],
        cache_path=args.cache,
        output_root=args.output_root,
        config_path=_config_path(args.config_root, selected[0]),
        device=args.device,
    )
    print(json.dumps(manifest, sort_keys=True))
    return 0


def rejection_prediction(
    *,
    material_id: str,
    prototype_family: str,
    partition: str,
    path_index: int,
    stage: str,
    arm: str,
    seed: int,
    corruption: str,
    reason: str,
    site_count: int = 0,
    missing_count: int = 0,
    missing_ratio: float = 0.0,
) -> dict[str, object]:
    return {
        "material_id": material_id,
        "prototype_family": prototype_family,
        "partition": partition,
        "path_index": path_index,
        "stage": stage,
        "arm": arm,
        "seed": seed,
        "corruption": corruption,
        "site_count": site_count,
        "missing_count": missing_count,
        "missing_ratio": missing_ratio,
        "evaluation_pair_id": f"{material_id}:{path_index}:{missing_count}",
        "orbit_multiplicity_accuracy": 0.0,
        "wyckoff_accuracy": 0.0,
        "periodic_edge_precision": 0.0,
        "periodic_edge_recall": 0.0,
        "periodic_edge_f1": 0.0,
        "structure_match": False,
        "short_contact": True,
        "component_pass_count": 0,
        "strict_success": False,
        "generation_rejection": reason,
        "score_policy": "zero_no_refill",
        "coordinate_smooth_l1": None,
        "cartesian_mic_rmsd": None,
    }


if __name__ == "__main__":
    raise SystemExit(main())
