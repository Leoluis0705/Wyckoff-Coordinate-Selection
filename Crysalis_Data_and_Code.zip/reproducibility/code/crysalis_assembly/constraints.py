from collections import Counter
from dataclasses import replace

from .schemas import (
    ActionType,
    AssemblyAction,
    AssemblyState,
    ConstraintRepair,
    ConstraintReport,
    ConstraintViolation,
    NodeStatus,
    ProjectionResult,
    ReasonCode,
)


def _determinant(lattice: tuple[tuple[float, float, float], ...]) -> float:
    a, b, c = lattice[0]
    d, e, f = lattice[1]
    g, h, i = lattice[2]
    return a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)


def _outside_primary_cell(position: tuple[float, float, float]) -> bool:
    return any(component < 0.0 or component >= 1.0 for component in position)


def _active_atoms(state: AssemblyState):
    return tuple(
        atom for atom in state.atom_nodes if atom.status is not NodeStatus.MISSING
    )


def _composition_counts(state: AssemblyState) -> Counter[str]:
    return Counter(atom.element for atom in _active_atoms(state))


class ConstraintCompiler:
    def check(self, state: AssemblyState) -> tuple[ConstraintViolation, ...]:
        violations: list[ConstraintViolation] = []
        if _determinant(state.lattice) <= 0.0:
            violations.append(
                ConstraintViolation(
                    code=ReasonCode.NON_POSITIVE_LATTICE,
                    message="lattice determinant must be positive",
                    object_id=state.state_id,
                    constraint_id="positive_lattice_volume",
                )
            )

        active_atoms = _active_atoms(state)
        if len(active_atoms) > state.embryo.budget.max_atoms:
            violations.append(
                ConstraintViolation(
                    code=ReasonCode.ATOM_BUDGET_EXCEEDED,
                    message=(
                        f"active atom count {len(active_atoms)} exceeds budget "
                        f"{state.embryo.budget.max_atoms}"
                    ),
                    object_id=state.state_id,
                    constraint_id="max_atoms",
                )
            )

        allowed_elements = set(state.embryo.allowed_elements)
        for orbit in state.orbit_nodes:
            if orbit.element is not None and orbit.element not in allowed_elements:
                violations.append(
                    ConstraintViolation(
                        code=ReasonCode.DISALLOWED_ELEMENT,
                        message=f"element {orbit.element} is outside the allowed set",
                        object_id=orbit.stable_id,
                        constraint_id="allowed_elements",
                    )
                )
        for atom in active_atoms:
            if atom.element not in allowed_elements:
                violations.append(
                    ConstraintViolation(
                        code=ReasonCode.DISALLOWED_ELEMENT,
                        message=f"element {atom.element} is outside the allowed set",
                        object_id=atom.stable_id,
                        constraint_id="allowed_elements",
                    )
                )

        expected_counts = {
            item.element: item.count for item in state.embryo.composition_budget
        }
        actual_counts = _composition_counts(state)
        for element in sorted(actual_counts):
            actual = actual_counts[element]
            budget = expected_counts.get(element, 0)
            if actual > budget:
                violations.append(
                    ConstraintViolation(
                        code=ReasonCode.COMPOSITION_BUDGET_EXCEEDED,
                        message=(
                            f"element {element} count {actual} exceeds budget {budget}"
                        ),
                        object_id=state.state_id,
                        constraint_id=f"composition:{element}",
                    )
                )

        for atom in active_atoms:
            if _outside_primary_cell(atom.fractional_position):
                violations.append(
                    ConstraintViolation(
                        code=ReasonCode.FRACTIONAL_COORDINATE_OUT_OF_RANGE,
                        message="fractional coordinate must be wrapped into [0, 1)",
                        object_id=atom.stable_id,
                        constraint_id="fractional_coordinate_range",
                    )
                )

        return tuple(violations)

    def validate_action(
        self, state: AssemblyState, action: AssemblyAction
    ) -> tuple[ConstraintViolation, ...]:
        violations = list(self.check(state))
        if action.source_state_id != state.state_id:
            violations.append(
                ConstraintViolation(
                    code=ReasonCode.ACTION_SOURCE_MISMATCH,
                    message="action source_state_id does not match the current state",
                    object_id=action.action_id,
                    constraint_id="action_source_state",
                )
            )

        known_targets = {
            state.embryo.embryo_id,
            *(slot.stable_id for slot in state.embryo.role_slots),
            *(slot.stable_id for slot in state.embryo.orbit_slots),
            *(node.stable_id for node in state.orbit_nodes),
            *(node.stable_id for node in state.atom_nodes),
            *(factor.stable_id for factor in state.factors),
        }
        for target in action.targets:
            if target not in known_targets:
                violations.append(
                    ConstraintViolation(
                        code=ReasonCode.UNKNOWN_ACTION_TARGET,
                        message=f"action target {target} does not exist in the state",
                        object_id=target,
                        constraint_id="known_action_target",
                    )
                )

        if action.action_type is ActionType.BIND_ELEMENT:
            element = action.parameter("element")
            if isinstance(element, str) and element not in state.embryo.allowed_elements:
                violations.append(
                    ConstraintViolation(
                        code=ReasonCode.DISALLOWED_ELEMENT,
                        message=f"element {element} is outside the allowed set",
                        object_id=action.action_id,
                        constraint_id="allowed_elements",
                    )
                )

        if action.action_type is ActionType.STOP:
            expected = {
                item.element: item.count for item in state.embryo.composition_budget
            }
            if dict(_composition_counts(state)) != expected:
                violations.append(
                    ConstraintViolation(
                        code=ReasonCode.INCOMPLETE_COMPOSITION,
                        message="Stop requires exact completion of the composition budget",
                        object_id=action.action_id,
                        constraint_id="stop_completeness",
                    )
                )

        return tuple(violations)

    def allowed_actions(
        self, state: AssemblyState, actions: tuple[AssemblyAction, ...]
    ) -> tuple[bool, ...]:
        return tuple(not self.validate_action(state, action) for action in actions)

    def project_or_reject(self, state: AssemblyState) -> ProjectionResult:
        pre_violations = self.check(state)
        non_repairable = tuple(
            violation
            for violation in pre_violations
            if violation.code is not ReasonCode.FRACTIONAL_COORDINATE_OUT_OF_RANGE
        )
        if non_repairable:
            return ProjectionResult(
                state=None,
                report=ConstraintReport(
                    pre_violations=pre_violations,
                    post_violations=pre_violations,
                    rejected=True,
                ),
            )

        if not pre_violations:
            return ProjectionResult(state=state, report=ConstraintReport())

        repaired_atoms = []
        repairs: list[ConstraintRepair] = []
        for atom in state.atom_nodes:
            if atom.status is NodeStatus.MISSING or not _outside_primary_cell(
                atom.fractional_position
            ):
                repaired_atoms.append(atom)
                continue
            wrapped = tuple(component % 1.0 for component in atom.fractional_position)
            magnitude = max(
                abs(before - after)
                for before, after in zip(atom.fractional_position, wrapped)
            )
            repaired_atoms.append(replace(atom, fractional_position=wrapped))
            repairs.append(
                ConstraintRepair(
                    code=ReasonCode.FRACTIONAL_COORDINATE_WRAPPED,
                    message="wrapped fractional coordinate into the primary cell",
                    magnitude=magnitude,
                    object_id=atom.stable_id,
                )
            )

        repaired_state = replace(state, atom_nodes=tuple(repaired_atoms))
        post_violations = self.check(repaired_state)
        if post_violations:
            return ProjectionResult(
                state=None,
                report=ConstraintReport(
                    pre_violations=pre_violations,
                    post_violations=post_violations,
                    repairs=tuple(repairs),
                    rejected=True,
                ),
            )
        return ProjectionResult(
            state=repaired_state,
            report=ConstraintReport(
                pre_violations=pre_violations,
                repairs=tuple(repairs),
            ),
        )
