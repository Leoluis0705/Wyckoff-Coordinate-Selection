from dataclasses import dataclass

from .schemas import Image3


@dataclass(frozen=True, order=True)
class PeriodicEdgeKey:
    source_id: str
    target_id: str
    image: Image3

    def as_tuple(self) -> tuple[str, str, Image3]:
        return self.source_id, self.target_id, self.image


def canonical_periodic_edge_key(
    source_id: str, target_id: str, image: tuple[int, ...]
) -> PeriodicEdgeKey:
    if not isinstance(source_id, str) or not source_id.strip():
        raise ValueError("source_id must be a non-empty string")
    if not isinstance(target_id, str) or not target_id.strip():
        raise ValueError("target_id must be a non-empty string")
    if len(image) != 3 or any(type(component) is not int for component in image):
        raise ValueError("periodic image must contain three integers")

    normalized_image: Image3 = image[0], image[1], image[2]
    if source_id == target_id and normalized_image == (0, 0, 0):
        raise ValueError("zero-image self edge is not a structural relation")

    inverse_image: Image3 = tuple(-component for component in normalized_image)
    forward = source_id, target_id, normalized_image
    reverse = target_id, source_id, inverse_image
    canonical = min(forward, reverse)
    return PeriodicEdgeKey(*canonical)
