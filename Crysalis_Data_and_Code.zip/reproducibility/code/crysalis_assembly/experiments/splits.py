from __future__ import annotations

import hashlib
import math
import warnings
from collections import defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from itertools import combinations

from pymatgen.analysis.structure_matcher import StructureMatcher

from .symmetry import CanonicalCrystal


SPLIT_NAMES = ("train", "validation", "test")
HALIDES = frozenset({"F", "Cl", "Br", "I"})


@dataclass(frozen=True, slots=True)
class SplitEntry:
    material_id: str
    source_split: str
    reduced_formula: str
    structure_hash: str
    prototype_family: str
    split: str
    space_group: int
    site_count: int
    stress_flags: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class LeakageAudit:
    duplicate_material_ids: int
    prototype_family_cross_split: int
    exact_structure_hash_cross_split: int
    near_duplicate_candidate_pairs: int
    confirmed_near_duplicate_cross_split: int
    test_structure_count: int

    @property
    def confirmed_near_duplicate_rate(self) -> float:
        return self.confirmed_near_duplicate_cross_split / max(
            self.test_structure_count, 1
        )

    def passes(self, *, max_near_duplicate_rate: float) -> bool:
        return (
            self.duplicate_material_ids == 0
            and self.prototype_family_cross_split == 0
            and self.exact_structure_hash_cross_split == 0
            and self.confirmed_near_duplicate_rate < max_near_duplicate_rate
        )


def _structure_matcher(*, scale: bool) -> StructureMatcher:
    return StructureMatcher(
        primitive_cell=False,
        scale=scale,
        attempt_supercell=False,
        ltol=0.2,
        stol=0.3,
        angle_tol=5.0,
    )


def _fit_anonymous(
    matcher: StructureMatcher, left: CanonicalCrystal, right: CanonicalCrystal
) -> bool:
    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            message="Set OLD_ERROR_HANDLING to false and catch the errors directly.*",
            category=DeprecationWarning,
        )
        return bool(matcher.fit_anonymous(left.structure, right.structure))


def assign_verified_families(
    crystals: Sequence[CanonicalCrystal],
) -> dict[str, str]:
    material_ids = [crystal.material_id for crystal in crystals]
    if len(material_ids) != len(set(material_ids)):
        raise ValueError("canonical crystals must have unique material IDs")

    buckets: dict[str, list[CanonicalCrystal]] = defaultdict(list)
    for crystal in crystals:
        buckets[crystal.prototype_signature].append(crystal)

    matcher = _structure_matcher(scale=True)
    family_by_material: dict[str, str] = {}
    for signature in sorted(buckets):
        clusters: list[list[CanonicalCrystal]] = []
        for crystal in sorted(buckets[signature], key=lambda item: item.material_id):
            for cluster in clusters:
                if _fit_anonymous(matcher, cluster[0], crystal):
                    cluster.append(crystal)
                    break
            else:
                clusters.append([crystal])

        for cluster_index, cluster in enumerate(clusters):
            digest = hashlib.sha256(
                f"{signature}|cluster:{cluster_index}".encode("utf-8")
            ).hexdigest()[:20]
            family_id = f"proto-{digest}"
            for crystal in cluster:
                family_by_material[crystal.material_id] = family_id
    return family_by_material


def stress_flags(crystal: CanonicalCrystal) -> tuple[str, ...]:
    flags = []
    elements = {element.symbol for element in crystal.structure.composition.elements}
    if elements & HALIDES:
        flags.append("halide")
    if crystal.site_count >= 18:
        flags.append("high_site_count")
    if crystal.space_group <= 15:
        flags.append("low_symmetry")
    return tuple(sorted(flags))


def _validate_ratios(ratios: Mapping[str, float]) -> dict[str, float]:
    if set(ratios) != set(SPLIT_NAMES):
        raise ValueError("split ratios must define train, validation, and test")
    normalized = {name: float(ratios[name]) for name in SPLIT_NAMES}
    if any(not math.isfinite(value) or value <= 0 for value in normalized.values()):
        raise ValueError("split ratios must be finite and positive")
    if abs(sum(normalized.values()) - 1.0) > 1e-9:
        raise ValueError("split ratios must sum to 1")
    return normalized


def assign_grouped_splits(
    crystals: Sequence[CanonicalCrystal],
    family_by_material: Mapping[str, str],
    ratios: Mapping[str, float],
    seed: int,
) -> tuple[SplitEntry, ...]:
    ratios = _validate_ratios(ratios)
    missing = sorted(
        crystal.material_id
        for crystal in crystals
        if crystal.material_id not in family_by_material
    )
    if missing:
        raise ValueError(f"missing prototype families for: {', '.join(missing)}")

    families: dict[str, list[CanonicalCrystal]] = defaultdict(list)
    for crystal in crystals:
        families[family_by_material[crystal.material_id]].append(crystal)
    ranked_families = sorted(
        families.items(),
        key=lambda item: (
            -len(item[1]),
            hashlib.sha256(f"{seed}:{item[0]}".encode("utf-8")).hexdigest(),
            item[0],
        ),
    )
    total = len(crystals)
    targets = {name: ratios[name] * total for name in SPLIT_NAMES}
    counts = {name: 0 for name in SPLIT_NAMES}
    split_by_family: dict[str, str] = {}
    for family_id, members in ranked_families:
        chosen = max(
            SPLIT_NAMES,
            key=lambda name: (
                (targets[name] - counts[name]) / max(targets[name], 1.0),
                -SPLIT_NAMES.index(name),
            ),
        )
        split_by_family[family_id] = chosen
        counts[chosen] += len(members)

    entries = []
    for crystal in sorted(crystals, key=lambda item: item.material_id):
        family = family_by_material[crystal.material_id]
        entries.append(
            SplitEntry(
                material_id=crystal.material_id,
                source_split=crystal.record.source_split,
                reduced_formula=crystal.reduced_formula,
                structure_hash=crystal.structure_hash,
                prototype_family=family,
                split=split_by_family[family],
                space_group=crystal.space_group,
                site_count=crystal.site_count,
                stress_flags=stress_flags(crystal),
            )
        )
    return tuple(entries)


def _cross_split_groups(
    entries: Sequence[SplitEntry], field: str
) -> dict[str, set[str]]:
    groups: dict[str, set[str]] = defaultdict(set)
    for entry in entries:
        groups[str(getattr(entry, field))].add(entry.split)
    return groups


def audit_split(
    entries: Sequence[SplitEntry],
    crystals_by_id: Mapping[str, CanonicalCrystal],
) -> LeakageAudit:
    ids = [entry.material_id for entry in entries]
    duplicate_ids = len(ids) - len(set(ids))
    family_groups = _cross_split_groups(entries, "prototype_family")
    hash_groups = _cross_split_groups(entries, "structure_hash")
    family_cross = sum(len(splits) > 1 for splits in family_groups.values())
    hash_cross = sum(len(splits) > 1 for splits in hash_groups.values())

    exact_members: dict[str, list[SplitEntry]] = defaultdict(list)
    for entry in entries:
        exact_members[entry.structure_hash].append(entry)
    confirmed_pairs: set[tuple[str, str]] = set()
    candidate_pairs: set[tuple[str, str]] = set()
    for members in exact_members.values():
        for left, right in combinations(members, 2):
            if left.split != right.split:
                pair = tuple(sorted((left.material_id, right.material_id)))
                candidate_pairs.add(pair)
                confirmed_pairs.add(pair)

    candidate_buckets: dict[tuple[str, int], list[SplitEntry]] = defaultdict(list)
    for entry in entries:
        candidate_buckets[(entry.reduced_formula, entry.space_group)].append(entry)
    matcher = _structure_matcher(scale=True)
    for members in candidate_buckets.values():
        for left, right in combinations(members, 2):
            if left.split == right.split:
                continue
            pair = tuple(sorted((left.material_id, right.material_id)))
            candidate_pairs.add(pair)
            if pair in confirmed_pairs:
                continue
            left_crystal = crystals_by_id.get(left.material_id)
            right_crystal = crystals_by_id.get(right.material_id)
            if left_crystal is None or right_crystal is None:
                raise ValueError("leakage audit is missing a canonical crystal")
            with warnings.catch_warnings():
                warnings.filterwarnings(
                    "ignore",
                    message="Set OLD_ERROR_HANDLING to false and catch the errors directly.*",
                    category=DeprecationWarning,
                )
                if matcher.fit(left_crystal.structure, right_crystal.structure):
                    confirmed_pairs.add(pair)

    test_count = sum(entry.split == "test" for entry in entries)
    return LeakageAudit(
        duplicate_material_ids=duplicate_ids,
        prototype_family_cross_split=family_cross,
        exact_structure_hash_cross_split=hash_cross,
        near_duplicate_candidate_pairs=len(candidate_pairs),
        confirmed_near_duplicate_cross_split=len(confirmed_pairs),
        test_structure_count=test_count,
    )
