from __future__ import annotations

import hashlib
import json
import math
import random
from collections import Counter, defaultdict
from collections.abc import Sequence
from dataclasses import dataclass, replace
from pathlib import Path

from .deconstruction import CorruptionVariant
from .mp20 import load_mp20_records
from .symmetry import CanonicalCrystal, canonicalize_record


Vector3 = tuple[float, float, float]
Matrix3 = tuple[Vector3, Vector3, Vector3]

GATE0_EVIDENCE_FILES = {
    "source_manifest.json",
    "clean_manifest.jsonl",
    "rejections.jsonl",
    "split_manifest.jsonl",
    "corruption_manifest.jsonl",
    "oracle_roundtrip_manifest.jsonl",
}


class ModelDataError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class CompletionRecord:
    material_id: str
    prototype_family: str
    split: str
    stress_flags: tuple[str, ...]
    variant: CorruptionVariant
    path_index: int
    example_seed: int
    lattice: Matrix3
    atomic_numbers: tuple[int, ...]
    fractional_coordinates: tuple[Vector3, ...]
    orbit_multiplicities: tuple[int, ...]
    wyckoff_indices: tuple[int, ...]
    space_group: int
    missing_site_indices: tuple[int, ...]
    model_partition: str | None = None

    def __post_init__(self) -> None:
        site_count = len(self.atomic_numbers)
        if site_count == 0:
            raise ValueError("completion record must contain atoms")
        if not (
            len(self.fractional_coordinates)
            == len(self.orbit_multiplicities)
            == len(self.wyckoff_indices)
            == site_count
        ):
            raise ValueError("completion record site fields must have equal length")
        if not self.missing_site_indices:
            raise ValueError("completion record must contain missing sites")
        if tuple(sorted(set(self.missing_site_indices))) != self.missing_site_indices:
            raise ValueError("missing site indices must be sorted and unique")
        if self.missing_site_indices[-1] >= site_count:
            raise ValueError("missing site index is out of range")


@dataclass(frozen=True, slots=True)
class CompletionInput:
    material_id: str
    model_partition: str
    lattice: Matrix3
    atomic_numbers: tuple[int, ...]
    fractional_coordinates: tuple[Vector3, ...]
    query_mask: tuple[bool, ...]
    space_group: int
    missing_count: int


@dataclass(frozen=True, slots=True)
class CompletionTarget:
    material_id: str
    full_fractional_coordinates: tuple[Vector3, ...]
    query_fractional_coordinates: tuple[Vector3, ...]
    query_orbit_multiplicities: tuple[int, ...]
    query_wyckoff_indices: tuple[int, ...]
    original_site_indices: tuple[int, ...]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _read_json(path: Path) -> dict[str, object]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ModelDataError(f"cannot read {path.name}: {exc}") from exc
    if not isinstance(payload, dict):
        raise ModelDataError(f"{path.name} must contain a JSON object")
    return payload


def _read_jsonl(path: Path) -> list[dict[str, object]]:
    try:
        rows = [
            json.loads(line)
            for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
    except (OSError, json.JSONDecodeError) as exc:
        raise ModelDataError(f"cannot read {path.name}: {exc}") from exc
    if any(not isinstance(row, dict) for row in rows):
        raise ModelDataError(f"{path.name} must contain JSON objects")
    return rows


def verify_gate0_artifacts(gate0_dir: Path) -> dict[str, object]:
    gate0_dir = Path(gate0_dir)
    report = _read_json(gate0_dir / "gate0_report.json")
    if report.get("gate0_pass") is not True:
        raise ModelDataError("Gate 0 report is not a PASS")
    hashes = report.get("artifact_hashes")
    if not isinstance(hashes, dict) or set(hashes) != GATE0_EVIDENCE_FILES:
        raise ModelDataError("Gate 0 artifact hash ledger is incomplete")
    for filename, expected in sorted(hashes.items()):
        path = gate0_dir / filename
        if not path.is_file():
            raise ModelDataError(f"missing Gate 0 artifact {filename}")
        observed = _sha256(path)
        if observed.lower() != str(expected).lower():
            raise ModelDataError(
                f"SHA-256 mismatch for {filename}: expected {expected}, observed {observed}"
            )
    return report


def _wyckoff_index(letter: str) -> int:
    normalized = letter.strip().lower()
    if len(normalized) != 1 or not "a" <= normalized <= "z":
        raise ModelDataError(f"unsupported Wyckoff label {letter!r}")
    return ord(normalized) - ord("a")


def _site_labels(crystal: CanonicalCrystal) -> tuple[tuple[int, ...], tuple[int, ...]]:
    multiplicities = [0] * crystal.site_count
    wyckoff = [-1] * crystal.site_count
    for orbit in crystal.orbits:
        for site_index in orbit.site_indices:
            multiplicities[site_index] = orbit.multiplicity
            wyckoff[site_index] = _wyckoff_index(orbit.wyckoff_letter)
    if any(value <= 0 for value in multiplicities) or any(value < 0 for value in wyckoff):
        raise ModelDataError(f"incomplete orbit labels for {crystal.material_id}")
    return tuple(multiplicities), tuple(wyckoff)


def _canonical_crystals(
    mp20_root: Path,
    source_manifest: dict[str, object],
    clean_rows: Sequence[dict[str, object]],
) -> dict[str, CanonicalCrystal]:
    root_in_manifest = Path(str(source_manifest.get("root", ""))).resolve()
    if Path(mp20_root).resolve() != root_in_manifest:
        raise ModelDataError(
            f"MP-20 root mismatch: expected {root_in_manifest}, observed {Path(mp20_root).resolve()}"
        )
    raw_hashes = source_manifest.get("sha256_by_file")
    if not isinstance(raw_hashes, list):
        raise ModelDataError("source manifest SHA-256 ledger is malformed")
    try:
        expected_hashes = {str(name): str(value) for name, value in raw_hashes}
    except (TypeError, ValueError) as exc:
        raise ModelDataError("source manifest SHA-256 ledger is malformed") from exc
    source_records, _ = load_mp20_records(
        Path(mp20_root), expected_hashes=expected_hashes, strict_hashes=True
    )
    by_id = {record.material_id: record for record in source_records}
    crystals: dict[str, CanonicalCrystal] = {}
    for row in clean_rows:
        material_id = str(row.get("material_id", ""))
        source_record = by_id.get(material_id)
        if source_record is None:
            raise ModelDataError(f"clean parent {material_id} is absent from MP-20")
        crystal = canonicalize_record(
            source_record,
            symprec_values=(0.03, 0.05, 0.10),
            angle_tolerance=5.0,
            max_sites=20,
        )
        if crystal.structure_hash != row.get("structure_hash"):
            raise ModelDataError(f"structure hash mismatch for {material_id}")
        if crystal.space_group != row.get("space_group"):
            raise ModelDataError(f"space-group mismatch for {material_id}")
        crystals[material_id] = crystal
    return crystals


def load_completion_records(
    mp20_root: Path,
    gate0_dir: Path,
    variant: CorruptionVariant,
) -> tuple[CompletionRecord, ...]:
    if not isinstance(variant, CorruptionVariant):
        raise TypeError("variant must be a CorruptionVariant")
    gate0_dir = Path(gate0_dir)
    verify_gate0_artifacts(gate0_dir)
    source_manifest = _read_json(gate0_dir / "source_manifest.json")
    clean_rows = _read_jsonl(gate0_dir / "clean_manifest.jsonl")
    split_rows = _read_jsonl(gate0_dir / "split_manifest.jsonl")
    corruption_rows = [
        row
        for row in _read_jsonl(gate0_dir / "corruption_manifest.jsonl")
        if row.get("variant") == variant.value
    ]
    split_by_id = {str(row.get("material_id", "")): row for row in split_rows}
    crystals = _canonical_crystals(mp20_root, source_manifest, clean_rows)

    records: list[CompletionRecord] = []
    for row in corruption_rows:
        material_id = str(row.get("parent_material_id", ""))
        crystal = crystals.get(material_id)
        split_row = split_by_id.get(material_id)
        if crystal is None or split_row is None:
            raise ModelDataError(f"corruption parent {material_id} has no clean split row")
        if row.get("split") != split_row.get("split"):
            raise ModelDataError(f"corruption split mismatch for {material_id}")
        missing = tuple(int(value) for value in row.get("missing_site_indices", ()))
        multiplicities, wyckoff = _site_labels(crystal)
        structure = crystal.structure
        records.append(
            CompletionRecord(
                material_id=material_id,
                prototype_family=str(split_row.get("prototype_family", "")),
                split=str(split_row.get("split", "")),
                stress_flags=tuple(str(value) for value in split_row.get("stress_flags", ())),
                variant=variant,
                path_index=int(row.get("path_index", -1)),
                example_seed=int(row.get("example_seed", -1)),
                lattice=tuple(
                    tuple(float(value) for value in lattice_row)
                    for lattice_row in structure.lattice.matrix
                ),
                atomic_numbers=tuple(int(site.specie.Z) for site in structure),
                fractional_coordinates=tuple(
                    tuple(float(value) % 1.0 for value in site.frac_coords)
                    for site in structure
                ),
                orbit_multiplicities=multiplicities,
                wyckoff_indices=wyckoff,
                space_group=crystal.space_group,
                missing_site_indices=missing,
                model_partition=str(split_row.get("split", "")),
            )
        )

    counts = Counter(record.material_id for record in records)
    if not counts or set(counts.values()) != {4}:
        raise ModelDataError(
            f"expected four {variant.value} states per parent, observed {dict(counts)}"
        )
    return tuple(
        sorted(records, key=lambda item: (item.material_id, item.path_index))
    )


def _rank(seed: int, material_id: str) -> str:
    return hashlib.sha256(f"{seed}:{material_id}".encode("utf-8")).hexdigest()


def assign_model_partitions(
    records: Sequence[CompletionRecord],
    *,
    seed: int,
    iid_fraction: float,
) -> tuple[CompletionRecord, ...]:
    if type(seed) is not int or seed < 0:
        raise ValueError("seed must be a non-negative integer")
    if not isinstance(iid_fraction, (int, float)) or not 0 < iid_fraction < 1:
        raise ValueError("iid_fraction must lie in (0, 1)")

    family_parents: dict[str, set[str]] = defaultdict(set)
    for record in records:
        if record.split == "train":
            family_parents[record.prototype_family].add(record.material_id)
        elif record.split not in {"validation", "test"}:
            raise ModelDataError(f"unknown experiment split {record.split!r}")

    iid_parents: set[str] = set()
    for family, parent_ids in family_parents.items():
        if len(parent_ids) < 3:
            continue
        ranked = sorted(parent_ids, key=lambda material_id: (_rank(seed, material_id), material_id))
        requested = max(1, math.floor(iid_fraction * len(ranked)))
        iid_parents.update(ranked[: min(len(ranked) - 1, requested)])

    partitioned = []
    for record in records:
        if record.split == "train":
            partition = "iid_test" if record.material_id in iid_parents else "train_fit"
        else:
            partition = record.split
        partitioned.append(replace(record, model_partition=partition))
    return tuple(partitioned)


def _noise_seed(noise_seed: int, material_id: str) -> int:
    digest = hashlib.sha256(f"{noise_seed}:{material_id}".encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big")


def make_model_example(
    record: CompletionRecord,
    *,
    noise_seed: int,
) -> tuple[CompletionInput, CompletionTarget]:
    if type(noise_seed) is not int or noise_seed < 0:
        raise ValueError("noise_seed must be a non-negative integer")
    rng = random.Random(_noise_seed(noise_seed, record.material_id))
    missing = list(record.missing_site_indices)
    rng.shuffle(missing)
    missing_set = set(missing)
    visible = [
        site_index
        for site_index in range(len(record.atomic_numbers))
        if site_index not in missing_set
    ]
    node_order = (*visible, *missing)
    query_mask = (False,) * len(visible) + (True,) * len(missing)
    input_coordinates = tuple(
        record.fractional_coordinates[site_index]
        for site_index in visible
    ) + tuple(
        (rng.random(), rng.random(), rng.random()) for _ in missing
    )
    model_input = CompletionInput(
        material_id=record.material_id,
        model_partition=record.model_partition or record.split,
        lattice=record.lattice,
        atomic_numbers=tuple(record.atomic_numbers[index] for index in node_order),
        fractional_coordinates=input_coordinates,
        query_mask=query_mask,
        space_group=record.space_group,
        missing_count=len(missing),
    )
    target = CompletionTarget(
        material_id=record.material_id,
        full_fractional_coordinates=tuple(
            record.fractional_coordinates[index] for index in node_order
        ),
        query_fractional_coordinates=tuple(
            record.fractional_coordinates[index] for index in missing
        ),
        query_orbit_multiplicities=tuple(
            record.orbit_multiplicities[index] for index in missing
        ),
        query_wyckoff_indices=tuple(record.wyckoff_indices[index] for index in missing),
        original_site_indices=tuple(missing),
    )
    return model_input, target
