from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import math
import os
import platform
import random
import subprocess
import sys
import time
import warnings
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass
from functools import lru_cache
from pathlib import Path

warnings.filterwarnings(
    "ignore",
    message="The pynvml package is deprecated.*",
    category=FutureWarning,
    module="torch.cuda",
)

import numpy as np
import torch

from .deconstruction import CorruptionVariant
from .model import (
    PeriodicCompletionModel,
    PeriodicEGNNConfig,
    count_trainable_parameters,
)
from .model_data import (
    CompletionRecord,
    CompletionInput,
    CompletionTarget,
    assign_model_partitions,
    load_completion_records,
    make_model_example,
)
from .model_objective import (
    LossWeights,
    collate_completion_examples,
    completion_loss,
)
from ..gate1b_v2.training import (
    TransferPreparationEvidence,
    encoder_digest,
    prepare_transfer_model,
)


class TrainingError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class DataSettings:
    iid_holdout_fraction: float
    partition_seed: int
    paths_per_parent: int
    max_sites: int


@dataclass(frozen=True, slots=True)
class TrainingSettings:
    batch_size: int
    max_updates: int
    validation_interval: int
    learning_rate: float
    weight_decay: float
    gradient_clip_norm: float
    amp: bool


@dataclass(frozen=True, slots=True)
class SamplingSettings:
    samples_per_state: int
    refinement_steps: int


@dataclass(frozen=True, slots=True)
class MetricSettings:
    structure_matcher_stol: float
    structure_matcher_angle_tolerance: float
    short_contact_absolute_angstrom: float
    short_contact_radius_scale: float
    radius_fallback_angstrom: float
    edge_probability_threshold: float
    bootstrap_draws: int
    bootstrap_seed: int


@dataclass(frozen=True, slots=True)
class Gate1Config:
    schema_version: str
    experiment_version: str
    variants: tuple[CorruptionVariant, ...]
    seeds: tuple[int, ...]
    data: DataSettings
    model: PeriodicEGNNConfig
    training: TrainingSettings
    sampling: SamplingSettings
    loss_weights: LossWeights
    metrics: MetricSettings
    evaluation_partitions: tuple[str, ...]
    blind_test_locked: bool
    config_hash: str


@dataclass(frozen=True, slots=True)
class TrainingRunArgs:
    mp20_root: Path
    gate0_dir: Path
    output_dir: Path
    config_path: Path
    variant: CorruptionVariant
    seed: int
    device: str = "auto"
    resume: bool = False
    initial_checkpoint: Path | None = None
    frozen_probe: bool = False
    balanced_mechanisms: tuple[str, str] | None = None


@dataclass(frozen=True, slots=True)
class TrainingRunManifest:
    schema_version: str
    experiment_version: str
    status: str
    variant: str
    seed: int
    config_hash: str
    gate0_report_hash: str
    data_ledger_hash: str
    git_commit: str
    parameter_count: int
    completed_updates: int
    train_record_count: int
    validation_record_count: int
    checkpoint_sha256: str
    metrics_sha256: str
    environment: tuple[tuple[str, str], ...]
    command: str
    total_parameter_count: int
    initial_checkpoint_sha256: str | None
    frozen_encoder_sha256_before: str | None
    frozen_encoder_sha256_after: str | None
    balanced_mechanisms: tuple[str, str] | None


@dataclass(frozen=True, slots=True)
class TrainingBenchmark:
    completed_updates: int
    elapsed_seconds: float
    updates_per_second: float
    parameter_count: int
    peak_device_memory_bytes: int
    device: str
    train_record_count: int
    config_hash: str
    data_ledger_hash: str


ROOT_KEYS = {
    "schema_version",
    "experiment_version",
    "variants",
    "seeds",
    "data",
    "model",
    "training",
    "sampling",
    "loss_weights",
    "metrics",
    "evaluation",
    "blind_test",
}
DATA_KEYS = {"iid_holdout_fraction", "partition_seed", "paths_per_parent", "max_sites"}
MODEL_KEYS = {
    "hidden_dim",
    "message_passing_layers",
    "radial_basis_count",
    "neighbor_cutoff_angstrom",
    "coordinate_step_scale",
    "dropout",
}
TRAINING_KEYS = {
    "batch_size",
    "max_updates",
    "validation_interval",
    "learning_rate",
    "weight_decay",
    "gradient_clip_norm",
    "amp",
}
SAMPLING_KEYS = {"samples_per_state", "refinement_steps"}
LOSS_KEYS = {
    "coordinate",
    "orbit_multiplicity",
    "wyckoff",
    "periodic_edge",
    "stop",
    "invalid_risk",
}
METRIC_KEYS = {
    "structure_matcher_stol",
    "structure_matcher_angle_tolerance",
    "short_contact_absolute_angstrom",
    "short_contact_radius_scale",
    "radius_fallback_angstrom",
    "edge_probability_threshold",
    "bootstrap_draws",
    "bootstrap_seed",
}


def _canonical_json(payload: object) -> str:
    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    )


def _payload_hash(payload: object) -> str:
    return hashlib.sha256(_canonical_json(payload).encode("utf-8")).hexdigest()


def _gradient_step_metrics(
    gradient_norm: torch.Tensor,
    *,
    use_amp: bool,
    scale_before: float,
    scale_after: float,
) -> tuple[float | None, bool]:
    optimizer_step_skipped = use_amp and scale_after < scale_before
    value = float(gradient_norm)
    if not math.isfinite(value):
        if not optimizer_step_skipped:
            raise TrainingError(
                "non-finite gradient norm without a skipped AMP optimizer step"
            )
        return None, True
    return value, optimizer_step_skipped


def _file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _mapping(payload: Mapping[str, object], key: str) -> dict[str, object]:
    value = payload.get(key)
    if not isinstance(value, dict):
        raise TrainingError(f"{key} must be a JSON object")
    return value


def _require_exact_keys(
    payload: Mapping[str, object], expected: set[str], label: str
) -> None:
    missing = sorted(expected - set(payload))
    unknown = sorted(set(payload) - expected)
    if missing:
        raise TrainingError(f"{label} is missing keys: {', '.join(missing)}")
    if unknown:
        raise TrainingError(f"{label} has unknown keys: {', '.join(unknown)}")


def _positive_int(value: object, label: str) -> int:
    if type(value) is not int or value <= 0:
        raise TrainingError(f"{label} must be a positive integer")
    return value


def _non_negative_int(value: object, label: str) -> int:
    if type(value) is not int or value < 0:
        raise TrainingError(f"{label} must be a non-negative integer")
    return value


def _positive_float(value: object, label: str) -> float:
    if not isinstance(value, (int, float)) or float(value) <= 0:
        raise TrainingError(f"{label} must be positive")
    return float(value)


def load_gate1_config(path: Path) -> Gate1Config:
    try:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise TrainingError(f"cannot read Gate 1 config: {exc}") from exc
    if not isinstance(payload, dict):
        raise TrainingError("Gate 1 config must contain a JSON object")
    _require_exact_keys(payload, ROOT_KEYS, "config")
    data = _mapping(payload, "data")
    model = _mapping(payload, "model")
    training = _mapping(payload, "training")
    sampling = _mapping(payload, "sampling")
    losses = _mapping(payload, "loss_weights")
    metrics = _mapping(payload, "metrics")
    evaluation = _mapping(payload, "evaluation")
    blind_test = _mapping(payload, "blind_test")
    _require_exact_keys(data, DATA_KEYS, "data")
    _require_exact_keys(model, MODEL_KEYS, "model")
    _require_exact_keys(training, TRAINING_KEYS, "training")
    _require_exact_keys(sampling, SAMPLING_KEYS, "sampling")
    _require_exact_keys(losses, LOSS_KEYS, "loss_weights")
    _require_exact_keys(metrics, METRIC_KEYS, "metrics")
    _require_exact_keys(evaluation, {"partitions"}, "evaluation")
    _require_exact_keys(blind_test, {"locked"}, "blind_test")

    raw_variants = payload["variants"]
    raw_seeds = payload["seeds"]
    raw_partitions = evaluation["partitions"]
    if not isinstance(raw_variants, list) or not raw_variants:
        raise TrainingError("variants must be a non-empty list")
    if not isinstance(raw_seeds, list) or not raw_seeds:
        raise TrainingError("seeds must be a non-empty list")
    if not isinstance(raw_partitions, list) or not raw_partitions:
        raise TrainingError("evaluation.partitions must be a non-empty list")
    try:
        variants = tuple(CorruptionVariant(str(value)) for value in raw_variants)
    except ValueError as exc:
        raise TrainingError(f"unsupported corruption variant: {exc}") from exc
    if len(set(variants)) != len(variants):
        raise TrainingError("variants must be unique")
    seeds = tuple(_non_negative_int(value, "seed") for value in raw_seeds)
    if len(set(seeds)) != len(seeds):
        raise TrainingError("seeds must be unique")
    partitions = tuple(str(value) for value in raw_partitions)
    if set(partitions) - {"validation"}:
        raise TrainingError("training config may evaluate validation only")
    if blind_test["locked"] is not True:
        raise TrainingError("blind test must remain locked in training configs")

    iid_fraction = float(data["iid_holdout_fraction"])
    if not 0 < iid_fraction < 1:
        raise TrainingError("data.iid_holdout_fraction must lie in (0, 1)")
    amp = training["amp"]
    if type(amp) is not bool:
        raise TrainingError("training.amp must be boolean")
    dropout = float(model["dropout"])
    config_hash = _payload_hash(payload)
    return Gate1Config(
        schema_version=str(payload["schema_version"]),
        experiment_version=str(payload["experiment_version"]),
        variants=variants,
        seeds=seeds,
        data=DataSettings(
            iid_holdout_fraction=iid_fraction,
            partition_seed=_non_negative_int(data["partition_seed"], "partition_seed"),
            paths_per_parent=_positive_int(data["paths_per_parent"], "paths_per_parent"),
            max_sites=_positive_int(data["max_sites"], "max_sites"),
        ),
        model=PeriodicEGNNConfig(
            hidden_dim=_positive_int(model["hidden_dim"], "hidden_dim"),
            message_passing_layers=_positive_int(
                model["message_passing_layers"], "message_passing_layers"
            ),
            radial_basis_count=_positive_int(
                model["radial_basis_count"], "radial_basis_count"
            ),
            neighbor_cutoff_angstrom=_positive_float(
                model["neighbor_cutoff_angstrom"], "neighbor_cutoff_angstrom"
            ),
            coordinate_step_scale=_positive_float(
                model["coordinate_step_scale"], "coordinate_step_scale"
            ),
            dropout=dropout,
        ),
        training=TrainingSettings(
            batch_size=_positive_int(training["batch_size"], "batch_size"),
            max_updates=_positive_int(training["max_updates"], "max_updates"),
            validation_interval=_positive_int(
                training["validation_interval"], "validation_interval"
            ),
            learning_rate=_positive_float(training["learning_rate"], "learning_rate"),
            weight_decay=float(training["weight_decay"]),
            gradient_clip_norm=_positive_float(
                training["gradient_clip_norm"], "gradient_clip_norm"
            ),
            amp=amp,
        ),
        sampling=SamplingSettings(
            samples_per_state=_positive_int(
                sampling["samples_per_state"], "samples_per_state"
            ),
            refinement_steps=_positive_int(
                sampling["refinement_steps"], "refinement_steps"
            ),
        ),
        loss_weights=LossWeights(
            coordinate=float(losses["coordinate"]),
            orbit_multiplicity=float(losses["orbit_multiplicity"]),
            wyckoff=float(losses["wyckoff"]),
            periodic_edge=float(losses["periodic_edge"]),
            stop=float(losses["stop"]),
            invalid_risk=float(losses["invalid_risk"]),
        ),
        metrics=MetricSettings(
            structure_matcher_stol=_positive_float(
                metrics["structure_matcher_stol"], "structure_matcher_stol"
            ),
            structure_matcher_angle_tolerance=_positive_float(
                metrics["structure_matcher_angle_tolerance"],
                "structure_matcher_angle_tolerance",
            ),
            short_contact_absolute_angstrom=_positive_float(
                metrics["short_contact_absolute_angstrom"],
                "short_contact_absolute_angstrom",
            ),
            short_contact_radius_scale=_positive_float(
                metrics["short_contact_radius_scale"], "short_contact_radius_scale"
            ),
            radius_fallback_angstrom=_positive_float(
                metrics["radius_fallback_angstrom"], "radius_fallback_angstrom"
            ),
            edge_probability_threshold=_positive_float(
                metrics["edge_probability_threshold"], "edge_probability_threshold"
            ),
            bootstrap_draws=_positive_int(
                metrics["bootstrap_draws"], "bootstrap_draws"
            ),
            bootstrap_seed=_non_negative_int(
                metrics["bootstrap_seed"], "bootstrap_seed"
            ),
        ),
        evaluation_partitions=partitions,
        blind_test_locked=True,
        config_hash=config_hash,
    )


def _git_commit() -> str:
    completed = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        check=False,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip() if completed.returncode == 0 else "unavailable"


def _version(distribution: str) -> str:
    try:
        return importlib.metadata.version(distribution)
    except importlib.metadata.PackageNotFoundError:
        return "unavailable"


def _environment(device: torch.device) -> tuple[tuple[str, str], ...]:
    gpu = (
        torch.cuda.get_device_name(device)
        if device.type == "cuda"
        else "not-used"
    )
    return tuple(
        sorted(
            {
                "cuda_available": str(torch.cuda.is_available()),
                "cuda_runtime": str(torch.version.cuda),
                "device": str(device),
                "gpu": gpu,
                "numpy": np.__version__,
                "os": platform.platform(),
                "pymatgen": _version("pymatgen"),
                "python": platform.python_version(),
                "scipy": _version("scipy"),
                "torch": torch.__version__,
            }.items()
        )
    )


def _resolve_device(requested: str) -> torch.device:
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(requested)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise TrainingError("CUDA was requested but is unavailable")
    return device


def _seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed % (2**32))
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.use_deterministic_algorithms(True, warn_only=True)
    if torch.backends.cudnn.is_available():
        torch.backends.cudnn.benchmark = False


def _record_payload(record: CompletionRecord) -> dict[str, object]:
    payload = asdict(record)
    payload["variant"] = record.variant.value
    return payload


def _ledger_hash(records: Sequence[CompletionRecord]) -> str:
    rows = [
        _record_payload(record)
        for record in sorted(
            records,
            key=lambda item: (item.material_id, item.variant.value, item.path_index),
        )
    ]
    return _payload_hash(rows)


@lru_cache(maxsize=128)
def _order_records(
    records: tuple[CompletionRecord, ...], seed: int, epoch: int
) -> tuple[CompletionRecord, ...]:
    def rank(record: CompletionRecord) -> tuple[str, str, int]:
        digest = hashlib.sha256(
            f"{seed}:{epoch}:{record.material_id}:{record.path_index}".encode("utf-8")
        ).hexdigest()
        return digest, record.material_id, record.path_index

    return tuple(sorted(records, key=rank))


def _training_batch(
    records: Sequence[CompletionRecord],
    *,
    update: int,
    batch_size: int,
    seed: int,
) -> tuple[CompletionRecord, ...]:
    frozen_records = tuple(records)
    selected = []
    position = (update - 1) * batch_size
    remaining = batch_size
    while remaining:
        epoch, index = divmod(position, len(frozen_records))
        ordered = _order_records(frozen_records, seed, epoch)
        take = min(remaining, len(frozen_records) - index)
        selected.extend(ordered[index : index + take])
        position += take
        remaining -= take
    return tuple(selected)


def _balanced_training_batch(
    records: Sequence[CompletionRecord],
    *,
    mechanisms: tuple[str, str],
    update: int,
    batch_size: int,
    seed: int,
) -> tuple[CompletionRecord, ...]:
    if batch_size % 2:
        raise TrainingError("balanced mechanism batches require an even batch size")
    grouped = []
    for mechanism in mechanisms:
        label = f"v2-mechanism:{mechanism}"
        selected = tuple(record for record in records if label in record.stress_flags)
        if not selected:
            raise TrainingError(f"no records for balanced mechanism {mechanism}")
        grouped.append(selected)
    half = batch_size // 2
    left = _training_batch(
        grouped[0], update=update, batch_size=half, seed=seed
    )
    right = _training_batch(
        grouped[1], update=update, batch_size=half, seed=seed + 1
    )
    return tuple(
        record
        for pair in zip(left, right, strict=True)
        for record in pair
    )


def _noise_seed(seed: int, update: int, record: CompletionRecord) -> int:
    digest = hashlib.sha256(
        f"{seed}:{update}:{record.example_seed}:{record.material_id}".encode("utf-8")
    ).digest()
    return int.from_bytes(digest[:8], "big")


def _examples(
    records: Sequence[CompletionRecord], *, seed: int, update: int
) -> tuple[tuple[CompletionInput, CompletionTarget], ...]:
    return tuple(
        make_model_example(
            record,
            noise_seed=_noise_seed(seed, update, record),
        )
        for record in records
    )


def _validation_loss(
    model: PeriodicCompletionModel,
    records: Sequence[CompletionRecord],
    config: Gate1Config,
    device: torch.device,
    seed: int,
) -> float:
    model.eval()
    values = []
    with torch.no_grad():
        for start in range(0, len(records), config.training.batch_size):
            subset = records[start : start + config.training.batch_size]
            batch, target = collate_completion_examples(
                _examples(subset, seed=seed, update=0), device=device
            )
            output = model(batch)
            loss = completion_loss(
                batch,
                output,
                target,
                config.loss_weights,
                edge_cutoff_angstrom=config.model.neighbor_cutoff_angstrom,
                short_contact_absolute_angstrom=config.metrics.short_contact_absolute_angstrom,
                short_contact_radius_scale=config.metrics.short_contact_radius_scale,
                radius_fallback_angstrom=config.metrics.radius_fallback_angstrom,
            )
            values.append((float(loss.total), len(subset)))
    return sum(value * count for value, count in values) / sum(count for _, count in values)


def _atomic_write_json(path: Path, payload: object) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(_canonical_json(payload) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def _atomic_checkpoint(path: Path, payload: dict[str, object]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temporary)
    os.replace(temporary, path)


def _checkpoint_payload(
    *,
    model: PeriodicCompletionModel,
    optimizer: torch.optim.Optimizer,
    scaler: torch.amp.GradScaler,
    completed_updates: int,
    config_hash: str,
    ledger_hash: str,
    variant: CorruptionVariant,
    seed: int,
    parameter_count: int,
) -> dict[str, object]:
    return {
        "model": model.state_dict(),
        "optimizer": optimizer.state_dict(),
        "scaler": scaler.state_dict(),
        "completed_updates": completed_updates,
        "config_hash": config_hash,
        "data_ledger_hash": ledger_hash,
        "variant": variant.value,
        "seed": seed,
        "parameter_count": parameter_count,
        "git_commit": _git_commit(),
        "python_random_state": random.getstate(),
        "numpy_random_state": np.random.get_state(),
        "torch_random_state": torch.get_rng_state(),
        "cuda_random_state": torch.cuda.get_rng_state_all()
        if torch.cuda.is_available()
        else None,
    }


def _restore_checkpoint(
    checkpoint: Mapping[str, object],
    *,
    model: PeriodicCompletionModel,
    optimizer: torch.optim.Optimizer,
    scaler: torch.amp.GradScaler,
    config: Gate1Config,
    ledger_hash: str,
    args: TrainingRunArgs,
    parameter_count: int,
) -> int:
    if checkpoint.get("config_hash") != config.config_hash:
        raise TrainingError("resume config hash mismatch")
    if checkpoint.get("data_ledger_hash") != ledger_hash:
        raise TrainingError("resume data ledger hash mismatch")
    if checkpoint.get("variant") != args.variant.value or checkpoint.get("seed") != args.seed:
        raise TrainingError("resume variant or seed mismatch")
    if checkpoint.get("parameter_count") != parameter_count:
        raise TrainingError("resume parameter count mismatch")
    if checkpoint.get("git_commit") != _git_commit():
        raise TrainingError("resume Git commit mismatch")
    model.load_state_dict(checkpoint["model"])
    optimizer.load_state_dict(checkpoint["optimizer"])
    scaler.load_state_dict(checkpoint["scaler"])
    random.setstate(checkpoint["python_random_state"])
    np.random.set_state(checkpoint["numpy_random_state"])
    torch.set_rng_state(checkpoint["torch_random_state"])
    cuda_state = checkpoint.get("cuda_random_state")
    if cuda_state is not None and torch.cuda.is_available():
        torch.cuda.set_rng_state_all(cuda_state)
    return int(checkpoint["completed_updates"])


def train_run(
    args: TrainingRunArgs,
    *,
    records: Sequence[CompletionRecord] | None = None,
) -> TrainingRunManifest:
    config = load_gate1_config(args.config_path)
    if args.variant not in config.variants:
        raise TrainingError(f"variant {args.variant.value} is absent from config")
    if args.seed not in config.seeds:
        raise TrainingError(f"seed {args.seed} is absent from config")
    device = _resolve_device(args.device)
    _seed_everything(args.seed)

    injected_records = records is not None
    if records is None:
        loaded = load_completion_records(args.mp20_root, args.gate0_dir, args.variant)
        records = assign_model_partitions(
            loaded,
            seed=config.data.partition_seed,
            iid_fraction=config.data.iid_holdout_fraction,
        )
    records = tuple(records)
    if any(record.variant != args.variant for record in records):
        raise TrainingError("training ledger contains a different variant")
    train_records = tuple(
        record for record in records if record.model_partition == "train_fit"
    )
    validation_records = tuple(
        record for record in records if record.model_partition == "validation"
    )
    if not train_records or not validation_records:
        raise TrainingError("training requires train_fit and validation records")
    ledger_hash = _ledger_hash(records)

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_path = output_dir / "checkpoint.pt"
    metrics_path = output_dir / "metrics.jsonl"
    manifest_path = output_dir / "run_manifest.json"
    if checkpoint_path.exists() and not args.resume:
        raise TrainingError(f"output already contains a checkpoint: {checkpoint_path}")

    model = PeriodicCompletionModel(config.model).to(device)
    if args.resume and args.initial_checkpoint is not None:
        raise TrainingError("resume and initial checkpoint are mutually exclusive")
    transfer_evidence: TransferPreparationEvidence | None = None
    if args.initial_checkpoint is not None:
        transfer_evidence = prepare_transfer_model(
            model,
            initial_checkpoint=args.initial_checkpoint,
            seed=args.seed,
            frozen_probe=args.frozen_probe,
        )
    elif args.frozen_probe:
        raise TrainingError("frozen probe requires an initial checkpoint")
    parameter_count = count_trainable_parameters(model)
    total_parameter_count = sum(parameter.numel() for parameter in model.parameters())
    optimizer = torch.optim.AdamW(
        (parameter for parameter in model.parameters() if parameter.requires_grad),
        lr=config.training.learning_rate,
        weight_decay=config.training.weight_decay,
    )
    use_amp = config.training.amp and device.type == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp)
    start_update = 0
    if args.resume:
        if not checkpoint_path.is_file():
            raise TrainingError("resume requested but checkpoint is missing")
        checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
        start_update = _restore_checkpoint(
            checkpoint,
            model=model,
            optimizer=optimizer,
            scaler=scaler,
            config=config,
            ledger_hash=ledger_hash,
            args=args,
            parameter_count=parameter_count,
        )
        metrics_mode = "a"
    else:
        metrics_mode = "w"

    with metrics_path.open(metrics_mode, encoding="utf-8", newline="\n") as metrics_file:
        for update in range(start_update + 1, config.training.max_updates + 1):
            model.train()
            subset = (
                _balanced_training_batch(
                    train_records,
                    mechanisms=args.balanced_mechanisms,
                    update=update,
                    batch_size=config.training.batch_size,
                    seed=args.seed,
                )
                if args.balanced_mechanisms is not None
                else _training_batch(
                    train_records,
                    update=update,
                    batch_size=config.training.batch_size,
                    seed=args.seed,
                )
            )
            batch, target = collate_completion_examples(
                _examples(subset, seed=args.seed, update=update), device=device
            )
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast(device_type=device.type, enabled=use_amp):
                output = model(batch)
                loss = completion_loss(
                    batch,
                    output,
                    target,
                    config.loss_weights,
                    edge_cutoff_angstrom=config.model.neighbor_cutoff_angstrom,
                    short_contact_absolute_angstrom=config.metrics.short_contact_absolute_angstrom,
                    short_contact_radius_scale=config.metrics.short_contact_radius_scale,
                    radius_fallback_angstrom=config.metrics.radius_fallback_angstrom,
                )
            scaler.scale(loss.total).backward()
            scaler.unscale_(optimizer)
            gradient_norm = torch.nn.utils.clip_grad_norm_(
                model.parameters(), config.training.gradient_clip_norm
            )
            scale_before = float(scaler.get_scale())
            scaler.step(optimizer)
            scaler.update()
            gradient_norm_metric, optimizer_step_skipped = _gradient_step_metrics(
                gradient_norm,
                use_amp=use_amp,
                scale_before=scale_before,
                scale_after=float(scaler.get_scale()),
            )

            should_validate = (
                update % config.training.validation_interval == 0
                or update == config.training.max_updates
            )
            validation_loss = (
                _validation_loss(model, validation_records, config, device, args.seed)
                if should_validate
                else None
            )
            row = {
                "gradient_norm": gradient_norm_metric,
                "optimizer_step_skipped": optimizer_step_skipped,
                "train_coordinate": float(loss.coordinate.detach()),
                "train_invalid_risk": float(loss.invalid_risk.detach()),
                "train_orbit_multiplicity": float(loss.orbit_multiplicity.detach()),
                "train_periodic_edge": float(loss.periodic_edge.detach()),
                "train_stop": float(loss.stop.detach()),
                "train_total": float(loss.total.detach()),
                "train_wyckoff": float(loss.wyckoff.detach()),
                "update": update,
                "validation_total": validation_loss,
                "variant": args.variant.value,
            }
            metrics_file.write(_canonical_json(row) + "\n")
            metrics_file.flush()
            if should_validate:
                _atomic_checkpoint(
                    checkpoint_path,
                    _checkpoint_payload(
                        model=model,
                        optimizer=optimizer,
                        scaler=scaler,
                        completed_updates=update,
                        config_hash=config.config_hash,
                        ledger_hash=ledger_hash,
                        variant=args.variant,
                        seed=args.seed,
                        parameter_count=parameter_count,
                    ),
                )

    gate0_report_hash = (
        "injected-fixture"
        if injected_records
        else _file_hash(Path(args.gate0_dir) / "gate0_report.json")
    )
    command = (
        "python -m crysalis_assembly.experiments.train_gate1 "
        f"--mp20-root {args.mp20_root} --gate0-dir {args.gate0_dir} "
        f"--output-dir {args.output_dir} --config {args.config_path} "
        f"--variant {args.variant.value} --seed {args.seed} --device {args.device}"
    )
    frozen_after = encoder_digest(model) if args.frozen_probe else None
    if (
        transfer_evidence is not None
        and args.frozen_probe
        and frozen_after != transfer_evidence.encoder_sha256_before
    ):
        raise TrainingError("frozen encoder changed during probe")
    manifest = TrainingRunManifest(
        schema_version=config.schema_version,
        experiment_version=config.experiment_version,
        status="completed",
        variant=args.variant.value,
        seed=args.seed,
        config_hash=config.config_hash,
        gate0_report_hash=gate0_report_hash,
        data_ledger_hash=ledger_hash,
        git_commit=_git_commit(),
        parameter_count=parameter_count,
        completed_updates=config.training.max_updates,
        train_record_count=len(train_records),
        validation_record_count=len(validation_records),
        checkpoint_sha256=_file_hash(checkpoint_path),
        metrics_sha256=_file_hash(metrics_path),
        environment=_environment(device),
        command=command,
        total_parameter_count=total_parameter_count,
        initial_checkpoint_sha256=(
            transfer_evidence.initial_checkpoint_sha256
            if transfer_evidence is not None
            else None
        ),
        frozen_encoder_sha256_before=(
            transfer_evidence.encoder_sha256_before
            if transfer_evidence is not None and args.frozen_probe
            else None
        ),
        frozen_encoder_sha256_after=frozen_after,
        balanced_mechanisms=args.balanced_mechanisms,
    )
    _atomic_write_json(manifest_path, asdict(manifest))
    return manifest


def benchmark_updates(
    args: TrainingRunArgs,
    *,
    updates: int,
    records: Sequence[CompletionRecord] | None = None,
) -> TrainingBenchmark:
    config = load_gate1_config(args.config_path)
    if type(updates) is not int or not 0 < updates <= config.training.max_updates:
        raise TrainingError("benchmark updates must lie in [1, training.max_updates]")
    if args.variant not in config.variants or args.seed not in config.seeds:
        raise TrainingError("benchmark variant or seed is absent from config")
    device = _resolve_device(args.device)
    _seed_everything(args.seed)
    if records is None:
        loaded = load_completion_records(args.mp20_root, args.gate0_dir, args.variant)
        records = assign_model_partitions(
            loaded,
            seed=config.data.partition_seed,
            iid_fraction=config.data.iid_holdout_fraction,
        )
    records = tuple(records)
    if any(record.variant != args.variant for record in records):
        raise TrainingError("benchmark ledger contains a different variant")
    train_records = tuple(
        record for record in records if record.model_partition == "train_fit"
    )
    if not train_records:
        raise TrainingError("benchmark requires train_fit records")

    model = PeriodicCompletionModel(config.model).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=config.training.learning_rate,
        weight_decay=config.training.weight_decay,
    )
    use_amp = config.training.amp and device.type == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp)
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
        torch.cuda.synchronize(device)
    started = time.perf_counter()
    for update in range(1, updates + 1):
        model.train()
        subset = _training_batch(
            train_records,
            update=update,
            batch_size=config.training.batch_size,
            seed=args.seed,
        )
        batch, target = collate_completion_examples(
            _examples(subset, seed=args.seed, update=update), device=device
        )
        optimizer.zero_grad(set_to_none=True)
        with torch.amp.autocast(device_type=device.type, enabled=use_amp):
            output = model(batch)
            loss = completion_loss(
                batch,
                output,
                target,
                config.loss_weights,
                edge_cutoff_angstrom=config.model.neighbor_cutoff_angstrom,
                short_contact_absolute_angstrom=config.metrics.short_contact_absolute_angstrom,
                short_contact_radius_scale=config.metrics.short_contact_radius_scale,
                radius_fallback_angstrom=config.metrics.radius_fallback_angstrom,
            )
        scaler.scale(loss.total).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(
            model.parameters(), config.training.gradient_clip_norm
        )
        scaler.step(optimizer)
        scaler.update()
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    elapsed = time.perf_counter() - started
    peak_memory = (
        int(torch.cuda.max_memory_allocated(device)) if device.type == "cuda" else 0
    )
    return TrainingBenchmark(
        completed_updates=updates,
        elapsed_seconds=elapsed,
        updates_per_second=updates / elapsed,
        parameter_count=count_trainable_parameters(model),
        peak_device_memory_bytes=peak_memory,
        device=str(device),
        train_record_count=len(train_records),
        config_hash=config.config_hash,
        data_ledger_hash=_ledger_hash(records),
    )


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Train one Crysalis Gate 1 variant")
    parser.add_argument("--mp20-root", type=Path, required=True)
    parser.add_argument("--gate0-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--config", dest="config_path", type=Path, required=True)
    parser.add_argument(
        "--variant", choices=[item.value for item in CorruptionVariant], required=True
    )
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--resume", action="store_true")
    parsed = parser.parse_args(argv)
    try:
        manifest = train_run(
            TrainingRunArgs(
                mp20_root=parsed.mp20_root,
                gate0_dir=parsed.gate0_dir,
                output_dir=parsed.output_dir,
                config_path=parsed.config_path,
                variant=CorruptionVariant(parsed.variant),
                seed=parsed.seed,
                device=parsed.device,
                resume=parsed.resume,
            )
        )
    except Exception as exc:
        print(f"Gate 1 training error: {exc}", file=sys.stderr)
        return 2
    print(
        f"Gate 1 training completed: variant={manifest.variant} "
        f"seed={manifest.seed} updates={manifest.completed_updates}"
    )
    print(parsed.output_dir / "run_manifest.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
