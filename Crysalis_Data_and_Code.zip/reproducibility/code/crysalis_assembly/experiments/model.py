from __future__ import annotations

from dataclasses import dataclass, replace

import torch
from torch import Tensor, nn


@dataclass(frozen=True, slots=True)
class PeriodicEGNNConfig:
    hidden_dim: int
    message_passing_layers: int
    radial_basis_count: int
    neighbor_cutoff_angstrom: float
    coordinate_step_scale: float
    dropout: float = 0.0

    def __post_init__(self) -> None:
        if self.hidden_dim <= 0 or self.message_passing_layers <= 0:
            raise ValueError("model dimensions must be positive")
        if self.radial_basis_count < 2:
            raise ValueError("radial_basis_count must be at least two")
        if self.neighbor_cutoff_angstrom <= 0 or self.coordinate_step_scale <= 0:
            raise ValueError("distance and coordinate scales must be positive")
        if not 0 <= self.dropout < 1:
            raise ValueError("dropout must lie in [0, 1)")


@dataclass(frozen=True, slots=True)
class CompletionBatch:
    atomic_numbers: Tensor
    fractional_coordinates: Tensor
    lattice: Tensor
    node_mask: Tensor
    query_mask: Tensor
    space_group: Tensor
    missing_count: Tensor
    noise_level: Tensor

    def __post_init__(self) -> None:
        if self.atomic_numbers.ndim != 2:
            raise ValueError("atomic_numbers must have shape [B, N]")
        batch_size, node_count = self.atomic_numbers.shape
        if self.fractional_coordinates.shape != (batch_size, node_count, 3):
            raise ValueError("fractional_coordinates must have shape [B, N, 3]")
        if self.lattice.shape != (batch_size, 3, 3):
            raise ValueError("lattice must have shape [B, 3, 3]")
        if self.node_mask.shape != (batch_size, node_count):
            raise ValueError("node_mask must have shape [B, N]")
        if self.query_mask.shape != (batch_size, node_count):
            raise ValueError("query_mask must have shape [B, N]")
        if self.space_group.shape != (batch_size,):
            raise ValueError("space_group must have shape [B]")
        if self.missing_count.shape != (batch_size,):
            raise ValueError("missing_count must have shape [B]")
        if self.noise_level.shape != (batch_size,):
            raise ValueError("noise_level must have shape [B]")
        if torch.any(self.query_mask & ~self.node_mask):
            raise ValueError("query nodes must be valid nodes")

    def to(self, device: torch.device | str) -> CompletionBatch:
        return replace(
            self,
            atomic_numbers=self.atomic_numbers.to(device),
            fractional_coordinates=self.fractional_coordinates.to(device),
            lattice=self.lattice.to(device),
            node_mask=self.node_mask.to(device),
            query_mask=self.query_mask.to(device),
            space_group=self.space_group.to(device),
            missing_count=self.missing_count.to(device),
            noise_level=self.noise_level.to(device),
        )


@dataclass(frozen=True, slots=True)
class CompletionOutput:
    fractional_coordinates: Tensor
    query_cartesian_updates: Tensor
    orbit_multiplicity_logits: Tensor
    wyckoff_logits: Tensor
    periodic_edge_logits: Tensor
    stop_logit: Tensor
    invalid_risk_logit: Tensor


class _PeriodicLayer(nn.Module):
    def __init__(self, config: PeriodicEGNNConfig) -> None:
        super().__init__()
        hidden = config.hidden_dim
        self.cutoff = config.neighbor_cutoff_angstrom
        self.coordinate_step_scale = config.coordinate_step_scale
        centers = torch.linspace(0.0, self.cutoff, config.radial_basis_count)
        self.register_buffer("radial_centers", centers)
        spacing = self.cutoff / (config.radial_basis_count - 1)
        self.radial_gamma = 1.0 / (spacing * spacing)
        self.message_mlp = nn.Sequential(
            nn.Linear(hidden * 2 + config.radial_basis_count, hidden),
            nn.SiLU(),
            nn.Linear(hidden, hidden),
            nn.SiLU(),
        )
        self.node_mlp = nn.Sequential(
            nn.Linear(hidden * 2, hidden),
            nn.SiLU(),
            nn.Linear(hidden, hidden),
        )
        self.coordinate_mlp = nn.Sequential(
            nn.Linear(hidden, hidden),
            nn.SiLU(),
            nn.Linear(hidden, 1, bias=False),
        )
        self.dropout = nn.Dropout(config.dropout)
        self.norm = nn.LayerNorm(hidden)

    def _geometry(
        self,
        coordinates: Tensor,
        lattice: Tensor,
        node_mask: Tensor,
    ) -> tuple[Tensor, Tensor, Tensor]:
        node_count = coordinates.shape[1]
        delta_fractional = coordinates[:, None, :, :] - coordinates[:, :, None, :]
        delta_fractional = delta_fractional - torch.round(delta_fractional)
        delta_cartesian = torch.einsum(
            "bijd,bdk->bijk", delta_fractional, lattice
        )
        distance = torch.linalg.vector_norm(delta_cartesian, dim=-1)
        pair_mask = node_mask[:, :, None] & node_mask[:, None, :]
        diagonal = torch.eye(node_count, dtype=torch.bool, device=node_mask.device)
        pair_mask = pair_mask & ~diagonal.unsqueeze(0) & (distance <= self.cutoff)
        radial = torch.exp(
            -self.radial_gamma
            * (distance.unsqueeze(-1) - self.radial_centers) ** 2
        )
        return delta_cartesian, radial, pair_mask

    def forward(
        self,
        features: Tensor,
        coordinates: Tensor,
        lattice: Tensor,
        node_mask: Tensor,
        query_mask: Tensor,
    ) -> tuple[Tensor, Tensor, Tensor]:
        node_count = features.shape[1]
        delta_cartesian, radial, pair_mask = self._geometry(
            coordinates, lattice, node_mask
        )
        feature_i = features[:, :, None, :].expand(-1, -1, node_count, -1)
        feature_j = features[:, None, :, :].expand(-1, node_count, -1, -1)
        messages = self.message_mlp(torch.cat((feature_i, feature_j, radial), dim=-1))
        messages = messages * pair_mask.unsqueeze(-1)
        neighbor_count = pair_mask.sum(dim=2, keepdim=True).clamp(min=1)
        aggregate = messages.sum(dim=2) / neighbor_count
        update = self.node_mlp(torch.cat((features, aggregate), dim=-1))
        features = self.norm(features + self.dropout(update))
        features = features * node_mask.unsqueeze(-1)

        coordinate_weight = self.coordinate_mlp(messages).squeeze(-1)
        cartesian_update = (
            coordinate_weight.unsqueeze(-1) * delta_cartesian
        ).sum(dim=2) / neighbor_count
        cartesian_update = cartesian_update * self.coordinate_step_scale
        cartesian_update = cartesian_update * query_mask.unsqueeze(-1)
        inverse_lattice = torch.linalg.inv(lattice)
        fractional_update = torch.einsum(
            "bnd,bdk->bnk", cartesian_update, inverse_lattice
        )
        proposed = torch.remainder(coordinates + fractional_update, 1.0)
        coordinates = torch.where(query_mask.unsqueeze(-1), proposed, coordinates)
        return features, coordinates, cartesian_update


class PeriodicCompletionModel(nn.Module):
    def __init__(self, config: PeriodicEGNNConfig) -> None:
        super().__init__()
        self.config = config
        hidden = config.hidden_dim
        self.element_embedding = nn.Embedding(119, hidden, padding_idx=0)
        self.query_embedding = nn.Embedding(2, hidden)
        self.space_group_embedding = nn.Embedding(231, hidden, padding_idx=0)
        self.condition_mlp = nn.Sequential(
            nn.Linear(4, hidden),
            nn.SiLU(),
            nn.Linear(hidden, hidden),
        )
        self.layers = nn.ModuleList(
            _PeriodicLayer(config) for _ in range(config.message_passing_layers)
        )
        self.orbit_head = nn.Linear(hidden, 20)
        self.wyckoff_head = nn.Linear(hidden, 26)

        edge_centers = torch.linspace(
            0.0, config.neighbor_cutoff_angstrom, config.radial_basis_count
        )
        self.register_buffer("edge_radial_centers", edge_centers)
        spacing = config.neighbor_cutoff_angstrom / (config.radial_basis_count - 1)
        self.edge_radial_gamma = 1.0 / (spacing * spacing)
        self.edge_mlp = nn.Sequential(
            nn.Linear(hidden * 2 + config.radial_basis_count, hidden),
            nn.SiLU(),
            nn.Linear(hidden, 1),
        )
        self.stop_head = nn.Sequential(nn.Linear(hidden, hidden), nn.SiLU(), nn.Linear(hidden, 1))
        self.invalid_head = nn.Sequential(
            nn.Linear(hidden, hidden), nn.SiLU(), nn.Linear(hidden, 1)
        )

    def _initial_features(self, batch: CompletionBatch) -> Tensor:
        atomic_numbers = batch.atomic_numbers.clamp(min=0, max=118)
        space_group = batch.space_group.clamp(min=0, max=230)
        noise = batch.noise_level
        continuous = torch.stack(
            (
                batch.missing_count / 20.0,
                noise,
                torch.sin(torch.pi * noise),
                torch.cos(torch.pi * noise),
            ),
            dim=-1,
        )
        features = (
            self.element_embedding(atomic_numbers)
            + self.query_embedding(batch.query_mask.long())
            + self.space_group_embedding(space_group)[:, None, :]
            + self.condition_mlp(continuous)[:, None, :]
        )
        return features * batch.node_mask.unsqueeze(-1)

    def _edge_logits(
        self,
        features: Tensor,
        coordinates: Tensor,
        lattice: Tensor,
        node_mask: Tensor,
    ) -> Tensor:
        node_count = features.shape[1]
        delta_fractional = coordinates[:, None, :, :] - coordinates[:, :, None, :]
        delta_fractional = delta_fractional - torch.round(delta_fractional)
        delta_cartesian = torch.einsum(
            "bijd,bdk->bijk", delta_fractional, lattice
        )
        distance = torch.linalg.vector_norm(delta_cartesian, dim=-1)
        radial = torch.exp(
            -self.edge_radial_gamma
            * (distance.unsqueeze(-1) - self.edge_radial_centers) ** 2
        )
        feature_i = features[:, :, None, :].expand(-1, -1, node_count, -1)
        feature_j = features[:, None, :, :].expand(-1, node_count, -1, -1)
        directed = self.edge_mlp(
            torch.cat((feature_i, feature_j, radial), dim=-1)
        ).squeeze(-1)
        symmetric = 0.5 * (directed + directed.transpose(1, 2))
        pair_mask = node_mask[:, :, None] & node_mask[:, None, :]
        diagonal = torch.eye(node_count, dtype=torch.bool, device=node_mask.device)
        pair_mask = pair_mask & ~diagonal.unsqueeze(0)
        return torch.where(pair_mask, symmetric, torch.full_like(symmetric, -20.0))

    def forward(self, batch: CompletionBatch) -> CompletionOutput:
        features = self._initial_features(batch)
        coordinates = batch.fractional_coordinates
        total_cartesian_update = torch.zeros_like(coordinates)
        for layer in self.layers:
            features, coordinates, cartesian_update = layer(
                features,
                coordinates,
                batch.lattice,
                batch.node_mask,
                batch.query_mask,
            )
            total_cartesian_update = total_cartesian_update + cartesian_update

        count = batch.node_mask.sum(dim=1, keepdim=True).clamp(min=1)
        pooled = features.sum(dim=1) / count
        return CompletionOutput(
            fractional_coordinates=coordinates,
            query_cartesian_updates=total_cartesian_update,
            orbit_multiplicity_logits=self.orbit_head(features),
            wyckoff_logits=self.wyckoff_head(features),
            periodic_edge_logits=self._edge_logits(
                features, coordinates, batch.lattice, batch.node_mask
            ),
            stop_logit=self.stop_head(pooled).squeeze(-1),
            invalid_risk_logit=self.invalid_head(pooled).squeeze(-1),
        )


def count_trainable_parameters(model: nn.Module) -> int:
    return sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)
