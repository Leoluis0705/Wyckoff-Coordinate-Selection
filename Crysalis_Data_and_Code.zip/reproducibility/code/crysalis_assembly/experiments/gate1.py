from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import warnings
from collections import defaultdict
from collections.abc import Sequence
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path

warnings.filterwarnings(
    "ignore",
    message="The pynvml package is deprecated.*",
    category=FutureWarning,
    module="torch.cuda",
)

import torch

from .deconstruction import CorruptionVariant
from .gate1_metrics import (
    CompletionMetrics,
    evaluate_completion,
    paired_family_bootstrap,
    summarize_metrics,
)
from .model import PeriodicCompletionModel
from .model_data import (
    CompletionRecord,
    assign_model_partitions,
    load_completion_records,
    make_model_example,
)
from .model_objective import collate_completion_examples, sample_completions
from .train_gate1 import (
    Gate1Config,
    TrainingRunArgs,
    load_gate1_config,
    train_run,
)


class Gate1Error(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class MatrixAudit:
    run_count: int
    expected_run_count: int
    parameter_count: int
    completed_updates: int
    train_record_count: int
    validation_record_count: int
    config_hash: str
    gate0_report_hash: str


def _canonical_json(payload: object) -> str:
    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    )


def _payload_hash(payload: object) -> str:
    return hashlib.sha256(_canonical_json(payload).encode("utf-8")).hexdigest()


def _file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _read_json(path: Path) -> dict[str, object]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise Gate1Error(f"cannot read {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise Gate1Error(f"{path} must contain a JSON object")
    return payload


def _read_jsonl(path: Path) -> list[dict[str, object]]:
    try:
        rows = [
            json.loads(line)
            for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
    except (OSError, json.JSONDecodeError) as exc:
        raise Gate1Error(f"cannot read {path}: {exc}") from exc
    if any(not isinstance(row, dict) for row in rows):
        raise Gate1Error(f"{path} must contain JSON objects")
    return rows


def _atomic_write_json(path: Path, payload: object) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(_canonical_json(payload) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def _write_jsonl(path: Path, rows: Sequence[dict[str, object]]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        "".join(_canonical_json(row) + "\n" for row in rows),
        encoding="utf-8",
    )
    os.replace(temporary, path)


def _run_dir(root: Path, variant: CorruptionVariant, seed: int) -> Path:
    return Path(root) / variant.value / f"seed-{seed}"


def _expected_runs(
    root: Path, config: Gate1Config
) -> tuple[tuple[CorruptionVariant, int, Path], ...]:
    return tuple(
        (variant, seed, _run_dir(root, variant, seed))
        for variant in config.variants
        for seed in config.seeds
    )


def validate_run_matrix(root: Path, config: Gate1Config) -> MatrixAudit:
    expected = _expected_runs(root, config)
    missing = [
        f"{variant.value}/seed-{seed}"
        for variant, seed, path in expected
        if not (path / "run_manifest.json").is_file()
    ]
    if missing:
        raise Gate1Error(f"missing runs: {', '.join(missing)}")

    parameter_counts: set[int] = set()
    completed_updates: set[int] = set()
    train_counts: set[int] = set()
    validation_counts: set[int] = set()
    gate0_hashes: set[str] = set()
    ledger_by_variant: dict[str, set[str]] = defaultdict(set)
    for variant, seed, run_dir in expected:
        manifest = _read_json(run_dir / "run_manifest.json")
        if manifest.get("status") != "completed":
            raise Gate1Error(f"run is not completed: {variant.value}/seed-{seed}")
        if manifest.get("variant") != variant.value or manifest.get("seed") != seed:
            raise Gate1Error(f"run identity mismatch: {variant.value}/seed-{seed}")
        if manifest.get("config_hash") != config.config_hash:
            raise Gate1Error(f"config hash mismatch: {variant.value}/seed-{seed}")
        checkpoint = run_dir / "checkpoint.pt"
        metrics = run_dir / "metrics.jsonl"
        if _file_hash(checkpoint) != manifest.get("checkpoint_sha256"):
            raise Gate1Error(f"checkpoint hash mismatch: {variant.value}/seed-{seed}")
        if _file_hash(metrics) != manifest.get("metrics_sha256"):
            raise Gate1Error(f"metrics hash mismatch: {variant.value}/seed-{seed}")
        metric_rows = _read_jsonl(metrics)
        if not metric_rows or int(metric_rows[-1].get("update", -1)) != config.training.max_updates:
            raise Gate1Error(f"metrics update mismatch: {variant.value}/seed-{seed}")
        serialized_metrics = _canonical_json(metric_rows)
        if '"partition":"test"' in serialized_metrics or '"partition":"iid_test"' in serialized_metrics:
            raise Gate1Error(f"blind partition was accessed: {variant.value}/seed-{seed}")
        parameter_counts.add(int(manifest.get("parameter_count", -1)))
        completed_updates.add(int(manifest.get("completed_updates", -1)))
        train_counts.add(int(manifest.get("train_record_count", -1)))
        validation_counts.add(int(manifest.get("validation_record_count", -1)))
        gate0_hashes.add(str(manifest.get("gate0_report_hash", "")))
        ledger_by_variant[variant.value].add(
            str(manifest.get("data_ledger_hash", ""))
        )

    if len(parameter_counts) != 1:
        raise Gate1Error(f"parameter counts differ: {sorted(parameter_counts)}")
    if completed_updates != {config.training.max_updates}:
        raise Gate1Error(f"completed updates differ: {sorted(completed_updates)}")
    if len(train_counts) != 1 or len(validation_counts) != 1:
        raise Gate1Error("matched train/validation record counts differ")
    if len(gate0_hashes) != 1:
        raise Gate1Error("runs do not share one Gate 0 report")
    if any(len(values) != 1 for values in ledger_by_variant.values()):
        raise Gate1Error("data ledger changed across seeds within a variant")
    return MatrixAudit(
        run_count=len(expected),
        expected_run_count=len(expected),
        parameter_count=next(iter(parameter_counts)),
        completed_updates=next(iter(completed_updates)),
        train_record_count=next(iter(train_counts)),
        validation_record_count=next(iter(validation_counts)),
        config_hash=config.config_hash,
        gate0_report_hash=next(iter(gate0_hashes)),
    )


def _lock_payload(root: Path, config: Gate1Config) -> dict[str, object]:
    audit = validate_run_matrix(root, config)
    run_files = {}
    for variant, seed, run_dir in _expected_runs(root, config):
        key = f"{variant.value}/seed-{seed}"
        run_files[key] = {
            name: _file_hash(run_dir / name)
            for name in ("checkpoint.pt", "metrics.jsonl", "run_manifest.json")
        }
    return {
        "schema_version": config.schema_version,
        "experiment_version": config.experiment_version,
        "config_hash": config.config_hash,
        "audit": asdict(audit),
        "run_files": run_files,
    }


def freeze_run_matrix(root: Path, config: Gate1Config) -> dict[str, object]:
    root = Path(root)
    payload = _lock_payload(root, config)
    lock = {**payload, "lock_hash": _payload_hash(payload)}
    _atomic_write_json(root / "gate1_lock.json", lock)
    return lock


def require_blind_test_lock(root: Path, *, unlock: bool) -> dict[str, object]:
    if not unlock:
        raise Gate1Error("blind evaluation must be explicitly unlocked")
    path = Path(root) / "gate1_lock.json"
    if not path.is_file():
        raise Gate1Error("blind-test lock is missing")
    lock = _read_json(path)
    claimed = lock.pop("lock_hash", None)
    observed = _payload_hash(lock)
    if claimed != observed:
        raise Gate1Error("blind-test lock hash mismatch")
    return {**lock, "lock_hash": claimed}


def _progress(path: Path, event: str, **fields: object) -> None:
    row = {
        "event": event,
        "timestamp_utc": datetime.now(UTC).isoformat(),
        **fields,
    }
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(_canonical_json(row) + "\n")
        handle.flush()


def _sampling_seed(seed: int, partition: str, start: int) -> int:
    digest = hashlib.sha256(f"{seed}:{partition}:{start}".encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big")


def _load_partition_records(
    mp20_root: Path,
    gate0_dir: Path,
    config: Gate1Config,
    variant: CorruptionVariant,
    partition: str,
) -> tuple[CompletionRecord, ...]:
    records = load_completion_records(mp20_root, gate0_dir, variant)
    partitioned = assign_model_partitions(
        records,
        seed=config.data.partition_seed,
        iid_fraction=config.data.iid_holdout_fraction,
    )
    selected = tuple(
        record for record in partitioned if record.model_partition == partition
    )
    if not selected:
        raise Gate1Error(f"partition {partition!r} is empty for {variant.value}")
    return selected


def _evaluate_run(
    *,
    records: Sequence[CompletionRecord],
    run_dir: Path,
    config: Gate1Config,
    variant: CorruptionVariant,
    seed: int,
    device: torch.device,
) -> tuple[CompletionMetrics, ...]:
    model = PeriodicCompletionModel(config.model).to(device)
    checkpoint = torch.load(
        run_dir / "checkpoint.pt", map_location=device, weights_only=False
    )
    model.load_state_dict(checkpoint["model"])
    model.eval()
    rows: list[CompletionMetrics] = []
    for start in range(0, len(records), config.training.batch_size):
        subset = records[start : start + config.training.batch_size]
        examples = tuple(
            make_model_example(
                record,
                noise_seed=_sampling_seed(seed, record.model_partition or record.split, start),
            )
            for record in subset
        )
        batch, target = collate_completion_examples(examples, device=device)
        sampled = sample_completions(
            model,
            batch,
            samples_per_state=config.sampling.samples_per_state,
            refinement_steps=config.sampling.refinement_steps,
            seed=_sampling_seed(seed, records[0].model_partition or records[0].split, start),
        )
        for batch_index, record in enumerate(subset):
            rows.append(
                evaluate_completion(
                    batch,
                    sampled.selected_output,
                    target,
                    batch_index=batch_index,
                    material_id=record.material_id,
                    path_index=record.path_index,
                    prototype_family=record.prototype_family,
                    partition=record.model_partition or record.split,
                    variant=variant.value,
                    seed=seed,
                    stress_flags=record.stress_flags,
                    edge_cutoff_angstrom=config.model.neighbor_cutoff_angstrom,
                    edge_probability_threshold=config.metrics.edge_probability_threshold,
                    structure_matcher_stol=config.metrics.structure_matcher_stol,
                    structure_matcher_angle_tolerance=config.metrics.structure_matcher_angle_tolerance,
                    short_contact_absolute_angstrom=config.metrics.short_contact_absolute_angstrom,
                    short_contact_radius_scale=config.metrics.short_contact_radius_scale,
                    radius_fallback_angstrom=config.metrics.radius_fallback_angstrom,
                )
            )
    return tuple(rows)


def _metric_payload(row: CompletionMetrics) -> dict[str, object]:
    return {
        **asdict(row),
        "strict_success": row.strict_success,
        "failure_reasons": row.failure_reasons,
    }


def evaluate_matrix_partition(
    *,
    mp20_root: Path,
    gate0_dir: Path,
    root: Path,
    config: Gate1Config,
    partition: str,
    device: str,
) -> tuple[tuple[CompletionMetrics, ...], dict[str, object]]:
    resolved_device = torch.device(
        "cuda" if device == "auto" and torch.cuda.is_available() else device
        if device != "auto"
        else "cpu"
    )
    all_rows: list[CompletionMetrics] = []
    summaries: dict[str, object] = {}
    record_cache: dict[CorruptionVariant, tuple[CompletionRecord, ...]] = {}
    for variant in config.variants:
        record_cache[variant] = _load_partition_records(
            mp20_root, gate0_dir, config, variant, partition
        )
        for seed in config.seeds:
            rows = _evaluate_run(
                records=record_cache[variant],
                run_dir=_run_dir(root, variant, seed),
                config=config,
                variant=variant,
                seed=seed,
                device=resolved_device,
            )
            all_rows.extend(rows)
            summaries[f"{variant.value}/seed-{seed}"] = asdict(
                summarize_metrics(rows)
            )
    report = {
        "schema_version": config.schema_version,
        "config_hash": config.config_hash,
        "partition": partition,
        "row_count": len(all_rows),
        "summaries": summaries,
    }
    return tuple(all_rows), report


def _write_partition_evidence(
    root: Path,
    partition: str,
    rows: Sequence[CompletionMetrics],
    report: dict[str, object],
) -> None:
    _write_jsonl(
        root / f"{partition}_predictions.jsonl",
        [_metric_payload(row) for row in rows],
    )
    _atomic_write_json(root / f"{partition}_report.json", report)


def run_matrix(
    *,
    mp20_root: Path,
    gate0_dir: Path,
    root: Path,
    config_path: Path,
    device: str,
    decision_scope: str,
) -> dict[str, object]:
    config = load_gate1_config(config_path)
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    progress_path = root / "progress.jsonl"
    for variant, seed, run_dir in _expected_runs(root, config):
        _progress(
            progress_path,
            "run_started",
            variant=variant.value,
            seed=seed,
        )
        try:
            manifest = train_run(
                TrainingRunArgs(
                    mp20_root=mp20_root,
                    gate0_dir=gate0_dir,
                    output_dir=run_dir,
                    config_path=config_path,
                    variant=variant,
                    seed=seed,
                    device=device,
                )
            )
        except Exception as exc:
            _progress(
                progress_path,
                "run_failed",
                variant=variant.value,
                seed=seed,
                error=str(exc),
            )
            raise
        _progress(
            progress_path,
            "run_completed",
            variant=variant.value,
            seed=seed,
            completed_updates=manifest.completed_updates,
        )

    audit = validate_run_matrix(root, config)
    rows, validation = evaluate_matrix_partition(
        mp20_root=mp20_root,
        gate0_dir=gate0_dir,
        root=root,
        config=config,
        partition="validation",
        device=device,
    )
    _write_partition_evidence(root, "validation", rows, validation)
    report = {
        "schema_version": config.schema_version,
        "experiment_version": config.experiment_version,
        "config_hash": config.config_hash,
        "decision_scope": decision_scope,
        "audit": asdict(audit),
        "validation": validation,
        "test_partition_accessed": False,
    }
    _atomic_write_json(root / "gate1_matrix_report.json", report)
    return report


def _variant_rows(
    rows: Sequence[CompletionMetrics], variant: str
) -> tuple[CompletionMetrics, ...]:
    return tuple(row for row in rows if row.variant == variant)


def _strict_rate(rows: Sequence[CompletionMetrics]) -> float:
    return sum(row.strict_success for row in rows) / len(rows)


def _gate1_decision(
    ood_rows: Sequence[CompletionMetrics],
    iid_rows: Sequence[CompletionMetrics],
    config: Gate1Config,
) -> dict[str, object]:
    random_rates = {
        variant: _strict_rate(_variant_rows(ood_rows, variant))
        for variant in ("m0", "m1")
    }
    baseline = max(random_rates, key=lambda item: (random_rates[item], item))
    m3_ood = _variant_rows(ood_rows, "m3")
    baseline_ood = _variant_rows(ood_rows, baseline)
    m3_rate = _strict_rate(m3_ood)
    baseline_rate = _strict_rate(baseline_ood)
    absolute_gain = m3_rate - baseline_rate
    baseline_error = 1.0 - baseline_rate
    relative_error_reduction = (
        absolute_gain / baseline_error if baseline_error > 0 else 0.0
    )
    interval = paired_family_bootstrap(
        m3_ood,
        baseline_ood,
        draws=config.metrics.bootstrap_draws,
        seed=config.metrics.bootstrap_seed,
    )
    seed_directions = 0
    for seed in config.seeds:
        treated = [row for row in m3_ood if row.seed == seed]
        control = [row for row in baseline_ood if row.seed == seed]
        seed_directions += _strict_rate(treated) > _strict_rate(control)

    m3_iid_rate = _strict_rate(_variant_rows(iid_rows, "m3"))
    baseline_iid_rate = _strict_rate(_variant_rows(iid_rows, baseline))
    iid_drop = baseline_iid_rate - m3_iid_rate
    checks = {
        "effect_size": absolute_gain >= 0.05 or relative_error_reduction >= 0.20,
        "family_bootstrap_lower_positive": interval.lower_95 > 0,
        "seed_direction": seed_directions >= 2,
        "iid_drop_within_two_points": iid_drop <= 0.02,
    }
    return {
        "status": "PASS" if all(checks.values()) else "NO-GO",
        "best_random_baseline": baseline,
        "m3_ood_strict_success": m3_rate,
        "baseline_ood_strict_success": baseline_rate,
        "absolute_gain": absolute_gain,
        "relative_error_reduction": relative_error_reduction,
        "bootstrap": asdict(interval),
        "seed_directions_positive": seed_directions,
        "m3_iid_strict_success": m3_iid_rate,
        "baseline_iid_strict_success": baseline_iid_rate,
        "iid_absolute_drop": iid_drop,
        "checks": checks,
    }


def evaluate_blind(
    *,
    mp20_root: Path,
    gate0_dir: Path,
    root: Path,
    config_path: Path,
    device: str,
    unlock: bool,
) -> dict[str, object]:
    config = load_gate1_config(config_path)
    lock = require_blind_test_lock(root, unlock=unlock)
    current = _lock_payload(root, config)
    if lock.get("config_hash") != config.config_hash or lock.get("run_files") != current.get("run_files"):
        raise Gate1Error("blind-test lock no longer matches the run matrix")
    iid_rows, iid_report = evaluate_matrix_partition(
        mp20_root=mp20_root,
        gate0_dir=gate0_dir,
        root=root,
        config=config,
        partition="iid_test",
        device=device,
    )
    test_rows, test_report = evaluate_matrix_partition(
        mp20_root=mp20_root,
        gate0_dir=gate0_dir,
        root=root,
        config=config,
        partition="test",
        device=device,
    )
    _write_partition_evidence(root, "iid_test", iid_rows, iid_report)
    _write_partition_evidence(root, "test", test_rows, test_report)
    decision = _gate1_decision(test_rows, iid_rows, config)
    report = {
        "schema_version": config.schema_version,
        "config_hash": config.config_hash,
        "lock_hash": lock["lock_hash"],
        "iid": iid_report,
        "prototype_ood": test_report,
        "decision": decision,
    }
    _atomic_write_json(root / "gate1_decision.json", report)
    return report


def _common_run_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--mp20-root", type=Path, required=True)
    parser.add_argument("--gate0-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--device", default="auto")


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run Crysalis Stage A Gate 1")
    subparsers = parser.add_subparsers(dest="command", required=True)
    debug = subparsers.add_parser("run-debug")
    _common_run_arguments(debug)
    pilot = subparsers.add_parser("run-pilot")
    _common_run_arguments(pilot)
    audit_parser = subparsers.add_parser("audit")
    audit_parser.add_argument("--runs", type=Path, required=True)
    audit_parser.add_argument("--config", type=Path, required=True)
    freeze_parser = subparsers.add_parser("freeze")
    freeze_parser.add_argument("--runs", type=Path, required=True)
    freeze_parser.add_argument("--config", type=Path, required=True)
    evaluate_parser = subparsers.add_parser("evaluate")
    evaluate_parser.add_argument("--mp20-root", type=Path, required=True)
    evaluate_parser.add_argument("--gate0-dir", type=Path, required=True)
    evaluate_parser.add_argument("--runs", type=Path, required=True)
    evaluate_parser.add_argument("--config", type=Path, required=True)
    evaluate_parser.add_argument("--device", default="auto")
    evaluate_parser.add_argument("--unlock-blind-test", action="store_true")
    parsed = parser.parse_args(argv)
    try:
        if parsed.command in {"run-debug", "run-pilot"}:
            scope = (
                "smoke_only_no_gate1_claim"
                if parsed.command == "run-debug"
                else "validation_only_blind_test_locked"
            )
            report = run_matrix(
                mp20_root=parsed.mp20_root,
                gate0_dir=parsed.gate0_dir,
                root=parsed.output_dir,
                config_path=parsed.config,
                device=parsed.device,
                decision_scope=scope,
            )
            print(
                f"Gate 1 matrix completed: {report['decision_scope']} "
                f"runs={report['audit']['run_count']}"
            )
            print(parsed.output_dir / "gate1_matrix_report.json")
        elif parsed.command == "audit":
            audit = validate_run_matrix(parsed.runs, load_gate1_config(parsed.config))
            _atomic_write_json(parsed.runs / "matrix_audit.json", asdict(audit))
            print(_canonical_json(asdict(audit)))
        elif parsed.command == "freeze":
            lock = freeze_run_matrix(parsed.runs, load_gate1_config(parsed.config))
            print(lock["lock_hash"])
        else:
            report = evaluate_blind(
                mp20_root=parsed.mp20_root,
                gate0_dir=parsed.gate0_dir,
                root=parsed.runs,
                config_path=parsed.config,
                device=parsed.device,
                unlock=parsed.unlock_blind_test,
            )
            print(f"Gate 1 decision: {report['decision']['status']}")
            print(parsed.runs / "gate1_decision.json")
    except Exception as exc:
        print(f"Gate 1 error: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
