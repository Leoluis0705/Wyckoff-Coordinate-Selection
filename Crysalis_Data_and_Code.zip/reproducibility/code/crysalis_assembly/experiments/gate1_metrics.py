from __future__ import annotations

from collections import Counter, defaultdict
from collections.abc import Sequence
from dataclasses import dataclass

import numpy as np
import torch
import torch.nn.functional as F
from pymatgen.analysis.structure_matcher import StructureMatcher
from pymatgen.core import Element, Lattice, Structure

from .model import CompletionBatch, CompletionOutput
from .model_objective import (
    CompletionTargetBatch,
    has_short_contact,
    match_queries_by_element,
)


class Gate1MetricsError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class CompletionMetrics:
    material_id: str
    path_index: int
    prototype_family: str
    partition: str
    variant: str
    seed: int
    stress_flags: tuple[str, ...]
    orbit_multiplicity_accuracy: float
    wyckoff_accuracy: float
    periodic_edge_precision: float
    periodic_edge_recall: float
    periodic_edge_f1: float
    structure_match: bool
    short_contact: bool
    coordinate_smooth_l1: float = 0.0
    cartesian_mic_rmsd: float = 0.0

    @property
    def strict_success(self) -> bool:
        return (
            self.orbit_multiplicity_accuracy == 1.0
            and self.wyckoff_accuracy == 1.0
            and self.periodic_edge_f1 == 1.0
            and self.structure_match
            and not self.short_contact
        )

    @property
    def failure_reasons(self) -> tuple[str, ...]:
        reasons = []
        if self.orbit_multiplicity_accuracy != 1.0:
            reasons.append("orbit_multiplicity_mismatch")
        if self.wyckoff_accuracy != 1.0:
            reasons.append("wyckoff_mismatch")
        if self.periodic_edge_f1 != 1.0:
            reasons.append("periodic_edge_mismatch")
        if not self.structure_match:
            reasons.append("structure_mismatch")
        if self.short_contact:
            reasons.append("short_contact")
        return tuple(reasons)


@dataclass(frozen=True, slots=True)
class StressSummary:
    flag: str
    count: int
    strict_success_rate: float


@dataclass(frozen=True, slots=True)
class EvaluationSummary:
    count: int
    family_count: int
    strict_successes: int
    micro_strict_success: float
    macro_family_strict_success: float
    mean_orbit_multiplicity_accuracy: float
    mean_wyckoff_accuracy: float
    mean_periodic_edge_f1: float
    structure_match_rate: float
    short_contact_rate: float
    stress_summaries: tuple[StressSummary, ...]
    failure_reason_counts: tuple[tuple[str, int], ...]
    mean_coordinate_smooth_l1: float
    mean_cartesian_mic_rmsd: float


@dataclass(frozen=True, slots=True)
class BootstrapInterval:
    mean_difference: float
    lower_95: float
    upper_95: float
    draws: int
    seed: int
    family_count: int


def _periodic_edge_matrix(
    coordinates: torch.Tensor,
    lattice: torch.Tensor,
    cutoff_angstrom: float,
) -> torch.Tensor:
    delta = coordinates[None, :, :] - coordinates[:, None, :]
    delta = delta - torch.round(delta)
    cartesian = delta @ lattice
    return torch.linalg.vector_norm(cartesian, dim=-1) <= cutoff_angstrom


def _safe_prf(
    predicted: torch.Tensor, expected: torch.Tensor
) -> tuple[float, float, float]:
    true_positive = int((predicted & expected).sum())
    false_positive = int((predicted & ~expected).sum())
    false_negative = int((~predicted & expected).sum())
    precision = (
        true_positive / (true_positive + false_positive)
        if true_positive + false_positive
        else 1.0
    )
    recall = (
        true_positive / (true_positive + false_negative)
        if true_positive + false_negative
        else 1.0
    )
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return precision, recall, f1


def _structure(
    lattice: torch.Tensor,
    atomic_numbers: torch.Tensor,
    coordinates: torch.Tensor,
    node_mask: torch.Tensor,
) -> Structure:
    selected = torch.where(node_mask)[0]
    species = [
        Element.from_Z(int(atomic_numbers[index])).symbol for index in selected.tolist()
    ]
    return Structure(
        Lattice(lattice.detach().cpu().numpy()),
        species,
        coordinates[selected].detach().cpu().numpy(),
        coords_are_cartesian=False,
        to_unit_cell=True,
    )


def evaluate_completion(
    batch: CompletionBatch,
    output: CompletionOutput,
    target: CompletionTargetBatch,
    *,
    batch_index: int,
    material_id: str,
    path_index: int,
    prototype_family: str,
    partition: str,
    variant: str,
    seed: int,
    stress_flags: tuple[str, ...],
    edge_cutoff_angstrom: float = 5.0,
    edge_probability_threshold: float = 0.5,
    structure_matcher_stol: float = 0.5,
    structure_matcher_angle_tolerance: float = 5.0,
    short_contact_absolute_angstrom: float = 0.70,
    short_contact_radius_scale: float = 0.55,
    radius_fallback_angstrom: float = 1.0,
) -> CompletionMetrics:
    if target.material_ids[batch_index] != material_id:
        raise Gate1MetricsError("metric metadata does not match target material ID")
    pairs = match_queries_by_element(batch, output, target)[batch_index]
    if not pairs:
        raise Gate1MetricsError("completion has no query assignments")
    predicted_orbits = []
    expected_orbits = []
    predicted_wyckoff = []
    expected_wyckoff = []
    node_count = batch.atomic_numbers.shape[1]
    mapping = torch.arange(node_count, device=batch.atomic_numbers.device)
    for predicted_index, target_index in pairs:
        mapping[predicted_index] = target_index
        predicted_orbits.append(
            int(output.orbit_multiplicity_logits[batch_index, predicted_index].argmax())
            + 1
        )
        expected_orbits.append(
            int(target.orbit_multiplicities[batch_index, target_index])
        )
        predicted_wyckoff.append(
            int(output.wyckoff_logits[batch_index, predicted_index].argmax())
        )
        expected_wyckoff.append(int(target.wyckoff_indices[batch_index, target_index]))

    orbit_accuracy = sum(
        predicted == expected
        for predicted, expected in zip(predicted_orbits, expected_orbits, strict=True)
    ) / len(pairs)
    wyckoff_accuracy = sum(
        predicted == expected
        for predicted, expected in zip(
            predicted_wyckoff, expected_wyckoff, strict=True
        )
    ) / len(pairs)

    expected_edges = _periodic_edge_matrix(
        target.full_fractional_coordinates[batch_index],
        batch.lattice[batch_index],
        edge_cutoff_angstrom,
    )
    expected_edges = expected_edges[mapping[:, None], mapping[None, :]]
    predicted_edges = (
        torch.sigmoid(output.periodic_edge_logits[batch_index])
        >= edge_probability_threshold
    )
    valid = batch.node_mask[batch_index]
    incident = batch.query_mask[batch_index, :, None] | batch.query_mask[
        batch_index, None, :
    ]
    upper = torch.triu(
        torch.ones((node_count, node_count), dtype=torch.bool, device=valid.device),
        diagonal=1,
    )
    edge_mask = valid[:, None] & valid[None, :] & incident & upper
    edge_precision, edge_recall, edge_f1 = _safe_prf(
        predicted_edges[edge_mask], expected_edges[edge_mask]
    )

    matcher = StructureMatcher(
        ltol=1e-8,
        stol=structure_matcher_stol,
        angle_tol=structure_matcher_angle_tolerance,
        primitive_cell=False,
        scale=False,
        attempt_supercell=False,
    )
    predicted_structure = _structure(
        batch.lattice[batch_index],
        batch.atomic_numbers[batch_index],
        output.fractional_coordinates[batch_index],
        batch.node_mask[batch_index],
    )
    target_structure = _structure(
        batch.lattice[batch_index],
        batch.atomic_numbers[batch_index],
        target.full_fractional_coordinates[batch_index],
        batch.node_mask[batch_index],
    )
    structure_match = bool(matcher.fit(predicted_structure, target_structure))
    short_contact = bool(
        has_short_contact(
            output.fractional_coordinates[batch_index : batch_index + 1],
            batch.lattice[batch_index : batch_index + 1],
            batch.atomic_numbers[batch_index : batch_index + 1],
            batch.node_mask[batch_index : batch_index + 1],
            absolute_angstrom=short_contact_absolute_angstrom,
            radius_scale=short_contact_radius_scale,
            radius_fallback_angstrom=radius_fallback_angstrom,
        )[0]
    )
    coordinate_deltas = torch.stack(
        tuple(
            (
                output.fractional_coordinates[batch_index, predicted_index]
                - target.full_fractional_coordinates[batch_index, target_index]
                - torch.round(
                    output.fractional_coordinates[batch_index, predicted_index]
                    - target.full_fractional_coordinates[batch_index, target_index]
                )
            )
            @ batch.lattice[batch_index]
            for predicted_index, target_index in pairs
        )
    )
    coordinate_smooth_l1 = float(
        F.smooth_l1_loss(coordinate_deltas, torch.zeros_like(coordinate_deltas))
    )
    cartesian_mic_rmsd = float(
        torch.sqrt(torch.mean(torch.sum(coordinate_deltas.square(), dim=-1)))
    )
    return CompletionMetrics(
        material_id=material_id,
        path_index=path_index,
        prototype_family=prototype_family,
        partition=partition,
        variant=variant,
        seed=seed,
        stress_flags=stress_flags,
        orbit_multiplicity_accuracy=orbit_accuracy,
        wyckoff_accuracy=wyckoff_accuracy,
        periodic_edge_precision=edge_precision,
        periodic_edge_recall=edge_recall,
        periodic_edge_f1=edge_f1,
        structure_match=structure_match,
        short_contact=short_contact,
        coordinate_smooth_l1=coordinate_smooth_l1,
        cartesian_mic_rmsd=cartesian_mic_rmsd,
    )


def summarize_metrics(rows: Sequence[CompletionMetrics]) -> EvaluationSummary:
    if not rows:
        raise ValueError("cannot summarize an empty metric set")
    families: dict[str, list[CompletionMetrics]] = defaultdict(list)
    for row in rows:
        families[row.prototype_family].append(row)
    strict_values = [float(row.strict_success) for row in rows]
    family_rates = [
        sum(row.strict_success for row in family_rows) / len(family_rows)
        for family_rows in families.values()
    ]
    stress_flags = sorted({flag for row in rows for flag in row.stress_flags})
    stress_summaries = tuple(
        StressSummary(
            flag=flag,
            count=len(subset),
            strict_success_rate=sum(row.strict_success for row in subset) / len(subset),
        )
        for flag in stress_flags
        for subset in ([row for row in rows if flag in row.stress_flags],)
    )
    failures = Counter(
        reason for row in rows for reason in row.failure_reasons
    )
    return EvaluationSummary(
        count=len(rows),
        family_count=len(families),
        strict_successes=sum(row.strict_success for row in rows),
        micro_strict_success=sum(strict_values) / len(strict_values),
        macro_family_strict_success=sum(family_rates) / len(family_rates),
        mean_orbit_multiplicity_accuracy=sum(
            row.orbit_multiplicity_accuracy for row in rows
        )
        / len(rows),
        mean_wyckoff_accuracy=sum(row.wyckoff_accuracy for row in rows) / len(rows),
        mean_periodic_edge_f1=sum(row.periodic_edge_f1 for row in rows) / len(rows),
        structure_match_rate=sum(row.structure_match for row in rows) / len(rows),
        short_contact_rate=sum(row.short_contact for row in rows) / len(rows),
        stress_summaries=stress_summaries,
        failure_reason_counts=tuple(sorted(failures.items())),
        mean_coordinate_smooth_l1=sum(row.coordinate_smooth_l1 for row in rows)
        / len(rows),
        mean_cartesian_mic_rmsd=sum(row.cartesian_mic_rmsd for row in rows)
        / len(rows),
    )


def _metric_index(
    rows: Sequence[CompletionMetrics],
) -> dict[tuple[str, int, int], CompletionMetrics]:
    index: dict[tuple[str, int, int], CompletionMetrics] = {}
    for row in rows:
        key = (row.material_id, row.path_index, row.seed)
        if key in index:
            raise Gate1MetricsError(f"duplicate paired metric key {key}")
        index[key] = row
    return index


def paired_family_bootstrap(
    treatment: Sequence[CompletionMetrics],
    baseline: Sequence[CompletionMetrics],
    *,
    draws: int,
    seed: int,
) -> BootstrapInterval:
    if draws <= 0:
        raise ValueError("draws must be positive")
    treatment_index = _metric_index(treatment)
    baseline_index = _metric_index(baseline)
    if set(treatment_index) != set(baseline_index):
        raise Gate1MetricsError("paired metric keys do not match")
    family_differences: dict[str, list[float]] = defaultdict(list)
    for key in sorted(treatment_index):
        treated = treatment_index[key]
        control = baseline_index[key]
        if treated.prototype_family != control.prototype_family:
            raise Gate1MetricsError(f"paired family mismatch for {key}")
        family_differences[treated.prototype_family].append(
            float(treated.strict_success) - float(control.strict_success)
        )
    if not family_differences:
        raise Gate1MetricsError("paired bootstrap requires metrics")
    family_means = np.asarray(
        [np.mean(values) for _, values in sorted(family_differences.items())],
        dtype=float,
    )
    rng = np.random.default_rng(seed)
    sampled = rng.choice(
        family_means,
        size=(draws, len(family_means)),
        replace=True,
    ).mean(axis=1)
    lower, upper = np.quantile(sampled, (0.025, 0.975))
    return BootstrapInterval(
        mean_difference=float(family_means.mean()),
        lower_95=float(lower),
        upper_95=float(upper),
        draws=draws,
        seed=seed,
        family_count=len(family_means),
    )
