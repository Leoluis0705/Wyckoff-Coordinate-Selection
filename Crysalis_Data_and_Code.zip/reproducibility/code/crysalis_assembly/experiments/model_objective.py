from __future__ import annotations

import warnings
from dataclasses import dataclass, replace
from functools import lru_cache

import torch
import torch.nn.functional as F
from pymatgen.core import Element
from scipy.optimize import linear_sum_assignment
from torch import Tensor

from .model import CompletionBatch, CompletionOutput, PeriodicCompletionModel
from .model_data import CompletionInput, CompletionTarget


class ObjectiveError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class CompletionTargetBatch:
    material_ids: tuple[str, ...]
    full_fractional_coordinates: Tensor
    orbit_multiplicities: Tensor
    wyckoff_indices: Tensor
    original_site_indices: Tensor

    def to(self, device: torch.device | str) -> CompletionTargetBatch:
        return replace(
            self,
            full_fractional_coordinates=self.full_fractional_coordinates.to(device),
            orbit_multiplicities=self.orbit_multiplicities.to(device),
            wyckoff_indices=self.wyckoff_indices.to(device),
            original_site_indices=self.original_site_indices.to(device),
        )


@dataclass(frozen=True, slots=True)
class LossWeights:
    coordinate: float
    orbit_multiplicity: float
    wyckoff: float
    periodic_edge: float
    stop: float
    invalid_risk: float

    def __post_init__(self) -> None:
        if any(
            value < 0
            for value in (
                self.coordinate,
                self.orbit_multiplicity,
                self.wyckoff,
                self.periodic_edge,
                self.stop,
                self.invalid_risk,
            )
        ):
            raise ValueError("loss weights must be non-negative")


@dataclass(frozen=True, slots=True)
class LossBreakdown:
    total: Tensor
    coordinate: Tensor
    orbit_multiplicity: Tensor
    wyckoff: Tensor
    periodic_edge: Tensor
    stop: Tensor
    invalid_risk: Tensor


@dataclass(frozen=True, slots=True)
class SampledCompletions:
    all_fractional_coordinates: Tensor
    selected_fractional_coordinates: Tensor
    selected_indices: Tensor
    candidate_scores: Tensor
    selected_output: CompletionOutput


def collate_completion_examples(
    examples: tuple[tuple[CompletionInput, CompletionTarget], ...],
    *,
    noise_level: float = 1.0,
    device: torch.device | str | None = None,
) -> tuple[CompletionBatch, CompletionTargetBatch]:
    if not examples:
        raise ValueError("cannot collate an empty completion batch")
    batch_size = len(examples)
    node_count = max(len(model_input.atomic_numbers) for model_input, _ in examples)
    atomic_numbers = torch.zeros((batch_size, node_count), dtype=torch.long)
    coordinates = torch.zeros((batch_size, node_count, 3), dtype=torch.float32)
    lattice = torch.zeros((batch_size, 3, 3), dtype=torch.float32)
    node_mask = torch.zeros((batch_size, node_count), dtype=torch.bool)
    query_mask = torch.zeros((batch_size, node_count), dtype=torch.bool)
    space_group = torch.zeros(batch_size, dtype=torch.long)
    missing_count = torch.zeros(batch_size, dtype=torch.float32)
    target_coordinates = torch.zeros((batch_size, node_count, 3), dtype=torch.float32)
    orbit_multiplicities = torch.zeros((batch_size, node_count), dtype=torch.long)
    wyckoff_indices = torch.full((batch_size, node_count), -1, dtype=torch.long)
    original_site_indices = torch.full((batch_size, node_count), -1, dtype=torch.long)
    material_ids: list[str] = []

    for batch_index, (model_input, target) in enumerate(examples):
        if model_input.material_id != target.material_id:
            raise ObjectiveError("input and target material IDs differ")
        count = len(model_input.atomic_numbers)
        query_positions = [
            index for index, is_query in enumerate(model_input.query_mask) if is_query
        ]
        if len(query_positions) != len(target.query_fractional_coordinates):
            raise ObjectiveError("query target count does not match model input")
        atomic_numbers[batch_index, :count] = torch.tensor(model_input.atomic_numbers)
        coordinates[batch_index, :count] = torch.tensor(
            model_input.fractional_coordinates, dtype=torch.float32
        )
        lattice[batch_index] = torch.tensor(model_input.lattice, dtype=torch.float32)
        node_mask[batch_index, :count] = True
        query_mask[batch_index, :count] = torch.tensor(model_input.query_mask)
        space_group[batch_index] = model_input.space_group
        missing_count[batch_index] = model_input.missing_count
        target_coordinates[batch_index, :count] = torch.tensor(
            target.full_fractional_coordinates, dtype=torch.float32
        )
        orbit_multiplicities[batch_index, query_positions] = torch.tensor(
            target.query_orbit_multiplicities
        )
        wyckoff_indices[batch_index, query_positions] = torch.tensor(
            target.query_wyckoff_indices
        )
        original_site_indices[batch_index, query_positions] = torch.tensor(
            target.original_site_indices
        )
        material_ids.append(model_input.material_id)

    batch = CompletionBatch(
        atomic_numbers=atomic_numbers,
        fractional_coordinates=coordinates,
        lattice=lattice,
        node_mask=node_mask,
        query_mask=query_mask,
        space_group=space_group,
        missing_count=missing_count,
        noise_level=torch.full((batch_size,), float(noise_level)),
    )
    target_batch = CompletionTargetBatch(
        material_ids=tuple(material_ids),
        full_fractional_coordinates=target_coordinates,
        orbit_multiplicities=orbit_multiplicities,
        wyckoff_indices=wyckoff_indices,
        original_site_indices=original_site_indices,
    )
    if device is not None:
        batch = batch.to(device)
        target_batch = target_batch.to(device)
    return batch, target_batch


def _periodic_cartesian_delta(
    first: Tensor, second: Tensor, lattice: Tensor
) -> Tensor:
    delta = first - second
    delta = delta - torch.round(delta)
    return delta @ lattice


def match_queries_by_element(
    batch: CompletionBatch,
    output: CompletionOutput,
    target: CompletionTargetBatch,
) -> tuple[tuple[tuple[int, int], ...], ...]:
    assignments: list[tuple[tuple[int, int], ...]] = []
    for batch_index in range(batch.atomic_numbers.shape[0]):
        query_indices = torch.where(batch.query_mask[batch_index])[0]
        pairs: list[tuple[int, int]] = []
        elements = torch.unique(batch.atomic_numbers[batch_index, query_indices])
        for element in elements.tolist():
            predicted_indices = query_indices[
                batch.atomic_numbers[batch_index, query_indices] == element
            ]
            target_indices = query_indices[
                batch.atomic_numbers[batch_index, query_indices] == element
            ]
            if len(predicted_indices) != len(target_indices):
                raise ObjectiveError("predicted and target element multisets differ")
            predicted = output.fractional_coordinates[
                batch_index, predicted_indices
            ][:, None, :]
            expected = target.full_fractional_coordinates[
                batch_index, target_indices
            ][None, :, :]
            delta_cartesian = _periodic_cartesian_delta(
                predicted,
                expected,
                batch.lattice[batch_index],
            )
            cost = delta_cartesian.square().sum(dim=-1).detach().cpu().numpy()
            rows, columns = linear_sum_assignment(cost)
            pairs.extend(
                (int(predicted_indices[row]), int(target_indices[column]))
                for row, column in zip(rows, columns, strict=True)
            )
        assignments.append(tuple(sorted(pairs)))
    return tuple(assignments)


@lru_cache(maxsize=119)
def _atomic_radius(atomic_number: int, fallback: float) -> float:
    if atomic_number <= 0:
        return 0.0
    element = Element.from_Z(atomic_number)
    if element.atomic_radius is not None and float(element.atomic_radius) > 0:
        return float(element.atomic_radius)
    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            message="No data available for atomic_radius_calculated for .*",
            category=UserWarning,
        )
        calculated = element.atomic_radius_calculated
    if calculated is not None and float(calculated) > 0:
        return float(calculated)
    return fallback


def has_short_contact(
    fractional_coordinates: Tensor,
    lattice: Tensor,
    atomic_numbers: Tensor,
    node_mask: Tensor,
    *,
    absolute_angstrom: float = 0.70,
    radius_scale: float = 0.55,
    radius_fallback_angstrom: float = 1.0,
) -> Tensor:
    node_count = fractional_coordinates.shape[1]
    delta = (
        fractional_coordinates[:, None, :, :]
        - fractional_coordinates[:, :, None, :]
    )
    delta = delta - torch.round(delta)
    delta_cartesian = torch.einsum("bijd,bdk->bijk", delta, lattice)
    distance = torch.linalg.vector_norm(delta_cartesian, dim=-1)
    radii = torch.tensor(
        [
            _atomic_radius(int(value), radius_fallback_angstrom)
            for value in atomic_numbers.detach().cpu().reshape(-1).tolist()
        ],
        dtype=fractional_coordinates.dtype,
        device=fractional_coordinates.device,
    ).reshape_as(atomic_numbers)
    threshold = torch.maximum(
        torch.full_like(distance, absolute_angstrom),
        radius_scale * (radii[:, :, None] + radii[:, None, :]),
    )
    pair_mask = node_mask[:, :, None] & node_mask[:, None, :]
    upper = torch.triu(
        torch.ones((node_count, node_count), dtype=torch.bool, device=node_mask.device),
        diagonal=1,
    )
    return ((distance < threshold) & pair_mask & upper.unsqueeze(0)).any(dim=(1, 2))


def _target_edges(
    target: CompletionTargetBatch,
    batch: CompletionBatch,
    cutoff_angstrom: float,
) -> Tensor:
    delta = (
        target.full_fractional_coordinates[:, None, :, :]
        - target.full_fractional_coordinates[:, :, None, :]
    )
    delta = delta - torch.round(delta)
    cartesian = torch.einsum("bijd,bdk->bijk", delta, batch.lattice)
    return torch.linalg.vector_norm(cartesian, dim=-1) <= cutoff_angstrom


def completion_loss(
    batch: CompletionBatch,
    output: CompletionOutput,
    target: CompletionTargetBatch,
    weights: LossWeights,
    *,
    edge_cutoff_angstrom: float = 5.0,
    short_contact_absolute_angstrom: float = 0.70,
    short_contact_radius_scale: float = 0.55,
    radius_fallback_angstrom: float = 1.0,
) -> LossBreakdown:
    assignments = match_queries_by_element(batch, output, target)
    coordinate_terms: list[Tensor] = []
    orbit_logits: list[Tensor] = []
    orbit_targets: list[Tensor] = []
    wyckoff_logits: list[Tensor] = []
    wyckoff_targets: list[Tensor] = []
    edge_logits: list[Tensor] = []
    edge_targets: list[Tensor] = []
    target_edges = _target_edges(target, batch, edge_cutoff_angstrom)
    node_count = batch.atomic_numbers.shape[1]

    for batch_index, pairs in enumerate(assignments):
        mapping = torch.arange(node_count, device=batch.atomic_numbers.device)
        for predicted_index, target_index in pairs:
            mapping[predicted_index] = target_index
            delta = _periodic_cartesian_delta(
                output.fractional_coordinates[batch_index, predicted_index],
                target.full_fractional_coordinates[batch_index, target_index],
                batch.lattice[batch_index],
            )
            coordinate_terms.append(delta)
            orbit_logits.append(
                output.orbit_multiplicity_logits[batch_index, predicted_index]
            )
            orbit_targets.append(
                target.orbit_multiplicities[batch_index, target_index] - 1
            )
            wyckoff_logits.append(output.wyckoff_logits[batch_index, predicted_index])
            wyckoff_targets.append(target.wyckoff_indices[batch_index, target_index])

        valid = batch.node_mask[batch_index]
        incident = batch.query_mask[batch_index, :, None] | batch.query_mask[
            batch_index, None, :
        ]
        upper = torch.triu(
            torch.ones((node_count, node_count), dtype=torch.bool, device=valid.device),
            diagonal=1,
        )
        edge_mask = valid[:, None] & valid[None, :] & incident & upper
        mapped_target = target_edges[batch_index][mapping[:, None], mapping[None, :]]
        edge_logits.append(output.periodic_edge_logits[batch_index][edge_mask])
        edge_targets.append(mapped_target[edge_mask].to(output.periodic_edge_logits.dtype))

    zero = output.fractional_coordinates.sum() * 0.0
    coordinate = (
        F.smooth_l1_loss(torch.stack(coordinate_terms), torch.zeros_like(torch.stack(coordinate_terms)))
        if coordinate_terms
        else zero
    )
    orbit = (
        F.cross_entropy(torch.stack(orbit_logits), torch.stack(orbit_targets))
        if orbit_logits
        else zero
    )
    wyckoff = (
        F.cross_entropy(torch.stack(wyckoff_logits), torch.stack(wyckoff_targets))
        if wyckoff_logits
        else zero
    )
    edge = (
        F.binary_cross_entropy_with_logits(
            torch.cat(edge_logits), torch.cat(edge_targets)
        )
        if edge_logits and any(values.numel() for values in edge_logits)
        else zero
    )
    invalid_target = has_short_contact(
        output.fractional_coordinates.detach(),
        batch.lattice,
        batch.atomic_numbers,
        batch.node_mask,
        absolute_angstrom=short_contact_absolute_angstrom,
        radius_scale=short_contact_radius_scale,
        radius_fallback_angstrom=radius_fallback_angstrom,
    ).to(output.invalid_risk_logit.dtype)
    invalid_risk = F.binary_cross_entropy_with_logits(
        output.invalid_risk_logit, invalid_target
    )
    stop = F.binary_cross_entropy_with_logits(output.stop_logit, 1.0 - invalid_target)
    total = (
        weights.coordinate * coordinate
        + weights.orbit_multiplicity * orbit
        + weights.wyckoff * wyckoff
        + weights.periodic_edge * edge
        + weights.stop * stop
        + weights.invalid_risk * invalid_risk
    )
    return LossBreakdown(
        total=total,
        coordinate=coordinate,
        orbit_multiplicity=orbit,
        wyckoff=wyckoff,
        periodic_edge=edge,
        stop=stop,
        invalid_risk=invalid_risk,
    )


def sample_completions(
    model: PeriodicCompletionModel,
    batch: CompletionBatch,
    *,
    samples_per_state: int,
    refinement_steps: int,
    seed: int,
) -> SampledCompletions:
    if samples_per_state <= 0 or refinement_steps <= 0:
        raise ValueError("sampling counts must be positive")
    generator = torch.Generator(device=batch.fractional_coordinates.device)
    generator.manual_seed(seed)
    coordinates: list[Tensor] = []
    scores: list[Tensor] = []
    outputs: list[CompletionOutput] = []
    with torch.no_grad():
        for _ in range(samples_per_state):
            noise = torch.rand(
                batch.fractional_coordinates.shape,
                generator=generator,
                dtype=batch.fractional_coordinates.dtype,
                device=batch.fractional_coordinates.device,
            )
            current = replace(
                batch,
                fractional_coordinates=torch.where(
                    batch.query_mask.unsqueeze(-1),
                    noise,
                    batch.fractional_coordinates,
                ),
            )
            output: CompletionOutput | None = None
            for step in range(refinement_steps):
                level = 1.0 - step / refinement_steps
                current = replace(
                    current,
                    noise_level=torch.full_like(current.noise_level, level),
                )
                output = model(current)
                current = replace(
                    current,
                    fractional_coordinates=output.fractional_coordinates,
                )
            assert output is not None
            edge_probability = torch.sigmoid(output.periodic_edge_logits)
            incident = current.query_mask[:, :, None] | current.query_mask[:, None, :]
            pair_mask = (
                current.node_mask[:, :, None]
                & current.node_mask[:, None, :]
                & incident
            )
            uncertainty = (
                edge_probability * (1.0 - edge_probability) * pair_mask
            ).sum(dim=(1, 2)) / pair_mask.sum(dim=(1, 2)).clamp(min=1)
            score = torch.sigmoid(output.invalid_risk_logit) + 1e-3 * uncertainty
            coordinates.append(output.fractional_coordinates)
            scores.append(score)
            outputs.append(output)

    stacked_coordinates = torch.stack(coordinates)
    stacked_scores = torch.stack(scores)
    selected_indices = stacked_scores.argmin(dim=0)
    batch_indices = torch.arange(
        batch.atomic_numbers.shape[0], device=batch.atomic_numbers.device
    )
    selected = stacked_coordinates[selected_indices, batch_indices]

    def select_tensor(values: list[Tensor]) -> Tensor:
        stacked = torch.stack(values)
        return stacked[selected_indices, batch_indices]

    selected_output = CompletionOutput(
        fractional_coordinates=selected,
        query_cartesian_updates=select_tensor(
            [output.query_cartesian_updates for output in outputs]
        ),
        orbit_multiplicity_logits=select_tensor(
            [output.orbit_multiplicity_logits for output in outputs]
        ),
        wyckoff_logits=select_tensor([output.wyckoff_logits for output in outputs]),
        periodic_edge_logits=select_tensor(
            [output.periodic_edge_logits for output in outputs]
        ),
        stop_logit=select_tensor([output.stop_logit for output in outputs]),
        invalid_risk_logit=select_tensor(
            [output.invalid_risk_logit for output in outputs]
        ),
    )
    return SampledCompletions(
        all_fractional_coordinates=stacked_coordinates,
        selected_fractional_coordinates=selected,
        selected_indices=selected_indices,
        candidate_scores=stacked_scores,
        selected_output=selected_output,
    )
