from __future__ import annotations

import hashlib
import json
import math
import warnings
from collections import Counter, defaultdict
from collections.abc import Sequence
from dataclasses import dataclass
from enum import Enum
from itertools import permutations
from statistics import median

from pymatgen.analysis.prototypes import AflowPrototypeMatcher
from pymatgen.analysis.structure_matcher import StructureMatcher
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer

from .mp20 import MP20Record


class RejectionCode(str, Enum):
    PARSE_ERROR = "parse_error"
    ELEMENT_COUNT_OUT_OF_RANGE = "element_count_out_of_range"
    SITE_COUNT_OUT_OF_RANGE = "site_count_out_of_range"
    DISORDERED_SITE = "disordered_site"
    NON_UNIT_OCCUPANCY = "non_unit_occupancy"
    NON_POSITIVE_LATTICE = "non_positive_lattice"
    ROUNDTRIP_MISMATCH = "roundtrip_mismatch"
    AMBIGUOUS_SYMMETRY = "ambiguous_symmetry"
    MIXED_ORBIT_SPECIES = "mixed_orbit_species"


class StructureRejection(ValueError):
    def __init__(self, code: RejectionCode, detail: str):
        self.code = code
        self.detail = detail
        super().__init__(f"{code.value}: {detail}")


@dataclass(frozen=True, slots=True)
class OrbitRecord:
    orbit_index: int
    site_indices: tuple[int, ...]
    element: str
    role: str
    multiplicity: int
    wyckoff_letter: str


@dataclass(frozen=True, slots=True)
class SymmetryObservation:
    symprec: float
    space_group: int
    equivalent_atoms: tuple[int, ...]
    wyckoff_letters: tuple[str, ...]

    @property
    def identity(self) -> tuple[object, ...]:
        groups: dict[int, list[int]] = defaultdict(list)
        for site_index, group in enumerate(self.equivalent_atoms):
            groups[group].append(site_index)
        normalized = tuple(
            sorted(
                (
                    self.wyckoff_letters[indices[0]],
                    tuple(indices),
                )
                for indices in groups.values()
            )
        )
        return self.space_group, normalized


@dataclass(frozen=True, slots=True)
class CanonicalCrystal:
    record: MP20Record
    structure: Structure
    structure_hash: str
    space_group: int
    symmetry_status: str
    symmetry_observations: tuple[SymmetryObservation, ...]
    orbits: tuple[OrbitRecord, ...]
    prototype_signature: str
    reduced_formula: str
    cif_parse_warnings: tuple[str, ...]

    @property
    def material_id(self) -> str:
        return self.record.material_id

    @property
    def site_count(self) -> int:
        return len(self.structure)


@dataclass(frozen=True, slots=True)
class AflowAudit:
    audited_count: int
    matched_count: int
    labels_by_material: tuple[tuple[str, str], ...]

    @property
    def coverage(self) -> float:
        if not self.audited_count:
            return 0.0
        return self.matched_count / self.audited_count


def _canonical_site_records(structure: Structure) -> list[tuple[str, tuple[float, ...]]]:
    records = []
    for site in structure:
        fractional = tuple(round(float(value) % 1.0, 8) for value in site.frac_coords)
        records.append((site.species_string, fractional))
    return sorted(records)


def canonical_structure_hash(structure: Structure) -> str:
    payload = {
        "lattice": [
            [round(float(value), 8) for value in row]
            for row in structure.lattice.matrix
        ],
        "sites": [
            {"element": element, "fractional": list(fractional)}
            for element, fractional in _canonical_site_records(structure)
        ],
    }
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _canonical_structure(structure: Structure) -> Structure:
    sorted_sites = sorted(
        structure,
        key=lambda site: (
            site.species_string,
            *(round(float(value) % 1.0, 8) for value in site.frac_coords),
        ),
    )
    return Structure(
        structure.lattice,
        [site.specie for site in sorted_sites],
        [tuple(float(value) % 1.0 for value in site.frac_coords) for site in sorted_sites],
        coords_are_cartesian=False,
        to_unit_cell=True,
    )


def _observe_symmetry(
    structure: Structure, *, symprec: float, angle_tolerance: float
) -> SymmetryObservation:
    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            message="Set OLD_ERROR_HANDLING to false and catch the errors directly.*",
            category=DeprecationWarning,
        )
        dataset = SpacegroupAnalyzer(
            structure,
            symprec=symprec,
            angle_tolerance=angle_tolerance,
        ).get_symmetry_dataset()
    if dataset is None:
        raise StructureRejection(
            RejectionCode.AMBIGUOUS_SYMMETRY,
            f"spglib returned no dataset at symprec={symprec}",
        )
    return SymmetryObservation(
        symprec=float(symprec),
        space_group=int(dataset.number),
        equivalent_atoms=tuple(int(value) for value in dataset.equivalent_atoms),
        wyckoff_letters=tuple(str(value) for value in dataset.wyckoffs),
    )


def choose_symmetry_observation(
    observations: Sequence[SymmetryObservation],
) -> tuple[SymmetryObservation, str]:
    if len(observations) != 3:
        raise ValueError("symmetry ensemble must contain exactly three observations")
    counts = Counter(observation.identity for observation in observations)
    identity, count = counts.most_common(1)[0]
    if count < 2:
        raise StructureRejection(
            RejectionCode.AMBIGUOUS_SYMMETRY,
            "no two-of-three symmetry signature majority",
        )
    candidates = [item for item in observations if item.identity == identity]
    midpoint = median(item.symprec for item in observations)
    chosen = min(candidates, key=lambda item: (abs(item.symprec - midpoint), item.symprec))
    return chosen, "stable" if count == 3 else "majority"


def _canonical_role_map(
    elements: Sequence[str], raw_orbits: Sequence[tuple[str, int, str]]
) -> tuple[dict[str, str], str]:
    unique_elements = tuple(sorted(set(elements)))
    role_letters = tuple("ABCD"[: len(unique_elements)])
    best_serialized: str | None = None
    best_map: dict[str, str] | None = None
    for assignment in permutations(role_letters):
        role_map = dict(zip(unique_elements, assignment))
        records = sorted(
            (role_map[element], multiplicity, wyckoff)
            for element, multiplicity, wyckoff in raw_orbits
        )
        serialized = ";".join(
            f"{role}:{multiplicity}{wyckoff}"
            for role, multiplicity, wyckoff in records
        )
        if best_serialized is None or serialized < best_serialized:
            best_serialized = serialized
            best_map = role_map
    if best_serialized is None or best_map is None:
        raise ValueError("prototype signature requires at least one element")
    return best_map, best_serialized


def composition_collapsed_signature(
    space_group: int, orbits: Sequence[OrbitRecord]
) -> str:
    _, serialized = _canonical_role_map(
        [orbit.element for orbit in orbits],
        [
            (orbit.element, orbit.multiplicity, orbit.wyckoff_letter)
            for orbit in orbits
        ],
    )
    return f"sg{space_group}|{serialized}"


def _orbits_from_observation(
    structure: Structure, observation: SymmetryObservation
) -> tuple[OrbitRecord, ...]:
    groups: dict[int, list[int]] = defaultdict(list)
    for site_index, group in enumerate(observation.equivalent_atoms):
        groups[group].append(site_index)

    raw = []
    for indices in sorted(groups.values(), key=lambda values: min(values)):
        elements = {structure[index].specie.symbol for index in indices}
        if len(elements) != 1:
            raise StructureRejection(
                RejectionCode.MIXED_ORBIT_SPECIES,
                f"equivalent sites contain multiple elements: {sorted(elements)}",
            )
        element = next(iter(elements))
        raw.append(
            (
                tuple(indices),
                element,
                len(indices),
                observation.wyckoff_letters[indices[0]],
            )
        )

    role_map, _ = _canonical_role_map(
        [item[1] for item in raw],
        [(item[1], item[2], item[3]) for item in raw],
    )
    return tuple(
        OrbitRecord(
            orbit_index=orbit_index,
            site_indices=indices,
            element=element,
            role=role_map[element],
            multiplicity=multiplicity,
            wyckoff_letter=wyckoff,
        )
        for orbit_index, (indices, element, multiplicity, wyckoff) in enumerate(raw)
    )


def canonicalize_record(
    record: MP20Record,
    *,
    symprec_values: Sequence[float],
    angle_tolerance: float,
    max_sites: int,
    min_elements: int = 2,
    max_elements: int = 4,
) -> CanonicalCrystal:
    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            parsed = Structure.from_str(record.cif, fmt="cif")
    except Exception as exc:
        raise StructureRejection(
            RejectionCode.PARSE_ERROR,
            f"{record.material_id}: {exc}",
        ) from exc
    rounding_prefix = "Issues encountered while parsing CIF:"
    rounding_marker = "fractional coordinates rounded to ideal values"
    parse_warnings = tuple(
        str(item.message)
        for item in caught
        if issubclass(item.category, UserWarning)
        and str(item.message).startswith(rounding_prefix)
        and rounding_marker in str(item.message)
    )
    for item in caught:
        message = str(item.message)
        if issubclass(item.category, UserWarning) and message.startswith(
            rounding_prefix
        ) and rounding_marker in message:
            continue
        warnings.warn(message, item.category, stacklevel=2)

    element_count = len(parsed.composition.elements)
    if not min_elements <= element_count <= max_elements:
        raise StructureRejection(
            RejectionCode.ELEMENT_COUNT_OUT_OF_RANGE,
            f"{record.material_id}: found {element_count} elements",
        )
    if not 1 <= len(parsed) <= max_sites:
        raise StructureRejection(
            RejectionCode.SITE_COUNT_OUT_OF_RANGE,
            f"{record.material_id}: found {len(parsed)} sites",
        )
    if not math.isfinite(parsed.volume) or parsed.volume <= 0:
        raise StructureRejection(
            RejectionCode.NON_POSITIVE_LATTICE,
            f"{record.material_id}: volume={parsed.volume}",
        )
    for site in parsed:
        if not site.is_ordered:
            raise StructureRejection(
                RejectionCode.DISORDERED_SITE,
                f"{record.material_id}: disordered site {site.species}",
            )
        occupancy = float(next(iter(site.species.values())))
        if abs(occupancy - 1.0) > 1e-8:
            raise StructureRejection(
                RejectionCode.NON_UNIT_OCCUPANCY,
                f"{record.material_id}: occupancy={occupancy}",
            )

    canonical = _canonical_structure(parsed)
    roundtripped = Structure.from_dict(canonical.as_dict())
    matcher = StructureMatcher(
        primitive_cell=False,
        scale=False,
        attempt_supercell=False,
        ltol=0.2,
        stol=0.3,
        angle_tol=5.0,
    )
    if not matcher.fit(canonical, roundtripped):
        raise StructureRejection(
            RejectionCode.ROUNDTRIP_MISMATCH,
            f"{record.material_id}: pymatgen dictionary round-trip did not match",
        )

    if tuple(float(value) for value in symprec_values) != (0.03, 0.05, 0.1):
        raise ValueError("symprec_values must be exactly (0.03, 0.05, 0.1)")
    observations = tuple(
        _observe_symmetry(
            canonical,
            symprec=float(symprec),
            angle_tolerance=angle_tolerance,
        )
        for symprec in symprec_values
    )
    chosen, status = choose_symmetry_observation(observations)
    orbits = _orbits_from_observation(canonical, chosen)
    return CanonicalCrystal(
        record=record,
        structure=canonical,
        structure_hash=canonical_structure_hash(canonical),
        space_group=chosen.space_group,
        symmetry_status=status,
        symmetry_observations=observations,
        orbits=orbits,
        prototype_signature=composition_collapsed_signature(
            chosen.space_group, orbits
        ),
        reduced_formula=canonical.composition.reduced_formula,
        cif_parse_warnings=parse_warnings,
    )


def audit_aflow_coverage(
    crystals: Sequence[CanonicalCrystal], sample_size: int, seed: int
) -> AflowAudit:
    if type(sample_size) is not int or sample_size < 0:
        raise ValueError("sample_size must be a non-negative integer")
    ranked = sorted(
        crystals,
        key=lambda crystal: (
            hashlib.sha256(
                f"{seed}:{crystal.material_id}".encode("utf-8")
            ).hexdigest(),
            crystal.material_id,
        ),
    )[:sample_size]
    matcher = AflowPrototypeMatcher(
        initial_ltol=0.2,
        initial_stol=0.3,
        initial_angle_tol=5,
    )
    labels = []
    for crystal in ranked:
        try:
            prototypes = matcher.get_prototypes(crystal.structure)
        except Exception:
            prototypes = None
        if not prototypes:
            continue
        label = str(prototypes[0].get("tags", {}).get("aflow", "UNKNOWN"))
        labels.append((crystal.material_id, label))
    return AflowAudit(
        audited_count=len(ranked),
        matched_count=len(labels),
        labels_by_material=tuple(sorted(labels)),
    )
