from __future__ import annotations

import argparse
import hashlib
import json
import sys
import warnings
from collections import Counter
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass, is_dataclass
from enum import Enum
from pathlib import Path

from pymatgen.analysis.structure_matcher import StructureMatcher

from ..constraints import ConstraintCompiler
from ..schemas import SCHEMA_VERSION
from ..serialization import (
    canonical_payload_json,
    payload_hash,
    trajectory_to_payload,
)
from .deconstruction import (
    CorruptionExample,
    DeconstructionError,
    build_full_state,
    build_oracle_trajectory,
    matched_corruptions,
    replay_oracle_actions,
    semantic_paths,
    state_content_hash,
    state_to_structure,
)
from .mp20 import (
    load_mp20_records,
    select_debug_records,
)
from .splits import (
    LeakageAudit,
    SplitEntry,
    assign_grouped_splits,
    assign_verified_families,
    audit_split,
)
from .symmetry import (
    AflowAudit,
    CanonicalCrystal,
    RejectionCode,
    StructureRejection,
    audit_aflow_coverage,
    canonicalize_record,
)


ARTIFACT_NAMES = (
    "source_manifest.json",
    "clean_manifest.jsonl",
    "rejections.jsonl",
    "split_manifest.jsonl",
    "corruption_manifest.jsonl",
    "oracle_roundtrip_manifest.jsonl",
)


class Gate0ConfigError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class Gate0Config:
    schema_version: str
    operator_version: str
    upstream_commit: str
    source_hashes: dict[str, str]
    limit: int
    seed: int
    min_elements: int
    max_elements: int
    max_sites: int
    symprec_values: tuple[float, ...]
    angle_tolerance: float
    max_ambiguity_rate: float
    min_missing_fraction: float
    max_missing_fraction: float
    paths_per_parent: int
    neighbor_cutoff: float
    split_ratios: dict[str, float]
    aflow_sample_size: int
    near_duplicate_max_rate: float
    canonical_roundtrip_min_rate: float
    oracle_inverse_min_rate: float
    raw_payload: dict[str, object]

    @property
    def config_hash(self) -> str:
        return payload_hash(self.raw_payload)


@dataclass(frozen=True, slots=True)
class SourceSummary:
    total_records: int
    selected_records: int
    rows_by_split: dict[str, int]
    sha256_by_file: dict[str, str]
    upstream_commit: str
    strict_hashes: bool


@dataclass(frozen=True, slots=True)
class CleanSummary:
    domain_candidate_records: int
    clean_records: int
    rejection_counts: dict[str, int]
    canonical_roundtrip_attempts: int
    canonical_roundtrip_successes: int
    canonical_roundtrip_rate: float
    symmetry_attempts: int
    ambiguous_symmetry_records: int
    ambiguity_rate: float
    cif_rounding_warning_records: int
    cif_rounding_warning_messages: int


@dataclass(frozen=True, slots=True)
class SplitSummary:
    structure_counts: dict[str, int]
    prototype_family_count: int
    stress_counts: dict[str, int]


@dataclass(frozen=True, slots=True)
class CorruptionSummary:
    eligible_parents: int
    ineligible_parents: int
    variant_counts: dict[str, int]
    unique_path_count_distribution: dict[str, int]


@dataclass(frozen=True, slots=True)
class OracleSummary:
    attempts: int
    successes: int
    content_recoveries: int
    structure_match_recoveries: int
    split_mismatches: int
    recovery_rate: float


@dataclass(frozen=True, slots=True)
class ProjectorSummary:
    attempts: int
    idempotent: int
    idempotency_rate: float


@dataclass(frozen=True, slots=True)
class GateCheck:
    name: str
    passed: bool
    observed: float | int | str
    criterion: str


@dataclass(frozen=True, slots=True)
class Gate0Report:
    schema_version: str
    operator_version: str
    config_hash: str
    source: SourceSummary
    clean: CleanSummary
    split: SplitSummary
    leakage: LeakageAudit
    corruption: CorruptionSummary
    oracle: OracleSummary
    projector: ProjectorSummary
    aflow: AflowAudit
    gate_checks: tuple[GateCheck, ...]
    gate0_pass: bool
    scope_note: str
    artifact_hashes: dict[str, str]


def _require_mapping(value: object, name: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise Gate0ConfigError(f"{name} must be an object")
    return value


def _require_keys(
    value: Mapping[str, object], expected: set[str], name: str
) -> None:
    actual = set(value)
    if actual != expected:
        missing = sorted(expected - actual)
        extra = sorted(actual - expected)
        raise Gate0ConfigError(
            f"{name} keys differ; missing={missing}, extra={extra}"
        )


def load_gate0_config(path: Path) -> Gate0Config:
    try:
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise Gate0ConfigError(f"cannot read Gate 0 config: {exc}") from exc
    root = _require_mapping(raw, "config")
    _require_keys(
        root,
        {
            "schema_version",
            "operator_version",
            "source",
            "selection",
            "symmetry",
            "deconstruction",
            "edges",
            "split",
            "audit",
            "gates",
        },
        "config",
    )
    source = _require_mapping(root["source"], "source")
    selection = _require_mapping(root["selection"], "selection")
    symmetry = _require_mapping(root["symmetry"], "symmetry")
    deconstruction = _require_mapping(root["deconstruction"], "deconstruction")
    edges = _require_mapping(root["edges"], "edges")
    split = _require_mapping(root["split"], "split")
    audit = _require_mapping(root["audit"], "audit")
    gates = _require_mapping(root["gates"], "gates")
    _require_keys(source, {"upstream_commit", "hashes"}, "source")
    _require_keys(
        selection,
        {"limit", "seed", "min_elements", "max_elements", "max_sites"},
        "selection",
    )
    _require_keys(
        symmetry,
        {"symprec", "angle_tolerance", "max_ambiguity_rate"},
        "symmetry",
    )
    _require_keys(
        deconstruction,
        {"min_missing_fraction", "max_missing_fraction", "paths_per_parent"},
        "deconstruction",
    )
    _require_keys(edges, {"neighbor_cutoff_angstrom"}, "edges")
    _require_keys(split, {"train", "validation", "test"}, "split")
    _require_keys(
        audit,
        {"aflow_sample_size", "near_duplicate_max_rate"},
        "audit",
    )
    _require_keys(
        gates,
        {"canonical_roundtrip_min_rate", "oracle_inverse_min_rate"},
        "gates",
    )
    hashes = _require_mapping(source["hashes"], "source.hashes")
    config = Gate0Config(
        schema_version=str(root["schema_version"]),
        operator_version=str(root["operator_version"]),
        upstream_commit=str(source["upstream_commit"]),
        source_hashes={str(key): str(value) for key, value in hashes.items()},
        limit=int(selection["limit"]),
        seed=int(selection["seed"]),
        min_elements=int(selection["min_elements"]),
        max_elements=int(selection["max_elements"]),
        max_sites=int(selection["max_sites"]),
        symprec_values=tuple(float(value) for value in symmetry["symprec"]),
        angle_tolerance=float(symmetry["angle_tolerance"]),
        max_ambiguity_rate=float(symmetry["max_ambiguity_rate"]),
        min_missing_fraction=float(deconstruction["min_missing_fraction"]),
        max_missing_fraction=float(deconstruction["max_missing_fraction"]),
        paths_per_parent=int(deconstruction["paths_per_parent"]),
        neighbor_cutoff=float(edges["neighbor_cutoff_angstrom"]),
        split_ratios={name: float(split[name]) for name in ("train", "validation", "test")},
        aflow_sample_size=int(audit["aflow_sample_size"]),
        near_duplicate_max_rate=float(audit["near_duplicate_max_rate"]),
        canonical_roundtrip_min_rate=float(gates["canonical_roundtrip_min_rate"]),
        oracle_inverse_min_rate=float(gates["oracle_inverse_min_rate"]),
        raw_payload=dict(root),
    )
    if config.schema_version != SCHEMA_VERSION:
        raise Gate0ConfigError(
            f"config schema_version must be {SCHEMA_VERSION}"
        )
    if not config.operator_version.strip():
        raise Gate0ConfigError("operator_version must be non-empty")
    if config.seed != 20260820:
        raise Gate0ConfigError("selection seed must be 20260820")
    if config.paths_per_parent != 4:
        raise Gate0ConfigError("paths_per_parent must be 4")
    if config.symprec_values != (0.03, 0.05, 0.1):
        raise Gate0ConfigError("symprec must be [0.03, 0.05, 0.1]")
    if not 0 <= config.aflow_sample_size:
        raise Gate0ConfigError("aflow_sample_size must be non-negative")
    if not 0 <= config.max_ambiguity_rate < 1:
        raise Gate0ConfigError("max_ambiguity_rate must be in [0, 1)")
    if not 0 < config.near_duplicate_max_rate < 1:
        raise Gate0ConfigError("near_duplicate_max_rate must be in (0, 1)")
    return config


def _jsonable(value: object) -> object:
    if is_dataclass(value) and not isinstance(value, type):
        return _jsonable(asdict(value))
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_jsonable(item) for item in value]
    return value


def _atomic_write(path: Path, text: str) -> None:
    temporary = path.with_name(f"{path.name}.tmp")
    temporary.write_text(text, encoding="utf-8", newline="\n")
    temporary.replace(path)


def _write_json(path: Path, payload: object) -> None:
    _atomic_write(path, canonical_payload_json(_jsonable(payload)) + "\n")


def _write_jsonl(path: Path, rows: Sequence[Mapping[str, object]]) -> None:
    text = "".join(canonical_payload_json(_jsonable(row)) + "\n" for row in rows)
    _atomic_write(path, text)


def _file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _fixed_matcher() -> StructureMatcher:
    return StructureMatcher(
        primitive_cell=False,
        scale=False,
        attempt_supercell=False,
        ltol=0.2,
        stol=0.3,
        angle_tol=5.0,
    )


def _projector_idempotent(state: object) -> bool:
    compiler = ConstraintCompiler()
    first = compiler.project_or_reject(state)
    if first.state is None or first.report.rejected:
        return False
    second = compiler.project_or_reject(first.state)
    return (
        second.state == first.state
        and not second.report.rejected
        and second.report.projection_magnitude == 0.0
    )


def _clean_manifest_row(
    crystal: CanonicalCrystal, entry: SplitEntry
) -> dict[str, object]:
    return {
        "material_id": crystal.material_id,
        "source_split": crystal.record.source_split,
        "source_row": crystal.record.source_row,
        "reduced_formula": crystal.reduced_formula,
        "element_count": len(crystal.structure.composition.elements),
        "site_count": crystal.site_count,
        "space_group": crystal.space_group,
        "symmetry_status": crystal.symmetry_status,
        "structure_hash": crystal.structure_hash,
        "prototype_signature": crystal.prototype_signature,
        "prototype_family": entry.prototype_family,
        "split": entry.split,
        "stress_flags": entry.stress_flags,
        "cif_parse_warnings": crystal.cif_parse_warnings,
    }


def _corruption_row(
    example: CorruptionExample, split: str
) -> dict[str, object]:
    return {
        "parent_material_id": example.parent_material_id,
        "split": split,
        "variant": example.variant.value,
        "path_index": example.path_index,
        "example_seed": example.example_seed,
        "missing_site_indices": example.missing_site_indices,
        "missing_orbit_indices": example.missing_orbit_indices,
        "missing_count": example.missing_count,
        "missing_fraction": example.missing_fraction,
        "site_count": example.site_count,
        "is_semantic_union": example.is_semantic_union,
        "unique_semantic_path_count": example.unique_semantic_path_count,
    }


def _render_markdown(report: Gate0Report) -> str:
    status = "PASS" if report.gate0_pass else "NO-GO"
    lines = [
        "# Crysalis Stage A Gate 0 Debug Report",
        "",
        f"**Decision:** {status}",
        "",
        "## Source and cleaning",
        "",
        f"- Source records: {report.source.total_records}",
        f"- Deterministic debug selection: {report.source.selected_records}",
        f"- Clean records: {report.clean.clean_records}",
        f"- Canonical round-trip: {report.clean.canonical_roundtrip_successes}/{report.clean.canonical_roundtrip_attempts} ({report.clean.canonical_roundtrip_rate:.4%})",
        f"- Symmetry ambiguity: {report.clean.ambiguous_symmetry_records}/{report.clean.symmetry_attempts} ({report.clean.ambiguity_rate:.4%})",
        f"- CIF ideal-coordinate rounding warnings captured: {report.clean.cif_rounding_warning_records} records / {report.clean.cif_rounding_warning_messages} messages",
        "",
        "## Split and corruption",
        "",
        f"- Split counts: {report.split.structure_counts}",
        f"- Verified prototype families: {report.split.prototype_family_count}",
        f"- Eligible parents: {report.corruption.eligible_parents}",
        f"- Variant counts: {report.corruption.variant_counts}",
        "",
        "## Oracle and leakage",
        "",
        f"- Oracle recovery: {report.oracle.successes}/{report.oracle.attempts} ({report.oracle.recovery_rate:.4%})",
        f"- Projector idempotency: {report.projector.idempotent}/{report.projector.attempts} ({report.projector.idempotency_rate:.4%})",
        f"- Prototype-family cross-split leaks: {report.leakage.prototype_family_cross_split}",
        f"- Exact-hash cross-split leaks: {report.leakage.exact_structure_hash_cross_split}",
        f"- Confirmed near-duplicate cross-split pairs: {report.leakage.confirmed_near_duplicate_cross_split}",
        "",
        "## Gate checks",
        "",
        "| Check | Passed | Observed | Criterion |",
        "|---|---:|---:|---|",
    ]
    lines.extend(
        f"| {check.name} | {'yes' if check.passed else 'no'} | {check.observed} | {check.criterion} |"
        for check in report.gate_checks
    )
    lines.extend(
        [
            "",
            "## Scope",
            "",
            "This run is intentionally role/orbit/edge only. Motif factors are not part of Gate 0 and remain gated behind the later M4 decision.",
            "",
        ]
    )
    return "\n".join(lines)


def run_gate0(
    mp20_root: Path,
    output_dir: Path,
    config_path: Path,
    *,
    strict_hashes: bool = True,
) -> Gate0Report:
    config = load_gate0_config(config_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    records, source_manifest = load_mp20_records(
        Path(mp20_root),
        expected_hashes=config.source_hashes,
        strict_hashes=strict_hashes,
    )
    selected = select_debug_records(records, limit=config.limit, seed=config.seed)
    source_summary = SourceSummary(
        total_records=source_manifest.total_records,
        selected_records=len(selected),
        rows_by_split=dict(source_manifest.rows_by_split),
        sha256_by_file=dict(source_manifest.sha256_by_file),
        upstream_commit=config.upstream_commit,
        strict_hashes=strict_hashes,
    )

    clean: list[CanonicalCrystal] = []
    rejections: list[dict[str, object]] = []
    rejection_counts: Counter[str] = Counter()
    domain_candidates = 0
    roundtrip_attempts = 0
    roundtrip_successes = 0
    symmetry_attempts = 0
    ambiguity_count = 0
    post_roundtrip_codes = {
        RejectionCode.AMBIGUOUS_SYMMETRY,
        RejectionCode.MIXED_ORBIT_SPECIES,
    }
    for record in selected:
        if not config.min_elements <= len(record.elements) <= config.max_elements:
            code = RejectionCode.ELEMENT_COUNT_OUT_OF_RANGE
            rejection_counts[code.value] += 1
            rejections.append(
                {
                    "material_id": record.material_id,
                    "phase": "cleaning",
                    "reason_code": code.value,
                    "detail": f"source declares {len(record.elements)} elements",
                }
            )
            continue
        domain_candidates += 1
        try:
            crystal = canonicalize_record(
                record,
                symprec_values=config.symprec_values,
                angle_tolerance=config.angle_tolerance,
                max_sites=config.max_sites,
                min_elements=config.min_elements,
                max_elements=config.max_elements,
            )
        except StructureRejection as exc:
            rejection_counts[exc.code.value] += 1
            rejections.append(
                {
                    "material_id": record.material_id,
                    "phase": "cleaning",
                    "reason_code": exc.code.value,
                    "detail": exc.detail,
                }
            )
            if exc.code is RejectionCode.ROUNDTRIP_MISMATCH:
                roundtrip_attempts += 1
            elif exc.code in post_roundtrip_codes:
                roundtrip_attempts += 1
                roundtrip_successes += 1
                symmetry_attempts += 1
                if exc.code is RejectionCode.AMBIGUOUS_SYMMETRY:
                    ambiguity_count += 1
            continue
        roundtrip_attempts += 1
        roundtrip_successes += 1
        symmetry_attempts += 1
        clean.append(crystal)

    roundtrip_rate = roundtrip_successes / max(roundtrip_attempts, 1)
    ambiguity_rate = ambiguity_count / max(symmetry_attempts, 1)
    clean_summary = CleanSummary(
        domain_candidate_records=domain_candidates,
        clean_records=len(clean),
        rejection_counts=dict(sorted(rejection_counts.items())),
        canonical_roundtrip_attempts=roundtrip_attempts,
        canonical_roundtrip_successes=roundtrip_successes,
        canonical_roundtrip_rate=roundtrip_rate,
        symmetry_attempts=symmetry_attempts,
        ambiguous_symmetry_records=ambiguity_count,
        ambiguity_rate=ambiguity_rate,
        cif_rounding_warning_records=sum(
            bool(crystal.cif_parse_warnings) for crystal in clean
        ),
        cif_rounding_warning_messages=sum(
            len(crystal.cif_parse_warnings) for crystal in clean
        ),
    )

    aflow = audit_aflow_coverage(
        clean,
        sample_size=min(config.aflow_sample_size, len(clean)),
        seed=config.seed,
    )
    families = assign_verified_families(clean)
    split_entries = assign_grouped_splits(
        clean,
        families,
        config.split_ratios,
        seed=config.seed,
    )
    crystals_by_id = {crystal.material_id: crystal for crystal in clean}
    entry_by_id = {entry.material_id: entry for entry in split_entries}
    leakage = audit_split(split_entries, crystals_by_id)
    split_counts = Counter(entry.split for entry in split_entries)
    stress_counts = Counter(
        flag for entry in split_entries for flag in entry.stress_flags
    )
    split_summary = SplitSummary(
        structure_counts={name: split_counts[name] for name in ("train", "validation", "test")},
        prototype_family_count=len(set(families.values())),
        stress_counts=dict(sorted(stress_counts.items())),
    )

    corruption_rows: list[dict[str, object]] = []
    oracle_rows: list[dict[str, object]] = []
    variant_counts: Counter[str] = Counter()
    unique_path_counts: Counter[str] = Counter()
    eligible_parents = 0
    oracle_attempts = 0
    oracle_successes = 0
    content_recoveries = 0
    structure_recoveries = 0
    split_mismatches = 0
    projector_attempts = 0
    projector_idempotent = 0
    matcher = _fixed_matcher()
    for crystal in sorted(clean, key=lambda item: item.material_id):
        entry = entry_by_id[crystal.material_id]
        try:
            paths = semantic_paths(
                crystal,
                count=config.paths_per_parent,
                min_fraction=config.min_missing_fraction,
                max_fraction=config.max_missing_fraction,
                seed=config.seed,
            )
        except DeconstructionError as exc:
            rejections.append(
                {
                    "material_id": crystal.material_id,
                    "phase": "deconstruction",
                    "reason_code": "no_semantic_mask_in_fraction_band",
                    "detail": str(exc),
                }
            )
            continue
        eligible_parents += 1
        unique_path_counts[str(paths[0].unique_path_count)] += 1
        examples = matched_corruptions(
            crystal,
            paths,
            count=config.paths_per_parent,
            min_fraction=config.min_missing_fraction,
            max_fraction=config.max_missing_fraction,
            seed=config.seed,
        )
        for example in examples:
            variant_counts[example.variant.value] += 1
            corruption_rows.append(_corruption_row(example, entry.split))

        full_state = build_full_state(
            crystal,
            entry.prototype_family,
            cutoff=config.neighbor_cutoff,
        )
        for path in paths:
            oracle_attempts += 1
            trajectory = build_oracle_trajectory(
                full_state,
                crystal,
                path,
                split=entry.split,
                operator_version=config.operator_version,
            )
            if trajectory.split != entry.split:
                split_mismatches += 1
            recovered = replay_oracle_actions(
                trajectory.initial_state,
                tuple(step.action for step in trajectory.steps),
            )
            content_match = state_content_hash(recovered) == state_content_hash(
                full_state
            )
            with warnings.catch_warnings():
                warnings.filterwarnings(
                    "ignore",
                    message="Set OLD_ERROR_HANDLING to false and catch the errors directly.*",
                    category=DeprecationWarning,
                )
                structure_match = bool(
                    matcher.fit(state_to_structure(recovered), crystal.structure)
                )
            content_recoveries += int(content_match)
            structure_recoveries += int(structure_match)
            success = content_match and structure_match
            oracle_successes += int(success)
            for state in (trajectory.initial_state, recovered):
                projector_attempts += 1
                projector_idempotent += int(_projector_idempotent(state))
            oracle_rows.append(
                {
                    "parent_material_id": crystal.material_id,
                    "split": entry.split,
                    "path_index": path.path_index,
                    "trajectory_id": trajectory.trajectory_id,
                    "trajectory_hash": payload_hash(trajectory_to_payload(trajectory)),
                    "content_match": content_match,
                    "structure_match": structure_match,
                    "success": success,
                }
            )

    corruption_summary = CorruptionSummary(
        eligible_parents=eligible_parents,
        ineligible_parents=len(clean) - eligible_parents,
        variant_counts={name: variant_counts[name] for name in ("m0", "m1", "m2", "m3")},
        unique_path_count_distribution=dict(sorted(unique_path_counts.items())),
    )
    oracle_rate = oracle_successes / max(oracle_attempts, 1)
    oracle_summary = OracleSummary(
        attempts=oracle_attempts,
        successes=oracle_successes,
        content_recoveries=content_recoveries,
        structure_match_recoveries=structure_recoveries,
        split_mismatches=split_mismatches,
        recovery_rate=oracle_rate,
    )
    projector_rate = projector_idempotent / max(projector_attempts, 1)
    projector_summary = ProjectorSummary(
        attempts=projector_attempts,
        idempotent=projector_idempotent,
        idempotency_rate=projector_rate,
    )

    matched_counts = len(set(variant_counts.values())) == 1 and set(
        variant_counts
    ) == {"m0", "m1", "m2", "m3"}
    checks = (
        GateCheck(
            "canonical_roundtrip_rate",
            roundtrip_rate >= config.canonical_roundtrip_min_rate,
            roundtrip_rate,
            f">= {config.canonical_roundtrip_min_rate}",
        ),
        GateCheck(
            "symmetry_ambiguity_rate",
            ambiguity_rate <= config.max_ambiguity_rate,
            ambiguity_rate,
            f"<= {config.max_ambiguity_rate}",
        ),
        GateCheck(
            "oracle_inverse_rate",
            oracle_attempts > 0 and oracle_rate >= config.oracle_inverse_min_rate,
            oracle_rate,
            f">= {config.oracle_inverse_min_rate}",
        ),
        GateCheck(
            "prototype_family_cross_split",
            leakage.prototype_family_cross_split == 0,
            leakage.prototype_family_cross_split,
            "== 0",
        ),
        GateCheck(
            "exact_structure_hash_cross_split",
            leakage.exact_structure_hash_cross_split == 0,
            leakage.exact_structure_hash_cross_split,
            "== 0",
        ),
        GateCheck(
            "confirmed_near_duplicate_rate",
            leakage.confirmed_near_duplicate_rate
            < config.near_duplicate_max_rate,
            leakage.confirmed_near_duplicate_rate,
            f"< {config.near_duplicate_max_rate}",
        ),
        GateCheck(
            "trajectory_split_inheritance",
            split_mismatches == 0,
            split_mismatches,
            "== 0",
        ),
        GateCheck(
            "projector_idempotency",
            projector_attempts > 0 and projector_rate == 1.0,
            projector_rate,
            "== 1.0",
        ),
        GateCheck(
            "matched_variant_state_counts",
            matched_counts,
            str(corruption_summary.variant_counts),
            "all four counts equal and non-empty",
        ),
    )
    gate0_pass = all(check.passed for check in checks)

    source_payload = {
        **asdict(source_manifest),
        "upstream_commit": config.upstream_commit,
        "config_hash": config.config_hash,
        "selected_material_ids": [record.material_id for record in selected],
    }
    clean_rows = [
        _clean_manifest_row(crystal, entry_by_id[crystal.material_id])
        for crystal in sorted(clean, key=lambda item: item.material_id)
    ]
    split_rows = [asdict(entry) for entry in split_entries]
    rejections.sort(
        key=lambda row: (
            str(row["material_id"]),
            str(row["phase"]),
            str(row["reason_code"]),
        )
    )
    corruption_rows.sort(
        key=lambda row: (
            str(row["parent_material_id"]),
            str(row["variant"]),
            int(row["path_index"]),
        )
    )
    oracle_rows.sort(
        key=lambda row: (str(row["parent_material_id"]), int(row["path_index"]))
    )
    _write_json(output_dir / "source_manifest.json", source_payload)
    _write_jsonl(output_dir / "clean_manifest.jsonl", clean_rows)
    _write_jsonl(output_dir / "rejections.jsonl", rejections)
    _write_jsonl(output_dir / "split_manifest.jsonl", split_rows)
    _write_jsonl(output_dir / "corruption_manifest.jsonl", corruption_rows)
    _write_jsonl(output_dir / "oracle_roundtrip_manifest.jsonl", oracle_rows)
    artifact_hashes = {
        name: _file_hash(output_dir / name) for name in ARTIFACT_NAMES
    }
    report = Gate0Report(
        schema_version=SCHEMA_VERSION,
        operator_version=config.operator_version,
        config_hash=config.config_hash,
        source=source_summary,
        clean=clean_summary,
        split=split_summary,
        leakage=leakage,
        corruption=corruption_summary,
        oracle=oracle_summary,
        projector=projector_summary,
        aflow=aflow,
        gate_checks=checks,
        gate0_pass=gate0_pass,
        scope_note="orbit_only_no_motif_factors",
        artifact_hashes=artifact_hashes,
    )
    _atomic_write(output_dir / "gate0_report.md", _render_markdown(report))
    _write_json(output_dir / "gate0_report.json", report)
    return report


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run Crysalis Stage A Gate 0")
    parser.add_argument("--mp20-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        report = run_gate0(args.mp20_root, args.output_dir, args.config)
    except Exception as exc:
        print(f"Gate 0 pipeline error: {exc}", file=sys.stderr)
        return 2
    decision = "PASS" if report.gate0_pass else "NO-GO"
    print(f"Gate 0 completed: {decision}")
    print(args.output_dir / "gate0_report.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
