from __future__ import annotations

import hashlib
import json
import math
import random
from collections import Counter
from collections.abc import Sequence
from dataclasses import dataclass, replace
from enum import Enum

from pymatgen.core import Structure

from ..constraints import ConstraintCompiler
from ..periodic import canonical_periodic_edge_key
from ..schemas import (
    ActionType,
    AssemblyAction,
    AssemblyBudget,
    AssemblyState,
    AtomNode,
    ElementCount,
    MaterialEmbryo,
    NodeStatus,
    OrbitNode,
    OrbitSlot,
    PeriodicEdge,
    RoleSlot,
    Trajectory,
    TrajectoryStep,
)
from ..serialization import canonical_payload_json, payload_hash, state_to_payload
from .symmetry import CanonicalCrystal


class DeconstructionError(ValueError):
    pass


class CorruptionVariant(str, Enum):
    M0 = "m0"
    M1 = "m1"
    M2 = "m2"
    M3 = "m3"


@dataclass(frozen=True, slots=True)
class SemanticPath:
    path_index: int
    orbit_indices: tuple[int, ...]
    missing_site_indices: tuple[int, ...]
    unique_path_count: int


@dataclass(frozen=True, slots=True)
class CorruptionExample:
    parent_material_id: str
    variant: CorruptionVariant
    path_index: int
    example_seed: int
    missing_site_indices: tuple[int, ...]
    missing_orbit_indices: tuple[int, ...]
    site_count: int
    is_semantic_union: bool
    unique_semantic_path_count: int

    @property
    def missing_count(self) -> int:
        return len(self.missing_site_indices)

    @property
    def missing_fraction(self) -> float:
        return self.missing_count / self.site_count


def _validate_fraction_band(min_fraction: float, max_fraction: float) -> None:
    if not (0 < min_fraction <= max_fraction < 1):
        raise ValueError("missing fractions must satisfy 0 < min <= max < 1")


def _seeded_int(*parts: object) -> int:
    encoded = ":".join(str(part) for part in parts).encode("utf-8")
    return int.from_bytes(hashlib.sha256(encoded).digest()[:8], "big")


def _subset_rank(material_id: str, seed: int, subset: tuple[int, ...]) -> str:
    encoded = f"{seed}:{material_id}:{','.join(map(str, subset))}".encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def semantic_paths(
    crystal: CanonicalCrystal,
    *,
    count: int,
    min_fraction: float,
    max_fraction: float,
    seed: int,
) -> tuple[SemanticPath, ...]:
    if type(count) is not int or count <= 0:
        raise ValueError("count must be positive")
    _validate_fraction_band(min_fraction, max_fraction)
    min_sites = math.ceil(min_fraction * crystal.site_count - 1e-12)
    max_sites = math.floor(max_fraction * crystal.site_count + 1e-12)
    if min_sites > max_sites:
        raise DeconstructionError("no integer missing count lies in the fraction band")

    cap = max(64, count * 16)
    candidates_by_size: dict[int, list[tuple[int, ...]]] = {0: [()]}
    for orbit in sorted(crystal.orbits, key=lambda item: item.orbit_index):
        snapshot = {size: list(values) for size, values in candidates_by_size.items()}
        for size, subsets in snapshot.items():
            new_size = size + orbit.multiplicity
            if new_size > max_sites:
                continue
            bucket = candidates_by_size.setdefault(new_size, [])
            for subset in subsets:
                candidate = tuple(sorted((*subset, orbit.orbit_index)))
                if candidate not in bucket:
                    bucket.append(candidate)
            bucket.sort(key=lambda item: _subset_rank(crystal.material_id, seed, item))
            del bucket[cap:]

    candidates = {
        subset
        for size, subsets in candidates_by_size.items()
        if min_sites <= size <= max_sites
        for subset in subsets
        if subset
    }
    ranked = sorted(
        candidates,
        key=lambda item: (_subset_rank(crystal.material_id, seed, item), item),
    )
    if not ranked:
        raise DeconstructionError("no_semantic_mask_in_fraction_band")
    unique = ranked[:count]
    orbit_by_index = {orbit.orbit_index: orbit for orbit in crystal.orbits}
    paths = []
    for path_index in range(count):
        subset = unique[path_index % len(unique)]
        ordered = tuple(
            sorted(
                subset,
                key=lambda orbit_index: (
                    _seeded_int(
                        seed,
                        crystal.material_id,
                        path_index,
                        orbit_index,
                    ),
                    orbit_index,
                ),
            )
        )
        missing_sites = tuple(
            sorted(
                site_index
                for orbit_index in ordered
                for site_index in orbit_by_index[orbit_index].site_indices
            )
        )
        paths.append(
            SemanticPath(
                path_index=path_index,
                orbit_indices=ordered,
                missing_site_indices=missing_sites,
                unique_path_count=len(unique),
            )
        )
    return tuple(paths)


def _full_missing_orbits(
    crystal: CanonicalCrystal, missing_sites: Sequence[int]
) -> tuple[int, ...]:
    missing = set(missing_sites)
    return tuple(
        orbit.orbit_index
        for orbit in crystal.orbits
        if set(orbit.site_indices).issubset(missing)
    )


def _is_orbit_union(crystal: CanonicalCrystal, missing_sites: Sequence[int]) -> bool:
    missing = set(missing_sites)
    return all(
        not (missing & set(orbit.site_indices))
        or set(orbit.site_indices).issubset(missing)
        for orbit in crystal.orbits
    )


def _random_mask(site_count: int, missing_count: int, seed: int) -> tuple[int, ...]:
    return tuple(sorted(random.Random(seed).sample(range(site_count), missing_count)))


def matched_corruptions(
    crystal: CanonicalCrystal,
    semantic: Sequence[SemanticPath],
    *,
    count: int,
    min_fraction: float,
    max_fraction: float,
    seed: int,
) -> tuple[CorruptionExample, ...]:
    if len(semantic) < count:
        raise ValueError("semantic paths must provide at least count entries")
    _validate_fraction_band(min_fraction, max_fraction)
    min_sites = math.ceil(min_fraction * crystal.site_count - 1e-12)
    max_sites = math.floor(max_fraction * crystal.site_count + 1e-12)
    unique_path_count = semantic[0].unique_path_count
    examples = []

    for index in range(count):
        example_seed = _seeded_int(seed, crystal.material_id, CorruptionVariant.M0, index)
        rng = random.Random(example_seed)
        missing_count = rng.randint(min_sites, max_sites)
        missing = tuple(sorted(rng.sample(range(crystal.site_count), missing_count)))
        examples.append(
            CorruptionExample(
                parent_material_id=crystal.material_id,
                variant=CorruptionVariant.M0,
                path_index=index,
                example_seed=example_seed,
                missing_site_indices=missing,
                missing_orbit_indices=_full_missing_orbits(crystal, missing),
                site_count=crystal.site_count,
                is_semantic_union=_is_orbit_union(crystal, missing),
                unique_semantic_path_count=unique_path_count,
            )
        )

    for index in range(count):
        target = semantic[index]
        example_seed = _seeded_int(seed, crystal.material_id, CorruptionVariant.M1, index)
        missing = _random_mask(crystal.site_count, len(target.missing_site_indices), example_seed)
        examples.append(
            CorruptionExample(
                parent_material_id=crystal.material_id,
                variant=CorruptionVariant.M1,
                path_index=index,
                example_seed=example_seed,
                missing_site_indices=missing,
                missing_orbit_indices=_full_missing_orbits(crystal, missing),
                site_count=crystal.site_count,
                is_semantic_union=_is_orbit_union(crystal, missing),
                unique_semantic_path_count=unique_path_count,
            )
        )

    canonical = semantic[0]
    for index in range(count):
        example_seed = _seeded_int(seed, crystal.material_id, CorruptionVariant.M2, index)
        examples.append(
            CorruptionExample(
                parent_material_id=crystal.material_id,
                variant=CorruptionVariant.M2,
                path_index=index,
                example_seed=example_seed,
                missing_site_indices=canonical.missing_site_indices,
                missing_orbit_indices=canonical.orbit_indices,
                site_count=crystal.site_count,
                is_semantic_union=True,
                unique_semantic_path_count=unique_path_count,
            )
        )

    for index in range(count):
        target = semantic[index]
        example_seed = _seeded_int(seed, crystal.material_id, CorruptionVariant.M3, index)
        examples.append(
            CorruptionExample(
                parent_material_id=crystal.material_id,
                variant=CorruptionVariant.M3,
                path_index=index,
                example_seed=example_seed,
                missing_site_indices=target.missing_site_indices,
                missing_orbit_indices=target.orbit_indices,
                site_count=crystal.site_count,
                is_semantic_union=True,
                unique_semantic_path_count=unique_path_count,
            )
        )
    return tuple(examples)


def _orbit_id(material_id: str, orbit_index: int) -> str:
    return f"{material_id}:orbit:{orbit_index:03d}"


def _atom_id(material_id: str, site_index: int) -> str:
    return f"{material_id}:atom:{site_index:03d}"


def _build_edges(
    crystal: CanonicalCrystal, cutoff: float
) -> tuple[PeriodicEdge, ...]:
    centers, points, images, _ = crystal.structure.get_neighbor_list(
        r=cutoff,
        numerical_tol=1e-8,
        exclude_self=True,
    )
    relation_type = f"neighbor<={cutoff:.3f}A"
    unique: dict[tuple[str, str, tuple[int, int, int]], PeriodicEdge] = {}
    for center, point, image in zip(centers, points, images):
        source_id = _atom_id(crystal.material_id, int(center))
        target_id = _atom_id(crystal.material_id, int(point))
        key = canonical_periodic_edge_key(
            source_id,
            target_id,
            tuple(int(component) for component in image),
        )
        unique[key.as_tuple()] = PeriodicEdge(
            source_id=key.source_id,
            target_id=key.target_id,
            image=key.image,
            relation_type=relation_type,
        )
    return tuple(unique[key] for key in sorted(unique))


def build_full_state(
    crystal: CanonicalCrystal, prototype_family: str, cutoff: float
) -> AssemblyState:
    if not math.isfinite(cutoff) or cutoff <= 0:
        raise ValueError("cutoff must be finite and positive")
    material_id = crystal.material_id
    elements = tuple(
        sorted(element.symbol for element in crystal.structure.composition.elements)
    )
    counts = Counter(site.specie.symbol for site in crystal.structure)
    role_to_element = {orbit.role: orbit.element for orbit in crystal.orbits}
    role_slots = tuple(
        RoleSlot(
            stable_id=f"{material_id}:role:{role}",
            role=role,
            allowed_elements=(role_to_element[role],),
        )
        for role in sorted(role_to_element)
    )
    orbit_slots = tuple(
        OrbitSlot(
            stable_id=f"{material_id}:slot:{orbit.orbit_index:03d}",
            multiplicity=orbit.multiplicity,
            role_slot_id=f"{material_id}:role:{orbit.role}",
        )
        for orbit in crystal.orbits
    )
    embryo = MaterialEmbryo(
        embryo_id=f"{material_id}:embryo",
        task="fixed_lattice_partial_completion",
        composition_budget=tuple(
            ElementCount(element=element, count=counts[element]) for element in elements
        ),
        allowed_elements=elements,
        role_slots=role_slots,
        orbit_slots=orbit_slots,
        budget=AssemblyBudget(
            max_atoms=crystal.site_count,
            max_actions=len(crystal.orbits) + 1,
        ),
        space_group=crystal.space_group,
        prototype=prototype_family,
    )
    orbit_nodes = tuple(
        OrbitNode(
            stable_id=_orbit_id(material_id, orbit.orbit_index),
            slot_id=f"{material_id}:slot:{orbit.orbit_index:03d}",
            multiplicity=orbit.multiplicity,
            role=orbit.role,
            element=orbit.element,
            wyckoff_label=orbit.wyckoff_letter,
            status=NodeStatus.ACTIVE,
        )
        for orbit in crystal.orbits
    )
    orbit_by_site = {
        site_index: orbit.orbit_index
        for orbit in crystal.orbits
        for site_index in orbit.site_indices
    }
    atom_nodes = tuple(
        AtomNode(
            stable_id=_atom_id(material_id, site_index),
            orbit_id=_orbit_id(material_id, orbit_by_site[site_index]),
            element=site.specie.symbol,
            fractional_position=tuple(float(value) % 1.0 for value in site.frac_coords),
            status=NodeStatus.ACTIVE,
        )
        for site_index, site in enumerate(crystal.structure)
    )
    lattice = tuple(
        tuple(float(value) for value in row) for row in crystal.structure.lattice.matrix
    )
    state = AssemblyState(
        state_id=f"{material_id}:full",
        embryo=embryo,
        orbit_nodes=orbit_nodes,
        atom_nodes=atom_nodes,
        edges=_build_edges(crystal, cutoff),
        factors=(),
        lattice=lattice,
    )
    violations = ConstraintCompiler().check(state)
    if violations:
        raise DeconstructionError(f"full state violates constraints: {violations}")
    return state


def _atom_to_record(atom: AtomNode) -> dict[str, object]:
    return {
        "stable_id": atom.stable_id,
        "orbit_id": atom.orbit_id,
        "element": atom.element,
        "fractional_position": list(atom.fractional_position),
    }


def _edge_to_record(edge: PeriodicEdge) -> dict[str, object]:
    return {
        "source_id": edge.source_id,
        "target_id": edge.target_id,
        "image": list(edge.image),
        "relation_type": edge.relation_type,
        "active": edge.active,
    }


def _edge_identity(edge: PeriodicEdge) -> tuple[object, ...]:
    return edge.source_id, edge.target_id, edge.image, edge.relation_type


def _apply_oracle_action(state: AssemblyState, action: AssemblyAction) -> AssemblyState:
    if action.source_state_id != state.state_id:
        raise DeconstructionError("oracle action source does not match current state")
    next_state_id = action.parameter("next_state_id")
    if not isinstance(next_state_id, str) or not next_state_id:
        raise DeconstructionError("oracle action is missing next_state_id")

    if action.action_type is ActionType.STOP:
        violations = ConstraintCompiler().validate_action(state, action)
        if violations:
            raise DeconstructionError(f"oracle Stop is invalid: {violations}")
        return replace(
            state,
            state_id=next_state_id,
            parent_state_id=state.state_id,
            step_index=state.step_index + 1,
            action_history=(*state.action_history, action.action_id),
        )
    if action.action_type is not ActionType.ADD_ORBIT:
        raise DeconstructionError(
            f"unsupported oracle action type {action.action_type.value}"
        )

    orbit_id = action.parameter("orbit_id")
    atoms_json = action.parameter("atoms_json")
    edges_json = action.parameter("edges_json")
    if not all(isinstance(value, str) for value in (orbit_id, atoms_json, edges_json)):
        raise DeconstructionError("ADD_ORBIT oracle payload is incomplete")
    try:
        atom_records = json.loads(atoms_json)
        edge_records = json.loads(edges_json)
    except json.JSONDecodeError as exc:
        raise DeconstructionError("ADD_ORBIT oracle payload is invalid JSON") from exc
    if not isinstance(atom_records, list) or not isinstance(edge_records, list):
        raise DeconstructionError("ADD_ORBIT oracle payload must contain lists")

    restored_atoms = {
        record["stable_id"]: AtomNode(
            stable_id=record["stable_id"],
            orbit_id=record["orbit_id"],
            element=record["element"],
            fractional_position=tuple(record["fractional_position"]),
            status=NodeStatus.ACTIVE,
        )
        for record in atom_records
    }
    known_atom_ids = {atom.stable_id for atom in state.atom_nodes}
    if not set(restored_atoms).issubset(known_atom_ids):
        raise DeconstructionError("oracle payload references an unknown atom")
    atom_nodes = tuple(
        restored_atoms.get(atom.stable_id, atom) for atom in state.atom_nodes
    )
    orbit_found = False
    orbit_nodes = []
    for orbit in state.orbit_nodes:
        if orbit.stable_id == orbit_id:
            orbit = replace(orbit, status=NodeStatus.ACTIVE)
            orbit_found = True
        orbit_nodes.append(orbit)
    if not orbit_found:
        raise DeconstructionError("oracle payload references an unknown orbit")

    decoded_edges = tuple(
        PeriodicEdge(
            source_id=record["source_id"],
            target_id=record["target_id"],
            image=tuple(record["image"]),
            relation_type=record["relation_type"],
            active=record["active"],
        )
        for record in edge_records
    )
    edge_by_identity = {_edge_identity(edge): edge for edge in state.edges}
    edge_by_identity.update({_edge_identity(edge): edge for edge in decoded_edges})
    updated = replace(
        state,
        state_id=next_state_id,
        parent_state_id=state.state_id,
        step_index=state.step_index + 1,
        action_history=(*state.action_history, action.action_id),
        orbit_nodes=tuple(orbit_nodes),
        atom_nodes=atom_nodes,
        edges=tuple(edge_by_identity[key] for key in sorted(edge_by_identity)),
    )
    violations = ConstraintCompiler().check(updated)
    if violations:
        raise DeconstructionError(f"replayed oracle state is invalid: {violations}")
    return updated


def replay_oracle_actions(
    initial_state: AssemblyState, actions: Sequence[AssemblyAction]
) -> AssemblyState:
    state = initial_state
    for action in actions:
        state = _apply_oracle_action(state, action)
    return state


def build_oracle_trajectory(
    full_state: AssemblyState,
    crystal: CanonicalCrystal,
    path: SemanticPath,
    *,
    split: str,
    operator_version: str,
) -> Trajectory:
    if crystal.material_id not in full_state.state_id:
        raise ValueError("full state and crystal material IDs do not match")
    missing_site_ids = {
        _atom_id(crystal.material_id, site_index)
        for site_index in path.missing_site_indices
    }
    missing_orbit_ids = {
        _orbit_id(crystal.material_id, orbit_index)
        for orbit_index in path.orbit_indices
    }
    partial_atoms = tuple(
        replace(
            atom,
            fractional_position=(0.0, 0.0, 0.0),
            status=NodeStatus.MISSING,
        )
        if atom.stable_id in missing_site_ids
        else atom
        for atom in full_state.atom_nodes
    )
    partial_orbits = tuple(
        replace(orbit, status=NodeStatus.MISSING)
        if orbit.stable_id in missing_orbit_ids
        else orbit
        for orbit in full_state.orbit_nodes
    )
    partial_edges = tuple(
        edge
        for edge in full_state.edges
        if edge.source_id not in missing_site_ids and edge.target_id not in missing_site_ids
    )
    path_key = ",".join(map(str, path.orbit_indices))
    trajectory_digest = hashlib.sha256(
        f"{operator_version}:{crystal.material_id}:{path.path_index}:{path_key}".encode(
            "utf-8"
        )
    ).hexdigest()[:16]
    trajectory_id = f"{crystal.material_id}:trajectory:{trajectory_digest}"
    initial = replace(
        full_state,
        state_id=f"{trajectory_id}:state:000",
        orbit_nodes=partial_orbits,
        atom_nodes=partial_atoms,
        edges=partial_edges,
        step_index=0,
        parent_state_id=None,
        action_history=(),
    )

    full_orbits = {orbit.stable_id: orbit for orbit in full_state.orbit_nodes}
    current = initial
    steps = []
    for step_number, orbit_index in enumerate(reversed(path.orbit_indices), start=1):
        orbit_id = _orbit_id(crystal.material_id, orbit_index)
        if orbit_id not in full_orbits:
            raise DeconstructionError(f"path references unknown orbit {orbit_index}")
        restored = tuple(
            atom for atom in full_state.atom_nodes if atom.orbit_id == orbit_id
        )
        active_after = {
            atom.stable_id
            for atom in current.atom_nodes
            if atom.status is not NodeStatus.MISSING
        } | {atom.stable_id for atom in restored}
        present_edges = {_edge_identity(edge) for edge in current.edges}
        activated_edges = tuple(
            edge
            for edge in full_state.edges
            if edge.source_id in active_after
            and edge.target_id in active_after
            and _edge_identity(edge) not in present_edges
        )
        action = AssemblyAction(
            action_id=f"{trajectory_id}:action:{step_number:03d}",
            source_state_id=current.state_id,
            action_type=ActionType.ADD_ORBIT,
            targets=(orbit_id, *(atom.stable_id for atom in restored)),
            parameters=(
                ("orbit_id", orbit_id),
                ("atoms_json", canonical_payload_json([_atom_to_record(atom) for atom in restored])),
                ("edges_json", canonical_payload_json([_edge_to_record(edge) for edge in activated_edges])),
                ("next_state_id", f"{trajectory_id}:state:{step_number:03d}"),
            ),
            preconditions=("fixed_lattice", "composition_budget"),
        )
        current = _apply_oracle_action(current, action)
        steps.append(TrajectoryStep(action=action, state=current))

    stop_number = len(steps) + 1
    stop = AssemblyAction(
        action_id=f"{trajectory_id}:action:{stop_number:03d}",
        source_state_id=current.state_id,
        action_type=ActionType.STOP,
        parameters=(("next_state_id", f"{trajectory_id}:state:{stop_number:03d}"),),
        preconditions=("exact_composition",),
    )
    current = _apply_oracle_action(current, stop)
    steps.append(TrajectoryStep(action=stop, state=current))
    if state_content_hash(current) != state_content_hash(full_state):
        raise DeconstructionError("oracle replay did not recover full state content")
    return Trajectory(
        trajectory_id=trajectory_id,
        parent_structure_id=crystal.material_id,
        split=split,
        operator_version=operator_version,
        seed=_seeded_int(
            operator_version, crystal.material_id, path.path_index, path_key
        ),
        initial_state=initial,
        steps=tuple(steps),
    )


def state_to_structure(state: AssemblyState) -> Structure:
    atoms = sorted(
        (
            atom
            for atom in state.atom_nodes
            if atom.status is not NodeStatus.MISSING
        ),
        key=lambda atom: atom.stable_id,
    )
    return Structure(
        state.lattice,
        [atom.element for atom in atoms],
        [atom.fractional_position for atom in atoms],
        coords_are_cartesian=False,
        to_unit_cell=True,
    )


def state_content_hash(state: AssemblyState) -> str:
    content = dict(state_to_payload(state)["data"])
    for key in ("state_id", "step_index", "parent_state_id", "action_history"):
        content.pop(key)
    return payload_hash(content)
