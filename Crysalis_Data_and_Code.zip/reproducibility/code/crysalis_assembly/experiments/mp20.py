from __future__ import annotations

import ast
import csv
import hashlib
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path


SOURCE_SPLITS = ("train", "val", "test")
REQUIRED_COLUMNS = ("material_id", "pretty_formula", "elements", "cif")


class MP20SourceError(ValueError):
    """Raised when the frozen MP-20 source contract is not satisfied."""


@dataclass(frozen=True, slots=True)
class MP20Record:
    material_id: str
    pretty_formula: str
    elements: tuple[str, ...]
    cif: str
    source_split: str
    source_row: int


@dataclass(frozen=True, slots=True)
class MP20SourceManifest:
    root: str
    total_records: int
    rows_by_split: tuple[tuple[str, int], ...]
    sha256_by_file: tuple[tuple[str, str], ...]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest().upper()


def _parse_elements(raw: str, *, material_id: str) -> tuple[str, ...]:
    try:
        value = ast.literal_eval(raw)
    except (SyntaxError, ValueError) as exc:
        raise MP20SourceError(
            f"invalid elements for {material_id}: expected a Python string list"
        ) from exc
    if not isinstance(value, (list, tuple)) or not value:
        raise MP20SourceError(f"invalid elements for {material_id}: expected a list")
    if any(not isinstance(item, str) or not item.strip() for item in value):
        raise MP20SourceError(f"invalid elements for {material_id}: blank element")
    return tuple(sorted(set(value)))


def load_mp20_records(
    root: Path,
    expected_hashes: Mapping[str, str],
    strict_hashes: bool = True,
) -> tuple[tuple[MP20Record, ...], MP20SourceManifest]:
    root = Path(root)
    records: list[MP20Record] = []
    seen_ids: set[str] = set()
    rows_by_split: dict[str, int] = {}
    hashes: dict[str, str] = {}

    for split in SOURCE_SPLITS:
        filename = f"{split}.csv"
        path = root / filename
        if not path.is_file():
            raise MP20SourceError(f"missing MP-20 source file {filename}")

        observed_hash = _sha256(path)
        hashes[filename] = observed_hash
        if strict_hashes:
            expected = expected_hashes.get(filename)
            if expected is None:
                raise MP20SourceError(f"missing expected SHA-256 for {filename}")
            if observed_hash != expected.upper():
                raise MP20SourceError(
                    f"SHA-256 mismatch for {filename}: "
                    f"expected {expected.upper()}, observed {observed_hash}"
                )

        row_count = 0
        with path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            fieldnames = set(reader.fieldnames or ())
            missing = sorted(set(REQUIRED_COLUMNS) - fieldnames)
            if missing:
                raise MP20SourceError(
                    f"{filename} is missing required columns: {', '.join(missing)}"
                )
            for source_row, row in enumerate(reader):
                material_id = (row.get("material_id") or "").strip()
                if not material_id:
                    raise MP20SourceError(
                        f"blank material_id in {filename} row {source_row}"
                    )
                if material_id in seen_ids:
                    raise MP20SourceError(f"duplicate material_id {material_id}")
                seen_ids.add(material_id)
                records.append(
                    MP20Record(
                        material_id=material_id,
                        pretty_formula=(row.get("pretty_formula") or "").strip(),
                        elements=_parse_elements(
                            row.get("elements") or "", material_id=material_id
                        ),
                        cif=row.get("cif") or "",
                        source_split=split,
                        source_row=source_row,
                    )
                )
                row_count += 1
        rows_by_split[split] = row_count

    manifest = MP20SourceManifest(
        root=str(root.resolve()),
        total_records=len(records),
        rows_by_split=tuple(sorted(rows_by_split.items())),
        sha256_by_file=tuple(sorted(hashes.items())),
    )
    return tuple(records), manifest


def select_debug_records(
    records: Sequence[MP20Record], limit: int, seed: int
) -> tuple[MP20Record, ...]:
    if type(limit) is not int or limit <= 0:
        raise ValueError("limit must be positive")
    if type(seed) is not int or seed < 0:
        raise ValueError("seed must be a non-negative integer")

    def rank(record: MP20Record) -> tuple[str, str]:
        key = f"{seed}:{record.material_id}".encode("utf-8")
        return hashlib.sha256(key).hexdigest(), record.material_id

    return tuple(sorted(records, key=rank)[:limit])
