from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping, Sequence
from typing import Any

from .schemas import (
    SCHEMA_VERSION,
    ActionType,
    AssemblyAction,
    AssemblyBudget,
    AssemblyState,
    AtomNode,
    ConstraintLevel,
    ElementCount,
    LedgerEntry,
    MaterialEmbryo,
    MotifFactor,
    NodeStatus,
    OrbitNode,
    OrbitSlot,
    PeriodicEdge,
    RoleSlot,
    Trajectory,
    TrajectoryStep,
)


def canonical_payload_json(payload: object) -> str:
    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    )


def payload_hash(payload: object) -> str:
    encoded = canonical_payload_json(payload).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _mapping(value: object, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{name} must be a mapping")
    return value


def _sequence(value: object, name: str) -> Sequence[Any]:
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise ValueError(f"{name} must be a sequence")
    return value


def _envelope_data(
    payload: Mapping[str, object], expected_record_type: str
) -> Mapping[str, Any]:
    schema_version = payload.get("schema_version")
    if schema_version != SCHEMA_VERSION:
        raise ValueError(f"unsupported schema_version {schema_version}")
    record_type = payload.get("record_type")
    if record_type != expected_record_type:
        raise ValueError(
            f"expected record_type {expected_record_type}, received {record_type}"
        )
    return _mapping(payload.get("data"), "payload data")


def _element_count_to_data(value: ElementCount) -> dict[str, object]:
    return {"element": value.element, "count": value.count}


def _element_count_from_data(value: object) -> ElementCount:
    data = _mapping(value, "element count")
    return ElementCount(element=data["element"], count=data["count"])


def _budget_to_data(value: AssemblyBudget) -> dict[str, object]:
    return {
        "max_atoms": value.max_atoms,
        "max_actions": value.max_actions,
        "max_volume": value.max_volume,
    }


def _budget_from_data(value: object) -> AssemblyBudget:
    data = _mapping(value, "assembly budget")
    return AssemblyBudget(
        max_atoms=data["max_atoms"],
        max_actions=data["max_actions"],
        max_volume=data.get("max_volume"),
    )


def _role_slot_to_data(value: RoleSlot) -> dict[str, object]:
    return {
        "stable_id": value.stable_id,
        "role": value.role,
        "allowed_elements": list(value.allowed_elements),
    }


def _role_slot_from_data(value: object) -> RoleSlot:
    data = _mapping(value, "role slot")
    return RoleSlot(
        stable_id=data["stable_id"],
        role=data["role"],
        allowed_elements=tuple(
            _sequence(data["allowed_elements"], "role slot allowed_elements")
        ),
    )


def _orbit_slot_to_data(value: OrbitSlot) -> dict[str, object]:
    return {
        "stable_id": value.stable_id,
        "multiplicity": value.multiplicity,
        "role_slot_id": value.role_slot_id,
    }


def _orbit_slot_from_data(value: object) -> OrbitSlot:
    data = _mapping(value, "orbit slot")
    return OrbitSlot(
        stable_id=data["stable_id"],
        multiplicity=data["multiplicity"],
        role_slot_id=data["role_slot_id"],
    )


def _embryo_to_data(value: MaterialEmbryo) -> dict[str, object]:
    return {
        "embryo_id": value.embryo_id,
        "task": value.task,
        "composition_budget": [
            _element_count_to_data(item) for item in value.composition_budget
        ],
        "allowed_elements": list(value.allowed_elements),
        "role_slots": [_role_slot_to_data(item) for item in value.role_slots],
        "orbit_slots": [_orbit_slot_to_data(item) for item in value.orbit_slots],
        "budget": _budget_to_data(value.budget),
        "space_group": value.space_group,
        "prototype": value.prototype,
    }


def _embryo_from_data(value: object) -> MaterialEmbryo:
    data = _mapping(value, "material embryo")
    return MaterialEmbryo(
        embryo_id=data["embryo_id"],
        task=data["task"],
        composition_budget=tuple(
            _element_count_from_data(item)
            for item in _sequence(data["composition_budget"], "composition_budget")
        ),
        allowed_elements=tuple(
            _sequence(data["allowed_elements"], "allowed_elements")
        ),
        role_slots=tuple(
            _role_slot_from_data(item)
            for item in _sequence(data["role_slots"], "role_slots")
        ),
        orbit_slots=tuple(
            _orbit_slot_from_data(item)
            for item in _sequence(data["orbit_slots"], "orbit_slots")
        ),
        budget=_budget_from_data(data["budget"]),
        space_group=data.get("space_group"),
        prototype=data.get("prototype"),
    )


def _orbit_node_to_data(value: OrbitNode) -> dict[str, object]:
    return {
        "stable_id": value.stable_id,
        "slot_id": value.slot_id,
        "multiplicity": value.multiplicity,
        "role": value.role,
        "element": value.element,
        "wyckoff_label": value.wyckoff_label,
        "occupancy": value.occupancy,
        "status": value.status.value,
    }


def _orbit_node_from_data(value: object) -> OrbitNode:
    data = _mapping(value, "orbit node")
    return OrbitNode(
        stable_id=data["stable_id"],
        slot_id=data["slot_id"],
        multiplicity=data["multiplicity"],
        role=data["role"],
        element=data.get("element"),
        wyckoff_label=data.get("wyckoff_label"),
        occupancy=data["occupancy"],
        status=NodeStatus(data["status"]),
    )


def _atom_node_to_data(value: AtomNode) -> dict[str, object]:
    return {
        "stable_id": value.stable_id,
        "orbit_id": value.orbit_id,
        "element": value.element,
        "fractional_position": list(value.fractional_position),
        "status": value.status.value,
    }


def _atom_node_from_data(value: object) -> AtomNode:
    data = _mapping(value, "atom node")
    position = tuple(
        _sequence(data["fractional_position"], "fractional_position")
    )
    return AtomNode(
        stable_id=data["stable_id"],
        orbit_id=data["orbit_id"],
        element=data["element"],
        fractional_position=position,
        status=NodeStatus(data["status"]),
    )


def _edge_to_data(value: PeriodicEdge) -> dict[str, object]:
    return {
        "source_id": value.source_id,
        "target_id": value.target_id,
        "image": list(value.image),
        "relation_type": value.relation_type,
        "active": value.active,
    }


def _edge_from_data(value: object) -> PeriodicEdge:
    data = _mapping(value, "periodic edge")
    return PeriodicEdge(
        source_id=data["source_id"],
        target_id=data["target_id"],
        image=tuple(_sequence(data["image"], "periodic image")),
        relation_type=data["relation_type"],
        active=data["active"],
    )


def _factor_to_data(value: MotifFactor) -> dict[str, object]:
    return {
        "stable_id": value.stable_id,
        "motif_type": value.motif_type,
        "member_ids": list(value.member_ids),
        "uncertainty": value.uncertainty,
    }


def _factor_from_data(value: object) -> MotifFactor:
    data = _mapping(value, "motif factor")
    return MotifFactor(
        stable_id=data["stable_id"],
        motif_type=data["motif_type"],
        member_ids=tuple(_sequence(data["member_ids"], "motif member_ids")),
        uncertainty=data["uncertainty"],
    )


def _ledger_to_data(value: LedgerEntry) -> dict[str, object]:
    return {
        "constraint_id": value.constraint_id,
        "level": value.level.value,
        "satisfied": value.satisfied,
        "detail": value.detail,
        "assumption_branch": value.assumption_branch,
    }


def _ledger_from_data(value: object) -> LedgerEntry:
    data = _mapping(value, "ledger entry")
    return LedgerEntry(
        constraint_id=data["constraint_id"],
        level=ConstraintLevel(data["level"]),
        satisfied=data["satisfied"],
        detail=data["detail"],
        assumption_branch=data.get("assumption_branch"),
    )


def _state_to_data(state: AssemblyState) -> dict[str, object]:
    return {
        "state_id": state.state_id,
        "embryo": _embryo_to_data(state.embryo),
        "orbit_nodes": [_orbit_node_to_data(item) for item in state.orbit_nodes],
        "atom_nodes": [_atom_node_to_data(item) for item in state.atom_nodes],
        "edges": [_edge_to_data(item) for item in state.edges],
        "factors": [_factor_to_data(item) for item in state.factors],
        "lattice": [list(row) for row in state.lattice],
        "ledger": [_ledger_to_data(item) for item in state.ledger],
        "step_index": state.step_index,
        "parent_state_id": state.parent_state_id,
        "action_history": list(state.action_history),
        "energy_eligible": state.energy_eligible,
        "uncertainty": [
            {"name": name, "value": value} for name, value in state.uncertainty
        ],
    }


def _state_from_data(value: object) -> AssemblyState:
    data = _mapping(value, "assembly state")
    lattice = tuple(
        tuple(_sequence(row, "lattice row"))
        for row in _sequence(data["lattice"], "lattice")
    )
    uncertainty = []
    for item in _sequence(data["uncertainty"], "uncertainty"):
        record = _mapping(item, "uncertainty record")
        uncertainty.append((record["name"], record["value"]))
    return AssemblyState(
        state_id=data["state_id"],
        embryo=_embryo_from_data(data["embryo"]),
        orbit_nodes=tuple(
            _orbit_node_from_data(item)
            for item in _sequence(data["orbit_nodes"], "orbit_nodes")
        ),
        atom_nodes=tuple(
            _atom_node_from_data(item)
            for item in _sequence(data["atom_nodes"], "atom_nodes")
        ),
        edges=tuple(
            _edge_from_data(item)
            for item in _sequence(data["edges"], "edges")
        ),
        factors=tuple(
            _factor_from_data(item)
            for item in _sequence(data["factors"], "factors")
        ),
        lattice=lattice,
        ledger=tuple(
            _ledger_from_data(item)
            for item in _sequence(data["ledger"], "ledger")
        ),
        step_index=data["step_index"],
        parent_state_id=data.get("parent_state_id"),
        action_history=tuple(
            _sequence(data["action_history"], "action_history")
        ),
        energy_eligible=data["energy_eligible"],
        uncertainty=tuple(uncertainty),
    )


def _action_to_data(action: AssemblyAction) -> dict[str, object]:
    return {
        "action_id": action.action_id,
        "source_state_id": action.source_state_id,
        "action_type": action.action_type.value,
        "targets": list(action.targets),
        "parameters": [
            {"name": name, "value": value} for name, value in action.parameters
        ],
        "preconditions": list(action.preconditions),
    }


def _action_from_data(value: object) -> AssemblyAction:
    data = _mapping(value, "assembly action")
    parameters = []
    for item in _sequence(data["parameters"], "action parameters"):
        record = _mapping(item, "action parameter")
        parameters.append((record["name"], record["value"]))
    return AssemblyAction(
        action_id=data["action_id"],
        source_state_id=data["source_state_id"],
        action_type=ActionType(data["action_type"]),
        targets=tuple(_sequence(data["targets"], "action targets")),
        parameters=tuple(parameters),
        preconditions=tuple(
            _sequence(data["preconditions"], "action preconditions")
        ),
    )


def state_to_payload(state: AssemblyState) -> dict[str, object]:
    return {
        "schema_version": SCHEMA_VERSION,
        "record_type": "assembly_state",
        "data": _state_to_data(state),
    }


def state_from_payload(payload: Mapping[str, object]) -> AssemblyState:
    return _state_from_data(_envelope_data(payload, "assembly_state"))


def trajectory_to_payload(trajectory: Trajectory) -> dict[str, object]:
    return {
        "schema_version": SCHEMA_VERSION,
        "record_type": "trajectory",
        "data": {
            "trajectory_id": trajectory.trajectory_id,
            "parent_structure_id": trajectory.parent_structure_id,
            "split": trajectory.split,
            "operator_version": trajectory.operator_version,
            "seed": trajectory.seed,
            "initial_state": _state_to_data(trajectory.initial_state),
            "steps": [
                {
                    "action": _action_to_data(step.action),
                    "state": _state_to_data(step.state),
                }
                for step in trajectory.steps
            ],
        },
    }


def trajectory_from_payload(payload: Mapping[str, object]) -> Trajectory:
    data = _envelope_data(payload, "trajectory")
    steps = []
    for item in _sequence(data["steps"], "trajectory steps"):
        record = _mapping(item, "trajectory step")
        steps.append(
            TrajectoryStep(
                action=_action_from_data(record["action"]),
                state=_state_from_data(record["state"]),
            )
        )
    return Trajectory(
        trajectory_id=data["trajectory_id"],
        parent_structure_id=data["parent_structure_id"],
        split=data["split"],
        operator_version=data["operator_version"],
        seed=data["seed"],
        initial_state=_state_from_data(data["initial_state"]),
        steps=tuple(steps),
    )
