# Crysalis: residual Wyckoff coordinates and framework information

Data and code accompanying “Residual Wyckoff Coordinate Freedom and Framework Information in Crystal Assembly”, by Jinxuan Liu, Xu Yan, Xurui Zhang and Hang Zeng.

## Contents

- source_data/: candidate force labels, selected candidates, independent-potential comparisons, assembly and relaxation observations, and 36 DFT coordinate/input sets. Its README describes units, keys and exclusions.
- reproducibility/: implementation, model inputs, frozen models, parent partitions and training records. Its README describes software environments and external model requirements.
- supplemental_experiments/: descriptor controls, trained weights and predictions, contact-filter analyses, chemical strata, paired energy analyses, and scripts.
- figure_sources/: the plotting scripts’ final PDF/SVG/PNG outputs used in the manuscript and Supporting Information.

## Main-paper results

| Manuscript item | Data |
|---|---|
| Figure 1; residual force variation | supplemental_experiments/reframing/event_spread.csv; supplemental_experiments/jcim/filtered_event_spread.csv; supplemental_experiments/jcim/filter_summary.csv |
| Figure 2; descriptor comparisons | supplemental_experiments/reframing/ranking_summary.csv; supplemental_experiments/jcim/descriptor_seeds.csv; supplemental_experiments/jcim/descriptor_summary.csv; supplemental_experiments/subsets_torch/ |
| Figure 3; contact, stage and chemistry groups | supplemental_experiments/reframing/contact_strata.csv; supplemental_experiments/reframing/independent_contact_pairs.csv; supplemental_experiments/jcim/ |
| Figure 4; terminal outcomes | supplemental_experiments/reframing/threshold_spectrum.csv; supplemental_experiments/jcim/energy_pairs.csv |
| Tables 1–2 | supplemental_experiments/reframing/ranking_summary.csv; supplemental_experiments/reframing/threshold_spectrum.csv |
| Direct contact-stratum contrast | supplemental_experiments/reproduce_contact_contrast.py; supplemental_experiments/reframing/ |

Tables S1–S28 and Figures S1–S10 are in the separate Supporting Information PDF. The subdirectory README files provide detailed file maps; figure numbering in earlier analysis-script descriptions refers to those scripts’ own output filenames. The table above maps the current main-paper figures.

## Use

Unzip all directories together to preserve relative paths. Numerical CSV and JSON files can be read without training models. Scripts under supplemental_experiments/ locate inputs relative to this extracted directory. Statistical analysis and plotting scripts can replace their derived output files, so run them on a working copy. Training scripts reject an existing output directory; choose a new output location as documented in each script.

The model and evaluation runtimes are documented in reproducibility/README.md, reproducibility/requirements_scorer_environment.txt and SI Section S9. Original experiment runners may require machine-specific paths and external model weights to be configured. VASP and licensed PAW potential contents are not included; POTCAR.spec identifies the required potentials. The CIF files are computational coordinate exports, not diffraction measurements.

The public archive at https://github.com/Leoluis0705/Crysalis-CGD-Reproducibility/releases/tag/cgd-recovery-20261028 provides the earlier code and data release. This accompanying archive also includes the descriptor-subset, contact-filter and paired-energy analyses used in the present manuscript.
