"""Five paired seeds, fixed original folds and optimization settings; no new labels."""
from pathlib import Path
import sys, csv, json, time, hashlib
import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'reproducibility/code'))
from crysalis_g1.experiments.context_conditional_landscape import build_matched_feature_matrices, deterministic_parent_folds
from crysalis_g1.experiments.full_orbit_operator import fit_fold_model, event_ranking_metrics, trainable_parameter_count
from scripts.run_context_conditional_wyckoff_atlas import _normalized_predict

OUT = Path(__file__).resolve().parent/'subsets_torch'
OUT.mkdir(exist_ok=False)
torch.set_num_threads(1)
protocol = json.loads((OUT.parent/'protocol.json').read_text(encoding='utf-8'))

def read(name):
    with (ROOT/'reproducibility/inputs'/name).open(encoding='utf-8',newline='') as f:
        return [r for r in csv.DictReader(f) if r['chgnet_status']=='EVALUATED']

dev, ext = read('atlas_candidates.csv'), read('external_candidates.csv')
folds = deterministic_parent_folds([r['parent_id'] for r in dev])
fold_array = np.array([folds[r['parent_id']] for r in dev])
assert len(set(r['parent_id'] for r in dev)&set(r['parent_id'] for r in ext))==0
target = np.log1p([float(r['initial_max_force_ev_per_angstrom']) for r in dev])

def matrices(rows):
    orbit, context = build_matched_feature_matrices(rows)
    return {'ORBIT':orbit, 'PROGRESS47':context[:,list(range(46))+[57]], 'DISTANCE48':context[:,:48], 'RESIDUAL49':context[:,list(range(46))+[54,55,56]], 'GEOMETRY57':context[:,:57], 'CONTEXT':context}


xs, es = matrices(dev), matrices(ext)
groups={}
for cohort, rows in [('development',dev),('additional',ext)]:
    group={}
    for i,r in enumerate(rows): group.setdefault(r['event_id'],[]).append(i)
    groups[cohort]={k:np.array(sorted(v,key=lambda i:int(rows[i]['candidate_index']))) for k,v in group.items()}
event_rows=[]; summaries=[]; fits=[]

def evaluate(rows,pred,cohort,arm,seed):
    selected=[]
    for event_id,ii in groups[cohort].items():
        force=np.array([float(rows[i]['initial_max_force_ev_per_angstrom']) for i in ii])
        m=event_ranking_metrics(force=force,prediction=pred[ii])
        row=dict(cohort=cohort,arm=arm,seed=seed,event_id=event_id,parent_id=rows[ii[0]]['parent_id'],stage=rows[ii[0]]['stage'],ndcg5=float(m['ndcg5']),force=float(m['top1_force']),selected_candidate_id=rows[ii[int(m['top1_index'])]]['candidate_id'])
        selected.append(row);event_rows.append(row)
    for stage in ['ALL','EARLY','MID','LATE','TERMINAL']:
        rr=[r for r in selected if stage=='ALL' or r['stage']==stage]
        summaries.append(dict(cohort=cohort,arm=arm,seed=seed,stage=stage,events=len(rr),mean_ndcg5=float(np.mean([r['ndcg5'] for r in rr])),median_force=float(np.median([r['force'] for r in rr])),mean_log_force=float(np.mean(np.log1p([r['force'] for r in rr])))))

start=time.monotonic()
for seed in protocol['seeds']:
    for arm,x in xs.items():
        oof=np.full(len(dev),np.nan)
        for fold in range(5):
            tr=np.ones(len(dev),bool) if fold==4 else fold_array!=fold
            te=np.arange(len(dev)) if fold==4 else np.flatnonzero(~tr)
            fit_seed=seed+1000*fold
            fitted=fit_fold_model(x_train=x[tr],y_train=target[tr],x_test=x[te],device='cpu',seed=fit_seed,updates=300,deadline=None)
            fits.append(dict(seed=seed,fit_seed=fit_seed,arm=arm,fold=fold if fold<4 else 'full',parameters=trainable_parameter_count(fitted['model']),loss=fitted['final_training_loss']))
            torch.save({'state_dict':fitted['model'].state_dict(),'normalization':fitted['normalization'],'input_n':x.shape[1],'hidden_n':128,'arm':arm,'seed':fit_seed},OUT/f'{arm}_{seed}_{fold}.pt')
            if fold<4:oof[te]=fitted['prediction']
            else:external=_normalized_predict(fitted['model'],es[arm],fitted['normalization'],device='cpu')
        assert np.isfinite(oof).all() and np.isfinite(external).all()
        np.savez_compressed(OUT/f'{arm}_{seed}_predictions.npz',development=oof,additional=external)
        evaluate(dev,oof,'development',arm,seed)
        evaluate(ext,external,'additional',arm,seed)
        print(f'{seed} {arm} complete; {time.monotonic()-start:.1f}s',flush=True)

def write(name,rows):
    with (OUT/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
write('event_metrics.csv',event_rows);write('seed_metrics.csv',summaries);write('fits.csv',fits)
with (OUT/'candidate_order.json').open('w') as f:json.dump({c:[r['candidate_id'] for r in rr] for c,rr in [('development',dev),('additional',ext)]},f)
aggregate=[]
for cohort in ['development','additional']:
    for arm in xs:
        rr=[r for r in summaries if r['cohort']==cohort and r['arm']==arm and r['stage']=='ALL']
        row={'cohort':cohort,'arm':arm,'seeds':len(rr)}
        for key in ['mean_ndcg5','median_force','mean_log_force']:
            vals=[r[key] for r in rr];row[key]={'mean':float(np.mean(vals)),'min':min(vals),'max':max(vals),'sd':float(np.std(vals,ddof=1))}
        aggregate.append(row)
(OUT/'summary.json').write_text(json.dumps({'scope':'New independent fits using frozen physical labels','fit_n':len(fits),'elapsed_seconds':time.monotonic()-start,'aggregate':aggregate,'input_sha256':{n:hashlib.sha256((ROOT/'reproducibility/inputs'/n).read_bytes()).hexdigest() for n in ['atlas_candidates.csv','external_candidates.csv']}},indent=2))
print(json.dumps(aggregate,indent=2),flush=True)
