"""Publication figures from saved numerical tables; vector text and geometry."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

R=Path(__file__).resolve().parents[1];D=R/'supplemental_experiments/jcim';P=R/'supplemental_experiments/reframing';O=R/'figures';O.mkdir(parents=True,exist_ok=True)
BLUE='#465B88';CORAL='#DB5243';TEAL='#309D88';PURPLE='#9B66A5';GRAY='#9B9D98'
plt.rcParams.update({'font.family':'Arial','font.size':8,'axes.labelsize':8,'axes.titlesize':8.5,'axes.linewidth':.65,'xtick.major.width':.6,'ytick.major.width':.6,'xtick.labelsize':7,'ytick.labelsize':7,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'savefig.facecolor':'white'})
def save(fig,name):
    for ext in ['pdf','svg','png']:fig.savefig(O/f'{name}.{ext}',dpi=600)
    plt.close(fig)
def panel(ax,letter,title):
    ax.set_title(title,loc='left',pad=12)
    ax.text(-.16,1.09,letter,transform=ax.transAxes,fontweight='bold',fontsize=11)
    ax.tick_params(direction='out',length=3)
def ecdf(ax,v,color,label,ls='-'):
    v=np.sort(v);ax.plot(v,np.arange(1,len(v)+1)/len(v),color=color,label=label,lw=1.5,ls=ls)
def forest(ax,df,groups,labelmap,cohorts=True):
    for co,color,dy,marker in [('development',TEAL,-.13,'o'),('additional',PURPLE,.13,'s')]:
        z=df[df.cohort==co].set_index('group')
        for i,g in enumerate(groups):
            row=z.loc[str(g)]
            ax.errorbar(row['mean'],i+dy,xerr=[[row['mean']-row.lo],[row.hi-row['mean']]],fmt=marker,color=color,ms=4,capsize=2,lw=1)
    ax.axvline(0,c='.65',lw=.7,ls=(0,(3,3)))
    ax.set_yticks(range(len(groups)),[labelmap.get(str(g),str(g)) for g in groups]);ax.invert_yaxis()
    ax.set_xlabel(r'Mean paired $\Delta\ln(1+F/F_0)$')
cohandles=[Line2D([],[],color=TEAL,marker='o',ls='',label='Development'),Line2D([],[],color=PURPLE,marker='s',ls='',label='Additional parents')]

e=pd.read_csv(P/'event_spread.csv');f=pd.read_csv(D/'filtered_event_spread.csv')
N_TEAL='#33B5A5';N_VIOLET='#7C6CCF';N_INK='#272727';N_GREY='#8C8C8C'
def npanel(ax,letter,title='',x=-.155):
    ax.text(x,1.045,letter,transform=ax.transAxes,fontsize=9,fontweight='bold',
            ha='left',va='bottom',color=N_INK)
    if title:ax.set_title(title,loc='left',pad=7,fontsize=7.2,color='#5A5A5A')
fig=plt.figure(figsize=(7.0,4.05))
gs=fig.add_gridspec(2,3,width_ratios=[1,1,1],height_ratios=[1.45,1.0],
                    left=.075,right=.985,bottom=.115,top=.925,wspace=.42,hspace=.72)
ax=fig.add_subplot(gs[0,:]);npanel(ax,'a','Residual spread',x=-.055)
ax.axvline(.5,color='#9A9A9A',lw=.65,ls=(0,(2.5,2.5)),zorder=1)
ax.text(.508,1.0,'0.50',fontsize=5.6,color='#9A9A9A',va='top',ha='left')
for co,col in [('development',N_TEAL),('additional',N_VIOLET)]:
    for flt,ls,lw,al in [('All',(0,(3,2)),.9,.85),('Residual = 0','-',1.7,1)]:
        v=np.sort(f[(f.cohort==co)&(f['filter']==flt)].iqr.dropna().values)
        ax.plot(v,np.arange(1,len(v)+1)/len(v),color=col,lw=lw,ls=ls,alpha=al,
                zorder=3 if lw>1 else 2)
ax.text(.012,.93,'97.3% development and 97.2% additional\nretain IQR $\\geq$ 0.50 after filtering',
        transform=ax.transAxes,fontsize=6.4,color=N_GREY,va='top',ha='left',linespacing=1.45)
ax.set_xlim(0,2.2);ax.set_ylim(0,1.02)
ax.set_xlabel(r'Within-event IQR of $\ln(1+F/F_0)$');ax.set_ylabel('Fraction of events')
ax.legend(handles=[Line2D([],[],color=N_TEAL,lw=1.6,label='Development'),
                   Line2D([],[],color=N_VIOLET,lw=1.6,label='Additional parents'),
                   Line2D([],[],color=N_GREY,lw=1.0,ls=(0,(3,2)),label='all candidates'),
                   Line2D([],[],color=N_GREY,lw=1.6,label='zero residual')],
          frameon=False,fontsize=6.3,loc='lower right',handlelength=1.7,
          labelspacing=.28,borderpad=.05,borderaxespad=.7)
ax=fig.add_subplot(gs[1,0]);npanel(ax,'b','Force span')
for co,col,ty in [('Development',N_TEAL,.62),('Additional parents',N_VIOLET,.36)]:
    z=np.sort(e[e.cohort==co].span_ratio.values);m=np.median(z)
    ax.plot(z,np.arange(1,len(z)+1)/len(z),color=col,lw=1.4)
    ax.plot([m],[.5],'o',color='white',ms=3.8,mec=col,mew=1.2,zorder=3)
    ax.annotate(f'{m:.0f}$\\times$',xy=(m,.5),xytext=(m*7,ty),color=col,fontsize=6.4,
                va='center',arrowprops=dict(arrowstyle='-',color=col,lw=.5,shrinkA=0,shrinkB=3))
ax.set_xscale('log');ax.set_xlim(10,3e6);ax.set_ylim(0,1.02)
ax.set_xlabel('Max / min force');ax.set_ylabel('Fraction of events')
ax=fig.add_subplot(gs[1,1]);npanel(ax,'c','Free coordinates')
for i,dim in [(0,3),(1,2),(2,1)]:
    for co,col,dy in [('Development',N_TEAL,-.14),('Additional parents',N_VIOLET,.14)]:
        q=e[(e.cohort==co)&(e.d==dim)].iqr_log1p.quantile([.25,.5,.75]).to_numpy()
        ax.plot([q[0],q[2]],[i+dy]*2,color=col,lw=2.4,solid_capstyle='round',alpha=.8)
        ax.plot([q[1]],[i+dy],'o',color='white',ms=3.8,mec=col,mew=1.2,zorder=3)
ax.set_yticks([0,1,2],['d = 3\nn = 14','d = 2\nn = 179','d = 1\nn = 899'])
ax.set_ylim(2.6,-.6);ax.set_xlim(0.95,1.95)
ax.set_xlabel(r'IQR of $\ln(1+F/F_0)$')
ax=fig.add_subplot(gs[1,2]);npanel(ax,'d','Filter')
for i,(name,lab) in enumerate([('All','all'),('Drop largest force','drop max'),('Residual = 0','zero res.')]):
    for co,col,dy in [('development',N_TEAL,-.14),('additional',N_VIOLET,.14)]:
        v=f[(f.cohort==co)&(f['filter']==name)].iqr.dropna();pct=(v>=.5).mean()*100
        ax.plot([pct],[i+dy],'o',color=col,ms=4.4,mec='white',mew=.8)
        ax.text(pct+.22,i+dy,f'{pct:.1f}',ha='left',va='center',fontsize=5.8,color=col)
ax.set_yticks([0,1,2],['all','drop\nmax','zero\nres.'])
ax.set_ylim(2.6,-.6);ax.set_xlim(96.6,101.2)
ax.set_xticks([97,98,99,100]);ax.set_xlabel('Retained (%)')
save(fig,'JCIM_Figure1')

fig,axs=plt.subplots(1,2,figsize=(7.0,3.7));fig.subplots_adjust(left=.17,right=.98,bottom=.20,top=.84,wspace=.68)
rs=pd.read_csv(P/'ranking_summary.csv');ax=axs[0];panel(ax,'a','Analytic and learned rankings')
arms=['Contact','Distance','Orbit-only','Context','Oracle']
for co,col,dy in [('Development',TEAL,-.12),('Additional parents',PURPLE,.12)]:
    for i,arm in enumerate(arms):
        z=rs[(rs.cohort==co)&(rs.arm==arm)].iloc[0]
        ax.errorbar(z.ndcg,i+dy,xerr=[[max(0,z.ndcg-z.ndcg_lo)],[max(0,z.ndcg_hi-z.ndcg)]] ,fmt='o' if co=='Development' else 's',ms=4,c=col,capsize=2)
ax.set_yticks(range(5),['Contact penalty','Largest distance','Orbit-only','Full context','Label oracle']);ax.invert_yaxis();ax.set_xlim(.35,1.03);ax.set_xlabel('Mean NDCG@5')
ds=pd.read_csv(D/'descriptor_seeds.csv');ax=axs[1];panel(ax,'b','What information improves ranking?')
arms=['ORBIT','PROGRESS47','RESIDUAL49','DISTANCE48','GEOMETRY57','CONTEXT']
for co,col,dy in [('development',TEAL,-.13),('additional',PURPLE,.13)]:
    for i,arm in enumerate(arms):
        z=ds[(ds.cohort==co)&(ds.arm==arm)].mean_ndcg5
        ax.plot([z.min(),z.max()],[i+dy]*2,c=col,lw=1)
        ax.scatter(z,np.full(len(z),i+dy),s=13,color=col,alpha=.8,marker='o' if co=='development' else 's')
ax.set_yticks(range(6),['Orbit-only','+ Progress','+ Contact residuals','+ Two distances','+ All geometry','Full context']);ax.invert_yaxis();ax.set_xlim(.56,.75);ax.set_xlabel('Mean NDCG@5 (five seeds)')
fig.legend(handles=cohandles,loc='lower center',ncol=2,frameon=False,bbox_to_anchor=(.53,.015));save(fig,'JCIM_Figure2')

fig,axs=plt.subplots(2,2,figsize=(7.0,5.9));fig.subplots_adjust(left=.17,right=.98,bottom=.14,top=.92,wspace=.57,hspace=.57)
ax=axs[0,0];panel(ax,'a','Independent MatterSim evaluation')
ct=pd.read_csv(P/'contact_strata.csv')
for i,(name,label,n) in enumerate([('All','All pairs',96),('Contact residual > 0','Positive residual',23),('Contact residual = 0','Zero residual',73)]):
    z=ct[ct.group==name].iloc[0];ax.errorbar(z['mean'],i,xerr=[[z['mean']-z.lo],[z.hi-z['mean']]],fmt='o',color=CORAL if i==1 else BLUE,capsize=3,ms=5)
ax.set_yticks([0,1,2],['All (96)','Positive residual (23)','Zero residual (73)']);ax.invert_yaxis();ax.axvline(0,c='.65',lw=.7,ls='--');ax.set_xlabel(r'Mean paired $\Delta\ln(1+F/F_0)$')
ch=pd.read_csv(D/'chemistry_strata.csv',dtype={'group':str})
ax=axs[0,1];panel(ax,'b','Assembly stage · CHGNet');forest(ax,ch[ch.dimension=='stage'],['EARLY','MID','LATE','TERMINAL'],{'EARLY':'Early','MID':'Middle','LATE':'Late','TERMINAL':'Terminal'})
ax=axs[1,0];panel(ax,'c','Inserted element · CHGNet');forest(ax,ch[ch.dimension=='element_block'],['s','p','d','f'],{x:f'{x} block' for x in ['s','p','d','f']})
ax=axs[1,1];panel(ax,'d','Space group · CHGNet');forest(ax,ch[ch.dimension=='target_space_group'],['12','63','123','139','164','189','194','225'],{})
fig.legend(handles=cohandles,loc='lower center',ncol=2,frameon=False,bbox_to_anchor=(.53,.015));save(fig,'JCIM_Figure3')

fig,axs=plt.subplots(2,2,figsize=(7.0,5.5));fig.subplots_adjust(left=.11,right=.98,bottom=.13,top=.92,wspace=.38,hspace=.65)
th=pd.read_csv(P/'threshold_spectrum.csv')
for j,pot in enumerate(['CHGNet','MatterSim']):
    ax=axs[0,j];panel(ax,'ab'[j],f'{pot} · all 512 conditions');z=th[th.potential==pot]
    for arm,col,marker,label in [('orbit',BLUE,'s','Orbit-only'),('context',CORAL,'o','Context')]:ax.plot(z.threshold,z[f'{arm}_pass']/512*100,color=col,marker=marker,ms=4,lw=1.4,label=label)
    ax.set_xscale('log');ax.set_xticks([.5,1,2,5,10],['0.5','1','2','5','10']);ax.set_xlabel(r'Force threshold (eV Å$^{-1}$)');ax.set_ylabel('Legal completion below threshold (%)');ax.set_ylim(40,80)
    if j==0:ax.legend(frameon=False,fontsize=7)
en=pd.read_csv(D/'energy_pairs.csv');ax=axs[1,0];panel(ax,'c','Energy changes across paired terminals')
v=en[~en.same_placements].delta_per_atom.sort_values().to_numpy();ax.scatter(np.arange(1,len(v)+1),v,c=np.where(v<0,TEAL,CORAL),s=17,edgecolors='white',linewidths=.3)
ax.axhline(0,c='.6',lw=.7);ax.set_yscale('symlog',linthresh=.1);ax.set_ylim(v.min()*1.8,v.max()*1.8);ax.set_xlabel('Changed placements, ordered by energy difference');ax.set_ylabel(r'$E_{\mathrm{context}}-E_{\mathrm{orbit}}$ (eV atom$^{-1}$)')
ax=axs[1,1];panel(ax,'d','Which paired structures changed?')
counts=[398,40,9];labels=['Same placements','Changed, lower energy','Changed, higher energy'];colors=['#BEBFB4',TEAL,CORAL]
for i,(n,lab,col) in enumerate(zip(counts,labels,colors)):
    ax.barh(i,n,color=col,height=.47);ax.text(n+5,i,str(n),va='center',fontsize=8)
ax.set_yticks(range(3),labels);ax.invert_yaxis();ax.set_xlim(0,450);ax.set_xlabel('Paired legal completions (n = 447)')
save(fig,'JCIM_Figure4')

fig=plt.figure(figsize=(3.25,1.75));ax=fig.add_axes([0,0,1,1]);ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
ax.text(.5,.93,'Wyckoff coordinate selection',ha='center',va='top',fontsize=8.5,fontweight='bold')
xy=np.array([[.07,.37],[.27,.37],[.34,.63],[.14,.63],[.07,.37]])
ax.plot(xy[:,0],xy[:,1],color='#ADB4BA',lw=.9)
for x,y in [(.10,.41),(.29,.58),(.19,.50)]:ax.scatter(x,y,s=43,c=BLUE,edgecolors='white',linewidths=.6)
ax.plot([.14,.27],[.45,.57],color=CORAL,lw=1.3,ls=':');ax.scatter([.17,.22,.26],[.48,.53,.565],s=26,c=CORAL,edgecolors='white',linewidths=.4)
ax.text(.20,.19,'Fixed orbit action\nCoordinate choices',ha='center',fontsize=7,linespacing=1.4)
ax.annotate('',xy=(.46,.50),xytext=(.37,.50),arrowprops={'arrowstyle':'->','color':'#444444','lw':1})
for x,y in [(.48,.38),(.60,.42),(.57,.65)]:
    ax.plot([.54,x],[.51,y],c=TEAL,lw=1.1);ax.scatter(x,y,s=35,c=BLUE,edgecolors='white',linewidths=.5)
ax.scatter(.54,.51,s=40,c=CORAL,edgecolors='white',linewidths=.5)
ax.text(.54,.19,'Framework\ndistances',ha='center',fontsize=7,linespacing=1.4)
ax.annotate('',xy=(.75,.50),xytext=(.65,.50),arrowprops={'arrowstyle':'->','color':'#444444','lw':1})
for i,y in enumerate([.63,.51,.39]):
    col=TEAL if i==0 else '#AAB0B7'
    ax.plot([.79,.91],[y,y],c=col,lw=2.5);ax.scatter(.79,y,s=28,c=col)
ax.text(.84,.19,'Candidate\nranking',ha='center',fontsize=7,linespacing=1.4)
fig.savefig(O/'TOC_legacy.tif',dpi=600,pil_kwargs={'compression':'tiff_lzw'})
save(fig,'TOC_legacy')
print('Four figures and legacy TOC exported as PDF, SVG and 600-dpi PNG.')
