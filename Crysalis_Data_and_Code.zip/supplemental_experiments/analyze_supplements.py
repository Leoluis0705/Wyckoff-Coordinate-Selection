"""Parent-aware analysis of frozen records and new paired-seed fits."""
from pathlib import Path
import json, re
import numpy as np
import pandas as pd
from pymatgen.core import Structure

ROOT=Path(__file__).resolve().parents[1];EXP=ROOT/'supplemental_experiments';OUT=EXP/'analysis';OUT.mkdir(exist_ok=True)
SEED=20261028;B=10000
def read(name):return pd.read_csv(ROOT/'source_data'/name)
def dump(name,value):(OUT/name).write_text(json.dumps(value,indent=2,ensure_ascii=False),encoding='utf-8')
def boot_mean(vals,parents=None):
    vals=np.asarray(vals,float);rng=np.random.default_rng(SEED)
    if parents is None:parents=np.arange(len(vals))
    ids=np.unique(parents);sums=np.array([vals[np.asarray(parents)==p].sum() for p in ids]);counts=np.array([(np.asarray(parents)==p).sum() for p in ids])
    ii=rng.integers(0,len(ids),(B,len(ids)))
    sims=sums[ii].sum(1)/counts[ii].sum(1)
    return {'n':len(vals),'parents':len(ids),'mean':float(vals.mean()),'ci95':np.quantile(sims,[.025,.975]).tolist()}
def boot_tail(a,b):
    a=np.asarray(a,float);b=np.asarray(b,float);rng=np.random.default_rng(SEED)
    ii=rng.integers(0,len(a),(B,len(a)));diff=np.quantile(b[ii],.9,axis=1)-np.quantile(a[ii],.9,axis=1)
    return {'pairs':len(a),'orbit_p90':float(np.quantile(a,.9)),'context_p90':float(np.quantile(b,.9)),'delta_ci95':np.quantile(diff,[.025,.975]).tolist(),'mean_log_delta':float(np.mean(np.log1p(b)-np.log1p(a)))}

records=[json.loads(s) for s in (ROOT/'source_data/generation_trajectories.jsonl').open()]
rows=[]
for r in records:
    steps=[s for s in r['steps'] if s.get('geometry_source') in ['ORBIT_ONLY','CONTEXT'] and s.get('predicted_compatibility_score') is not None]
    rows.append(dict(parent_id=r['parent_id'],arm=r['arm'],K=r['K'],exposed=bool(steps),scored_steps=len(steps),requested_candidates=sum(s['candidate_count'] for s in steps),legal=r['formula_sg_legal_terminal']))
ex=pd.DataFrame(rows);ex.to_csv(OUT/'trajectory_exposure.csv',index=False)
ex.groupby(['arm','K']).agg(attempts=('parent_id','size'),scorer_calls=('exposed','sum'),scored_steps=('scored_steps','sum'),requested_candidates=('requested_candidates','sum'),legal=('legal','sum')).reset_index().to_csv(OUT/'exposure_counts.csv',index=False)
lookup=ex.set_index(['parent_id','arm','K'])
gp=read('generation_paired.csv');gp=gp[gp.K==24].copy()
gp['either_scored']=[bool(lookup.loc[(p,'CONTEXT',24),'exposed'] or lookup.loc[(p,'ORBIT_ONLY',24),'exposed']) for p in gp.parent_id]
gp.to_csv(OUT/'generation_strata.csv',index=False)
tails={};strata=[]
for evaluator in ['chgnet','mattersim']:
    a=gp[f'orbit_{evaluator}_force'];b=gp[f'context_{evaluator}_force']
    tails[evaluator]=boot_tail(a,b)
    for val,label in [(False,'neither_scored'),(True,'either_scored')]:
        rr=gp[gp.either_scored==val];aa=rr[f'orbit_{evaluator}_force'].to_numpy();bb=rr[f'context_{evaluator}_force'].to_numpy()
        strata.append(dict(evaluator=evaluator,stratum=label,**boot_mean(np.log1p(bb)-np.log1p(aa)),orbit_median=float(np.median(aa)),context_median=float(np.median(bb)),orbit_p90=float(np.quantile(aa,.9)),context_p90=float(np.quantile(bb,.9))))
dump('common_terminal_tail.json',tails);dump('generation_strata.json',strata)
gf=read('generation_forces.csv');gf=gf[gf.K==24]
gf.groupby('arm').apply(lambda x:pd.Series({'legal_evaluated':len(x),'legal_and_force_le10':int((x.force<=10).sum()),'attempts':512}),include_groups=False).reset_index().to_csv(OUT/'attempt_yield.csv',index=False)
ip=read('independent_potential_pairs.csv');ids=np.array([re.search(r'mp-\d+',e).group() for e in ip.event_id])
dump('mattersim_parent_cluster.json',boot_mean(np.log1p(ip.CONTEXT)-np.log1p(ip.ORBIT_ONLY),ids))
rp=read('relaxation_pairs.csv');rp=rp[rp.comparison=='CONTEXT_K24_VS_ORBIT_K24'].copy()
rp['either_scored']=[bool(lookup.loc[(p,'CONTEXT',24),'exposed'] or lookup.loc[(p,'ORBIT_ONLY',24),'exposed']) for p in rp.parent_id]
rp.to_csv(OUT/'relaxation_strata.csv',index=False)
rel=[]
for val,label in [(False,'neither_scored'),(True,'either_scored')]:
    rr=rp[rp.either_scored==val];delta=rr.burden_delta.to_numpy()
    rel.append(dict(stratum=label,**boot_mean(delta),lower=int((delta<0).sum()),equal=int((delta==0).sum()),higher=int((delta>0).sum()),orbit_mean=float(rr.right_burden.mean()),context_mean=float(rr.left_burden.mean())))
dump('relaxation_strata.json',rel)
df=read('dft_results.csv').pivot(index='event_key',columns='arm',values='max_force_ev_per_a')
delta=np.log1p(df.context)-np.log1p(df.orbit_only)
loo={k:float(delta.drop(k).mean()) for k in delta.index}
drop=next(k for k in delta.index if 'mp-1025558' in k)
dump('dft_influence.json',{'all':boot_mean(delta),'lower':int((delta<0).sum()),'equal':int((delta==0).sum()),'higher':int((delta>0).sum()),'leave_one_out_means':loo,'exclude_largest_orbit_force':boot_mean(delta.drop(drop))})
contacts=[]
for event in ['event_10_Q4_mp-1025558']:
    for arm in ['context','orbit_only','parent']:
        path=ROOT/'source_data/dft_structures'/event/arm/'POSCAR'
        if not path.exists():continue
        structure=Structure.from_file(path);dist=structure.distance_matrix.copy();np.fill_diagonal(dist,np.inf)
        i,j=np.unravel_index(dist.argmin(),dist.shape)
        contacts.append(dict(event=event,arm=arm,formula=structure.composition.reduced_formula,shortest_pair=f'{structure[i].specie}-{structure[j].specie}',min_distance=float(dist[i,j]),site_i=int(i),site_j=int(j),pairs_below_0p8=int(np.count_nonzero(np.triu(dist<.8,1)))))
dump('dft_contacts.json',contacts)

ev=pd.read_csv(EXP/'ablations/event_metrics.csv');paired=[]
for cohort in ['development','additional']:
    for comparator in ['ORBIT','ORBIT_MATCHED','PROGRESS_MATCHED','GEOMETRY_MATCHED']:
        ll=ev[(ev.cohort==cohort)&(ev.arm=='CONTEXT')]
        rr=ev[(ev.cohort==cohort)&(ev.arm==comparator)]
        m=ll.merge(rr,on=['event_id','seed'],suffixes=('_context','_comparator'),validate='one_to_one')
        m['delta']=np.log1p(m.force_context)-np.log1p(m.force_comparator)
        # Average paired fits per event first; retain parent clusters and all events.
        mm=m.groupby(['event_id','parent_id_context'],as_index=False).delta.mean()
        result=dict(cohort=cohort,comparator=comparator,**boot_mean(mm.delta,mm.parent_id_context))
        result['seed_deltas']=m.groupby('seed').delta.mean().to_dict()
        result['seed_ndcg_deltas']=m.assign(ndcg_delta=m.ndcg5_context-m.ndcg5_comparator).groupby('seed').ndcg_delta.mean().to_dict()
        paired.append(result)
dump('ablation_paired_effects.json',paired)
late=[json.loads(s) for s in (EXP/'branch_and_random/late_random_evaluated.jsonl').open()]
ctx={r['parent_id']:r for r in records if r['K']==24 and r['arm']=='CONTEXT'}
late_map={r['parent_id']:r for r in late}
common=[p for p in sorted(ctx) if ctx[p]['formula_sg_legal_terminal'] and late_map[p]['formula_sg_legal_terminal']]
a=np.array([late_map[p]['initial_max_force_ev_per_angstrom'] for p in common]);b=np.array([ctx[p]['initial_max_force_ev_per_angstrom'] for p in common])
completion=np.array([int(ctx[p]['formula_sg_legal_terminal'])-int(late_map[p]['formula_sg_legal_terminal']) for p in sorted(ctx)])
dump('late_random_comparison.json',{'pairs':len(common),'mean_log_delta_context_minus_late_random':boot_mean(np.log1p(b)-np.log1p(a)),'legal_completion_delta':boot_mean(completion),'late_random_legal_and_force_le10':sum(r['formula_sg_legal_terminal'] and r['chgnet_status']=='EVALUATED' and r['initial_max_force_ev_per_angstrom']<=10 for r in late)})
print('Analysis complete',flush=True)
print(json.dumps({'tails':tails,'relaxation':rel,'contacts':contacts},indent=2))
