from pathlib import Path
import json,hashlib,itertools,sys
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from pymatgen.core import Structure

ROOT=Path(__file__).resolve().parents[1];EXP=ROOT/'supplemental_experiments';OUT=ROOT/'figures';OUT.mkdir(parents=True,exist_ok=True)
mpl.rcParams.update({'font.family':'Arial','font.size':8,'axes.labelsize':8,'axes.titlesize':9,'axes.linewidth':.7,'axes.spines.top':False,'axes.spines.right':False,'legend.frameon':False,'svg.fonttype':'none','pdf.fonttype':42,'savefig.facecolor':'white'})
COLORS=['#465B88','#65A2D2','#9BC491','#B08FC2','#DB5243']
ARMS=['ORBIT','ORBIT_MATCHED','PROGRESS_MATCHED','GEOMETRY_MATCHED','CONTEXT']
LABELS=['Orbit-only','Matched orbit','Progress only','Geometry only','Full context']
specs=[]
def export(fig,name,caption,sources,panels):
    fig.canvas.draw()
    for ext in ['pdf','svg']:fig.savefig(OUT/f'{name}.{ext}')
    fig.savefig(OUT/f'{name}.png',dpi=600)
    fig.savefig(OUT/f'{name}_preview.png',dpi=170)
    plt.close(fig)
    spec={'schema_version':'1.0','figure_id':name,'mode':'create','target':{'journal':'Crystal Growth & Design','width_mm':182.88,'height_mm':fig.get_figheight()*25.4},'status':'DATA_VALIDATED','style_profile':'Existing author-selected A palette; design judgment','data_manifest':[{'id':f'source{i}','path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'role':'authoritative'} for i,p in enumerate(sources)],'panels':[],'exports':[{'format':e,'path':str(OUT/f'{name}.{e}'),'verified':False} for e in ['svg','pdf','png']],'qa_checks':{'data_traceability':'pass','caption_completeness':'pass','visual_legibility':'pending','export_integrity':'pending'}}
    for letter,title,backend,metric,n,units,uncertainty in panels:
        spec['panels'].append({'id':letter,'title':title,'evidence_class':'EVIDENTIARY','render_backend':backend,'visual_grammar':'quantitative-grid' if backend=='matplotlib' else 'structure-statistics','rendering_form':'plot' if backend=='matplotlib' else 'structure-rendering','evidence_refs':[f'source{i}' for i in range(len(sources))],'cohort_relation':'not_applicable','caption':{'what':title,'metric_definition':metric,'denominator':n,'n':n,'units':units,'uncertainty':uncertainty,'subset':caption}})
    path=EXP/f'{name}_spec.json';path.write_text(json.dumps(spec,indent=2))
    specs.append(path)

sm=pd.read_csv(EXP/'ablations/seed_metrics.csv');sm=sm[sm.stage=='ALL']
fig,axes=plt.subplots(1,2,figsize=(7.2,3.4),sharex=True)
fig.subplots_adjust(left=.20,right=.97,bottom=.18,top=.85,wspace=.32)
for j,(cohort,title) in enumerate([('development','Development · 663 events'),('additional','Additional parents · 429 events')]):
    ax=axes[j]
    for i,(arm,color) in enumerate(zip(ARMS,COLORS)):
        values=sm[(sm.cohort==cohort)&(sm.arm==arm)].mean_ndcg5.to_numpy()
        y=4-i
        ax.plot([values.min(),values.max()],[y,y],color=color,lw=1.3)
        ax.scatter(values,y+np.linspace(-.11,.11,5),s=22,color=color,edgecolors='white',linewidths=.5,zorder=3)
        ax.scatter(values.mean(),y,marker='D',facecolors='white',edgecolors=color,s=35,linewidths=1.2,zorder=4)
    ax.set(xlim=(.54,.76),ylim=(-.5,4.65),xlabel='Mean NDCG@5',yticks=range(5),yticklabels=LABELS[::-1] if j==0 else ['']*5)
    ax.set_xticks([.55,.60,.65,.70,.75]);ax.tick_params(axis='y',length=0)
    ax.set_title(title,loc='left',pad=15)
    ax.text(-.17 if j==0 else -.07,1.08,'ab'[j],transform=ax.transAxes,fontweight='bold',fontsize=11)
fig.text(.20,.045,'Points: five paired training seeds     Diamond: mean     Line: observed range',fontsize=7.5)
export(fig,'FigureS3','Five seeds per arm. Development uses original four parent-disjoint folds; additional cohort uses full-development fits. No tuning on the additional cohort.',[EXP/'ablations/seed_metrics.csv'],[(c,t,'matplotlib','Event-mean NDCG@5','5 seeds; 663/429 events; 192/128 parents','dimensionless','five points and observed seed range; not a confidence interval') for c,t in zip('ab',['Development ranking','Additional-parent ranking'])])

fig=plt.figure(figsize=(7.2,3.1));a=fig.add_axes([.08,.25,.40,.55]);b=fig.add_axes([.64,.25,.30,.55])
for y,total,scored,label in [(1,512,127,'Generation conditions'),(0,447,83,'Common legal pairs')]:
    a.barh(y,total,height=.40,color='#E4E6E8')
    a.barh(y,scored,height=.40,color='#65A2D2')
    a.text(scored/2,y,str(scored),ha='center',va='center',fontsize=8)
    a.text(scored+(total-scored)/2,y,str(total-scored),ha='center',va='center',fontsize=8)
    a.text(0,y+.30,label,fontsize=8)
a.set(xlim=(0,512),ylim=(-.45,1.65),yticks=[],xticks=[0,128,256,384,512],xlabel='Conditions or paired terminals')
a.spines['left'].set_visible(False)
a.set_title('a  Scorer participation · K = 24',loc='left',pad=15)
for y,lower,equal,higher,label in [(1,0,75,0,'Neither scored · n = 75'),(0,9,10,2,'Either scored · n = 21')]:
    pos=0
    for count,color in zip([lower,equal,higher],['#DB5243','#D8DBDF','#465B88']):
        b.barh(y,count,left=pos,height=.4,color=color)
        if count and count<4:
            b.annotate(str(count),(pos+count/2,y),xytext=(pos+count+4,y-.16),ha='left',va='center',fontsize=8,arrowprops={'arrowstyle':'-','lw':.6,'color':'#444444'})
        elif count:b.text(pos+count/2,y,str(count),va='center',ha='center',fontsize=8,color='white' if color=='#465B88' else '#222222')
        pos+=count
    b.text(0,y+.30,label,fontsize=8)
b.set(xlim=(0,75),ylim=(-.45,1.65),yticks=[],xticks=[0,25,50,75],xlabel='Relaxation pairs')
b.spines['left'].set_visible(False);b.set_title('b  Context relaxation score',loc='left',pad=15)
fig.legend(handles=[Line2D([],[],marker='s',ls='',color=c,label=l) for c,l in [('#65A2D2','Scorer invoked'),('#E4E6E8','Neither invoked')]],loc='lower left',bbox_to_anchor=(.06,.035),ncol=2,fontsize=7.5)
fig.legend(handles=[Line2D([],[],marker='s',ls='',color=c,label=l) for c,l in [('#DB5243','Lower'),('#D8DBDF','Equal'),('#465B88','Higher')]],loc='lower right',bbox_to_anchor=(.98,.035),ncol=3,fontsize=7.5)
export(fig,'FigureS4','K24 historical trajectories. A scorer invocation requires the learned geometry branch and a numeric score. Relaxation sample is the original96 primary pairs.',[EXP/'analysis/trajectory_exposure.csv',EXP/'analysis/relaxation_strata.csv'],[('a','Participation counts','matplotlib','Recorded numeric learned-scorer invocation','512 attempts per arm;447 shared legal pairs','counts','not_applicable: complete recorded populations'),('b','Relaxation score by participation','matplotlib','Context capped-step score lower/equal/higher than orbit-only','96 primary pairs:75 neither scored and21 either scored','counts','not_applicable: complete recorded sample')])

# Figure S5 uses the same stored geometries and a shared orthographic view.
import runpy
runpy.run_path(str(EXP/'redraw_figure_s5.py'), run_name='__main__')
print('Created FigureS3, FigureS4 and FigureS5')
