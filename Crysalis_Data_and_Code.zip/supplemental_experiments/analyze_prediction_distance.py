from pathlib import Path
import numpy as np,pandas as pd,json
from scipy.stats import spearmanr
R=Path(__file__).resolve().parents[1];out=[]
for co,file in [('development','atlas_candidates.csv'),('additional','external_candidates.csv')]:
 d=pd.read_csv(R/'reproducibility/inputs'/file);d=d[d.chgnet_status=='EVALUATED'].reset_index(drop=True)
 ids=json.loads((R/'supplemental_experiments/ablations/candidate_order.json').read_text())[co]
 assert ids==d.candidate_id.tolist()
 for seed in range(202610280,202610285):
  pred=np.load(R/f'supplemental_experiments/ablations/CONTEXT_{seed}_predictions.npz')[co]
  for eid, g in d.groupby('event_id'):
   out.append(dict(cohort=co,seed=seed,event_id=eid,parent_id=g.parent_id.iloc[0],rho=spearmanr(g.candidate_framework_min_distance_min,pred[g.index]).statistic))
a=pd.DataFrame(out);a.to_csv(R/'supplemental_experiments/reframing/predicted_distance_correlations.csv',index=False)
for co,g in a.groupby('cohort'): print(co,g.groupby('seed').rho.median().to_dict())
