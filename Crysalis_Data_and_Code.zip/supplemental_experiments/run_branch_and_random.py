"""Replay scorer branches, then compute the matched late-random K24 arm."""
from pathlib import Path
import sys,json,time,copy,importlib.metadata
import numpy as np
import torch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'reproducibility/code'))
import scripts.run_final_generative_candidate_budget_benchmark as g
torch.set_num_threads(1)
OUT=Path(__file__).resolve().parent/'branch_and_random';OUT.mkdir(exist_ok=False)
models=ROOT/'reproducibility/models';inp=ROOT/'reproducibility/inputs'
device=torch.device('cpu')
policy,mdn,_=g._load_policy_and_mdn(models/'policy.pt',models/'direct_mdn.pt',device)
om,on=g._load_landscape(models/'orbit_only.pt',g.ORBIT_ONLY_FEATURE_NAMES)
cm,cn=g._load_landscape(models/'context_conditional.pt',g.CONTEXT_FEATURE_NAMES)
parents=g.load_recovered_parents(inp/'recovered_parent_states.jsonl')
saved=[json.loads(s) for s in (inp/'generation_trajectories.jsonl').open()]
saved={(r['parent_id'],r['arm']):r for r in saved if r['K']==24 and r['arm'] in ['ORBIT_ONLY','CONTEXT']}
base_select=g._select_landscape_geometry
audit=[]
def traced_select(**kw):
    value,receipt=base_select(**kw)
    audit.append({'parent_id':kw['parent_id'],'step':kw['step'],'arm':kw['arm'],'receipt':receipt,'pool':kw['rows']})
    return value,receipt

def run(pid,arm):
    return g._run_trajectory(parent=parents[pid],arm=arm,k=24,policy=policy,mdn=mdn,orbit_model=om,orbit_norm=on,context_model=cm,context_norm=cn,device=device)

def exposed(r):return any(s.get('geometry_source') in ['ORBIT_ONLY','CONTEXT'] and s.get('predicted_compatibility_score') is not None for s in r['steps'])
pids=sorted(set(pid for pid,arm in saved))
divergent=[]
for pid in pids:
    a,b=saved[pid,'ORBIT_ONLY'],saved[pid,'CONTEXT']
    if a['formula_sg_legal_terminal'] and b['formula_sg_legal_terminal'] and exposed(a) and exposed(b) and [s.get('selected_candidate_index') for s in a['steps']]!=[s.get('selected_candidate_index') for s in b['steps']]:divergent.append(pid)
assert divergent
targets=[(divergent[0],a,'scored_divergence') for a in ['ORBIT_ONLY','CONTEXT']]
for arm in ['ORBIT_ONLY','CONTEXT']:
    pid=next(pid for pid in pids if exposed(saved[pid,arm]) and any(s.get('projector_status')=='REJECTED' for s in saved[pid,arm]['steps']))
    targets.append((pid,arm,'scored_rejection'))
report=[];g._select_landscape_geometry=traced_select
for pid,arm,purpose in targets:
    audit.clear();actual,structure=run(pid,arm);reference=saved[pid,arm]
    assert actual['formula_sg_legal_terminal']==reference['formula_sg_legal_terminal']
    assert actual['failure']==reference['failure']
    assert len(actual['steps'])==len(reference['steps'])
    coord_error=score_error=0.
    for step,saved_step in zip(actual['steps'],reference['steps']):
        for key in ['selected_action','selected_candidate_index','projector_status','geometry_source','failure_reason','candidate_count']:
            assert step.get(key)==saved_step.get(key),(pid,arm,key)
        if step.get('selected_u'):coord_error=max(coord_error,float(np.max(np.abs(np.array(step['selected_u'])-saved_step['selected_u']))))
        if step.get('predicted_compatibility_score') is not None:score_error=max(score_error,abs(step['predicted_compatibility_score']-saved_step['predicted_compatibility_score']))
    assert coord_error<2e-5 and score_error<2e-5
    assert audit
    report.append({'parent_id':pid,'arm':arm,'purpose':purpose,'steps':len(actual['steps']),'scoring_calls':len(audit),'coordinate_max_error':coord_error,'score_max_error':score_error,'all_action_candidate_validation_and_failure_fields_match':True})
    (OUT/f'replay_{purpose}_{arm}.json').write_text(json.dumps({'report':report[-1],'actual':actual,'reference':reference,'candidate_pools':audit},indent=2))
    print(report[-1],flush=True)
(OUT/'replay_summary.json').write_text(json.dumps(report,indent=2))

def late_random_select(**kw):
    assert kw['arm']=='CONTACT'
    return base_select(**{**kw,'arm':'RANDOM_LEGAL'})
g._select_landscape_geometry=late_random_select
holdout=json.loads((inp/'holdout.json').read_text())['parent_ids']
(OUT/'structures').mkdir()
records=[];structures={};start=time.monotonic()
with (OUT/'late_random_trajectories.jsonl').open('w') as f:
    for i,pid in enumerate(holdout):
        r,structure=run(pid,'CONTACT')
        r['arm']='LATE_RANDOM';r['record_id']=r['record_id'].replace(':CONTACT:',':LATE_RANDOM:')
        for step in r['steps']:
            step['arm']='LATE_RANDOM'
            if step.get('geometry_source')=='CONTACT':step['geometry_source']='LATE_RANDOM'
        records.append(r)
        if structure is not None:
            structures[r['record_id']]=structure
            structure.to(filename=str(OUT/'structures'/f'{pid}.cif'),fmt='cif')
        f.write(json.dumps(r)+'\n');f.flush()
        if (i+1)%32==0:print(f'Late random {i+1}/512; {time.monotonic()-start:.1f}s',flush=True)
assert len(records)==512
# Reuse the exact early/fixed branches and random hash; no selection retries.
model=g._load_chgnet('cuda')
g._evaluate_chgnet(model,records,structures)
with (OUT/'late_random_evaluated.jsonl').open('w') as f:
    for r in records:f.write(json.dumps(r)+'\n')
summary=g._summary(records)
summary['environment']={name:importlib.metadata.version(name) for name in ['torch','numpy','chgnet','pymatgen','pyxtal','spglib']}
summary['elapsed_seconds']=time.monotonic()-start
(OUT/'late_random_summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2),flush=True)
