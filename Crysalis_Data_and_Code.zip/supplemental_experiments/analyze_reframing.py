from pathlib import Path
import sys,json,warnings
import numpy as np,pandas as pd
from scipy.stats import spearmanr
warnings.filterwarnings('ignore',category=RuntimeWarning)
R=Path(__file__).resolve().parents[1];O=R/'supplemental_experiments/reframing';sys.path.insert(0,str(R/'reproducibility/code'))
from crysalis_g1.experiments.full_orbit_operator import event_ranking_metrics
rng=np.random.default_rng(20261030)
def boot(df,col):
 g=df.groupby('parent_id')[col].agg(['sum','count']);ix=rng.integers(0,len(g),(10000,len(g)));v=g['sum'].to_numpy()[ix].sum(1)/g['count'].to_numpy()[ix].sum(1);return [float(df[col].mean()),*np.quantile(v,[.025,.975]).tolist()]
def boot_gap(df,flag,col):
 'Between-stratum contrast. Parents are drawn jointly over the whole 96-pair set, so a parent shared by both strata contributes to both. Separate seed: does not perturb rng above.'
 r=np.random.default_rng(20261031);p=df.parent_id.unique();mm={q:g for q,g in df.groupby('parent_id')};v=[]
 for _ in range(10000):
  s=r.choice(p,len(p),replace=True);b=pd.concat([mm[q] for q in s],ignore_index=True);a=b.loc[b[flag],col].mean();n=b.loc[~b[flag],col].mean()
  if np.isfinite(a) and np.isfinite(n):v.append(a-n)
 return [float(df.loc[df[flag],col].mean()-df.loc[~df[flag],col].mean()),*np.quantile(v,[.025,.975]).tolist()]
raw=[];events=[];ranks=[]
for cohort,file in [('Development','atlas_candidates.csv'),('Additional parents','external_candidates.csv')]:
 d=pd.read_csv(R/'reproducibility/inputs'/file);d=d[d.chgnet_status=='EVALUATED'].copy();d['cohort']=cohort;raw.append(d)
 for event,g in d.groupby('event_id',sort=True):
  g=g.sort_values('candidate_index');f=g.initial_max_force_ev_per_angstrom.to_numpy();q=np.quantile(f,[.25,.75]);first=g.iloc[0]
  events.append(dict(cohort=cohort,event_id=event,parent_id=first.parent_id,d=int(first.free_dof),multiplicity=first.multiplicity,space_group=first.target_space_group,stage=first.stage,n=len(g),iqr_log1p=float(np.diff(np.quantile(np.log1p(f),[.25,.75]))[0]),span_ratio=float(f.max()/f.min()) if f.min()>0 else np.nan,iqr_ratio=float(q[1]/q[0]) if q[0]>0 else np.nan,force_min=f.min(),force_max=f.max(),distance_force_spearman=spearmanr(g.candidate_framework_min_distance_min,f).statistic))
  for arm,pred in [('Distance',-g.candidate_framework_min_distance_min.to_numpy()),('Contact',g.static_full_orbit_contact_score.to_numpy()),('Oracle',np.log1p(f))]:
   m=event_ranking_metrics(force=f,prediction=pred);ranks.append(dict(cohort=cohort,event_id=event,parent_id=first.parent_id,arm=arm,ndcg5=m['ndcg5'],force=m['top1_force'],candidate_id=g.iloc[int(m['top1_index'])].candidate_id))
d=pd.concat(raw,ignore_index=True);e=pd.DataFrame(events);a=pd.DataFrame(ranks);e.to_csv(O/'event_spread.csv',index=False);a.to_csv(O/'analytic_rankings.csv',index=False)
sel=pd.read_csv(R/'source_data/candidate_selections.csv')
for arm,prefix in [('Orbit-only','orbit_only'),('Context','context')]:
 t=sel[['cohort','event_id','parent_id',f'{prefix}_ndcg5',f'{prefix}_top1_force']].rename(columns={f'{prefix}_ndcg5':'ndcg5',f'{prefix}_top1_force':'force'});t['arm']=arm;a=pd.concat([a,t],ignore_index=True)
summ=[]
for (cohort,arm),g in a.groupby(['cohort','arm']):
 z=boot(g,'ndcg5');summ.append(dict(cohort=cohort,arm=arm,n=len(g),ndcg=z[0],ndcg_lo=z[1],ndcg_hi=z[2],median_force=g.force.median()))
pd.DataFrame(summ).to_csv(O/'ranking_summary.csv',index=False)
spread=[]
for cohort,g in e.groupby('cohort'):
 spread.append(dict(cohort=cohort,n=len(g),parents=g.parent_id.nunique(),median_iqr=g.iqr_log1p.median(),median_span=g.span_ratio.median(),tenfold_span=int((g.span_ratio>10).sum()),median_iqr_ratio=g.iqr_ratio.median(),tenfold_iqr=int((g.iqr_ratio>10).sum()),min_iqr=g.iqr_log1p.min(),median_distance_force_rho=g.distance_force_spearman.median()))
pd.DataFrame(spread).to_csv(O/'spread_summary.csv',index=False)
# Independent-potential pairs linked by actual candidate identifiers.
ip=pd.read_csv(R/'source_data/independent_potential_candidates.csv');ip=ip[ip.arm.isin(['ORBIT_ONLY','CONTEXT'])].merge(d[['candidate_id','candidate_framework_min_distance_min','short_contact_residual_max','short_contact_residual_mean']],on='candidate_id',validate='many_to_one')
ip.to_csv(O/'independent_contacts.csv',index=False)
w=ip.pivot(index=['event_id','parent_id'],columns='arm',values=['force','candidate_framework_min_distance_min','short_contact_residual_max']).reset_index();w.columns=['_'.join(x).rstrip('_') for x in w.columns]
w['delta']=np.log1p(w.force_CONTEXT)-np.log1p(w.force_ORBIT_ONLY);w['close_contact']=w.short_contact_residual_max_ORBIT_ONLY>0;w['quartile']=pd.qcut(w.force_ORBIT_ONLY.rank(method='first'),4,labels=['Q1','Q2','Q3','Q4'])
cs=[]
for typ,mask in [('All',np.ones(len(w),bool)),('Contact residual > 0',w.close_contact),('Contact residual = 0',~w.close_contact),('Q1-Q3',w.quartile!='Q4'),('Q4',w.quartile=='Q4')]:
 g=w[mask];z=boot(g,'delta');cs.append(dict(group=typ,n=len(g),parents=g.parent_id.nunique(),mean=z[0],lo=z[1],hi=z[2],wins=int((g.delta<0).sum()),ties=int((g.delta==0).sum())))
w.to_csv(O/'independent_contact_pairs.csv',index=False);z=boot_gap(w,'close_contact','delta');cs.append(dict(group='Contact residual > 0 minus = 0',n=len(w),parents=w.parent_id.nunique(),mean=z[0],lo=z[1],hi=z[2],wins=np.nan,ties=np.nan));pd.DataFrame(cs).to_csv(O/'contact_strata.csv',index=False)
# Five seeds, full context vs contact controls; each event averaged across seeds before clustered bootstrap.
metrics=pd.concat([pd.read_csv(R/'supplemental_experiments'/folder/'event_metrics.csv') for folder in ['ablations','contact_ablations','contact_matched']],ignore_index=True)
metrics.to_csv(O/'combined_seed_events.csv',index=False)
ab=[]
for cohort in ['development','additional']:
 for arm in ['ORBIT','CONTACT3','ORBIT_CONTACT3','CONTACT_MATCHED']:
  c=metrics[(metrics.cohort==cohort)&(metrics.arm=='CONTEXT')];t=metrics[(metrics.cohort==cohort)&(metrics.arm==arm)];p=c.merge(t,on=['event_id','seed'],suffixes=('_c','_t'));p['delta_ndcg']=p.ndcg5_c-p.ndcg5_t;p['delta_force']=np.log1p(p.force_c)-np.log1p(p.force_t);p['parent_id']=p.parent_id_c;p=p.groupby(['event_id','parent_id'],as_index=False)[['delta_ndcg','delta_force']].mean();z=boot(p,'delta_ndcg');y=boot(p,'delta_force');ab.append(dict(cohort=cohort,comparator=arm,ndcg_delta=z[0],ndcg_lo=z[1],ndcg_hi=z[2],force_delta=y[0],force_lo=y[1],force_hi=y[2]))
pd.DataFrame(ab).to_csv(O/'contact_ablation_effects.csv',index=False)
# Threshold success is legal AND <= threshold, denominator all 512 attempted conditions.
traj=pd.read_json(R/'source_data/generation_trajectories.jsonl',lines=True);parents=sorted(traj[(traj.K==24)&(traj.arm=='CONTEXT')].parent_id);th=[]
for pot in ['CHGNet','MatterSim']:
 if pot=='CHGNet':f=pd.read_csv(R/'source_data/generation_forces.csv').rename(columns={'force':'F'})
 else:
  f=pd.read_csv(R/'source_data/generation_mattersim.csv');print('MatterSim columns',list(f.columns),flush=True)
  f=f[f.formula_sg_legal_terminal & f.finite & (f.matter_sim_status=='EVALUATED')].copy()
  f=f.rename(columns={'mattersim_max_force':'F'})
  if 'F' not in f: f=f.rename(columns={'max_force':'F','max_force_ev_per_angstrom':'F'})
 for threshold in [.5,1,2,5,10]:
  pop=pd.DataFrame({'parent_id':parents})
  for arm,label in [('ORBIT_ONLY','orbit'),('CONTEXT','context')]:
   q=f[(f.K==24)&(f.arm==arm)].set_index('parent_id');pop[label]=[bool(k in q.index and np.isfinite(q.loc[k,'F']) and q.loc[k,'F']<=threshold) for k in parents]
  pop['delta']=pop.context.astype(int)-pop.orbit.astype(int);z=boot(pop,'delta');th.append(dict(potential=pot,threshold=threshold,n=512,orbit_pass=int(pop.orbit.sum()),context_pass=int(pop.context.sum()),difference=z[0],lo=z[1],hi=z[2]))
pd.DataFrame(th).to_csv(O/'threshold_spectrum.csv',index=False)
print('SPREAD',pd.DataFrame(spread).to_string(index=False));print('RANKING',pd.DataFrame(summ).to_string(index=False));print('CONTACT',pd.DataFrame(cs).to_string(index=False));print('ABLATION',pd.DataFrame(ab).to_string(index=False));print('THRESHOLDS',pd.DataFrame(th).to_string(index=False))

