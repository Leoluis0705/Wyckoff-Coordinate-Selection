from pathlib import Path
import itertools,json,hashlib,csv
import numpy as np
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from pymatgen.core import Structure
ROOT=Path(__file__).resolve().parents[1];(ROOT/'figures').mkdir(parents=True,exist_ok=True)
mpl.rcParams.update({'font.family':'Arial','font.size':9,'svg.fonttype':'none','pdf.fonttype':42})
with (ROOT/'source_data/dft_results.csv').open(newline='',encoding='utf-8') as f:
    forces={row['arm']:float(row['max_force_ev_per_a']) for row in csv.DictReader(f) if row['event_key']=='event_10_Q4_mp-1025558'}
colors={'Ce':'#B08FC2','Ni':'#309D88','Sn':'#65A2D2'}
az,el=np.deg2rad([-57,20])
right=np.array([-np.sin(az),np.cos(az),0]);up=np.array([-np.sin(el)*np.cos(az),-np.sin(el)*np.sin(az),np.cos(el)])
projection=np.array([right,up]).T
structures=[]; info=[];bounds=[]
for arm in ['orbit_only','context']:
    path=ROOT/'source_data/dft_structures/event_10_Q4_mp-1025558'/arm/'POSCAR'
    st=Structure.from_file(path)
    candidates=[(st.get_distance(i,j),i,j) for i in range(len(st)) for j in range(i+1,len(st)) if {str(st[i].specie),str(st[j].specie)}=={'Ni','Sn'}]
    d,i,j=min(candidates);d,img=st.lattice.get_distance_and_image(st[i].frac_coords,st[j].frac_coords)
    end=st.lattice.get_cartesian_coords(st[j].frac_coords+img)
    verts=np.array(list(itertools.product([0,1],repeat=3)))@st.lattice.matrix
    structures.append((st,verts,i,j,end,img));bounds.extend((verts@projection).tolist());bounds.append((end@projection).tolist())
    info.append({'arm':arm,'shortest_Ni_Sn_A':float(d),'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'periodic_image':img.tolist()})
assert np.allclose([x['shortest_Ni_Sn_A'] for x in info],[.439365,2.436194],atol=1e-6)
lim=np.array(bounds);lo=lim.min(0);hi=lim.max(0);pad=(hi-lo)*.09
fig=plt.figure(figsize=(7.2,4.35),facecolor='white')
for n,(st,verts,i,j,end,img) in enumerate(structures):
    ax=fig.add_axes([.025+.505*n,.23,.445,.62])
    for a,b in itertools.combinations(range(8),2):
        bits=np.array(list(itertools.product([0,1],repeat=3)))
        if np.abs(bits[a]-bits[b]).sum()==1:
            xy=verts[[a,b]]@projection;ax.plot(*xy.T,color='#A4ADB7',lw=.85,zorder=1)
    xy=st.cart_coords@projection
    for k,site in enumerate(st):
        ax.scatter(*xy[k],s=145 if str(site.specie)=='Ce' else 105,c=colors[str(site.specie)],edgecolors='#33424F',linewidths=.65,zorder=3)
    contact=np.array([st[i].coords,end])@projection
    ax.plot(*contact.T,color='#DB5243',lw=2.5,zorder=5,solid_capstyle='round')
    if np.any(img):
        ax.scatter(*contact[1],s=105,facecolors='white',edgecolors=colors[str(st[j].specie)],linewidths=1.6,zorder=4)
    ax.set(xlim=(lo[0]-pad[0],hi[0]+pad[0]),ylim=(lo[1]-pad[1],hi[1]+pad[1]),aspect='equal');ax.axis('off')
    x=.045+.505*n
    fig.text(x,.91,'ab'[n],weight='bold',fontsize=12)
    fig.text(x+.035,.91,['Orbit-only','Context'][n],fontsize=11)
    fig.text(x,.17,'Shortest Ni–Sn contact',fontsize=8,color='#53616D')
    fig.text(x+.28,.17,f"{info[n]['shortest_Ni_Sn_A']:.3f} Å",fontsize=11,ha='right',weight='bold')
    fig.text(x,.075,'Maximum DFT force',fontsize=8,color='#53616D')
    fig.text(x+.39,.075,f"{forces[['orbit_only','context'][n]]:,.2f}"+r' eV Å$^{-1}$',fontsize=10,ha='right')
    fig.add_artist(Line2D([x,x+.39],[.22,.22],transform=fig.transFigure,color='#D9DEE3',lw=.8))
fig.legend(handles=[Line2D([],[],marker='o',ls='',color=c,label=s,markersize=6) for s,c in colors.items()],loc='upper center',bbox_to_anchor=(.5,1.01),ncol=3,frameon=False,fontsize=8,handletextpad=.4,columnspacing=1.6)
for ext in ['pdf','svg']:fig.savefig(ROOT/f'figures/FigureS5.{ext}')
fig.savefig(ROOT/'figures/FigureS5.png',dpi=600)
fig.savefig(ROOT/'figures/FigureS5_preview.png',dpi=180)
print(json.dumps(info, indent=2))
