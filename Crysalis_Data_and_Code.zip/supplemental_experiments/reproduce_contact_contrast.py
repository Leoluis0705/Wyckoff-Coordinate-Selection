"""Reproduce the contact-stratum contrast using joint parent resampling."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
R = Path(__file__).resolve().parents[1]
d = pd.read_csv(R / 'supplemental_experiments/reframing/independent_contact_pairs.csv')
parents = d.parent_id.unique()
g = d.groupby(['parent_id', 'close_contact']).delta.agg(['sum', 'count']).unstack(fill_value=0).reindex(parents)
ix = np.random.default_rng(20261031).integers(0, len(parents), (10000, len(parents)))
means = []
for flag in (True, False):
    counts = g[('count', flag)].to_numpy()[ix].sum(1)
    assert (counts > 0).all()
    means.append(g[('sum', flag)].to_numpy()[ix].sum(1) / counts)
a = set(d.loc[d.close_contact, 'parent_id'])
b = set(d.loc[~d.close_contact, 'parent_id'])
result = dict(pairs=len(d), parents=len(parents), shared_parents=len(a & b), seed=20261031, resamples=10000,
    difference=float(d.loc[d.close_contact, 'delta'].mean() - d.loc[~d.close_contact, 'delta'].mean()),
    interval=np.quantile(means[0] - means[1], [.025, .975]).tolist())
assert (result['pairs'], result['parents'], result['shared_parents']) == (96, 39, 11)
assert [round(v, 3) for v in result['interval']] == [-4.432, -1.805]
(R / 'supplemental_experiments/reframing/contact_contrast.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
