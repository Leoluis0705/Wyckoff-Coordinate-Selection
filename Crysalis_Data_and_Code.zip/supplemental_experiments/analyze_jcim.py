"""Recompute contact filtering, descriptor controls, chemistry and terminal energy."""
from pathlib import Path
import json, hashlib, sys
import numpy as np
import pandas as pd
from pymatgen.core import Element

R = Path(__file__).resolve().parents[1]
O = R/'supplemental_experiments/jcim'
O.mkdir(exist_ok=True)
rng = np.random.default_rng(20261031)

def interval(d, col):
    g = d.groupby('parent_id')[col].agg(['sum','count'])
    ix = rng.integers(0, len(g), (10000,len(g)))
    b = g['sum'].to_numpy()[ix].sum(1)/g['count'].to_numpy()[ix].sum(1)
    return dict(mean=float(d[col].mean()),lo=float(np.quantile(b,.025)),hi=float(np.quantile(b,.975)))

cs=[]
for co,fn in [('development','atlas_candidates.csv'),('additional','external_candidates.csv')]:
    d=pd.read_csv(R/'reproducibility/inputs'/fn)
    d=d[d.chgnet_status.eq('EVALUATED')].copy();d['cohort']=co;cs.append(d)
c=pd.concat(cs,ignore_index=True)
assert len(c)==26185 and np.isfinite(c.initial_max_force_ev_per_angstrom).all()
c['y']=np.log1p(c.initial_max_force_ev_per_angstrom)
rows=[]
for (co,ev),g in c.groupby(['cohort','event_id']):
    for label,sub in [('All',g),('Residual = 0',g[g.short_contact_residual_max==0]),('Residual <= 0.2',g[g.short_contact_residual_max<=.2]),('Residual <= 0.5',g[g.short_contact_residual_max<=.5]),('Drop largest force',g.sort_values('y').iloc[:-1])]:
        rows.append(dict(cohort=co,event_id=ev,parent_id=g.parent_id.iloc[0],filter=label,n=len(sub),d=int(g.free_dof.iloc[0]),iqr=float(sub.y.quantile(.75)-sub.y.quantile(.25)) if len(sub)>=3 else np.nan))
e=pd.DataFrame(rows);e.to_csv(O/'filtered_event_spread.csv',index=False)
fs=[]
for (co,filt),g in e.groupby(['cohort','filter']):
    v=g.dropna(subset=['iqr']);fs.append(dict(cohort=co,filter=filt,total_events=len(g),eligible_events=len(v),retained_candidates=int(g.n.sum()),median_iqr=v.iqr.median(),broad_events=int((v.iqr>=.5).sum()),median_candidates=v.n.median()))
pd.DataFrame(fs).to_csv(O/'filter_summary.csv',index=False)

m=pd.read_csv(R/'supplemental_experiments/subsets_torch/event_metrics.csv')
seed=pd.read_csv(R/'supplemental_experiments/subsets_torch/seed_metrics.csv');seed=seed[seed.stage=='ALL']
seed.to_csv(O/'descriptor_seeds.csv',index=False)
arm_summary=[]
for (co,arm),g in m.groupby(['cohort','arm']):
    a=g.groupby(['event_id','parent_id'],as_index=False).ndcg5.mean()
    arm_summary.append(dict(cohort=co,arm=arm,n=len(a),**interval(a,'ndcg5')))
pd.DataFrame(arm_summary).to_csv(O/'descriptor_summary.csv',index=False)
base=m[m.arm=='ORBIT'];full=m[m.arm=='CONTEXT']
p=full.merge(base,on=['cohort','seed','event_id','parent_id','stage'],suffixes=('_c','_o'),validate='one_to_one')
p['delta']=np.log1p(p.force_c)-np.log1p(p.force_o)
p['different']=(p.selected_candidate_id_c!=p.selected_candidate_id_o).astype(int)
p['gain']=p.ndcg5_c-p.ndcg5_o
meta=c.drop_duplicates('event_id')[['event_id','target_space_group','species','free_dof']].copy()
meta['element_block']=meta.species.map(lambda z: Element.from_Z(int(z)).block)
p=p.merge(meta,on='event_id',validate='many_to_one')
p.to_csv(O/'paired_seed_events.csv',index=False)
chem=[]
for co,g in p.groupby('cohort'):
    for dim in ['stage','target_space_group','element_block']:
        for val,h in g.groupby(dim):
            q=h.groupby(['event_id','parent_id'],as_index=False)[['delta','different','gain']].mean()
            chem.append(dict(cohort=co,dimension=dim,group=val,n=len(q),parents=q.parent_id.nunique(),different_selection_fraction=q.different.mean(),**interval(q,'delta')))
pd.DataFrame(chem).to_csv(O/'chemistry_strata.csv',index=False)
effects=[]
for co in ['development','additional']:
    for arm in ['ORBIT','PROGRESS47','DISTANCE48','RESIDUAL49','GEOMETRY57']:
        a=full[full.cohort==co].merge(m[(m.cohort==co)&(m.arm==arm)],on=['seed','event_id','parent_id'],suffixes=('_c','_a'))
        a['delta']=a.ndcg5_c-a.ndcg5_a
        a=a.groupby(['event_id','parent_id'],as_index=False).delta.mean()
        effects.append(dict(cohort=co,comparator=arm,**interval(a,'delta')))
pd.DataFrame(effects).to_csv(O/'descriptor_effects.csv',index=False)

t=pd.read_json(R/'source_data/generation_trajectories.jsonl',lines=True)
t=t[(t.K==24)&t.arm.isin(['CONTEXT','ORBIT_ONLY'])&t.formula_sg_legal_terminal]
def signature(steps):
    return json.dumps([(s['selected_action'],s['selected_u']) for s in steps],sort_keys=True)
t['placement_signature']=t.steps.map(signature)
t['n_atoms']=t.steps.map(lambda steps:sum(s['selected_action']['multiplicity'] for s in steps))
tw=t.pivot(index='parent_id',columns='arm',values=['placement_signature','n_atoms'])
ms=pd.read_csv(R/'source_data/generation_mattersim.csv')
ms=ms[(ms.K==24)&ms.arm.isin(['CONTEXT','ORBIT_ONLY'])&ms.formula_sg_legal_terminal&ms.finite]
en=ms.pivot(index='parent_id',columns='arm',values='mattersim_energy').dropna().reset_index()
en['delta']=en.CONTEXT-en.ORBIT_ONLY
en['same_placements']=en.parent_id.map(tw['placement_signature'].CONTEXT==tw['placement_signature'].ORBIT_ONLY)
en['n_atoms']=en.parent_id.map(tw['n_atoms'].CONTEXT)
assert (en.n_atoms==en.parent_id.map(tw['n_atoms'].ORBIT_ONLY)).all()
en['delta_per_atom']=en.delta/en.n_atoms
ex=pd.read_csv(R/'supplemental_experiments/analysis/trajectory_exposure.csv')
print('EXPOSURE_COLUMNS',list(ex.columns))
if 'scorer_calls' in ex:
    active=ex[(ex.K==24)&ex.arm.isin(['CONTEXT','ORBIT_ONLY'])].groupby('parent_id').scorer_calls.max()>0
else:
    active=t.set_index('parent_id').steps.map(lambda ss:any(s.get('candidate_count',0)>1 and s.get('predicted_compatibility_score') is not None for s in ss)).groupby(level=0).max()
en['scored']=en.parent_id.map(active).fillna(False)
en.to_csv(O/'energy_pairs.csv',index=False)
es=[]
for name,mask in [('All pairs',np.ones(len(en),bool)),('Scorer used',en.scored),('No scorer',~en.scored),('Different placements',~en.same_placements),('Same placements',en.same_placements)]+[(f'Absolute energy difference > {tol:g} eV',en.delta.abs()>tol) for tol in [1e-6,.01,.1,1]]:
    g=en[mask]
    if not len(g):continue
    es.append(dict(group=name,n=len(g),lower=int((g.delta< -1e-6).sum()),tied_1e6=int((g.delta.abs()<=1e-6).sum()),higher=int((g.delta>1e-6).sum()),median=g.delta.median(),median_per_atom=g.delta_per_atom.median(),**interval(g,'delta')))
pd.DataFrame(es).to_csv(O/'energy_summary.csv',index=False)
# A rerun must reproduce the original five-seed baseline exactly.
old=pd.read_csv(R/'supplemental_experiments/ablations/event_metrics.csv')
joined=m[m.arm.isin(['ORBIT','CONTEXT'])].merge(old[old.arm.isin(['ORBIT','CONTEXT'])],on=['cohort','arm','seed','event_id'],suffixes=('_new','_old'),validate='one_to_one')
assert len(joined)==10920 and np.allclose(joined.ndcg5_new,joined.ndcg5_old,atol=1e-12)
assert len(en)==447 and int(en.scored.sum())==83
assert len(pd.read_csv(R/'supplemental_experiments/subsets_torch/fits.csv'))==150
(O/'verification.json').write_text(json.dumps({'baseline_rows_reproduced':len(joined),'fits':150,'paired_terminals':len(en),'scored_pairs':int(en.scored.sum()),'same_placement_sequences':int(en.same_placements.sum()),'candidate_n':len(c),'event_n':c.event_id.nunique(),'source_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [R/'reproducibility/inputs/atlas_candidates.csv',R/'reproducibility/inputs/external_candidates.csv']}},indent=2))
print(pd.DataFrame(fs).to_string(index=False));print(pd.DataFrame(es).to_string(index=False))
