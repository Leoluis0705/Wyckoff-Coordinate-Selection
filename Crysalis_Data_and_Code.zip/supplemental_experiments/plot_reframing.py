from pathlib import Path
import numpy as np,pandas as pd,json
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];D=R/'supplemental_experiments/reframing';O=R/'figures';O.mkdir(parents=True,exist_ok=True)
mpl.rcParams.update({'font.family':'Arial','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.7,'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,'legend.frameon':False,'pdf.fonttype':42,'svg.fonttype':'none'})
blue='#465B88';coral='#DB5243';teal='#309D88';purple='#B08FC2';gray='#89939C'
def save(fig,name):
 for ext in ['pdf','svg']:fig.savefig(O/f'{name}.{ext}',facecolor='white')
 fig.savefig(O/f'{name}.png',dpi=600,facecolor='white');fig.savefig(O/f'{name}_preview.png',dpi=150,facecolor='white');plt.close(fig)
def title(ax,letter,text):ax.set_title(text,loc='left',fontsize=10,pad=13);ax.text(-.16,1.07,letter,transform=ax.transAxes,fontsize=12,fontweight='bold')
e=pd.read_csv(D/'event_spread.csv')
f,axs=plt.subplots(2,2,figsize=(7.2,5.4));f.subplots_adjust(left=.10,right=.98,bottom=.10,top=.92,hspace=.62,wspace=.38)
for cohort,c in [('Development',teal),('Additional parents',purple)]:
 q=e[e.cohort==cohort];x=np.sort(q.span_ratio);axs[0,0].plot(x,np.arange(1,len(x)+1)/len(x),c=c,lw=1.6,label=cohort)
axs[0,0].set(xscale='log',xlabel=r'Within-event force ratio $F_{max}/F_{min}$',ylabel='Cumulative fraction',ylim=(0,1.04));axs[0,0].axvline(10,color=gray,ls=':',lw=.8);axs[0,0].legend(fontsize=7,loc='lower right');title(axs[0,0],'a','Force span within the same orbit action')
for ax,field,letter,text in [(axs[0,1],'d','b','Free-coordinate dimension'),(axs[1,0],'space_group','c','Space group'),(axs[1,1],'multiplicity','d','Orbit multiplicity')]:
 cats=sorted(e[field].unique());
 for j,(cohort,c) in enumerate([('Development',teal),('Additional parents',purple)]):
  for k,cat in enumerate(cats):
   v=e[(e.cohort==cohort)&(e[field]==cat)].iqr_log1p.to_numpy()
   if not len(v):continue
   x=k+(-.16 if j==0 else .16);lo,med,hi=np.quantile(v,[.25,.5,.75]);ax.plot([x,x],[lo,hi],color=c,lw=3.2,solid_capstyle='round');ax.scatter(x,med,s=20,color=c,edgecolor='white',lw=.6,zorder=3)
 ax.set(xticks=range(len(cats)),xticklabels=[str(int(x)) for x in cats],xlabel={'d':'Number of free coordinates','space_group':'Space-group number','multiplicity':'Atoms per expanded orbit'}[field],ylabel=r'IQR of $\ln(1+F/F_0)$');ax.axhline(.5,color=gray,lw=.7,ls=':');title(ax,letter,text)
save(f,'ResidualFreedom')
r=pd.read_csv(D/'ranking_summary.csv');m=pd.read_csv(D/'combined_seed_events.csv');f,axs=plt.subplots(1,2,figsize=(7.2,3.5));f.subplots_adjust(left=.19,right=.98,bottom=.17,top=.86,wspace=.75)
order=['Contact','Distance','Orbit-only','Context','Oracle'];labels=['Contact penalty','Largest distance','Orbit-only','Full context','Label oracle']
for j,(cohort,c) in enumerate([('Development',teal),('Additional parents',purple)]):
 for y,arm in enumerate(order):
  q=r[(r.cohort==cohort)&(r.arm==arm)].iloc[0];yy=y+(-.10 if j==0 else .10);axs[0].plot([q.ndcg_lo,q.ndcg_hi],[yy,yy],c=c,lw=1.3);axs[0].scatter(q.ndcg,yy,s=23,c=c,zorder=3)
axs[0].set(yticks=range(5),yticklabels=labels,xlim=(.35,1.025),xlabel='Mean NDCG@5');title(axs[0],'a','Analytic and learned rankings')
order2=['CONTACT3','ORBIT','CONTACT_MATCHED','CONTEXT'];lab2=['Contact features only','Orbit-only','Orbit + contact features','Full context']
for j,(cohort,c) in enumerate([('development',teal),('additional',purple)]):
 for y,arm in enumerate(order2):
  q=m[(m.cohort==cohort)&(m.arm==arm)].groupby('seed').ndcg5.mean().to_numpy();yy=y+(-.10 if j==0 else .10);axs[1].plot([q.min(),q.max()],[yy,yy],c=c,lw=1.2);axs[1].scatter(q,yy+np.linspace(-.045,.045,len(q)),s=15,c=c,edgecolors='white',lw=.3)
axs[1].set(yticks=range(4),yticklabels=lab2,xlim=(.49,.75),xlabel='Mean NDCG@5');title(axs[1],'b','Contact-feature controls')
for ax in axs:ax.invert_yaxis();ax.spines['left'].set_visible(False);ax.tick_params(axis='y',length=0)
f.legend([mpl.lines.Line2D([],[],color=teal,marker='o',ls=''),mpl.lines.Line2D([],[],color=purple,marker='o',ls='')],['Development','Additional parents'],loc='lower center',ncol=2,fontsize=8,bbox_to_anchor=(.5,-.005));save(f,'RankingControls')
p=pd.read_csv(D/'independent_contact_pairs.csv');c=pd.read_csv(D/'contact_strata.csv');f,axs=plt.subplots(2,2,figsize=(7.2,5.3));f.subplots_adjust(left=.10,right=.98,bottom=.10,top=.91,wspace=.48,hspace=.64)
for x,y in zip(p.force_ORBIT_ONLY,p.force_CONTEXT):axs[0,0].plot([0,1],np.log1p([x,y]),color='#D9DEE3',lw=.55,zorder=1)
for j,(col,colr) in enumerate([('force_ORBIT_ONLY',blue),('force_CONTEXT',coral)]):
 v=p[col].to_numpy();jitter=np.random.default_rng(10+j).uniform(-.07,.07,len(v));axs[0,0].scatter(j+jitter,np.log1p(v),s=10,c=colr,alpha=.6,zorder=2);axs[0,0].plot([j-.16,j+.16],[np.log1p(np.median(v))]*2,c=colr,lw=2)
axs[0,0].set(xticks=[0,1],xticklabels=['Orbit-only','Context'],yticks=np.log1p([0,1,10,100,1000]),yticklabels=['0','1','10','100','1000'],ylabel=r'MatterSim force (eV Å$^{-1}$)');title(axs[0,0],'a','Selected candidates · 96 pairs')
for y,(group,label) in enumerate([('Contact residual > 0','Short contact · n = 23'),('Contact residual = 0','No short contact · n = 73')]):
 q=c[c.group==group].iloc[0];axs[0,1].errorbar(q['mean'],y,xerr=[[q['mean']-q.lo],[q.hi-q['mean']]],fmt='o',color=teal,capsize=3,lw=1.3)
axs[0,1].set(yticks=[0,1],yticklabels=['Short contact\nn = 23','No short contact\nn = 73'],ylim=(-.6,1.6),xlabel=r'Mean paired $\Delta\ln(1+F/F_0)$');axs[0,1].invert_yaxis();axs[0,1].axvline(0,c=gray,ls=':',lw=.9);title(axs[0,1],'b','Gain by initial contact geometry')
# Retain the original event-paired quartile estimates and intervals (Table S6).
q=pd.read_csv(R/'source_data/independent_potential_groups.csv')
q=q[(q.potential=='MATTERSIM')&(q.grouping=='ORBIT_FORCE_QUARTILE')]
for y,group in enumerate(['Q1','Q2','Q3','Q4']):
 row=q[q.group==group].iloc[0];mean=row.delta_mean
 axs[1,0].errorbar(mean,y,xerr=[[mean-row.ci_lower],[row.ci_upper-mean]],fmt='o',color=coral,capsize=3,lw=1.2)
axs[1,0].set(yticks=range(4),yticklabels=['Q1','Q2','Q3','Q4'],xlabel=r'Mean paired $\Delta\ln(1+F/F_0)$');axs[1,0].invert_yaxis();axs[1,0].axvline(0,c=gray,ls=':',lw=.8);title(axs[1,0],'c','Initial-force quartiles · 24 pairs each')
d=pd.read_csv(R/'source_data/dft_results.csv');v=d.pivot(index='event_key',columns='arm',values='max_force_ev_per_a').sort_index();conv=d[d.arm=='parent'].set_index('event_key').scf_converged
for i,(key,row) in enumerate(v.iterrows(),1):
 axs[1,1].plot([i,i],[row.orbit_only,row.context],c='#BFC7CF',lw=.8);axs[1,1].scatter(i,row.orbit_only,s=19,c=blue,marker='s');axs[1,1].scatter(i,row.context,s=19,c=coral)
 if conv[key]:axs[1,1].scatter(i,row.parent,s=14,c=gray,marker='^')
axs[1,1].set(yscale='log',ylim=(.01,30000),xticks=[1,4,7,10,12],xlabel='DFT event',ylabel=r'DFT force (eV Å$^{-1}$)');title(axs[1,1],'d','DFT check · 12 pairs')
save(f,'ContactEffects')
t=pd.read_csv(D/'threshold_spectrum.csv');f,axs=plt.subplots(1,2,figsize=(7.2,3.4));f.subplots_adjust(left=.10,right=.98,bottom=.23,top=.84,wspace=.38)
for ax,pot,letter in zip(axs,['CHGNet','MatterSim'],'ab'):
 q=t[t.potential==pot];xx=np.arange(len(q));ax.plot(xx,q.orbit_pass/512*100,c=blue,marker='o',ms=4,lw=1.5,label='Orbit-only');ax.plot(xx,q.context_pass/512*100,c=coral,marker='s',ms=4,lw=1.5,label='Context');ax.set(xticks=xx,xticklabels=['0.5','1','2','5','10'],ylim=(40,80),xlabel=r'Force threshold (eV Å$^{-1}$)',ylabel='Legal and below threshold (% of 512)');title(ax,letter,pot)
f.legend(*axs[0].get_legend_handles_labels(),loc='lower center',ncol=2,bbox_to_anchor=(.5,.015));save(f,'ThresholdSpectrum')
# TOC is a compact schematic of measured range and stratified effects, separate from manuscript pages.
f=plt.figure(figsize=(3.25,1.75));ax=f.add_axes([.17,.25,.78,.53]);q=c[c.group.isin(['Contact residual > 0','Contact residual = 0'])]
for y,(_,row) in enumerate(q.iterrows()):ax.plot([row.lo,row.hi],[y,y],c=teal,lw=2);ax.scatter(row['mean'],y,c=teal,s=20)
ax.axvline(0,c=gray,ls=':',lw=.8);ax.set(yticks=[0,1],yticklabels=['Short\ncontacts','No short\ncontacts'],ylim=(-.6,1.6),xticks=[-4,-2,0],xlabel='Context − orbit-only log force');ax.invert_yaxis();ax.tick_params(labelsize=6);ax.xaxis.label.set_size(6)
f.text(.5,.91,'Same symmetry, different forces',ha='center',fontsize=8,weight='bold');save(f,'TOC_residual_coordinates')
